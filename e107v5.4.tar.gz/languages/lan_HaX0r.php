<?php
/*
+---------------------------------------------------------------+
|	e107 website system													|
|	language file: HaX0r
|	Translated by: ShujiYomo													|
|																						|
|	�Steve Dunstan 2001-2002										|
|	http://jalist.com															|
|	stevedunstan@jalist.com											|
|																						|
|	Released under the terms and conditions of the		|
|	GNU General Public License (http://gnu.org).				|
+---------------------------------------------------------------+
*/

//articles.php/comment.php
define(LAN_0, "[b10X3d bj 4dmin]");
define(LAN_1, "unb10X0r");
define(LAN_2, "b10X0r");
define(LAN_3, "d31373");
define(LAN_4, "inph0");
define(LAN_5, "c0mm3n7z ...");
define(LAN_6, "j00 g0774 b3 10gg3d in 70 p057 - 10g in n0w 0r c1iX0r <a href=\"signup.php\">h3r3</a> 70 b3 1337");
define(LAN_7, "h4nd13: ");
define(LAN_8, "w0rdz");
define(LAN_9, "5ubmi7 w0rdz");
define(LAN_10, "w3 1ik3 5h0r7cu7z: [b] [i] [u] [img] [cen] [bq]<br />u53 [link] url [/link] ph0r 1inkz<br />1in3 br34kz (&lt;br /&gt;) r 4dd3d 4u70m4gic411j.");

//chat.php
define(LAN_11, "ch@b0X (411 p0575)");
define(LAN_12, "ch@ p057z");

//class.php
define(LAN_13, "n3wz 570rj k1in3d.");
define(LAN_14, "n3wz 570rj 0pd@3d.");
define(LAN_15, "n3wz r3c0rd3d.");
define(LAN_16, "h4nd13: ");
define(LAN_17, "p455w0rd: ");
define(LAN_18, "10g in n0w");
define(LAN_19, "c4n'7 wri73 n3wz.Xm1 - /backend n33dz p3rmz r3537. (666)");
define(LAN_20, "3rr0r");
define(LAN_21, "vi5i7z 70d4j: ");
define(LAN_22, "vi5i7z 3v0r: ");
define(LAN_23, "5i73 vi3wz: ");
define(LAN_24, "fuck|piss|shit|cunt|cock|asshole|motherfucker|mother fucker| arse|pussy|faggot");
define(LAN_25, "b4X0r");
define(LAN_26, "ph0rw4rd");

//forum.php
define(LAN_27, "j00 g0774 phi11 3v0rj7hing in");
define(LAN_28, "i 7h0ph7 j00 w4n73d 70 p057?");
define(LAN_29, "m0diphi3d");
define(LAN_30, "w31c0m3");
define(LAN_31, "n0 n3w p057z ot");
define(LAN_32, "7h0r3'z 1 n3w p057 ");
define(LAN_33, "7h0r3 r");
define(LAN_34, "n3w p057z");
define(LAN_35, "5inc3 j00 w4z h0r3.");
define(LAN_36, "j00 w4z h0r3 @ ");
define(LAN_37, "i7'z n0w ");
define(LAN_38, ", 411 7im3z iz GMT.");
define(LAN_39, "70741 70picz");
define(LAN_40, "70741 p057z.");
define(LAN_41, "7ha n00b1e57: ");
define(LAN_42, "1337z: ");
define(LAN_43, "j00 c4n 100k iph j00 4in'7 r39i570r3d, bu7 j00 c4n'7 533 n3w p057z, 3di7/d31373 j00r p057z un135z j00 <a href=\"signup.php\">r3gi570r</a> 4nd 10g in.");
define(LAN_44, "j00 c4n p057 iph j00 4in'7 r39i570r3d, bu7 w3'r3 wri7in9 d0wn j00r ip 4nd wi11 0wn j00.");
define(LAN_45, "j00 c4n'7 p057 un135z j00'r3 1337. c1iX0r <a href=\"signup.php\">h3r3</a> 70 b3 1337. ");
define(LAN_46, "b04rdz");
define(LAN_47, "7hr34dz");
define(LAN_48, "r3p1i3z");
define(LAN_49, "1457 p057");
define(LAN_50, "n4rcz");
define(LAN_51, "n0 b04rdz j37, 7h3 4dminz r 14zj.");
define(LAN_52, "n0 b04rdz in 7hiz 53c7i0n j37, 7h3 4dminz r 14zj.");
define(LAN_53, "7hr34d");
define(LAN_54, "574r70r");
define(LAN_55, "r3p1i3z");
define(LAN_56, "vi3wz");
define(LAN_57, "1457 p057");
define(LAN_58, "n0 0n3 p0573d 0n 7hiz b04rd j37. b3 1337 4nd d0 i7 j00r531ph.");
define(LAN_59, "j00 90774 b3 1337 70 p057. c1iX0r <a href=\"signup.php\">h0r3</a> 70 b3 1337, 0r 10g in, ph001.");
define(LAN_60, "574r7 n3w 7hr34d");
define(LAN_61, "h4nd13: ");
define(LAN_62, "5ubj3c7: ");
define(LAN_63, "p057: ");
define(LAN_64, "5ubmi7 n3w 7hr34d");
define(LAN_65, "j00 7h3 m4n - m0d0r@i0n 0n");
define(LAN_66, "7hr34d c1053d");
define(LAN_67, "p057z");
define(LAN_68, "m0diphj");
define(LAN_69, "k1in3");
define(LAN_70, "m0v3");
define(LAN_71, "n0 r3p1i3z.");
define(LAN_72, "0ri9in411j 5p3w3d bj");
define(LAN_73, "r3p1j: ");
define(LAN_74, "r3p1j 70 7hr34d");
define(LAN_75, "p057 r3p1j");
define(LAN_76, "r3p1j");
define(LAN_77, "0pd@3 7hr34d");
define(LAN_78, "upd@3 r3p1j");
define(LAN_79, "n3w p057z");
define(LAN_80, " n0 n3w p057z");
define(LAN_81, "c1053d 7hr34d");

//index.php
define(LAN_82, "n3wz - c@390rj");
define(LAN_83, "n0 n3wz j37, 7h3 4dminz r 14zj.");
define(LAN_84, "n3wz i73mz");

//links.php
define(LAN_85, "n0 1inkz j37.");
define(LAN_86, "c@390rj:");
define(LAN_87, "bu770n 4");
define(LAN_88, "r3ph0rr41z:");
define(LAN_89, "4dmin: ");
define(LAN_90, "4dd n3w 1ink in 7hiz c@390rj");
define(LAN_91, "4dd n3w c@390rj");

//oldpolls.php
define(LAN_92, "01d p011z");
define(LAN_93, "n0 01d p011z j37.");
define(LAN_94, "p0573d bj");
define(LAN_95, "70741 v073z:");
define(LAN_96, "p011z");

//search.php
define(LAN_97, "n0 m@ch3z.");
define(LAN_98, "n3wz i73mz");
define(LAN_99, "c0mm3n7z");
define(LAN_100, "4r7ic13z");
define(LAN_101, "ch@b0X"); 
define(LAN_102, "1inkz");
define(LAN_103, "ph0rum");

//signup.php
define(LAN_104, "u50r 3Xi57z. ch0053 4 n3w h4nd13.");
define(LAN_105, "j00r p455w0rdz d0n'7 m@ch.");
define(LAN_106, "i 54id 3m4i1, n07 n4m3. r3-7jp3 7h@.");
define(LAN_107, "j00'r3 n0w 7h3 1337357 m3mb0r uv ".SITENAME."");
define(LAN_108, "r39i57r@i0n c0mp1373");
define(LAN_109, "This site complies with The Children's Online Privacy Protection Act of 1998 (COPPA) and as such cannot accept registrations from users under the age of 13 without a written permission document from their parent or guardian. For more information you can read the legislation <a href=\"http://www.cdt.org/legislation/105th/privacy/coppa.html\">here</a>. Please contact the main site admin <a href=\"mailto:".SITEADMINEMAIL."\">here</a> if you require assistance.<br /><br /><div style=\"text-align:center\"><b>If you are over the age of 13 please click <a href=\"signup.php?stage1\">here</a> to continue the registration process.");
define(LAN_110, "r39i57r@i0n");
define(LAN_111, "r3-7jp3 p455w0rd: ");
define(LAN_112, "3m4i1: ");
define(LAN_113, "hid3 3m4i1 4ddr35z?: ");
define(LAN_114, "(7h@ m34nz n0 0n3 c4n 533 i7 135z 7h3j'r3 1337.)");
define(LAN_115, "ICQ numb0r: ");
define(LAN_116, "AIM h4nd13: ");
define(LAN_117, "MSN h4nd13: ");
define(LAN_118, "bir7hd4j: ");
define(LAN_119, "10c@i0n: ");
define(LAN_120, "5i9n@ur3: ");
define(LAN_121, "pic: ");
define(LAN_122, "7im3z0n3:");
define(LAN_123, "r39i570r");

//stats.php
define(LAN_124, "70741 uniqu3 5i73 vi3w5: ");
define(LAN_125, "70741 5i73 vi3w5: ");
define(LAN_126, "uniqu3 vi3wz bj p493: ");
define(LAN_127, "70741 vi3wz bj p493: ");
define(LAN_128, "br0w50r: ");
define(LAN_129, "0p0r@in9 5j573m: ");
define(LAN_130, "c0un7ri35/d0m4inz vi5i73d phr0m: ");
define(LAN_131, "r3ph0r0r5: ");
define(LAN_132, "5i73 57@i57icz");

//submitnews.php
define(LAN_133, "7h4nkz");
define(LAN_134, "w3 907 j00r 5ubmi55i0n, w3'11 100k @ i7 1@0r.");
define(LAN_135, "n3wz i73m: ");
define(LAN_136, "5ubmi7 n3wz i73m");

//user.php
define(LAN_137, "7h0r3 iz n0 inph0rm@i0n 0n 7hiz u50r, c4u53 7h3j 4r3n'7 r39i570r3d @");
define(LAN_138, "r39i570r3d m3mb0rz: ");
define(LAN_139, "0rd0r: ");
define(LAN_140, "r39i570r3d m3mb0rz");
define(LAN_141, "n0 r39i570r3d m3mb0rz j37.");
define(LAN_142, "m3mb0r");
define(LAN_143, "[hidd3n bj p4r4n0i4]");
define(LAN_144, "w3b5i73 ur1: ");
define(LAN_145, "r39i570r3d:");
define(LAN_146, "vi5i7z 5inc3 r39i57r@i0n: ");
define(LAN_147, "ch@b0X p057z: ");
define(LAN_148, "c0mm3n7z p0573d: ");
define(LAN_149, "ph0rum p057z: ");

//usersettings.php
define(LAN_150, "5377in9z upd@3d.");
define(LAN_151, "0k");
define(LAN_152, "n3w p455w0rd: ");
define(LAN_153, "r3-7jp3 n3w p455w0rd: ");
define(LAN_154, "upd@3 5377in9z");
define(LAN_155, "upd@3 u50r 5377in9z");
define(LAN_185, "p455w0rd phi31d iz b14nk, n00b.");

//plugins
define(LAN_156, "5ubmi7");
define(LAN_157, "r3537");
define(LAN_158, "n0 m355493z j37.");
define(LAN_159, "vi3w 411 p057z");
define(LAN_160, "w3bm4570r: ");
define(LAN_161, "h34d1in3z");
define(LAN_162, "n0 4c7iv3 5urv3j.");
define(LAN_163, "5ubmi7 v073");
define(LAN_164, "v0735: ");
define(LAN_165, "01d 5urv3jz");

//menus
define(LAN_166, "n0 4r7ic13z j37.");
define(LAN_167, "4r7ic13z");
define(LAN_168, "0ur h34d1in3z c4n b3 5jndic@3d bj 05in9 3i7h0r 0ur r5z 0r 73X7 ph33dz..");
define(LAN_169, "b4X3nd");
define(LAN_170, "w3c c0mp1i4nc3");
define(LAN_171, "uniqu3 u50r id n07 r3c09ni53d (p055ib13 c0rrup73d c00ki3).<br />Please <a href=\"index.php?logout\">c1iX0r h0r3</a> 70 k1in3 j00r c00ki3.");
define(LAN_172, "1090u7");
define(LAN_173, "109in 0rr0r");
define(LAN_174, "5i9nup");
define(LAN_175, "109in");
define(LAN_176, "u50rz 0n 7hiz p493: ");
define(LAN_177, "u50rz 0n 5i73: ");
define(LAN_178, "10993d in u50r5: ");
define(LAN_179, "0n1in3");
define(LAN_180, "534rch");
define(LAN_181, "1ink 70 uz");
define(LAN_182, "ch@b0X");
define(LAN_183, "m4in m3nu");
define(LAN_184, "p011");

// #### Added in v5 #### //

define(LAN_186, "53nd n3wz i73m");
define(LAN_187, "3m4i1 4ddr35z 70 53nd 70");
define(LAN_188, "i 7h0ph7 j00 mi9h7 b3 in70r3573d in 7hiz n3wz 570rj phr0m");
define(LAN_189, "p0w0r3d bj");
define(LAN_190, "r3vi3w5");
define(LAN_191, "inph0rm@i0n");
define(LAN_192, "7h3 u50rz uv 7hiz ph0rum h4v3 p0573d 4 70741 uv ");
define(LAN_193, "ph0rum m0d0r@0r");
define(LAN_194, "9u357");
define(LAN_195, "r39i570r3d m3mb0r");
define(LAN_196, "j00 h4v3 r34d ");
define(LAN_197, " uv 7h353 p057z.");
define(LAN_198, " 411 n3w p057z h4v3 b33n r34d.");
define(LAN_199, "m4rk 411 p057z 4z r34d");
define(LAN_200, "c1053 7hiz 7hr34d");
define(LAN_201, "r30p3n 7hiz 7hr34d");
define(LAN_202, "57iXj 7hr34d");
define(LAN_203, "57iXj/c1053d 7hr34d");
define(LAN_204, "j00 <b>c4n</b> 574r7 n3w 7hr34dz");
define(LAN_205, "j00 <b>c4nn07</b> 574r7 n3w 7hr34dz");
define(LAN_206, "j00 <b>can</b> p057 r3p1i3z");
define(LAN_207, "j00 <b>c4nn07</b> p057 r3p1i3z");
define(LAN_208, "j00 <b>can</b> 3di7 j00r p057z");
define(LAN_209, "j00 <b>c4nn07</b> 3di7 j00r p057z");
define(LAN_210, "j00 <b>can</b> d31373 j00r p057z");
define(LAN_211, "j00 <b>c4nn07</b> d31373 j00r p057z");
define(LAN_212, "ph0r907 p455w0rd?");
define(LAN_213, "7h@ u50rn4m3/3m4i1 4ddr35z w4z n07 ph0und in d@4b453.");
define(LAN_214, "un4b13 70 r3537 p455w0rd");
define(LAN_215, "j00r p455w0rd 4 ".SITENAME." h4z b33n r3537. j00r n3w p455w0rd iz\n\n");
define(LAN_216, "70 v41id@3 j00r n3w p455w0rd p13453 90 70 7h3 ph0110win9 ur1 ...");
define(LAN_217, "7h4nkz, j00r n3w p455w0rd iz n0w v41id@3d. j00 m4j n0w 109in u5in9 j00r n3w p455w0rd.");


?>