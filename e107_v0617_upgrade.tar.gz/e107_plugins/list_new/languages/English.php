<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/


define("LIST_1", "News Items");
define("LIST_2", "Comments");
define("LIST_3", "New since your last visit ...");
define("LIST_4", "None");
define("LIST_5", "Chatbox posts");
define("LIST_6", "Forum posts");
define("LIST_7", "New members");
define("LIST_8", "found");
define("LIST_9", "news items");
define("LIST_10", "returned");
define("LIST_11", "Admin");
define("LIST_12", "Settings");
define("LIST_13", "Profile");
define("LIST_14", "Article");
define("LIST_15", "Content");
define("LIST_16", "Review");
define("LIST_17", "Download");
define("LIST_18", "FAQ");
define("LIST_18", "Poll");
define("LIST_19", "Docs");
define("LIST_20", "Bugtracker");

define("LIST_21", "Articles");


?>