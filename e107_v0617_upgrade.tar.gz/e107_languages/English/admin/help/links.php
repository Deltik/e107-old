<?php
$text = "Enter all your site links here. For main site links (the ones displayed in your main navigation bar) set the category to 'Main', any others will be displayed on the Links page. You can seperate these links into different categories.
<br />
<br />
The submenus generator is ONLY usefull for e107 DHTML menus (TreeMenu, UltraTreeMenu, eDynamicMenu, ypSlideMenu...)";
$ns -> tablerender("Links Help", $text);
?>