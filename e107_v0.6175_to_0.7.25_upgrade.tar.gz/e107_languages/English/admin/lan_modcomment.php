<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_modcomment.php $
|     $Revision: 11678 $
|     $Id: lan_modcomment.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderated.");
define("MDCLAN_2", "No comments for this item");
define("MDCLAN_3", "Member");
define("MDCLAN_4", "Guest");
define("MDCLAN_5", "unblock");
define("MDCLAN_6", "block");

define("MDCLAN_8", "Moderate Comments");
define("MDCLAN_9", "Warning! Deleting Parent comments will also delete all replies!");

define("MDCLAN_10", "options");
define("MDCLAN_11", "comment");
define("MDCLAN_12", "comments");
define("MDCLAN_13", "blocked");
define("MDCLAN_14", "lock comments");
define("MDCLAN_15", "open");
define("MDCLAN_16", "locked");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>