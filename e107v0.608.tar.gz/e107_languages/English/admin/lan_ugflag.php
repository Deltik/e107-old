<?php

define("UGFLAN_1", "Maintainance setting updated");
define("UGFLAN_2", "Activate maintenance flag");
define("UGFLAN_3", "Update Maintanance Setting");
define("UGFLAN_4", "Maintanance Setting");

define("UGFLAN_5", "Text to display when site down");
define("UGFLAN_6", "Leave blank to display default message");

?>