<?php

$e107info['e107_version'] = "v0.608";
$e107info['e107_build'] = "0";

?>