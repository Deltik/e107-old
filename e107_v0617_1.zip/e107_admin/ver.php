<?php

$e107info['e107_version'] = "v0.6171";
$e107info['e107_build'] = "20050513";

?>