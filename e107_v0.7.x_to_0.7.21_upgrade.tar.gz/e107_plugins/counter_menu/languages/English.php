<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_plugins/counter_menu/languages/English.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
	
define("COUNTER_L1", "Admin visits aren't being counted.");
define("COUNTER_L2", "This page today ...");
define("COUNTER_L3", "total");
define("COUNTER_L4", "This page ever ...");
define("COUNTER_L5", "unique");
define("COUNTER_L6", "Site ...");
define("COUNTER_L7", "Counter");
define("COUNTER_L8", "Admin message: <b>Stat logging is disabled.</b><br />To activate, you need to install the Statistic Logging plugin from your <a href='".e_ADMIN."plugin.php'>plugin manager</a>, then activate it from the <a href='".e_PLUGIN."log/admin_config.php'>configuration screen</a>.");
	
?>