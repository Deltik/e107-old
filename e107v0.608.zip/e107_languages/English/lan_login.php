<?php

define("LAN_27", "You left required field(s) blank");
define("LAN_300", "That username was not found in the database.");
define("LAN_301", "Incorrect password.");
define("LAN_302", "You have not activated your account. You should have received an email with instructions on how to confirm your account, if not please contact a site administrator.");

?>