<?php
$text = "Please upload your files into the /files/downloads folder, your images into the /files/downloadimages folder and thumbnail images into the /files/downloadthumbs folder.";
$ns -> tablerender("Download Help", $text);
?>