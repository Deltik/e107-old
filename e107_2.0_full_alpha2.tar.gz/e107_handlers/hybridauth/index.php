<?php
/*!
* HybridAuth
* http://hybridauth.sourceforge.net | https://github.com/hybridauth/hybridauth
*  (c) 2009-2011 HybridAuth authors | hybridauth.sourceforge.net/licenses.html
*/

// ------------------------------------------------------------------------
//	HybridAuth End Point
// ------------------------------------------------------------------------
require_once("../../class2.php"); 
require_once( "Hybrid/Auth.php" );
require_once( "Hybrid/Endpoint.php" ); 

Hybrid_Endpoint::process();
