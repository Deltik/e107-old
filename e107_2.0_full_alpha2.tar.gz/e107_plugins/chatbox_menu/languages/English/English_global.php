<?php


define("LAN_PLUGIN_CHATBOX_MENU_NAME",		 	"Chatbox");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", 	"Chatbox Menu");

// Admin Log 
//FIXME - Global LANS must begin with LAN_PLUGIN_{FOLDER_NAME}_ 
define("LAN_AL_CHBLAN_01","Chatbox settings updated");
define("LAN_AL_CHBLAN_02","Chatbox pruned");
define("LAN_AL_CHBLAN_03","Chatbox posts recalculated");
define("LAN_AL_CHBLAN_04","");
define("LAN_AL_CHBLAN_05","");

// Notify
define("NT_LAN_CB_1", "Chatbox Events");
define("NT_LAN_CB_2", "Message posted");
define("NT_LAN_CB_3", "Posted by");
define("NT_LAN_CB_4", "IP Address");
define("NT_LAN_CB_5", "Message");
define("NT_LAN_CB_6", "Chatbox Message Posted");

?>