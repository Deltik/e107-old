<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2013 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 */

define("BLOGCAL_L1", "News by month");
define("BLOGCAL_L2", "Archive");
define("BLOGCAL_1", "News Items");
	
define("BLOGCAL_CONF1", "Months/row");
define("BLOGCAL_CONF2", "Cellpadding");
//define("BLOGCAL_CONF3", "Update Menu Settings");
define("BLOGCAL_CONF4", "BlogCal Menu Configuration");
//define("BLOGCAL_CONF5", "BlogCal menu configuration saved");
define("BLOGCAL_ARCHIV1", "Select Archive");
	
?>