<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.8/e107_languages/English/lan_membersonly.php,v $
|     $Revision$
|     $Date$
|     $Author$
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Members Only");

define("LAN_MEMBERS_0", "restricted area");
define("LAN_MEMBERS_1", "This is a restricted area.");
define("LAN_MEMBERS_2","For access please <a href='".e_LOGIN."'>log in</a>");
define("LAN_MEMBERS_3","or <a href='".e_SIGNUP."'>register</a> as a member");
define("LAN_MEMBERS_4","Click here to return to front page");


?>