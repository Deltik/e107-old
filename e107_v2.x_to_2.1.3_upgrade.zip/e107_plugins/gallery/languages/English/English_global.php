<?php

/**
 * @file
 * Language file for "gallery" plugin.
 */

define("LAN_PLUGIN_GALLERY_TITLE", "Gallery");
define("LAN_PLUGIN_GALLERY_DIZ", "A simple image gallery");

define("LAN_PLUGIN_GALLERY_SEF_01", "Gallery SEF");
define("LAN_PLUGIN_GALLERY_SEF_02", "SEF URLs enabled.");
define("LAN_PLUGIN_GALLERY_SEF_03", "SEF URLs disabled.");
define("LAN_PLUGIN_GALLERY_SEF_04", "Gallery default");
