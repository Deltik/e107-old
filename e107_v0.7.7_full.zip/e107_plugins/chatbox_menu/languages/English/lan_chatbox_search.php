<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/English/lan_chatbox_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/19 09:12:53 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");

?>