<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/10 21:31:57 $
|     $Author: loloirie $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Select Language to verify");
define("LAN_CHECK_2", "Begin Verify");
define("LAN_CHECK_3", "Verification of");
define("LAN_CHECK_4", "File missing!");
define("LAN_CHECK_5", "Phrase missing!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "phrase");

define("LAN_CHECK_8", "A file is missing...");
define("LAN_CHECK_9", " files are missing...");
define("LAN_CHECK_10", "Critical error: ");
define("LAN_CHECK_11", "No file missing !");
define("LAN_CHECK_12", "A file is wrong...");
define("LAN_CHECK_13", " files are wrong...");
define("LAN_CHECK_14", "All existing files are valid !");

?>
