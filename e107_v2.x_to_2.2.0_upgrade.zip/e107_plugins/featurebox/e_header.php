<?php


if (!defined('e107_INIT')){ exit; } 

if(USER_AREA)
{
	e107::css('featurebox', 'featurebox.css');
}
