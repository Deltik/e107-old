<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/09 15:38:12 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Download Error");
define("LAN_dl_62", "You have been prevented from downloading this file, you have exceeded your download quota");
define("LAN_dl_63", "You do not have the correct permissions to download this file.");
define("LAN_dl_64", "Back");
define("LAN_dl_65", "File Not Found");

?>