<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/15 15:18:40 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Content");
define("CONT_SCH_LAN_2", "All Content Categories");
define("CONT_SCH_LAN_3", "Posted in reply to item");

?>