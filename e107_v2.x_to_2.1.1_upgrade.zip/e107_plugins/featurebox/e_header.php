<?php
if (!defined('e107_INIT')){ exit; } 
//XXX If you need 'camera' please include it in your theme file.
/*
if(USER_AREA)
{
	e107::css('core','camera/css/camera.css','jquery');
}*/
?>