// UK lang variables
tinyMCE.addI18n('en.ibrowser',{
	desc : 'Image Browser'
});