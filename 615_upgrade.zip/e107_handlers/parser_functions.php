<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/e107_handlers/parser_functions.php
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
function e107core_parse($match){
	
}

?>
