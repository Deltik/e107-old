<?php

define("PAGE_NAME", "Members Only"); 

define("LAN_MEMBERS_0", "restricted area");
define("LAN_MEMBERS_1", "This is a ".LAN_MEMBERS_0);
define("LAN_MEMBERS_2","to access it either log in or");
define("LAN_MEMBERS_3","register as a member");
define("LAN_MEMBERS_4","Click here to return to front page");

?>