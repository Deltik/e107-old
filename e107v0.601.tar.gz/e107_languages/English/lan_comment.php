<?php

define("PAGE_NAME", "Comments"); 

define("LAN_0", "[blocked by admin]");
define("LAN_1", "Unblock");
define("LAN_2", "Block");
define("LAN_3", "Delete");
define("LAN_4", "Info");
define("LAN_5", "Comments ...");
define("LAN_6", "You must be logged in to post comments on this site - please either log in or if you are not registered click <a href='".e_BASE."signup.php'>here</a> to signup");
define("LAN_7", "Main site administrator");
define("LAN_8", "Comment");
define("LAN_9", "Submit comment");
define("LAN_10", "Administrator");
define("LAN_11", "<b>Error!</b> Was unable to enter your comment into the database - please retype leaving out any non-standard characters.");
define("LAN_16", "Username: ");
define("LAN_99", "Comments");
define("LAN_145", "Registered: ");
define("LAN_194", "Guest");
define("LAN_310", "Unable to accept post as that username is registered - if it is your username please login to post.");
define("LAN_312", "Duplicate post - unable to accept.");

?>