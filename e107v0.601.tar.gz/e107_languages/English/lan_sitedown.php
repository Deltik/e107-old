<?php

define("LAN_00", "<b>- Temporarily Closed -</b><br /><br />We have temporarily closed the site for some essential maintainance. This shouldn't take too long - please check back soon, apologies for the inconvinience.");

?>