<?php

define("BANLAN_1", "Ban removed.");
define("BANLAN_2", "No bans.");
define("BANLAN_3", "Existing Bans");
define("BANLAN_4", "Remove ban");
define("BANLAN_5", "Ban by IP");
define("BANLAN_6", "Ban by email address"); 
define("BANLAN_7", "Reason");
define("BANLAN_8", "Ban User");
define("BANLAN_9", "Ban users from site");

?>