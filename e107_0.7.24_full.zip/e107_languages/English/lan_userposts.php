<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_userposts.php $
|     $Revision: 11678 $
|     $Id: lan_userposts.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "User Posts");

define("UP_LAN_0", "All Forum Posts for ");
define("UP_LAN_1", "All Comments for ");
define("UP_LAN_2", "Thread");
define("UP_LAN_3", "Views");
define("UP_LAN_4", "Replies");
define("UP_LAN_5", "Lastpost");
define("UP_LAN_6", "Threads");
define("UP_LAN_7", "No Comments");
define("UP_LAN_8", "No Posts");
define("UP_LAN_9", " on ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Posted on");
define("UP_LAN_12", "Search");
define("UP_LAN_13", "Comments");
define("UP_LAN_14", "Forum Posts");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP Address");
?>