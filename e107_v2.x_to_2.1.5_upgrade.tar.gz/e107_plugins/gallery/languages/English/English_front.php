<?php

/**
 * @file
 * Language file for "gallery" plugin.
 */

define("LAN_GALLERY_FRONT_01", "Right-click > Save Link As");
define("LAN_GALLERY_FRONT_02", "Expand the image");