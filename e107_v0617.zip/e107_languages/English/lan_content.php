<?php

define("PAGE_NAME", "Article/Review");

define("LAN_1", "Article");
define("LAN_2", "Review");
define("LAN_3", "Category");


define("LAN_25", "Previous Page");
define("LAN_26", "Next Page");
define("LAN_27", "List reviews in this category");
define("LAN_28", "Back to reviews front page");
define("LAN_29", "moderate comments");
define("LAN_30", "Back to reviews front page");
define("LAN_31", "No matches");
define("LAN_32", "Recent Reviews");
define("LAN_33", "reviews");
define("LAN_34", "review");
define("LAN_35", "Review Categories");
define("LAN_36", "List articles in this category");
define("LAN_37", "Back to articles front page");


define("LAN_38", "vote");
define("LAN_39", "votes");
define("LAN_40", "How would you rate this article?");
define("LAN_41", "thanks for submitting your rating");
define("LAN_42", "Rating");
define("LAN_43", "by ");
define("LAN_44", " on ");
define("LAN_45", "No articles in this category");
define("LAN_46", "Archive");
define("LAN_47", "Recent Articles");

define("LAN_48", "articles");
define("LAN_49", "article");
define("LAN_50", "Article Categories");
define("LAN_51", "This article cannot be viewed.");
define("LAN_52", "Error");
define("LAN_53", "This review cannot be viewed.");
define("LAN_54", "This page cannot be viewed.");

define("LAN_55", "No reviews yet.");
define("LAN_56", "No articles yet.");
define("LAN_57", "Articles");
define("LAN_58", "Reviews");
define("LAN_59", "View");
define("LAN_60", "Content");

define("LAN_61", "Uncategorized");
define("LAN_62", "Archive");
define("LAN_63", "page");
define("LAN_64", "This article has been rated: ");
define("LAN_65", "Not rated");

?>