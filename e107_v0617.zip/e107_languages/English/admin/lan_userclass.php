<?php

define("UCSLAN_1", "Sending notification email to");
define("UCSLAN_2", "Updated Privelages");
define("UCSLAN_3", "Dear");
define("UCSLAN_4", "Your privelages have been updated at");
define("UCSLAN_5", "You now have access to the following area(s)");
define("UCSLAN_6", "Set class for user");
define("UCSLAN_7", "Set Classes");
define("UCSLAN_8", "Notify User");
define("UCSLAN_8", "Classes Updated.");
define("UCSLAN_9", "Regards");

?>