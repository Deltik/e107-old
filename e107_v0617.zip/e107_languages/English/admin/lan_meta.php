<?php

define("METLAN_1", "Meta tags updated in database");
define("METLAN_2", "Enter meta-tags");
define("METLAN_3", "Enter new meta tag settings");
define("METLAN_4", "Updated");
define("METLAN_5", "type your description here");
define("METLAN_6", "type, a, list, of, your, keywords, here");
define("METLAN_7", "type your copyright info here");
define("METLAN_8", "Meta Tags");


?>