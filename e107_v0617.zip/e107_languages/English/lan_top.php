<?php


define("TOP_LAN_0", "Top Forum Posters");
define("TOP_LAN_1", "User Name");
define("TOP_LAN_2", "Posts");
define("TOP_LAN_3", "Top Comment Posters");
define("TOP_LAN_4", "Comments");
define("TOP_LAN_5", "Top Chatbox Posters");
define("TOP_LAN_6", "Site Rating");

//v.616
define("LAN_1", "Thread");
define("LAN_2", "Poster");
define("LAN_3", "Views");
define("LAN_4", "Replies");
define("LAN_5", "Lastpost");
define("LAN_6", "Threads");
define("LAN_7", "Most Active Threads");
define("LAN_8", "Top Posters");


?>