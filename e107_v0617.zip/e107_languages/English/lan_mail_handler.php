<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107/e107_languages/English/lan_mail_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/09/10 02:58:00 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Produced By e107 website system");
define("LANMAILH_2", "This is a multi-part message in MIME format.");
define("LANMAILH_3", " is not properly formatted");
define("LANMAILH_4", "Server rejected address");
define("LANMAILH_5", "No response from server");
define("LANMAILH_6", "Cannot find E-Mail server.");
define("LANMAILH_7", " appears to be valid.");


?>