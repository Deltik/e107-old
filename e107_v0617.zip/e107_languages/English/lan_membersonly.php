<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107/e107_languages/English/lan_membersonly.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/09/10 02:58:00 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Members Only");

define("LAN_MEMBERS_0", "restricted area");
define("LAN_MEMBERS_1", "This is a restricted area");
define("LAN_MEMBERS_2","to access it either log in or");
define("LAN_MEMBERS_3","register as a member");
define("LAN_MEMBERS_4","Click here to return to front page");

?>