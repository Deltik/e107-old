<?php
/*
+ ----------------------------------------------------------------------------+
     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107/e107_plugins/newforumposts_menu/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/09/03 18:32:12 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("NFP_1", "All latest posts are outside of your user class, unable to display.");
define("NFP_2", "No posts yet");
define("NFP_3", "New Forum Posts menu configuration saved");
define("NFP_4", "Caption");
define("NFP_5", "Number of posts to display?");
define("NFP_6", "Number of characters to display?");
define("NFP_7", "Postfix for too long posts?");
define("NFP_8", "Show original topics in menu?");
define("NFP_9", "Update menu Settings");
define("NFP_10", "New Forum Posts Menu Configuration");





?>