<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/


define("FADER_L1", "Fading text inside a menu, uses code from DynamicDrive.com");
define("FADER_L2", "First message");
define("FADER_L3", "Second message");
define("FADER_L4", "Leave textboxes blank if you want to :)");
define("FADER_L5", "To configure please click on the link in the plugins section of the admin front page, then go to the menus screen and activate the menu");

define("FADER_L6", "Caption");
define("FADER_L7", "Message");
define("FADER_L8", "Fade Colour");
define("FADER_L9", "Black to white");
define("FADER_L10", "White to black");
define("FADER_L11", "Default layer height in pixels");
define("FADER_L12", "default");
define("FADER_L13", "Fade delay in milliseconds");
define("FADER_L14", "Fader Menu Configuration");
define("FADER_L15", "Update Menu Settings");
define("FADER_L16", "Fader menu configuration saved.");
define("FADER_L17", "Configure Fader");


?>