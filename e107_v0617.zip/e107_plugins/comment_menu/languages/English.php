<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CM_L1", "No comments yet.");
define("CM_L2", "");
define("CM_L3", "Caption");
define("CM_L4", "Number of comments to display?");
define("CM_L5", "Number of characters to display?");
define("CM_L6", "Postfix for too long comments?");
define("CM_L7", "Show original news title in menu?");
define("CM_L8", "New Comments Menu Configuration");
define("CM_L9", "Update Menu Settings");
define("CM_L10", "Comments menu configuration saved");


?>