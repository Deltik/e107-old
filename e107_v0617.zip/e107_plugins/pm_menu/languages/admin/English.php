<?php

define(PMLAN_PM,"Private Message");
define(PM_ADLAN_PM,"Private Messaging");
define(PM_ADLAN_1,"PM Config Options");
define(PM_ADLAN_2,"PM Admin Functions");
define(PM_ADLAN_3,"Update PM Settings");
define(PM_ADLAN_4,"Select User");
define(PM_ADLAN_5,"ALL Messages Deleted");
define(PM_ADLAN_6,"Messages to/from");
define(PM_ADLAN_7,"deleted");
define(PM_ADLAN_8,"Messages older than ");
define(PM_ADLAN_9,"days old");
define(PM_ADLAN_10,"This will delete ALL messages more than ");
define(PM_ADLAN_11,"Confirm Delete");
define(PM_ADLAN_12,"Cancel");
define(PM_ADLAN_13,"You must enter a value.");
define(PM_ADLAN_14,"Delete messages");
define(PM_ADLAN_15,"This will delete ALL messages either to or from the user: ");
define(PM_ADLAN_16,"You must select a user first.");
define(PM_ADLAN_17,"Delete messages from / to user");
define(PM_ADLAN_18,"This will delete ALL messages from the PM system, whether they are read or not.");
define(PM_ADLAN_19,"Delete ALL messages");
define(PM_ADLAN_20,"PM settings updated");
define(PM_ADLAN_21,"Plugin title");
define(PM_ADLAN_22,"Show New PM Animation");
define(PM_ADLAN_23,"Show user dropdown list");
define(PM_ADLAN_24,"Auto delete read messages");
define(PM_ADLAN_25,"READ message timeout");
define(PM_ADLAN_26,"UNREAD message timeout");
define(PM_ADLAN_27,"Popup notification on new PM");
define(PM_ADLAN_28,"Popup delay time");
define(PM_ADLAN_29,"Restrict PM to");
define(PM_ADLAN_30,"All registered users");
define(PM_ADLAN_31,"Userclass");
define(PM_ADLAN_32,"Delete messages more than");
define(PM_ADLAN_33,"Yes");
define(PM_ADLAN_34,"No");
define(PM_ADLAN_35,"Send email notifications");
define(PM_ADLAN_36,"Please check tick to confirm operation");
define(PM_ADLAN_37,"messages in system");
define(PM_ADLAN_38,"Find username");
define(PM_ADLAN_39,"days");
define(PM_ADLAN_40,"disable");
define(PM_ADLAN_41,"seconds");
define(PM_ADLAN_42,"This plugin is a fully featured Private Messaging system.");
define(PM_ADLAN_43,"Configure Private Messenger");
define(PM_ADLAN_44,"To activate please go to your menus screen and select the pm_menu into one of your menu areas.");
define(PM_ADLAN_45,"PM has been successfully upgraded to version");


?>