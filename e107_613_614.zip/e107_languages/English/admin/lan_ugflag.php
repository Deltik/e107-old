<?php

define("UGFLAN_1", "maintenance setting updated");
define("UGFLAN_2", "Activate maintenance flag");
define("UGFLAN_3", "Update Maintenance Setting");
define("UGFLAN_4", "Maintenance Setting");

define("UGFLAN_5", "Text to display when site down");
define("UGFLAN_6", "Leave blank to display default message");

?>