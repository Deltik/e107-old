<?php

define("FRTLAN_1", "Front Page settings updated.");
define("FRTLAN_2", "Display");
define("FRTLAN_3", "News (default)");
define("FRTLAN_4", "Forum");
define("FRTLAN_5", "Downloads");
define("FRTLAN_6", "Links");
define("FRTLAN_7", "Content Page");
define("FRTLAN_8", "Other");
define("FRTLAN_9", "Type");
define("FRTLAN_10", "Always front page");
define("FRTLAN_11", "Splashscreen only");
define("FRTLAN_12", "Update Front Page Settings");
define("FRTLAN_13", "Front Page Settings");

define("FRTLAN_14", "(type full URL or integer for article)");


?>