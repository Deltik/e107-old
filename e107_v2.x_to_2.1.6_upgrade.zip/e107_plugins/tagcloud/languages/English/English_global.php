<?php
/*
* Copyright (c) e107 Inc 2008-2013 - e107.org, 
* Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
*
* 'FAQ plugin' global language definitions
*/

define("LAN_PLUGIN_TAGCLOUD_NAME", 			"Tag Cloud");
define("LAN_PLUGIN_TAGCLOUD_DESCRIPTION", 	"A simple tagcloud menu for your e107 website.");



