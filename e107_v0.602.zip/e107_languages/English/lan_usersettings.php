<?php

define("PAGE_NAME", "User Settings");

define("LAN_7", "Login Name: ");
define("LAN_20", "Error");
define("LAN_105", "The two passwords do not match");
define("LAN_106", "That doesn't appear to be a valid email address");
define("LAN_112", "Email Address: ");
define("LAN_113", "Hide email address?: ");
define("LAN_114", "This will prevent your email address from being displayed on site");
define("LAN_115", "ICQ Number: ");
define("LAN_116", "AIM Address: ");
define("LAN_117", "MSN Messenger: ");
define("LAN_118", "Birthday: ");
define("LAN_119", "Location: ");
define("LAN_120", "Signature: ");
define("LAN_121", "Avatar: ");
define("LAN_122", "Timezone:");
define("LAN_144", "Website URL: ");
define("LAN_150", "Settings updated and saved into database.");
define("LAN_151", "OK");
define("LAN_152", "New Password: ");
define("LAN_153", "Re-type New Password: ");
define("LAN_154", "Update Settings");
define("LAN_155", "Update User Settings");
define("LAN_185", "You left the password field blank ");
define("LAN_308", "Real Name: ");
define("LAN_401", "Leave blank to keep existing password");
define("LAN_402", "Type path or choose avatar");
define("LAN_403", "Choose avatar");
define("LAN_404", "Please note: Any image uploaded to this server which is deemed inappropriate by the administrators will be deleted immediately.");
?>