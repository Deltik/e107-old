<?php

define("PAGE_NAME", "Submit News");

define("LAN_7", "Login Name: ");
define("LAN_62", "Subject: ");
define("LAN_112", "Email Address: ");
define("LAN_133", "Thankyou");
define("LAN_134", "Your item has been submitted and will be reviewed by one of the site administrators in due course.");
define("LAN_135", "News Item: ");
define("LAN_136", "Submit News Item");

?>