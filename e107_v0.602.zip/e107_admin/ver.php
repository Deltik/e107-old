<?php

$e107info['e107_version'] = "v0.602";
$e107info['e107_build'] = "07/10/2003";

?>