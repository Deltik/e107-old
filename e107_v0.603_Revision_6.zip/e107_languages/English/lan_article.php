<?php

define("PAGE_NAME", "Article"); 

define("LAN_5", "Comments ...");
define("LAN_25", "Previous page");
define("LAN_26", "Next page");
define("LAN_99", "Comments");
define("LAN_100", "Articles");
define("LAN_190", "Reviews");
define("LAN_313", "Please choose which list you wish to display ...");
define("LAN_398", "No summary.");
define("LAN_399", "Rating");

define("LAN_400", "Inactive page");
define("LAN_401", "This page is inactive and cannot be shown.");

define("LAN_2", "You do not have the correct permissions to view this article.");


?>