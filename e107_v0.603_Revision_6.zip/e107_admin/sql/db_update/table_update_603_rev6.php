<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/table update #1
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if(ADMINPERMS == "0"){
	mysql_query("ALTER TABLE ".MPREFIX."headlines CHANGE headline_description headline_description TEXT NOT NULL");
	mysql_query("ALTER TABLE ".MPREFIX."headlines DROP headline_webmaster");
	mysql_query("ALTER TABLE ".MPREFIX."headlines DROP headline_copyright");
	mysql_query("ALTER TABLE ".MPREFIX."headlines DROP headline_tagline");
	mysql_query("ALTER TABLE ".MPREFIX."headlines DROP headline_image");
	$text = "<div style='text-align:center'>Alterations made successfully to the '".MPREFIX."headlines' table, please now delete the following file from your server ...<br /><br /><b>".ADMINDIR."sql/db_updates/table_update_603_rev6.php</b><br />";
	$ns -> tablerender("Upgrade completed", $text);
}

?>