<?php

$e107info['e107_version'] = "v0.603";
$e107info['e107_build'] = "Revision #6";

?>