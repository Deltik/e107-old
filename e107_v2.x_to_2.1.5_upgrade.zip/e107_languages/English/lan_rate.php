<?php
/*
+ ----------------------------------------------------------------------------+
| 
|     e107 website system
|     Copyright (C) 2008-2016 e107 Inc (e107.org)
|     Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
|
+ ----------------------------------------------------------------------------+
*/

define("RATELAN_0", "Vote");
define("RATELAN_1", "Votes");
define("RATELAN_2", "How do you rate this item?");
define("RATELAN_3", "Thanks for voting!");
define("RATELAN_4", "Not rated");
define("RATELAN_5", "Rate this:");
define("RATELAN_6", "Please login to rate this.");
define("RATELAN_7", "Like");
define("RATELAN_8", "Dislike");
define("RATELAN_9", "You already voted");
define("RATELAN_10", "There is no item ID in the rating");
define("RATELAN_11", "Rating Failed ");

define("RATELAN_POOR","Poor");
define("RATELAN_FAIR","Fair");
define("RATELAN_GOOD","Good");
define("RATELAN_VERYGOOD","Very Good");
define("RATELAN_EXCELLENT","Excellent");


?>
