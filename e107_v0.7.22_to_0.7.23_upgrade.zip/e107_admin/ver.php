<?php
/*
* Copyright (c) 2010 e107 Inc e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_admin/ver.php $
* $Id: ver.php 11672 2010-08-20 20:08:54Z e107coders $
*
* Version file
*/

if (!defined('e107_INIT')) { exit; }

$e107info['e107_version'] = "0.7.23";
?>
