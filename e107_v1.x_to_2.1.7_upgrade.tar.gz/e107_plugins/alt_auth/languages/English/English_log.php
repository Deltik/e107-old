<?php

/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)

 */

/**
 *	e107 Alternate authorisation plugin
 *
 *	@package	e107_plugins
 *	@subpackage	alt_auth
 */

define("LAN_AL_AUTH_01","Alt auth Settings changed");
define("LAN_AL_AUTH_02","Alt auth extended user classes changed");
define("LAN_AL_AUTH_03","Alt auth method settings changed");


?>
