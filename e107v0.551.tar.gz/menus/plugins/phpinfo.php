<?php
$text .= wad("phpinfo.php", "PHPInfo", "PHPInfo page", "0");
?>