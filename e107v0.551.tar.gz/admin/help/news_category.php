<?php
$text = "You can seperate your news items into different categories, and allow visitors to display only the news items in those categories. <br /><br />Upload your news icon images either themes/-yourtheme-/images/ or themes/shared/newsicons/.";
$ns -> tablerender("News Category Help", $text);
?>