<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Error - please re-submit");
define("UDALAN_2", "Settings updated");
define("UDALAN_3", "Settings Updated for");
define("UDALAN_4", "Name");
define("UDALAN_5", "Password");
define("UDALAN_6", "Re-type Password");
define("UDALAN_7", "Change Password");
define("UDALAN_8", "Password Update for");

?>