<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Received messages");
define("MESSLAN_2", "Delete Message");
define("MESSLAN_3", "Message Deleted.");
define("MESSLAN_4", "Delete All Messages");
define("MESSLAN_5", "Confirm");
define("MESSLAN_6", "All messages deleted.");
define("MESSLAN_7", "No messages.");
define("MESSLAN_8", "Message type");
define("MESSLAN_9", "Reported on");

define("MESSLAN_10", "Submitted by");
define("MESSLAN_11", "opens in new window");
define("MESSLAN_12", "Message");
define("MESSLAN_13", "Link");


?>