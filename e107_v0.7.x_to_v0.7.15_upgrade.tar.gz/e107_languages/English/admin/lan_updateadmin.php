<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Error - please re-submit");
define("UDALAN_2", "Settings updated");
define("UDALAN_3", "Settings updated for");
define("UDALAN_4", "Name");
define("UDALAN_5", "Password");
define("UDALAN_6", "Re-type password");
define("UDALAN_7", "Change password");
define("UDALAN_8", "Password updated for");

?>