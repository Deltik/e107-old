<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_parser_functions.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/25 16:39:41 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Guest");
define("LAN_WROTE", "wrote"); // as in John wrote.."  ";


?>
