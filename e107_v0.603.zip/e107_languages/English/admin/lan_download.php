<?php

define("DOWLAN_1", "Download added to database.");
define("DOWLAN_2", "Download updated in database.");
define("DOWLAN_3", "Download deleted.");
define("DOWLAN_4", "Please tick the confirm box to delete the download");
define("DOWLAN_5", "There are no download categories defined yet, until you define some you cannot enter any downloads.<br />Please <a href='download_category.php'>click here</a> to go to the download categories page.");
define("DOWLAN_6", "No downloads yet.");
define("DOWLAN_7", "Existing Downloads");
define("DOWLAN_8", "Edit");
define("DOWLAN_9", "Delete");
define("DOWLAN_10", "tick to confirm");
define("DOWLAN_11", "Category");
define("DOWLAN_12", "Name");
define("DOWLAN_13", "File");
define("DOWLAN_14", "enter url if external file");

define("DOWLAN_15", "Author");
define("DOWLAN_16", "Author Email");
define("DOWLAN_17", "Author Website");

define("DOWLAN_18", "Description");
define("DOWLAN_19", "Main image");
define("DOWLAN_20", "Thumbnail image");
define("DOWLAN_21", "Active?");
define("DOWLAN_22", "Yes");
define("DOWLAN_23", "No");
define("DOWLAN_24", "Update Download");
define("DOWLAN_25", "Submit Download");
define("DOWLAN_26", "Downloads");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");
define("DOWLAN_15", "Author");


?>