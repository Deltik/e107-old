<?php
$text .= wad("frontpage.php", "Front Page", "Configure front page content", "P");
?>