<?php
$text .= wad("cache.php", "Cache", "Configure cache system", "P");
?>