<?php
$ns -> tablerender(LAN_181,  "<div style=\"text-align:center\">\n<a href=\"".SITEURL."\"><img style=\"border:0\" src=\"".SITEBUTTON."\" alt=\"Link to us\" /></a>\n</div>");
?>