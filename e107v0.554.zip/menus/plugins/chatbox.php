<?php
$text .= wad("chatbox_conf.php", "Chatbox", "Configure chatbox", "P");
?>