<?php
$text .= wad("upload.php", "User Uploads", "Moderate uploads", "P");
?>