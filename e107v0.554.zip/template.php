<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/template.php
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
require_once("class2.php");
require_once(HEADERF);


/*

Your PHP content goes here ...

If you wish to use HTML ...

<?

Your HTML goes here ...

<?php

*/



require_once(FOOTERF);
?>