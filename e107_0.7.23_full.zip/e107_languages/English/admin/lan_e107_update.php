<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_e107_update.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Action");
define("LAN_UPDATE_3", "Not Needed");

define("LAN_UPDATE_5", "Update available");
define("LAN_UPDATE_7", "Executed");
define("LAN_UPDATE_8", "Update from");
define("LAN_UPDATE_9", "to");
define("LAN_UPDATE_10", "Available Updates");
define("LAN_UPDATE_11", ".617 to .7 Update Continued");
define("LAN_UPDATE_12", "One of your tables contains duplicate entries.");


?>