<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags updated in database");
define("METLAN_2", "Enter additional meta-tags");
define("METLAN_3", "Enter new meta tag settings");
define("METLAN_4", "Updated");
define("METLAN_5", "type your description here");
define("METLAN_6", "type, a, list, of, your, keywords, here");
define("METLAN_7", "type your copyright info here");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "Description");
define("METLAN_10", "Keywords");
define("METLAN_11", "Copyright");
define("METLAN_12", "Use News title and summary as the meta-description on news pages.");
define("METLAN_13", "Author");

?>