<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_user_select.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Select user");
define("US_LAN_2", "Select user class");
define("US_LAN_3", "All users");
define("US_LAN_4", "Find username");
define("US_LAN_5", "User(s) found");
define("US_LAN_6", "Search");
?>