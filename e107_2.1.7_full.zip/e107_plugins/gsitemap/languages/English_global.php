<?php

define("LAN_PLUGIN_GSITEMAP_NAME", "Google Sitemap");
define("LAN_PLUGIN_GSITEMAP_DESCRIPTION", "Generates a Google Sitemap");

?>