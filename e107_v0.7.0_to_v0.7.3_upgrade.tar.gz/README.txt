0.7.x -> 0.7.3 Upgrade Guide

This update to 0.7.0 / 0.7.1 / 0.7.2 is a cumulative patch including all upgrade files from 0.7.1 / 0.7.2 / 0.7.3.
Included in these releases are security related file changes and so you must upgrade your site with all these files.

To install simply upload the files to your server overwriting the existing 0.7.x files.
There are no database changes in this release so no update button will show.

