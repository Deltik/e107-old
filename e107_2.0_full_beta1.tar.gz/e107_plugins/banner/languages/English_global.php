<?php

define("LAN_PLUGIN_BANNER_NAME",		"Banners");
define("LAN_PLUGIN_BANNER_DESCRIPTION", "Add advertising banners to your e107 website");

?>