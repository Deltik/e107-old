<?php

$text = "Set your chatbox preferences from here.<br />If the replace link box is ticked, any links entered will be replaced by the text you enter in the textbox, this stops long links causing display problems. Wordwrap will auto wrap text that is longer than the length specified here.";

$ns -> tablerender("Chatbox", $text);
?>