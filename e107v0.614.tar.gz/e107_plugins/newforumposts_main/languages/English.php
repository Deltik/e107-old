<?php

define("LAN_1", "Thread");
define("LAN_2", "Poster");
define("LAN_3", "Views");
define("LAN_4", "Replies");
define("LAN_5", "Lastpost");
define("LAN_6", "Threads");

?>