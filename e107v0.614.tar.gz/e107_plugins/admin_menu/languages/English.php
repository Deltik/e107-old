<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ADMIN_MENU_L1", "Select ...");
define("ADMIN_MENU_L2", "Admin");

?>