<?php

define("LAN_183", "Main Menu");
define("LAN_502", "Admin Area");

?>