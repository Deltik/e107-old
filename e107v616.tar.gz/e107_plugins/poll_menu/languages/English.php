<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("POLL_1", "Votes: ");
define("POLL_2", "Comments");
define("POLL_3", "Old Surveys");
define("POLL_4", "Submit Vote");
define("POLL_5", "Poll");


define("POLL_6", "No votes");
define("POLL_7", "1 vote");
define("POLL_8", " votes");
define("POLL_9", "moderator");
define("POLL_10", "delete poll only");

define("POLL_11", "Poll updated in database.");
define("POLL_12", "Posted by: ");

define("POLL_163", "Submit Vote");
define("POLL_164", "Votes: ");
define("POLL_165", "Old Surveys");
define("POLL_184", "Poll");

define("POLL_500", "Comments");

?>