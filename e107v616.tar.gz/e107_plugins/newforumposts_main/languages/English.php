<?php

define("LAN_1", "Thread");
define("LAN_2", "Poster");
define("LAN_3", "Views");
define("LAN_4", "Replies");
define("LAN_5", "Lastpost");
define("LAN_6", "Threads");

define("NFPM_L1", "This plugin displays a list of new forum posts on your front page");
define("NFPM_L2", "Latest Forum Posts"); 
define("NFPM_L3", "To configure please click on the link in the plugins section of the admin front page");
define("NFPM_L4", "Activate in which area?");
define("NFPM_L5", "Inactive");
define("NFPM_L6", "Top of page");
define("NFPM_L7", "Bottom of page");
define("NFPM_L8", "Caption");
define("NFPM_L9", "Number of new posts to display?");
define("NFPM_L10", "Display inside scrolling layer?");
define("NFPM_L11", "Layer height");
define("NFPM_L12", "New Forum Posts Configuration");
define("NFPM_L13", "Update New Forum Posts Settings");
define("NFPM_L14", "New Forum Posts settings updated.");
define("NFPM_L15", "Check to display latest forum posts.<br />Default is latest topics.");


?>