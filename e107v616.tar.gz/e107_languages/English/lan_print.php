<?php

define("PAGE_NAME", "Printer Friendly");

define("LAN_86", "Category:");
define("LAN_87", "by ");
define("LAN_94", "Posted by");
define("LAN_135", "News Item: ");
define("LAN_303", "This news item is from ");
define("LAN_304", "Article Title: ");
define("LAN_305", "Subheading: ");
define("LAN_306", "This article is from ");
define("LAN_307", "Print this page");

?>