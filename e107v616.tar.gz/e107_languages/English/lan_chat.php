<?php

define("PAGE_NAME", "Chatbox"); 

define("LAN_11", "Chatbox (all posts)");
define("LAN_12", "Chat Posts");
define("LAN_13", "on");

define("LAN_14", "Error!");
define("LAN_15", "You do not have the correct permissions to view this page.");

define("LAN_16", "[ this post has been blocked by admin ]");

?>