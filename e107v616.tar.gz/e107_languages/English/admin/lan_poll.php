<?php

define("POLLAN_1", "Delete cancelled.");
define("POLLAN_2", "No polls set yet");
define("POLLAN_3", "Existing Polls");
define("POLLAN_4", "Edit");
define("POLLAN_5", "Delete");
define("POLLAN_6", "tick to confirm");
define("POLLAN_7", "Poll Question");
define("POLLAN_8", "Option");
define("POLLAN_9", "Add another option");
define("POLLAN_10", "Poll status");
define("POLLAN_11", "Inactive");
define("POLLAN_12", "Active - allow votes from all");
define("POLLAN_13", "Active - allow votes from members only");
define("POLLAN_14", "Preview again");
define("POLLAN_15", "Update poll in database");
define("POLLAN_16", "Post poll to database");
define("POLLAN_17", "Preview");
define("POLLAN_18", "Clear Form");
define("POLLAN_19", "Polls");

define("POLLAN_20", "Options");
define("POLLAN_21", "Are you sure you want to delete this poll?");

define("POLLAN_22", "No polls");
define("POLLAN_23", "Poll Preview");

?>