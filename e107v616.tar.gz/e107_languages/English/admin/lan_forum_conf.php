<?php

define("FORLAN_1", "Thread closed.");
define("FORLAN_2", "Thread reopened.");
define("FORLAN_3", "Thread made sticky.");
define("FORLAN_4", "Thread unstuck.");
define("FORLAN_5", "Poll deleted.");
define("FORLAN_6", "Thread deleted");
define("FORLAN_7", "replies deleted");
define("FORLAN_8", "Delete cancelled.");
define("FORLAN_9", "Thread moved.");
define("FORLAN_10", "Move cancelled.");
define("FORLAN_11", "Back To Forums");
define("FORLAN_12", "Forum Configuration");
define("FORLAN_13", "Are you absolutely certain you want to delete this poll?<br />Once deleted it <b><u>cannot</u></b> be retreived.");
define("FORLAN_14", "Cancel");
define("FORLAN_15", "Confirm Delete Forum Post");
define("FORLAN_16", "Confirm Delete Poll");
define("FORLAN_17", "posted by");
define("FORLAN_18", "Are you absolutely certain you want to delete this forum");
define("FORLAN_19", "thread and it's related posts?");
define("FORLAN_20", "the poll will also be deleted");
define("FORLAN_21", "Once deleted they");
define("FORLAN_22", "post?<br />Once deleted it");
define("FORLAN_23", "cannot</u></b> be retreived");
define("FORLAN_24", "Move thread  to forum");
define("FORLAN_25", "Move Thread");
define("FORLAN_26", "Reply deleted");

?>