<?php

define("MDCLAN_1", "Moderated.");
define("MDCLAN_2", "No comments for this item");
define("MDCLAN_3", "Member");
define("MDCLAN_4", "Guest");
define("MDCLAN_5", "unblock");
define("MDCLAN_6", "block");
define("MDCLAN_7", "delete");
define("MDCLAN_8", "Moderate Comments");
define("MDCLAN_9", "Warning! Deleting Parent comments will also delete all replies!");

?>