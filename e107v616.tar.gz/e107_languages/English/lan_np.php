<?php

define("NP_1", "Previous page");
define("NP_2", "Next page");
define("NP_3", "Go to page");

?>