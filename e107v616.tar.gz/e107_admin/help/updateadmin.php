<?php
$text = "Update your password here.";
$ns -> tablerender("Update Settings Help", $text);
?>