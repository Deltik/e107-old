<?php
$caption = "Front Page Help";
$text = "From this screen you can choose what to display on the front page of your site, the default is news. You can also use this page to set up a 'splashscreen', a page that will only display when a visitor first enters your site.";
$ns -> tablerender($caption, $text);
?>