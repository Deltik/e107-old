<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/09/06 19:34:04 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags updated in database");
define("METLAN_2", "Enter additional meta-tags");
define("METLAN_3", "Enter new meta tag settings");
define("METLAN_4", "Updated");
define("METLAN_5", "type your description here");
define("METLAN_6", "type, a, list, of, your, keywords, here");
define("METLAN_7", "type your copyright info here");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "Description");
define("METLAN_10", "Keywords");
define("METLAN_11", "Copyright");

?>