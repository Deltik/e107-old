<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_cache.php $
|     $Revision: 11678 $
|     $Id: lan_cache.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Cache System Status");
define("CACLAN_2", "Set cache status");
define("CACLAN_3", "Cache System");
define("CACLAN_4", "Cache status set");
define("CACLAN_5", "Empty Cache");
define("CACLAN_6", "Cache Emptied");

define("CACLAN_7", "Cache Disabled");
// define("CACLAN_8", "Cache data saved to MySQL");
define("CACLAN_9", "Cache data saved to disk file");
define("CACLAN_10", "The cache directory is not writable. Please ensure this directory is set CHMOD 0777");
?>