<?php
$text = "Enter all your site links here. For main site links (the ones displayed in your main navigation bar) set the category to 'Main', any others will be displayed on the Links page. You can seperate these links into different categories.";
$ns -> tablerender("Links Help", $text);
?>