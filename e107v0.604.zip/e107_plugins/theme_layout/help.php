<?php
$caption = "<b>Note</b>";
$text = "There is a bug in Internet Explorer that could cause it to crash when using this script, there is no way around this so please make sure you save your text at regular intervals.";
$ns -> tablerender($caption, $text);
?>