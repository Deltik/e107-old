<?php
$ns -> tablerender(SITEBUTTON_MENU_L1,  "<div style='text-align:center'>\n<a href='".SITEURL."'><img style='border:0' src='".e_IMAGE.SITEBUTTON."' alt='Link to us' /></a>\n</div>");
?>