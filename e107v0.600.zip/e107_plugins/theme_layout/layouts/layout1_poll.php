<?php

$pollstyle = "
<b>Poll: {QUESTION}</b>
<br /><br />
{OPTIONS=<div class='alttd'>OPTION</div>BAR<br /><span class='smalltext'>PERCENTAGE VOTES</span><br />\n}
<div style='text-align:center' class='smalltext'>{VOTE_TOTAL} {COMMENTS}
<br />
{OLDPOLLS}
</div>
";

?>