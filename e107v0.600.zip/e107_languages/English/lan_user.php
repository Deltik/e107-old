<?php

define("PAGE_NAME", "Members");

define("LAN_20", "Error");
define("LAN_112", "Email Address: ");
define("LAN_115", "ICQ Number: ");
define("LAN_116", "AIM Address: ");
define("LAN_117", "MSN Messenger: ");
define("LAN_118", "Birthday: ");
define("LAN_119", "Location: ");
define("LAN_120", "Signature: ");
define("LAN_137", "There is no information for that user as they are not registered at");
define("LAN_138", "Registered members: ");
define("LAN_139", "Order: ");
define("LAN_140", "Registered members");
define("LAN_141", "No registered members yet.");
define("LAN_142", "Member");
define("LAN_143", "[hidden by request]");
define("LAN_144", "Website URL: ");
define("LAN_145", "Registered: ");
define("LAN_146", "Visits to site since registration: ");
define("LAN_147", "Chatbox posts: ");
define("LAN_148", "Comments posted: ");
define("LAN_149", "Forum posts: ");
define("LAN_308", "Real Name: ");

define("LAN_400", "That is not a valid user.");

?>