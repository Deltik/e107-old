<?php

define("CNTLAN_1", "Fields left blank.");
define("CNTLAN_2", "Content updated in database.");
define("CNTLAN_3", "Please tick the confirm box to delete this content page");
define("CNTLAN_4", "No content pages yet.");
define("CNTLAN_5", "Existing Content Pages");
define("CNTLAN_6", "Edit");
define("CNTLAN_7", "Delete");
define("CNTLAN_8", "tick to confirm");
define("CNTLAN_9", "Open HTML Editor");
define("CNTLAN_10", "Link name");
define("CNTLAN_11", "Page Heading");
define("CNTLAN_12", "Content");
define("CNTLAN_13", "Allow comments");
define("CNTLAN_14", "On");
define("CNTLAN_15", "Off");
define("CNTLAN_16", "Update Content Page");
define("CNTLAN_17", "Submit Content Page");
define("CNTLAN_18", "Content Pages");
define("CNTLAN_19", "Visible to");
define("CNTLAN_20", "Content page deleted.");
define("CNTLAN_21", "Auto line breaks");
define("CNTLAN_22", "( if you're posting HTML code you should set this to off )");

?>