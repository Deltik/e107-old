<?php

define("DOWLAN_1", "Field(s) left blank.");
define("DOWLAN_2", "Download parent created in database.");
define("DOWLAN_3", "Download category created in database.");
define("DOWLAN_4", "Download parent updated in database.");
define("DOWLAN_5", "Download category updated in database.");
define("DOWLAN_6", "Download Parent deleted.");
define("DOWLAN_7", "Please tick the confirm box to delete the parent");
define("DOWLAN_8", "Download Category deleted.");
define("DOWLAN_9", "Please tick the confirm box to delete the category");
define("DOWLAN_10", "Parents");
define("DOWLAN_11", "Existing Parents");
define("DOWLAN_12", "Edit");
define("DOWLAN_13", "Delete");
define("DOWLAN_14", "tick to confirm");
define("DOWLAN_15", "Name");
define("DOWLAN_16", "Icon");
define("DOWLAN_17", "Description");
define("DOWLAN_18", "Update Parent");
define("DOWLAN_19", "Create New Download Parent");
define("DOWLAN_20", "Categories");
define("DOWLAN_21", "Existing Categories?");
define("DOWLAN_22", "You will need to create a download parent before creating categories.");
define("DOWLAN_23", "Download Categories");
define("DOWLAN_24", "Parent");
define("DOWLAN_25", "Visible to");
define("DOWLAN_26", "Update Category");
define("DOWLAN_27", "Create New Download Category");
define("DOWLAN_28", "Download Categories");

?>