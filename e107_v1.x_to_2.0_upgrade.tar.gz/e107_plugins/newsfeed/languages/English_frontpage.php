<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * Plugin - newsfeeds
 *
 * $Source: /cvs_backup/e107_0.8/e107_plugins/newsfeed/languages/English_frontpage.php,v $
 * $Revision$
 * $Date$
 * $Author$
 *
*/

define("NWSF_FP_1", "News Feeds");
define("NWSF_FP_2", "main page");

?>