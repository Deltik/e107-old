<?php

define("LAN_PLUGIN_PM_NAME", "Private Messenger");
define("LAN_PLUGIN_PM_DESCRIPTION", "This plugin is a fully featured Private Messaging system.");
define("LAN_PLUGIN_PM_URL_DEFAULT_LABEL", "Default");
define("LAN_PLUGIN_PM_URL_DEFAULT_DESCR", "Default");
?>