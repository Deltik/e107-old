<?php
$text = "";
require_once(e_BASE."plugins/chatbox.php");
?>