<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/banner.php
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
require_once("class2.php");

$qs = explode(".", e_QUERY);
$action = $qs[0]; $id = $qs[1];

if($action == "clientlogin"){
	require_once(HEADERF);
	echo "<div style=\"align:center\">";
	$text =  "<form method=\"post\" action=\"".e_SELF."\">\n
<table style=\"width:40%\" align=\"center\">
<tr>
<td style=\"width:15%\" class=\"defaulttext\">".LAN_16."</td>
<td><input class=\"tbox\" type=\"text\" name=\"clientlogin\" size=\"30\" value=\"$id\" maxlength=\"20\" />\n</td>
</tr>
<tr>
<td style=\"width:15%\" class=\"defaulttext\">".LAN_17."</td>
<td><input class=\"tbox\" type=\"password\" name=\"clientpassword\" size=\"30\" value=\"\" maxlength=\"20\" />\n</td>
</tr>
<tr>
<td style=\"width:15%\"></td>
<td>
<input class=\"button\" type=\"submit\" name=\"clientsubmit\" value=\"Continue\" />
</td>
</tr>
</table>";
$ns -> tablerender("Please enter your client login and password to continue", $text);
require_once(FOOTERF);
exit;
}

if(IsSet($_POST['clientsubmit'])){
	require_once(HEADERF);
	if(!$banner_total = $sql -> db_Select("banner", "*", "banner_clientlogin='".$_POST['clientlogin']."' AND banner_clientpassword='".$_POST['clientpassword']."' ")){
		$ns -> tablerender("Error", "<br /><div style=\"text-align:center\">Sorry, unable to find those details in the database. Please contact the site administrator for details.</div><br />");
		require_once(FOOTERF);
		exit;
	}

	$text = "<table class=\"fborder\" style=\"width:98%\">
	<tr><td colspan=\"7\" style=\"text-align:center\" class=\"fcaption\">Banners Statistics</td></tr>
	<tr>
	<td class=\"forumheader\" style=\"text-align:center\"><span class=\"smallblacktext\">Client</span></td>
	<td class=\"forumheader\" style=\"text-align:center\"><span class=\"smallblacktext\">Banner ID</span></td>
	<td class=\"forumheader\" style=\"text-align:center\"><span class=\"smallblacktext\">Clickthroughs</span></td>
	<td class=\"forumheader\" style=\"text-align:center\"><span class=\"smallblacktext\">Click %</span></td>
	<td class=\"forumheader\" style=\"text-align:center\"><span class=\"smallblacktext\">Impressions</span></td>
	<td class=\"forumheader\" style=\"text-align:center\"><span class=\"smallblacktext\">Impressions Purchased</span></td>
	<td class=\"forumheader\" style=\"text-align:center\"><span class=\"smallblacktext\">Impressions Left</span></td>
	</tr>";

	if(!$banner_total){
		$text .= "<tr>
		<td colspan=\"7\" class=\"forumheader2\" style=\"text-align:center\">No banners</td>";
	}else{
		while($row = $sql-> db_Fetch()){
			extract($row);

			$clickpercentage = ($banner_clicks && $banner_impressions ? round(($banner_clicks / $banner_impressions) * 100)."%" : "-");
			$impressions_left = ($banner_impurchased ? $banner_impurchased - $banner_impressions : "Unlimited");
			$impressions_purchased = ($banner_impurchased ? $banner_impurchased : "Unlimited");

			$start_date = ($banner_startdate ? strftime("%d %B %Y", $banner_startdate) : "Not applicable");
			$end_date = ($banner_enddate ? strftime("%d %B %Y", $banner_enddate) : "Not applicable");

			$text.="<tr>
			<td class=\"forumheader3\" style=\"text-align:center\">".$banner_clientname."</td>
			<td class=\"forumheader3\" style=\"text-align:center\">".$banner_id."</td>
			<td class=\"forumheader3\" style=\"text-align:center\">".$banner_clicks."</td>
			<td class=\"forumheader3\" style=\"text-align:center\">".$clickpercentage."</td>
			<td class=\"forumheader3\" style=\"text-align:center\">".$banner_impressions."</td>
			<td class=\"forumheader3\" style=\"text-align:center\">".$impressions_purchased."</td>
			<td class=\"forumheader3\" style=\"text-align:center\">".$impressions_left."</td>
			</tr>
			<td colspan=\"7\" class=\"forumheader3\" style=\"text-align:center\">

			Active: ". ($banner_active ? "Yes" : "<b>No</b>")." | 

			Starts: ".$start_date.", Ends: ".$end_date."</td></tr>";
			
			if($banner_ip){
				$tmp = explode("^", $banner_ip);
				$text .= "<tr><td class=\"forumheader3\">
				Clickthrough IP addresses: ".(count($tmp)-1)."</td>
				<td colspan=\"6\" class=\"forumheader3\">";
				for($a=0; $a<=(count($tmp)-2); $a++){
					$text .= $tmp[$a]."<br />";
				}
			}
			
			
			$text .= "</td>
			<tr><td colspan=\"8\">&nbsp;</td></tr>";
		}
	}

	$text .= "</table>";

	echo $text;

	require_once(FOOTERF);
	exit;
}


if(!e_QUERY){ header("location: ".e_BASE."index.php"); }



$sql -> db_Select("banner", "*", "banner_id='".e_QUERY."' ");
$row = $sql -> db_Fetch(); extract($row);

$ip = getip();

$newip = (preg_match("/".$ip."\^/", $banner_ip) ? $banner_ip : $banner_ip.$ip."^");

$sql -> db_Update("banner", "banner_clicks=banner_clicks+1, banner_ip='$newip' WHERE banner_id='".e_QUERY."' ");
header("location: ".$banner_clickurl);

?>