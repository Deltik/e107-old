<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/other_news_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/23 14:53:38 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
	
define("TD_MENU_L1", "Other News");
define("TD_MENU_L2", "Other News");
	
?>