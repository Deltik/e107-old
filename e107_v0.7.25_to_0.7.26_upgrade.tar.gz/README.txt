0.7.25 -> 0.7.26 Upgrade Guide
This is an update from 0.7.25 to 0.7.26 only. If you are upgrading from any other version besides 0.7.25 ,
then you have downloaded the wrong package.  For those users that have been using the current SVN version of e107, from any other version besides 0.7.25 this is the correct version to use.

Included in these releases are security related file changes and so you must upgrade your site with all these files.

To install, simply upload the files to your server overwriting the existing 0.7.25 files.
There are no database changes in this release.