<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/table update #1
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if(ADMINPERMS == "0"){
	mysql_query("ALTER TABLE ".MPREFIX."news ADD news_render_type TINYINT UNSIGNED NOT NULL ");
	mysql_query("ALTER TABLE ".MPREFIX."content CHANGE content_parent content_parent INT UNSIGNED DEFAULT '0' NOT NULL ");
	$text = "<div style='text-align:center'>Alterations made successfully to the database, please now delete the following file from your server ...<br /><br /><b>".ADMINDIR."sql/db_updates/table_update_611_to_612.php</b><br />";
	$ns -> tablerender("Upgrade completed", $text);
}





?>