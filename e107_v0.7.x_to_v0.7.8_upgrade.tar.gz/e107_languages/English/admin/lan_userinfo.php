<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userinfo.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Unable to find poster's IP address - no information is available.");
// define("USFLAN_2", "Error");
define("USFLAN_3", "Messages posted from IP address");
define("USFLAN_4", "Host");
define("USFLAN_5", "Click here to transfer IP address to admin ban page");
define("USFLAN_6", "User ID");
define("USFLAN_7", "User Information");

?>