<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/English/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/04 18:24:28 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'en');
define("CORE_LC", 'en');
define("CORE_LC2", 'gb');
define("CHARSET", "iso-8859-1");
define("CORE_LAN1","Error : theme is missing.\\n\\nChange the used themes in your preferences (admin area) or upload files of the current theme on the server.");

//v.616
define("CORE_LAN2"," \\1 wrote:");// "\\1" represents the username.
define("CORE_LAN3","file attachment disabled");
?>