This English iso-8859-1 language pack is for those upgrading 0.6175 to 0.7. You must use this language pack for 
upgrading otherwise certain charaters in your old 0.6175 content will display corrupted. Do not use this language 
pack for new 0.7 installs as new installs use UTF-8 character encoding which is the default language pack included 
in the 0.7 core zip. Currently this English iso-8859-1 pack only contains 1 file - e107_languages/English/English.php,
which overwrites the existing UTF-8 equivalent file in the 0.7 core zip.