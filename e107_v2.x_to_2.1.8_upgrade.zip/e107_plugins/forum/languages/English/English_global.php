<?php

define("LAN_PLUGIN_FORUM_NAME", "Forum");
define("LAN_PLUGIN_FORUM_DESC", "This plugin is a fully featured forum system.");
define("LAN_PLUGIN_FORUM_POSTS", "Forum posts");
define("LAN_PLUGIN_FORUM_ALLFORUMS", "All Forums");
define("LAN_PLUGIN_FORUM_LATESTPOSTS", "Latest Posts");
// Notify
// TODO - LAN cleanup (see e_notify)

//define('FORUM_NT_1', 'Forum Events');
//define('FORUM_NT_2', 'Thread');
//define('FORUM_NT_3', 'Post');
//define('FORUM_NT_4', 'added by');
//define('FORUM_NT_5', 'moved by');
// define('FORUM_NT_6', 'Forum - Thread created');



define("FORUM_LAN_URL_DEFAULT_LABEL", "Default Forum URLs");
define("FORUM_LAN_URL_DEFAULT_DESCR", "URLs of 'GET type' with no single entry point. Examples:<br />http://yoursite.com/e107_plugins/forum/forum.php (forum index)<br />http://yoursite.com/e107_plugins/forum/forum_viewtopic.php?id=2 (thread view)");

define("FORUM_LAN_URL_REWRITE_LABEL", "SEF Forum URLs (UNDER DEVELOPMENT)");
define("FORUM_LAN_URL_REWRITE_DESCR", "Examples:<br />UNDER DEVELOPMENT");

?>