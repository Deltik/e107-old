<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 */

 
define("LAN_FORUM_MENU_001", "Posted by");
define("LAN_FORUM_MENU_002", "No posts yet");
define("LAN_FORUM_MENU_003", "New Forum Posts menu configuration saved");
define("LAN_FORUM_MENU_004", "Caption");
define("LAN_FORUM_MENU_005", "Number of posts to display?");
define("LAN_FORUM_MENU_006", "Number of characters to display?");
define("LAN_FORUM_MENU_007", "Postfix for too long posts?");
define("LAN_FORUM_MENU_008", "Show original topics in menu?");
define("LAN_FORUM_MENU_009", "Update menu Settings");
// define("LAN_FORUM_MENU_010", "New Forum Posts Menu Configuration");

define("LAN_FORUM_MENU_012", "Maximum age of displayed posts");
define("LAN_FORUM_MENU_013", "Use zero on a quiet site; setting a value in days will reduce database time on a busy site");

define("LAN_FORUM_MENU_014", "Scrolling layer height (in pixels)");
define("LAN_FORUM_MENU_015", "Leave blank for no scrolling");
	
?>