/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.3 2006/03/03 05:07:12 e107coders Exp $ 
 */  

tinyMCE.addToLang('flash',{
title : 'Vlo�it / editovat Flash',
desc : 'Vlo�it / editovat Flash',
file : 'Flash soubor (.swf)',
size : 'Velikost',
list : 'Flash soubory',
props : 'Flash nastaven�',
general : 'Obecn�'
});
