// SE lang variables

tinyMCE.addToLang('',{
iespell_desc : 'K&ouml;r r&auml;ttstavningskontroll',
iespell_download : "ieSpell verkar inte vara installerad. Klicka OK f&ouml;r att ladda hem."
});
