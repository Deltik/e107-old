<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2017 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * English language file - for site links 
 *
*/

define("LAN_SITELINKS_183", "Main Menu");
//define("LAN_SITELINKS_502", "Admin Area");//NOT USED

?>
