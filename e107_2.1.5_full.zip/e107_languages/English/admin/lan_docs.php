<?php
/*
 * Copyright (C) 2008-2013 e107 Inc (e107.org), Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
 *
 * Admin Language File
 *
*/

define("LAN_DOCS", "System Docs");
define("LAN_DOCS_SECTIONS", "Sections");
define("LAN_DOCS_GOTOP", "Go to top");
define("LAN_DOCS_ANSWER", "Answer");
define("LAN_DOCS_QUESTION", "Question");
?>