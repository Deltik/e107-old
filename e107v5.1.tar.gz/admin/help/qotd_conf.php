<?php
$text = "Using this plugin you can display a random quote from a quote file. Upload the file to your server and type in the path to the file (ie /files/quote.txt)";

$ns -> tablerender("QOTD", $text);
?>