<?php
$text = "Using this plugin you can display a Trivia Question from a trivia file. Upload the file to your server and type in the path to the file (ie /files/quote.txt)";

$ns -> tablerender("Trivia", $text);
?>