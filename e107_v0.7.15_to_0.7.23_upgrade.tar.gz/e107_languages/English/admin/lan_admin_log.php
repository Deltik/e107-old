<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "Date");
define("LAN_ADMINLOG_2", "Title");
define("LAN_ADMINLOG_3", "Description");
define("LAN_ADMINLOG_4", "User IP");
define("LAN_ADMINLOG_5", "User ID");
define("LAN_ADMINLOG_6", "Informative Icon");
define("LAN_ADMINLOG_7", "Informative Message");
define("LAN_ADMINLOG_8", "Notice Icon");
define("LAN_ADMINLOG_9", "Notice Message");
define("LAN_ADMINLOG_10", "Warning Icon");
define("LAN_ADMINLOG_11", "Warning Message");
define("LAN_ADMINLOG_12", "Fatal Icon");
define("LAN_ADMINLOG_13", "Fatal Error Message");

?>