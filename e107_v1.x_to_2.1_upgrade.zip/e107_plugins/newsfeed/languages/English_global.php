<?php

define("LAN_PLUGIN_NEWSFEEDS_NAME", "Newsfeeds");
define("LAN_PLUGIN_NEWSFEEDS_DESCRIPTION", "This plugin will retrieve rss feeds from other websites and display them according to your preferences.");

?>
