<?php
$text .= wad("meta.php", "Meta Tags", "Edit site meta tags", "P");
?>