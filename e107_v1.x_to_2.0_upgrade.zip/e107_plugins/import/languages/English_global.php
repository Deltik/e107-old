<?php
/*
* Copyright (c) e107 Inc 2009 - e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $Id$
*
* 'Import plugin' global language defines
*/
define("LAN_PLUGIN_IMPORT_NAME", "Import into e107");
define("LAN_PLUGIN_IMPORT_DESCRIPTION", "Import data from Wordpress, Joomla, Drupal, Blogpost, RSS and other formats.");
?>