<?php

define("LAN_PLUGIN_TRACKBACK_NAME", "Trackback");
define("LAN_PLUGIN_TRACKBACK_DESCRIPTION", "This plugin enables you to use trackback in your news posts.");

?>