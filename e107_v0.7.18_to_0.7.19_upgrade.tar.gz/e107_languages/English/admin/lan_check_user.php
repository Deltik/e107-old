<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_check_user.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define('LAN_CKUSER_01','Check user database');
define('LAN_CKUSER_02','This will check for various potential problems with your user database');
define('LAN_CKUSER_03','If you have a lot of users, it may take some time, or even time out');
define('LAN_CKUSER_04','Proceed');
define('LAN_CKUSER_05','Check for duplicate login names');
define('LAN_CKUSER_06','Select functions to perform');
define('LAN_CKUSER_07','Duplicate User Names found');
define('LAN_CKUSER_08','No duplicates found');
define('LAN_CKUSER_09','User Name');
define('LAN_CKUSER_10','User ID');
define('LAN_CKUSER_11','Display Name');
define('LAN_CKUSER_12','Check for duplicate email addresses');
define('LAN_CKUSER_13','Duplicate email addresses found');
define('LAN_CKUSER_14','Email address');
define('LAN_CKUSER_15','No duplicates found');
define('LAN_CKUSER_16','Find entries where user name is someone else\'s login name');
define('LAN_CKUSER_17','Conflicting user name and login name');
define('LAN_CKUSER_18','User A');
define('LAN_CKUSER_19','User B');
define('LAN_CKUSER_20','');

?>