<?php
/*
+---------------------------------------------------------------+
|        e107 website system                                                                                                        |
|        language file: english                                                                                                        |
|                                                                                                                                                                                |
|        �Steve Dunstan 2001-2002                                                                                |
|        http://jalist.com                                                                                                                        |
|        stevedunstan@jalist.com                                                                                        |
|                                                                                                                                                                                |
|        Released under the terms and conditions of the                |
|        GNU General Public License (http://gnu.org).                                |
+---------------------------------------------------------------+
*/
 define(LAN_0, "[bloqu� par l'admin]");

//define(LAN_1, "Unblock");

 define(LAN_1, "D�bloqu�");

//define(LAN_2, "Block");

 define(LAN_2, "Bloqu�");

//define(LAN_3, "Delete");

 define(LAN_3, "Effacer");

//define(LAN_4, "Info");

 define(LAN_4, "Info");

//define(LAN_5, "Comments ...");

 define(LAN_5, "Commentaires ...");

//define(LAN_6, "You must be logged in to post comments on this site - please either log in or if you are not registered click <a href="signup.php">here</a> to signup");

 define(LAN_6, "Vous devez vous identifier pour poster des commentaires sur ce site - veuillez le faire <a href=\"signup.php\">ici</a>.");

//define(LAN_7, "Name: ");

 define(LAN_7, "Nom: ");

//define(LAN_8, "Comment");

 define(LAN_8, "Commentaire");

//define(LAN_9, "Submit comment");

 define(LAN_9, "Proposer");

//define(LAN_10, "Shortcut tags allowed: [b] [i] [u] [img] [cen] [bq]<br />use [link] url [/link] for links<br />Line breaks (< br />) are auto added.");

 define(LAN_10, "Tags permis: [b] [i] [u] [img] [cen] [bq]<br />Utiliser [link] votre url [/link] pour les liens<br />Les retours � la ligne (< br />) sont identifi�s automatiquement.");


//chat.php
//define(LAN_11, "Chatbox (all posts)");

 define(LAN_11, "Coin de la causette (tous les messages)");

//define(LAN_12, "Chat Posts");

 define(LAN_12, "Messages");


//class.php
//define(LAN_13, "News story deleted.");

 define(LAN_13, "Nouvelle effac�e.");

//define(LAN_14, "News updated in database.");

 define(LAN_14, "Nouvelle mise � jour.");

//define(LAN_15, "News entered into database.");

 define(LAN_15, "Nouvelle ajout�e.");

//define(LAN_16, "Username: ");

 define(LAN_16, "Surnom/Pseudo: ");

//define(LAN_17, "Password: ");

 define(LAN_17, "Mot de Passe: ");

//define(LAN_18, "Please log in");

 define(LAN_18, "Veuillez vous identifier");

//define(LAN_19, "Unable to write news.xml file to server, please ensure the /backend directory has the correct permissions set (666)");

 define(LAN_19, "Impossible d'�crire sur le fichier news.xml, veuillez contr�ler les permissions (666) du dossier /backend ");

//define(LAN_20, "Error");

 define(LAN_20, "Erreur");

//define(LAN_21, "Total page visits today: ");

 define(LAN_21, "Total des pages vues aujourd'hui: ");

//define(LAN_22, "Total page visits ever: ");

 define(LAN_22, "Total des pages vues: ");

//define(LAN_23, "Total site views: ");

 define(LAN_23, "Total des pages vues: ");

//define(LAN_24, "fuck|piss|shit|cunt|cock|asshole|motherfucker|mother fucker| arse|pussy|faggot");

 define(LAN_24, "putain|pisse|merde|cunt|bite|trou du cul|fils de pute|encul�| arse|chatte|faggot");

//define(LAN_25, "Previous page");

 define(LAN_25, "Page pr�c�dente");

//define(LAN_26, "Next page");

 define(LAN_26, "Page suivante");


//forum.php
//define(LAN_27, "You left required fields blank");

 define(LAN_27, "Vous avez oubli� de remplir des champs obligatoires");

//define(LAN_28, "Err you didn't post anything ..");

 define(LAN_28, "Erreur, vous avez oubli� d'entrer le moindre mot ..");

//define(LAN_29, "Edited");
 define(LAN_29, "Edit�");

//define(LAN_30, "Welcome");
 define(LAN_30, "Bienvenue");

//define(LAN_31, "There are no new posts ");
 define(LAN_31, "Il n'y a pas de nouveaux messages ");

//define(LAN_32, "There is 1 new post ");
 define(LAN_32, "Il y a 1 nouveau message ");

//define(LAN_33, "There are");
 define(LAN_33, "Il y a ");

//define(LAN_34, "new posts");
 define(LAN_34, "nouveaux messages");

//define(LAN_35, "since your last visit.");
 define(LAN_35, "depuis votre derni�re visite.");

//define(LAN_36, "You last visit visited at ");
 define(LAN_36, "Votre derni�re visite remonte � ");

//define(LAN_37, "It is now is ");
 define(LAN_37, "Nous sommes le ");

//define(LAN_38, ", all times are GMT.");
 define(LAN_38, ", GMT.");

//define(LAN_39, "total topics");
 define(LAN_39, "sujets totaux");

//define(LAN_40, "total posts.");
 define(LAN_40, "messages totaux.");

//define(LAN_41, "Newest member: ");
 define(LAN_41, "Derniers membres: ");

//define(LAN_42, "Registered members: ");
 define(LAN_42, "Membres enregistr�s: ");

//define(LAN_43, "These forums can be browsed and posted to by non-registered users, but if you wish to see info related to new posts, edit/delete your posts etc you will have to <a href="signup.php">register</a> and log in.");
 define(LAN_43, "Vous pouvez visiter et poster sur ces forums sans vous enregistrer. Mais si vous voulez b�n�ficier de tous les atouts du forum, vous devez vous identifier <a href=\"signup.php\">ici</a>.");

//define(LAN_44, "These forums can be browsed and posted to by non-registered users, ip addresses and host will be logged.");

 define(LAN_44, "Vous pouvez visiter et poster sur ces forums sans vous enregistrer. Cependant votre adresse IP sera enregistr� afin d'�viter certains abus.");

//define(LAN_45, "These forums can only be posted to by registered and logged in members, please click <a href="signup.php">here</a> to go to the registration page.");

 define(LAN_45, "Vous devez vous identifier pour poster sur ces forums, vous pouvez le faire <a href=\"signup.php\">ici</a>.");

//define(LAN_46, "Forum");
 define(LAN_46, "Forum");

//define(LAN_47, "Threads");
 define(LAN_47, "Fil");

//define(LAN_48, "Replies");
 define(LAN_48, "R�ponses");

//define(LAN_49, "Last Post");
 define(LAN_49, "Dernier message");

//define(LAN_50, "Moderators");
 define(LAN_50, "Mod�rateurs");

//define(LAN_51, "No forums yet, please check back soon.");
 define(LAN_51, "Il n'y a encore aucun forum.");

//define(LAN_52, "No forums in this section yet, please check back soon.");
 define(LAN_52, "Il n'y a encore aucun forum dans cette section.");

//define(LAN_53, "Thread");
 define(LAN_53, "Fil");

//define(LAN_54, "Starter");
 define(LAN_54, "D�marreur");

//define(LAN_55, "Replies");
 define(LAN_55, "R�ponses");

//define(LAN_56, "Views");
 define(LAN_56, "Vues");

//define(LAN_57, "Lastpost");
 define(LAN_57, "Dernier message");

//define(LAN_58, "There are no topics in this forum yet.");
 define(LAN_58, "Il n'y a encore aucun sujet dans ce forum.");

//define(LAN_59, "You must be a registered member and logged in to post on this forum. Click <a href="signup.php">here</a> to sign up or login from the login menu.");

 define(LAN_59, "Vous devez vous identifier pour poster sur ce forum, vous pouvez le faire <a href=\"signup.php\">ici</a>.");

//define(LAN_60, "Start New Thread");

 define(LAN_60, "D�buter un nouveau fil");

//define(LAN_61, "Your Name: ");
 define(LAN_61, "Votre nom: ");

//define(LAN_62, "Subject: ");
 define(LAN_62, "Sujet: ");

//define(LAN_63, "Post: ");
 define(LAN_63, "Message: ");

//define(LAN_64, "Submit new thread");
 define(LAN_64, "Proposer un nouveau fil");

//define(LAN_65, "Admin detected - moderation switched on");
 define(LAN_65, "Admin detect� - moderation enclench�");

//define(LAN_66, "This thread is now closed");
 define(LAN_66, "Ce fil est maintenant ferm�");

//define(LAN_67, "posts");
 define(LAN_67, "messages");

//define(LAN_68, "edit");
 define(LAN_68, "editer");

//define(LAN_69, "delete");
 define(LAN_69, "effacer");

//define(LAN_70, "move");
 define(LAN_70, "d�placer");

//define(LAN_71, "No replies.");
 define(LAN_71, "Aucune r�ponse.");

//define(LAN_72, "Originally posted by");
 define(LAN_72, "Post� par");

//define(LAN_73, "Reply: ");
 define(LAN_73, "R�ponse: ");

//define(LAN_74, "Reply to thread");
 define(LAN_74, "R�pondre au fil");

//define(LAN_75, "Post Reply");
 define(LAN_75, "Poster votre r�ponse");

//define(LAN_76, "Reply");
 define(LAN_76, "R�pondre");

//define(LAN_77, "Update Thread");
 define(LAN_77, "Mis � jour du fil");

//define(LAN_78, "Update Reply");
 define(LAN_78, "Mis � jour de la r�ponse");

//define(LAN_79, "New posts");
 define(LAN_79, "Nouveaux messages");

//define(LAN_80, " No new posts");
 define(LAN_80, "Aucun nouveaux messages");

//define(LAN_81, "Closed thread");
 define(LAN_81, "Fil ferm�");


//index.php
//define(LAN_82, "News - Category");
 define(LAN_82, "Nouvelles - Categorie");

//define(LAN_83, "No news items yet.");
 define(LAN_83, "Aucune nouvelle proposition.");

//define(LAN_84, "News Items");
 define(LAN_84, "Nouvelle Proposition");


//links.php
//define(LAN_85, "No links yet.");
 define(LAN_85, "Aucun liens.");

//define(LAN_86, "Category:");
 define(LAN_86, "Categorie:");

//define(LAN_87, "Button for");
 define(LAN_87, "Bouton pour");

//define(LAN_88, "Referals:");
 define(LAN_88, "R�f�rants:");

//define(LAN_89, "Admin: ");
 define(LAN_89, "Admin: ");

//define(LAN_90, "add new link in this category");
 define(LAN_90, "ajouter des nouveaux liens dans cette cat�gorie");

//define(LAN_91, "add new category");
 define(LAN_91, "ajouter de nouvelles cat�gories");


//oldpolls.php
//define(LAN_92, "Old Surveys");
 define(LAN_92, "Anciens sondages");

//define(LAN_93, "No old polls yet.");
define(LAN_93, "Aucun ancien sondage pour le moment.");

//define(LAN_94, "Posted by");
 define(LAN_94, "Propos� par");

//define(LAN_95, "Total votes:");
 define(LAN_95, "Total des votes:");

//define(LAN_96, "Polls");
 define(LAN_96, "Sondages");


//search.php
//define(LAN_97, "No matches.");
 define(LAN_97, "Aucunes occurences.");

//define(LAN_98, "News Items");
 define(LAN_98, "Articles");

//define(LAN_99, "Comments");
 define(LAN_99, "Commentaires");

//define(LAN_100, "Articles");
 define(LAN_100, "Articles");

//define(LAN_101, "Chatbox");
 define(LAN_101, "Le coin de la causette");

//define(LAN_102, "Links");
 define(LAN_102, "Liens");

//define(LAN_103, "Forum");
 define(LAN_103, "Forum");


//signup.php
//define(LAN_104, "That user name already exists in the database, please choose a different user name.");

 define(LAN_104, "Ce nom d'utilisateur existe d�j� dans la base de donn�es, veuillez en choisir un autre.");

//define(LAN_105, "The two passwords do not match, please re-enter.");

 define(LAN_105, "Vous avez entrer deux mots de passe diff�rants, veuillez les r�-entrer.");

//define(LAN_106, "That doesn't appear to be a valid email address, please re-enter.");

 define(LAN_106, "Cet e-mail ne semble pas �tre valide, veuillez le r�-entrer.");

//define(LAN_107, "Thankyou! You are now a registered member of ".SITENAME.", please keep your username and password written down in a safe place as if lost they cannot be retrieved.<br /><br />You can now login from the Login box.");

 define(LAN_107, "MERCI! Vous faites maintenant partie de la communaut� du ".SITENAME.". Un bon conseil, notez votre identifiant et votre mot de passe dans un lieu s�r.<br /><br />Vous pouvez d�s � pr�sent vous identifier !.");

//define(LAN_108, "Registration complete");
 define(LAN_108, "Enregistrement complet");

//define(LAN_109, "This site complies with The Children's Online Privacy Protection Act of 1998 (COPPA) and as such cannot accept registrations from users under the age of 13 without a written permission document from their parent or guardian. For more information you can read the legislation <a href="http://www.cdt.org/legislation/105th/privacy/coppa.html">here</a>. Please contact the main site admin <a href="mailto:".SITEADMINEMAIL."">here</a> if you require assistance.<br /><br /><div style="text-align:center"><b>If you are over the age of 13 please click <a href="signup.php?stage1">here</a> to continue the registration process.");

 define(LAN_109, "Ce site adh�re aux principes du <b>The Children's Online Privacy Protection Act of 1998 (COPPA)</b>. D�s lors, nous ne pouvons accepter votre enregistrement si vous n'avez pas 13 ans r�volus ou une permission �crite de vos parents. Pour plus d'informations, merci de vous r�f�rer sur le site de la COPPA <a href=\"http://www.cdt.org/legislation/105th/privacy/coppa.html\">ici</a>. En cas de probl�me, merci de contacter le webmaster du site <a href=\"mailto:".SITEADMINEMAIL."\">ici</a>.<br /><br /><div style=\"text-align:center\"><b>Si vous avez 13 ans r�volus, veuillez cliquer <a href=\"signup.php?stage1\">ici</a>.");

//define(LAN_110, "Registration");
 define(LAN_110, "Enregistrement");

//define(LAN_111, "Re-type Password: ");
 define(LAN_111, "Re-taper votre mot de passe: ");

//define(LAN_112, "Email Address: ");
 define(LAN_112, "Adresse e-mail: ");

//define(LAN_113, "Hide email address?: ");
 define(LAN_113, "Cacher votre adresse e-mail?: ");

//define(LAN_114, "(This will prevent your email address from being displayed)");
 define(LAN_114, "(Ceci pr�servera votre e-mail de la vue de tous)");

//define(LAN_115, "ICQ Number: ");
 define(LAN_115, "Num�ro ICQ: ");

//define(LAN_116, "AIM Nickname: ");
 define(LAN_116, "Identifiant AIM: ");

//define(LAN_117, "MSN Nickname: ");
 define(LAN_117, "Identifiant MSN: ");

//define(LAN_118, "Birthday: ");
 define(LAN_118, "Anniversaire: ");

//define(LAN_119, "Location: ");
 define(LAN_119, "Lieu: ");

//define(LAN_120, "Signature: ");
 define(LAN_120, "Signature: ");

//define(LAN_121, "Image: ");
 define(LAN_121, "Image: ");

//define(LAN_122, "Timezone:");
 define(LAN_122, "Zone horaire:");

//define(LAN_123, "Register");
 define(LAN_123, "Enregistrer");


//stats.php
//define(LAN_124, "Total unique site views: ");
 define(LAN_124, "Total des visites (unique): ");

//define(LAN_125, "Total site views: ");
 define(LAN_125, "Total des visites: ");

//define(LAN_126, "Unique views by page: ");
 define(LAN_126, "Visites uniques par pages: ");

//define(LAN_127, "Total views by page: ");
 define(LAN_127, "Visites par pages: ");

//define(LAN_128, "Browser: ");
 define(LAN_128, "Navigateur: ");

//define(LAN_129, "Operating system: ");
 define(LAN_129, "Systeme d'exploitation: ");

//define(LAN_130, "Countries/Domains visited from: ");
 define(LAN_130, "Pays/Domaines des visiteurs: ");

//define(LAN_131, "Referers: ");
 define(LAN_131, "Referants: ");

//define(LAN_132, "Site Statistics");
 define(LAN_132, "Stats");


//submitnews.php
//define(LAN_133, "Thankyou");
 define(LAN_133, "MERCI");

//define(LAN_134, "Your item has been submitted and will be reviewed by one of the site administrators in due course.");
 define(LAN_134, "Votre proposition a bien �t� transmise et sera examin�e ASAP.");

//define(LAN_135, "News Item: ");
 define(LAN_135, "Articles: ");

//define(LAN_136, "Submit News Item");
 define(LAN_136, "Proposer");


//user.php
//define(LAN_137, "There is no information for that user as they are not registered at");

 define(LAN_137, "Il n'y a pas d'information sur cet utilisateur");

//define(LAN_138, "Registered members: ");
 define(LAN_138, "Membres enregistr�s: ");

//define(LAN_139, "Order: ");
 define(LAN_139, "Ordre: ");

//define(LAN_140, "Registered members");
 define(LAN_140, "Membres enregistr�s");

//define(LAN_141, "No registered members yet.");
 define(LAN_141, "Il n'y a aucun membre enregistr�.");

//define(LAN_142, "Member");
 define(LAN_142, "Membre");

//define(LAN_143, "[hidden by request]");
 define(LAN_143, "[cach� selon sa demande]");

//define(LAN_144, "Website URL: ");
 define(LAN_144, "URL: ");

//define(LAN_145, "Registered:");
 define(LAN_145, "Enregistr� le:");

//define(LAN_146, "Visits to site since registration: ");
 define(LAN_146, "Visites sur le site depuis son enregistrement: ");

//define(LAN_147, "Chatbox posts: ");
 define(LAN_147, "Messages: ");

//define(LAN_148, "Comments posted: ");
 define(LAN_148, "Commentaires post�s: ");

//define(LAN_149, "Forum posts: ");
 define(LAN_149, "Messages sur le forum: ");


//usersettings.php
//define(LAN_150, "Settings updated.");
 define(LAN_150, "Pr�f�rences mises � jour.");

//define(LAN_151, "OK");
 define(LAN_151, "OK");

//define(LAN_152, "New Password: ");
 define(LAN_152, "Nouveau mot de passe: ");

//define(LAN_153, "Re-type New Password: ");
 define(LAN_153, "Re-taper votre nouveau mot de passe: ");

//define(LAN_154, "Update Settings");
 define(LAN_154, "Pr�f�rences mise � jour");

//define(LAN_155, "Update User Settings");
 define(LAN_155, "Mise � jour des pr�fences des utilisateurs");

//define(LAN_185, "You left the password field blank,");
 define(LAN_185, "Vous avez oubli� d'entrer votre mot de passe");


//plugins
//define(LAN_156, "Submit");
 define(LAN_156, "Envoyer");

//define(LAN_157, "Reset");
 define(LAN_157, "Raz");

//define(LAN_158, "No messages yet.");
 define(LAN_158, "Il n'y a aucun message pour le moment.");

//define(LAN_159, "View all posts");
 define(LAN_159, "Voir tous les messages");

//define(LAN_160, "Webmaster: ");
 define(LAN_160, "Webmaster: ");

//define(LAN_161, "Headlines");
 define(LAN_161, "Headlines");

//define(LAN_162, "No active survey.");
 define(LAN_162, "Il n'y a aucun sondage actif.");

//define(LAN_163, "Submit Vote");
 define(LAN_163, "Soumettre votre vote");

//define(LAN_164, "Votes: ");
 define(LAN_164, "Votes: ");

//define(LAN_165, "Old Surveys");
 define(LAN_165, "Anciens sondages");


//menus
//define(LAN_166, "No articles yet.");
 define(LAN_166, "Il n'y a aucun article pour le moment.");

//define(LAN_167, "Articles");
 define(LAN_167, "Articles");

//define(LAN_168, "Our headlines can be syndicated by using either our rss or text feeds.");
 define(LAN_168, "Vous pouvez reprendre nos headlines gr�ce � ces deux fichiers: rss ou txt.");

//define(LAN_169, "Backend");
 define(LAN_169, "Dorsal");

//define(LAN_170, "W3C Compliance");
 define(LAN_170, "Conforme au normes W3C");

//define(LAN_171, "Unique user id not recognised (possible corrupted cookie).<br />Please <a href="index.php?logout">click here</a> to destroy cookie.");

 define(LAN_171, "Le site ne peut reconna�tre votre ID(un cookie d�grad� probablement).<br />Veuillez vous <a href=\"index.php?logout\">d�connecter</a>.");

//define(LAN_172, "Logout");
 define(LAN_172, "D�connexion");

//define(LAN_173, "Login Error");
 define(LAN_173, "Erreur d'Idendification");

//define(LAN_174, "Signup");
 define(LAN_174, "S'enregister");

//define(LAN_175, "Login");
 define(LAN_175, "Identification");

//define(LAN_176, "Users on this page: ");
 define(LAN_176, "Visiteurs sur cette page: ");

//define(LAN_177, "Users on site: ");
 define(LAN_177, "Visiteurs sur le site: ");

//define(LAN_178, "Logged in users: ");
 define(LAN_178, "Membres enregistr�s: ");

//define(LAN_179, "Online");
 define(LAN_179, "En ligne");

//define(LAN_180, "Search");
 define(LAN_180, "Recherche");

//define(LAN_181, "Link to us");
 define(LAN_181, "Lien vers nous");

//define(LAN_182, "Chatbox");
 define(LAN_182, "Le coin de la causette");

//define(LAN_183, "Main Menu");
 define(LAN_183, "Menu principal");

//define(LAN_184, "Poll");
 define(LAN_184, "Sondage");


// #### Added in v5 #### //

//define(LAN_186, "Send News Item");
 define(LAN_186, "Envoyer article");

//define(LAN_187, "Email address to send to");
 define(LAN_187, "Envoyer �");

//define(LAN_188, "I thought you might be interested in this news story from");
 define(LAN_188, "I thought you might be interested in this news story from");

//define(LAN_189, "Powered by");
 define(LAN_189, "Fonctionne avec");

//define(LAN_190, "Reviews");
 define(LAN_190, "Relectures");

//define(LAN_191, "Information");
 define(LAN_191, "Information");

//define(LAN_192, "The users of this forum have posted a total of ");
 define(LAN_192, "Les utilisateurs de ce forum on post� un total de ");

//define(LAN_193, "Forum Moderator");
 define(LAN_193, "Mod�rateur du forum");

//define(LAN_194, "Guest");
 define(LAN_194, "Invit�");

//define(LAN_195, "Registered Member");
 define(LAN_195, "Membre enregistr�");

//define(LAN_196, "You have read ");
 define(LAN_196, "Vous avez lu ");

//define(LAN_197, " of these posts.");
 define(LAN_197, " de ces messages.");

//define(LAN_198, " All new posts have been read.");
 define(LAN_198, " Tous les nouveaux messages ont �t� lus.");

//define(LAN_199, "Mark all posts as read");
 define(LAN_199, "Marquer tous les messages comme lus");

//define(LAN_200, "close this thread");
 define(LAN_200, "Fermer ce fil");

//define(LAN_201, "reopen this thread");
 define(LAN_201, "Reouvrir ce fil");

//define(LAN_202, "Sticky thread");
 define(LAN_202, "Fil collant");

//define(LAN_203, "Sticky/Closed thread");
 define(LAN_203, "Fil Ferm�/Collant");

//define(LAN_204, "You <b>can</b> start new threads");
 define(LAN_204, "Vous <b>pouvez</b> d�marrer un nouveau fil");

//define(LAN_205, "You <b>cannot</b> start new threads");
 define(LAN_205, "Vous <b>ne pouvez pas</b> d�marrer un nouveau fil");

//define(LAN_206, "You <b>can</b> post replies");
 define(LAN_206, "Vous <b>pouvez</b> poster des r�ponses");

//define(LAN_207, "You <b>cannot</b> post replies");
 define(LAN_207, "Vous <b>ne pouvez pas</b> poster des r�ponses");

//define(LAN_208, "You <b>can</b> edit your posts");
 define(LAN_208, "Vous <b>pouvez</b> �diter vos messages");

//define(LAN_209, "You <b>cannot</b> edit your posts");
 define(LAN_209, "Vous <b>ne pouvez pas</b> �diter vos messages");

//define(LAN_210, "You <b>can</b> delete your posts");
 define(LAN_210, "Vous <b>pouvez</b> effacer vos messages");

//define(LAN_211, "You <b>cannot</b> delete your posts");
 define(LAN_211, "Vous <b>ne pouvez pas</b> effacer vos messages");

//define(LAN_212, "Forgot password?");
 define(LAN_212, "Mot de passe oubli�");

//define(LAN_213, "That username/email address was not found in database.");
 define(LAN_213, "Ce nom d'utilisateur ou cette adresse n'a pas �t� trouv� dans la base de donn�es.");

//define(LAN_214, "Unable to reset password");
 define(LAN_214, "Impossible de red�finir le mot de passe");

//define(LAN_215, "Your password for ".SITENAME." has been reset. Your new password isnn");
 define(LAN_215, "Votre mot de passe pour ".SITENAME." a �t� red�finit. Votre nouveau mot de passe est");

//define(LAN_216, "To validate your new password please go to the following URL ...");
 define(LAN_216, "Pour valider votre nouveau mot de passe, merci d'aller sur le lien suivant ...");

//define(LAN_217, "Thankyou, your new password is now validated. You may now login using your new password.");
 define(LAN_217, "Merci, votre nouveau mot de passe est maintenant valid�. Vous pouvez utiliser votre nouveau mot de passe pour vous identifier.");


// NEW IN VERSION 5.3b4 - PLEASE UPDATE!

define(LAN_300, "That username was not found in the database.<br /><br />");
define(LAN_301, "Incorrect password.<br /><br />");
define(LAN_302, "You have not activated your account. You should have received an email with instructions on how to confirm your account, if not please contact a site administrator.<br /><br />");
define(LAN_303, "This news item is from ");
define(LAN_304, "Article Title: ");
define(LAN_305, "Subheading: ");
define(LAN_306, "This article is from ");
define(LAN_307, "Total posts in this category: ");
define(LAN_308, "Real Name: ");
define(LAN_309, "Please enter your details below - <b>a verification email will be sent to the email address you enter here so it must be valid, </b>if you do not wish to display your email address on this site please tick the hide email address box.");
define(LAN_310, "Unable to accept post as that username is registered - if it is your username please login to post.");
define(LAN_311, "Anonymous");
define(LAN_312, "Duplicate post - unable to accept.");
define(LAN_313, "Please choose which list you wish to display ...");
define(LAN_314, "Classes: ");
define(LAN_315, "Users: ");
define(LAN_316, "Go to page ");
define(LAN_317, "None");
define(LAN_318, "moderator options: ");
define(LAN_319, "Unstick");
define(LAN_320, "Stick");
define(LAN_321, "Moderators: ");
define(LAN_322, "Posted: ");
define(LAN_323, "Preview");
define(LAN_324, "Your message has been successfully posted.");
define(LAN_325, "Click Here to view your message");
define(LAN_326, "Click here to return to the forum");
define(LAN_327, "Review");
define(LAN_328, "Arrangements");   // "Settings" as used in default-header.
define(LAN_329, "Auto Login"); // Auto Login

define("LAN_354", "(R�serv�)");
define("LAN_355", "Encore aucun t�l�chargement dans cette cat�gorie");
define("LAN_356", "Taille totale des fichiers: ");
define("LAN_357", "Fichiers t�l�charg�s: ");
define("LAN_358", "Fichiers disponibles: ");
define("LAN_359", "Evaluer ce fichier");
define("LAN_360", "Merci d'avoir donn� une note !");
define("LAN_361", "t�l�chargements de");
define("LAN_362", "fichiers");
define("LAN_363", "T�l�chargements");
define("LAN_364", "Trier par");
define("LAN_365", "Date");
define("LAN_366", "Taille de fichier");
define("LAN_367", "T�l�charger");
define("LAN_368", "Aucun t�l�chargement possible pour le moment, veuillez r�essayer plus tard");
define("LAN_369", "Non class� actuellement");
define("LAN_370", "Classement: ");



?>