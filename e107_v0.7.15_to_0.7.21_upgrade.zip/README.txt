0.7.15 - 0.7.20 to 0.7.21 Upgrade Guide

This is an update from 0.7.15 - 0.7.20 to 0.7.21.  If you are upgrading from any other version besides from one of these, then you have downloaded the wrong package.  For those users that have been using the current CVS version of e107, this is the correct version to use.

Included in these releases are security related file changes and so you must upgrade your site with all these files.

To install, simply upload the files to your server overwriting the existing 0.7.15 - 0.7.20 files.

There are no database changes in this release.

