<?php

$DEMO_GALLERY_TITLE = LAN_THEME_DEMO_GALLERY_1;
$DEMO_GALLERY_TMPL = "<div class='clearfix' style='width: 100%;'>
	<div style='float: left; width: 49%;'>
		<a href='#'><img src='".THEME_ABS."images/demo_gal1.png' alt='' style='width: 100px; height: 64px; vertical-align: top;' /></a>
	</div>
	<div style='float: left; width: 49%; vertical-align: top;'>
		".LAN_THEME_DEMO_GALLERY_2."<br /><a href='#'>12</a> ".LAN_THEME_DEMO_GALLERY_3."
	</div>
</div>
<div style='text-align: center; width: 80%; border-bottom: 2px #ddd solid; margin: 30px auto ;'></div>
<div class='clearfix' style='width: 100%;'>
	<div style='float: left; width: 49%;'>
  <a href='#'><img src='".THEME_ABS."images/demo_gal2.png' alt='' style='width: 100px; height: 64px; vertical-align: top;' /></a>
	</div>
	<div style='float: left; width: 49%; vertical-align: top;'>
		".LAN_THEME_DEMO_GALLERY_2."<br /><a href='#'>12</a> ".LAN_THEME_DEMO_GALLERY_3."
	</div>
</div>
<br />
<small>".LAN_THEME_DEMO_GALLERY_4."</small>
";
?>