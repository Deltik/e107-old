<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/reline/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/24 19:02:07 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Comments are turned off for this item");
define("LAN_THEME_2", "Read/Post Comment: ");
define("LAN_THEME_3", "Read the rest...");
define("LAN_THEME_4", "Trackbacks: ");
define("LAN_THEME_5", "Posted by");
define("LAN_THEME_6", "on");
define("LAN_THEME_7", "Search...");


?>
