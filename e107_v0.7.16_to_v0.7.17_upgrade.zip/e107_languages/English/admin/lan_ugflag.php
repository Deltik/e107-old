<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_ugflag.php,v $
|     $Revision: 1.3 $
|     $Date: 2009/10/28 16:53:52 $
|     $Author: marj_nl_fr $
+----------------------------------------------------------------------------+
*/
define('UGFLAN_1', 'maintenance setting updated');
define('UGFLAN_2', 'Activate maintenance flag');
define('UGFLAN_3', 'Update Maintenance Setting');
define('UGFLAN_4', 'Maintenance Setting');

define('UGFLAN_5', 'Text to display when site down');
define('UGFLAN_6', 'Leave blank to display default message');

define('UGFLAN_8', 'Limit access to Admins only');
define('UGFLAN_9', 'Limit access to Main-Admins only');

?>