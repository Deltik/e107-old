<?php

$chatboxstyle = "
<span class='smalltext'><b>
{USERNAME}
</b> on 
{TIMEDATE}
</span><br />
<div class='mediumtext' style='text-align:left'>
{MESSAGE}
</div>
<div class='smalltext' style='text-align:right'>
{ADMINOPTIONS}
</div>";

?>