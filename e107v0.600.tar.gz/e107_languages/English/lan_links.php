<?php

define("PAGE_NAME", "Links");

define("LAN_61", "Link Categories");
define("LAN_62", "categories");
define("LAN_63", "category");
define("LAN_64", "in this category");
define("LAN_65", "link");
define("LAN_66", "links");
define("LAN_67", "Show All Links");
define("LAN_68", "edit");
define("LAN_69", "delete");
define("LAN_86", "Category:");
define("LAN_88", "Referals:");
define("LAN_89", "Admin: ");
define("LAN_90", "add new link in this category");
define("LAN_91", "add new category");

?>