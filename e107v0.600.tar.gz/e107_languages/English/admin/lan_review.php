<?php

define("REVLAN_1", "Review added to database.");
define("REVLAN_2", "Fields left blank.");
define("REVLAN_3", "Review updated in database.");
define("REVLAN_4", "Review deleted.");
define("REVLAN_5", "Please tick the confirm box to delete this review");
define("REVLAN_6", "No reviews yet.");
define("REVLAN_7", "Existing Reviews");
define("REVLAN_8", "Edit");
define("REVLAN_9", "Delete");
define("REVLAN_10", "tick to confirm");
define("REVLAN_11", "Open HTML Editor");
define("REVLAN_12", "Heading");
define("REVLAN_13", "Sub-Heading");
define("REVLAN_14", "Summary");
define("REVLAN_15", "Review");
define("REVLAN_16", "Rating");
define("REVLAN_17", "Please select rating");
define("REVLAN_18", "Allow comments?");
define("REVLAN_19", "On");
define("REVLAN_20", "Off");
define("REVLAN_21", "Visible to");
define("REVLAN_22", "Update Review");
define("REVLAN_23", "Submit Review");
define("REVLAN_24", "Reviews");

?>