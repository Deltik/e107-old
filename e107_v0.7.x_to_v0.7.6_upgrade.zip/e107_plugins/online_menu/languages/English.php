<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/11/16 19:50:45 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

define("ONLINE_L1", "Guests: ");
define("ONLINE_L2", "Members: ");
define("ONLINE_L3", "On this page: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Members");
define("ONLINE_L6", "Newest");
define("TRACKING_MESSAGE", "Online user tracking is currently disabled, please enable it <a href='".e_ADMIN."users.php?options'>here</a><br />");
?>