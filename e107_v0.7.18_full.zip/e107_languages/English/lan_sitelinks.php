<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_sitelinks.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/02 13:59:40 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Main Menu");
define("LAN_SITELINKS_502", "Admin Area");

?>