<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvs_backup/e107_0.7/e107_plugins/forum/languages/English/lan_newforumposts_menu.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
	
define("NFP_1", "All latest posts are outside of your user class, unable to display.");
define("NFP_2", "No posts yet");
define("NFP_3", "New Forum Posts menu configuration saved");
define("NFP_4", "Caption");
define("NFP_5", "Number of posts to display?");
define("NFP_6", "Number of characters to display?");
define("NFP_7", "Postfix for too long posts?");
define("NFP_8", "Show original topics in menu?");
define("NFP_9", "Update menu Settings");
define("NFP_10", "New Forum Posts Menu Configuration");
define("NFP_11", "Posted by");
define("NFP_12", "Maximum age of displayed posts");
define("NFP_13", "Use zero on a quiet site; setting a value in days will reduce database time on a busy site");
	
?>