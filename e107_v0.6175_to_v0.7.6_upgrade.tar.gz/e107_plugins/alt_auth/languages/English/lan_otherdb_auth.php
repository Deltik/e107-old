<?php
define("OTHERDB_LAN_1", "Database Type:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Username:");
define("OTHERDB_LAN_4", "Password:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Table");
define("OTHERDB_LAN_7", "Username Field:");
define("OTHERDB_LAN_8", "Password Field:");
define("OTHERDB_LAN_9", "Password Method:");
define("OTHERDB_LAN_10", "Configure otherdb auth");
define("OTHERDB_LAN_11", "** The following fields are not required if using an e107 database");

?>
