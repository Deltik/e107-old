<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/05 06:58:21 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "The filetype");
define("LANUPLOAD_2", "is not allowed and has been deleted.");
define("LANUPLOAD_3", "Successfully uploaded");
define("LANUPLOAD_4", "Either destination folder does not exist or is not writable. (chmod 777)");
define("LANUPLOAD_5", "The uploaded file exceeds the upload_max_filesize directive in php.ini.");
define("LANUPLOAD_6", "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form.");
define("LANUPLOAD_7", "The uploaded file was only partially uploaded.");
define("LANUPLOAD_8", "No file was uploaded.");
define("LANUPLOAD_9", "Uploaded file size 0 bytes");
define("LANUPLOAD_10", "Upload failed [Duplicate filename] - A file with the same name already exits.");
define("LANUPLOAD_11", "The file did not upload. Filename: ");
define("LANUPLOAD_12", "Error");

?>