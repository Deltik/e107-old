<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2017 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 */
 
define("LAN_PLUGIN_POLL_NAME", "Poll");
define("LAN_PLUGIN_POLL_DESCRIPTION", "The poll plugin allows you to define polls in either a menu or forum post.");

?>
