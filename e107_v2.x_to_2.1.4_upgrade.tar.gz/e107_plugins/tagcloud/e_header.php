<?php

if(USER_AREA)
{
	e107::css('tagcloud', 'tagcloud.css');
}

?>