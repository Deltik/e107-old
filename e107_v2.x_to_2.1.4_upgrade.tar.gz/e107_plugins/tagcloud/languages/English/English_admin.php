<?php
/*
* Copyright (c) e107 Inc 2008-2013 - e107.org, 
* Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
*
* 'FAQ plugin' admin-area language definitions
*/
 


