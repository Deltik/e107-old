/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.2 2006/03/03 05:07:12 e107coders Exp $ 
 */  

tinyMCE.addToLang('',{
insert_flash : 'Vložiť/editovať Flash Movie',
insert_flash_file : 'Flash súbor (.swf)',
insert_flash_size : 'Veľkosť',
insert_flash_list : 'Zoznam',
flash_props : 'Vlastnosti Flash'
});
