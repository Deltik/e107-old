0.7.x -> 0.7.20 Upgrade Guide

This update to 0.7.20 is a cumulative patch including all upgrade files from previous 0.7.x releases.
Included in these releases are security related file changes and so you must upgrade your site with all these files.

To install simply upload the files to your server overwriting the existing 0.7.x files.

There will be some database changes in this release, so you will be required to login to the site admin account, go to the main admin page and perform the database upgrades indicated.
