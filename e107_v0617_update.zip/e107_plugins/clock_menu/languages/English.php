<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/e107_plugins/clock_menu/languages/English.php
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('CLOCK_MENU_L1','Clock menu configuration saved');
define('CLOCK_MENU_L2','Caption');
define('CLOCK_MENU_L3','Update Menu Settings');
define('CLOCK_MENU_L4','Clock Menu Config');

?>