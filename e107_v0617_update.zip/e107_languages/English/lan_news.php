<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107/e107_languages/English/lan_news.php,v $
|     $Revision: 1.3 $
|     $Date: 2004/09/09 10:02:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "News");

define("LAN_82", "News - Category");
define("LAN_83", "No news items yet - please check back soon.");
define("LAN_84", "News Items");
define("LAN_99", "Comments");
define("LAN_100", "On");
define("LAN_307", "Total posts in this category: ");

define("LAN_NEWS_1", "News for specific members only");
define("LAN_NEWS_2", "You are not allowed to see this news");
define("LAN_NEWS_3", "Please delete install.php from your server");
define("LAN_NEWS_4", "if you do not there is a potential security risk to your website");
?>