<?php
/*
|	�Lolo Irie 2001-2004 (e107 Dev Team)
|	http://etalkers.org

|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org) for the e107 project.
*/
function sm_stats(){
	$texto = "<p class='caption2' style='text-align: left;' >\n
	<img src='".THEME."images/bullet2.gif' alt='bullet' /> <a class=\"sitemap2\"  href=\"stats.php\" >".LANSM_20."</a> <b class='smalltext' >".LANSM_33."</b>\n
	</p><br />\n";


	return $texto;
}
?>