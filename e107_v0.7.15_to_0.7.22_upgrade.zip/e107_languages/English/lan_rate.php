<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_rate.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "vote");
define("RATELAN_1", "votes");
define("RATELAN_2", "how do you rate this item?");
define("RATELAN_3", "thank you for your vote");
define("RATELAN_4", "not rated");
define("RATELAN_5", "Rate");

?>