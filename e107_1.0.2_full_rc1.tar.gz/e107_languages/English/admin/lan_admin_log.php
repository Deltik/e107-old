<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_admin_log.php $
|     $Revision: 11678 $
|     $Id: lan_admin_log.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "Date");
define("LAN_ADMINLOG_2", "Title");
define("LAN_ADMINLOG_3", "Description");
define("LAN_ADMINLOG_4", "User IP");
define("LAN_ADMINLOG_5", "User ID");
define("LAN_ADMINLOG_6", "Informative Icon");
define("LAN_ADMINLOG_7", "Informative Message");
define("LAN_ADMINLOG_8", "Notice Icon");
define("LAN_ADMINLOG_9", "Notice Message");
define("LAN_ADMINLOG_10", "Warning Icon");
define("LAN_ADMINLOG_11", "Warning Message");
define("LAN_ADMINLOG_12", "Fatal Icon");
define("LAN_ADMINLOG_13", "Fatal Error Message");

?>