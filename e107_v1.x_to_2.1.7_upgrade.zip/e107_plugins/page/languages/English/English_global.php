<?php

define("LAN_PLUGIN_PAGE_BOCHAP",  "Search in Book/Chapter");
