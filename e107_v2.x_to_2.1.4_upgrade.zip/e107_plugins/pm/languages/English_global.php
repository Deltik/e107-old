<?php

define("LAN_PLUGIN_PM_NAME", "Private Messenger");
define("LAN_PLUGIN_PM_DESCRIPTION", "This plugin is a fully featured Private Messaging system.");
define("LAN_PLUGIN_PM_URL_DEFAULT_LABEL", "Default");
define("LAN_PLUGIN_PM_URL_DEFAULT_DESCR", "Default");
define("LAN_PLUGIN_PM_INBOX", "Inbox");
define("LAN_PLUGIN_PM_OUTBOX", "Outbox");
define("LAN_PLUGIN_PM_NEW", "Send New Message");
define("LAN_PLUGIN_PM_TO", "To");
define("LAN_PLUGIN_PM_FROM", "From");
define("LAN_PLUGIN_PM_SUB", "Subject");
define("LAN_PLUGIN_PM_MESS", "Message");
define("LAN_PLUGIN_PM_READ", "Read");
define("LAN_PLUGIN_PM_DEL", "Delete PM");
define("LAN_PLUGIN_PM_ATTACHMENT", "Attachment");
define("LAN_PLUGIN_PM_SIZE", "Size");
?>
