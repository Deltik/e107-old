<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 *
 *
 * $URL$
 * $Id$
 */

if (!defined('e107_INIT')) { exit; }

e107::css('inline','
	a.e-wysiwyg-toggle { margin-top:5px }
	.mce-tinymce.mce-fullscreen {   z-index: 1050;  !important }
');


?>