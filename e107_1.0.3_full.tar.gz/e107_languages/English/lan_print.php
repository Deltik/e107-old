<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_print.php $
|     $Revision: 11678 $
|     $Id: lan_print.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Printer Friendly"); }

define("LAN_PRINT_86", "Category:");
define("LAN_PRINT_87", "by ");
define("LAN_PRINT_94", "Posted by");
define("LAN_PRINT_135", "News Item: ");
define("LAN_PRINT_303", "This news item is from ");
define("LAN_PRINT_304", "Title: ");
define("LAN_PRINT_305", "Subheading: ");
define("LAN_PRINT_306", "This is from: ");
define("LAN_PRINT_307", "Print this page");

define("LAN_PRINT_1", "printer friendly");


?>