<?php

define("LCLAN_1", "Options Saved");
define("LCLAN_2", "Link added to database.");
define("LCLAN_3", "Link updated in database.");
define("LCLAN_4", "Link deleted.");
define("LCLAN_5", "Please tick the confirm box to delete this link.");
define("LCLAN_6", "Order updated.");
define("LCLAN_7", "No links set yet.");
define("LCLAN_8", "Existing Links");
define("LCLAN_9", "Edit");
define("LCLAN_10", "Delete");
define("LCLAN_11", "tick to confirm");
define("LCLAN_12", "Link Category");
define("LCLAN_13", "No categories set yet.");

define("LCLAN_14", "Add/Edit Categories");
define("LCLAN_15", "Link Name");
define("LCLAN_16", "Link URL");
define("LCLAN_17", "Link Description");
define("LCLAN_18", "Link Button / Icon");
define("LCLAN_19", "Link Open Type");
define("LCLAN_20", "opens in same window");
define("LCLAN_21", "_target=blank");
define("LCLAN_22", "_target=parent");

define("LCLAN_23", "_target=top");
define("LCLAN_24", "open in 600x400 miniwindow");
define("LCLAN_25", "Link Class");
define("LCLAN_26", "Ticking will make the link visible to only users in that class");
define("LCLAN_27", "Update Link");
define("LCLAN_28", "Add link");
define("LCLAN_29", "Links");
define("LCLAN_30", "move up");
define("LCLAN_31", "move down");
define("LCLAN_32", "Update Order");

define("LCLAN_33", "Link Order");
define("LCLAN_34", "Tick this to allow have the links page show only the link categories. Helpful if you have a lot of links.");
define("LCLAN_35", "Update Options");
define("LCLAN_36", "Link Page Options");

define("LCLAN_39", "View Images");

define("LCLAN_40", "Show only link categories");

define("LCLAN_41", "Allow links to be submitted");
define("LCLAN_42", "Allow visitors to submit links to your site");

define("LCLAN_43", "Submit links class");
define("LCLAN_44", "Select which users can submit links");
define("LCLAN_45", "Submitted by");
define("LCLAN_46", "Validate link");
define("LCLAN_47", "Submitted links");
define("LCLAN_48", "Date");
define("LCLAN_49", "Submitted link deleted");

define("LCLAN_50", "Mark as validated");

?>