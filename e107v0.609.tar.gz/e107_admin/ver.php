<?php

$e107info['e107_version'] = "v0.609";
$e107info['e107_build'] = "0";

?>