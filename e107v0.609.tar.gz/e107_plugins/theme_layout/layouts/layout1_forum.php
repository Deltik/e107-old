$FORUMSTART = "
<table style='width:100%' class='fborder'>
<tr>
<td  colspan='2' class='fcaption'>{BREADCRUMB}</td>
</tr>
<tr>
<td class='forumheader' colspan='2'>
<table cellspacing='0' cellpadding='0' style='width:100%'>
<tr>
<td class='smalltext'>{NEXTPREV}</td>
<td style='text-align:right'>&nbsp;{TRACK}</td>
</tr>
</table>
</td>
</tr>
<tr>
<td style='width:80%; vertical-align:bottom'>{MODERATORS}<div class='mediumtext'>{GOTOPAGES}</div></td>
<td style='width:20%; text-align:right'>{BUTTONS}</td>
</tr>
<tr>
<td colspan='2' style='text-align:center'>{THREADSTATUS}
<table style='width:100%' class='fborder'>
<tr>
<td style='width:20%; text-align:center' class='fcaption'>Author</td>
<td style='width:80%; text-align:center' class='fcaption'>Post</td>
</tr>";

$FORUMTHREADSTYLE = "
<tr>
<td class='forumheader' style='vertical-align:middle'>{NEWFLAG}{POSTER}</td>
<td class='forumheader' style='vertical-align:middle'>
<table cellspacing='0' cellpadding='0' style='width:100%'>
<tr>
<td class='smallblacktext'>{THREADDATESTAMP}</td>
<td style='text-align:right'>{QUOTEIMG}</td>
</tr>
</table>
</td>
</tr>
<tr>
<td class='forumheader3' style='vertical-align:top'>{AVATAR}<span class='smalltext'>{MEMBERID}{RPG}{JOINED}{POSTS}</span></td>
<td class='forumheader3' style='vertical-align:top'>{POST}<br />{SIGNATURE}</td>
</tr>
<tr>
<td class='finfobar'><span class='smallblacktext'>{TOP}</span></td>
<td class='finfobar' style='vertical-align:top'><table cellspacing='0' cellpadding='0' style='width:100%'>
<tr>
<td>{PROFILEIMG} {EMAILIMG} {WEBSITEIMG} {PRIVMESSAGE}</td>
<td style='text-align:right'>{MODOPTIONS}</td>
</tr>
</table>
</td>
</tr>
<tr>
<td colspan='2'></td>
</tr>";

$FORUMEND = "
</table>
</td>
</tr>
<tr>
<td style='width:80%; vertical-align:top'><div class='mediumtext'>{GOTOPAGES}</div>{FORUMJUMP}</td>
<td style='width:20%; text-align:right'>{BUTTONS}</td>
</tr>
</table>";

$FORUMREPLYSTYLE = "";