<?php

setlocale(LC_ALL, 'en');
define("CHARSET", "iso-8859-1");

?>