<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/e107_handlers/parser_functions.php
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
@include(e_LANGUAGEDIR.e_LAN."/lan_parser_functions.php");
@include(e_LANGUAGEDIR."English/lan_parser_functions.php");
function e107core_parse($match,$referrer){
	global $pref;
}

?>
