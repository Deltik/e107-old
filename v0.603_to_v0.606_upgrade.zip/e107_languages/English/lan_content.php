<?php

define("PAGE_NAME", "Article/Review");

define("LAN_25", "Previous page");
define("LAN_26", "Next page");


define("LAN_27", "List reviews in this category");
define("LAN_28", "Back to reviews front page");
define("LAN_29", "moderate comments");
define("LAN_30", "Back to reviews front page");
define("LAN_31", "No matches");
define("LAN_32", "Recent Reviews");
define("LAN_33", "reviews");
define("LAN_34", "review");
define("LAN_35", "Review Categories");
define("LAN_36", "List articles in this category");
define("LAN_37", "Back to articles front page");


define("LAN_38", "vote");
define("LAN_39", "votes");
define("LAN_40", "How would you rate this article?");
define("LAN_41", "thanks for submitting your rating");
define("LAN_42", "Rating");
define("LAN_43", "by");
define("LAN_44", "on");
define("LAN_45", "No articles in this category");
define("LAN_46", "Archive");
define("LAN_47", "Recent Articles");

define("LAN_48", "articles");
define("LAN_49", "article");
define("LAN_50", "Article Categories");
define("LAN_51", "This article cannot be viewed.");
define("LAN_52", "Error");
?>