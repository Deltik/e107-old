<?php

define("DOWLAN_1", "Download added to database.");
define("DOWLAN_2", "Download updated in database.");
define("DOWLAN_3", "Download deleted.");
define("DOWLAN_4", "Please tick the confirm box to delete the download");
define("DOWLAN_5", "There are no download categories defined yet, until you define some you cannot enter any downloads.");
define("DOWLAN_6", "No existing downloads");
define("DOWLAN_7", "Existing Downloads");
define("DOWLAN_8", "Edit");
define("DOWLAN_9", "Delete");
define("DOWLAN_10", "tick to confirm");
define("DOWLAN_11", "Category");
define("DOWLAN_12", "Name");
define("DOWLAN_13", "File");
define("DOWLAN_14", "enter url if external file");

define("DOWLAN_15", "Author");
define("DOWLAN_16", "Author Email");
define("DOWLAN_17", "Author Website");

define("DOWLAN_18", "Description");
define("DOWLAN_19", "Main image");
define("DOWLAN_20", "Thumbnail image");
define("DOWLAN_21", "Active?");
define("DOWLAN_22", "Yes");
define("DOWLAN_23", "No");
define("DOWLAN_24", "Update Download");
define("DOWLAN_25", "Submit Download");
define("DOWLAN_26", "Downloads");

define("DOWLAN_27", "Download");
define("DOWLAN_28", "Options");
define("DOWLAN_29", "Downloads Front Page");
define("DOWLAN_30", "Create Download");
define("DOWLAN_31", "Categories");
define("DOWLAN_32", "Downloads Options");
define("DOWLAN_33", "Are you sure you want to delete this download?");
define("DOWLAN_34", "Are you sure you want to delete this download category?");
define("DOWLAN_35", "Download");
define("DOWLAN_36", "deleted");
define("DOWLAN_37", "Parent");
define("DOWLAN_38", "No existing categories");
define("DOWLAN_39", "Download categories");
define("DOWLAN_40", "None - main parent");
define("DOWLAN_41", "Icon");
define("DOWLAN_42", "View Images");

define("DOWLAN_43", "Visible to");
define("DOWLAN_44", "Ticking will make the categorry visible to only users in that class");

define("DOWLAN_45", "Create Category");
define("DOWLAN_46", "Update Category");

define("DOWLAN_47", "Category created");
define("DOWLAN_48", "Category Updated");
define("DOWLAN_49", "Download Category");

define("DOWLAN_50", "Go to page: ");
define("DOWLAN_51", "Search downloads");

?>