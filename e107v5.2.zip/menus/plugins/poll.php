<?php
$text .= wad("poll_conf.php", "Poll", "Create/edit polls", "P");
?>