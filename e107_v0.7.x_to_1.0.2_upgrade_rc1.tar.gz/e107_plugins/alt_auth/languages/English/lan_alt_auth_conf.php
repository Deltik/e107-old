<?php


define('LAN_ALT_2', 'Current authorization type');
define('LAN_ALT_3', 'Choose Alternative Authorization Type');
define('LAN_ALT_4', 'Configure parameters for');
define('LAN_ALT_5', 'Configure authorization parameters');
define('LAN_ALT_6', 'Failed connection action');
define('LAN_ALT_7', 'If connection to the alternate method fails, how should that be handled?');
define('LAN_ALT_8', 'User not found action');
define('LAN_ALT_9', 'If username is not found using alternate method, how should that be handled?');
define('LAN_ALT_10', 'Failed login');
define('LAN_ALT_11', 'Use e107 user table');

define('LAN_ALT_PAGE', 'Alternative authentication');