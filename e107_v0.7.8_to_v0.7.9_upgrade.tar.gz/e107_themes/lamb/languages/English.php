<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/lamb/languages/English.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/03/03 19:59:49 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'lamb' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Comments are turned off for this item");
define("LAN_THEME_3", "comment: ");
define("LAN_THEME_4", "Read the rest ...");
define("LAN_THEME_5", "Trackbacks: ");


?>