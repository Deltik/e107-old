<?php

define("PAGE_NAME", "Forum"); 

define("LAN_30", "Welcome");
define("LAN_31", "There are no new posts ");
define("LAN_32", "There is 1 new post ");
define("LAN_33", "There are");
define("LAN_34", "new posts");
define("LAN_35", "since your last visit.");
define("LAN_36", "You last visited at ");
define("LAN_37", "It is now ");
define("LAN_38", ", all times are ");
define("LAN_41", "Newest member: ");
define("LAN_42", "Registered members: ");
define("LAN_44", "These forums can be used by non-registered users, but please be aware that your IP Address will be logged if you make a post.<br />To access the full features of this forum  you will need to <a href='".e_BASE."signup.php'>register</a> and log in.");
define("LAN_45", "These forums can only be posted to by registered and logged in members, please click <a href='".e_BASE."signup.php'>here</a> to go to the registration page.");
define("LAN_46", "Forum");
define("LAN_47", "Threads");
define("LAN_48", "Replies");
define("LAN_49", "Last Post");
define("LAN_51", "No forums yet, please check back soon.");
define("LAN_52", "No forums in this section yet, please check back soon.");
define("LAN_79", "New posts");
define("LAN_80", " No new posts");
define("LAN_81", "Closed thread");
define("LAN_100", "articles");
define("LAN_180", "Search");
define("LAN_191", "Information");
define("LAN_192", "The users of this forum have made a total of ");
define("LAN_196", "You have read ");
define("LAN_197", " of these posts.");
define("LAN_198", " All new posts have been read.");
define("LAN_199", "Mark all posts as read");
define("LAN_204", "You <b>can</b> start new threads");
define("LAN_205", "You <b>cannot</b> start new threads");
define("LAN_206", "You <b>can</b> post replies");
define("LAN_207", "You <b>cannot</b> post replies");
define("LAN_208", "You <b>can</b> edit your posts");
define("LAN_209", "You <b>cannot</b> edit your posts");
define("LAN_392", "stop tracking this thread");
define("LAN_393", "List tracked threads");
define("LAN_394", "Closed forum");
define("LAN_397", "Tracked threads");
define("LAN_398", "Closed");
define("LAN_399", "Restricted");
define("LAN_400", "This forum can only be browsed by registered members");
define("LAN_401", "Members only");

define("LAN_402", "This forum is read only");

define("LAN_403", "No posts yet");
define("LAN_404", "posts");
define("LAN_405", "Read Only");

define("LAN_406", "This forum is restricted to administrators only");
define("LAN_407", "This forum is restricted to members only");
define("LAN_408", "This is a read-only forum");
define("LAN_409", "This is a class restricted forum");
define("LAN_410", "Welcome guest");

?>