<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_notify.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "User Signup");

define("NT_LAN_UV_1", "User Signup Verified");
define("NT_LAN_UV_2", "User ID: ");
define("NT_LAN_UV_3", "User Login Name: ");
define("NT_LAN_UV_4", "User IP: ");


define("NT_LAN_LI_1", "User Logged In");

define("NT_LAN_LO_1", "User Logged Out");
define("NT_LAN_LO_2", " logged out of site");

define("NT_LAN_FL_1", "Flood Ban");
define("NT_LAN_FL_2", "IP address banned for flooding");

define("NT_LAN_SN_1", "News Item Submitted");

define("NT_LAN_NU_1", "Updated");

define("NT_LAN_ND_1", "News Item Deleted");
define("NT_LAN_ND_2", "Deleted news item id");

?>