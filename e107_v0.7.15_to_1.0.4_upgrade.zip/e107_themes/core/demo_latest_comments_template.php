<?php

$DEMO_COMMENTS_TITLE = LAN_THEME_DEMO_COMMENT_1;
$DEMO_COMMENTS_TMPL = "<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' /> <a href='#'>".LAN_THEME_DEMO_COMMENT_2."</a><br />
		".LAN_THEME_DEMO_COMMENT_3."<a href='#'>e107</a>
	</div>
</div>
<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' /> <a href='#'>".LAN_THEME_DEMO_COMMENT_2."</a><br />
		".LAN_THEME_DEMO_COMMENT_3."<a href='#'>e107</a>
	</div>
</div>
<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' /> <a href='#'>".LAN_THEME_DEMO_COMMENT_2."</a><br />
		".LAN_THEME_DEMO_COMMENT_3."<a href='#'>e107</a>
	</div>
</div>
<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' /> <a href='#'>".LAN_THEME_DEMO_COMMENT_2."</a><br />
		".LAN_THEME_DEMO_COMMENT_3."<a href='#'>e107</a>
	</div>
</div>
<small>".LAN_THEME_DEMO_COMMENT_4."</small>
";
?>