<?php
define("LAN_ALT_1", "Current authorization type");
define("LAN_ALT_2", "Update settings");
define("LAN_ALT_3", "Choose Alternate Authorization Type");
define("LAN_ALT_4", "Configure parameters for");
define("LAN_ALT_5", "Configure authorization parameters");
define("LAN_ALT_6", "Failed connection action");
define("LAN_ALT_7", "If connection to the alternate method fails, how should that be handled?");
define("LAN_ALT_8", "User not found action");
define("LAN_ALT_9", "If username is not found using alternate method, how should that be handled?");

define("LAN_ALT_FALLBACK", "Use e107 user table");
define("LAN_ALT_FAIL", "Failed login");

?>
