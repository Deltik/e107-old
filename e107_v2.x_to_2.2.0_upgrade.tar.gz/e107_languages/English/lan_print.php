<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2017 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * English language file - Printer Friendly Page
 *
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Printer Friendly"); }
//define("LAN_PRINT_86", "Category:");//LAN_CATEGORY // NOT USED
//efine("LAN_PRINT_87", "by ");//NOT USED
//define("LAN_PRINT_94", "Posted by");//LAN_POSTED_BY//NOT USED
//define("LAN_PRINT_135", "News Item: ");//NOT USED 
define("LAN_PRINT_303", "This news item is from ");
//define("LAN_PRINT_304", "Title: ");//LAN_TITLE
//define("LAN_PRINT_305", "Subheading: ");//NOT USED
//define("LAN_PRINT_306", "This is from: ");//NOT USED

define("LAN_PRINT_307", "Print this page");//TODO LANS GENERIC CANDIDATE

define("LAN_PRINT_1", "printer friendly");//TODO LANS GENERIC CANDIDATE

?>
