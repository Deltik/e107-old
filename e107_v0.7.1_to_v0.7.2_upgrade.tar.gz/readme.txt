0.7.1 -> 0.7.2 Upgrade Guide

This small update to 0.7.1 includes a major security update addressing potential xss exploits 
in the bbcodes system plus multiple bug fixes along with a couple of new features.

To install simply upload the files to your server overwriting the existing 0.7.1 files.
There are no database changes in this release so no update button will show.

0.7.1 -> 0.7.2 Changelog
  
Removed PHP error reporting for visitors that aren't site admins
Fixed WYSIWYG image paths
Fixed parse error in leaf theme's ul.sc
Fixed an issue where plugin-manager kept suggesting to remove plugin folder even after it was removed
Added $mode variable to tablerender in menus (Content)
Made stats logging more stable
New LINKSEPARATOR added for sitelinks
Ability to assign sielink css class per link category
Fixes for RSS Feeds
XHTML fixes for stats, by moving core head up the 'b' class for stats bar will be over-ridable by themes.
Fully templated forum_post
Return parm added to menu shortcode to enable a global pre and post shortcode style to be applied
Zip uploaded themes and plugins will now chmod all files from extracted theme or plugin as 0666 (making them deletable)
Site URL forwarding now sends 301 (moved permanently) rather than 302
Added new [hide] bbcode and the use of it in forums, users will have to reply to a thread to read anything inside [hide][/hide]
Added ETag header and must-revalidate cache control, should stop naughty proxies caching user login transitions
Fixed an annoying RSS encoding bug where the parser totally ignored the site's CHARSET (For news feed menus and pages)
Added alt auth to core (with LDAP/Active Directory/Etc support)
Extended user field record now deleted when user deleted or pruned
Added mysql error reporting to the installer and made it E_ALL error reporting and use includes rather than requires - no more blank screens
New toAttribute function added to validate user input in tag attributes to prevent potential xss exploits. thanks to Thomas Pollet for reporting this issue to us.
Plus many other bug fixes