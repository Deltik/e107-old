<?php



$mes = e107::getMessage();
echo $mes->render('default','info',false);

?>
