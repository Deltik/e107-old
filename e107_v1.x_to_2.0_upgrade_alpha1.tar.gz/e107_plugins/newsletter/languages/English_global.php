<?php

define("LAN_PLUGIN_NEWSLETTER_NAME", "Newsletter");
define("LAN_PLUGIN_NEWSLETTER_DESCRIPTION", "Provides a quick and easy way to configure and send newsletters.");

?>