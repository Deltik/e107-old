<?php
define("LDAPLAN_1", "Server address");
define("LDAPLAN_2", "Base DN or Domain<br />If LDAP - Enter BaseDN<br />If AD - Enter domain");
define("LDAPLAN_3", "LDAP Browsing user<br />Full context of the user who is able to search the directory.");
define("LDAPLAN_4", "LDAP Browsing password<br />Password for the LDAP Browsing user.");
define("LDAPLAN_5", "LDAP Version");
define("LDAPLAN_6", "Configure LDAP auth");
?>
