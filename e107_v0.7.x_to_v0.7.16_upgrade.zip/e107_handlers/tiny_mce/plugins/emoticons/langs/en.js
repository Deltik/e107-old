// UK lang variables

tinyMCE.addI18n('en.emoticons',{
	desc : 'Insert emotion'
});