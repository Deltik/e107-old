<?php
/*
* Copyright (c) 2018 e107 Inc e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
*
* Version file
*/

if (!defined('e107_INIT')) { exit; }

$e107info['e107_version'] = "2.1.9";
?>
