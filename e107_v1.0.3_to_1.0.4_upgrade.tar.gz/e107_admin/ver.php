<?php
/*
* Copyright (c) 2013 e107 Inc e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_admin/ver.php $
* $Id: ver.php 13107 2013-05-21 21:55:27Z e107coders $
*
* Version file
*/

if (!defined('e107_INIT')) { exit; }

$e107info['e107_version'] = "1.0.4";
?>
