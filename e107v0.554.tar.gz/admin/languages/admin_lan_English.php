<?php
/*
+---------------------------------------------------------------
|        e107 website system
|        admin language file: english
|
|        �Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/


define("ADLAN_0", "News");
define("ADLAN_1", "Add/edit/delete news items");
define("ADLAN_2", "News Categories");
define("ADLAN_3", "Add/edit/delete news categories");
define("ADLAN_4", "Preferences");
define("ADLAN_5", "Edit Site Preferences");
define("ADLAN_0", "News");
define("ADLAN_0", "News");
define("ADLAN_0", "News");
define("ADLAN_0", "News");
define("ADLAN_0", "News");
define("ADLAN_0", "News");
define("ADLAN_0", "News");

?>