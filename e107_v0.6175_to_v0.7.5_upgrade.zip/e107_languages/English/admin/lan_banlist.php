<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/17 06:49:46 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Ban removed.");
define("BANLAN_2", "No bans.");
define("BANLAN_3", "Existing Bans");
define("BANLAN_4", "Remove ban");
define("BANLAN_5", "Enter IP, email address, or host");
define("BANLAN_7", "Reason");
define("BANLAN_8", "Ban User");
define("BANLAN_9", "Ban users from site");
define("BANLAN_10", "IP / Email / Reason");
define("BANLAN_11", "Auto-ban: More than 10 failed login attempts");

?>