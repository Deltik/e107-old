<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.8/e107_languages/English/lan_parser_functions.php,v $
|     $Revision$
|     $Date$
|     $Author$
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Guest");
define("LAN_WROTE", "wrote"); // as in John wrote.."  ";


?>
