<?php
$text .= wad("headlines_conf.php", "Headlines", "Retrieve and display other site's headlines", "0.1.2");
?>