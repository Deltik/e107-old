<?php
require_once("plugins/headlines.php");
?>