<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|	/sitedown.php
|
|	�Steve Dunstan 2001-2002
|	http://jalist.com
|	stevedunstan@jalist.com
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

$text = "<font style=\"FONT-SIZE: 11px; COLOR: black; FONT-FAMILY: Tahoma, Verdana, Arial, Helvetica; TEXT-DECORATION: none\">
<div style=\"text-align:center\">
<img src=\"themes/shared/logo.png\" alt=\"Logo\" />
</div>
<hr />
<br />

<div style=\"text-align:center\"><b>- Temporarily Closed -</b><br /><br />We have temporarily closed the site for some essential maintainance. This shouldn't take too long - please check back soon, apologies for the inconvinience.

</font>";

echo $text;

?>