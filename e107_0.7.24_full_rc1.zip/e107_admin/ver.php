<?php
/*
* Copyright (c) 2010 e107 Inc e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $URL$
* $Id$
*
* Version file
*/

if (!defined('e107_INIT')) { exit; }

$e107info['e107_version'] = "0.7.24 rc1";
?>
