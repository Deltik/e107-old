<?php
$text = "";
require_once("plugins/poll.php");
?>