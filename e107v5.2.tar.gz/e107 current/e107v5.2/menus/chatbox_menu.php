<?php
$text = "";
require_once("plugins/chatbox.php");
?>