<?php
/*
+---------------------------------------------------------------+
|	e107 website system													|
|	language file: malay													|
|																						|
|	�translate in malay										|
|	by eYtO															|
|	eyt007@tm.net.my											|
|																						|
|	Released under the terms and conditions of the		|
|	GNU General Public License (http://gnu.org).				|
+---------------------------------------------------------------+
*/

//articles.php/comment.php
define(LAN_0, "[blocked by admin]");
define(LAN_1, "Unblock");
define(LAN_2, "Block");
define(LAN_3, "Delete");
define(LAN_4, "Info");
define(LAN_5, "Komen ...");
define(LAN_6, "Anda mesti masuk sebagai ahli sebelum menghantar kiriman - Sila masuk sebagai ahli atau mendaftar sebagai ahli baru dengan klik <a href=\"signup.php\">di sini</a> untuk mendaftar");
define(LAN_7, "Nama: ");
define(LAN_8, "Komen");
define(LAN_9, "Hantar Komen");
define(LAN_10, "Shortcut tags allowed: [b] [i] [u] [img] [cen] [bq]<br />use [link] url [/link] for links<br />Line breaks (&lt;br /&gt;) are auto added.");

//chat.php
define(LAN_11, "Borak (all posts)");
define(LAN_12, "Chat Posts");

//class.php
define(LAN_13, "Berita telah dipadam.");
define(LAN_14, "Berita terbaru dipangkalan data.");
define(LAN_15, "Berita dimasukkan dipangkalan data.");
define(LAN_16, "Username: ");
define(LAN_17, "Kata Laluan: ");
define(LAN_18, "Sila Daftar Ahli");
define(LAN_19, "Berita.xml tidak dapat ditulis/dipaparkan diserver, Sila pastikan /backend directory has the correct permissions set (666)");
define(LAN_20, "Error");
define(LAN_21, "Jumlah laman dilawat hari ini: ");
define(LAN_22, "Jumlah keseluruhan laman dilawat: ");
define(LAN_23, "Jumlah paparan laman: ");
define(LAN_24, "fuck|piss|shit|cunt|cock|asshole|motherfucker|mother fucker| arse|pussy|faggot");
define(LAN_25, "Halaman sebelum");
define(LAN_26, "Halaman selepas");

//forum.php
define(LAN_27, "anda meninggalkan ruangan kosong yang perlu diisi..");
define(LAN_28, "Err anda tidak menghantar apa-apa ..");
define(LAN_29, "Ubah");
define(LAN_30, "Assalamualaikum, Selamat Datang");
define(LAN_31, "Tiada kiriman terbaru ");
define(LAN_32, "1 kiriman terbaru ");
define(LAN_33, "Terdapat");
define(LAN_34, "Kiriman terbaru");
define(LAN_35, "Sejak anda melawat laman ini.");
define(LAN_36, "Lawatan terakhir anda pada ");
define(LAN_37, "Hari ini ");
define(LAN_38, ", Semua masa dalam GMT.");
define(LAN_39, "Jumlah topik");
define(LAN_40, "Jumlah kiriman.");
define(LAN_41, "Ahli terkini: ");
define(LAN_42, "Ahli berdaftar: ");
define(LAN_43, "Forum ini boleh dilayari dan di isi oleh ahli tidak berdaftar, tetapi jika anda ingin melihat maklumat berkenaan kiriman terbaru, ubah/padam kiriman anda dsb anda haruslah men<a href=\"signup.php\">daftar</a> dan masuk sebagai ahli.");
define(LAN_44, "Forum ini boleh dilayari dan di isi oleh ahli tidak berdaftar, alamat ip dan host akan direkod.");
define(LAN_45, "Forum ini hanya boleh di isi/kirim oleh ahli berdaftar dan masuk sebagai ahli, Sila klik <a href=\"signup.php\">Di sini</a> untuk pergi ke laman pendaftaran ahli.");
define(LAN_46, "Forum");
define(LAN_47, "Topik");
define(LAN_48, "Balas");
define(LAN_49, "Kiriman terakhir");
define(LAN_50, "Pengendali");
define(LAN_51, "Forum belum dikemaskini...sila masuk kemudian...");
define(LAN_52, "Belum ada forum dalam ruang ini, Sila datang kemudian.");
define(LAN_53, "Topik");
define(LAN_54, "Dimulakan");
define(LAN_55, "Balas");
define(LAN_56, "Dilihat");
define(LAN_57, "Kiriman terakhir");
define(LAN_58, "Tiada sebarang topik di forum ini.");
define(LAN_59, "Anda mestilah Ahli berdaftar dan masuk untuk menghantar sebarang topik di forum ini. Klik<a href=\"signup.php\">di sini</a> untuk masuk atau masuk melalui menu ahli.");
define(LAN_60, "Mulakan topik baru");
define(LAN_61, "Nama anda: ");
define(LAN_62, "Perkara: ");
define(LAN_63, "Kiriman: ");
define(LAN_64, "Hantar topik baru");
define(LAN_65, "Admin dikesan - Pengendali online");
define(LAN_66, "Topik ditutup");
define(LAN_67, "hantar");
define(LAN_68, "ubah");
define(LAN_69, "buang");
define(LAN_70, "pindah");
define(LAN_71, "Tiada balasan.");
define(LAN_72, "Kiriman asal oleh");
define(LAN_73, "Balas: ");
define(LAN_74, "Balas topik");
define(LAN_75, "Hantar balasan");
define(LAN_76, "Balas");
define(LAN_77, "Topik dikemaskini");
define(LAN_78, "Balasan dikemaskini");
define(LAN_79, "Kiriman terbaru");
define(LAN_80, " Tiada kiriman terbaru");
define(LAN_81, "Topik ditutup");

//index.php
define(LAN_82, "Berita - Kategori");
define(LAN_83, "Tiada Berita terkini lagi.");
define(LAN_84, "Berita ");

//links.php
define(LAN_85, "Tiada jalinan lagi.");
define(LAN_86, "Kategori:");
define(LAN_87, "Butang untuk");
define(LAN_88, "Referals:");
define(LAN_89, "Admin: ");
define(LAN_90, "Buat jalinan baru dalam kategori ini");
define(LAN_91, "Buat kategori baru");

//oldpolls.php
define(LAN_92, "Undian lama");
define(LAN_93, "Tiada undian lama lagi.");
define(LAN_94, "Dikirim oleh");
define(LAN_95, "Jumlah Undian:");
define(LAN_96, "Undian");

//search.php
define(LAN_97, "Tiada kesamaan.");
define(LAN_98, "Berita anda");
define(LAN_99, "Komen");
define(LAN_100, "Artikel");
define(LAN_101, "Borak Online"); 
define(LAN_102, "Jalinan");
define(LAN_103, "Forum");

//signup.php
define(LAN_104, "Username telah ada dalam pangkalan data, Sila pilih username yang lain.");
define(LAN_105, "Kata laluan tidak serasi, Sila isi sekali lagi.");
define(LAN_106, "alamat e-mail anda tidak tepat/salah, Sila isi sekali lagi.");
define(LAN_107, "Terima kasih! Anda adalah ahli terbaru ".SITENAME.", Sila simpan nama dan kata laluan yang telah dibuat dengan selamat kerana tiada penggantian akan dibuat.<br /><br />Anda boleh masuk dengan mengisi ruangan Daftar Ahli.");
define(LAN_108, "Pendaftaran selesai");
define(LAN_109, "This site complies with The Children's Online Privacy Protection Act of 1998 (COPPA) and as such cannot accept registrations from users under the age of 13 without a written permission document from their parent or guardian. For more information you can read the legislation <a href=\"http://www.cdt.org/legislation/105th/privacy/coppa.html\">here</a>. Please contact the main site admin <a href=\"mailto:".SITEADMINEMAIL."\">here</a> if you require assistance.<br /><br /><div style=\"text-align:center\"><b>If you are over the age of 13 please click <a href=\"signup.php?stage1\">here</a> to continue the registration process.");
define(LAN_110, "Pendaftaran ahli");
define(LAN_111, "Ulang kata laluan: ");
define(LAN_112, "Alamat e-mail: ");
define(LAN_113, "Sembunyi alamat e-mail?: ");
define(LAN_114, "(This will prevent your email address from being displayed)");
define(LAN_115, "ICQ Number: ");
define(LAN_116, "AIM Nickname: ");
define(LAN_117, "MSN Nickname: ");
define(LAN_118, "HariLahir: ");
define(LAN_119, "Tempat: ");
define(LAN_120, "Tandatangan: ");
define(LAN_121, "Gambar: ");
define(LAN_122, "Timezone:");
define(LAN_123, "Daftar Sebagai Ahli");

//stats.php
define(LAN_124, "Jumlah laman tertentu dipapar: ");
define(LAN_125, "Jumlah laman dipaparkan: ");
define(LAN_126, "Paparan mengikut muka laman: ");
define(LAN_127, "Jumlah paparan mengikut laman: ");
define(LAN_128, "Browser: ");
define(LAN_129, "Operating system: ");
define(LAN_130, "Negara/Domains visited from: ");
define(LAN_131, "Referers: ");
define(LAN_132, "Statistik Laman");

//submitnews.php
define(LAN_133, "Terima Kasih");
define(LAN_134, "Kiriman anda telah dihantar dan akan dilihat oleh pengendali laman sebelum dipaparkan.");
define(LAN_135, "Isi Berita : ");
define(LAN_136, "Hantar Berita ");

//user.php
define(LAN_137, "Tiada maklumat berkenaan ahli tersebut atau belum didaftarkan lagi");
define(LAN_138, "Ahli berdaftar: ");
define(LAN_139, "Susun: ");
define(LAN_140, "Ahli berdaftar");
define(LAN_141, "Tiada ahli berdaftar lagi.");
define(LAN_142, "Ahli");
define(LAN_143, "[Disembunyikan atas permintaan]");
define(LAN_144, "Alamat laman web: ");
define(LAN_145, "Daftar:");
define(LAN_146, "Melawat laman sejak mendaftar: ");
define(LAN_147, "Borak Online posts: ");
define(LAN_148, "Kirim Komen: ");
define(LAN_149, "Forum posts: ");

//usersettings.php
define(LAN_150, "Settings dikemaskini.");
define(LAN_151, "OK, terima kasih");
define(LAN_152, "Kata laluan baru: ");
define(LAN_153, "Ulang kata laluan baru: ");
define(LAN_154, "Kemaskini Settings");
define(LAN_155, "Kemaskini Settings ahli");
define(LAN_185, "Anda tidak mengisi kata laluan,");

//plugins
define(LAN_156, "Hantar");
define(LAN_157, "Padam");
define(LAN_158, "Tiada mesej lagi.");
define(LAN_159, "Papar semua kiriman");
define(LAN_160, "Webmaster: ");
define(LAN_161, "Headlines");
define(LAN_162, "Tiada Undian aktif.");
define(LAN_163, "Hantar Undian");
define(LAN_164, "Undi: ");
define(LAN_165, "Undian lama");

//menus
define(LAN_166, "Tiada artikel lagi.");
define(LAN_167, "Jurnal eYtO");
define(LAN_168, "Our headlines can be syndicated by using either our rss or text feeds.");
define(LAN_169, "Backend");
define(LAN_170, "W3C Compliance");
define(LAN_171, "Ahli tidak dikenalpasti (possible corrupted cookie).<br />Sila <a href=\"index.php?logout\">Klik di sini</a> untuk membuang cookie.");
define(LAN_172, "Keluar");
define(LAN_173, "Login Error");
define(LAN_174, "Daftar");
define(LAN_175, "Masuk");
define(LAN_176, "Online kat page ni: ");
define(LAN_177, "Online kat laman ni: ");
define(LAN_178, "Ahli berdaftar: ");
define(LAN_179, "Online");
define(LAN_180, "Carian");
define(LAN_181, "Promosikan eYtO");
define(LAN_182, "Borak Online");
define(LAN_183, "Menu Utama");
define(LAN_184, "Undian");

// #### Added in v5 #### //

define(LAN_186, "Hantar Berita");
define(LAN_187, "Alamat e-mail kengkawan");
define(LAN_188, "Wei!!! korang baca le berita kat laman web ni...Nah! alamatnye..");
define(LAN_189, "Powered by");
define(LAN_190, "Reviews");
define(LAN_191, "Maklumat");
define(LAN_192, "Jumlah kiriman telah dikirim oleh ahli ialah ");
define(LAN_193, "Pengendali Forum ");
define(LAN_194, "Tetamu");
define(LAN_195, "Ahli berdaftar");
define(LAN_196, "Anda telah baca ");
define(LAN_197, " kiriman ini.");
define(LAN_198, " Semua kiriman telah anda baca.");
define(LAN_199, "Tandakan kiriman yang telah dibaca");
define(LAN_200, "tutup topik ini");
define(LAN_201, "Buka semula topik ini");
define(LAN_202, "Topik penting");
define(LAN_203, "Penting/tutup topik");
define(LAN_204, "Anda <b>boleh</b> mulakan topik baru");
define(LAN_205, "Anda <b>tidak boleh</b> mulakan topik baru");
define(LAN_206, "Anda <b>boleh</b> kirim balasan");
define(LAN_207, "Anda <b>tidak boleh</b> kirim balasan");
define(LAN_208, "Anda <b>boleh</b> ubah kiriman anda");
define(LAN_209, "Anda <b>tidak boleh</b> ubah kiriman anda");
define(LAN_210, "Anda <b>boleh</b> buang kiriman anda");
define(LAN_211, "Anda <b>tidak boleh</b> buang kiriman anda");
define(LAN_212, "Lupa kata laluan?");
define(LAN_213, "username/alamat e-mail tiada dalam pangkalan data.");
define(LAN_214, "tidak boleh ubah kata laluan");
define(LAN_215, "Kata laluan anda untuk laman ".SITENAME." telah diubah. Kata laluan baru anda ialah\n\n");
define(LAN_216, "Untuk mengaktifkan kata lauan anda, sila klik url ...");
define(LAN_217, "terima kasih, kata laluan anda telah dikemaskini. Anda boleh masuk dengan kata laluan baru .");


?>