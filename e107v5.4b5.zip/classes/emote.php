<?php
function r_emote(){
$emote = "<a href=\"javascript:addtext(' :)')\"><img src=\"themes/shared/emoticons/smile.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :(')\"><img src=\"themes/shared/emoticons/frown.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :D')\"><img src=\"themes/shared/emoticons/grin.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :?')\"><img src=\"themes/shared/emoticons/confused.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :((')\"><img src=\"themes/shared/emoticons/cry.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' %-6')\"><img src=\"themes/shared/emoticons/special.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' X)')\"><img src=\"themes/shared/emoticons/dead.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :@')\"><img src=\"themes/shared/emoticons/gah.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' ~:\(')\"><img src=\"themes/shared/emoticons/mad.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :!')\"><img src=\"themes/shared/emoticons/idea.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :|')\"><img src=\"themes/shared/emoticons/neutral.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' ?!')\"><img src=\"themes/shared/emoticons/question.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' B)')\"><img src=\"themes/shared/emoticons/rolleyes.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' 8)')\"><img src=\"themes/shared/emoticons/shades.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :O')\"><img src=\"themes/shared/emoticons/suprised.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' :P')\"><img src=\"themes/shared/emoticons/tongue.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' ;)')\"><img src=\"themes/shared/emoticons/wink.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' !ill')\"><img src=\"themes/shared/emoticons/ill.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' !amazed')\"><img src=\"themes/shared/emoticons/amazed.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' !cry')\"><img src=\"themes/shared/emoticons/cry.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' !dodge')\"><img src=\"themes/shared/emoticons/dodge.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' !alien')\"><img src=\"themes/shared/emoticons/alien.png\" style=\"border:0\" alt=\"\" />
<a href=\"javascript:addtext(' !heart')\"><img src=\"themes/shared/emoticons/heart.png\" style=\"border:0\" alt=\"\" />";
return $emote;
}
?>