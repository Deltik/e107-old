<?php
/*
 * Copyright (C) 2008-2013 e107 Inc (e107.org), Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
 *
 * Admin Language File
 *
*/

define("MESSLAN_1", "Received messages");
define("MESSLAN_2", "Delete Message");
define("MESSLAN_3", "Message Deleted.");
define("MESSLAN_4", "Delete All Messages");
define("MESSLAN_5", "Confirm");
define("MESSLAN_6", "All messages deleted.");
define("MESSLAN_7", "No messages.");
define("MESSLAN_8", "Message type");
define("MESSLAN_9", "Reported on");

define("MESSLAN_10", "Submitted by");
define("MESSLAN_11", "opens in new window");
define("MESSLAN_12", "Message");
define("MESSLAN_13", "Link");

?>