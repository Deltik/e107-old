<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_modcomment.php $
|     $Revision: 12892 $
|     $Id: lan_modcomment.php 12892 2012-07-21 03:20:42Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderated.");
define("MDCLAN_2", "No comments for this item");
define("MDCLAN_3", "Member");
define("MDCLAN_4", "Guest");
define("MDCLAN_5", "unblock");
define("MDCLAN_6", "block");

define("MDCLAN_7", "approve");
define("MDCLAN_8", "Moderate Comments");
define("MDCLAN_9", "Warning! Deleting Parent comments will also delete all replies!");

define("MDCLAN_10", "options");
define("MDCLAN_11", "comment");
define("MDCLAN_12", "comments");
define("MDCLAN_13", "blocked");
define("MDCLAN_14", "lock comments");
define("MDCLAN_15", "open");
define("MDCLAN_16", "locked");
define("MDCLAN_17", "There are no comments pending approval at this time");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>