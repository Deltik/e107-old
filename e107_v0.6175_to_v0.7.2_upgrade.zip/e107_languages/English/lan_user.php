<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/04/06 03:53:00 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Members");

define("LAN_20", "Error");
define("LAN_112", "Email Address");
define("LAN_115", "ICQ Number");
define("LAN_116", "AIM Address");
define("LAN_117", "MSN Messenger");
define("LAN_118", "Birthday");
define("LAN_119", "Location");
define("LAN_120", "Signature");
define("LAN_137", "There is no information for that user as they are not registered at");
define("LAN_138", "Registered members: ");
define("LAN_139", "Order: ");
define("LAN_140", "Registered members");
define("LAN_141", "No registered members yet.");
define("LAN_142", "Member");
define("LAN_143", "[hidden by request]");
define("LAN_144", "Website URL");
define("LAN_145", "Joined");
define("LAN_146", "Visits to site since registration");
define("LAN_147", "Chatbox posts");
define("LAN_148", "Comments posted");
define("LAN_149", "Forum posts");
define("LAN_308", "Real Name");
define("LAN_400", "That is not a valid user.");
define("LAN_401", "no information");
define("LAN_402", "Member Profile");
define("LAN_403", "Site Stats");
define("LAN_404", "Last visit");
define("LAN_405", "days ago");
define("LAN_406", "Rating");
define("LAN_407", "none");
define("LAN_408", "no photo");
define("LAN_409", "points");
define("LAN_410", "Miscellaneous");
define("LAN_411", "Click here to update your information");
define("LAN_412", "Click here to edit this user's information");
define("LAN_413", "delete photo");
define("LAN_414", "previous member");
define("LAN_415", "next member");
define("LAN_416", "You must be logged in to access this page");
define("LAN_417", "Main site administrator");
define("LAN_418", "Site administrator");
define("LAN_419", "Show");
define("LAN_420", "DESC");
define("LAN_421", "ASC");
define("LAN_422", "Go");
define("LAN_423", "Click here to View User Comments");
define("LAN_424", "Click here to View Forum Posts");
define("LAN_425", "Send Private Message");
define("LAN_426", "ago");

define("USERLAN_1", "Peer Rating");

?>