/**
 * ES lang variables
 * 
 * Authors : Alvaro Velasco,
 *           Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>,
 *           Carlos C Soto (eclipxe) <csoto@sia-solutions.com>
 * Last Updated : October 17, 2005
 * TinyMCE Version : 2.0RC3
 */

tinyMCE.addToLang('',{
iespell_desc : 'Ejecutar corrector ortogr�fico',
iespell_download : "Corrector ortogr�fico no detectado. Pulse OK para ir a la p�gina de descarga."
});

