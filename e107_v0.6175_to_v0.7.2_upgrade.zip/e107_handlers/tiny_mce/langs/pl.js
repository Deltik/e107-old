// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 26.10.2005

tinyMCE.addToLang('',{
bold_desc : 'Pogrubienie (Ctrl+B)',
italic_desc : 'Pochylenie (Ctrl+I)',
underline_desc : 'Podkre�lenie (Ctrl+U)',
striketrough_desc : 'Przekre�lenie',
justifyleft_desc : 'Wyr�wnaj do lewej',
justifycenter_desc : 'Wyr�wnaj do �rodka',
justifyright_desc : 'Wyr�wnaj do prawej',
justifyfull_desc : 'Wyr�wnaj na ca�o�ci',
bullist_desc : 'Lista nienumerowana',
numlist_desc : 'Lista numerowana',
outdent_desc : 'Zmniejsz wci�cie',
indent_desc : 'Zwi�ksz wci�cie',
undo_desc : 'Cofnij (Ctrl+Z)',
redo_desc : 'Pon�w (Ctrl+Y)',
link_desc : 'Wstaw/edytuj link',
unlink_desc : 'Usu� link',
image_desc : 'Wstaw/edytuj obrazek',
cleanup_desc : 'Usu� zb�dny kod',
focus_alert : 'Instancja edytora musi by� aktywna przed u�yciem tego polecenia.',
edit_confirm : 'Czy chcesz u�y� edytora WYSIWYG dla tego pola tekstowego?',
insert_link_title : 'Wstaw/edytuj link',
insert : 'Wstaw',
update : 'Aktualizuj',
cancel : 'Anuluj',
insert_link_url : 'URL linku',
insert_link_target : 'Cel',
insert_link_target_same : 'Otw�rz link w tym samym oknie',
insert_link_target_blank : 'Otw�rz link w nowym oknie',
insert_image_title : 'Wstaw/edytuj obrazek',
insert_image_src : 'URL obrazka',
insert_image_alt : 'Opis obrazka',
help_desc : 'Pomoc',
bold_img : "bold.gif",
italic_img : "italic.gif",
underline_img : "underline.gif",
clipboard_msg : 'Kopiuj/Wytnij/Wklej nie jest dost�pne dla przegl�darek Mozilla i Firefox.\nCzy chcesz uzyska� o tym wi�cej informacji?',
popup_blocked : 'Niestety, ale odnotowano, �e Twoja przegl�darka ma w��czon� blokad� okienek popup. Musisz wy��czy� opcj� blokowania okienek dla tej strony, aby TinyMCE m�g� pracowa� z pe�n� funkcjonalno�ci�.'
});
