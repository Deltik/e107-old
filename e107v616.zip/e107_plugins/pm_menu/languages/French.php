<?php

// translation by Lolo Irie, http://www.touchatou.com

define(PMLAN_PM,"Messagerie");
define(PMLAN_0, "Nouveau(x) Message(s)");
define(PMLAN_1, "message(s) re�us(s)");
define(PMLAN_2, "message(s) envoy�(s)");
define(PMLAN_3, "utilisateur bloqu�");
define(PMLAN_4, "utilisateurs bloqu�s");
define(PMLAN_5, "Envoyer un nouveau message");
define(PMLAN_6, "Voir");
define(PMLAN_7, "Pas autoris�");
define(PMLAN_8, "Vous devez �tre enregistr�/connect� pour utiliser le syst�me de messagerie.");
define(PMLAN_9, "Envoyer un message");
define(PMLAN_10, "Erreur !!!");
define(PMLAN_11, "Poster Message");
define(PMLAN_12, "UTILISATEUR");
define(PMLAN_13, "n'existe pas");
define(PMLAN_14, "Message effac�");
define(PMLAN_15, "Message envoy� avec succ�s � ");
define(PMLAN_16, "Vous n'�tes pas autoris� actuellement � utiliser la messagerie ");
define(PMLAN_17, "Cet utilisateur a bloqu� vos messages.");
define(PMLAN_18, "Vous avez bien bloqu� les messages de ");
define(PMLAN_19, " n'est pas autoris� � vous envoyer des messages.");
define(PMLAN_20, "Vous n'�tes pas autoris� � supprimer ce filtre!");
define(PMLAN_21, "Filtre d�j� existant ");
define(PMLAN_22, "Message commenc� le : ");
define(PMLAN_23, " messages ont �t� bloqu�s.");
define(PMLAN_24, "Filtre actif non trouv�.");
define(PMLAN_25, "Messages actuellement bloqu�s");
define(PMLAN_26, "R�pondre au message priv�");
define(PMLAN_27, "Message");
define(PMLAN_28, "Envoyer message");
define(PMLAN_29, "Sujet:");
define(PMLAN_30, "Message:");
define(PMLAN_31, "A");
define(PMLAN_32, "Emotes:");
define(PMLAN_33, "Choisissez le destinataire");
define(PMLAN_34, "Date d'envoi");
define(PMLAN_35, "De");
define(PMLAN_36, "Configuration des filtres");
define(PMLAN_37, "Vous n'�tes pas autoris� � voir ce message");
define(PMLAN_38, "Filtrer les messages");
define(PMLAN_39, "Supprimer un filtre");
define(PMLAN_40, "Effacer");
define(PMLAN_41, "R�pondre");
define(PMLAN_42, "Message original");
define(PMLAN_43, "Message envoy�:");
define(PMLAN_44, "Message lu:");
define(PMLAN_45, "Message(s) non lu(s)");
define(PMLAN_46, "Utilisateur:");
define(PMLAN_47, "Classe Utilisateur:");
define(PMLAN_48, "Tous les Utilisateurs");
define(PMLAN_49, "Non lu");
define(PMLAN_50, "Vous avez re�u un nouveau PM");
define(PMLAN_51, "Site");
define(PMLAN_52,"SVP cochez  la case pour confirmer l'operation");

?>