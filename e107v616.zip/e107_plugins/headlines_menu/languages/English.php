<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NFMENU_160", "Webmaster: ");
define("NFMENU_161", "News Headlines");
define("NFMENU_162", "Last updated");

define("NFMENU_163", "Unable to open ");
define("NFMENU_164", "Your server does not allow outside URL's to be opened using fopen(), contact your site administrator");
define("NFMENU_165", "[more]");
define("NFMENU_166", "Details");

?>