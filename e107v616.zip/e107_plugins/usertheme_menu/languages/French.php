<?
// French - user-theme. 
define(LAN_350, "Choix Th&egrave;me");
define(LAN_351, "S&eacute;lection Th&egrave;me");

?>