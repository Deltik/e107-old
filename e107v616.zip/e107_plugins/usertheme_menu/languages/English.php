<?php

define("LAN_350", "Set Theme");
define("LAN_351", "Select Theme");

?>