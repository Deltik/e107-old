<?php

define("LAN_GUEST", "Guest"); 

?>