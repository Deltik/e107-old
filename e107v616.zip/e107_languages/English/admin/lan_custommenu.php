<?php

define("CUSLAN_1", "Fields left blank.");
define("CUSLAN_2", "Unable to create custom menu - please ensure your ");
define("CUSLAN_3", "custom directory is CHMODDed to 777.");
define("CUSLAN_4", "Custom menu updated.");
define("CUSLAN_5", "Custom menu successfully created. To activate go to your menus screen.");
define("CUSLAN_6", "Unable to open menu");
define("CUSLAN_7", "for reading");
define("CUSLAN_8", "Existing Menus");
define("CUSLAN_9", "Edit");
define("CUSLAN_10", "None");
define("CUSLAN_11", "Menu Filename");
define("CUSLAN_12", "Menu Caption Title");
define("CUSLAN_13", "Menu Text");
define("CUSLAN_14", "Preview Again");
define("CUSLAN_15", "Preview");
define("CUSLAN_16", "Update Custom Menu");
define("CUSLAN_17", "Create Custom Menu");
define("CUSLAN_18", "Custom Menus");
?>