<?php

define("MENLAN_1", "Visible to all");
define("MENLAN_2", "Visible to members only");
define("MENLAN_3", "Visible to administrators only");
define("MENLAN_4", "Only visible to users in");
define("MENLAN_5", "class");
define("MENLAN_6", "Update Menu Class");
define("MENLAN_7", "Set class for");
define("MENLAN_8", "Class updated");
define("MENLAN_9", "New custom menu installed");
define("MENLAN_10", "New menu installed");
define("MENLAN_11", "Menu removed");
define("MENLAN_12", "Activate this menu - please choose location");
define("MENLAN_13", "Activate in Area");
define("MENLAN_14", "Area");
define("MENLAN_15", "Deactivate");
define("MENLAN_16", "Configure");
define("MENLAN_17", "Move Up");
define("MENLAN_18", "Move Down");
define("MENLAN_19", "Move to Area");
define("MENLAN_20", "Visibility");

define("MENLAN_21", "Visible to Guests only");
define("MENLAN_22", "Inactive Menus");

?>