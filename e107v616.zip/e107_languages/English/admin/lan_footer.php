<?php

define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Head Admin");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Theme");
define("FOOTLAN_6", "by");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Install date");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP Version");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Site Info");
define("FOOTLAN_14", "Show Docs");
define("FOOTLAN_15", "Documentation");
define("FOOTLAN_16", "Database");

?>