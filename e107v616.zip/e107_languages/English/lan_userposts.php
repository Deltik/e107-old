<?php

define("PAGE_NAME", "User Posts"); 

define("UP_LAN_0", "All Forum Posts for ");
define("UP_LAN_1", "All Comments for ");
define("UP_LAN_2", "Thread");
define("UP_LAN_3", "Views");
define("UP_LAN_4", "Replies");
define("UP_LAN_5", "Lastpost");
define("UP_LAN_6", "Threads");
define("UP_LAN_7", "No Comments");
define("UP_LAN_8", "No Posts");
define("UP_LAN_9", " on ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Posted on: ");
define("UP_LAN_12", "Search");
?>