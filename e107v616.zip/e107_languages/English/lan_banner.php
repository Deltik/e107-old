<?php

define("PAGE_NAME", "Banner"); 

define("LAN_16", "Username: ");
define("LAN_17", "Password: ");
define("LAN_18", "Continue");
define("LAN_19", "Please enter your client login and password to continue");
define("LAN_20", "Sorry, unable to find those details in the database. Please contact the site administrator for details.");
define("LAN_21", "Banners Statistics");
define("LAN_22", "Client");
define("LAN_23", "Banner ID");
define("LAN_24", "Clickthroughs");
define("LAN_25", "Click %");
define("LAN_26", "Impressions");
define("LAN_27", "Impressions Purchased");
define("LAN_28", "Impressions Left");
define("LAN_29", "No banners");
define("LAN_30", "Unlimited");
define("LAN_31", "Not applicable");
define("LAN_32", "Yes");
define("LAN_33", "No");
define("LAN_34", "Ends");
define("LAN_35", "Clickthrough IP addresses");
define("LAN_36", "Active:");
define("LAN_37", "Starts:");

?>