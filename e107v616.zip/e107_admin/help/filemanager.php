<?php
$text = "You are able to manage the files in your /files directory from this page. If you are getting error message about permissions when uploading please CHMOD the directory you are atempting to upload into to 777.";
$ns -> tablerender("File Manager Help", $text);
?>