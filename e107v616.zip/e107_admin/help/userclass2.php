<?php
$caption = "Use Class Help";
$text = "You can create or edit/delete existing classes from this page.<br />This is useful for restricting users to certain parts of your site. For example, you could create a class called TEST, then create a forum which only allowed users in the TEST class to access it.";
$ns -> tablerender($caption, $text);
?>