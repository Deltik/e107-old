<?php
$text = "This page allows you to moderate your registered members. You can update their settings, give them administrator status and set their user class among other things.";
$ns -> tablerender("Users Help", $text);
unset($text);
?>