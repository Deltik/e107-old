<?php
$caption = "Site Admin Help";
$text = "Use this page to enter new, or delete site administrators. The administrator will only have permission to access the features that are ticked.";
$ns -> tablerender($caption, $text);
?>