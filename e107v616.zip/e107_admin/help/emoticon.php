<?php

$text = "Tick the box to have text emoticons replaced by image emoticons.<br /><br />
Type any updates you require in the textboxes, and click update to save your settings. Use the form at the foot of the page to add new emotes.";

$ns -> tablerender("Emoticon Help", $text);
?>