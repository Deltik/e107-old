<?php
$caption = "Newspost Help";
$text = "<b>General</b><br />
Body will be displayed on the main page, extended will be readable by clicking a 'Read More' link.
<br />
<br />
<b>Show title only</b>
<br />
Enable this to show the news title only on front page, with clickable link to full story.
<br /><br />
<b>Activation</b>
<br />
If you set a start and/or end date your news item will only be displayed between these dates.
";
$ns -> tablerender($caption, $text);
?>