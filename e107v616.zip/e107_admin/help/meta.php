<?php
$text = "Any meta tags you enter here will be sent to screen in the right place.";

$ns -> tablerender("Meta Tags", $text);
?>