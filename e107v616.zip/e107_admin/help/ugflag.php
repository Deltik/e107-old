<?php
$text = "If you are upgrading e107 or just need your site to be offline for a while just tick the maintainance box and your visitors will be redirected to a page explaining the site is down for repair. After you've finished untick the box to return site to normal.";

$ns -> tablerender("Maintainance", $text);
?>