<?php
$text .= wad("log_conf.php", "Logger", "Log visitor statistics/page counts etc", "P");
?>