<?php
echo "<a href=\"http://e107.org\"><img src=".e_HTTP."themes/shared/banners/bannerimages/e107.jpg\" style=\"border:0\" alt=\"\" height=\"60\" width=\"468\" /></a>";
?>