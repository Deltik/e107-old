<?php
$text = "<div style=\"text-align:center\" class=\"smalltext\">
".LAN_168."<br />
<a href=\"".e_HTTP."backend/news.xml\">news.xml</a> - <a href=\"".e_HTTP."backend/news.txt\">news.txt</a>
</div>";
$ns -> tablerender(LAN_169, $text);
?>