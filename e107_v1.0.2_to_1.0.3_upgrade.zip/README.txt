1.0.2 -> 2.0.2 Upgrade Guide
This is an update from 1.0.2 to 2.0.2 only. If you are upgrading from any other version besides 1.0.2 ,
then you have downloaded the wrong package.  For those users that have been using the current SVN version of e107, from any other version besides 1.0.2 this is the correct version to use.

Included in these releases are security related file changes and so you must upgrade your site with all these files.

To install, simply upload the files to your server overwriting the existing 1.0.2 files.
There are no database changes in this release.