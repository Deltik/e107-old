<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2017 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 */

define("LAN_PLUGIN_USER_NAME", "User");
define("LAN_PLUGIN_USER_DESC", "User Theme and Language Menus");

?>