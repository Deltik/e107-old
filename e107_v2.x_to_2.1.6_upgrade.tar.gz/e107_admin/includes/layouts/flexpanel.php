<?php

/**
 * @file
 * Layouts for "flexpanel" dashboard style.
 */

$ONECOL_12 = '
<div class="row">
	<div class="col-sm-12">
		<div class="draggable-panels" id="menu-area-01">
			{MENU_AREA_01}
		</div>
		
		<div class="draggable-panels" id="menu-area-02">
			{MENU_AREA_02}
		</div>
		
		<div class="draggable-panels" id="menu-area-03">
			{MENU_AREA_03}
		</div>
		
		<div class="draggable-panels" id="menu-area-04">
			{MENU_AREA_04}
		</div>
		
		<div class="draggable-panels" id="menu-area-05">
			{MENU_AREA_05}
		</div>
		
		<div class="draggable-panels" id="menu-area-06">
			{MENU_AREA_06}
		</div>
		
		<div class="draggable-panels" id="menu-area-07">
			{MENU_AREA_07}
		</div>
		
		<div class="draggable-panels" id="menu-area-08">
			{MENU_AREA_08}
		</div>
		
		<div class="draggable-panels" id="menu-area-09">
			{MENU_AREA_09}
		</div>
		
		<div class="draggable-panels" id="menu-area-10">
			{MENU_AREA_10}
		</div>
		
		<div class="draggable-panels" id="menu-area-11">
			{MENU_AREA_11}
		</div>
	</div>
</div>
';
