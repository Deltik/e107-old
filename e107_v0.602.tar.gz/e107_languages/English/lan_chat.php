<?php

define("PAGE_NAME", "Chatbox"); 

define("LAN_11", "Chatbox (all posts)");
define("LAN_12", "Chat Posts");

?>