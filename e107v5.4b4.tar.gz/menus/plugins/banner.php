<?php
$text .= wad("banner.php", "Banners", "Configure banners", "P");
?>