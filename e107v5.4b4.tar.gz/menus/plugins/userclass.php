<?php
$text .= wad("userclass2.php", "User Classes", "Create/edit user classes", "4");
?>