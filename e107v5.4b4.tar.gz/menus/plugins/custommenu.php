<?php
$text .= wad("custommenu.php", "Custom Menus", "Create custom menu items", "P");
?>