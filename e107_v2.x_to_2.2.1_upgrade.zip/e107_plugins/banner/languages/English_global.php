<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2016 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 */
 
define("LAN_PLUGIN_BANNER_NAME",		"Banners");
define("LAN_PLUGIN_BANNER_DESCRIPTION", "Add advertising banners to your e107 website");

?>