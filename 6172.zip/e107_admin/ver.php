<?php

$e107info['e107_version'] = "v0.6172 (fixed)";
$e107info['e107_build'] = "20050815";

?>