<?php
if (!defined('e107_INIT')) { exit; }
include_once(e_HANDLER.'shortcode_handler.php');
$list_shortcodes = $tp -> e_sc -> parse_scbatch(__FILE__);
/*
SC_BEGIN LIST_DATE
global $LIST_DATE;
return $LIST_DATE;
SC_END

SC_BEGIN LIST_ICON
global $LIST_ICON;
return $LIST_ICON;
SC_END

SC_BEGIN LIST_HEADING
global $LIST_HEADING;
return $LIST_HEADING;
SC_END

SC_BEGIN LIST_AUTHOR
global $LIST_AUTHOR;
return $LIST_AUTHOR;
SC_END

SC_BEGIN LIST_CATEGORY
global $LIST_CATEGORY;
return $LIST_CATEGORY;
SC_END

SC_BEGIN LIST_INFO
global $LIST_INFO;
return $LIST_INFO;
SC_END


SC_BEGIN LIST_RECENT_ID
global $LIST_RECENT_ID;
return $LIST_RECENT_ID;
SC_END

*/
?>