<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/newsfeed/languages/English_frontpage.php $
|     $Revision: 11678 $
|     $Id: English_frontpage.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "News Feeds");
define("NWSF_FP_2", "main page");

?>