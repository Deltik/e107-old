<?php
/*
+---------------------------------------------------------------+
|        e107 website system                                                                                                        |
|        language file: polish                                                                                                        |
|           wlodzimierz.szymanowski@wp.pl                                                                                                                                                                     |
|        �Steve Dunstan 2001-2002                                                                                |
|        http://jalist.com                                                                                                                        |
|        stevedunstan@jalist.com                                                                                        |
|                                                                                                                                                                                |
|        Released under the terms and conditions of the                |
|        GNU General Public License (http://gnu.org).                                |
+---------------------------------------------------------------+
*/

setlocale(LC_ALL, 'en');


//articles.php/comment.php
define("LAN_0", "[zablokowane przed admina]");
define("LAN_1", "Odblokowa�");
define("LAN_2", "Zablokowa�");
define("LAN_3", "Usun��");
define("LAN_4", "Info");
define("LAN_5", "Komentarze ...");
define("LAN_6", "Musisz by� zalogowany by wys�a� komentarz - zaloguj si� lub je�li nie jeste� u�ytkownikiem kliknij <a href=\"signup.php\">tutaj</a> by nim zosta�");
define("LAN_7", "Nazwa u�ytkownika: ");
define("LAN_8", "Komentarz");
define("LAN_9", "Dostarcz komentarz");
define("LAN_10", "Tagi dozwolone: [b] [i] [u] [img] [center] [link]<br />u�yj [link=link text] link url [/link] dla link�w<br />Prze�amanie linii (&lt;br /&gt;) jest nieaktywne.");

//chat.php
define("LAN_11", "Chatbox (wszystkie posty)");
define("LAN_12", "Chat Posty");

//class.php
define("LAN_13", "News usuni�ty.");
define("LAN_14", "News zmieniony w bazie.");
define("LAN_15", "News wprowadzony do bazy.");
define("LAN_16", "Uzytkownik: ");
define("LAN_17", "Has�o: ");
define("LAN_18", "Zaloguj si�");
define("LAN_19", "Nie mo�na zapisa� pliku news.xml na serwerze, upewnij si� �e katalog /backend ma zezwolenie (666)");
define("LAN_20", "B��d");
define("LAN_21", "Ca�kowita ilo�� wizyt dzisiaj: ");
define("LAN_22", "Ca�kowita ilo�� wizyt: ");
define("LAN_23", "Total site views: ");
define("LAN_24", "fuck|piss|shit|cunt|cock|asshole|motherfucker|mother fucker| arse|pussy|faggot");
define("LAN_25", "Poprzednia");
define("LAN_26", "Nast�pna");

//forum.php
define("LAN_27", "Pozostawi�e� puste pola");
define("LAN_28", "Nic nie wys�a�e� ..");
define("LAN_29", "Edytowane");
define("LAN_30", "Witaj");
define("LAN_31", "Nie ma nowych post�w ");
define("LAN_32", "Jest 1 nowy post ");
define("LAN_33", "Jest");
define("LAN_34", "nowych post�w");
define("LAN_35", "od ostatniej twojej wizyty.");
define("LAN_36", "Twoja ostatnia wizyta ");
define("LAN_37", "Teraz jest ");
define("LAN_38", ", wszystkie czasy s� GMT");
define("LAN_39", "ilo�� temat�w");
define("LAN_40", "ilo�� post�w.");
define("LAN_41", "Najnowszy cz�onek: ");
define("LAN_42", "Zarejestrowanych u�ytkownik�w: ");
define("LAN_43", "To forum jest dost�pne dla wszystkich u�ytkownik�w i go�ci, ale je�li chcesz zobaczy� info odnosz�ce si� do nowych post�w, edytowa� lub usuwa� twoje posty etc musisz si� <a href=\"signup.php\">zarejestrowa�</a> i zalogowa�.");
define("LAN_44", "To forum jest dost�pne dla wszystkich u�ytkownik�w i go�ci, adresy ip i hosty b�d� zapami�tane.");
define("LAN_45", "To forum jest dost�pne tylko dla zarejestrowanych i zalogowanych u�ytkownik�w, kliknij <a href=\"signup.php\">tutaj</a> by przenie�� si� do strony rejestracji.");
define("LAN_46", "Forum");
define("LAN_47", "W�tki");
define("LAN_48", "Odpowiedzi");
define("LAN_49", "Ostatni Post");
define("LAN_50", "Moderatorzy");
define("LAN_51", "No forums yet, please check back soon.");
define("LAN_52", "Nie ma na razie �adnego forum, sprawd� za jaki� czas powt�rne.");
define("LAN_53", "W�tek");
define("LAN_54", "Starter");
define("LAN_55", "Odpowiedzi");
define("LAN_56", "Podgl�dy");
define("LAN_57", "Ostatnia poczta");
define("LAN_58", "Na razie nie ma temat�w w tym forum.");
define("LAN_59", "Musisz by� zarejestrowanym i zalogowanym u�ytkownikiem by wys�a� posta na to forum. Kliknij <a href=\"signup.php\">tutaj</a> by zarejestrowa� si� lub zalogowa�.");
define("LAN_60", "Rozpocznij nowy w�tek");
define("LAN_61", "Twoja nazwa: ");
define("LAN_62", "Temat: ");
define("LAN_63", "Post: ");
define("LAN_64", "Dostarcz nowy w�tek");
define("LAN_65", "Admin detected - moderation switched on");
define("LAN_66", "Ten w�tek jest zamkni�ty");
define("LAN_67", "posty");
define("LAN_68", "edycja");
define("LAN_69", "usu�");
define("LAN_70", "przenie�");
define("LAN_71", "Brak odpowiedzi.");
define("LAN_72", "Oryginalnie wys�ane przez");
define("LAN_73", "Odpowiedz: ");
define("LAN_74", "Odpowied� na w�tek");
define("LAN_75", "Odpowied� na posta");
define("LAN_76", "Odpowiedz:");
define("LAN_77", "Zmie� w�tek");
define("LAN_78", "Zmie� odpowied�");
define("LAN_79", "Nowe posty");
define("LAN_80", " Brak nowych post�w");
define("LAN_81", "W�tek zamkni�ty");

//index.php
define("LAN_82", "News - Kategoria");
define("LAN_83", "Nie ma �adnych news�w sprawd� jeszcze raz za jaki� czas.");
define("LAN_84", "Newsy");

//links.php
define("LAN_85", "Nie ma na razie �adnych link�w.");
define("LAN_86", "Kategoria:");
define("LAN_87", "Przycisk");
define("LAN_88", "Przegl�dane:");
define("LAN_89", "Admin: ");
define("LAN_90", "dodaj nowego linka w tej kategorii");
define("LAN_91", "dodaj now� kategori�");

//oldpolls.php
define("LAN_92", "Stare ankiety");
define("LAN_93", "Na razie nie ma starych ankiet.");
define("LAN_94", "Wys�ane przez:");
define("LAN_95", "Ilo�� g�os�w:");
define("LAN_96", "Ankiety");

//search.php
define("LAN_97", "Nie znaleziono.");
define("LAN_98", "Newsy");
define("LAN_99", "Komentarze");
define("LAN_100", "Artyku�y");
define("LAN_101", "Chatbox");
define("LAN_102", "Linki");
define("LAN_103", "Forum");

//signup.php
define("LAN_104", "Ten u�ytkownik ju� istnieje w bazie danych, wybierz inn� nazw�.");
define("LAN_105", "Oba has�a s� r�ne, wprowad� je jeszcze raz.");
define("LAN_106", "Wygl�da na to �e jest to z�y adres e-mailowy, popraw go.");
define("LAN_107", "Dzi�ki! Jeste� teraz zarejestrowanym u�ytkownikiem ".SITENAME.", zapami�taj lub zapisz gdzie� swoj� nazw� i has�o, je�li je utracisz twoje dane nie b�d� mog�y by� odzyskane.<br /><br />Teraz mo�esz si� zalogowa�.");
define("LAN_108", "Rejestracja zako�czona");
define("LAN_109", "To miejsce jest zgodne z The Children's Online Privacy Protection Act of 1998 (COPPA) i nie mo�e zakceptowa� rejestracji od u�tkownik�w poni�ej 13 roku �ycia bez pisemnej zgody rodzic�w lub opiekun�w. Wi�cej nformacji na ten temat mo�na znale�� tutaj <a href=\"http://www.cdt.org/legislation/105th/privacy/coppa.html\">here</a>. Please contact the main site admin <a href=\"mailto:".SITEADMINEMAIL."\">here</a> if you require assistance.<br /><br /><div style=\"text-align:center\"><b>Please certify you are over the age of 13");
define("LAN_110", "Rejestracja");
define("LAN_111", "Powt�rz has�o: ");
define("LAN_112", "Adres email: ");
define("LAN_113", "Ukry� adres e-mail?: ");
define("LAN_114", "(To zapobiegnie wy�wietleniu twojego adresu)");
define("LAN_115", "Numer ICQ: ");
define("LAN_116", "Nazwa AIM: ");
define("LAN_117", "Nazwa MSN: ");
define("LAN_118", "Data urodzenia: ");
define("LAN_119", "Miasto: ");
define("LAN_120", "Podpis: ");
define("LAN_121", "Obraz: ");
define("LAN_122", "Strefa czasowa:");
define("LAN_123", "Zarejestruj");

//stats.php
define("LAN_124", "Total unique site views: ");
define("LAN_125", "Total site views: ");
define("LAN_126", "Unique views by page: ");
define("LAN_127", "Total views by page: ");
define("LAN_128", "Browser: ");
define("LAN_129", "Operating system: ");
define("LAN_130", "Countries/Domains visited from: ");
define("LAN_131", "Referers: ");
define("LAN_132", "Site Statistics");

//submitnews.php
define("LAN_133", "Dzi�ki");
define("LAN_134", "Tw�j news zosta� dostarczony i zostanie przegl�dni�ty przez administrator�w.");
define("LAN_135", "Tekst newsa: ");
define("LAN_136", "Dostarcz newsa");

//user.php
define("LAN_137", "There is no information for that user as they are not registered at");
define("LAN_138", "Zarejestrowani u�ytkownicy: ");
define("LAN_139", "Kolejno��: ");
define("LAN_140", "Zarejestrowani u�ytkownicy");
define("LAN_141", "Na razie nie ma zarejestrowanych u�ytkownik�w.");
define("LAN_142", "Cz�onek");
define("LAN_143", "[ukryte na ��danie]");
define("LAN_144", "URL strony: ");
define("LAN_145", "Zarejestrowany: ");
define("LAN_146", "Wizyty od czasu rejestracji: ");
define("LAN_147", "Post�w na czacie: ");
define("LAN_148", "Wys�anych komentarzy: ");
define("LAN_149", "Post�w na forum: ");

//usersettings.php
define("LAN_150", "Ustawienia zmienione i zapisane w bazie.");
define("LAN_151", "OK");
define("LAN_152", "Nowe has�o: ");
define("LAN_153", "Powt�rz nowe has�o: ");
define("LAN_154", "Zmie� ustawienia");
define("LAN_155", "Zmie� ustawienia u�ytkownika");
define("LAN_185", "Zostawi�e� pole has�a puste,");

//plugins
define("LAN_156", "Dostarcz");
define("LAN_157", "Reset");
define("LAN_158", "Na razie nie ma komunikat�w.");
define("LAN_159", "Zobacz wszystkie posty");
define("LAN_160", "Webmaster: ");
define("LAN_161", "Headlines");
define("LAN_162", "�adna ankieta nie jest aktywna.");
define("LAN_163", "Zag�osuj");
define("LAN_164", "G�osy: ");
define("LAN_165", "Stare ankiety");

//menus
define("LAN_166", "Na razie nie ma �adnych artyku��w.");
define("LAN_167", "Artyku�y");
define("LAN_168", "Our headlines can be syndicated by using either our rss or text feeds.");
define("LAN_169", "Backend");
define("LAN_170", "W3C-zgodno��");
define("LAN_171", "U�ytkownik jest nierospoznany (prawdopodobnie uszkodzone cookie).<br />Prosz� <a href=\"index.php?logout\">klikn�� tytaj</a> by zniszczy� cookie.");
define("LAN_172", "Logout");
define("LAN_173", "B��d loginu");
define("LAN_174", "Zapisz si�");
define("LAN_175", "Login");
define("LAN_176", "Na tej stronie: ");
define("LAN_177", "W sumie: ");
define("LAN_178", "Cz�onk�w: ");
define("LAN_179", "Online");
define("LAN_180", "Szukaj");
define("LAN_181", "Link do nas");
define("LAN_182", "Chatbox");
define("LAN_183", "Menu g��wne");
define("LAN_184", "Ankieta");

// #### Added in v5 #### //

define("LAN_186", "Wy�lij newsa");
define("LAN_187", "Adres e-mail do wys�ania do");
define("LAN_188", "My�l� �e b�dziesz zainteresowany w historii od");
define("LAN_189", "Powered by");
define("LAN_190", "Przegl�dy");
define("LAN_191", "Informacje");
define("LAN_192", "Ca�kowita ilo�� post�w wys�ana przez u�ytkownik�w ");
define("LAN_193", "Moderator forum");
define("LAN_194", "Go��");
define("LAN_195", "Zarejestrowany u�ytkownik");
define("LAN_196", "Przeczyta�e� ");
define("LAN_197", " tych post�w.");
define("LAN_198", " Wszystkie nowe posty zosta�y przeczytane.");
define("LAN_199", "Zaznacz wszystkie posty jako przeczytane");
define("LAN_200", "zamknij ten w�tek");
define("LAN_201", "otw�rz ten w�tek");
define("LAN_202", "�liski w�tek");
define("LAN_203", "�liski/Zamkni�ty w�tek");
define("LAN_204", "<b>Mo�esz</b> rozpocz�� nowy w�tek");
define("LAN_205", "<b>Nie mo�esz</b> rozpocz�� nowego w�tku");
define("LAN_206", "<b>Mo�esz</b> odpowiedzie�");
define("LAN_207", "<b>Nie mo�esz</b> odpowiedzie�");
define("LAN_208", "<b>Mo�esz</b> edytowa� twoje posty");
define("LAN_209", "<b>Nie mo�esz</b> edytowa� twoich post�w");
define("LAN_210", "<b>Mo�esz</b> usun�� twoje posty");
define("LAN_211", "<b>Nie mo�esz</b> usun�� twoich post�w");
define("LAN_212", "Zapomnia�e� has�a?");
define("LAN_213", "Ten u�ytkownik/adres email nie zosta� znaleziony w bazie danych.");
define("LAN_214", "Nie mo�na zresetowa� has�a");
define("LAN_215", "Twoje has�o do ".SITENAME." zosta�o zresetowane. Nowe has�o jest\n\n");
define("LAN_216", "By uruchomi� nowe has�o id� do URL ...");
define("LAN_217", "Dzi�ki, twoje has�o zosta�o potwierdzone. Mo�esz si� teraz zalogowa� przy u�yciu nowego has�a.");

define("LAN_281", "Go�cie: ");

// NEW IN VERSION 5.3b4 - PLEASE UPDATE!

define("LAN_300", "Ta nazwa u�ytkownika nie zosta�a znaleziona w bazie danych.<br /><br />");
define("LAN_301", "Nieprawid�owe has�o.<br /><br />");
define("LAN_302", "Nie aktywowa�e� konta. Powiniene� otrzyma� emaila z instrukcj� co zrobi�, je�li nie to skontaktuj si� z administratorem strony.<br /><br />");
define("LAN_303", "Ten news jest od ");
define("LAN_304", "Tytu� artyku�u: ");
define("LAN_305", "Podtytu�: ");
define("LAN_306", "Ten artyku� jest od ");
define("LAN_307", "Ilo�� post�w w tej kategorii: ");
define("LAN_308", "Rzeczywista nazwa: ");
define("LAN_309", "Wprowad� swoje dane poni�ej - <b>a email sprawdzaj�cy b�dzie wys�any na adres kt�ry  musi by� czynny, </b>je�li nie chcesz wy�wietlania swego adresu na tej stronie zaznacz kratk� ukrywania adresu.");
define("LAN_310", "Nie mo�na zaakceptowa� postu poniewa� ten u�ytkownik jest zarejestrowany - je�li jest to twoja nazwa zaloguj si� i wy�lij post.");
define("LAN_311", "Anonymous");
define("LAN_312", "Duplicate post - unable to accept.");
define("LAN_313", "Please choose which list you wish to display ...");
define("LAN_314", "Klasy: ");
define("LAN_315", "U�ytkownicy: ");
define("LAN_316", "Id� do strony ");
define("LAN_317", "�aden");
define("LAN_318", "Opcje moderatora: ");
define("LAN_319", "Unstick");
define("LAN_320", "Stick");
define("LAN_321", "Moderatorzy: ");
define("LAN_322", "Wys�ane: ");
define("LAN_323", "Podgl�d");
define("LAN_324", "Tw�j komunikat zosta� wys�any.");
define("LAN_325", "Kliknij tutaj by zobaczy� tw�j komunikat");
define("LAN_326", "Kilknij tutaj by wr�ci� do forum");
define("LAN_327", "Przegl�d");
define("LAN_328", "Ustawienia");   // "Settings" as used in default-header.
define("LAN_329", "Auto Login"); // Auto Login

define("LAN_350", "Ustaw temat");
define("LAN_351", "Wybierz temat");

define("LAN_352", "Ustaw j�zyk");
define("LAN_353", "Wybierz j�zyk");


define("LAN_354", "(Ograniczona)");
define("LAN_355", "Na razie nie ma �adnych plik�w do �adowania");
define("LAN_356", "Ca�kowita wielko�� plik�w: ");
define("LAN_357", "Pliki za�adowane: ");
define("LAN_358", "Pliki dost�pne: ");
define("LAN_359", "Oce� ten download");
define("LAN_360", "dzi�ki za ocen�");
define("LAN_361", "za�aduj z");
define("LAN_362", "pliki");
define("LAN_363", "Downloads");
define("LAN_364", "Sortuj wed�ug");
define("LAN_365", "Data");
define("LAN_366", "Wielko�� pliku");
define("LAN_367", "Download");
define("LAN_368", "Nie plik�w do �adowania, sprawd� wkr�tce jeszcze raz");
define("LAN_369", "Jeszcze nie oceniane");
define("LAN_370", "Ocena: ");

define("LAN_371", "Logowanie nie jest aktywne, by aktywowa� id� do sekcji admina, kliknij na Logger i zaznacz Activate Logging/Counter checkbox.");
define("LAN_372", "Ta w�a�ciwo�� na tej stronie zosta�a wy��czona.");
define("LAN_373", "na razie nie ma statystyki.");
define("LAN_374", "Rozpocz�to logowanie:");
define("LAN_375", "Zobacz wszystko");
define("LAN_376", "Ostatnich dziesi�ciu unikalnych go�ci");
define("LAN_377", "wszystko");
define("LAN_378", "top 10");
define("LAN_379", "Rozdzielczo�� ekranu");

define("LAN_380", "Je�li �yczysz sobie by� zawiadomiony e-mailem kiedy przysz�a odpowied� na tw�j w�tek zaznacz pole ");
define("LAN_381", "Odpowied� z forum od ");
define("LAN_382", "Post zrobiony: ");
define("LAN_383", "Klinknij na link by zobaczy� pe�ny w�tek ...");
define("LAN_384", "Odpowiedziano na forumt ");
define("LAN_385", "Post: ");
define("LAN_386", "Je�li nie �yczysz sobie dodawa� ankiety do twojego w�tku zostaw to pole puste ");
define("LAN_387", "Musisz by� zalogowanym cz�onkiem by wzi�� udzia� w g�osowaniu.");
define("LAN_388", "Popularny watek");


define("LAN_389", "Poprzedni w�tek");
define("LAN_390", "Nastepny watek");
define("LAN_391", "�led� ten w�tek");
define("LAN_392", "przesta� �ledzi� ten w�tek");

define("LAN_393", "Lista �ledzonych w�tk�w");
define("LAN_394", "Forum zamkni�te");
define("LAN_395", "[popularne]");
define("LAN_396", "Og�oszenie");
define("LAN_397", "�ledzone w�tki");

define("LAN_398", "Nie ma podsumowania.");


define("LAN_399", "Kontynuuj");
define("LAN_400", "Nazwy i has�a s� czu�e na <b>wielko�� liter</b>");
define("LAN_401", "Zostaw puste by utrzyma� aktualne has�o");

define("LAN_402", "Musisz by� zarejestrowanym u�ytkownikiem by �ci�gn�� pliki do tego serwera.");
define("LAN_403", "Nie masz w�a�ciwych uprawnie� by �ci�gn�� pliki do tego serwera.");
define("LAN_404", "Dzi�ki. Tw�j upload b�dzie przegl�dni�ty przez administratora i umieszczony na stronie je�li b�dzie odpowiedni.");
define("LAN_405", "Wielko�� pliku przekracza g�rn� granic� - skasowany.");
define("LAN_406", "<b>Uwaga</b><br />Dozwolone typy plik�w:");
define("LAN_407", "K�zdy inny typ pliku zostanie skasowany.");
define("LAN_408", "<u>Podkre�lone</u> pola s� wymagane");

define("LAN_409", "Nazwa pliku");
define("LAN_410", "Wersja");
define("LAN_411", "Plik");
define("LAN_412", "Screenshot");
define("LAN_413", "Opis");


define("LAN_414", "Working demo");
define("LAN_415", "wprowad� URL do miejsca gdzie demo mo�e by� ogl�dane");
define("LAN_416", "Submit and Upload");
define("LAN_417", "Upload pliku");
?>