<?php
/*
+---------------------------------------------------------------+
|	e107 website system											|
|	language file: slovak ISO-8859-2										|
|																|
|	translate by jow(IK) and wyrm										|
|	http://e107.po49ta4e.org and http://www.dragonsworld.cz									|
|																|
|	�Steve Dunstan 2001-2002									|
|	http://jalist.com											|
|	stevedunstan@jalist.com										|
|																|
|	Released under the terms and conditions of the				|
|	GNU General Public License (http://gnu.org).				|
+---------------------------------------------------------------+
*/

setlocale(LC_ALL, 'cs_CZ.ISO_8859-2');


//articles.php/comment.php
define(LAN_0, "[zablokovan� adminom]");
define(LAN_1, "Odblokova�");
define(LAN_2, "Zablokova�");
define(LAN_3, "Zmaza�");
define(LAN_4, "Info");
define(LAN_5, "Koment�re ...");
define(LAN_6, "Mus�te by� prihl�sen�, aby ste moholi posiela� koment�re - pros�m prihl�ste sa, pokia� nieste zaregistrovan�, m��ete tak urobi� kliknut�m <a href=\"signup.php\">sem</a>");
define(LAN_7, "Meno: ");
define(LAN_8, "Komet�r");
define(LAN_9, "Posla� koment�r");
define(LAN_10, "Povolen� zkratky miesto html tagov: [b] [i] [u] [img] [center] [link]<br />pou�ite [link=text odkazu] url odkazu [/link] pre odkaz<br />Konce riadkov (&lt;br /&gt;) su prid�van� automaticky.");

//chat.php
define(LAN_11, "Chatbox (v�etky pr�spevky)");
define(LAN_12, "Poslan� pr�spevky");

//class.php
define(LAN_13, "Novinka zmazan�.");
define(LAN_14, "Novinka prep�san� v datab�ze.");
define(LAN_15, "Novinky v datab�ze.");
define(LAN_16, "Meno u��vate�a: ");
define(LAN_17, "Heslo: ");
define(LAN_18, "Pros�m, prihl�ste sa");
define(LAN_19, "Nemo�no zap�sa� s�bor news.xml, pros�m uistite sa, �e /backend directory m� spr�vne zadanie pr�stupu (666)");
define(LAN_20, "Chyba...");
define(LAN_21, "Po�et dne�n�ch n�v�tev: ");
define(LAN_22, "Po�et n�v�tev: ");
define(LAN_23, "Po�et zobrazen�: ");
define(LAN_24, "fuck|piss|shit|cunt|cock|asshole|motherfucker|mother fucker| arse|pussy|faggot");
define(LAN_25, "Predch�dzaj�ca str�nka");
define(LAN_26, "�al�ia str�nka");

//forum.php
define(LAN_27, "Nevyplnili ste potrebn� polo�ky");
define(LAN_28, "Ni� ste neposlali...");
define(LAN_29, "Zmenen�");
define(LAN_30, "Vitajte!");
define(LAN_31, "�iadna nov� po�ta ");
define(LAN_32, "Je tu 1 nov� spr�va ");
define(LAN_33, "S� tu");
define(LAN_34, "nov� spr�vy");
define(LAN_35, "od Va�ej poslednej n�v�tevy.");
define(LAN_36, "Va�a posledn� n�v�teva ");
define(LAN_37, "Teraz je ");
define(LAN_38, ", v�etky �asy v GMT");
define(LAN_39, "v�etky n�mety");
define(LAN_40, "v�etky spr�vy.");
define(LAN_41, "Najnov�� �len: ");
define(LAN_42, "Registrovan� �lenovia: ");
define(LAN_43, "Tieto f�ra m��u by� zaslan� aj neregistrovan�m u�ivate�om, ale pokia� si chcete prehliadnu� inform�cie o nov�ch spr�v�ch, o ich �prave/mazan�, mus�te se <a href=\"signup.php\">zaregistrova�</a> a prihl�si�.");
define(LAN_44, "Tieto f�ra m��u by� zaslan� aj neregistrovan�m u�ivate�om, ip adresy a hostitelia bud� zap�san�.");
define(LAN_45, "Tieto f�ra m��u zasiela� len registrovan� a prihl�sen� u�ivatelia, pros�m kliknite <a href=\"signup.php\">sem</a> pre registr�ciu");
define(LAN_46, "F�rum");
define(LAN_47, "T�my");
define(LAN_48, "Odpovede");
define(LAN_49, "Posledn� spr�vy");
define(LAN_50, "Moder�tori");
define(LAN_51, "�iadne akt�vne f�rum, sk�ste to nesk�r.");
define(LAN_52, "�iadne akt�vne f�rum v tejto sekci�, sk�ste to nesk�r.");
define(LAN_53, "T�ma");
define(LAN_54, "�tart�r");
define(LAN_55, "Odpovede");
define(LAN_56, "N�h�ady");
define(LAN_57, "Najnov�ie spr�vy");
define(LAN_58, "Moment�lne sa tu nenach�dzaj� �iadne n�mety pre toto f�rum.");
define(LAN_59, "Mus�te by� zaregistrovn� a prihl�sen�, aby ste mohli prispieva� do tohto f�ra. Kliknite <a href=\"signup.php\">sem</a> pre registr�ciu alebo prihl�senie v prihlasovacom menu.");
define(LAN_60, "Nov� t�ma");
define(LAN_61, "Va�e meno: ");
define(LAN_62, "O �om?: ");
define(LAN_63, "Spr�vy: ");
define(LAN_64, "Potvrdi� nov� t�mu");
define(LAN_65, "Zaznamenan� administr�tor - moderovanie zapnut�");
define(LAN_66, "T�to t�ma je moment�lne uzavret�");
define(LAN_67, "spr�vy");
define(LAN_68, "meni�");
define(LAN_69, "zmaza�");
define(LAN_70, "presun��");
define(LAN_71, "�iadne odpovede.");
define(LAN_72, "Odoslan� od:");
define(LAN_73, "Odpove�: ");
define(LAN_74, "Odpoveda� na t�mu");
define(LAN_75, "Zasla� odpove�");
define(LAN_76, "Odpoveda�");
define(LAN_77, "Upravi� t�mu");
define(LAN_78, "Inovova� odpove�");
define(LAN_79, "Nov� spr�vy");
define(LAN_80, "�iadne nov� spr�vy");
define(LAN_81, "Uzavren� t�ma");

//index.php
define(LAN_82, "Spr�vy - Kateg�ria");
define(LAN_83, "Ni� nov� nezaznamenan�, sk�ste to nesk�r.");
define(LAN_84, "Nov� pr�spevok");

//links.php
define(LAN_85, "�iadne odkazy.");
define(LAN_86, "Kateg�ria:");
define(LAN_87, "Tla��tko pre");
define(LAN_88, "Nav�t�ven�:");
define(LAN_89, "Administr�tor: ");
define(LAN_90, "prida� nov� odkaz v t�to kategori�");
define(LAN_91, "prida� nov� kateg�riu");

//oldpolls.php
define(LAN_92, "Star�ie ankety");
define(LAN_93, "Zatia� �iadne star�ie ankety.");
define(LAN_94, "zaslan� od");
define(LAN_95, "Po�et hlasov:");
define(LAN_96, "Ankety");

//search.php
define(LAN_97, "Nen�jden�.");
define(LAN_98, "Pr�spevky noviniek");
define(LAN_99, "Koment�re");
define(LAN_100, "�l�nky");
define(LAN_101, "Chatbox");
define(LAN_102, "Odkazy");
define(LAN_103, "F�rum");

//signup.php
define(LAN_104, "Meno tohto u��vate�a je u� pou�it� v datab�zi, pros�m, zvolte in�.");
define(LAN_105, "Heslo alebo jeho potvrdenie nies� toto�n�, pros�m, zadajte heslo znovu.");
define(LAN_106, "Zrejme nespr�vny form�t emailovej adresy, pros�m, zadajte ju znovu.");
define(LAN_107, "�akujem! Ste zaregistrovan� na str�nky ".SITENAME.", pros�m zapam�tajte si svoje u�ivate�sk� meno a heslo, pokia� ich zabudnete, nebudete ich u� m�c� pou��va�.<br /><br />Teraz sa m��te prihl�si� z prihlasovacieho boxu.");
define(LAN_108, "Registr�cia �sp�n�");
define(LAN_109, "T�to str�nka zodpoved� The Children's Online Privacy Protection Act z roku 1998 (COPPA) a preto tu nem��u b�� zaregistrovan� u��vatelia mlad�� ako 13 rokov bez p�somn�ho s�hlasu rodi�ov alebo zodpovedn�ch os�b. Pre viac inform�ci� ��tajte t�to <a href=\"http://www.cdt.org/legislation/105th/privacy/coppa.html\">vyhl�ku</a>. Skontaktujte webmastra <a href=\"mailto:".SITEADMINEMAIL."\">tu</a> pre pr�padn� asistenciu.<br /><br /><div style=\"text-align:center\"><b>Pros�m potvr�te, �e m�te viac ako 13 let.");
define(LAN_110, "Registr�cia");
define(LAN_111, "Kontrola hesla: ");
define(LAN_112, "Emailov� adresa: ");
define(LAN_113, "Skry� emailov� adresu?: ");
define(LAN_114, "(Zabr�ni to zobrazovaniu Va�ej emailov� adresy.)");
define(LAN_115, "ICQ ��slo: ");
define(LAN_116, "AIM Prez�vka: ");
define(LAN_117, "MSN Prez�vka: ");
define(LAN_118, "Narodeniny: ");
define(LAN_119, "Miesto: ");
define(LAN_120, "Podpis: ");
define(LAN_121, "Obr�zok: ");
define(LAN_122, "�asov� p�smo:");
define(LAN_123, "Zaregistrova�");

//stats.php
define(LAN_124, "Po�et unik�tnych zobrazen�: ");
define(LAN_125, "Po�et vzhliadnut� str�nky: ");
define(LAN_126, "Po�et unik�tnych zobrazen� str�nky: ");
define(LAN_127, "Po�et zobrazen� str�nky: ");
define(LAN_128, "Prehliada�: ");
define(LAN_129, "Opera�n� syst�m: ");
define(LAN_130, "N�v�teva �t�tov/dom�n od: ");
define(LAN_131, "�tatistiky: ");
define(LAN_132, "�tatistiky str�nky");

//submitnews.php
define(LAN_133, "�akujem");
define(LAN_134, "V� pr�spevok bol potvrden� a bude predan� administr�torovi na schv�lenie.");
define(LAN_135, "Text pr�spevku: ");
define(LAN_136, "Odosla� pr�spevok");

//user.php
define(LAN_137, "T�to inform�cia nie je pr�stupn� u�ivate�om bez ragistr�cie.");
define(LAN_138, "Registrovan� u��vatelia: ");
define(LAN_139, "Ponuka: ");
define(LAN_140, "Registrovan� u��vatelia");
define(LAN_141, "�iadny registrovan� u��vatelia");
define(LAN_142, "�len");
define(LAN_143, "[skryt� pod�a priania]");
define(LAN_144, "URL www str�nky: ");
define(LAN_145, "Registrovan�:");
define(LAN_146, "Po�et n�v�tev od registr�cie: ");
define(LAN_147, "Chatbox spr�vy: ");
define(LAN_148, "Zaslan� koment�re: ");
define(LAN_149, "Spr�vy pre f�rum: ");

//usersettings.php
define(LAN_150, "Nastavenie zmenen� a zap�san� do datab�zy.");
define(LAN_151, "OK");
define(LAN_152, "Nov� heslo: ");
define(LAN_153, "Kontrola nov�ho hesla: ");
define(LAN_154, "Zmeni� nastavenie");
define(LAN_155, "Zmeni� nastavenie u��vate�a");
define(LAN_185, "Ch�ba heslo, zap�sa� do kolonky");

//plugins
define(LAN_156, "Potvrdi�");
define(LAN_157, "Vymaza�");
define(LAN_158, "�iadne spr�vy.");
define(LAN_159, "Uk�za� v�etky spr�vy");
define(LAN_160, "Webmaster: ");
define(LAN_161, "Spr�vy");
define(LAN_162, "�iadna akt�vna anketa.");
define(LAN_163, "Potvrdi� vo�bu");
define(LAN_164, "Vo�by: ");
define(LAN_165, "Star�ie ankety");

//menus
define(LAN_166, "�iadny �l�nok.");
define(LAN_167, "�l�nky");
define(LAN_168, "Na�e pr�spevky m��u b�� prebran� na��tan�m bu� rss a alebo textov�ho s�boru.");
define(LAN_169, "Z�hlavie");
define(LAN_170, "W3C Kompliancia");
define(LAN_171, "Nerozoznan� ip adresa tohto u��vate�a (mo�no po�koden� cookie).<br />Pros�m <a href=\"index.php?logout\">kliknite sem</a> pre jeho vymazanie.");
define(LAN_172, "Odhl�si�");
define(LAN_173, "Chyba v prihlasovan�");
define(LAN_174, "Registr�cia");
define(LAN_175, "Prihl�si� sa");
define(LAN_176, "Na t�to str�nku: ");
define(LAN_177, "Celkom: ");
define(LAN_178, "�lenovia: ");
define(LAN_179, "Online");
define(LAN_180, "Hlada�");
define(LAN_181, "Spojenie na n�s");
define(LAN_182, "Chatbox");
define(LAN_183, "Hlavn� Menu");
define(LAN_184, "Anketa");

// #### Added in v5 #### //

define(LAN_186, "Posla� pr�spevok");
define(LAN_187, "Emailov� adresa posla� komu");
define(LAN_188, "Mysl�m, �e by sa V�m mohla p��i� t�to nov� poviedka od");
define(LAN_189, "Be�� v�aky");
define(LAN_190, "N�hlady");
define(LAN_191, "Inform�cie");
define(LAN_192, "U��vatelia tohto f�ra poslali celkom ");
define(LAN_193, "Moder�tor f�ra");
define(LAN_194, "Hos�");
define(LAN_195, "Registrovan� �len");
define(LAN_196, "��tali ste ");
define(LAN_197, " t�chto spr�v.");
define(LAN_198, " V�etky nov� spr�vy boly pre��tan�.");
define(LAN_199, "Ozna�i� v�etky spr�vy za pre��tan�");
define(LAN_200, "uzavrie� t�to t�mu");
define(LAN_201, "znovuotvori� t�to t�mu");
define(LAN_202, "St�la t�ma");
define(LAN_203, "St�la/Uzavret� t�ma");
define(LAN_204, "<b>M��ete</b> vlo�it nov� t�mu");
define(LAN_205, "<b>Nem��ete</b> vlo�it nov� t�mu");
define(LAN_206, "<b>M��ete</b> zasla� odpove�");
define(LAN_207, "<b>Nem��ete</b> zasla� odpove�");
define(LAN_208, "<b>M��ete</b> menit svoje spr�vy");
define(LAN_209, "<b>Nem��ete</b> meni� svoje spr�vy");
define(LAN_210, "<b>M��ete</b> vymaza� svoje spr�vy");
define(LAN_211, "<b>Nem��ete</b> vymaza� svoje spr�vy");
define(LAN_212, "Zabudli ste heslo?");
define(LAN_213, "T�to emailov� adresa/u��vate�sk� m�no/nebola n�jden� v datab�zi.");
define(LAN_214, "Nemo�no vymaza� heslo");
define(LAN_215, "Va�e heslo pre str�nku".SITENAME." bolo zru�en�. Va�e nov� heslo je\n\n");
define(LAN_216, "Pre zpoplatnenie tohto hesla pros�m chodte na adresu...");
define(LAN_217, "�akujem, Va�e nov� heslo je teraz platn�. M��ete sa prihl�si� pomocov Va�eho nov�ho hesla.");

define(LAN_281, "Hostia: ");

// NEW IN VERSION 5.3b4 - PLEASE UPDATE!

define(LAN_300, "Toto u�ivate�sk� meno nebolo n�jden� v datab�zi.<br /><br />");
define(LAN_301, "Chybn� heslo.<br /><br />");
define(LAN_302, "Neaktivoval ste si svoj ��et. You should have received an email with instructions on how to confirm your account, if not please contact a site administrator.<br /><br />");
define(LAN_303, "Tento pr�spevok noviniek je od ");
define(LAN_304, "N�zov �l�nku: ");
define(LAN_305, "Podn�zov: ");
define(LAN_306, "Tento �l�nok je od ");
define(LAN_307, "Po�et spr�v v tejto kategori�: ");
define(LAN_308, "Prav� m�no: ");
define(LAN_309, "Pros�m vlo�te �daje o sebe - <b>potvrdzuj�ci email bude zaslan� na adresu, ktor� tu uv�dzate, preto mus� by� pr�slu�n� schr�nka platn�, </b>pokia� si neprajete zobrazova� Va�u emailov� adresu na t�chto str�nk�ch, pros�m za�krtnite Nezobrazova� emailov� adresu.");
define(LAN_310, "Nemo�no prija� pr�spevok, preto�e toto meno je zaregistrovan� - pokia� je toto va�e u��vate�sk� meno, pros�m, prihl�ste sa, aby syst�m mohol v� pr�spevok prija�.");
define(LAN_311, "Anonymn�");
define(LAN_312, "Dvojit� zaslanie - neprijat�.");
define(LAN_313, "Pros�m vyberte si zoznam...");
define(LAN_314, "Triedy: ");
define(LAN_315, "U��vatelia: ");
define(LAN_316, "�s� na str�nku ");                                                                                                                                                                       ;
define(LAN_317, "Ni�");
define(LAN_318, "Nastavenie oper�tora: ");
define(LAN_319, "Zru�i� st�los�");
define(LAN_320, "St�l�");
define(LAN_321, "Moder�tori: ");
define(LAN_322, "Poslan�: ");
define(LAN_323, "N�h�ad");
define(LAN_324, "Va�a spr�va bola �spe�ne odoslan�.");
define(LAN_325, "kliknite sem pre zobrazenie Va�ej spr�vy");
define(LAN_326, "kliknite sem pre znovuvst�penie do f�ra");
define(LAN_327, "N�h�ad");
define(LAN_328, "Nastavenia");   // "Settings" as used in default-header.
define(LAN_329, "Auto Login"); // Auto Login

define(LAN_350, "Nastav vzh�ad");
define(LAN_351, "Vyber vzh�ad");

define(LAN_352, "Nastav jazyk");
define(LAN_353, "Vyber jazykov� rozhranie");

define("LAN_354", "(Restricted)");
define("LAN_355", "No downloads in this category yet");
define("LAN_356", "Total size of files: ");
define("LAN_357", "Files downloaded: ");
define("LAN_358", "Files available: ");
define("LAN_359", "Rate this download");
define("LAN_360", "thanks for rating");
define("LAN_361", "downloads from");
define("LAN_362", "files");
define("LAN_363", "Downloads");
define("LAN_364", "Sort by");
define("LAN_365", "Date");
define("LAN_366", "Filesize");
define("LAN_367", "Download");
define("LAN_368", "No downloads yet, please check back soon");
define("LAN_369", "Not rated yet");
define("LAN_370", "Rating: ");

define("LAN_371", "Logging is not activated, to activate go to your admin section, click on Logger and tick the Activate Logging/Counter checkbox.");
define("LAN_372", "The features on this page have been disabled.");
define("LAN_373", "�iadne �tatistiky.");
define("LAN_374", "�tart �tatistiky:");
define("LAN_375", "Zobrazi� v�etko");
define("LAN_376", "Posledn�ch 10 n�v�tevn�kov");
define("LAN_377", "v�etky");
define("LAN_378", "top 10");
define("LAN_379", "Rozl��enie monitora");

define("LAN_380", "If you wish to be notified by email when a reply is posted to your thread please tick the box ");
define("LAN_381", "Forum reply from ");
define("LAN_382", "Post made: ");
define("LAN_383", "Please click the following link to view the full thread ...");
define("LAN_384", "Forum reply at ");
define("LAN_385", "Post: ");
define("LAN_386", "If you do not wish to add a poll to your thread leave the fields blank ");
define("LAN_387", "You must be a logged-in member to vote in this poll.");
define("LAN_388", "Popular thread");


define("LAN_389", "Previous thread");
define("LAN_390", "Next thread");
define("LAN_391", "track this thread");
define("LAN_392", "stop tracking this thread");

define("LAN_393", "List tracked threads");
define("LAN_394", "Closed forum");
define("LAN_395", "[popular]");
define("LAN_396", "Announcement");
define("LAN_397", "Tracked threads");


define("LAN_398", "No summary.");

define("LAN_399", "Continue");
define("LAN_400", "Usernames and passwords are <b>case-sensitive</b>");
define("LAN_401", "Leave blank to keep existing password");

define("LAN_402", "You must be a registered member to upload files to this server.");
define("LAN_403", "You do not have the correct permissions to upload files to this server.");
define("LAN_404", "Thankyou. Your upload will be reviewed by an administrator and posted to the site if appropriate.");
define("LAN_405", "File exceeds specified maximum size limit - deleted.");
define("LAN_406", "<b>Please note</b><br />Allowed filetypes:");
define("LAN_407", "Any other filetypes uploaded will be instantly deleted.");
define("LAN_408", "<u>Underlined</u> fields are required");

define("LAN_409", "Name of file");
define("LAN_410", "Version");
define("LAN_411", "File");
define("LAN_412", "Screenshot");
define("LAN_413", "Description");


define("LAN_414", "Working demo");
define("LAN_415", "enter URL to site where demo can be viewed");
define("LAN_416", "Submit and Upload");
define("LAN_417", "Upload File");
?>