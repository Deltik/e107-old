<?php
$caption = "SMTP";
$text = "Enter your smtp settings here to use them for site email functions instead of PHP's native mail function, to stop using remove smtp.php from the plugins folder.";
$ns -> tablerender($caption, $text);
?>