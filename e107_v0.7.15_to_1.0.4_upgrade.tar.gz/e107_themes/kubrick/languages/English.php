<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_themes/kubrick/languages/English.php $
|     $Revision: 11678 $
|     $Id: English.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' by <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Based on original theme by Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Comments are turned off for this item");
define("LAN_THEME_3", "comment: ");
define("LAN_THEME_4", "Read the rest ...");
define("LAN_THEME_5", "Trackbacks: ");
define('LAN_THEME_6', 'on');
define('LAN_THEME_7', 'by');


?>