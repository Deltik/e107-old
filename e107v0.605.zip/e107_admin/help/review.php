<?php
$text = "Reviews are similar to articles but they will be listed in their own menu item.";
$ns -> tablerender("Review Help", $text);
?>