<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Site temporarily closed");
define("LAN_00", "is temporarily closed");
define("LAN_01", "We have temporarily closed the site for some essential maintainance. This shouldn't take too long - please check back soon, apologies for the inconvenience.");
?>