<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_emoticon.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Emote activation");
define("EMOLAN_2", "Name");
define("EMOLAN_3", "Emotes");
define("EMOLAN_4", "Activate emoticons?");

define("EMOLAN_5", "Image");
define("EMOLAN_6", "Emote Code");
define("EMOLAN_7", "separate multiple entries with spaces");

define("EMOLAN_8", "Status");
define("EMOLAN_9", "Options");
define("EMOLAN_10", "Active");
define("EMOLAN_11", "Activate pack'");

define("EMOLAN_12", "Edit / configure this pack");
define("EMOLAN_13", "Installed packs");

define("EMOLAN_14", "Save configuration");
define("EMOLAN_15", "Edit / configure emotes");
define("EMOLAN_16", "Emote configuration saved");
define("EMOLAN_2", "Name");
define("EMOLAN_2", "Name");
define("EMOLAN_2", "Name");
define("EMOLAN_2", "Name");
define("EMOLAN_2", "Name");
define("EMOLAN_2", "Name");

?>