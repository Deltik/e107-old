<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_plugins/forum/languages/English/lan_forum_search.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Select forum");
define("FOR_SCH_LAN_3", "All Forums");
define("FOR_SCH_LAN_4", "Whole post");
define("FOR_SCH_LAN_5", "As part of thread");

?>