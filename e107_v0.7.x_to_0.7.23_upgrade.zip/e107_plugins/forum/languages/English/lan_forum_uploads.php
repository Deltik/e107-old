<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_plugins/forum/languages/English/lan_forum_uploads.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','Uploaded Files in forum');
define('FRMUP_2','File deleted');
define('FRMUP_3','Error: Unable to delete file');
define('FRMUP_4','File deletion');
define('FRMUP_5','Filename');
define('FRMUP_6','Result');
define('FRMUP_7','Found in thread');
define('FRMUP_8','NOT FOUND');
define('FRMUP_9','No uploaded files found');
define('FRMUP_10','Delete');
	
?>