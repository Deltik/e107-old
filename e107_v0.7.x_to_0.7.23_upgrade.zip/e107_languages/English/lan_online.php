<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_online.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "Guests: ");
define("ONLINE_EL2", "Members: ");
define("ONLINE_EL3", "On this page: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Members");
define("ONLINE_EL6", "Newest member");
define("ONLINE_EL7", "viewing");
define("ONLINE_EL8", "most ever online: ");
define("ONLINE_EL9", "on");
define("ONLINE_EL10", "Member Name");
define("ONLINE_EL11", "Viewing Page");
define("ONLINE_EL12", "Replying to");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Thread");
define("ONLINE_EL15", "Page");
define("CLASSRESTRICTED", "Class Restricted Page");
define("ARTICLEPAGE", "Article/Review");
define("CHAT", "Chat");
define("COMMENT", "Comments");
define("DOWNLOAD", "Downloads");
define("EMAIL", "email.php");
define("FORUM", "Main Forum Index");
define("LINKS", "Links");
define("NEWS", "News");
define("OLDPOLLS", "Old Polls");
define("POLLCOMMENT", "Poll");
define("PRINTPAGE", "Print");
define("LOGIN", "Logging In");
define("SEARCH", "Searching");
define("STATS", "Site Stats");
define("SUBMITNEWS", "Submit News");
define("UPLOAD", "Uploads");
define("USERPAGE", "User Profiles");
define("USERSETTINGS", "User Settings");
define("ONLINE", "Online Users");
define("LISTNEW", "List New Items");
define("USERPOSTS", "User Posts");
define("SUBCONTENT", "Submit Article/Review");
define("TOP", "Top Posters/Most Active Threads");
define("ADMINAREA", "Admin Area");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Events List");
define("CALENDAR", "Events Calendar");
define("FAQ", "Faq");
define("PM", "Private Messaging");
define("SURVEY", "Survey");
define("ARTICLE", "Article");
define("CONTENT", "Content Page");
define("REVIEW", "Review");

?>