<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Printer Friendly"); }

define("LAN_PRINT_86", "Category:");
define("LAN_PRINT_87", "by ");
define("LAN_PRINT_94", "Posted by");
define("LAN_PRINT_135", "News Item: ");
define("LAN_PRINT_303", "This news item is from ");
define("LAN_PRINT_304", "Title: ");
define("LAN_PRINT_305", "Subheading: ");
define("LAN_PRINT_306", "This is from: ");
define("LAN_PRINT_307", "Print this page");

define("LAN_PRINT_1", "printer friendly");


?>