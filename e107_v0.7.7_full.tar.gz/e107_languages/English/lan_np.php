<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_np.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("NP_1", "Previous page");
define("NP_2", "Next page");
define("NP_3", "Go to page");

?>