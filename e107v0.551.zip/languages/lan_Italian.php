<?php
/*
+---------------------------------------------------------------+
|        e107 website system                                                                                                        |
|        language file: Italian                                                                                                        |
|                                                                                                                                                                                |
|        �Steve Dunstan 2001-2002                                                                                |
|        http://jalist.com                                                                                                                        |
|        stevedunstan@jalist.com                                                                                        |
|                                                                                                                                                                                |
|        Released under the terms and conditions of the                |
|        GNU General Public License (http://gnu.org).                                |
+---------------------------------------------------------------+
*/

//articles.php/comment.php
define(LAN_0, "[bloccato dall'amministratore]");
define(LAN_1, "Sblocca");
define(LAN_2, "Blocca");
define(LAN_3, "Elimina");
define(LAN_4, "Info");
define(LAN_5, "Commenti ...");
define(LAN_6, "Devi entrare nel sito come utente registrato per poter inviare dei commenti - sei pregato di fornire nome utente e password o se non sei registrato clicca <a href=\"signup.php\">qui</a> per registrarti");
define(LAN_7, "Nome: ");
define(LAN_8, "Commento");
define(LAN_9, "Aggiungi commento");
define(LAN_10, "Tags permessi: [b] [i] [u] [img] [centera] [link]<br />usa [link=testo del link] testo link [/link] per i link <br />Il ritorno a capo (&lt;br /&gt;) sono inseriti in automatico.");

//chat.php
define(LAN_11, "Area Chat (tutti i messaggi)");
define(LAN_12, "Messaggi Chat");

//class.php
define(LAN_13, "Elenco notizie eliminato.");
define(LAN_14, "Database notizie aggiornato.");
define(LAN_15, "Notizia inserito nel database.");
define(LAN_16, "Nome utente: ");
define(LAN_17, "Password: ");
define(LAN_18, "Entra");
define(LAN_19, "Abilita la scrittura sul file news.xml sul server, assicurati che la cartella /backend abbia i permessi giusti impostati (666)");
define(LAN_20, "Errore");
define(LAN_21, "Totale pagine visitate oggi: ");
define(LAN_22, "Totale pagine visitate: ");
define(LAN_23, "Totale accesso al sito: ");
//define(LAN_24, "fuck|piss|shit|cunt|cock|asshole|motherfucker|mother fucker| arse|pussy|faggot");
define(LAN_24, "fottere|cazzo|pisciare|merda|figa|cazzo|buco del culo|motherfucker|mother fucker |culo|frocio");
define(LAN_25, "Pagina precedente");
define(LAN_26, "Pagina successiva");

//forum.php
define(LAN_27, "Un campo necessario � stato lasciato vuoto");
define(LAN_28, "Errore. Non hai inserito niente ..");
define(LAN_29, "Modificato");
define(LAN_30, "Benvenuto");
define(LAN_31, "Non ci sono nuovi messaggi ");
define(LAN_32, "C'� un nuovo messaggio ");
define(LAN_33, "Ci sono ");
define(LAN_34, "nuovi messaggi");
define(LAN_35, "dall'ultimo tuo accesso al sito.");
define(LAN_36, "Il tuo ultimo accesso � stato il ");
define(LAN_37, "Oggi � ");
define(LAN_38, ", tutti gli orari sono in GMT.");
define(LAN_39, "totale argomenti");
define(LAN_40, "totale messaggi.");
define(LAN_41, "Ultimo utente: ");
define(LAN_42, "Utenti registrati: ");
define(LAN_43, "Questi forums possono essere consultati e aperti agli utenti non registrati, ma se desideri vedere le info relative ai nuovi messaggi, modificare/eliminare i tuoi messaggi etc devi <a href=\"signup.php\">registrarti</a> e autenticarti.");
define(LAN_44, "Questi forums possono essere consultati e aperti agli utenti non registrati, gli indirizzi ip e il nome host verranno registrati.");
define(LAN_45, "Questi forums sono accessibili soltanto da parte utenti registrati e autenticati, clicca <a href=\"signup.php\">qui</a> per andare alla pagine di registrazione.");
define(LAN_46, "Forum");
define(LAN_47, "Filoni");
define(LAN_48, "Risposte");
define(LAN_49, "Ultimo messaggio");
define(LAN_50, "Moderatori");
define(LAN_51, "Non ci sono, per il momento, forum, per favore verifica pi� avanti.");
define(LAN_52, "Non ci sono, per il momento, forum in questa sezione, per favore verifica pi� avanti.");
define(LAN_53, "Argomenti");
define(LAN_54, "Starter");
define(LAN_55, "Risposte(Repliche)");
define(LAN_56, "Viste");
define(LAN_57, "ultimo messaggio");
define(LAN_58, "Non ci sono, Per il momento, argomenti in questo forum.");
define(LAN_59, "Devi essere un utente registrato e autenticato per poter inviare messaggi a questo forum. Clicca <a href=\"signup.php\">qui</a> per registrarti o entra dal menu di login.");
define(LAN_60, "Iniziato nuovo argomento");
define(LAN_61, "Il tuo nome : ");
define(LAN_62, "Subject: ");
define(LAN_63, "Messaggio: ");
define(LAN_64, "Invia nuovo argomento");
define(LAN_65, "Amministratore in linea - moderazione attivata");
define(LAN_66, "Questo argomento � chiuso");
define(LAN_67, "messaggi");
define(LAN_68, "modifica");
define(LAN_69, "elimina");
define(LAN_70, "sposta");
define(LAN_71, "Nessuna replica.");
define(LAN_72, "Inviato originalmente da");
define(LAN_73, "Risposta: ");
define(LAN_74, "Rispondi all'argomento");
define(LAN_75, "Invia la risposta");
define(LAN_76, "Rispondi");
define(LAN_77, "Aggiorna argomento");
define(LAN_78, "Aggiorna risposte");
define(LAN_79, "Nuovi messaggi");
define(LAN_80, " Nessun nuovo messaggio");
define(LAN_81, "Argomenti chiusi");

//index.php
define(LAN_82, "Notizie - Categoria");
define(LAN_83, "Nessuna notizia - per favore verifica pi� avanti.");
define(LAN_84, "Elenco notizie");

//links.php
define(LAN_85, "Nessun link presente.");
define(LAN_86, "Categoria:");
define(LAN_87, "Buttone per");
define(LAN_88, "Referals:");
define(LAN_89, "Amminist.: ");
define(LAN_90, "aggiungi nuovi link a questa categoria");
define(LAN_91, "inserisci nuova categoria");

//oldpolls.php
define(LAN_92, "Sondaggi precedenti");
define(LAN_93, "non ci sono altri sondaggi precedenti.");
define(LAN_94, "Inviato da");
define(LAN_95, "Totale voti:");
define(LAN_96, "Sondaggi");

//search.php
define(LAN_97, "Non � stato trovato niente.");
define(LAN_98, "Elenco notizie");
define(LAN_99, "Commenti");
define(LAN_100, "Articoli");
define(LAN_101, "Area Chat");
define(LAN_102, "Links");
define(LAN_103, "Forum");

//signup.php
define(LAN_104, "Nome utente gi� utilizzato, si prega di indicare un mome utente diverso.");
define(LAN_105, "Le due password inserite non sono uguali. Si prega di riprovare.");
define(LAN_106, "L'email fornito non sembra valido. Si prega di controllare.");
define(LAN_107, "Grazie! Adesso sei un utente registrato di ".SITENAME.", scrivi il nome utente e la password e conservali in un luogo sicuro dato che non si possono recuperare.<br /><br />Adosso puoi entrare nel sito dalla finestra di Login.");
define(LAN_108, "Registrazione completata");
define(LAN_109, "Questo sito aderisce alla convenzione per la protezione della privacy dei bambini su internet del 1998 (Children's Online Privacy Protection Act [COPPA]) e per questo non pu� accettare la registrazione dei bambini al di sotto dei 13 anni senza un permesso scritto dai loro genitori o tutori. Per maggior informazioni puoi leggere la legislazione sull'argomento <a href=\"http://www.cdt.org/legislation/105th/privacy/coppa.html\">qui</a>. Contattate l'amministratore del sito  <a href=\"mailto:".SITEADMINEMAIL."\">qui</a> se avete bisogno di assistenza .<br /><br /><div style=\"text-align:center\"><b> Se hai pi� di 13 anni clicca <a href=\"signup.php?stage1\">qui</a> per continuare con la registrazione.");
define(LAN_110, "Registrazione");
define(LAN_111, "Conferma  Password: ");
define(LAN_112, "Indirizzo Email: ");
define(LAN_113, "Nascondere il tuo indirizzo email?: ");
define(LAN_114, "(Questo permette che il tuo email non venga mostrato)");
define(LAN_115, "ICQ Number: ");
define(LAN_116, "AIM Nickname: ");
define(LAN_117, "MSN Nickname: ");
define(LAN_118, "Giorno di nascita: ");
define(LAN_119, "Localit�: ");
define(LAN_120, "Firma: ");
define(LAN_121, "Foto: ");
define(LAN_122, "Fuso orario:");
define(LAN_123, "Registra");

//stats.php
define(LAN_124, "Numero totale visite (univoche): ");
define(LAN_125, "Numero totale visite: ");
define(LAN_126, "Totale visite per pagina (univoche): ");
define(LAN_127, "Totale visite per pagina : ");
define(LAN_128, "Browser: ");
define(LAN_129, "Sistema operativo: ");
define(LAN_130, "Paesi/Domini dei visitatori: ");
define(LAN_131, "Referers: ");
define(LAN_132, "Statistiche del sito");

//submitnews.php
define(LAN_133, "Grazie");
define(LAN_134, "Il tuo messaggio � stato inviato e verr� esaminato da uno dei amministratori del sito a tempo debito.");
define(LAN_135, "Nuovi argomenti: ");
define(LAN_136, "Inserisci nuova notizia");

//user.php
define(LAN_137, "Non ci sono informazioni su questo utente visto che non � ancora registrato su");
define(LAN_138, "Utenti registrati: ");
define(LAN_139, "Ordina: ");
define(LAN_140, "Utenti registrati");
define(LAN_141, "Utente non ancora registrato.");
define(LAN_142, "Utente");
define(LAN_143, "[nascosto su richiesta]");
define(LAN_144, "Indirizzo (URL) sito web : ");
define(LAN_145, "Registrato:");
define(LAN_146, "Visite al sito dalla registrazione: ");
define(LAN_147, "Messaggi dell'Area Chat: ");
define(LAN_148, "Commenti inviati: ");
define(LAN_149, "Messaggi del Forum: ");

//usersettings.php
define(LAN_150, "Impostazioni aggiornate.");
define(LAN_151, "OK");
define(LAN_152, "Nuova Password: ");
define(LAN_153, "Verifica Nuova Password: ");
define(LAN_154, "Aggiorna impostazioni");
define(LAN_155, "Aggiorna impostazioni utente");
define(LAN_185, "Hai lasciato il campo della password vuoto,");

//plugins
define(LAN_156, "Invia");
define(LAN_157, "Azzera");
define(LAN_158, "Nessun messaggio.");
define(LAN_159, "Mostra tutti i messaggi");
define(LAN_160, "Webmaster: ");
define(LAN_161, "Titoli");
define(LAN_162, "Nessun sondaggio attivo.");
define(LAN_163, "Invia voto");
define(LAN_164, "Voti: ");
define(LAN_165, "Sondaggi vecchi");

//menus
define(LAN_166, "Nessun articolo.");
define(LAN_167, "Articoli");
define(LAN_168, "Our headlines can be syndicated by using either our rss or text feeds.");
//define(LAN_168, "I nostri titoli sono sindacabili usando la nostra our rss or invii in formato testo.");
define(LAN_169, "Backend");
define(LAN_170, "Conforme W3C");
define(LAN_171, "La user id non � stata convalidata (i cookie possono essere danneggiati).<br />Si prega di <a href=\"index.php?logout\">cliccare qui</a> per eliminare i cookie.");
define(LAN_172, "Esci");
define(LAN_173, "Errori di autenticazione");
define(LAN_174, "Registrati");
define(LAN_175, "Login");
define(LAN_176, "Utenti su questa pagina: ");
define(LAN_177, "Utenti collegati al sito: ");
define(LAN_178, "Utenti collegati: ");
define(LAN_179, "In linea");
define(LAN_180, "Cerca");
define(LAN_181, "Attiva un link su di noi");
define(LAN_182, "Area Chat");
define(LAN_183, "Menu principale");
define(LAN_184, "Sondaggio");

// #### Added in v5 #### //

define(LAN_186, "Invia nuovo argomento");
define(LAN_187, "Indirizzo email a cui mandare ");
define(LAN_188, "Credevo che ti potesse interessare questa notizia da ");
define(LAN_189, "Powered by");
define(LAN_190, "Recensioni");
define(LAN_191, "Informazioni");
define(LAN_192, "Gli utenti di questo forum hanno inviato un totale di  ");
define(LAN_193, "Moderatore del Forum ");
define(LAN_194, "Ospite");
define(LAN_195, "Utente registrato");
define(LAN_196, "Hai letto ");
define(LAN_197, " di questi messaggi.");
define(LAN_198, " Tutti i nuovi messaggi sono stati letti.");
define(LAN_199, "Segnala tutti i messaggi come letti");
define(LAN_200, "chiudi questo argomento");
define(LAN_201, "riapri il argomento");
define(LAN_202, "Sticky thread");
//define(LAN_202, "Argomento vischioso");
define(LAN_203, "Sticky/Closed thread");
//define(LAN_203, "Argomento Sticky/Chiuso");
define(LAN_204, "<b>Puoi</b> iniziare un nuovo argomento");
define(LAN_205, "<b>Non puoi</b> iniziare un nuovo argomento");
define(LAN_206, "<b>Puoi</b> inviare risposte");
define(LAN_207, "<b>Non puoi</b> inviare risposte");
define(LAN_208, "<b>Puoi</b> modificare i tuoi messaggi inviati");
define(LAN_209, "<b>Non puoi</b> modificare i tuoi messaggi inviati");
define(LAN_210, "<b>Puoi</b> eliminare i tuoi messaggi inviati");
define(LAN_211, "<b>Non puoi</b> eliminare i tuoi messaggi inviati");
define(LAN_212, "Hai dimenticato la password?");
define(LAN_213, "Il nome utente/indirizzo email non sono stati trovati nel database.");
define(LAN_214, "Non � stato possibile azzerare la password");
define(LAN_215, "La tua password per il sito ".SITENAME." � stata azzerata. La tua nuova password �\n\n");
define(LAN_216, "Per convalidare la tua nuova password vai al seguente indirizzo ...");
define(LAN_217, "Grazie, la tua nuova password � stata convalidata. Adesso puoi entrare nel sito con la nuova password.");


     // NEW IN VERSION 5.3b4 - PLEASE UPDATE!

define(LAN_300, "That username was not found in the database.<br /><br />");
define(LAN_301, "Incorrect password.<br /><br />");
define(LAN_302, "You have not activated your account. You should have received an email with instructions on how to confirm your account, if not please contact a site administrator.<br /><br />");
define(LAN_303, "This news item is from ");
define(LAN_304, "Article Title: ");
define(LAN_305, "Subheading: ");
define(LAN_306, "This article is from ");
define(LAN_307, "Total posts in this category: ");
define(LAN_308, "Real Name: ");
define(LAN_309, "Please enter your details below - <b>a verification email will be sent to the email address you enter here so it must be valid, </b>if you do not wish to display your email address on this site please tick the hide email address box.");
define(LAN_310, "Unable to accept post as that username is registered - if it is your username please login to post.");
define(LAN_311, "Anonymous");
define(LAN_312, "Duplicate post - unable to accept.");
define(LAN_313, "Please choose which list you wish to display ...");
define(LAN_314, "Classes: ");
define(LAN_315, "Users: ");
define(LAN_316, "Go to page ");
define(LAN_317, "None");
define(LAN_318, "moderator options: ");
define(LAN_319, "Unstick");
define(LAN_320, "Stick");
define(LAN_321, "Moderators: ");
define(LAN_322, "Posted: ");
define(LAN_323, "Preview");
define(LAN_324, "Your message has been successfully posted.");
define(LAN_325, "Click Here to view your message");
define(LAN_326, "Click here to return to the forum");
define(LAN_327, "Review");
define(LAN_328, "Regolazioni");   // "Settings" as used in default-header.
define(LAN_329, "Auto Login"); // Auto Login

define("LAN_354", "(Ristretto)");
define("LAN_355", "Nessun downloads in questa categoria");
define("LAN_356", "Dimensione totale dei files: ");
define("LAN_357", "Files scaricati: ");
define("LAN_358", "Files disponibili: ");
define("LAN_359", "Vota questo download");
define("LAN_360", "Grazie per aver votato");
define("LAN_361", "downloads da");
define("LAN_362", "files");
define("LAN_363", "Downloads");
define("LAN_364", "Ordina per");
define("LAN_365", "Data");
define("LAN_366", "Dimensione File");
define("LAN_367", "Download");
define("LAN_368", "Nessun downloads , perfavore riprova in seguito");
define("LAN_369", "Non ancora votato");
define("LAN_370", "Votazione: ");

?>