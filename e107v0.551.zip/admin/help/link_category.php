<?php
$text = "You can seperate your links into different categories, this makes navigating the main Links page much easier and improves layout.";
$ns -> tablerender("Link Category Help", $text);
?>