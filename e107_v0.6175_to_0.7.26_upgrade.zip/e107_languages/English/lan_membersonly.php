<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_membersonly.php $
|     $Revision: 11678 $
|     $Id: lan_membersonly.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Members Only");

define("LAN_MEMBERS_0", "restricted area");
define("LAN_MEMBERS_1", "This is a restricted area.");
define("LAN_MEMBERS_2","For access please <a href='".e_LOGIN."'>log in</a>");
define("LAN_MEMBERS_3","or <a href='".e_SIGNUP."'>register</a> as a member");
define("LAN_MEMBERS_4","Click here to return to front page");


?>