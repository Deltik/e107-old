<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_fla.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Failed login attempts");
define("FLALAN_2", "No failed login attempts have been logged");
define("FLALAN_3", "Attempt(s) deleted");
define("FLALAN_4", "User attempted to login using incorrect username/password");
define("FLALAN_5", "IP(s) banned");
define("FLALAN_6", "Date");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP address/ Host");
define("FLALAN_9", "Options");
define("FLALAN_10", "Delete / Ban checked entries");
define("FLALAN_11", "check all delete checkboxes");
define("FLALAN_12", "uncheck all delete checkboxes");
define("FLALAN_13", "check all ban checkboxes");
define("FLALAN_14", "uncheck all ban checkboxes");
define("FLALAN_15", "The following IP address(es) have been auto-banned - user attempted more than ten failed logins");
define("FLALAN_16", "delete this auto ban list");
define("FLALAN_17", "Auto-ban list deleted");

?>