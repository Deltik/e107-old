<?php
// Messages for log entries
define("LAN_AL_STAT_01", "Stats - reset");
define("LAN_AL_STAT_02", "Stats - settings changed");
define("LAN_AL_STAT_03", "Stats - pages removed");
define("LAN_AL_STAT_04", "Stats - historic data removed");
// define("LAN_AL_STAT_05", "");
// define("LAN_AL_STAT_06", "");
// define("LAN_AL_STAT_07", "");

?>