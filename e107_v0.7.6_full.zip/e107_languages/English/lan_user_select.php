<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/09 20:59:02 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Select user");
define("US_LAN_2", "Select user class");
define("US_LAN_3", "All users");
define("US_LAN_4", "Find username");
define("US_LAN_5", "User(s) found");
define("US_LAN_6", "Search");
?>