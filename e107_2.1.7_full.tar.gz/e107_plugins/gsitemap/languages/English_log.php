<?php

// Admin log messages
//-------------------
define("LAN_AL_GSMAP_01", "Import sitelinks");
define("LAN_AL_GSMAP_02", "Sitemap link deleted");
define("LAN_AL_GSMAP_03", "Sitemap link added");
define("LAN_AL_GSMAP_04", "Sitemap link updated");


?>