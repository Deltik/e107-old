<?php

$text = "Set your chatbox preferences from here.<br /><br />
To activate the chatbox, go to your menus page and make sure chatbox_menu is in either your left or right column.";

$ns -> tablerender("Chatbox", $text);
?>