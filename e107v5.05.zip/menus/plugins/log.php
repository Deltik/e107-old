<?php
$text .= wad("log_conf.php", "Logger", "Log visitor statistics/page counts etc", "0.1.2");
?>