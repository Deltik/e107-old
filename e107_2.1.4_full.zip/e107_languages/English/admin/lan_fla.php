<?php
/*
 * Copyright (C) 2008-2013 e107 Inc (e107.org), Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
 *
 * Admin Language File
 *
*/

// define("FLALAN_1", "Failed login attempts");
define("FLALAN_2", "No failed login attempts have been logged");
define("FLALAN_3", "Attempt(s) deleted");
define("FLALAN_4", "User attempted to login using incorrect username/password");
define("FLALAN_5", "IP(s) banned");
// define("FLALAN_6", "Date");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP address/ Host");
// define("FLALAN_9", "Options");
define("FLALAN_10", "Delete / Ban checked entries");
// define("FLALAN_11", "check all delete checkboxes");
// define("FLALAN_12", "uncheck all delete checkboxes");
// define("FLALAN_13", "check all ban checkboxes");
// define("FLALAN_14", "uncheck all ban checkboxes");
define("FLALAN_15", "The following IP address(es) have been auto-banned - user attempted more than ten failed logins");
define("FLALAN_16", "delete this auto ban list");
define("FLALAN_17", "Auto-ban list deleted");
define('FLALAN_18', "Could not ban IP address --IP-- - on whitelist");

// define('FLALAN_19', "Check All Delete");
?>