<?php
$text .= wad("userclass_conf.php", "User Classes", "Assign classes to users", "P");
?>