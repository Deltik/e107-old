<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/compliance_menu/languages/English-iso.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:51 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
	
define("COMPLIANCE_L1", "W3C Compliance");

?>