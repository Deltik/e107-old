<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/English-iso/lan_chatbox_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:51 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");

?>