<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/search_menu/languages/English-iso.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:57:11 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("LAN_180", "Search");
	
?>