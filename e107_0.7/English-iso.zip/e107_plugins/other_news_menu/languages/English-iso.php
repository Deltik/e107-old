<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/other_news_menu/languages/English-iso.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:57:11 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
	
define("TD_MENU_L1", "Other News");
	
?>