<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English-iso/lan_forum_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:51 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Select forum");
define("FOR_SCH_LAN_3", "All Forums");
define("FOR_SCH_LAN_4", "Whole post");
define("FOR_SCH_LAN_5", "As part of thread");

?>