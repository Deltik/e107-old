<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English-iso/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:51 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','Uploaded Files in forum');
define('FRMUP_2','File deleted');
define('FRMUP_3','Error: Unable to delete file');
define('FRMUP_4','File deletion');
define('FRMUP_5','Filename');
define('FRMUP_6','Result');
define('FRMUP_7','Found in thread');
define('FRMUP_8','NOT FOUND');
define('FRMUP_9','No uploaded files found');
define('FRMUP_10','Delete');
	
?>