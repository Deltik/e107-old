<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English-iso/lan_content_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:51 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Content");
define("CONT_SCH_LAN_2", "All Content Categories");
define("CONT_SCH_LAN_3", "Posted in reply to item");

?>