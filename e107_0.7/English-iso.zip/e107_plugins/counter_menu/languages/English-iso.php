<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/counter_menu/languages/English-iso.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:51 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
	
define("COUNTER_L1", "Admin visits aren't being counted.");
define("COUNTER_L2", "This page today ...");
define("COUNTER_L3", "total");
define("COUNTER_L4", "This page ever ...");
define("COUNTER_L5", "unique");
define("COUNTER_L6", "Site ...");
define("COUNTER_L7", "Counter");
define("COUNTER_L8", "Admin message: <b>Stat logging is disabled.</b><br />To activate, you need to install the Statistic Logging plugin from your <a href='".e_ADMIN."plugin.php'>plugin manager</a>, then activate it from the <a href='".e_PLUGIN."log/admin_config.php'>configuration screen</a>.");
	
?>