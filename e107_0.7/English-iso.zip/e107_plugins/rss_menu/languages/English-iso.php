<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/rss_menu/languages/English-iso.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:57:11 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " can be syndicated by using these rss feeds.");
define("BACKEND_MENU_L2", "RSS Feeds");

define("BACKEND_MENU_L3", "Our news");
define("BACKEND_MENU_L4", "Our comments");
define("BACKEND_MENU_L5", "Our forum threads");
define("BACKEND_MENU_L6", "Our forum posts");

define("BACKEND_MENU_L7", "Our chatbox posts");
define("BACKEND_MENU_L8", "Our bugtracker reports");
define("BACKEND_MENU_L9", "Our downloads");

define("RSS_LAN01", "Enable seperate feeds for each news category?");
define("RSS_LAN02", "Enable seperate feeds for each download category?");
?>