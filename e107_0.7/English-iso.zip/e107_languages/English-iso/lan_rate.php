<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "vote");
define("RATELAN_1", "votes");
define("RATELAN_2", "how do you rate this item?");
define("RATELAN_3", "thank you for your vote");
define("RATELAN_4", "not rated");
define("RATELAN_5", "Rate");

?>