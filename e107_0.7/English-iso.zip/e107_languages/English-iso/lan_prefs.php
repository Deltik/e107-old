<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/lan_prefs.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 03:40:33 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 powered website");
define("LAN_PREF_2", "e107 website system");
define("LAN_PREF_3", "All trademarks are � their respective owners, all other content is � e107 powered website.<br />e107 is � e107.org 2002-2005 and is released under the <a href=\"http://www.gnu.org/\" rel=\"external\">GNU GPL license</a>.");
define("LAN_PREF_4", "censored");
define("LAN_PREF_5", "Forums");

?>