<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/admin/lan_cpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Title");
define("CUSLAN_2", "Type");
define("CUSLAN_3", "Options");
define("CUSLAN_4", "Delete this page?");
define("CUSLAN_5", "Existing Pages");
define("CUSLAN_7", "Menu Name");
define("CUSLAN_8", "Title / Caption");
define("CUSLAN_9", "Text");
define("CUSLAN_10", "Allow page to be rated");
define("CUSLAN_11", "Front page");
define("CUSLAN_12", "Create page");
define("CUSLAN_13", "Allow comments");
define("CUSLAN_14", "Password protect page");
define("CUSLAN_15", "enter password to protect page");
define("CUSLAN_16", "Create link in main menu");
define("CUSLAN_17", "enter link name to create");
define("CUSLAN_18", "Page / link visible to");
define("CUSLAN_19", "Update Page");
define("CUSLAN_20", "Create Page");
define("CUSLAN_21", "Update Menu");
define("CUSLAN_22", "Create Menu");
define("CUSLAN_23", "Edit page");
define("CUSLAN_24", "Create new page");
define("CUSLAN_25", "Edit menu");
define("CUSLAN_26", "Create new menu");
define("CUSLAN_27", "Page saved to database.");
define("CUSLAN_28", "Page deleted");
define("CUSLAN_29", "List pages if no page selected");
define("CUSLAN_30", "Expiry time for cookie (in seconds)");
define("CUSLAN_31", "Create menu");
define("CUSLAN_32", "Convert old pages/menus");
define("CUSLAN_33", "Page Options");
define("CUSLAN_34", "Beginning conversion");
define("CUSLAN_35", "Finished custom page update - updated");
define("CUSLAN_36", "To set your preferences for each page, please return to front page and edit the pages.");
define("CUSLAN_37", "Custom Page Update");
define("CUSLAN_38", "on");
define("CUSLAN_39", "off");
define("CUSLAN_40", "Save Options");

define("CUSLAN_41", "Display author and date information");
define("CUSLAN_42", "No pages defined yet");

?>