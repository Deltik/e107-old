<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/admin/lan_meta.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags updated in database");
define("METLAN_2", "Enter meta-tags");
define("METLAN_3", "Enter new meta tag settings");
define("METLAN_4", "Updated");
define("METLAN_5", "type your description here");
define("METLAN_6", "type, a, list, of, your, keywords, here");
define("METLAN_7", "type your copyright info here");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "description");
define("METLAN_10", "keywords");
define("METLAN_11", "copyright");

?>