<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/admin/lan_userinfo.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Unable to find poster's IP address - no information is available.");
// define("USFLAN_2", "Error");
define("USFLAN_3", "Messages posted from IP address");
define("USFLAN_4", "Host");
define("USFLAN_5", "Click here to transfer IP address to admin ban page");
define("USFLAN_6", "UserID");
define("USFLAN_7", "User Information");

?>