<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/admin/lan_credits.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Credits");
define("CRELAN_2", "Here is a list of third-party software / resources used in e107. The e107 development team would like to personally thank the developers of the following for allowing us to redistribute their code with e107, and for releasing their software under the GPL licence.");
// define("CRELAN_3", "Resource");
// define("CRELAN_4", "Description");
// define("CRELAN_5", "Website");
// define("CRELAN_6", "Permission");
define("CRELAN_7", "version");



?>