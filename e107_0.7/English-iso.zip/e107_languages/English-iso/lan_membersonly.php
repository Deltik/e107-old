<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/lan_membersonly.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Members Only");

define("LAN_MEMBERS_0", "restricted area");
define("LAN_MEMBERS_1", "This is a restricted area");
define("LAN_MEMBERS_2","to access it either <a href='login.php'>log in</a> or");
define("LAN_MEMBERS_3","register as a member");
define("LAN_MEMBERS_4","Click here to return to front page");

?>