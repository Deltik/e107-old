<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English-iso/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:56:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Everyone (public)");
define("UC_LAN_1", "Guests");
define("UC_LAN_2", "No One (inactive)");
define("UC_LAN_3", "Members");
define("UC_LAN_4", "Read Only");
define("UC_LAN_5", "Admin");
?>