<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/human_condition/languages/English-iso.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/08/24 00:57:11 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' by <a href='http://e107.org' rel='external'>jalist</a>, based on the Wordpress theme, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Comments are turned off for this item");
define("LAN_THEME_3", "comment(s): ");
define("LAN_THEME_4", "Read the rest ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Comment by");


?>
