/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.2 2005/12/24 00:09:57 e107coders Exp $ 
 */  

tinyMCE.addToLang('',{
iespell_desc : 'Spustit kontrolu pravopisu',
iespell_download : "ieSpell nedetekován. Klikněte na OK a otevřete stahovací stránku."
});

