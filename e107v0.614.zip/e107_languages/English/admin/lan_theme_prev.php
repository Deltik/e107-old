<?php

define("TPVLAN_1", "This is a Theme Test Page");
define("TPVLAN_2", "This theme is active for this page only. Links below will not work.");
define("TPVLAN_3", "Preferences");
define("TPVLAN_4", "Preview More Themes");
define("TPVLAN_5", "Preview Site Themes");
define("TPVLAN_6", "Preview");
define("TPVLAN_7", "Preview Theme");
define("TPVLAN_8", "This theme is active for this page only. Links below will not work.");
define("TPVLAN_9", "Preview More Themes");
define("TPVLAN_10", "Click Submit to set as site theme. ");
define("TPVLAN_11", "info");
define("TPVLAN_12", "Theme preferences saved.");
define("TPVLAN_13", "Theme");
define("TPVLAN_13", "Submit");

?>