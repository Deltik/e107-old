<?php

define("LAN_UPDATE_1", "Update");
define("LAN_UPDATE_2", "Action");
define("LAN_UPDATE_3", "Not Needed");
define("LAN_UPDATE_4", "Update");
define("LAN_UPDATE_5", "Update(s) available");
define("LAN_UPDATE_6", "Update all");
define("LAN_UPDATE_7", "Executing");
define("LAN_UPDATE_8", "Update from");
define("LAN_UPDATE_9", "to");
define("LAN_UPDATE_10", "Available updates");

?>