<?php

define("USFLAN_1", "Unable to find poster's IP address - no information is available.");
define("USFLAN_2", "Error");
define("USFLAN_3", "Messages posted from IP address");
define("USFLAN_4", "Host");
define("USFLAN_5", "Click here to transfer IP address to admin ban page");
define("USFLAN_6", "UserID");
define("USFLAN_7", "User Information");

?>