<?php

define("PAGE_NAME", "Old Surveys");

define("LAN_92", "Old Surveys");
define("LAN_93", "No old polls yet.");
define("LAN_94", "Posted by");
define("LAN_95", "Total votes:");
define("LAN_96", "Polls");
define("LAN_97", "Show Comments");

define("LAN_98", "Poll");
define("LAN_99", "Active from ");
define("LAN_100", " to ");

?>