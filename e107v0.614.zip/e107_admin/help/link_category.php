<?php
$text = "You can seperate your links into different categories, this makes navigating the main Links page much easier and improves layout.<br /><br />Any link entered under the Main category will be displayed in your main navigation menu.";
$ns -> tablerender("Link Category Help", $text);
?>