0.7.0 -> 0.7.1 Upgrade Guide

This small update to 0.7.0 addresses several bugs along with a couple of new features.
To install simply upload the files to your server overwriting the existing 0.7.0 files.
There are no database changes in this release so no update button will show.

Fixes:
Allowed file-types corrected.
Fix for Chatbox Encoding Issues with ajax. (Bug #2169)
Version Number in admin fixed. (Bug #2182)
News Archive Title backslashes fixed. (Bug #2183)
Kubrick Theme Fixed. (Bug #2164 thanks whoisrich)
Fix for PM (Bug #2168)
Forum-post redirection fixed. (Bug #2171)
comma is no longer a stop character in a link (Bug #2172)
Wysiwyg is checking perms correctly now. (Bug #1884)
Corrections to the credits.
Fix for TinyMce entity encoding.

Enhancements:
Admin frontpage now searches for potential malicious scripts.
Html posting can now be disabled completely in admin/prefs
favicon.ico can now be used in the theme folder to override the default one..avoiding loss when upgrading e107. 