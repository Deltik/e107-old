<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Site temporarily closed");
define("LAN_SITEDOWN_00", "is temporarily closed");
define("LAN_SITEDOWN_01", "We have temporarily closed the site for some essential maintenance. This shouldn't take too long - please check back soon, apologies for the inconvenience.");
?>
