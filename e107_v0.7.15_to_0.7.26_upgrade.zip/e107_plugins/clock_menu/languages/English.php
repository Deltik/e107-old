<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/clock_menu/languages/English.php $
|     $Revision: 11678 $
|     $Id: English.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', 'Clock menu configuration saved');
define('CLOCK_MENU_L2', 'Caption');
define('CLOCK_MENU_L3', 'Update Menu Settings');
define('CLOCK_MENU_L4', 'Clock Menu Config');
define('CLOCK_MENU_L5', 'Monday,');
define('CLOCK_MENU_L6', 'Tuesday,');
define('CLOCK_MENU_L7', 'Wednesday,');
define('CLOCK_MENU_L8', 'Thursday,');
define('CLOCK_MENU_L9', 'Friday,');
define('CLOCK_MENU_L10', 'Saturday,');
define('CLOCK_MENU_L11', 'Sunday,');
define('CLOCK_MENU_L12', 'January');
define('CLOCK_MENU_L13', 'February');
define('CLOCK_MENU_L14', 'March');
define('CLOCK_MENU_L15', 'April');
define('CLOCK_MENU_L16', 'May');
define('CLOCK_MENU_L17', 'June');
define('CLOCK_MENU_L18', 'July');
define('CLOCK_MENU_L19', 'August');
define('CLOCK_MENU_L20', 'September');
define('CLOCK_MENU_L21', 'October');
define('CLOCK_MENU_L22', 'November');
define('CLOCK_MENU_L23', 'December');
define('CLOCK_MENU_L24', '');
?>