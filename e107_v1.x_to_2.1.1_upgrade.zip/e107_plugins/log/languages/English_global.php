<?php
// e107 Global Log File for the Log Plugin. 
// All Defined Must include the folder of the plugin. LAN_PLUGIN_{FOLDER}

define("LAN_PLUGIN_LOG_NAME",			"Site Stats");
define("LAN_PLUGIN_LOG_DESCRIPTION", 	"This plugin will log all visits to your site, and build detailed statistic screens based on the information gathered.");
define("LAN_PLUGIN_LOG_CONFIGURE",		"Configure Statistics Logging"); 
define("LAN_PLUGIN_LOG_LINK", 			"Visits");

?>