<?php
/**
 * Copyright (C) e107 Inc (e107.org), Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
 * $Id$
 * 
 * News menu language file
 */
	
define("TD_MENU_L1", "Other News");
define("TD_MENU_L2", "Other News");

define("LAN_NEWSCAT_MENU_TITLE", "News Categories");
define("LAN_NEWSLATEST_MENU_TITLE", "Latest News");
define("LAN_NEWSARCHIVE_MENU_TITLE", "News Archive");

?>