<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system English Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|        Last Modified: 2017/02/18 11:38:44
|
|        $Author: Yesszus $
+---------------------------------------------------------------+
*/
define("TMCEALAN_1", "Paste as text by default");
define("TMCEALAN_2", "Browser spellcheck");
define("TMCEALAN_3", "Enable this if the browser internal spellchecker should be used.");
define("TMCEALAN_4", "Visual Blocks");
define("TMCEALAN_5", "Enable to make html blocks visible during editing.");
define("TMCEALAN_6", "Code-Highlight CSS class.");

