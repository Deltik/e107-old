<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_userclass2.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Cleared all users from class.");
define("UCSLAN_2", "Class users updated.");
define("UCSLAN_3", "Class deleted.");
define("UCSLAN_4", "Please tick the confirm box to delete this user class");
define("UCSLAN_5", "Class updated.");
define("UCSLAN_6", "Class saved to database.");
define("UCSLAN_7", "No user classes yet.");
define("UCSLAN_8", "Existing Classes");

// define("UCSLAN_9", "Edit");
// define("UCSLAN_10", "Delete");
define("UCSLAN_11", "tick to confirm");
define("UCSLAN_12", "Class Name");
define("UCSLAN_13", "Class Description");
define("UCSLAN_14", "Update User Class");
define("UCSLAN_15", "Create New Class");
define("UCSLAN_16", "Assign users to class");
define("UCSLAN_17", "Remove");
define("UCSLAN_18", "Clear Class");
define("UCSLAN_19", "Assign users to");
define("UCSLAN_20", "class");
define("UCSLAN_21", "User Class Settings");

define("UCSLAN_22", "Users - click to move ...");
define("UCSLAN_23", "Users in this class ...");

define("UCSLAN_24", "Who can manage class");


?>