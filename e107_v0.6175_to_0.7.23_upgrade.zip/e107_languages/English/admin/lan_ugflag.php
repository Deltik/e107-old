<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_ugflag.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define('UGFLAN_1', 'maintenance setting updated');
define('UGFLAN_2', 'Activate maintenance flag');
define('UGFLAN_3', 'Update Maintenance Setting');
define('UGFLAN_4', 'Maintenance Setting');

define('UGFLAN_5', 'Text to display when site down');
define('UGFLAN_6', 'Leave blank to display default message');

define('UGFLAN_8', 'Limit access to Admins only');
define('UGFLAN_9', 'Limit access to Main-Admins only');

?>