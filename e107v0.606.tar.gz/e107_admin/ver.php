<?php

$e107info['e107_version'] = "v0.606";
$e107info['e107_build'] = "0";

?>