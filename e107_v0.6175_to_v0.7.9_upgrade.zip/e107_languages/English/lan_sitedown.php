<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/31 21:16:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Site temporarily closed");
define("LAN_SITEDOWN_00", "is temporarily closed");
define("LAN_SITEDOWN_01", "We have temporarily closed the site for some essential maintenance. This shouldn't take too long - please check back soon, apologies for the inconvenience.");
?>
