<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Ban removed.");
define("BANLAN_2", "No bans.");
define("BANLAN_3", "Existing Bans");
define("BANLAN_4", "Remove ban");
define("BANLAN_5", "Enter IP, email address, or host");
define("BANLAN_7", "Reason");
define("BANLAN_8", "Ban Address");
define("BANLAN_9", "Ban users from site by email, IP or host address");
define("BANLAN_10", "IP / Email / Reason");
define("BANLAN_11", "Auto-ban: More than 10 failed login attempts");
define("BANLAN_12", "Note: Reverse DNS is currently disabled, it must be enabled to allow banning by host.  Banning by IP and email will still function normally.");
define("BANLAN_13", "Note: To ban a user by user name, go to the users admin page: ");
define('BANLAN_78','Hit count exceeded (--HITS-- requests within allotted time)');

?>