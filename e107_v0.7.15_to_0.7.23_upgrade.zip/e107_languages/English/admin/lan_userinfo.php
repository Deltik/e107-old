<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_userinfo.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 12:56:14 -0600 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Unable to find poster's IP address - no information is available.");
// define("USFLAN_2", "Error");
define("USFLAN_3", "Messages posted from IP address");
define("USFLAN_4", "Host");
define("USFLAN_5", "Click here to transfer IP address to admin ban page");
define("USFLAN_6", "User ID");
define("USFLAN_7", "User Information");

?>