<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_parser_functions.php,v $
|     $Revision: 11634 $
|     $Date: 2010-07-30 04:30:59 -0500 (Fri, 30 Jul 2010) $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Guest");
define("LAN_WROTE", "wrote"); // as in John wrote.."  ";


?>