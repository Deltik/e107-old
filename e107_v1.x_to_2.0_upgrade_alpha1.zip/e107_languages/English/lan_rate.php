<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.8/e107_languages/English/lan_rate.php,v $
|     $Revision$
|     $Date$
|     $Author$
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "Vote");
define("RATELAN_1", "Votes");
define("RATELAN_2", "How do you rate this item?");
define("RATELAN_3", "Thanks for voting!");
define("RATELAN_4", "Not rated");
define("RATELAN_5", "Rate this:");
define("RATELAN_6",	"Please login to rate this.");

define("RATELAN_POOR","Poor");
define("RATELAN_FAIR","Fair");
define("RATELAN_GOOD","Good");
define("RATELAN_VERYGOOD","Very Good");
define("RATELAN_EXCELLENT","Excellent");


?>