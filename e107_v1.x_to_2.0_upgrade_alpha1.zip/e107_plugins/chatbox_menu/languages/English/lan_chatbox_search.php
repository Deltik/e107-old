<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.8/e107_plugins/chatbox_menu/languages/English/lan_chatbox_search.php,v $
|     $Revision$
|     $Date$
|     $Author$
+----------------------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");

?>