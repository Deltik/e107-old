<?php


define("LAN_PLUGIN_CHATBOX_MENU_NAME",		 	"Chatbox");
define("LAN_PLUGIN_CHATBOX_MENU_DESCRIPTION", 	"Chatbox Menu");

// Admin Log 
define("LAN_AL_CHBLAN_01","Chatbox settings updated");
define("LAN_AL_CHBLAN_02","Chatbox pruned");
define("LAN_AL_CHBLAN_03","Chatbox posts recalculated");
define("LAN_AL_CHBLAN_04","");
define("LAN_AL_CHBLAN_05","");


?>