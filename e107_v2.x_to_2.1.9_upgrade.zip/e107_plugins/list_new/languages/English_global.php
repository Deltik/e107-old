<?php
/*
* Copyright (c) e107 Inc 2009 - e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $Id$
*
* 'List new items' global language defines
*/

define("LAN_PLUGIN_LIST_NEW_NAME", "List New Items");
define("LAN_PLUGIN_LIST_NEW_DESCRIPTION", "This plugin allows you to view a list and/or menu of recent additions in all e107 categories. You can either view the list with data since your last visit, or view a general latest additions list.");
