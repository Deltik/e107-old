<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_equery_secure.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "You are being redirected to an admin function, possible database modifications could occur");
define("EQSEC_LAN2", "Please confirm this action:");
define("EQSEC_LAN3", "No referrer");
define("EQSEC_LAN4", "Action from:");
define("EQSEC_LAN5", "Action to:");
define("EQSEC_LAN6", "Confirm action");
define("EQSEC_LAN7", "Or cancel");
?>