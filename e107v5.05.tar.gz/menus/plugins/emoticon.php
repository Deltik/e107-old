<?php
$text .= wad("emoticon_conf.php", "Emoticons", "Convert text smileys into image smileys", "0.1.2");
?>