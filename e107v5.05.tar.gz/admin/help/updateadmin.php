<?php
$text = "Update your name, email and password here.";
$ns -> tablerender("Update Settings Help", $text);
?>