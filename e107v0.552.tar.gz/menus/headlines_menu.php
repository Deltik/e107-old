<?php
require_once(e_BASE."plugins/headlines.php");
?>