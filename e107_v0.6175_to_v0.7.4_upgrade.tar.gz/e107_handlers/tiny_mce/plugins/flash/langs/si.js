// SI lang variables ISO-8859-2

tinyMCE.addToLang('flash',{
title : 'Vstavi/uredi Flash film',
desc : 'Vstavi/uredi Flash film',
file : 'Flash datoteka (.swf)',
size : 'Velikost',
list : 'Flash datoteke',
props : 'Lastnosti',
general : 'Splo&#353;no'
});
