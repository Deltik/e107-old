<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_footer.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Head Admin");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Admin Theme");
define("FOOTLAN_6", "by");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Install date");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP Version");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Site Info");
define("FOOTLAN_14", "Show Docs");
define("FOOTLAN_15", "Documentation");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "Site Theme");

?>