<?php
/*
* Copyright e107 Inc e107.org, Licensed under GNU GPL (http://www.gnu.org/licenses/gpl.txt)
* $URL: https://e107.svn.sourceforge.net/svnroot/e107/tags/e107_v07_20_release/e107_admin/ver.php $
* $Id: ver.php 11480 2010-04-16 02:46:29Z mcfly_e107 $
*
* Version file
*/

if (!defined('e107_INIT')) { exit; }

$e107info['e107_version'] = "0.7.20";
?>
