<?php

define("ARLAN_0", "Thankyou, your article has been saved and will be reviewed by a site administrator in due course.");
define("ARLAN_1", "Fields left blank.");
define("ARLAN_2", "Thankyou, your review has been saved and will be reviewed by a site administrator in due course.");
define("ARLAN_15", "Submit Article");
define("ARLAN_17", "Heading");
define("ARLAN_18", "Sub-Heading");
define("ARLAN_19", "Summary");
define("ARLAN_20", "Article");
define("ARLAN_21", "Allow comments?");
define("ARLAN_22", "On");
define("ARLAN_23", "Off");
define("ARLAN_24", "Add email/print icons?");
define("ARLAN_25", "Yes");
define("ARLAN_26", "No");
define("ARLAN_27", "Submit Article");
define("ARLAN_28", "Preview");
define("ARLAN_55", "Visible to");
define("ARLAN_73", "Open HTML Editor");
define("ARLAN_74", "Category");
define("ARLAN_75", "None");
define("ARLAN_82", "Author Details");
define("ARLAN_84", "author name");
define("ARLAN_85", "author email address");


define("ARLAN_86", "Review");

define("ARLAN_87", "Rating");
define("ARLAN_88", "Please select rating");
define("ARLAN_89", "Submit Review");
?>