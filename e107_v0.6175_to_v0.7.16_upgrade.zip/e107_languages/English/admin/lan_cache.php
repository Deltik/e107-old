<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Cache System Status");
define("CACLAN_2", "Set cache status");
define("CACLAN_3", "Cache System");
define("CACLAN_4", "Cache status set");
define("CACLAN_5", "Empty Cache");
define("CACLAN_6", "Cache Emptied");

define("CACLAN_7", "Cache Disabled");
// define("CACLAN_8", "Cache data saved to MySQL");
define("CACLAN_9", "Cache data saved to disk file");
define("CACLAN_10", "The cache directory is not writable. Please ensure this directory is set CHMOD 0777");
?>