<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "maintenance setting updated");
define("UGFLAN_2", "Activate maintenance flag");
define("UGFLAN_3", "Update Maintenance Setting");
define("UGFLAN_4", "Maintenance Setting");

define("UGFLAN_5", "Text to display when site down");
define("UGFLAN_6", "Leave blank to display default message");

?>