<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: mrpete $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Printer Friendly");

define("LAN_86", "Category:");
define("LAN_87", "by ");
define("LAN_94", "Posted by");
define("LAN_135", "News Item: ");
define("LAN_303", "This news item is from ");
define("LAN_304", "Title: ");
define("LAN_305", "Subheading: ");
define("LAN_306", "This is from: ");
define("LAN_307", "Print this page");

?>