// UK lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Indsæt smiley';
tinyMCELang['lang_emotions_desc'] = 'Smileys';