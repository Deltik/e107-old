/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.1 2005/12/24 00:09:57 e107coders Exp $ 
 */  

tinyMCE.addToLang('',{
iespell_desc : 'Spustiť kontrolu pravopisu',
iespell_download : "ieSpell nedetekovaný Kliknite na OK a otvorte stahovaciu stránku."
});

