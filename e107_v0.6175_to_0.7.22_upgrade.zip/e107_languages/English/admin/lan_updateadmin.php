<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_updateadmin.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Error - please re-submit");
define("UDALAN_2", "Settings updated");
define("UDALAN_3", "Settings updated for");
define("UDALAN_4", "Name");
define("UDALAN_5", "Password");
define("UDALAN_6", "Re-type password");
define("UDALAN_7", "Change password");
define("UDALAN_8", "Password updated for");

?>