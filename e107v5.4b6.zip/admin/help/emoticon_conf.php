<?php

$text = "Tick the box to have text emoticons replaced by image emoticons.";

$ns -> tablerender("Emoticon Help", $text);
?>