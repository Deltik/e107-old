<?php

define("PAGE_NAME", "Upload");

define("LAN_20", "Error");
define("LAN_61", "Your Name: ");
define("LAN_112", "Email Address: ");
define("LAN_144", "Website URL: ");
define("LAN_402", "You must be a registered member to upload files to this server.");
define("LAN_403", "You do not have the correct permissions to upload files to this server.");
define("LAN_404", "Thankyou. Your upload will be reviewed by an administrator and posted to the site if appropriate.");
define("LAN_405", "File exceeds specified maximum size limit - deleted.");
define("LAN_406", "<b>Please note</b><br />Allowed filetypes:");
define("LAN_407", "Any other filetypes uploaded will be instantly deleted.");
define("LAN_408", "<u>Underlined</u> fields are required");
define("LAN_409", "Name of file");
define("LAN_410", "Version");
define("LAN_411", "File");
define("LAN_412", "Screenshot");
define("LAN_413", "Description");
define("LAN_414", "Working demo");
define("LAN_415", "enter URL to site where demo can be viewed");
define("LAN_416", "Submit and Upload");
define("LAN_417", "Upload File");

?>