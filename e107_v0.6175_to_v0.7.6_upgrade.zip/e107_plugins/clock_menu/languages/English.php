<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', 'Clock menu configuration saved');
define('CLOCK_MENU_L2', 'Caption');
define('CLOCK_MENU_L3', 'Update Menu Settings');
define('CLOCK_MENU_L4', 'Clock Menu Config');
define('CLOCK_MENU_L5', 'Monday,');
define('CLOCK_MENU_L6', 'Tuesday,');
define('CLOCK_MENU_L7', 'Wednesday,');
define('CLOCK_MENU_L8', 'Thursday,');
define('CLOCK_MENU_L9', 'Friday,');
define('CLOCK_MENU_L10', 'Saturday,');
define('CLOCK_MENU_L11', 'Sunday,');
define('CLOCK_MENU_L12', 'January');
define('CLOCK_MENU_L13', 'February');
define('CLOCK_MENU_L14', 'March');
define('CLOCK_MENU_L15', 'April');
define('CLOCK_MENU_L16', 'May');
define('CLOCK_MENU_L17', 'June');
define('CLOCK_MENU_L18', 'July');
define('CLOCK_MENU_L19', 'August');
define('CLOCK_MENU_L20', 'September');
define('CLOCK_MENU_L21', 'October');
define('CLOCK_MENU_L22', 'November');
define('CLOCK_MENU_L23', 'December');
define('CLOCK_MENU_L24', '');
?>