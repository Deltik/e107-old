// UK lang variables

tinyMCELang['lang_insert_emoticons_title'] = 'Insert emotion';
tinyMCELang['lang_emoticons_desc'] = 'Emotions';

