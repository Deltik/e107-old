<?php
$DEMO_DOWNLOADS_TITLE = LAN_THEME_DEMO_DOWNLOADS_1;
$DEMO_DOWNLOADS_TMPL = "<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' />  ".LAN_THEME_DEMO_DOWNLOADS_2."
		<div style='text-decoration: none; vertical-align: middle;'>
			<a href='#'>".LAN_THEME_DEMO_DOWNLOADS_3." <img src='".THEME_ABS."images/file.png' alt='' style='width: 24px; height: 24px; vertical-align: middle; padding-top: 0px;' /></a>
		</div>
	</div>
</div>
<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' />  ".LAN_THEME_DEMO_DOWNLOADS_5."
		<div style='text-decoration: none; vertical-align: middle;'>
			<a href='#'>".LAN_THEME_DEMO_DOWNLOADS_3." <img src='".THEME_ABS."images/file.png' alt='' style='width: 24px; height: 24px; vertical-align: middle; padding-top: 0px;' /></a>
		</div>
	</div>
</div>
<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' />  ".LAN_THEME_DEMO_DOWNLOADS_6."
		<div style='text-decoration: none; vertical-align: middle;'>
			<a href='#'>".LAN_THEME_DEMO_DOWNLOADS_3." <img src='".THEME_ABS."/images/file.png' alt='' style='width: 24px; height: 24px; vertical-align: middle; padding-top: 0px;' /></a>
		</div>
	</div>
</div>
<div style='margin: 0 0 10px 0; width: 100%;'>
	<div style='vertical-align: top; width: 100%;'>
		<img src='".THEME_ABS."images/bullet.png' alt='' />  ".LAN_THEME_DEMO_DOWNLOADS_7."
		<div style='text-decoration: none; vertical-align: middle;'>
			<a href='#'>".LAN_THEME_DEMO_DOWNLOADS_3." <img src='".THEME_ABS."images/file.png' alt='' style='width: 24px; height: 24px; vertical-align: middle; padding-top: 0px;' /></a>
		</div>
	</div>
</div>
<small>".LAN_THEME_DEMO_DOWNLOADS_4."</small>
";
?>