// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('flash',{
title : 'Inds&#230;t / rediger Flash-film',
desc : 'Inds&#230;t / rediger Flash-film',
file : 'Flash-Fil (.swf)',
size : 'St&#248;rrelse',
list : 'Flash filer',
props : 'Flash egenskaber',
general : 'Genererelt'
});
