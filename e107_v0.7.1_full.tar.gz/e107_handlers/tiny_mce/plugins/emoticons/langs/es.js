// ES lang variables by Natxo CC

tinyMCELang['lang_insert_emotions_title'] = 'Inserta emoticono';
tinyMCELang['lang_emotions_desc'] = 'Emoticonos';

