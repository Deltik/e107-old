<?php

if (!defined('e107_INIT')) { exit; }

// This file allows changes to be made - including the
// default folder path names

$MySQLPrefix	     = 'e107_';

$ADMIN_DIRECTORY     = "e107_admin/";
$FILES_DIRECTORY     = "e107_files/";
$IMAGES_DIRECTORY    = "e107_images/";
$THEMES_DIRECTORY    = "e107_themes/";
$PLUGINS_DIRECTORY   = "e107_plugins/";
$HANDLERS_DIRECTORY  = "e107_handlers/";
$LANGUAGES_DIRECTORY = "e107_languages/";
$HELP_DIRECTORY      = "e107_docs/help/";
$DOWNLOADS_DIRECTORY = "e107_files/downloads/";

?>