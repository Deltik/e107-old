<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/02 06:14:20 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "Front Page settings updated.");
define("FRTLAN_2", "Set front page for");
define("FRTLAN_6", "Links");
// define("FRTLAN_7", "Content Page");
define("FRTLAN_12", "Update Front Page Settings");
define("FRTLAN_13", "Front Page Settings");
define("FRTLAN_15", "Other (enter url):");
define("FRTLAN_16", "error: no content main parent selected");
define("FRTLAN_17", "error: no content sub category selected");
define("FRTLAN_18", "error: no content item selected");
define("FRTLAN_19", "content main parent");
define("FRTLAN_20", "content category");
define("FRTLAN_21", "content item");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "all users");
define("FRTLAN_27", "Guests");
define("FRTLAN_28", "Members");
define("FRTLAN_29", "Administrators");
define("FRTLAN_31", "All Users");
define("FRTLAN_32", "User Class");
define("FRTLAN_33", "Current Settings");
define("FRTLAN_34", "Page");

?>