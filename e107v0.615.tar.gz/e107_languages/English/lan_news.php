<?php

define("PAGE_NAME", "News");

define("LAN_00", "Please delete install.php from your server ***</b><br />if you do not there is a potential security risk to your website");
define("LAN_82", "News - Category");
define("LAN_83", "No news items yet - please check back soon.");
define("LAN_84", "News Items");
define("LAN_99", "Comments");
define("LAN_100", "On");
define("LAN_307", "Total posts in this category: ");
?>