<?php

define("EMOLAN_1", "Emoticon settings updated.");
define("EMOLAN_2", "Emoticon added.");
define("EMOLAN_3", "Emoticon deleted.");
define("EMOLAN_4", "Activate emoticons?");
define("EMOLAN_5", "Emoticons");
define("EMOLAN_6", "Delete");
define("EMOLAN_7", "Update Emoticon Settings");
define("EMOLAN_8", "Emote code");
define("EMOLAN_9", "Emote image");
define("EMOLAN_10", "Add New Emote");
define("EMOLAN_11", "Emoticon Settings");

?>