<?php

define("CACLAN_1", "Activate cache system");
define("CACLAN_2", "Set cache status");
define("CACLAN_3", "Cache System");
define("CACLAN_4", "Cache status set");
define("CACLAN_5", "Empty Cache");
define("CACLAN_6", "Cache Emptied");

?>