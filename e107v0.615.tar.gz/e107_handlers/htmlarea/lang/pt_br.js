// I18N constants
// Brazilian Portuguese Translation by Alex Piaz <webmaster@globalmap.com>

HTMLArea.I18N = {

	// the following should be the filename without .js extension
	// it will be used for automatically load plugin language.
	lang: "pt_br",

	tooltips: {
		bold:           "Negrito",
		italic:         "It�lico",
		underline:      "Sublinhado",
		strikethrough:  "Tachado",
		subscript:      "Subescrito",
		superscript:    "Sobrescrito",
		justifyleft:    "Alinhar � Esquerda",
		justifycenter:  "Centralizar",
		justifyright:   "Alinhar � Direita",
		justifyfull:    "Justificar",
		orderedlist:    "Lista Numerada",
		unorderedlist:  "Lista Marcadores",
		outdent:        "Diminuir Indenta��o",
		indent:         "Aumentar Indenta��o",
		forecolor:      "Cor da Fonte",
		backcolor:      "Cor do Fundo",
		horizontalrule: "Linha Horizontal",
		createlink:     "Inserir Link",
		insertimage:    "Inserir Imagem",
		inserttable:    "Inserir Tabela",
		htmlmode:       "Ver C�digo-Fonte",
		popupeditor:    "Expandir Editor",
		about:          "Sobre",
		help:           "Ajuda",
		textindicator:  "Estilo Atual"
	}
};
