<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ARTICLE_MENU_L1", "Articles Front Page");
define("ARTICLE_MENU_L2", "Uncategorized");

define("ARTICLE_MENU_L3", "Caption");
define("ARTICLE_MENU_L4", "Number of articles to display");
define("ARTICLE_MENU_L5", "Show article categories in menu?");
define("ARTICLE_MENU_L6", "Title for articles list page:");
define("ARTICLE_MENU_L7", "Articles Menu Configuration");
define("ARTICLE_MENU_L8", "Update Menu Settings");
define("ARTICLE_MENU_L9", "Articles menu configuration saved");
define("ARTICLE_MENU_L10", "Show link to Submit Article");
define("ARTICLE_MENU_L11", "Submit Article");


?>