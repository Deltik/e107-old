<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ADMIN_MENU_L1", "Select ...");
define("ADMIN_MENU_L2", "Admin");

define("ADMIN_MENU_L3", "News");
define("ADMIN_MENU_L4", "Cat�gories News");
define("ADMIN_MENU_L5", "Preferences");
define("ADMIN_MENU_L6", "Menus");
define("ADMIN_MENU_L7", "Administrators");

define("ADMIN_MENU_L8", "Admin settings");
define("ADMIN_MENU_L9", "Forums");
define("ADMIN_MENU_L10", "Articles");
define("ADMIN_MENU_L11", "Content");
define("ADMIN_MENU_L12", "Reviews");

define("ADMIN_MENU_L13", "Links");
define("ADMIN_MENU_L14", "Link Categories");
define("ADMIN_MENU_L15", "Welcome Message");
define("ADMIN_MENU_L16", "Upload");
define("ADMIN_MENU_L17", "Submitted News");

define("ADMIN_MENU_L18", "Banlist");
define("ADMIN_MENU_L19", "Users");
define("ADMIN_MENU_L20", "Maintainance");
define("ADMIN_MENU_L21", "Logout");

?>