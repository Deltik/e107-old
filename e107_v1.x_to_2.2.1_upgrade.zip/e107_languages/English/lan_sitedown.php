<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.8/e107_languages/English/lan_sitedown.php,v $
|     $Revision$
|     $Date$
|     $Author$
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Site temporarily closed");
define("LAN_SITEDOWN_00", "is temporarily closed");
define("LAN_SITEDOWN_01", "We have temporarily closed the site for some essential maintenance. This shouldn't take too long - please check back soon. We apologise for the inconvenience.");
?>
