<?php

define("PAGE_NAME", "Search");

define("LAN_98", "News Items");
define("LAN_99", "Comments");
define("LAN_100", "Articles");
define("LAN_101", "Chatbox");
define("LAN_102", "Links");
define("LAN_103", "Forum");
define("LAN_140", "Registered members");
define("LAN_180", "Search");
define("LAN_190", "Reviews");
define("LAN_191", "Content");
define("LAN_192", "All categories");
define("LAN_193", "Event Calendar");
define("LAN_194", "All Categories");
define("LAN_195", "Searching");
define("LAN_196", "matches");

define("LAN_197", "Downloads");

?>