<?php
$text = "You can arrange where and in which order your menu items are from here. Use the arrows to move the menus up and down until you are satisfied with their positioning.<br />If you find the menus are not updating properly click on the refresh button.";
$ns -> tablerender("Menus Help", $text);
?>