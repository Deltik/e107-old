<?php
$text = "Activate site stats logging from this page. If you are short of server space tick the domain only box as referer logging, this will only log the domain as opposed to the whole url, ie 'jalist.com' instead of 'http://jalist.com/links.php' ";
$ns -> tablerender("Links Help", $text);
?>