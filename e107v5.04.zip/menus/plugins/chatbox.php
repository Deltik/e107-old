<?php
$text .= wad("chatbox_conf.php", "Chatbox", "Configure chatbox", "0.1.2");
?>