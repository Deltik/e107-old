/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.3 2006/03/03 05:07:12 e107coders Exp $ 
 */  

tinyMCE.addToLang('',{
iespell_desc : 'Spustit kontrolu pravopisu',
iespell_download : "ieSpell nedetekován. Klikněte na OK a otevřete stahovací stránku."
});

