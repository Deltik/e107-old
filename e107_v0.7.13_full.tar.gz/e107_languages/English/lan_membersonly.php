<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/06 18:11:26 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Members Only");

define("LAN_MEMBERS_0", "restricted area");
define("LAN_MEMBERS_1", "This is a restricted area.");
define("LAN_MEMBERS_2","For access please <a href='".e_LOGIN."'>log in</a>");
define("LAN_MEMBERS_3","or <a href='".e_SIGNUP."'>register</a> as a member");
define("LAN_MEMBERS_4","Click here to return to front page");


?>