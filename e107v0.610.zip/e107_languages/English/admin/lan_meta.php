<?php

define("METLAN_1", "Meta tags updated in database");
define("METLAN_2", "Enter meta-tags");
define("METLAN_3", "Enter new meta tag settings");

?>