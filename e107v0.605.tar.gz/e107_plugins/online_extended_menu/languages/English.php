<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ONLINE_EL1", "Guests: ");
define("ONLINE_EL2", "Members: ");
define("ONLINE_EL3", "On this page: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Members");
define("ONLINE_EL6", "Newest member");
define("ONLINE_EL7", "viewing");

?>