<?php

define("PAGE_NAME", "Statistics");

define("LAN_124", "Total unique site views: ");
define("LAN_125", "Total site views: ");
define("LAN_126", "Unique views by page: ");
define("LAN_127", "Total views by page: ");
define("LAN_128", "Browser: ");
define("LAN_129", "Operating system: ");
define("LAN_130", "Countries/Domains visited from: ");
define("LAN_131", "Referers: ");
define("LAN_132", "Site Statistics");
define("LAN_371", "Logging is not activated, to activate go to your admin section, click on Logger and tick the Activate Logging/Counter checkbox.");
define("LAN_372", "The features on this page have been disabled.");
define("LAN_373", "No stats yet.");
define("LAN_374", "Logging began:");
define("LAN_375", "View all");
define("LAN_376", "Last 10 unique visitors");
define("LAN_377", "all");
define("LAN_378", "top 10");
define("LAN_379", "Screen resolutions");
define("LAN_418", "days ago");
define("LAN_419", "Daily average");
define("LAN_420", "Weekly average");
define("LAN_421", "Monthly average");
define("LAN_422", "Not calculable yet");

?>