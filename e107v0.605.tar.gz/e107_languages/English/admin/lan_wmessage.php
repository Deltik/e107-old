<?php

define("WMGLAN_1", "Message for Guests");
define("WMGLAN_2", "Message for Members");
define("WMGLAN_3", "Message for Administrators");
define("WMGLAN_4", "Submit");
define("WMGLAN_5", "Set Welcome Message");
define("WMGLAN_6", "Activate?");

?>