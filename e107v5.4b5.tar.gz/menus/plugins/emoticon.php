<?php
$text .= wad("emoticon_conf.php", "Emoticons", "Convert text smileys into image smileys", "P");
?>