<?php
/*
+---------------------------------------------------------------+
|	e107 website system													|
|	language file: english													|
|																						|
|	�Steve Dunstan 2001-2002										|
|	http://jalist.com															|
|	stevedunstan@jalist.com											|
|																						|
|	Released under the terms and conditions of the		|
|	GNU General Public License (http://gnu.org).				|
+---------------------------------------------------------------+
*/

//articles.php/comment.php
define(LAN_0, "[Y�netimce Kapat�ld�]");
define(LAN_1, "Engeli Kald�r");
define(LAN_2, "Engelle");
define(LAN_3, "Sil");
define(LAN_4, "Bilgi");
define(LAN_5, "Yorumlar ...");
define(LAN_6, "Yorum g�nderebilmek i�in kullan�c� ad�n�zla giri� yapmal�s�n�z - e�er hesab�n�z yok ise l�tfen <a href=\"signup.php\">kay�t olun</a>");
define(LAN_7, "�sim: ");
define(LAN_8, "Yorum");
define(LAN_9, "Yorumu g�nder");
define(LAN_10, "Kullan�labilecek ifadeler: [b] [i] [u] [img] [center] [link]<br /> Linkler i�in [link=link text] �rnek Link [/link] �eklinde yaz�n�z. <br /> Sat�r atlama ifadesi (&lt;br /&gt;) sistem taraf�ndan eklenecektir.");

//chat.php
define(LAN_11, "Muhabbet Kutusu (B�t�n �letiler)");
define(LAN_12, "Muhabbet �letileri");

//class.php
define(LAN_13, "Haber silindi.");
define(LAN_14, "Haber veritaban�nda g�ncellendi.");
define(LAN_15, "Haber veritaban�na girildi.");
define(LAN_16, "Kullan�c� Ad�: ");
define(LAN_17, "�ifre: ");
define(LAN_18, "L�tfen giri� yap�n�z");
define(LAN_19, "news.xml dosyas�na yazmak amac� ile eri�ilemiyor. L�tfen /backend dizininin eri�im haklar�n� kontrol ediniz. (eri�in haklar� 'chmod 666' olmal�d�r)");
define(LAN_20, "Hata");
define(LAN_21, "Bug�n ziyaret edilen sayfa say�s�: ");
define(LAN_22, "Bug�ne kadar ziyaret edilen toplam sayfa say�s�: ");
define(LAN_23, "Siteye toplam ziyaret say�s�: ");
define(LAN_24, "fuck|piss|shit|cunt|cock|asshole|motherfucker|mother fucker| arse|pussy|faggot");
define(LAN_25, "�nceki sayfa");
define(LAN_26, "Sonraki sayfa");

//forum.php
define(LAN_27, "Gerekli alanlardan baz�lar�n� bo� b�rakt�n�z");
define(LAN_28, "��eriksiz form gonderdiniz ..");
define(LAN_29, "G�ncellenmi�");
define(LAN_30, "Ho�geldiniz");
define(LAN_31, "Son ziyaretinizden beri yeni ileti yok ");
define(LAN_32, "1 tane yeni ileti var ");
define(LAN_33, "");
define(LAN_34, "yeni ileti var");
define(LAN_35, "");
define(LAN_36, "Siteyi bir onceki ziyaret tarihiniz ");
define(LAN_37, "�u anda saat ");
define(LAN_38, ", b�tun zamanlar GMT'ye g�redir.");
define(LAN_39, "toplam konu.");
define(LAN_40, "toplam ileti.");
define(LAN_41, "En yeni �yemiz: ");
define(LAN_42, "Kay�tl� �yelerimiz: ");
define(LAN_43, "Kay�tl� olmayan ziyaret�iler bu forumlardaki iletileri okuyup kendileri ileti g�nderebilirler, fakat iletiler hakk�nda geni� bilgi almak ve g�nderdi�iniz iletileri daha sonradan de�i�tirebilmek icin sitemizde kay�t olup kullan�ci ad�n�zla giri� yapman�z gerekmektedir. [<a href=\"signup.php\">Kay�t Sayfas�</a>");
define(LAN_44, "Kay�tl� olmayan kullan�c�lar bu forumlari kullanabilirler. IP adresiniz sistemimize kaydedilecektir.");
define(LAN_45, "Bu forumlara sadece kay�tl� ve sisteme giri� yapm�� kullan�c�lar ileti g�nderebilirler. E�er kullan�c� ad�niz yoksa l�tfen <a href=\"signup.php\">kay�t olunuz</a>.");
define(LAN_46, "Forum");
define(LAN_47, "Konular");
define(LAN_48, "Cevaplar");
define(LAN_49, "Son �leti");
define(LAN_50, "Moderat�rler");
define(LAN_51, "Hen�z forum yok, l�tfen daha sonra tekrar deneyiniz.");
define(LAN_52, "Bu b�l�mde hen�z forum yok, l�tfen daha sonra tekrar deneyiniz.");
define(LAN_53, "Konu");
define(LAN_54, "Ba�latan");
define(LAN_55, "Cevaplar");
define(LAN_56, "G�sterilme");
define(LAN_57, "Son �leti");
define(LAN_58, "Bu forumda hen�z hic konu yok.");
define(LAN_59, "Bu forumlara sadece kay�tl� ve sisteme giri� yapm�� kullan�c�lar ileti g�nderebilirler. E�er kullan�c� ad�ni
z yoksa l�tfen <a href=\"signup.php\">kay�t olunuz</a>.");
define(LAN_60, "Yeni Konu Ba�lat");
define(LAN_61, "Ad�n�z: ");
define(LAN_62, "Konu Ba�l���: ");
define(LAN_63, "Metin: ");
define(LAN_64, "Yeni Konuyu G�nder");
define(LAN_65, "Admin tespit edildi - moderasyon moduna ge�ildi.");
define(LAN_66, "Bu konu �u anda kapal�d�r");
define(LAN_67, "iletiler");
define(LAN_68, "d�zenle");
define(LAN_69, "sil");
define(LAN_70, "ta��");
define(LAN_71, "Cevap yok.");
define(LAN_72, "Konuyu ilk a�an");
define(LAN_73, "Cevap: ");
define(LAN_74, "Konuya cevap ver");
define(LAN_75, "Cevap G�nder");
define(LAN_76, "Cevap");
define(LAN_77, "Konuyu G�ncelle");
define(LAN_78, "Cevab� G�ncelle");
define(LAN_79, "Yeni iletiler");
define(LAN_80, "Yeni ileti yok");
define(LAN_81, "Konu kapal�");

//index.php
define(LAN_82, "Haberler - B�l�m");
define(LAN_83, "Hen�z haber yok - l�tfen daha sonra tekrar deneyiniz.");
define(LAN_84, "Haberler");

//links.php
define(LAN_85, "Hen�z link yok.");
define(LAN_86, "Kategori:");
define(LAN_87, "K�sayol tu�u");
define(LAN_88, "Link Verenler:");
define(LAN_89, "Admin: ");
define(LAN_90, "Bu kategoriye yeni link ekle");
define(LAN_91, "Yeni kategori ekle");

//oldpolls.php
define(LAN_92, "Eski Anketler");
define(LAN_93, "Hen�z eski anket yok");
define(LAN_94, "G�nderen");
define(LAN_95, "Toplam oy say�s�");
define(LAN_96, "Anketler");

//search.php
define(LAN_97, "Tan�ma uyan sonu� bulunamad�");
define(LAN_98, "Haberler");
define(LAN_99, "Yorumlar");
define(LAN_100, "Makaleler");
define(LAN_101, "Muhabbet Kutusu"); 
define(LAN_102, "Linkler");
define(LAN_103, "Forumlar");

//signup.php
define(LAN_104, "Kullan�ci ad� baska bir ki�iye kay�tl�, l�tfen ba�ka bir kullan�ci ad� deneyiniz.");
define(LAN_105, "Girdi�iniz iki �ifre birbiriyle ayn� de�il, l�tfen tekrar deneyiniz.");
define(LAN_106, "Ge�ersiz email adresi girdiniz, l�tfen tekrar deneyiniz.");
define(LAN_107, "Te�ekk�rler! �u andan itibaran ".SITENAME." sitesine �yeli�iniz ba�lam��t�r. �ifrenizi kaybetmeniz halinde size bir yenisi verilecektir. Eski �ifrenizin ne oldu�unu y�netimimizin bilme �ans� yoktur. Bu y�zden l�tfen �ifrenizi ezberleyiniz.<br /><br />�u andan itibaren sisteme giri� yapabilirsiniz.");
define(LAN_108, "Kay�t �slemi tamamland�.");
define(LAN_109, "E�er bu siteye kay�t olman�z  bulundu�unuz yerin kanunlar�nca yasaklanm�� ise l�tfen kay�t olmayiniz. Sitemiz bu konuda hi�bir sorumluluk kabul etmeyecektir. <br /><br /> <a href=\"signup.php?stage=1\">Kay�t �slemine ba�lamak i�in t�klay�n</a>.");
define(LAN_110, "Kullan�c� Kayd�");
define(LAN_111, "�ifre (tekrar): ");
define(LAN_112, "Email Adresi: ");
define(LAN_113, "Email Adresiniz Gizlensin mi?: ");
define(LAN_114, "(Bu se�enek email adresinizin gizlenmesini sa�layacakt�r.)");
define(LAN_115, "ICQ Numaras�: ");
define(LAN_116, "AIM Ad�: ");
define(LAN_117, "MSN Ad�: ");
define(LAN_118, "Do�um G�n�n�z: ");
define(LAN_119, "�kamet yeri: ");
define(LAN_120, "�mza: ");
define(LAN_121, "Resim: ");
define(LAN_122, "Zaman Dilimi:");
define(LAN_123, "Kay�t Ol");

//stats.php
define(LAN_124, "Toplam �zg�n site g�r�nt�leme: ");
define(LAN_125, "Total site g�r�nt�leme: ");
define(LAN_126, "Sayfa ba��na �zg�n g�r�nt�lenme : ");
define(LAN_127, "Sayfa bas�na g�r�nt�lenme: ");
define(LAN_128, "Taray�c�: ");
define(LAN_129, "��letim Sistemi: ");
define(LAN_130, "�lkeler/Domainler: ");
define(LAN_131, "Link Verenler: ");
define(LAN_132, "Site �statistikleri");

//submitnews.php
define(LAN_133, "Te�ekk�rler!");
define(LAN_134, "G�ndermi� oldu�unuz haber en k�sa zamanda y�neticilerimiz taraf�ndan incelenip i�leme konacakt�r.");
define(LAN_135, "Haber: ");
define(LAN_136, "Haber G�nder");

//user.php
define(LAN_137, "Kullan�c� kay�ts�z oldu�undan hakk�nda bilgi yok");
define(LAN_138, "Kay�tl� Kullan�c�lar: ");
define(LAN_139, "S�ra: ");
define(LAN_140, "Kay�tl� Kullan�c�lar");
define(LAN_141, "Hen�z kay�tl� kullan�c� yok.");
define(LAN_142, "Kay�tl� �ye");
define(LAN_143, "[kullan�c�n�n iste�iyle gizlenmi�tir]");
define(LAN_144, "Web Sayfa�i URL: ");
define(LAN_145, "Kay�tli Kullan�c�:");
define(LAN_146, "Kay�t tarihinden beri ziyaret say�s�: ");
define(LAN_147, "Muhabbet kutusu iletileri: ");
define(LAN_148, "Yorumlari: ");
define(LAN_149, "Forum iletileri: ");

//usersettings.php
define(LAN_150, "Ayarlar g�ncellendi.");
define(LAN_151, "OK");
define(LAN_152, "Yeni �ifre: ");
define(LAN_153, "Yeni �ifre (tekrar): ");
define(LAN_154, "Ayarlar� G�ncelle");
define(LAN_155, "Kullan�c� Ayarlar�n� G�ncelle");
define(LAN_185, "�ifre alan�n� bo� b�rakt�n�z,");

//plugins
define(LAN_156, "G�nder");
define(LAN_157, "Temizle");
define(LAN_158, "Hen�z ileti yok.");
define(LAN_159, "B�t�n iletileri g�r�nt�le");
define(LAN_160, "Webmaster: ");
define(LAN_161, "Konu Ba�l�klar�");
define(LAN_162, "A��k Anket Yok");
define(LAN_163, "Oy Ver");
define(LAN_164, "Oylar: ");
define(LAN_165, "Eski Anketler");

//menus
define(LAN_166, "Hen�z makale yok.");
define(LAN_167, "Makaleler");
define(LAN_168, "Konu Ba�l�klar�m�z� RSS veya TEXT olarak kendi sitenizde yay�nlayabilirsiniz.");
define(LAN_169, "Teknik Altyap�");
define(LAN_170, "W3C Uyumluluk");
define(LAN_171, "Kullan�c� ID'niz ge�ersiz (kulland���m�z cookie'de bir sorun olabilir)<br />L�tfen<a href=\"index.php?logout\">COOKIE YOK ETME</a> tu�una bas�n�z.");
define(LAN_172, "Sistemden ��k��");
define(LAN_173, "Giri�te hata meydaana geldi.");
define(LAN_174, "Kay�t Olma");
define(LAN_175, "Sisteme giri�");
define(LAN_176, "Bu sayfadaki kullan�c�lar: ");
define(LAN_177, "Sitedeki kullan�c�lar: ");
define(LAN_178, "Sisteme giri� yapm�� kullan�c�lar: ");
define(LAN_179, "Sistem Bilgileri");
define(LAN_180, "Arama");
define(LAN_181, "Bize link verin");
define(LAN_182, "Muhabbet Kutusu");
define(LAN_183, "Ana Men�");
define(LAN_184, "Anket");

// #### Added in v5 #### //

define(LAN_186, "Haber G�nder");
define(LAN_187, "Hangi email adresine g�nderilsin?");
define(LAN_188, "Bu yaz� ile ilgilenebilece�ini d���nd�m, �u siteden al�nti: ");
define(LAN_189, "Sistemin Kalbi: ");
define(LAN_190, "�nceleme");
define(LAN_191, "Bilgi");
define(LAN_192, "Bu forumdaki kullan�c�lar�n g�nderdi�i ileti say�s�: ");
define(LAN_193, "Forum Moderat�r�");
define(LAN_194, "Misafir");
define(LAN_195, "Kay�tl� Kullan�c�");
define(LAN_196, "Bu iletilerin  ");
define(LAN_197, " tanesini okudunuz.");
define(LAN_198, " B�t�n yeni iletiler okundu.");
define(LAN_199, "B�t�n iletileri okunmu� gibi i�aretle");
define(LAN_200, "bu konuyu kapat");
define(LAN_201, "bu konuyu yeniden a�");
define(LAN_202, "Kal�c� Konu");
define(LAN_203, "Kal�c�/Kapal� konu");
define(LAN_204, "Yeni konu <b>ba�latabilirsiniz</b>");
define(LAN_205, "Yeni konu <b>ba�latamazs�n�z</b>");
define(LAN_206, "Konulara <b>cevap verebilirsiniz</b>");
define(LAN_207, "Konulara <b>cevap veremezsiniz</b>");
define(LAN_208, "�letilerinizi <b>g�ncelleyebilirsiniz</b>");
define(LAN_209, "�letilerinizi <b>g�ncelleyemezsiniz</b>");
define(LAN_210, "�letilerinizi <b>silebilirsiniz</b>");
define(LAN_211, "�letilerinizi <b>silemezsiniz</b>");
define(LAN_212, "�ifremi unuttum!");
define(LAN_213, "Girdi�iniz kullan�c� ad� veya email adresi sistemimizde bulunamad�!");
define(LAN_214, "Yeni �ifre g�nderiminde bir hata meydana geldi.");
define(LAN_215, SITENAME."�ifreniz de�i�tirildi. Yeni �ifreniz \n\n");
define(LAN_216, "Yeni �ifrenizi onaylamak i�in bu adrese gidiniz  ...");
define(LAN_217, "Te�ekk�rler. Yeni �ifreniz onayland�. Sitemize giri� yapabilirsiniz.");


?>
