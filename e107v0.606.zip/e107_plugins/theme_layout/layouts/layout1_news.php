<?php

$newsstyle = "
<div class='border'>
<div class='caption'>
<b>
{NEWSTITLE}
</b>
</div>
<div class='bodytable'>
<div style='text-align:left'>
{NEWSBODY}
{NEWSSOURCE}
{NEWSURL}
{EXTENDED}
<div style='text-align:right'>
{EMAILICON}
{PRINTICON}
{ADMINOPTIONS}
</div>
</div>
</div>
Posted by 
{NEWSAUTHOR}
on
{NEWSDATE}
&nbsp;::&nbsp;
{NEWSCOMMENTS}
</div>
<br />
";

?>