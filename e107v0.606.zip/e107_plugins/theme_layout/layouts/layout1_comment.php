<?php

$commentstyle = "
<table style='width:95%'>
<tr>
<td style='width:30%; vertical-align:top'>
<img src='".THEME."images/bullet2.gif' alt='bullet' /> 
<b>
{USERNAME}
</b>
<div class='spacer'>
{AVATAR}
</div>
<span class='smalltext'>
{COMMENTS}
<br />
{JOINED}
</span>
</td>
<td style='width:70%; vertical-align:top'>
<span class='smalltext'>
{TIMEDATE}
</span>
<br />
{COMMENT}
<br /><i><span class='smalltext'>
{SIGNATURE}
</span></i>
<br />
<div class='smalltext'>
{ADMINOPTIONS}
</div>
</td>
</tr>
</table>
<br />";

?>