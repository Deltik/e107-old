<?php

define("NCLAN_1", "Category added to database.");
define("NCLAN_2", "Categories updated.");
define("NCLAN_3", "Category deleted.");
define("NCLAN_4", "Please confirm you wish to delete the");
define("NCLAN_5", "news category - once deleted it cannot be retrieved");
define("NCLAN_6", "Cancel");
define("NCLAN_7", "Confirm Delete");
define("NCLAN_8", "Confirm Delete Category");
define("NCLAN_9", "Delete cancelled.");
define("NCLAN_10", "Update Existing Categories");
define("NCLAN_11", "Category Name");
define("NCLAN_12", "Category Icon");
define("NCLAN_13", "Create New News Category");
define("NCLAN_14", "News Categories");
define("NCLAN_15", "Update News Categories");
define("NCLAN_16", "Create New Category");
define("NCLAN_17", "Delete");

?>