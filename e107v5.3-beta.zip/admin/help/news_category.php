<?php
$text = "You can seperate your news items into different categories, and allow visitors to display only the news items in those categories. Just enter the category name, and the path to an image associated with that category. For an example take a look at the Misc category.";
$ns -> tablerender("News Category Help", $text);
?>