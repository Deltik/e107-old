+---------------------------------------------------------------+
|	e107 website system
|	
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+

IMPORTANT!

If you are upgrading from a previous version, make sure when uploading the files that you don't overwrite 
the config.php file in the root directory.

BACK IT UP FIRST BEFORE UPGRADING!

If you didn't and you have overwritten it go to http://e107.org/faq.php?1#faq34 for information.

