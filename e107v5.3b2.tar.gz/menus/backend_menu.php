<?php
$text = "<div style=\"text-align:center\" class=\"smalltext\">
".LAN_168."<br />
<a href=\"backend/news.xml\">news.xml</a> - <a href=\"backend/news.txt\">news.txt</a>
</div>";
$ns -> tablerender(LAN_169, $text);
?>