<?php

define("NWFLAN_1", "Newsfeed added to database.");
define("NWFLAN_2", "Newsfeed updated in database.");
define("NWFLAN_3", "Newsfeed deleted.");
define("NWFLAN_4", "Please tick the confirm box to delete the newsfeed.");
define("NWFLAN_5", "No newsfeeds yet.");
define("NWFLAN_6", "Existing Newsfeeds");
define("NWFLAN_7", "Edit");
define("NWFLAN_8", "Delete");
define("NWFLAN_9", "tick to confirm");
define("NWFLAN_10", "Backend URL");
define("NWFLAN_11", "Path to image");
define("NWFLAN_12", "Display Tagline?");
define("NWFLAN_13", "Display Description?");
define("NWFLAN_14", "Display Webmaster?");
define("NWFLAN_15", "Display Copyright?");
define("NWFLAN_16", "Activate?");
define("NWFLAN_17", "Update Newsfeed");
define("NWFLAN_18", "Add Newsfeed");
define("NWFLAN_19", "Newsfeeds");
define("NWFLAN_20", "No URL entered.");

?>