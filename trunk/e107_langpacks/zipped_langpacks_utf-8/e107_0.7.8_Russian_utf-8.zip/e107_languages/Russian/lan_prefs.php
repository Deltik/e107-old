<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:18 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "Сайт работает на e107");
define("LAN_PREF_2", "Система сайта e107");
define("LAN_PREF_3", "Этот сайт работает на <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, которая распространяется на условиях лицензии <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL.");
define("LAN_PREF_4", "цензура"); //censored
define("LAN_PREF_5", "Форумы");

?>