<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:16 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Электронная почта"); }

define("LAN_EMAIL_1", "От:");
define("LAN_EMAIL_2", "IP отправителя:");
define("LAN_EMAIL_3", "Emailed item from ");
define("LAN_EMAIL_4", "Отправить Email");
define("LAN_EMAIL_5", "Отправить другу с помощью Email");
define("LAN_EMAIL_6", "Я подумал, что Вас заинтересует эта информация с"); //I thought you might be interested in this item from
define("LAN_EMAIL_7", "отпавить с помощью email кому-нибудь");
define("LAN_EMAIL_8", "Комментарий");
define("LAN_EMAIL_9", "К сожалению, произошла ошибка, и письмо не было отправлено");
define("LAN_EMAIL_10", "Письмо отправлено на");
define("LAN_EMAIL_11", "Письмо отправлено");
define("LAN_EMAIL_12", "Ошибка");
define("LAN_EMAIL_13", "Отпавить статью другу с помощью Email");
define("LAN_EMAIL_14", "Отправить новость другу с помощью Email");
define("LAN_EMAIL_15", "Логин: ");
define("LAN_EMAIL_106", "Введен неправильный адрес эл. почты");
define("LAN_EMAIL_185", "Отправить статью");
define("LAN_EMAIL_186", "Отправить новость");
define("LAN_EMAIL_187", "Адрес Email для отправки");
define("LAN_EMAIL_188", "Я думаю, что Вас заинтересует эта новость с сайта");
define("LAN_EMAIL_189", "Я думаю, что Вас заинтересует эта статья на сайте");
define("LAN_EMAIL_190", "Введите изображенный код");


?>