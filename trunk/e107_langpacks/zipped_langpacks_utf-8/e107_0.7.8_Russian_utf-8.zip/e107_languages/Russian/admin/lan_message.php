<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:33 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("MESSLAN_1", "Принятые сообщения");
define("MESSLAN_2", "Удалить сообщение");
define("MESSLAN_3", "Сообщение удалено.");
define("MESSLAN_4", "Удалить все сообщения");
define("MESSLAN_5", "Подтвердите");
define("MESSLAN_6", "Все сообщения удалены.");
define("MESSLAN_7", "Нет сообщений.");
define("MESSLAN_8", "Тип сообщений");
define("MESSLAN_9", "Сообщено");

define("MESSLAN_10", "Сообщил ");
define("MESSLAN_11", "открыть в новом окне");
define("MESSLAN_12", "Сообщение");
define("MESSLAN_13", "Ссылка");


?>