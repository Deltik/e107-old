<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:29 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Действие");
define("LAN_UPDATE_3", "Не требуется");

define("LAN_UPDATE_5", "Обновление доступно");
define("LAN_UPDATE_7", "Выполнено");
define("LAN_UPDATE_8", "Обновить с ");
define("LAN_UPDATE_9", "на");
define("LAN_UPDATE_10", "Возможные обновления");
define("LAN_UPDATE_11", ".617 to .7 Update Continued");
define("LAN_UPDATE_12", "Одна из ваших таблиц содержит дубликаты записей.");

?>