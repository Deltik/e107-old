<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:35 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

// define("WMGLAN_1", "Message for Guests");
// define("WMGLAN_2", "Message for Members");
// define("WMGLAN_3", "Message for Administrators");
// define("WMGLAN_4", "Submit");
// define("WMGLAN_5", "Set Welcome Message");
// define("WMGLAN_6", "Activate?");
// define("WMGLAN_7", "Welcome message settings updated.");

define("WMLAN_00","Приветствия"); //Welcome Messages
define("WMLAN_01","Создать новое"); //Create New Message
define("WMLAN_02","Приветствие"); //Message
define("WMLAN_03","Видимость"); //Visibility
define("WMLAN_04","Текст"); //Message Text

define("WMLAN_05","Заключить в контейнер"); //Enclose
define("WMLAN_06","Если отмечено, сообщение появится внутри блока");
define("WMLAN_07","Отменить стандартную систему для использования {WMESSAGE} кода:");
// define("WMLAN_08","Preferences");

define("WMLAN_09","Еще нет приветственных сообщений");
define("WMLAN_10","Заголовок"); //Message Caption

?>