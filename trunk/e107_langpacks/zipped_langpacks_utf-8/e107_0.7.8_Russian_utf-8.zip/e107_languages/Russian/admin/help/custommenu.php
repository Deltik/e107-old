<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:23 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "В этом окне вы можете создавать персональные меню и персональные страницы.<br /><br />
Пожалуйста, прочитайте <a href='http://docs.e107.org?Custom Pages'>http://docs.e107.org?Custom Pages</a>";

$ns -> tablerender(CUSLAN_18, $text);
?>