<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:28 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("DBLAN_1", "Основные параметры настройки сохранены в БД.");
define("DBLAN_2", "Полное копирование базы");
define("DBLAN_3", "Сохранить БД SQL");
define("DBLAN_4", "Проверка целостности БД");
define("DBLAN_5", "Проверить БД SQL");
define("DBLAN_6", "Оптимизация БД е107");
define("DBLAN_7", "Оптимизировать БД SQL");
define("DBLAN_8", "Резервное копирование БД");
define("DBLAN_9", "Копировать настройки БД");
define("DBLAN_10", "Инструменты базы данных");
define("DBLAN_11", "База данных MySQL");
define("DBLAN_12", "оптимизирована");
define("DBLAN_13", "Назад");
define("DBLAN_14", "Завершить");
define("DBLAN_15", "Нажмите кнопку для проверки доступных обновлений БД");
define("DBLAN_16", "Проверить обновления");
define("DBLAN_17", "Pref. имя");
define("DBLAN_18", "Pref. значение");
define("DBLAN_19", "Нажмите кнопку, чтобы открыть редактор свойств (только для продвинутых пользователей)"); //Click button to open the preferences editor (for advanced users only)
define("DBLAN_20", "Редактор свойств"); //Preferences Editor
define("DBLAN_21", "Удалить выделенные"); //Delete Checked
define("DBLAN_22", "Плагин: Просмотр и сканирование"); //Plugin: View and Scan
define("DBLAN_23", "Сканирование завершено"); //Scan Completed
define("DBLAN_24", "Имя");
define("DBLAN_25", "Каталог");
define("DBLAN_26", "Выключенные add-ons"); //Included add-ons
define("DBLAN_27", "Установлен"); //Installed
define("DBLAN_28", "Нажмите кнопку, чтобы сканировать каталог плагинов на изменения"); //Click button to scan plugin directories for changes
define("DBLAN_29", "Сканировать каталог плагинов"); //Scan plugin directories
define("DBLAN_30", " (Если плагин выдает ошибку, проверьте символы вне тегов открытия/закрытия PHP)");
define("DBLAN_31", "Пройдено"); //CheckIt: Pass
define("DBLAN_32", "Ошибка");
define("DBLAN_33", "Недоступно");
define("DBLAN_34", "Не проверено");

?>