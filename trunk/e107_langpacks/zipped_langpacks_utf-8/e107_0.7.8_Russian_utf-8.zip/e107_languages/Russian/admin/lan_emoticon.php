<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:29 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("EMOLAN_1", "Активировать смайлики");
define("EMOLAN_2", "Имя ");
define("EMOLAN_3", "Эмоции");
define("EMOLAN_4", "Активировать смайлики?");

define("EMOLAN_5", "Изображение");
define("EMOLAN_6", "Код смайлика");
define("EMOLAN_7", "разделить пробелами");

define("EMOLAN_8", "Статус");
define("EMOLAN_9", "Опции");
define("EMOLAN_10", "Активно");
define("EMOLAN_11", "Активировать набор");

define("EMOLAN_12", "Редактировать/настроить набор");
define("EMOLAN_13", "Установленные наборы");

define("EMOLAN_14", "Сохранить настройки");
define("EMOLAN_15", "Редактировать/настроить смайлики");
define("EMOLAN_16", "Настройки смайликов сохранены");
define("EMOLAN_17", "You have an emoticon pack present that contains spaces, which are not allowed !");
define("EMOLAN_18", "please rename the instances listed below so they no longer contain spaces:");
define("EMOLAN_19", "Name");
define("EMOLAN_20", "Location");
define("EMOLAN_21", "Error");
//define("EMOLAN_2", "Name");
define("EMOLAN_22", "Найден новый смайлик пак:");
define("EMOLAN_23", "Найден новый смайлик xml пак:");
define("EMOLAN_24", "Найден новый смайлик php:");
?>
