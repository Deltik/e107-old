<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.2 $
|     $Date: 2007/03/19 11:33:57 $
|     $Author: verant $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "Гостей: ");
define("ONLINE_EL2", "Пользователей: ");
define("ONLINE_EL3", "На этой странице: ");
define("ONLINE_EL4", "В сети: ");
define("ONLINE_EL5", "Пользователей");
define("ONLINE_EL6", "Новый пользователь");
define("ONLINE_EL7", "просмотр");
define("ONLINE_EL8", "рекорд посетителей: ");
define("ONLINE_EL9", "Дата: ");
define("ONLINE_EL10", "Имя пользователя");
define("ONLINE_EL11", "Просмотр страницы");
define("ONLINE_EL12", "Ответить на");
define("ONLINE_EL13", "Форум");
define("ONLINE_EL14", "Тема");
define("ONLINE_EL15", "Страница");
define("CLASSRESTRICTED", "Страница только для определённой группы пользователей");
define("ARTICLEPAGE", "Статьи/Обзоры");
define("CHAT", "Чат");
define("COMMENT", "Комментарии");
define("DOWNLOAD", "Загрузки"); //Downloads
define("EMAIL", "email.php");
define("FORUM", "Главная страница форума");
define("LINKS", "Ссылки");
define("NEWS", "Новости");
define("OLDPOLLS", "Старые опросы");
define("POLLCOMMENT", "Опрос");
define("PRINTPAGE", "Печатать");
define("LOGIN", "Войти в"); //Logging In
define("SEARCH", "Поиск");
define("STATS", "Статистика");
define("SUBMITNEWS", "Добавить новость");
define("UPLOAD", "Загрузки на сервер"); //Uploads
define("USERPAGE", "Профили пользователей");
define("USERSETTINGS", "Настройки пользователей");
define("ONLINE", "Пользователи в сети");
define("LISTNEW", "Посмотреть обновления");
define("USERPOSTS", "Сообщения пользователя");
define("SUBCONTENT", "Разместить статью/обзор");
define("TOP", "Самые активные отправители/наиболее интересные темы");
define("ADMINAREA", "Админцентр");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Список событий");
define("CALENDAR", "Календарь событий");
define("FAQ", "Faq");
define("PM", "Личные сообщения"); //Private Messaging
define("SURVEY", "Форма опроса");
define("ARTICLE", "Статья");
define("CONTENT", "Страница контента");
define("REVIEW", "Обзор");
?>