<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:34:00 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LOGIN_MENU_L1", "Пользователь: ");
define("LOGIN_MENU_L2", "Пароль: ");
define("LOGIN_MENU_L3", "Регистрация");
define("LOGIN_MENU_L4", "Забыли пароль?");
define("LOGIN_MENU_L5", "Добро пожаловать, ");
define("LOGIN_MENU_L6", "Запомнить");
define("LOGIN_MENU_L7", "Уникальный ИД пользователя не опознан (возможно, повреждены cookies).<br />Нажмите <a href=\"".e_BASE."index.php?logout\">сюда</a> для удаления cookie.");
define("LOGIN_MENU_L8", "Выйти");
define("LOGIN_MENU_L9", "Ошибка входа");
define("LOGIN_MENU_L10", "Сайт закрыт на техническое обслуживание. Это означает, что все пользователи будут перенаправлены на страницу sitedown.php. Для активации сайта перейдите в Админцентр/Техническое обслуживание");
define("LOGIN_MENU_L11", "Админцентр");
define("LOGIN_MENU_L12", "Настройки");
define("LOGIN_MENU_L13", "Профиль");

define("LOGIN_MENU_L14", "новость");
define("LOGIN_MENU_L15", "новостей");
define("LOGIN_MENU_L16", "сообщение мини-чата");
define("LOGIN_MENU_L17", "сообщений мини-чата");
define("LOGIN_MENU_L18", "комментарий");
define("LOGIN_MENU_L19", "комментариев");
define("LOGIN_MENU_L20", "сообщение форума");
define("LOGIN_MENU_L21", "сообщений форума");
define("LOGIN_MENU_L22", "новый пользователь");
define("LOGIN_MENU_L23", "новых пользователей");
define("LOGIN_MENU_L24", "Нажмите здесь, для просмотра всех обновлений");
define("LOGIN_MENU_L25", "С вашего последнего посещения");
define("LOGIN_MENU_L26", "нет");
define("LOGIN_MENU_L27", "и");

define("LOGIN_MENU_L28", "Вход");

define("LOGIN_MENU_L29", "новая статья");
define("LOGIN_MENU_L30", "новых статей");

// New config options
define('LOGIN_MENU_L31', 'Показать новые новости');
define('LOGIN_MENU_L32', 'Показать новые статьи');
define('LOGIN_MENU_L33', 'Показать новые сообщения мини-чата');
define('LOGIN_MENU_L34', 'Показать новые комментарии');
define('LOGIN_MENU_L35', 'Показать новые сообщения форума');
define('LOGIN_MENU_L36', 'Показать новые пользователи');
define('LOGIN_MENU_L37', 'Обновить настройки');
define('LOGIN_MENU_L38', 'Настройки обновлены');

define('LOGIN_MENU_L39', 'Покинуть Админцентр'); //Leave Admin

define("LOGIN_MENU_L40", "Активировать снова"); //ReSend Activation Email
define("LOGIN_MENU_L41", "Настройки Меню Входа");
	
?>