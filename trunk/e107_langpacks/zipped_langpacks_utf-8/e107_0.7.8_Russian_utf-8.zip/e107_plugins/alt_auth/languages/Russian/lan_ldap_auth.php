<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:30:48 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LDAPLAN_1", "Адрес сервера");
define("LDAPLAN_2", "BaseDN или Domain<br />Для LDAP - введите BaseDN<br />Для AD - введите Domain");
define("LDAPLAN_3", "Пользователь LDAP<br />Полный контекст пользователя, имеющего права на поиск в директории"); //Full context of the user who is able to search the directory.
define("LDAPLAN_4", "Пароль пользователя LDAP<br />Пароль для пользователя LDAP, имеющего права на поиск в директории.");
define("LDAPLAN_5", "Версия LDAP");
define("LDAPLAN_6", "Настроить LDAP авторизацию");

define("LDAPLAN_7", "Фильтр поиска eDirectory:");
define("LDAPLAN_8", "Будет использоваться, чтобы убедиться, что имя пользователя находится в правильном дереве<br />т. е. '(objectclass=inetOrgPerson)'"); //This will be used to ensure the username is in the correct tree, <br />ie '(objectclass=inetOrgPerson)'
define("LDAPLAN_9", "Текущий фильтр поиска:"); //Current search filter will be

define("LDAPLAN_10", "Настройки обновлены");
define("LDAPLAN_11", "ВНИМАНИЕ: Похоже, что модуль ldap недоступен, установленный вами метод авторизации LDAP скорее всего не будет работать!");
define("LDAPLAN_12", "Тип сервера");
define("LDAPLAN_13", "Обновить настройки");
define("LDAPLAN_14", "Вернуться к основным настройкам alt_auth");
?>
