<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.2 $
|     $Date: 2007/03/19 05:57:52 $
|     $Author: verant $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Комментарии выключены"); //Comments are turned off for this item
define("LAN_THEME_2", "Читать/Добавить комментарий: "); //Read/Post Comment: 
define("LAN_THEME_3", "Читать полностью..."); //Read the rest...
define("LAN_THEME_4", "Трекбеки: "); //Trackbacks: 
define("LAN_THEME_5", "Добавил "); //Posted by
define("LAN_THEME_6", "от "); //on 

?>
