<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.2 $
|     $Date: 2007/03/19 05:57:40 $
|     $Author: verant $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'CraHan' от <a href='http://e107.org' rel='external'>jalist</a>, основано на теме от CraHan <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "комментарии: ");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбеки: ");
define("LAN_THEME_6", "Комментарий");

?>
