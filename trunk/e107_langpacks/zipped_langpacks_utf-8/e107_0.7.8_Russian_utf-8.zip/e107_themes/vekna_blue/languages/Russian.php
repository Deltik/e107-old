<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.2 $
|     $Date: 2007/03/19 05:58:34 $
|     $Author: verant $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'vekna blue' от <a href='http://e107.org' rel='external'>jalist</a>, основано на сайте Arach, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Читать/Добавить комментарий: ");
define("LAN_THEME_3", "Комментарии выключены");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбеки: ");

?>
