<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.2 $
|     $Date: 2007/03/19 05:58:04 $
|     $Author: verant $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' от <a href='http://e107.org' rel='external'>jalist</a>, Основано на теме Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>).");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "комментарии: ");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбеки: ");


?>
