<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.2 $
|     $Date: 2007/03/19 05:58:17 $
|     $Author: verant $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'leaf' от <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "Комментарии: ");
define("LAN_THEME_4", "Читать далее...");
define("LAN_THEME_5", "Трекбеки: ");
define("LAN_THEME_6", "Комментарий от");
define("LAN_THEME_7", "Новости");

?>
