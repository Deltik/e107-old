<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.2 $
|     $Date: 2007/02/27 07:52:51 $
|     $Author: verant $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "Читать/Добавить комментарии: ");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "Читать далее...");
define("LAN_THEME_4", "Добавил"); //Posted by
define("LAN_THEME_5", "на");
define("LAN_THEME_6", "e107.v4 от <a href='http://e107.org' rel='external'>jalist</a>");


?>