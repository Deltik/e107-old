<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 1.1 $
|     $Date: 2007/02/24 18:36:52 $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' от <a href='http://e107.org' rel='external'>jalist</a>, основано на теме Wordpress.org, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "Комментарии: ");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Ссылок: ");
define("LAN_THEME_6", "Комментарий");


?>
