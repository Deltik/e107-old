// RU lang variables UTF-8

tinyMCE.addToLang('',{
iespell_desc : 'Запустить проверку орфографии',
iespell_download : "ieSpell не обнаружен. нажмите OK, чтобы перейти на страницу загрузки."
});

