<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/reline/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/24 19:02:07 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Kommentare sind abgeschalten für diesen Eintrag");
define("LAN_THEME_2", "Lese/Schreibe Kommentare: ");
define("LAN_THEME_3", "Weiterlesen...");
define("LAN_THEME_4", "Trackbacks: ");
define("LAN_THEME_5", "Geschrieben von");
define("LAN_THEME_6", "am");
define("LAN_THEME_7", "Suche...");


?>
