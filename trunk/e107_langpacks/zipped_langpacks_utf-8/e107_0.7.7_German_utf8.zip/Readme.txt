/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language Files.
|     $Developement: DevTeam http://e107.org
|     $German Revision: 1.0 beta $
|     $Date: 2006/11/22 10:44:27 $
|     $Author: judy323, http://www.cms-myway.com, e107de.org
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ ISO encoded $
|     $ utf-8 encoded $
+----------------------------------------------------------------------------+
*/

INHALT:


utf-8 (utf-8 codierte Sprachfiles)


VERSION: 
e107v0.7.6


ANMERKUNG:

Diese Sprachpaket bitte nur verwenden wenn Ihre Seite utf8 codiert ist.
Sie sehen Ihre Seitencodierung unter e107_admin/admin.php --- links unter charset---dort muss utf8 stehen.
Falls Sie die Software neu installiert haben (e107_v0.7.6) k�nnen Sie diesen Punkt �bergehen, da utf8 Codierung vorliegt.
Falls Sie von Vorg�ngerversionen v0.615 upgraden und noch nicht auf utf8 umgestellt haben, bitte dieses Paket nicht verwenden. Bitte dann das iso Paket verwenden. Wobei geraten wird Ihre Seite in Zukunft auf utf8 umzustellen.
Sie finden diesbez�glich Informationen unter: http://www.e107de.org/mediawiki/index.php?title=Upgrading_database_content_to_UTF8

Bitte genau lesen welches Sprachpaket f�r Sie zutrifft und welches Sie dann installieren sollten.


Sollten Sie e107 Neuinstallieren, m�ssen Sie utf-8 codierte Files verwenden.



Installation:

Die Installation ist denkbar einfach.
Unter Beibehaltung der Verzeichnisstruktur bestehende Ordner Via ftp �berschrieben.

Rufen Sie danach

e107_admin/language.php auf und stellen sie die Sprache auf "German"	

Sollten Sie Ihre Seite multilingual gestallten wollen -> auf German- erstellen klicken und dann ausw�hlen welche Tabellen sie multilingual erstellen wollen.

Um sicher zu gehen dass die Sprachfiles korrekt sind, rufen sie bitte
/e107_admin/language.php?tools auf und W�hlen "German" aus.
Ihre Sprachfiles werden nun gescannt.

e107_languages/German
e107_plugins( Deutsche �bersetzungen)
e107_themes (Deutsche �bersetzungen)

Anmerkung:
Wahrscheinlich wird es so sein das es eine Nachricht gibt f�r German.php, die da lautet:

"LC_ALL Phrasen fehlen!"

Dies muss Sie nicht beunruhigen, da diese Datei, speziell dieser Befehl f�r setlocale---also die Ausgabe des Datums in deutscher Sprache verwendet wird und wir diesen angepasst haben (m�sste auf den meisten Servern lauff�hig sein)
Sollten Ihre Datums/Zeitangaben nich richtig dargestellt werden, wenden sie sich bitte an Ihren Host, wie dort mit dem setlocale Befehl umgegangen wird (dies ist von Host zu Host unterschiedlich) oder besuchen Sie http://www.php.net und suchen nach setlocale.

Wir haben den setlocale Befehl in der e107_languages/German.php angepasst auf:
setlocale(LC_ALL, 'de', 'de_DE.utf8', 'de_DE@euro', 'de_DE', 'deu_deu');
im Orginal w�re es
setlocale(LC_ALL, 'de');
was aber meist nicht ausreicht, das Datum richtig in deutsch darzustellen.

Beim Kalender Plugin kann es sein, das auch eine Fehlermeldung kommt die da lautet:
EC_adlan_35
Dies muss sie auch nicht beunruhigen, da es sich um einen leeren Define handelt.
Bearbeiten sie diese Sprachdatei und speichern sie einfach nochmals ab, verschwindet der Fehler.


Wichtig:

Sollten sie upgraden und eventuell Sprachdatein ver�ndert haben, bitte Backup vorher Ihrer Sprachfiles nicht vergessen.

F�r Anmerkungen, Verbesserungsvorschl�ge, Kritik usw bitte e-mail an admin@cms-myway.com