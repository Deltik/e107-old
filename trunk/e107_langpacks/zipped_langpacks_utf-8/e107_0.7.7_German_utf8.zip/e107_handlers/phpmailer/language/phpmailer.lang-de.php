<?php
/**
* PHPMailer language file.
* English Version
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'Es gültiger Empfänger angegeben werden ' . ' .';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer wird nicht unterstützt.';
$PHPMAILER_LANG["execute"] = 'Kann nicht ausführen: ';
$PHPMAILER_LANG["instantiate"] = 'Fehler bei der Mailfunktion.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Fehler: Rechteprobelm.';
$PHPMAILER_LANG["from_failed"] = 'Absenderfehler: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Fehler: Die Empfänger ' . ' erzeugen einen Fehler: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Fehler: Daten wurden nicht akzeptiert.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Fehler: Kann nicht zum SMTP host verbinden.';
$PHPMAILER_LANG["file_access"] = 'Kann auf diese Datei nicht zugreifen: ';
$PHPMAILER_LANG["file_open"] = 'Dateifehler: Kann diese Datei nicht öffen: ';
$PHPMAILER_LANG["encoding"] = 'Unbekanntes Encoding: ';
?>
