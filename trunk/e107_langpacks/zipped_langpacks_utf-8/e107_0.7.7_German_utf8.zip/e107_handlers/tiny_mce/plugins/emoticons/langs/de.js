// UK lang variables

tinyMCELang['lang_insert_emoticons_title'] = 'Smilies einf&uuml;gen';
tinyMCELang['lang_emoticons_desc'] = 'Smilies';

