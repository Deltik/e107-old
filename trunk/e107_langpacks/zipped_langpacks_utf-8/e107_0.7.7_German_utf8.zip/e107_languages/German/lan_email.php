<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/07 19:06:54 $
|     $Author: mcfly_e107 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }
 
define("LAN_EMAIL_1", "Von:");
define("LAN_EMAIL_2", "IP Adresse des Absenders:");
define("LAN_EMAIL_3", "Email von ");
define("LAN_EMAIL_4", "Email senden");
define("LAN_EMAIL_5", "Email Eintrag für einem Freund");
define("LAN_EMAIL_6", "Ich denke dieser Eintrag könnte von Interesse sein von");
define("LAN_EMAIL_7", "e-Mail an");
define("LAN_EMAIL_8", "Kommentar");
define("LAN_EMAIL_9", "Sorry - E-Mail kann nicht gesendet werden");
define("LAN_EMAIL_10", "Mail versandt an");
define("LAN_EMAIL_11", "E-Mail versandt");
define("LAN_EMAIL_12", "Fehler");
define("LAN_EMAIL_13", "Email Artikel an einen Freund");
define("LAN_EMAIL_14", "Email Newseintrag an einen Freund");
define("LAN_EMAIL_15", "Login Name: ");
define("LAN_EMAIL_106", "Dieses scheint keine gültige E-Mail Adresse zu sein");
define("LAN_EMAIL_185", "Artikel senden");
define("LAN_EMAIL_186", "News senden");
define("LAN_EMAIL_187", "E-Mail Adresse des Empfängers");
define("LAN_EMAIL_188", "Ich dachte diese News könnten Sie interessieren");
define("LAN_EMAIL_189", "Ich dachte dieser Artikel könnte für Sie von Interesse sein");
define("LAN_EMAIL_190", "Bitte sichtbaren Code eingeben");

?>
