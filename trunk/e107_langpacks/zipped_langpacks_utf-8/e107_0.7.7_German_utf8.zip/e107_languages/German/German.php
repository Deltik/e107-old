<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/German.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/29 07:43:11 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'de', 'de_DE.utf8', 'de_DE@euro', 'de_DE', 'deu_deu');
define("CORE_LC", 'de');
define("CORE_LC2", 'de');
define("CHARSET", "utf-8");
define("CORE_LAN1", "Fehler : Theme fehlt.\n\nÄndern Sie das Theme unter Einstellungen oder laden Sie ein neues Theme auf den Server.");
define("CORE_LAN2", " \1 schrieb:");// "\1");
define("CORE_LAN3", "Dateianhang nicht erlaubt/ausgeschaltet");
define("CORE_LAN4", "Bitte löschen Sie die install.php auf dem Server");
define("CORE_LAN5", "falls Sie dem nicht nachkommen, besteht ein potentielles Sicherheitsrisiko für Ihre Webseite");
define("CORE_LAN6", "Die -flood protection- wurde auf dieser Seite aktiviert und Sie sind hiermit gewarnt gebannt zu werden, sollten Sie weiterhin versuchen Seiten zu erreichen.");
define("CORE_LAN7", "Es wird versucht die Voreinstellungen des Cores aus dem automatischen Backup wieder herzustellen.");
define("CORE_LAN8", "Core Voreinstellungen Fehler");
define("CORE_LAN9", "Der Core konnte aus dem automatischen Backup nicht wieder hergestellt werden. Ausführung nicht möglich.");
define("CORE_LAN10", "Fehlerhaftes Cookie entdeckt - Sie wurden ausgelogged.");
define("LAN_WARNING", "Warnung!");
define("LAN_ERROR", "Fehler");
define("LAN_ANONYMOUS", "Unbekannter");
define("POPUP_LAN_1", "Bitte hier klicken um das Bild zu vergrössern");


?>
