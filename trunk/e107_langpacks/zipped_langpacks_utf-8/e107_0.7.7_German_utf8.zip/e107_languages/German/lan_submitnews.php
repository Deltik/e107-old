<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "News übermitteln");
define("LAN_7", "Benutzername: ");
define("LAN_62", "Betreff: ");
define("LAN_112", "E-Mail Adresse: ");
define("LAN_133", "Danke");
define("LAN_134", "Ihre News wurden gesendet und werden von einem Administrator baldmöglichst geprüft &amp; aktiviert werden.");
define("LAN_135", "News: ");
define("LAN_136", "News übermitteln");
define("NWSLAN_6", "Kategorie");
define("NWSLAN_10", "Keine News Kategorien");
define("NWSLAN_11", "Sie haben keinen Zutritt zu diesem Bereich.");
define("NWSLAN_12", "Zugang verweigert.");
define("SUBNEWSLAN_1", "Sie müssen einen Titel angeben.\\n");
define("SUBNEWSLAN_2", "Sie müssen Text eingeben.\\n");
define("SUBNEWSLAN_3", "Ihr Anhang muss entweder ein jpg, gif oder png file sein");
define("SUBNEWSLAN_4", "Datei ist zu gross");
define("SUBNEWSLAN_5", "Bild Datei");
define("SUBNEWSLAN_6", "(jpg, gif oder png)");


?>
