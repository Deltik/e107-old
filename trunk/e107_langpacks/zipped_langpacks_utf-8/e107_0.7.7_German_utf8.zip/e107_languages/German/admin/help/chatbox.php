<?php
$caption = "Chatbox Menü";
$text = "Chatbox Einstellungen können Sie hier vornehmen.<br />
Wenn Sie die 'Link ersetzen' Checkbox aktivieren, werden alle eingegebenen Links durch die im Textfeld eingegebenen Zeichen ersetzt. Zeilenumbruch Definiert die maximale Zeichenfolge (z.B. 20) auf die angegebene Zahl. Dann wird automatisch das Wortumgebrochen in die näste Zeile.";
$ns -> tablerender($caption, $text);
?>
