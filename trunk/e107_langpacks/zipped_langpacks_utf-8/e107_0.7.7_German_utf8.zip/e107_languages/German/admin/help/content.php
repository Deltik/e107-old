<?php

$text = "Sie können eine normale Seite mit diesem Menü hinzufügen. Es wird ein link zu Ihrer neuen Seite gesetzt in der Hauptnavigationsleiste. Wenn Sie beispielsweise einen neue Seite (test.php auch mit html code möglich) mit dem Namen Test eintragen, dann erscheint in Ihrer Haupnavigation die Seite Test.<br />
Wenn Ihre neue Seite eine Überschrift haben soll, dann tragen Sie diese bitte in dem dafür vorgesehen Feld 'Seitenüberschrift' ein.";
$ns -> tablerender("Inhalt Hilfe", $text);
?>
