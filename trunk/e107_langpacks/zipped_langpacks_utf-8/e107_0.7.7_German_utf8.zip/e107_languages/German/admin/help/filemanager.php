<?php
$text = "Hiermit organisieren Sie Ihre Verzeichnisse. Wenn eine Fehlermeldung über die Zugriffrechte erhalten CHMOD'en Sie bitte das Verzeichnis, in das Sie den Upload einstellen wollen auf '777'.";
$ns -> tablerender("Dateimanager Hilfe", $text);
?>
