<?php
$caption = "News veröffentlichen (posten) Hilfe";
$text = "<b>Allegemeines</b><br />
Der Teaser oder auch Body wird auf der Hauptseite angezeigt, der ausführliche Text wird dann lesbar, wenn der User 'weiterlesen' anklickt.
<br />
<br />
<b>Zeige nur Überschrift</b>
<br />
Aktivieren Sie diese Einstellung, um nur den Titel auf Ihrer News Seite anzuzeigen. Per Klick wird dann der gesamte Text lesbar angezeigt.
<br /><br />
<b>Aktivierung</b>
<br />
Wenn Sie ein Anfangs- und enddatum auswählen wird der Newseintrag nur in diesem Zeitraum sichtbar.";
$ns -> tablerender($caption, $text);
?>
