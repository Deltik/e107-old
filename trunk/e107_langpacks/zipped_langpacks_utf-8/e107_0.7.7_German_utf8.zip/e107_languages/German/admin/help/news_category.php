<?php
$text = "Sie können Ihre News in verschiedene Kategorien einteilen und ermöglichen dem Besucher so, nur die News anzuzeigen in den jeweilgen Kategorien interessant für den Leser sind.<br /><br />
Laden Sie Ihre News Icons entweder in den Ordner ".e_THEME."-IhrTheme-/images/ oder themes/shared/newsicons/";
$ns -> tablerender("News Kategorie Hilfe", $text);
?>
