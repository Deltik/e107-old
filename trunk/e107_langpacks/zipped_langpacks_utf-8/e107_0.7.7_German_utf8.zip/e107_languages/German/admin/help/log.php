<?php
$text = "Aktivieren Sie das 'logging' mit diesem Menü. Wenn Sie geringen Server Speicherplatz haben, aktivieren Sie die Checkbox 'nur Domain/Domäne als Bezug'. das erzeugt nur ein Kurz-Log für die URL, zB 'waketime.com' anstelle von 'http://www.waketime.com/news.php'";
$ns -> tablerender("Logging Hilfe", $text);
?>
