<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Erhaltene Nachrichten");
define("MESSLAN_2", "Gelöschte Nachrichten");
define("MESSLAN_3", "Nachrichten gelöscht.");
define("MESSLAN_4", "Alle Nachrichten löschen");
define("MESSLAN_5", "Bestätigen");
define("MESSLAN_6", "Alle Nachrichten gelöscht.");
define("MESSLAN_7", "Keine Nachrichten.");
define("MESSLAN_8", "Nachrichten Typ");
define("MESSLAN_9", "Geschrieben");

define("MESSLAN_10", "Geschrieben von");
define("MESSLAN_11", "öffnet in neuem Fenster");
define("MESSLAN_12", "Nachricht");
define("MESSLAN_13", "Link");


?>
