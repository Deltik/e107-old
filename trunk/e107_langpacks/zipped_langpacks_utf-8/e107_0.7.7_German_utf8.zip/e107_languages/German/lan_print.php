<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: mrpete $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Druckerfreundlich"); }

define("LAN_PRINT_86", "Kategorie:");
define("LAN_PRINT_87", "von ");
define("LAN_PRINT_94", "Eintrag von");
define("LAN_PRINT_135", "News: ");
define("LAN_PRINT_303", "Diese News sind von ");
define("LAN_PRINT_304", "Artikel Titel: ");
define("LAN_PRINT_305", "Untertitel: ");
define("LAN_PRINT_306", "Dieser Artikel ist von ");
define("LAN_PRINT_307", "Diese Seite drucken");

define("LAN_PRINT_1", "Druckerfreundlich");

?>
