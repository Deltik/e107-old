<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/other_news_menu/languages/German.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:53:12 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("TD_MENU_L1", "Andere News");
define("TD_MENU_L2", "Andere News");

?>
