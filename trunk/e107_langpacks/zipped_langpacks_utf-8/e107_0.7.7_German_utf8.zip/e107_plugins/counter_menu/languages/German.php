<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/counter_menu/languages/German.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/02/18 20:31:45 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("COUNTER_L1", "Adminbesuche werden nicht gezählt");
define("COUNTER_L2", "Diese Seite heute");
define("COUNTER_L3", "Insgesamt");
define("COUNTER_L4", "Diese Seite insgesamt");
define("COUNTER_L5", "einzigartig.");
define("COUNTER_L6", "Seite.");
define("COUNTER_L7", "Zähler");
define("COUNTER_L8", "Admin Nachricht: <b>Statistik Logs sind abgeschalten.</b><br />Um es zu aktivieren, müssen Sie das Statsitik Loggin Plugin installieren in Ihrem <a href='".e_ADMIN."plugin.php'>Plugin Manager</a>, danach aktivieren Sie es bitte mittels <a href='".e_PLUGIN."log/admin_config.php'>Konfigurations-Screen</a>.");

?>
