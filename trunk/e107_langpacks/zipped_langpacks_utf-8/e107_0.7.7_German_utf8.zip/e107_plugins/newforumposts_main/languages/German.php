<?php

define("NFPM_LAN_1", "Eintrag");
define("NFPM_LAN_2", "Schreiber");
define("NFPM_LAN_3", "Ansichten");
define("NFPM_LAN_4", "Antworten");
define("NFPM_LAN_5", "Letzter Eintrag");
define("NFPM_LAN_6", "Einträge");
define("NFPM_LAN_7", "von");

define("NFPM_L1", "Dieses Plugin zeigt eine Liste von Neuen Forumseinträgen auf der Hauptseite");
define("NFPM_L2", "Letzte Forumeinträge"); 
define("NFPM_L3", "Zum Konfigurieren klicken Sie bitte auf der Adminhauptseite - Neue Forum Einträge -");
define("NFPM_L4", "In welchem Bereich aktivieren?");
define("NFPM_L5", "Inaktiv");
define("NFPM_L6", "Oben auf der Seite");
define("NFPM_L7", "Unten auf der Seite");
define("NFPM_L8", "Überschrift");
define("NFPM_L9", "Die Anzahl der anzuzeigenden neuen Einträge?");
define("NFPM_L10", "Anzeige im srollenden Bereich?");
define("NFPM_L11", "Layer Höhe");
define("NFPM_L12", "Konfiguration");
define("NFPM_L13", "Einstellungen aktualisieren");
define("NFPM_L14", "Einstellungen aktualisiert.");
define("NFPM_L15", "Markieren Sie hier um die letzten Forumeinträge anzeigen zu lassen.<br />Gesetzt sind letzte Forumtopics.");
define('NFPM_L16', '[Benutzer gelöscht]');


?>
