<?php
	
define("LWLAN_1", "Feld(er) frei gelassen.");
define("LWLAN_2", "Link Wort gespeichert.");
define("LWLAN_3", "Link Wort aktualisiert.");
define("LWLAN_4", "Keine Link Wörter definiert bis jetzt.");
define("LWLAN_5", "Wort");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Optionen");
define("LWLAN_9", "Ja");
define("LWLAN_10", "Nein");
define("LWLAN_11", "Bestehende Linkwörter");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nein");
define("LWLAN_14", "LinkWort übermitteln");
define("LWLAN_15", "LinkWort aktualisieren");
define("LWLAN_16", "Bearbeiten");
define("LWLAN_17", "Löschen");
define("LWLAN_18", "Sind Sie sicher dieses Linkwort löschen zu wollen?");
define("LWLAN_19", "Linkwort gelöscht.");
define("LWLAN_20", "Der Linkworteintrag kann nicht gefunden werden.");
define("LWLAN_21", "Woert das Auto-Gelinkt werden soll");
define("LWLAN_22", "Aktivieren?");

define("LWLANINS_1", "Linkwörter");
define("LWLANINS_2", "Diese Plugin er&mouml;glicht es Ihnen spezielle Wörter mit einem eingegeben Link zu versehen");
define("LWLANINS_3", "Linkwörter konfigurieren");
define("LWLANINS_4", "Fü die Konfiguration der Linkwörter gehen Sie bitte auf die Admin Hauptseite und klicken Sie auf Linkörter");

?>
