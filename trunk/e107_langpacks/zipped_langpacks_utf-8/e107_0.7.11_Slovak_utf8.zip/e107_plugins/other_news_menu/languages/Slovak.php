<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/other_news_menu/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:15 $
|     $Author: manro, whitewoflsix $
+----------------------------------------------------------------------------+
*/
	
define("TD_MENU_L1", "Iné novinky");
define("TD_MENU_L2", "Iné novinky");
	
?>