<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Slovak/lan_content_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/

define("CONT_FP_1", "Kategória článku");
define("CONT_FP_2", "hlavná stránka");

?>
