<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/comment_menu/languages/Slovak.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: manro, whitewolfsix $
+----------------------------------------------------------------------------+
*/
	
define("CM_L1", "Žiadne komentáre.");
define("CM_L2", "");
define("CM_L3", "Nadpis menu");
define("CM_L4", "Počet zobrazených komentárov");
define("CM_L5", "Počet zobrazených znakov");
define("CM_L6", "Oprava pre dlhé komentáre");
define("CM_L7", "Zobraziť originálny nadpis novinky v menu?");
define("CM_L8", "Konfigurácia menu komentárov noviniek");
define("CM_L9", "Aktualizovat nastavenia menu");
define("CM_L10", "Nastavenia menu komentárov noviniek aktualizované");
define("CM_L11", "na");
define("CM_L12", "Re:");
define("CM_L13", "Odoslané kým");
	
	
?>
