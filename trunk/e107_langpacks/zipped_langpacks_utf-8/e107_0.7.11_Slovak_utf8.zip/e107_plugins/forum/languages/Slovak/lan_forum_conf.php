<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Slovak/lan_forum_conf.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "Anketa zmazaná.");
define("FORLAN_6", "Vlákno zmazané");
define("FORLAN_7", "odpovede zmazané");
define("FORLAN_8", "Zmazanie zrušené.");
define("FORLAN_9", "Vlákno presunuté.");
define("FORLAN_10", "Presunutie zrušené.");
define("FORLAN_11", "Späť do fór");
define("FORLAN_12", "Konfigurácia fór");
define("FORLAN_13", "Ste si istý, že chcete zmazať túto anketu?<br />Raz zmazané už <b><u>nemôže</u></b> byť obnovené.");
define("FORLAN_14", "Späť");
define("FORLAN_15", "Potvrdenie zmazania príspevku fóra");
define("FORLAN_16", "Potvrdenie zmazania ankety");
define("FORLAN_17", "zaslal:");
define("FORLAN_18", "Ste si istý, že chcete zmazať toto fórum");
define("FORLAN_19", "vlákno a súvisiace príspevky?");
define("FORLAN_20", "anketa bude taktiež zmazaná");
define("FORLAN_21", "Raz zmazané");
define("FORLAN_22", "príspevok?<br />Raz zmazané");
define("FORLAN_23", "nemôže</u></b> byť obnovené");
define("FORLAN_24", "Presunúť vlákno do fóra");
define("FORLAN_25", "Presunúť vlákno");
define("FORLAN_26", "Odpoveď zmazaná");
	
define("FORLAN_27", "presunuté");
	
define("FORLAN_28", "Nepremenujte názov vlákna");
define("FORLAN_29", "Pridať");
define("FORLAN_30", "do názvu");
define("FORLAN_31", "Premenovať na:");
define("FORLAN_32", "Možnosti premenovať vlákno:");

?>
