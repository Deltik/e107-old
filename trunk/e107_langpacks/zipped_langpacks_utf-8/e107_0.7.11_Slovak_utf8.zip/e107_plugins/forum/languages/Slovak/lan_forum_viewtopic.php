<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Slovak/lan_forum_viewtopic.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Fórum");
	
define("LAN_01", "Fóra");
define("LAN_02", "Choď na stránku");
define("LAN_03", "Choď");
define("LAN_04", "Späť");
define("LAN_05", "Ďalej");
define("LAN_06", "Poslané:");
define("LAN_07", "Bydlisko");
define("LAN_08", "Webstránka");
define("LAN_09", "Počet návštev od registrácie");
define("LAN_10", "Späť navrch");
define("LAN_65", "Skok");
define("LAN_66", "Toto vlákno je teraz zamknuté");
define("LAN_67", "príspevkov");
define("LAN_194", "Hosť");
define("LAN_195", "Registrovaný člen");
define("LAN_321", "Moderátori: ");
define("LAN_389", "Predchádzajúce vlákno");
define("LAN_390", "Ďalšie vlákno");
define("LAN_391", "Sledovať vlákno");
define("LAN_392", "Zrušiť sledovanie vlákna");
define("LAN_393", "Rýchla odpoveď");
define("LAN_394", "Ukázať");
define("LAN_395", "Odpovedať na fórum");
define("LAN_396", "Webstránka");
define("LAN_397", "Email");
define("LAN_398", "Profil");
define("LAN_399", "Osobná správa");
define("LAN_400", "Editovať");
define("LAN_401", "Citovať");
	
define("LAN_402", "Autor");
define("LAN_403", "Príspevok");
define("LAN_404", "Žiadne predchádzajúce vlákno");
define("LAN_405", "Žiadne ďalšie vlákno");
	
define("LAN_406", "Moderátor: Editovať");
define("LAN_435", "Moderátor: Zmazať");
define("LAN_408", "Moderátor: Presunúť");
define("LAN_409", "Ste si istý, že chcete zmazať toto vlákno a všetky odpovede?");
define("LAN_410", "Ste si istý, že chcete zmazať túto odpoveď?");
define("LAN_411", "zaslal: ");
	
//v.616
define("LAN_412", "Titulok");
define("LAN_413", "Report");
define("LAN_414", "Reportovať toto vlákno moderátorovi");
define("LAN_415", "Titulok vlákna");
define("LAN_416", "Zadajte váš report");
define("LAN_417", "Administrátor bude upovedomený na toto vlákno. Môžete zaslať správu obsahujúcu podľa vás dôležité fakty.");
define("LAN_418", "<b>Nepoužívajte</b> tieto správy na kontaktovanie administrátora z iného dôvodu.");
define("LAN_419", "Odoslať report");
define("LAN_420", "Kliknite pre zobrazenie vašeho príspevku");
define("LAN_421", "Report vlákna fóra od");
define("LAN_422", "Táto správa je reportovaná zo stránky ");
define("LAN_423", "Správa nemohla byť odoslaná. ");
define("LAN_424", "Správa bola reportovaná moderátorovi.<br />Ďakujeme Vám.");
define("LAN_425", "Správa od: ");
define("LAN_426", "Reportovaná správa vo vlákne: ");
define("LAN_427", "Chyba pri odosielaní emailu");
define("LAN_428", "Správa bola reportovaná");
define("LAN_429", "Kliknite sem pre návrat na fórum");
define("LAN_430", "anketa");
define("FORLAN_26", "Odpoveď zmazaná");
define("FORLAN_10", "Založiť nové vlákno");
define("LAN_29", "Editovaný");

define("LAN_431", "Odoberajte toto vlákno: rss 0.92");
define("LAN_432", "Odoberajte toto vlákno: rss 2.0");
define("LAN_433", "Odoberajte toto vlákno: RDF");
	
define("FORLAN_101", "Emailovať vlákno");
define("FORLAN_102", "Tlačiť zobrazenie");
define('FORLAN_103', '[užívateľ zmazaný]');
define('FORLAN_104', 'Vlákno nebolo nájdené');
define("FORLAN_HIDDEN", "SKRYTÉ - PRIHLÁSIŤ SA A ODPOVEDAŤ PRE ODKRYTIE");

?>
