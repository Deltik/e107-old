<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Slovak/lan_forum_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Fórum");
define("FOR_SCH_LAN_2", "Vybrať fórum");
define("FOR_SCH_LAN_3", "Všetky fóra");
define("FOR_SCH_LAN_4", "Celý príspevok");
define("FOR_SCH_LAN_5", "Ako časť vlákna");

?>
