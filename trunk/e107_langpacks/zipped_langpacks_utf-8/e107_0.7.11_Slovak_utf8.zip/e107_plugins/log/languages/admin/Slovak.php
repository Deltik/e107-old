<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/log/languages/admin/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
	
define("ADSTAT_ON", "Zapnúť");
define("ADSTAT_OFF", "Vypnúť");
define("ADSTAT_L1", "This plugin will log all visits to your site, and build detailed statistic screens based on the information gathered.");
define("ADSTAT_L2", "The statistics logger has been successfully installed. To activate, please go to the config screen and click Activate.<br /><b>You must set the permissions of the e107_plugins/log/logs folder to 777 (chmod 777)</b>");
define("ADSTAT_L3", "Zaznamenávanie štatistík");
define("ADSTAT_L4", "Aktivovať zaznamenávanie štatistík");
define("ADSTAT_L5", "Druhy štatistík");
define("ADSTAT_L6", "Prehliadače");
define("ADSTAT_L7", "Operačné systémy");
define("ADSTAT_L8", "Obrazovka rozlíšenie/hĺbka");
define("ADSTAT_L9", "Krajiny/domény odkiaľ prišli návštevníci");
define("ADSTAT_L10", "Odkazy");
define("ADSTAT_L11", "Vyhľadávacie dopyty");
define("ADSTAT_L12", "Resetovať štatistiky");
define("ADSTAT_L13", "toto zmaže štatistiky - opatrne!");
define("ADSTAT_L14", "Počty stránok");
define("ADSTAT_L15", "Aktualizovať nastavenia štatistík");
define("ADSTAT_L16", "Stránka nastavenia štatistík");
define("ADSTAT_L17", "Nastavenia štatistík boli aktualizované");
define("ADSTAT_L18", "Umožniť prístup k hlavnej stránke štatistík komu ...");
define("ADSTAT_L19", "Momentálni návštevníci");
define("ADSTAT_L20", "Počítať návštevy admina");
define("ADSTAT_L21", "Maximum záznamov zobrazovaných na stránke štatistík");
define("ADSTAT_L22", "Spustiť aktualizačnú rutinu");
define("ADSTAT_L23", "boli zistené záznamy z predchádzajúcej verzie e107, aktualizujte ich tu");
define("ADSTAT_L24", "Ísť na aktualizačný skript");
define("ADSTAT_L25", "Resetovať vybrané štatistiky");
define("ADSTAT_L26", "Odstrániť položky stránky");
define("ADSTAT_L27", "Ak majú vaše štatistiky nesprávne stránky, tu ich môžete odstrániť");
define("ADSTAT_L28", "Otvoriť stránku");


define("ADSTAT_L29", "Názov stránky");
define("ADSTAT_L30", "Zaškrtnite pre odstránenie");
define("ADSTAT_L31", "Odstrániť vybrané stránky");
define("ADSTAT_L32", "Usporiadanie stránky");
define("ADSTAT_L33", "Konfigurovať zaznamenávanie štatistík");
define("ADSTAT_L34", "Štatistiky webu");

?>