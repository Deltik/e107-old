<?php
define("LDAPLAN_1", "Adresa servera");
define("LDAPLAN_2", "BaseDN alebo Doména<br />Ak LDAP - vložte BaseDN<br />Ak AD - vložte doménu");
define("LDAPLAN_3", "LDAP užívateľ<br />Plný kontext užívateľa, ktorý môže prehľadávať zložky.");
define("LDAPLAN_4", "LDAP heslo<br />Heslo pre LDAP užívateľa.");
define("LDAPLAN_5", "LDAP verzia");
define("LDAPLAN_6", "Nastav LDAP overenie");
define("LDAPLAN_7", "eDirectory vyhľadávací filter:");
define("LDAPLAN_8", "Toto bude použité pre uistenie sa, že sa užívateľ nachádza v správnom strome, <br />napr. '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Súčasný vyhľadávací filter bude:");
define("LDAPLAN_10", "Nastavenia sú aktualizované");
define("LDAPLAN_11", "UPOZORNENIE: Vyzerá to tak, že ldap modul nie je momentálne dostupný, nastavenia pre vašu overovaciu metódu pre LDAP nebude fungovať!");
define("LDAPLAN_12", "Druh servera");
define("LDAPLAN_13", "Aktualizujte nastavenia");
?>
