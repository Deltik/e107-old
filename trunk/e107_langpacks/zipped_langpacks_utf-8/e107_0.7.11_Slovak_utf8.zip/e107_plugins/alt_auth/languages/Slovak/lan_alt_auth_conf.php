<?php
define("LAN_ALT_1", "Súčasný typ overovania");
define("LAN_ALT_2", "Aktualizujte nastavenia");
define("LAN_ALT_3", "Zvoľte alternatívny typ overovania");
define("LAN_ALT_4", "Nastavte parametre pre");
define("LAN_ALT_5", "Nastavte overovacie parametre");
define("LAN_ALT_6", "Spojovacia činnosť zlyhala");
define("LAN_ALT_7", "Ak spojenie na alternatívnu metódu zlyhá, ako s tým bude zaobchádzané?");
define("LAN_ALT_8", "Cinnosť nenájdeného užívateľa");
define("LAN_ALT_9", "Ak meno užívateľa nie je nájdené pri použití alternatívnej metódy, ako s tým bude zaobchádzané?");

define("LAN_ALT_FALLBACK", "Použiť e107 tabuľku užívateľa");
define("LAN_ALT_FAIL", "Prihlásenie zlyhalo");

?>
