<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsfeed/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro, whitewolfsix $
+----------------------------------------------------------------------------+
*/


define("NFLAN_01", "Dodávka noviniek");
define("NFLAN_02", "Tento plugin vyberie rss dodávky z iných internetových stránok a zobrazí ich podľa vašich nastavení");
define("NFLAN_03", "Konfigurovať dodávku noviniek");
define("NFLAN_04", "Plugin dodávky noviniek bol úspešne nainštalovaný. Pre pridanie dodávky noviniek a kongiguráciu, vráťte sa na hlavnú stránku administrácie a kliknite na ikonu dodávky noviniek v sekcii pluginov.");
define("NFLAN_05", "Upraviť");
define("NFLAN_06", "Zmazať");
define("NFLAN_07", "Existujúce dodávky noviniek");
define("NFLAN_08", "Hlavná stránka dodávky noviniek");
define("NFLAN_09", "Vytvoriť dodávku noviniek");
define("NFLAN_10", "URL k rss dodávke");
define("NFLAN_11", "Cesta k obrázku");
define("NFLAN_12", "Aktivácia");
define("NFLAN_13", "Nikde (neaktívne)");
define("NFLAN_14", "Len v menu");
define("NFLAN_15", "Vytvoriť dodávku noviniek");
define("NFLAN_16", "Aktualizovať dodávku noviniek");
define("NFLAN_17", "vložiť 'predvolené' do rámika k použitiu obrázka definovanom v dodávke, pre použitie vášho vlastného obrázka, vložte celú cestu, ponechajte prázdne pre žiadny obrázok.");
define("NFLAN_18", "Aktualizačný interval v sekundách");
define("NFLAN_19", "napr. 3600: dodávka noviniek bude aktualizovaná každú hodinu");
define("NFLAN_20", "Len na hlavnej stránke dodávky noviniek");
define("NFLAN_21", "Aj v menu aj na stránke dodávky noviniek");
define("NFLAN_22", "vyberte si kde chcete mať dodávku noviniek zobrazenú");
define("NFLAN_23", "Dodávka noviniek je pridaná do databázy.");
define("NFLAN_24", "Požadované pole(ia) ostali prázdne.");
define("NFLAN_25", "Dodávka noviniek je aktualizovaná v databáze.");
define("NFLAN_26", "Aktualizačný interval");
define("NFLAN_27", "Možnosti");
define("NFLAN_28", "URL");
define("NFLAN_29", "Dostupné dodávky noviniek");
define("NFLAN_30", "Názov dodávky");
define("NFLAN_31", "Naspäť do zoznamu dodávky noviniek");
define("NFLAN_32", "Nie je možné nájsť dodávku noviniek s tým identifikačným číslo.");
define("NFLAN_33", "Dátum vydaný: ");
define("NFLAN_34", "neznámy");
define("NFLAN_35", "poslané od ");
define("NFLAN_36", "Popis");
define("NFLAN_37", "krátky popis dodávky, vložte 'prednastavené' pre použitie popisu, ktorý je definovaný v dodávke");
define("NFLAN_38", "Nadpisy");
define("NFLAN_39", "Podrobnosti");
define("NFLAN_40", "Dodávka noviniek je zmazaná");
define("NFLAN_41", "Zatiaľ nebola definovaná dodávka noviniek");

define("NFLAN_42", "<b>&raquo;</b> <u>Názov dodávky:</u>
	Identifikačným názvom dodávky môže byť čokoľvek čo chcete.
	<br /><br />
	<b>&raquo;</b> <u>URL k rss dodávke:</u>
	Adresa rss dodávky
	<br /><br />
	<b>&raquo;</b> <u>Cesta k obrázku:</u>
	Ak má dodávka definovaný obrázok, pre používanie vložte 'prednastavené'. Pre použitie vlastného obrázka, vložte plnú cestu k nemu. A nakoniec, ponechajte prázdne, ak nechcete použiť obrázok.
	<br /><br />
	<b>&raquo;</b> <u>Popis:</u>
	Vložte krátky popis dodávky alebo 'prednastavené' pre použitie popisu, ktorý je definovaný v dodávke (ak tam nejaký je).
	<br /><br />
	<b>&raquo;</b> <u>Aktualizačný interval v sekundách:</u>
	Množstvo sekúnd, ktoré majú prejsť predtým, než je dodávka aktualizovaná, napr.: 1800 pre 30 minút, 3600 pre 1 hodinu.
	<br /><br />
	<b>&raquo;</b> <u>Aktivácia:</u>
	Kde chcete zobraziť výsledky dodávky? Aby ste videli menu dodávky, budete potrebovať aktivovať menu dodávky noviniek na <a href='".e_ADMIN."menus.php'>stránke menu</a>.
	<br /><br />Pre získanie vhodného zoznamu dostupných dodávok, navštívte <a href='http://www.syndic8.com/' rel='external'>syndic8.com</a> alebo <a href='http://feedfinder.feedster.com/index.php' rel='external'>feedster.com</a>");
define("NFLAN_43", "Pomoc pre dodávky noviniek");
define("NFLAN_44", "kliknúť pre zobrazenie");

define("NFLAN_45", "Počet položiek, ktoré sa zobrazia v menu");
define("NFLAN_46", "Počet položiek, ktoré sa zobrazia na hlavnej stránke");
define("NFLAN_47", "0 alebo prázdne pre zobrazenie všetkých");

define("NFLAN_48", "Nespracované dáta  nie je možné uložiť v databáze.");
define("NFLAN_49", "Nie je možné nesériovať rss dáta - používa neštandardnú syntax");

?>