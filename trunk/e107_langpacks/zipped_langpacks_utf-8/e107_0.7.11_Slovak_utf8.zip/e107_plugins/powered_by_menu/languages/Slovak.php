<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/powered_by_menu/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:15 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
	
define("POWEREDBY_L1", "Beží na");
	
?>