<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/linkwords/languages/Slovak.php $
|     Revision: 1.2 $
|     Date: 2007/15/12 16:43:40 $
|     Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "Pole(ia) ponechané prázdne.");
define("LWLAN_2", "Slovný link uložený.");
define("LWLAN_3", "Slovný link aktualizovaný.");
define("LWLAN_4", "Nie je definovaný žiadny slovný link.");
define("LWLAN_5", "Slová");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktívne?");
define("LWLAN_8", "Možnosti");
define("LWLAN_9", "áno");
define("LWLAN_10", "nie");
define("LWLAN_11", "Exisujúce slovné linky");
define("LWLAN_12", "Áno");
define("LWLAN_13", "Nie");
define("LWLAN_14", "Odoslať slovný link");
define("LWLAN_15", "Aktualizovať slovný link");
define("LWLAN_16", "Upraviť");
define("LWLAN_17", "Zmazať");
define("LWLAN_18", "Ste si istí, že chcete tento slovný link zmazať?");
define("LWLAN_19", "Slovný link bol zmazaný.");
define("LWLAN_20", "Nie je možné nájsť tú položku slovného linku.");
define("LWLAN_21", "Slovo pre autolink (alebo čiarkou oddelený zoznam slov)");
define("LWLAN_22", "Aktivovať?");
define("LWLAN_23", "Administrácia slovných linkov");
define("LWLAN_24", "Spravovať slová");
define("LWLAN_25", "Možnosti");
define("LWLAN_26", "Oblasti, v ktorých umožniť slovné linky");
define("LWLAN_27", "Toto je 'kontext' zobrazeného textu");
define("LWLAN_28", "Stránky, na ktorých je treba znefunkčniť slovné linky");
define("LWLAN_29", "Rovnaký formát ako ovládanie viditeľnosti menu. Každé zodpovedá jednému riadku. Určite čiastočnú alebo kompletnú URL. Ukončite s '!' pre presné porovnanie so záverečnou časťou linku");
define("LWLAN_30", "Uložiť možnosti");
define("LWLAN_31", "Pridať/upraviť slovný link");
define("LWLAN_32", "Možnosti slovného linku");
define("LWLAN_33", 'Oblasti názvu');
define("LWLAN_34", 'Sumár položiek');
define("LWLAN_35", 'Telo textu');
define("LWLAN_36", 'Popis (linky, atď.)');
define("LWLAN_37", 'Oblasti odkazov');
define("LWLAN_38", 'Klikateľné linky');
define("LWLAN_39", 'Nespracovaný text');
define("LWLAN_40", 'Užívateľom vložené názvy (napr. fórum)');
define("LWLAN_41", 'Užívateľom vložené telo textu (napr. fórum)');


define("LWLANINS_1", "Slovné linky");
define("LWLANINS_2", "Tento plugin spojí určené slová s definovanými linkami");
define("LWLANINS_3", "Konfigurovať slovné linky");
define("LWLANINS_4", "Pre konfiguráciu, kliknite prosím na link v sekcii pluginov na hlavnej administračnej stránke");

?>