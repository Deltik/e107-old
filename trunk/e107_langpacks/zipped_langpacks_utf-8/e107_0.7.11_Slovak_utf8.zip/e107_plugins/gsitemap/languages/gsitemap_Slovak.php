<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/gsitemap/languages/gsitemap_English.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/15 17:43:12 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "Mapa stránok");
define("GSLAN_1", "Link stránky");
define("GSLAN_2", "Importovať?");
define("GSLAN_3", "Typ");
define("GSLAN_4", "Meno");
define("GSLAN_5", "Url");
define("GSLAN_6", "Zaškrtnite linky na označenie ich pre importovanie ...");
define("GSLAN_7", "Importovanie linkov");
define("GSLAN_8", "Importovať s:");
define("GSLAN_9", "Priority");
define("GSLAN_10", "Frekvencia");
define("GSLAN_11", "vždy");
define("GSLAN_12", "každú hodinu");
define("GSLAN_13", "denne");
define("GSLAN_14", "týždenne");
define("GSLAN_15", "mesačne");
define("GSLAN_16", "ročne");
define("GSLAN_17", "nikdy");
define("GSLAN_18", "Importovať označené linky?");
define("GSLAN_19", "Google mapa stránok");
define("GSLAN_20", "Výpis");
define("GSLAN_21", "Inštrukcie");
define("GSLAN_22", "Vytvoriť novú položku");
define("GSLAN_23", "Importovať");
define("GSLAN_24", "Položky Google mapy stránok");
define("GSLAN_25", "Meno");
define("GSLAN_26", "URL");
define("GSLAN_27", "Naposledy zmenené");
define("GSLAN_28", "Frekv.");
define("GSLAN_29", "konfigurácia Google mapy stránok");
define("GSLAN_30", "Zobraziť poradie");
define("GSLAN_31", "Viditeľné pre");
define("GSLAN_32", "Ako používať Google mapy stránok?");
define("GSLAN_33", "Inštrukcie GSiteMap");
define("GSLAN_34", "Najskôr, vytvorte linky, ktoré chcete mať vo výpise vašej mapy stránok. Môžete importovať väčšinu vašich linkov kliknutím na tlačidlo 'Importovať' na pravej strane");
define("GSLAN_35", "Ak ste vybrali linky na importovanie, kliknite na 'Importovať' a potom skontrolujte linky, ktoré chcete importovať");
define("GSLAN_36", "Môžete tiež vložiť samostatné linky ručne kliknutím na tlačidlo 'Vytvoriť novú položku'");
define("GSLAN_37", "Keď budete mať nejaké položky, choďte na <a href='https://www.google.com/webmasters/sitemaps/stats'>https://www.google.com/webmasters/sitemaps/stats</a> a vložte tam nasledujúcu URL -> <b>".SITEURL."gsitemap.php</b> - ak táto url nevyzerá správne, uistite sa, prosím, že url vašej stránky je korektná v časti admin -> nastavenia");
define("GSLAN_38", "Pre viac informácií o protokole Google mapy stránok, choďte na <a href='http://www.google.com/webmasters/sitemaps/docs/en/protocol.html'>http://www.google.com/webmasters/sitemaps/docs/en/protocol.html</a>.");
define("GSLAN_39", "V mape stránok nie sú žiadne linky - importovať linky stránok?");
define("GSLAN_40", "Položky Google mapy stránok");

?>