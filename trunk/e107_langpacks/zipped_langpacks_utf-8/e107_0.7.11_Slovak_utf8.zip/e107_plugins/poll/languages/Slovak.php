<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/poll/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:15 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/

define("POLL_ADLAN01", "Anketa");
define("POLL_ADLAN02", "Anketový plugin vám umožňuje definovať ankety v menu alebo príspevkoch vo fóre.");
define("POLL_ADLAN03", "Nastav ankety");
define("POLL_ADLAN04", "Anketový plugin bol úspešne inštalovaný. K pridaniu ankety, klikni na ikonu Ankety v sekcii pluginov vášho admin panela, a nezabudnite aktivovať túto položku v menu zozname.");
define("POLL_ADLAN05", "Hlavná anketa: ");
define("POLL_ADLAN06", "Vlákno fóra: ");
define("POLL_ADLAN07", "Druh");

define("POLLAN_MENU_CAPTION", "Anketa");

define("POLLAN_1", "Existujúce ankety");
define("POLLAN_2", "Vytvor / uprav ankety");
define("POLLAN_3", "Anketová otázka");
define("POLLAN_4", "Možnosti");
define("POLLAN_5", "Uprav");
define("POLLAN_6", "Zmaž");
define("POLLAN_7", "Zatiaľ nie sú žiadne ankety.");
define("POLLAN_8", "Pridaj ďalšiu možnosť");
define("POLLAN_9", "Umožníš viacnásobné možnosti?");
define("POLLAN_10", "áno");
define("POLLAN_11", "nie");
define("POLLAN_12", "Ukáž výsledky");
define("POLLAN_13", "po hlasovaní");
define("POLLAN_14", "kliknutím zobrazí link k výsledkom - k použitiu tejto možnosti musia byť umožnené komentáre");
define("POLLAN_15", "Umožni hlasovať v tejto ankete");
define("POLLAN_16", "Metóda uchovania hlasu");
define("POLLAN_17", "cookie");
define("POLLAN_18", "IP adresa");
define("POLLAN_19", "UžívateľovoIČ (voliť môžu len členovia)");
define("POLLAN_20", "Umožniš komentovať túto anketu?");
define("POLLAN_21", "Znovu zobraz");
define("POLLAN_22", "Aktualizuj anketu");
define("POLLAN_23", "Vytvor anketu");
define("POLLAN_24", "Náhľad");
define("POLLAN_25", "Vyčisti formulár");
define("POLLAN_26", "hlasy");
define("POLLAN_27", "Komentáre");
define("POLLAN_28", "Predošlé ankety");
define("POLLAN_29", "poslaný");
define("POLLAN_30", "Odovzdaj");
define("POLLAN_31", "hlasy");
define("POLLAN_32", "Klikni sem k zobrazeniu výsledkov");
define("POLLAN_33", "Žiadne predcházajúce ankety.");
define("POLLAN_34", "Názov");
define("POLLAN_35", "Poslané");
define("POLLAN_36", "Aktívne");
define("POLLAN_37", "aktívne od");
define("POLLAN_38", "do");
define("POLLAN_39", "Ďakujeme, že ste hlasovali!");
define("POLLAN_40", "Klikni sem k zobrazeniu výsledkov");

define("POLLAN_41", "Táto anketa je určená len pre členov");
define("POLLAN_42", "Táto anketa je určená len pre adminov");
define("POLLAN_43", "Nemáš oprávnenie voliť v tejto ankete");

define("POLLAN_44", "Zmazať túto anketu?");
define("POLLAN_45", "Anketa bola úspešne aktualizovaná");
define("POLLAN_46", "Pole(ia) ostali prázdne");

?>