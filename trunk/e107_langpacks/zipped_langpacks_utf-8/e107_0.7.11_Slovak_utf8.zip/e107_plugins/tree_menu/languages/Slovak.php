<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/07 02:54:20 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("TREE_L1", "Nastaviť stromové menu");
define("TREE_L2", "Aktualizovať nastavenia stromového menu");
define("TREE_L3", "Nastavenie stromového menu je uložené.");
define("TREE_L4", "Zap");
define("TREE_L5", "Vyp");
define("TREE_L6", "CSS trieda k použitiu pre neotvoriteľné linky");
define("TREE_L7", "CSS trieda k použitiu pre otvoriteľné linky");
define("TREE_L8", "CSS trieda k použitiu pre otvorené linky");
define("TREE_L9", "Použiť dištančnú triedu medzi hlavnými linkami");

?>