<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_extended_menu/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: WhiteWolfSix $
+----------------------------------------------------------------------------+
*/
	
define("ONLINE_EL1", "hostí: ");
define("ONLINE_EL2", "členov: ");
define("ONLINE_EL3", "Na tejto stránke: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "členov");
define("ONLINE_EL6", "Najnovší člen");
define("ONLINE_EL7", "prezerá");
	
define("ONLINE_EL8", "najviac online: ");
define("ONLINE_EL9", "v");
define("ONLINE_TRACKING_MESSAGE", "Online sledovanie užívateľom je momentálne blokované, <a href='".e_ADMIN."users.php?options'>umožnite to</a></span><br />, prosím");

?>