<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
	
define("BLOGCAL_L1", "Novinky v roku");
define("BLOGCAL_L2", "Archív");
	
define("BLOGCAL_D1", "Po");
define("BLOGCAL_D2", "Ut");
define("BLOGCAL_D3", "St");
define("BLOGCAL_D4", "Št");
define("BLOGCAL_D5", "Pi");
define("BLOGCAL_D6", "So");
define("BLOGCAL_D7", "Ne");
	
define("BLOGCAL_M1", "Január");
define("BLOGCAL_M2", "Február");
define("BLOGCAL_M3", "Marec");
define("BLOGCAL_M4", "Apríl");
define("BLOGCAL_M5", "Máj");
define("BLOGCAL_M6", "Jún");
define("BLOGCAL_M7", "Júl");
define("BLOGCAL_M8", "August");
define("BLOGCAL_M9", "September");
define("BLOGCAL_M10", "Október");
define("BLOGCAL_M11", "November");
define("BLOGCAL_M12", "December");
	
define("BLOGCAL_1", "Novinky");
	
define("BLOGCAL_CONF1", "Mesiace");
define("BLOGCAL_CONF2", "Výplň bunky");
define("BLOGCAL_CONF3", "Aktualizovať nastavenie menu");
define("BLOGCAL_CONF4", "Konfigurácia menu BlogKal");
define("BLOGCAL_CONF5", "Konfigurácia menu BlogKal uložená");
	
define("BLOGCAL_ARCHIV1", "Zvoľte archívny rok");
	
?>
