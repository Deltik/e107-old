<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/banner_menu/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
	
define("BANNER_MENU_L1", "Reklamy");
define("BANNER_MENU_L2", "Nastavenia menu reklám uložené");
	
//v.617
define("BANNER_MENU_L3", "Nadpis");
define("BANNER_MENU_L4", "Kampaň");
define("BANNER_MENU_L5", "Konfigurácia menu reklám");
define("BANNER_MENU_L6", "zvoľte kampane viditeľné v menu");
define("BANNER_MENU_L7", "dostupné kampane");
define("BANNER_MENU_L8", "zvolené kampane");
define("BANNER_MENU_L9", "odstrániť voľbu");
define("BANNER_MENU_L10", "ako by mali byť vybrané kampane zobrazené?");
define("BANNER_MENU_L11", "zvoľte typ zobrazenia ...");
define("BANNER_MENU_L12", "jedna kampaň v jednom menu");
define("BANNER_MENU_L13", "všetky zvolené kampane v jednom menu");
define("BANNER_MENU_L14", "všetky zvolené kampane v oddelených menu");
define("BANNER_MENU_L15", "koľko reklám by malo byť zobrazených?");
define("BANNER_MENU_L16", "toto nastavenie môže byť použité len v kombinácií s nastavením 2 a 3.<br />ak je dostupný malý počet reklám, bude použitý maximálny možný počet.");
define("BANNER_MENU_L17", "nastaviť počet ...");
define("BANNER_MENU_L18", "Aktualizovať nastavenia menu");
	
?>
