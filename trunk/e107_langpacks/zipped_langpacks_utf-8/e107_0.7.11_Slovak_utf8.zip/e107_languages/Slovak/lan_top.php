<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Top prispievači fóra");
define("TOP_LAN_1", "Užívateľské meno");
define("TOP_LAN_2", "Príspevkov");
define("TOP_LAN_3", "Top prispievači komentárov");
define("TOP_LAN_4", "Komentárov");
define("TOP_LAN_5", "Top prispievači chatboxu");
define("TOP_LAN_6", "Hodnotenie portálu");

//v.616
define("LAN_1", "Vlákno");
define("LAN_2", "Prispievateľ");
define("LAN_3", "Zobrazení");
define("LAN_4", "Odpovedí");
define("LAN_5", "Posledný príspevok");
define("LAN_6", "Vlákno");
define("LAN_7", "Najviac aktívne vlákno");
define("LAN_8", "Top prispievači");

?>