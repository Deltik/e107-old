<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Slovak/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Detaily kontaktu");
define("LANCONTACT_02", "Kontaktný formulár");
define("LANCONTACT_03", "Vlož svoje meno:");
define("LANCONTACT_04", "E-mailová adresa:");
define("LANCONTACT_05", "Predmet správy:");
define("LANCONTACT_06", "Vlož svoju správu:");
define("LANCONTACT_07", "Odošli kópiu tejto správy na svoju vlastnú adresu ");
define("LANCONTACT_08", "Pošli");
define("LANCONTACT_09", "Tvoja správa bola odoslaná.");
define("LANCONTACT_10", "Pri posielaní správy sa vykytol problém.");
define("LANCONTACT_11", "Tvoja emailová adresa sa zdá byť neplatná.\\nSkontroluj ju a vyskúšaj znovu.");
define("LANCONTACT_12", "Tvoja správa je príliš krátka.");
define("LANCONTACT_13", "Vlož predmet správy, prosím.");
define("LANCONTACT_14", "Pošli správu komu:");
define("LANCONTACT_15", "Bol vložený neplatný kód");
define("LANCONTACT_16", "Vlož kód");

?>