<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Vygenerované webovým systémom e107");
define("LANMAILH_2", "Toto je multi-časťová správa v MIME formáte.");
define("LANMAILH_3", " nie je správne formátovaná");
define("LANMAILH_4", "Server vrátil adresu");
define("LANMAILH_5", "Žiadna odpoveď zo servra");
define("LANMAILH_6", "Nenájdený emailový server.");
define("LANMAILH_7", " je správny.");

?>