<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Upload");
define('LAN_UL_001','Neplatná e-mailová adresa');
define('LAN_UL_002', 'Nemáte oprávnenia pre uploadnutie súborov na server.');	// LAN_403

define('LAN_UL_020', 'Chyba');
define('LAN_UL_021', 'Zlyhanie uploadu');

define("LAN_61", "Vaše meno: ");
define("LAN_112", "Emailová adresa: ");
define("LAN_144", "URL webstránok: ");
define("LAN_402", "Pre upload súborov na tento server musíte byť jeho registrovaným členom.");
define("LAN_403", "Nemáte potrebné prístupové práva pre upload súborov.");
define("LAN_404", "Ďakujeme vám. Váš upload bol zaznamenaný a posunutý administrátorovi na schválenie.");
define("LAN_405", "Súbor prekračuje nastavenú maximálnu veľkosť - bude okamžite zmazaný.");
define("LAN_406", "Poznámka");
define("LAN_407", "Všetky ostatné typy súborov budú okamžite zmazané.");
define("LAN_408", "Podtrhnuté");
define("LAN_409", "Meno súboru");
define("LAN_410", "Verzia");
define("LAN_411", "Súbor");
define("LAN_412", "Náhľad");
define("LAN_413", "Popis");
define("LAN_414", "Fungujúce demo");
define("LAN_415", "vložte URL, kde je možné vidieť uploadovaný súbor v reále");
define("LAN_416", "Uložiť a Uploadovať");
define("LAN_417", "Upload súboru");
define("LAN_418", "Maximálna veľkosť súboru: ");
define("DOWLAN_11", "Kategória");
define("LAN_419", "Povolené typy súborov");
define("LAN_420", "polia sú povinné");

?>