<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Chyba, prosím, zadajte znovu");
define("UDALAN_2", "Nastavenie aktualizované");
define("UDALAN_3", "Nastavenie aktualizované pre");
define("UDALAN_4", "Meno");
define("UDALAN_5", "Heslo");
define("UDALAN_6", "Heslo znovu");
define("UDALAN_7", "Zmeniť heslo");
define("UDALAN_8", "Aktualizovať heslo pre");

?>
