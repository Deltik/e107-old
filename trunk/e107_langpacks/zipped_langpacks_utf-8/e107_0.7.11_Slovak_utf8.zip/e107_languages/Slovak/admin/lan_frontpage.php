<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_frontpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "Nastavenia úvodnej stránky aktualizované.");
define("FRTLAN_2", "Nastaviť úvodnú stránku pre");
define("FRTLAN_6", "Odkazy");
// define("FRTLAN_7", "Content Page");
define("FRTLAN_12", "Aktualizovať nastavenia úvodnej stránky");
define("FRTLAN_13", "Nastavenia úvodnej stránky");
define("FRTLAN_15", "Iné (zadajte URL):");
define("FRTLAN_16", "chyba: nezvolili ste zdroj obsahu");
define("FRTLAN_17", "chyba: nezvolili ste kategóriu obsahu");
define("FRTLAN_18", "chyba: nezvolili ste predmet obsahu");
define("FRTLAN_19", "zdroj obsahu");
define("FRTLAN_20", "kategória obsahu");
define("FRTLAN_21", "predmet obsahu");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "všetci užívatelia");
define("FRTLAN_27", "Hostia");
define("FRTLAN_28", "Členovia");
define("FRTLAN_29", "Administrátori");
define("FRTLAN_31", "Všetci užívatelia");
define("FRTLAN_32", "Trieda užívateľov");
define("FRTLAN_33", "Platné nastavenia");
define("FRTLAN_34", "Stránka");

?>
