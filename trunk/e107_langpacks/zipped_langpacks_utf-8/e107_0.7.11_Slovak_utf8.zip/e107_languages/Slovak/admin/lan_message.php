<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_message.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Prijaté správy");
define("MESSLAN_2", "Zmazať správu");
define("MESSLAN_3", "Správa zmazaná.");
define("MESSLAN_4", "Zmazať všetky správy");
define("MESSLAN_5", "Potvrdiť");
define("MESSLAN_6", "Všetky správy zmazané.");
define("MESSLAN_7", "Žiadne správy.");
define("MESSLAN_8", "Typ správy");
define("MESSLAN_9", "Odpoveď na");

define("MESSLAN_10", "Poslal");
define("MESSLAN_11", "otvoriť v novom okne");
define("MESSLAN_12", "Správa");
define("MESSLAN_13", "Odkaz");


?>
