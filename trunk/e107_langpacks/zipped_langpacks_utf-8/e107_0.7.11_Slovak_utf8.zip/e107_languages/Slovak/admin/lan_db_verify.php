<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_db_verify.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Nemožné načítať SQL datasúbor<br /><br />Prosím, skontrolujte, že súbor <b>core_sql.php</b> existuje na ceste - <b>/admin/sql</b>.");
define("DBLAN_2", "Skontrolovať všetko");

define("DBLAN_4", "Tabuľka");
define("DBLAN_5", "Pole");
define("DBLAN_6", "Stav");
define("DBLAN_7", "Poznámka");
define("DBLAN_8", "Chyba");
define("DBLAN_9", "Aktuálne");
define("DBLAN_10", "mal by byť");
define("DBLAN_11", "Chýbajúce polia");
define("DBLAN_12", "Extra pole!");
define("DBLAN_13", "Chýbajúca tabuľka!");
define("DBLAN_14", "Zvoľte tabuľku(y) pre skontrolovanie");
define("DBLAN_15", "Štart kontroly");
define("DBLAN_16", "SQL Kontrola");
define("DBLAN_17", "Späť");
define("DBLAN_18", "tabuľky");
define("DBLAN_19", "Pokus o opravu");
define("DBLAN_20", "Pokus o opravu tabulie");
define("DBLAN_21", "Opraviť označené");
define("DBLAN_22", " je nečitateľné");

?>
