<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_banlist.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Zákaz odstránený.");
define("BANLAN_2", "Žiadne zákazy.");
define("BANLAN_3", "Existujúce zákazy");
define("BANLAN_4", "Odstrániť zákaz");
define("BANLAN_5", "Zadajte IP, emailovú adresu, alebo hosta");
define("BANLAN_7", "Dôvod");
define("BANLAN_8", "Zakázať užívateľa");
define("BANLAN_9", "Zakázať užívateľov zo stránky");
define("BANLAN_10", "IP / Email / Dôvod");
define("BANLAN_11", "Auto-vyhostenie: Viac než 10 neúspešných pokusov o prihlásenie");
define("BANLAN_12", "Poznámka: Opačná DNS je momentálne zablokovaná, musí byť povolená, aby bolo možné vyhostiť podľa internetového hostiteľa. Vyhostenie podľa IP a email bude stále normálne fungovať.");
define("BANLAN_13", "Upozornenie: Pre vylúčenie užívateľa podľa užívateľského mena, choďte do užívateľovej administračnej stránky: ");

?>
