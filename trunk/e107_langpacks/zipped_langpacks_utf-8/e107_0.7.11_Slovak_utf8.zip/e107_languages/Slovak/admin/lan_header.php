<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_header.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Administrátor");
define("LAN_head_2", "Váš server nepodporuje HTTP uploady, takže nie sú možné verejné uploady avatarov, súborov atď. Pre odstránenie tohto obmedzenia nastavte file_uploads na On v súbore php.ini a reštartujte server. Ak nemáte prístup k súboru php.ini kontaktujte administrátora servera.");
define("LAN_head_3", "Váš server beží zo zapnutou reštrikciou basedir. Toto obmedzenie nepovolí HTTP upload súborov inde ako do hlavného adresára a mnoho skriptov v manažéry súborov nebude pracovať správne.");

define("LAN_head_4", "Administrátor");

define("LAN_head_5", "jazyk zobrazený v administrátorovi: ");
define("LAN_head_6", "Informácie o pluginoch");

?>
