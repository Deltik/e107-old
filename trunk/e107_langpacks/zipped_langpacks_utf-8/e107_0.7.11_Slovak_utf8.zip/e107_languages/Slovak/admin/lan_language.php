<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_language.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00","nebol vytvorený.(už existuje)");
define("LANG_LAN_01","bol zmazaný(ak existoval) a vytvorený.");
define("LANG_LAN_02","nebol zmazaný");
define("LANG_LAN_03","Tabuľky");

define("LANG_LAN_05","Nie je inštalované");
define("LANG_LAN_06", "Vytvoriť tabuľky");
define("LANG_LAN_07", "Zmazať existujúce tebuľky?");
define("LANG_LAN_08", "Nahradiť existujúce tabuľky (dáta budú stratené).");
define("LANG_LAN_10", "Potvrdiť zmazanie");
define("LANG_LAN_11", "Zmazať neskontrolované tabuľky (ak existujú).");
define("LANG_LAN_12", "Zapnúť multijazykovú podporu");
define("LANG_LAN_13", "Nastavenia multijazykovej podpory");
define("LANG_LAN_14", "Prednastavený jazyk portálu");
define("LANG_LAN_15", "Označte pre kópiu dát z prednastaveného jazyka portálu.(použiteľné pre odkazy, kategórie noviniek atď) ");
define("LANG_LAN_16", "Použitie viac-jazykovej databázy");
define("LANG_LAN_17", "Predvolený jazyk - nie sú potrebné ďalšie tabuľky.");
define("LANG_LAN_18", "Použite parkované subdomény pre nastavenie jazyka:");
define("LANG_LAN_19", "napr.: fr.mydomain.com pre nastavenie francúzskeho jazyka.");
define("LANG_LAN_20", "Pre povolenie vložte názov hlavnej domény, napr.: mydomain.com");

define("LANG_LAN_21", "Jazykové nástroje");

?>
