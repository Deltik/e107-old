<?php
$caption = "Front Page Help";
$text = "From this screen you can choose what to display as the front page of your site, the default is news.";
$ns -> tablerender($caption, $text);
?>