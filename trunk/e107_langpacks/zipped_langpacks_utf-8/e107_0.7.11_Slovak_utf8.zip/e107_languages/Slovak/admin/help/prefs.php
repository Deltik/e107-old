<?php
$text = "Your preferences allow you to specify all the important settings on your site, from site name and description to flood protection and profanity filtering.";
$ns -> tablerender("Preferences Help", $text);
?>