<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_menus.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Viditeľné pre všetkých");
define("MENLAN_2", "Viditeľné len pre členov");
define("MENLAN_3", "Viditeľné len pre administrátorov");
define("MENLAN_4", "Viditeľné len pre:");
// define("MENLAN_5", "class");
define("MENLAN_6", "Uložiť nastavenia viditeľnosti");
define("MENLAN_7", "Konfigurácia viditeľnosti pre");
define("MENLAN_8", "Nastavenia viditeľnosti aktualizované");
define("MENLAN_9", "Nainštalované nové vlastné menu");
define("MENLAN_10", "Nainštalované nové menu");
define("MENLAN_11", "Menu odstránené");
define("MENLAN_12", "Aktivované: zvoľte lokáciu");
define("MENLAN_13", "Aktivovať v lokácií");
define("MENLAN_14", "Lokácia");
define("MENLAN_15", "Deaktivovať");
define("MENLAN_16", "Konfigurovať");
define("MENLAN_17", "Posunúť hore");
define("MENLAN_18", "Posunúť dole");
define("MENLAN_19", "Presunúť do lokácie");
define("MENLAN_20", "Viditeľnosť");

// define("MENLAN_21", "Visible to Guests only");
define("MENLAN_22", "Neaktívne menu");

define("MENLAN_23", "Presunúť na koniec");
define("MENLAN_24", "Presunúť na začiatok");
define("MENLAN_25", "Funkcie ...");

define("MENLAN_26", "Toto menu bude <strong>ZOBRAZENÉ</strong> na nasledujúcich stránkach");
define("MENLAN_27", "Toto menu bude <strong>SKRYTÉ</strong> na nasledujúcich stránkach");
define("MENLAN_28", "Vložte len jednu stránku na riadok, stačí zadať URL pre odlíšenie");

define("MENLAN_29", "Zvoľte vrstvu");  
define("MENLAN_30", "Pre zobrazenie lokácií menu a ich pozícií vo vlastných vrstvách, zvoľte tu vlastnú vrstvu:");
define("MENLAN_31", "Predvolená vrstva");
define("MENLAN_32", "Vrstva nadpisov noviniek");
define("MENLAN_33", "Vlastná vrstva");
define("MENLAN_34", "Vložené");
define("MENLAN_35", "Konfigurácia menu");
define("MENLAN_36", "Zvoľte menu pre aktiváciu");
define("MENLAN_37", "tu zvoľte v ktorej lokácií sa majú aktivovať.");
define("MENLAN_38", "Podržte CTRL pre výber viacerých menu.");


?>
