<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_emoticon.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Aktivácia smajlíkov");
define("EMOLAN_2", "Názov");
define("EMOLAN_3", "Smajlíci");
define("EMOLAN_4", "Aktivovať smajlíkov?");

define("EMOLAN_5", "Obrázok");
define("EMOLAN_6", "Kód smajlíka");
define("EMOLAN_7", "viac možností oddelovať medzerami");

define("EMOLAN_8", "Stav");
define("EMOLAN_9", "Nastavenia");
define("EMOLAN_10", "Aktívny");
define("EMOLAN_11", "Aktivovať balík'");

define("EMOLAN_12", "Editovať / konfigurovať tento balík");
define("EMOLAN_13", "Inštalované balíky");

define("EMOLAN_14", "Uložiť konfiguráciu");
define("EMOLAN_15", "Editovať / konfigurovať smajlíkov");
define("EMOLAN_16", "Nastavenia smajlíkov uložené");
define("EMOLAN_17", "Máte balíček smajlov, ktorý obsahuje medzery, čo nie je povolené!");
define("EMOLAN_18", "Premenujte prosím položky na zozname, ktorý je uvedený nižšie, aby viac neobsahovali medzery:");
define("EMOLAN_19", "Názov");
define("EMOLAN_20", "Umiestnenie");
define("EMOLAN_21", "Chyba");
//define("EMOLAN_2", "Name");
define("EMOLAN_22", "Bol nájdený nový balík smajlov:");
define("EMOLAN_23", "Bol nájdený nový xml balík smajlov:");
define("EMOLAN_24", "Bol nájdený nový php balík smajlov:");
define("EMOLAN_25", "Inštalovanie nových PHP smajlov: ");
define("EMOLAN_26", "Znovu zoskenovať balík");
define("EMOLAN_27", "Počas spracovávania balíka sa vyskytla chyba: ");
define("EMOLAN_28", "Generovať XML");
define("EMOLAN_29", "XML súbor generovaný: ");
define("EMOLAN_30", "Chyba počas zápisu XML súboru: ");

?>
