<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_userinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Nie je možné nájsť IP adresu - informácie nie sú prístupné.");
// define("USFLAN_2", "Error");
define("USFLAN_3", "Správa poslaná z IP adresy");
define("USFLAN_4", "Host");
define("USFLAN_5", "Kliknite sem pre zaslanie IP adresy do administrátora zákazov");
define("USFLAN_6", "ID užívateľa");
define("USFLAN_7", "Informácie o užívateľovi");

?>
