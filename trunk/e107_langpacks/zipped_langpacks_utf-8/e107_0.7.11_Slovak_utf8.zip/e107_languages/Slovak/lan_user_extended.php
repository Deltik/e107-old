<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Textové pole");
define("UE_LAN_2", "Výberové menu");
define("UE_LAN_3", "Roletkové menu");
define("UE_LAN_4", "DB tabuľkové pole");
define("UE_LAN_5", "Textové pole");
define("UE_LAN_6", "Celok");
define("UE_LAN_7", "Dátum");

define("UE_LAN_8", "Jazyk");
define("UE_LAN_9", "Meno");
define("UE_LAN_10", "Typ");
define("UE_LAN_11", "Použitie");

define("UE_LAN_HIDE", "Skryť pre ostatných");

define("UE_LAN_LOCATION", "Bydlisko");
define("UE_LAN_LOCATION_DESC", "Bydlisko užívateľa");
define("UE_LAN_AIM", "AIM adresa");
define("UE_LAN_AIM_DESC", "AIM adresa");
define("UE_LAN_ICQ", "ICQ číslo");
define("UE_LAN_ICQ_DESC", "ICQ číslo");
define("UE_LAN_YAHOO", "Yahoo! adresa");
define("UE_LAN_YAHOO_DESC", "Yahoo! adresa");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN adresa");
define("UE_LAN_HOMEPAGE", "Domáca stránka");
define("UE_LAN_HOMEPAGE_DESC", "Užívateľove stránky (URL)");
define("UE_LAN_BIRTHDAY", "Narodeniny");
define("UE_LAN_BIRTHDAY_DESC", "Narodeniny");
define("UE_LAN_LANGUAGE", "Jazyk");
define("UE_LAN_LANGUAGE_DESC", "Užívateľov jazyk");
define("UE_LAN_COUNTRY", "Krajina");
define("UE_LAN_COUNTRY_DESC", "Užívateľova krajina (obsahuje tabuľku db)");

define("LAN_UE_FAIL_HOMEPAGE", "Neplatná položka pre nastavenia stránky obsahu");

?>