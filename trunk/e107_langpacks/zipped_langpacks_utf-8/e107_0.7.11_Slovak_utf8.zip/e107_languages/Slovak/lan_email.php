<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }

define("LAN_EMAIL_1", "Od:");
define("LAN_EMAIL_2", "IP adresa odosielateľa:");
define("LAN_EMAIL_3", "Odoslané z ");
define("LAN_EMAIL_4", "Odoslať email");
define("LAN_EMAIL_5", "Email pre priateľov");
define("LAN_EMAIL_6", "Myslím, že by ťa zaujímala tento článok zo servera");
define("LAN_EMAIL_7", "Pošli niekomu");
define("LAN_EMAIL_8", "Komentár");
define("LAN_EMAIL_9", "Prepáč - email nie je možné odoslať");
define("LAN_EMAIL_10", "Email odoslaný komu");
define("LAN_EMAIL_11", "Email odoslaný");
define("LAN_EMAIL_12", "Chyba");
define("LAN_EMAIL_13", "Odošli článok priateľovi");
define("LAN_EMAIL_14", "Odošli novinku priateľovi");
define("LAN_EMAIL_15", "Užívateľské meno: ");
define("LAN_EMAIL_106", "Zadali ste nesprávny fornát emailovej adresy");
define("LAN_EMAIL_185", "Poslať článok");
define("LAN_EMAIL_186", "Poslať novinku");
define("LAN_EMAIL_187", "Emailová adresa pre odoslanie");
define("LAN_EMAIL_188", "Myslím, že by ťa zaujímala táto novinka z ");
define("LAN_EMAIL_189", "Myslím, že by ťa zaujímal tento článok z");
define("LAN_EMAIL_190", "Vlož znázornený kód");

?>