<?php

define("LANINS_001", "inštalácia e107");


define("LANINS_002", "Fáza ");
define("LANINS_003", "1");
define("LANINS_004", "Výber jazyka");
define("LANINS_005", "Vyber si prosím jazyk, ktorý bude použitý počas inštalácie");
define("LANINS_006", "Nastav jazyk");
define("LANINS_007", "4");
define("LANINS_008", "Kontrola verzie PHP &amp; MySQL  / Kontrola nastavenia oprávnení");
define("LANINS_009", "Pretestovanie nastavenia oprávnení súborov");
define("LANINS_010", "Súbor nie je prístupný pre zápis: ");
define("LANINS_010a", "Zložka nie je prístupná pre zápis: ");
define("LANINS_011", "Chyba");
define("LANINS_012", "Funkcie MySQL pravdepodobne neexistujú. Toto pravdepodobne znamená, že buď MySQL PHP nadstavba nie je nainštalovaná alebo tvoja PHP inštalácia nie je skompilovaná s podporou MySQL."); // help for 012
define("LANINS_013", "Nie je možné rozpoznať číslo vašej verzie MySQL. Toto nie je kritická chyba, takže môžete pokračovať v inštalácii, no buďte si vedomí, že e107 vyžaduje MySQL >= 3.23 pre správne fungovanie.");
define("LANINS_014", "Oprávnenia súborov");
define("LANINS_015", "PHP verzia");
define("LANINS_016", "MySQL");
define("LANINS_017", "Potvrdiť");
define("LANINS_018", "Uistite sa, že všetky súbore na zozname existujú a sú serverom zapisovateľné. Toto normálne vyžaduje nastaviť ich CHMOD na 777, ale keďže sa prostredie mení - kontaktujte vášho poskytovateľa webhostu, ak zaznamenáte nejaké problémy.");
define("LANINS_019", "Verzia PHP nainštalovaného na vašom serveri neumožňuje beh e107. e107 vyžaduje PHP verzie od 4.3.0 vyššie, pre správny beh. Bud aktualizujte svoju PHP verziu, alebo kontaktujte vášho poskytovateľa s požiadavkou na aktualizáciu.");
define("LANINS_020", "Pokračovať v inštalácii");
define("LANINS_021", "2");
define("LANINS_022", "Detaily MySQL Servera");
define("LANINS_023", "Vložte sem, prosím, vaše MySQL údaje.

Ak máte základné oprávnenia, môžete vytvoriť novú databázu zaškrtnutím okienka, ak ich nemáte musíte najskôr vytvoriť alebo použiť už existujúcu databázu.

Ak máte len jednu databázu, použite predponu, takže skripty môžu zdieľať spoločnú databázu. 
Ak nepoznáte svoje MySQL údaje, kontaktujte svojho poskytovateľa webhostingu.");
define("LANINS_024", "MySQL server:");
define("LANINS_025", "MySQL meno užívateľa:");
define("LANINS_026", "MySQL heslo:");
define("LANINS_027", "MySQL databáza:");
define("LANINS_028", "Vytvoriť databázu?");
define("LANINS_029", "Predpona tabuliek:");
define("LANINS_030", "MySQL server, ktorý chcete, aby e107 používal. Môže obsahovať aj číslo portu, napr. \"hostname:port\" alebo cestu k miestnemu soketu, napr. \":/path/to/socket\" pre localhost.");
define("LANINS_031", "Meno užívateľa, ktoré má e107 používať pri spájaní s MySQL serverom");
define("LANINS_032", "Heslo pre užívateľa, ktorého ste práve vložili");
define("LANINS_033", "MySQL databáza, ktorú chcete, aby e107 používal. Ak má užívateľ oprávnenia pre vytvorenie databázy, môžete zvoliť automatické vytvorenie databázy, ak táto ešte neexistuje.");
define("LANINS_034", "Predpona, ktorú e107 použije pri vytváraní e107 tabuliek. Vhodné pri viacnásobných inštaláciách e107 v jednej databáze.");
define("LANINS_035", "Pokračovať");
define("LANINS_036", "3");
define("LANINS_037", "Overenie spojenia s MySQL");
define("LANINS_038", " a vytvorenie databázy");
define("LANINS_039", "Uistite sa prosím, že vyplníte všetky polia, hlavne MySQL server, MySQL meno užívateľa a MySQL databáza (Tieto sú vždy požadované MySQL serverom)");
define("LANINS_040", "Chyby");
define("LANINS_041", "Systém e107 nebol schopný vytvoriť spojenie s MySQL serverom s údajmi, ktoré ste použili. Vráťte sa, prosím, na poslednú stránku a uistite sa, že informácia je správna.");
define("LANINS_042", "Spojenie s MySQL serverom je vytvorené a overené.");
define("LANINS_043", "Databázu nie je možné vytvoriť, uistite sa prosím, že máte oprávnenie vytvárať databázu na vašom serveri.");
define("LANINS_044", "Databáza bola úspešne vytvorená.");
define("LANINS_045", "Stlačte tlačidlo, prosím, pre postup do ďalšej fázy.");
define("LANINS_046", "5");
define("LANINS_047", "Detaily administrátora");
define("LANINS_048", "Vráťte sa k poslednému kroku");
define("LANINS_049", "Dva heslá, ktoré ste vložili nie sú totožné. Vráťte sa späť a skúste to znovu, prosím.");
define("LANINS_050", "XML Rozšírenie");
define("LANINS_051", "Inštalované");
define("LANINS_052", "Nie je inštalované");
define("LANINS_053", "e107 .700 vyžaduje nainštalované PHP XML rozšírenie. Kontaktujte svojho poskytovateľa webhostingu alebo čítajte informáciu ");
define("LANINS_054", " pred pokračovaním");
define("LANINS_055", "Potvrdenie inštalácie");
define("LANINS_056", "6");
define("LANINS_057", " e107 má teraz všetky potrebné informácie pre dokončenie inštalácie.

Stlačte tlačidlo pre vytvorenie databázových tabuliek a pre uloženie vašich nastavení, prosím.

");
define("LANINS_058", "7");
define("LANINS_060", "Nie je možné čítať sql datový súbor

Uistite sa, prosím, že aúbor <b>core_sql.php</b> existuje v zložke <b>/e107_admin/sql</b>.");
define("LANINS_061", "e107 nebol schopný vytvoriť všetky potrebné databázové tabuľky.
Vyčistite databázu a odstráň možné problémy pred tým ako pokus zopakujete.");

define("LANINS_062", "[b]Vitajte na vašej novej internetovej stránke![/b]
e107 bol úspešne nainštalovaný a teraz je pripravený prijímať obsah.<br />Váš administračný panel sa [link=e107_admin/admin.php]nachádza tu[/link], kliknite na link, aby ste sa tam dostali. Budete sa musieť prihlásiť s použitím vášho užívateľského mena a hesla, ktoré ste použili počas inštalácie.

[b]Podpora[/b]
e107 stránka: [link=http://e107.org]http://e107.org[/link], najdete tu FAQ a dokumentáciu k e107.
Fóra: [link=http://e107.org/e107_plugins/forum/forum.php]http://e107.org/e107_plugins/forum/forum.php[/link]

[b]Downloady[/b]
Pluginy: [link=http://e107coders.org]http://e107coders.org[/link]
Témy: [link=http://e107themes.org]http://e107themes.org[/link]

Ďakujeme, že ste sa rozhodli vyskúšať e107 a dúfame, že naplní vaše potreby na internetové stránky.
(Túto správu môžete zmazať z administračného panela.)");

define("LANINS_063", "Vitajte v e107");

define("LANINS_069", "e107 bol úspešne nainštalovaný!

Z bezpečnostných dôvodov, musíte nastaviť oprávnenia súboru <b>e107_config.php</b> späť na CHMOD 644.

Taktiež zmažte install.php z vášho servera potom, čo kliknete na tlačidlo nižšie.
");
define("LANINS_070", "e107 nebol schopný uložiť hlavný konfiguračný súbor na váš server.

Uistite sa, prosím, že súbor <b>e107_config.php</b> má CHMOD nastavený na 666");
define("LANINS_071", "Dokončenie inštalácie");

define("LANINS_072", "Meno admina");
define("LANINS_073", "Toto je meno, ktoré budete používať re prihlásenie sa na stránku. Ak si želáte použiť ho tiež ako zobrazované meno");
define("LANINS_074", "Zobrazované meno admina");
define("LANINS_075", "Toto je meno, ktoré chcete, aby užívatelia videli vo vašom profile, fóre a iných oblastiach. Nechajte toto pole prázdne, ak chcete, aby bolo zobrazované to isté ako prihlasovacie meno.");
define("LANINS_076", "Heslo admina");
define("LANINS_077", "Vložte heslo, prosím, ktoré tu chcete používať");
define("LANINS_078", "Potvrdenie hesla admina");
define("LANINS_079", "Pre potvrdenie, prosím, znovu vložte heslo admina");
define("LANINS_080", "Adminov email");
define("LANINS_081", "Vložte svoju emailovú adresu");

define("LANINS_082", "uzivatel@vasestranky.sk");

// Better table creation error reporting
define("LANINS_083", "Chyba hlásená MySQL:");
define("LANINS_084", "Inštalačná aplikácia nemôže nadviazať spojenie s databázou");
define("LANINS_085", "Inštalačná aplikácia nemôže vybrať databázu:");

define("LANINS_086", "Meno admina, heslo admina a adminov email sú <b>požadované</b> polia. Vráťte sa na poslednú stránku, prosím a uistite sa, že ste použili správne informácie.");

define("LANINS_087", "Rôzne");
define("LANINS_088", "Obsah");
define("LANINS_089", "Downloady");
define("LANINS_090", "Členovia");
define("LANINS_091", "Napíš správu");
define("LANINS_092", "Kontaktuj nás");
define("LANINS_093", "Umožňuje prístup k súkromným položkám menu");
define("LANINS_094", "Príklad súkromnej triedy fóra");
define("LANINS_095", "Kontrola integrity");

define("LANINS_096", 'Posledné komentáre');
define("LANINS_097", '[viac ...]');
define("LANINS_098", 'Články');
define("LANINS_099", 'Úvodná strana čklánkov ...');
define("LANINS_100", 'Posledné príspevky fóra');
define("LANINS_101", 'Aktualizácia nastavenia menu');
define("LANINS_102", 'Dátum / Čas');
define("LANINS_103", 'Recenzie');
define("LANINS_104", 'Úvodná strana recenzií ...');

define("LANINS_105", '');
define("LANINS_106", '');

?>