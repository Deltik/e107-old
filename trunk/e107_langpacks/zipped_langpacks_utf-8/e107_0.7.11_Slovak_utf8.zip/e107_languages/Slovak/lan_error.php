<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_error.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Chyba");

define("LAN_ERROR_1", "Chyba 401 - Prístup zamietnutý");
define("LAN_ERROR_2", "Nemáte dostatočné práva pre prístup na túto stránku.");
define("LAN_ERROR_3", "Ak považujete túto chybu za bezpredmetnú, informujte, prosím, administrátora.");
define("LAN_ERROR_4", "Chyba 403 - Chyba autentifikácie");
define("LAN_ERROR_5", "Stránka, na ktorú požadujete prístup potrebuje vaše správe prihlasovacie údaje. Zadali ste alebo nesprávne užívateľské meno alebo heslo, poprípade váš internetový prehliadač nepodporuje túto funkciu.");
define("LAN_ERROR_6", "Ak považujete túto chybu za bezpredmetnú, informujte, prosím, administrátora.");
define("LAN_ERROR_7", "Chyba 404 - Dokument nenájdený");
define("LAN_ERROR_8", "Vami požadovaná adresa URL nebola nájdená na serveri. Platnosť odkazu alebo vypršala alebo bol dokument zmazaný alebo nemáte povolený prístup k tomuto dokumentu.");
define("LAN_ERROR_9", "Ak považujete túto chybu za bezpredmetnú, informujte, prosím, administrátora.");
define("LAN_ERROR_10", "Chyba 500 - Nepsrávna hlavička");
define("LAN_ERROR_11", "Server zaznamenal vnútornú chybu alebo chybu v konfigurácií a vašu požiadavku bohužial nemohol spracovať.");
define("LAN_ERROR_12", "Ak považujete túto chybu za bezpredmetnú, informujte, prosím, administrátora.");
define("LAN_ERROR_13", "Chyba - Neznáma");
define("LAN_ERROR_14", "Na servri sa vyskytla neznáma chyba");
define("LAN_ERROR_15", "Ak považujete túto chybu za bezpredmetnú, informujte, prosím, administrátora.");
define("LAN_ERROR_16", "Váš neúspešný pokus o prihlásenie");
define("LAN_ERROR_17", "bol zaznamenaný.");
define("LAN_ERROR_18", "Očividne ste boli požiadaný zotrvať tu");
define("LAN_ERROR_19", "Bohužial, doba platnosti odkazu vypršala alebo ste zadali nesprávnu adresu.");
define("LAN_ERROR_20", "Prosím, kliknite sem pre návrat na úvodnú stránku");
define("LAN_ERROR_21", "Požadovaná URL nemôže byť na tomto serveri nájdená. Link, ktorý ste nasledovali je pravdepodobne neplatný.");
define("LAN_ERROR_22", "Prosím, kliknite sem pre návrat na stránku pre vyhľadávanie");
define("LAN_ERROR_23", "Váš pokus dosiahnúť ");
define("LAN_ERROR_24", " bol neúspešný.");

// 0.7.6
define("LAN_ERROR_25", "[1]: Nie je možné načítať základné nastavenia z databázy - Základné nastavenia existujú, no nie je možné z nich vychádzať. Pokušam sa obnoviť základnú zálohu ...");
define("LAN_ERROR_26", "[2]: Nie je možné načítať základné nastavenia z databázy - základné nastavenia neexistujú.");
define("LAN_ERROR_27", "[3]: Základné nastavenia boli uložené - záloha bola aktivovaná.");
define("LAN_ERROR_28", "[4]: Základná záloha nebola nájdená. Spusti, prosím, <a href='".e_FILE."resetcore/resetcore.php'>Reset_Core</a> utilitu pre vytvorenie tvojich základných nastavení. <br />Po vytvorení tvojich základných nastavení, ulož prosím zálohu z admin/sql obrazovky.");
define("LAN_ERROR_29", "[5]: Pole(ia) bolo ponechané prázdne. Znovu odošli formulár s vyplnenými všetkými požadovanými poliami, prosím.");
define("LAN_ERROR_30", "[6]: Nie je možné vytvoriť platné spojenie s mySQL. Skontroluj si, prosím, či súbor e107_config.php obsahuje správne informácie.");
define("LAN_ERROR_31", "[7]: mySQL funguje, no databáza ({$mySQLdefaultdb}) nemôže byť spojená.<br />Skontroluj si, prosím, či súbor e107_config.php existuje a či obsahuje správne informácie.");
define("LAN_ERROR_32", "Pre dokončenie upgradu, skopíruj nasledujúci text do svojho e107_config.php súboru:");

?>
