<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Členovia");

define("LAN_20", "Chyba");
define("LAN_112", "Emailová adresa");
define("LAN_115", "ICQ číslo");
define("LAN_116", "AIM adresa");
define("LAN_117", "MSN Messenger");
define("LAN_118", "Narodeniny");
define("LAN_119", "Bydlisko");
define("LAN_120", "Podpis");
define("LAN_137", "Toto nie sú informácie dostupné neregistrovaným užívateľom");
define("LAN_138", "Registrovaný užívatelia: ");
define("LAN_139", "Poradie: ");
define("LAN_140", "Registrovaný užívateľ");
define("LAN_141", "Žiadny registrovaný užívatelia.");
define("LAN_142", "Člen");
define("LAN_143", "[skryté na požiadanie]");
define("LAN_144", "URL webstránky");
define("LAN_145", "Dátum registrácie");
define("LAN_146", "Počet návštev od registrácie");
define("LAN_147", "Príspevkov chatboxu");
define("LAN_148", "Príspevkov komentárov");
define("LAN_149", "Príspevkov fóra");
define("LAN_308", "Skutočné meno");
define("LAN_400", "Toto nieje platný užívateľ.");
define("LAN_401", "žiadne informácie");
define("LAN_402", "Profil užívateľa");
define("LAN_403", "Štatistiky");
define("LAN_404", "Posledná návšteva");
define("LAN_405", "dňami");
define("LAN_406", "Hodnotenie");
define("LAN_407", "žiadne");
define("LAN_408", "žiadne foto");
define("LAN_409", "bodov");
define("LAN_410", "Rôzne");
define("LAN_411", "Kliknite sem pre aktualizáciu vašich údajov");
define("LAN_412", "Kliknite sem pre editáciu údajov o tomto užívateľovi");
define("LAN_413", "zmazať foto");
define("LAN_414", "predchádzajúci člen");
define("LAN_415", "ďalší člen");
define("LAN_416", "Pre prístup na túto stránku musíte byť prihlásený");
define("LAN_417", "Hlavný administrátor");
define("LAN_418", "Administrátor");
define("LAN_419", "Ukázať");
define("LAN_420", "ZOSTUP");
define("LAN_421", "VZOSTUP");
define("LAN_422", "Vykonať");
define("LAN_423", "Kliknite sem pre zobrazenie užívateľových komentárov");
define("LAN_424", "Kliknite sem pre zobrazenie užívateľových príspevkov fóra");
define("LAN_425", "Poslať osobnú správu");
define("LAN_426", "od poslednej návštevy");

define("USERLAN_1", "Hodnotenie");
define("USERLAN_2", "Nemáte prístup k zobrazeniu tejto stránky.");

?>
