<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Revision: 1.2 $
|     $Date: 2005/12/09 20:59:02 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Vyber užívateľa");
define("US_LAN_2", "Vyber triedu užívateľa");
define("US_LAN_3", "Všetci užívatelia");
define("US_LAN_4", "Nájdi meno užívateľa");
define("US_LAN_5", "Užívateľ(ia) nájdený(í)");
define("US_LAN_6", "Hľadaj");

?>