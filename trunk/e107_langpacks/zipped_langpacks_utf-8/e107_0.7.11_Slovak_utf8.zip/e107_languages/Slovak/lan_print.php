<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak LAN_PRINTguage File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Verzia pre tlač"); }

define("LAN_PRINT_86", "Kategória:");
define("LAN_PRINT_87", "od ");
define("LAN_PRINT_94", "Zaslal");
define("LAN_PRINT_135", "Novinka: ");
define("LAN_PRINT_303", "Táto novinka je od ");
define("LAN_PRINT_304", "Titulok: ");
define("LAN_PRINT_305", "Podnadpis: ");
define("LAN_PRINT_306", "Toto je od: ");
define("LAN_PRINT_307", "Vytlač túto stránku");

define("LAN_PRINT_1", "verzia pre tlač");

?>