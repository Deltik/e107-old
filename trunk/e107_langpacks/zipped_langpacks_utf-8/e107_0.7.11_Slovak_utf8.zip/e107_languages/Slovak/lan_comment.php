<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_comment.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("COMLAN_0", "[blokované adminom]");
define("COMLAN_1", "Odblokovať");
define("COMLAN_2", "Zablokovať");
define("COMLAN_3", "Zmazať");
define("COMLAN_4", "Informácie");
define("COMLAN_5", "Komentáre ...");
define("COMLAN_6", "Musíte byť prihlásený, aby ste mohli zasielať komentáre - prosím prihláste alebo zaregistrujte sa");
define("COMLAN_7", "Hlavný administrátor");
define("COMLAN_8", "Komentár");
define("COMLAN_9", "Pridať komentár");
define("COMLAN_10", "Administrátor");
define("COMLAN_11", "Nie je možné uložiť váš komentár do databázy - prosím, skontrolujte neštandardné znaky.");
define("COMLAN_16", "Užívateľké meno: ");
define("COMLAN_99", "Komentáre");
define("COMLAN_100", "Novinky");
define("COMLAN_101", "Anketa");
define("COMLAN_102", "Odpoveď na: ");
define("COMLAN_103", "Článok");
define("COMLAN_104", "Recenzia");
define("COMLAN_105", "Stránka obsahu");
define("COMLAN_145", "Registrovaný: ");
define("COMLAN_194", "Hosť");
define("COMLAN_195", "Registrovaný člen");
define("COMLAN_310", "Nie je možné zaslať komentár s týmto užívateľským menom - ak je to vaše užívateľské meno prosím prihláste sa.");
define("COMLAN_312", "Dvojitý komentár, nie je možné uložiť.");
define("COMLAN_313", "Umiestnenie");
define("COMLAN_314", "moderovať komentáre");
define("COMLAN_315", "Sledovať komentár");
define("COMLAN_316", "Žiadne sledovanie novinky.");
define("COMLAN_317", "Moderovať sledovania");
define("COMLAN_318", "Editovať komentáre");
define("COMLAN_319", "editovať");
define("COMLAN_320", "Aktualizovať komentáre");
define("COMLAN_321", "tu");
define("COMLAN_322", "pre registráciu");
define("COMLAN_323", "Chyba!");
define("COMLAN_324", 'Predmet');
define("COMLAN_325", 'Re:');
define("COMLAN_326", 'Odpovedať');
define("COMLAN_327", 'Hodnotenie');
define("COMLAN_328", 'Komentáre sú zamknuté');
define("COMLAN_329", 'Neoprávnene');
define("COMLAN_330", 'IP:');

define("COMLAN_TYPE_1", "správy");
define("COMLAN_TYPE_2", "download");
define("COMLAN_TYPE_3", "faq");
define("COMLAN_TYPE_4", "anketa");
define("COMLAN_TYPE_5", "documenty");
define("COMLAN_TYPE_6", "hľadanie chýb");
define("COMLAN_TYPE_7", "idey");
define("COMLAN_TYPE_8", "profil užívateľa");
define("COMLAN_TYPE_PAGE", "Obsah");		// Reall custom page, but use a 'non-technical' description

?>