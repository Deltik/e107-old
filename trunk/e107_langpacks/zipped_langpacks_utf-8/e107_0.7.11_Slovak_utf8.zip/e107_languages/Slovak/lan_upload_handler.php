<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Typ súboru");
define("LANUPLOAD_2", "nie je povolený a bude okamžite zmazaný.");
define("LANUPLOAD_3", "Úspešne uploadované");
define("LANUPLOAD_4", "Niektorý z cieľových adresárov neexistuje alebo nie je zapisovateľný. (chmod 777)");
define("LANUPLOAD_5", "Uploadovaný súbor prekračuje direktívu upload_max_filesize v php.ini.");
define("LANUPLOAD_6", "Uploadovaný súbor prekračuje direktívu MAX_FILE_SIZE špecifikovanú v HTML kóde.");
define("LANUPLOAD_7", "Uploadovaný súbor bol presunutý len čiastočne.");
define("LANUPLOAD_8", "Žiadny súbor neuploadovaný.");
define("LANUPLOAD_9", "Veľkosť uploadovaného súboru je 0B");
define("LANUPLOAD_10", "Uploadovaný súbor [Duplicitný názov] - Súbor s rovnakým názvom už existuje.");
define("LANUPLOAD_11", "Súbor nebol uploadovaný. Súbor: ");
define("LANUPLOAD_12", "Chyba");
define("LANUPLOAD_13", "Chýba dočasná zložka");
define("LANUPLOAD_14", "Zápis súboru zlyhalo");
define("LANUPLOAD_15", "Upload nie je povolený");
define("LANUPLOAD_16", "Neznáma chyba");
define("LANUPLOAD_17", "Neplatné meno pre uploadovaný súbor");
define("LANUPLOAD_18", "Uploadovaný súbor prekračuje povolené limity.");
define("LANUPLOAD_19", "Príliš veľa súborov uploadovaných - prebytok zmazaný.");

?>