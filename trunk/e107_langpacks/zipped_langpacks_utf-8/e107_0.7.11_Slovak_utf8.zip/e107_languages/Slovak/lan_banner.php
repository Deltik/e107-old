<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Reklama");

define("BANNERLAN_16", "Užívateľské meno: ");
define("BANNERLAN_17", "Heslo: ");
define("BANNERLAN_18", "Pokračovať");
define("BANNERLAN_19", "Prosím, zadajte vaše klintské užívateľské meno a heslo");
define("BANNERLAN_20", "Prepáčte, ale vaše detaily neboli nájdené v databáze. Kontaktujte, prosím, hlavného administrátora.");
define("BANNERLAN_21", "Štatistiky reklamy");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "ID reklamy");
define("BANNERLAN_24", "Kliknutí");
define("BANNERLAN_25", "Z celkových %");
define("BANNERLAN_26", "Doba kampane");
define("BANNERLAN_27", "Uplynutá doba");
define("BANNERLAN_28", "Do konca zostáva");
define("BANNERLAN_29", "Žiadne reklamy");
define("BANNERLAN_30", "Neobmedzená");
define("BANNERLAN_31", "Neaplikovaná");
define("BANNERLAN_32", "Áno");
define("BANNERLAN_33", "Nie");
define("BANNERLAN_34", "Koniec:");
define("BANNERLAN_35", "Kliknutí podľa IP adries");
define("BANNERLAN_36", "Aktivita:");
define("BANNERLAN_37", "Štart:");
define("BANNERLAN_38", "Chyba");

?>
