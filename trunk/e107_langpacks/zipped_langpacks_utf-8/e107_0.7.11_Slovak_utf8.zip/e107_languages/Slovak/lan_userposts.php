<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Príspevky užívateľa");

define("UP_LAN_0", "Všetky príspevky fóra od ");
define("UP_LAN_1", "Všetky komentáre od ");
define("UP_LAN_2", "Vlákno");
define("UP_LAN_3", "Zobrazení");
define("UP_LAN_4", "Odpovedí");
define("UP_LAN_5", "Posledný príspevok");
define("UP_LAN_6", "Vlákien");
define("UP_LAN_7", "Žiadne komentáre");
define("UP_LAN_8", "Žiadne príspevky");
define("UP_LAN_9", " dňa ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Zaslal: ");
define("UP_LAN_12", "Hľadať");
define("UP_LAN_13", "Komentáre");
define("UP_LAN_14", "Príspevky fóra");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP adresa");

?>