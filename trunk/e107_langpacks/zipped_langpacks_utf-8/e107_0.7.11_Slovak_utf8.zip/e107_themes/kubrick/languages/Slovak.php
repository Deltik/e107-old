<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/kubrick/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/08/29 16:22:56 $
|     $Author: streaky $
|     $Translation: whitewolfsix $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' od <a href='http://e107.org' title='e107.org' rel='external'>jalista</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, založené na originálnej téme od Michaela Heilemanna (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Komentáre sú vypnuté pre túto položku");
define("LAN_THEME_3", "Komentár: ");
define("LAN_THEME_4", "Čítať zvyšok ...");
define("LAN_THEME_5", "Spätné sledovanie: ");


?>
