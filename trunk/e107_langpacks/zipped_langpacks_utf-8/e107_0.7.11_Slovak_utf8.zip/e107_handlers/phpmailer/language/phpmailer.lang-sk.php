<?php
/**
* PHPMailer language file.
* Slovak Version
* translation: whitewolfsix
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'Musíte zadať aspoň jednu ' . ' e-mailovú adresu príjemcu.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer nie je podporovaný.';
$PHPMAILER_LANG["execute"] = 'Nie je možné vykonať: ';
$PHPMAILER_LANG["instantiate"] = 'Nie je možné konkretizovať mailovú funkciu.';
$PHPMAILER_LANG["authenticate"] = 'SMTP chyba: Nie je možné overiť.';
$PHPMAILER_LANG["from_failed"] = 'Nasledujúca adresa Od zlyhala: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Chyba: Nasledujúci ' . 'príjemci zlyhali: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Chyba: Dáta neboli prijaté.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Chyba: Nie je možné spojiť sa s SMTP hostom.';
$PHPMAILER_LANG["file_access"] = 'Nie je možné vybrať súbor: ';
$PHPMAILER_LANG["file_open"] = 'Chyba súboru: Nie je možné súbor otvoriť: ';
$PHPMAILER_LANG["encoding"] = 'Neznáme kódovanie: ';
?>