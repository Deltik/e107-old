// SK jazykové premenné
// Autor: WhiteWolfSix
// Kódovanie: UTF-8

tinyMCELang['lang_ibrowser_title'] = 'Vložiť / Upraviť obrázok';
tinyMCELang['lang_ibrowser_desc'] = 'Vložiť / Upraviť obrázok';
tinyMCELang['lang_ibrowser_library'] = 'Knižnica';
tinyMCELang['lang_ibrowser_preview'] = 'Náhľad';
tinyMCELang['lang_ibrowser_img_sel'] = 'Výber obrázka';
tinyMCELang['lang_ibrowser_img_info'] = 'Informácia obrázka';
tinyMCELang['lang_ibrowser_img_upload'] = 'Upload obrázka';
tinyMCELang['lang_ibrowser_images'] = 'Obrázky';
tinyMCELang['lang_ibrowser_src'] = 'Zdroj';
tinyMCELang['lang_ibrowser_alt'] = 'Popis';
tinyMCELang['lang_ibrowser_size'] = 'Rozmer';
tinyMCELang['lang_ibrowser_align'] = 'Obtekanie textu';
tinyMCELang['lang_ibrowser_height'] = 'Výška';
tinyMCELang['lang_ibrowser_width'] = 'Šírka';
tinyMCELang['lang_ibrowser_reset'] = 'Vymazať rozmery';
tinyMCELang['lang_ibrowser_border'] = 'Okraj';
tinyMCELang['lang_ibrowser_hspace'] = 'HMedzera';
tinyMCELang['lang_ibrowser_vspace'] = 'VMedzera';
tinyMCELang['lang_ibrowser_select'] = 'Uložiť';
tinyMCELang['lang_ibrowser_delete'] = 'Zmazať';
tinyMCELang['lang_ibrowser_cancel'] = 'Zrušiť';
tinyMCELang['lang_ibrowser_uploadtxt'] = 'Súbor';
tinyMCELang['lang_ibrowser_uploadbt'] = 'Upload';
// error messages
tinyMCELang['lang_ibrowser_error'] = 'Chyba';
tinyMCELang['lang_ibrowser_errornoimg'] = 'Vyberte obrázok, prosím';
tinyMCELang['lang_ibrowser_errornodir'] = 'Knižnica fyzicky neexistuje';
tinyMCELang['lang_ibrowser_errorupload'] = 'Počas uploadovania súboru došlo ku chybe. Skúste znovu neskoršie, prosím.';
tinyMCELang['lang_ibrowser_errortype'] = 'Chybný typ obrazového súboru';
tinyMCELang['lang_ibrowser_errordelete'] = 'Mazanie zlyhalo';
tinyMCELang['lang_ibrowser_confirmdelete'] = 'Kliknite na OK pre zmazanie obrázku!';
tinyMCELang['lang_ibrowser_error_width_nan'] = 'Šírka nie je číslo!';
tinyMCELang['lang_ibrowser_error_height_nan'] = 'Výška nie je číslo!';
tinyMCELang['lang_ibrowser_error_border_nan'] = 'Okraj nie je číslo!';
tinyMCELang['lang_ibrowser_error_hspace_nan'] = 'Horizontálna medzera nie je číslo!';
tinyMCELang['lang_ibrowser_error_vspace_nan'] = 'Vertikálna medzera nie je číslo!';	