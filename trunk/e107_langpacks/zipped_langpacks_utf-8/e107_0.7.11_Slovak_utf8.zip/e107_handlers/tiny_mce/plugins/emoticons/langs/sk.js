// SK jazykové premenné

tinyMCELang['lang_insert_emoticons_title'] = 'Vlož smajla';
tinyMCELang['lang_emoticons_desc'] = 'Smajle';