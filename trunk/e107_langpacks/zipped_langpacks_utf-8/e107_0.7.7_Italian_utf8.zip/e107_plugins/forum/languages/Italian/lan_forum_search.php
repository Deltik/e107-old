<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/16 05:25:35 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Seleziona il forum");
define("FOR_SCH_LAN_3", "Tutti i forum");
define("FOR_SCH_LAN_4", "Tutto i messaggi");
define("FOR_SCH_LAN_5", "Parte della discussione");
?>
