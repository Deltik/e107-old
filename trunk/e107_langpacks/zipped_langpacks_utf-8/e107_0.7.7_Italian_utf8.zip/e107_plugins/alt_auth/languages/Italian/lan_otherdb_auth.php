<?php
define("OTHERDB_LAN_1", "Tipo di Database:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Username:");
define("OTHERDB_LAN_4", "Password:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Tabella");
define("OTHERDB_LAN_7", "Campo Username :");
define("OTHERDB_LAN_8", "Campo Password :");
define("OTHERDB_LAN_9", "Metodo Password :");
define("OTHERDB_LAN_10", "Configura otherdb auth");
define("OTHERDB_LAN_11", "** I campi seguenti non sono richiest usando un database e107");

?>
