<?php
//   Italian Translation: e107 Italian Team http://www.e107it.org

define("LAN_350", "Imposta Tema");
define("LAN_351", "Scegli Tema");

?>