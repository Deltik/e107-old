<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_comment.php,v $
|     $Revision: 1.7$
|     $Date: 2005/06/30 14:18:21 $|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+*/
define("COMLAN_0", "Bloccato da Amministratore");
define("COMLAN_1", "Sbloccato");
define("COMLAN_2", "Bloccato");
define("COMLAN_3", "Elimina");
define("COMLAN_4", "Informazioni");
define("COMLAN_5", "Commenti...");
define("COMLAN_6", "Devi essere loggato per inserire commenti su questo sito - Per favore loggati se sei registrato, oppure premi");
define("COMLAN_7", "Voto");
define("COMLAN_8", "Commento");
define("COMLAN_9", "Invia Commento");
define("COMLAN_10", "Amministratore");
define("COMLAN_11", "Impossibile inserire il tuo commento nel database - Per favore riscrivi evitando tutti i caratteri non standard.");
define("COMLAN_16", "Nome utente");
define("COMLAN_99", "Commenti");
define("COMLAN_100", "News");
define("COMLAN_101", "Sondaggio");
define("COMLAN_102", "Ripsondi a");
define("COMLAN_103", "Articolo");
define("COMLAN_104", "Recensione");
define("COMLAN_105", "Contenuti");
define("COMLAN_145", "Utente");
define("COMLAN_194", "Ospite");
define("COMLAN_195", "Utente registrato");
define("COMLAN_310", "Impossibile accettare il messaggio in quanto lo username inserito è registrato. Se sei tu l'utente registrato, per favore fai login.");
define("COMLAN_312", "Post Duplicato. Impossibile accettare");
define("COMLAN_313", "Provenienza");
define("COMLAN_314", "Modera commenti");
define("COMLAN_315", "Trackbacks ");
define("COMLAN_316", "Nessun trackbacks for questo commento.");
define("COMLAN_317", "Modera trackbacks.");
define("COMLAN_318", "Edita commento");
define("COMLAN_319", "edita");
define("COMLAN_320", "Aggiorna commento");
define("COMLAN_321", "qui");
define("COMLAN_322", "per registrarti");
define("COMLAN_323", "Errore!");
define("COMLAN_324", "Oggetto");
define("COMLAN_325", "Re:");
define("COMLAN_326", "Replica a questo");
define("COMLAN_327", "Valutazione");
define("COMLAN_328", "I Commenti sono bloccati");
define("COMLAN_329", "Non Autorizzato");
define("COMLAN_330", "IP:");
define("COMLAN_TYPE_1", "news");
define("COMLAN_TYPE_2", "download");
define("COMLAN_TYPE_3", "faq");
define("COMLAN_TYPE_4", "sondaggio");
define("COMLAN_TYPE_5", "documenti");
define("COMLAN_TYPE_6", "bugtrack");
define("COMLAN_TYPE_7", "idee");
define("COMLAN_TYPE_8", "profilo utente");


?>