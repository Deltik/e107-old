<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_prefs.php,v $
|     $Revision: 1.46 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107 Powered Website");
define("LAN_PREF_2", "e107 Website System");
define("LAN_PREF_3", "<a href=&quot;http://www.e107italia.org/&quot; rel=&quot;external&quot;>e107 Italian Team</a> © 2006<br />This site is powered by <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, which is released under the terms of the <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL License.");
define("LAN_PREF_4", "censurato");
define("LAN_PREF_5", "Forums");
?>
