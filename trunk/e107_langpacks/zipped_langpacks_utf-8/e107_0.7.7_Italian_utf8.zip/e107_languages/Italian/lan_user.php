<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/04/06 03:53:00 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Utenti Registrati");

define("LAN_20", "Errore");
define("LAN_112", "Indirizzo Email");
define("LAN_115", "Numero ICQ");
define("LAN_116", "Indirizzo AIM");
define("LAN_117", "MSN Messenger");
define("LAN_118", "Compleanno");
define("LAN_119", "Provenienza");
define("LAN_120", "Firma");
define("LAN_137", "Non ci sono informazioni per questo Utente poichè non è registrato");
define("LAN_138", "Utenti registrati: ");
define("LAN_139", "Ordinamento: ");
define("LAN_140", "Utenti registrati");
define("LAN_141", "Ancora nessun utente registrato.");
define("LAN_142", "Utente");
define("LAN_143", "[nascosto su richiesta]");
define("LAN_144", "URL Sito web");
define("LAN_145", "Registrato il");
define("LAN_146", "Visite al sito dalla data di registrazione");
define("LAN_147", "Messaggi Chatbox");
define("LAN_148", "Commenti scritti");
define("LAN_149", "Messaggi Forum");
define("LAN_308", "Nome Reale");
define("LAN_400", "Non è un utente valido.");
define("LAN_401", "nessuna informazione");
define("LAN_402", "Profilo Utente");
define("LAN_403", "Statistiche Sito");
define("LAN_404", "Ultima visita");
define("LAN_405", "giorni fa");
define("LAN_406", "Livello");
define("LAN_407", "nessuno");
define("LAN_408", "nessuna foto");
define("LAN_409", "punti");
define("LAN_410", "Varie");
define("LAN_411", "Premi qui per aggiornare le tue informazioni");
define("LAN_412", "Premi qui per modificare le informazioni di questo utente");
define("LAN_413", "Elimina Fotografia");
define("LAN_414", "Utente precedente");
define("LAN_415", "Utente successivo");
define("LAN_416", "Devi essere registrato e loggato per accedere a questa pagina");
define("LAN_417", "Amministratore principale del sito");
define("LAN_418", "Amministratore del sito");
define("LAN_419", "Mostra");
define("LAN_420", "DISC");
define("LAN_421", "ASC");
define("LAN_422", "Vai");
define("LAN_423", "Premi qui per vedere i commenti di questo utente");
define("LAN_424", "Premi qui per vedere i messaggi scritti sul forum da questo utente");
define("LAN_425", "Invia un messaggio privato a questo utente");
define("LAN_426", "fa");

define("USERLAN_1", "Peer Rating");

define("USERLAN_2", "Non hai i permessi per vedere questa pagina.");

?>
