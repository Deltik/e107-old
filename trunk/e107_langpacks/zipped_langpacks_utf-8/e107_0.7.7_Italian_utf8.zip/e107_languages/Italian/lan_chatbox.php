<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|
|     $Author: e107coders $
|	Traduzione Italiana a cura di:
|   e107 italian team http://e107it.org
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Impostazioni ChatBox aggiornate.");
define("CHBLAN_2", "Moderata.");
define("CHBLAN_3", "Ancora nessun messaggio.");
define("CHBLAN_4", "Utente registrato");
define("CHBLAN_5", "Ospite");
define("CHBLAN_6", "sblocca");
define("CHBLAN_7", "blocca");
define("CHBLAN_8", "elimina");
define("CHBLAN_9", "Modera la Chatbox");
define("CHBLAN_10", "Modera i messaggi");
define("CHBLAN_11", "Messaggi Chatbox da visualizzare");
define("CHBLAN_12", "numero di messaggi visualizzabili in chatbox");
define("CHBLAN_13", "Sostituisci links");
define("CHBLAN_14", "se spuntato, i links inseriti saranno sostituiti dal testo inserito nel box sottostante");
define("CHBLAN_15", "Stringa di sostituzione");
define("CHBLAN_16", "i links saranno sostituiti da questa stringa");
define("CHBLAN_17", "Conteggio per a-capo");
define("CHBLAN_18", "Le parole più lunghe del numero impostato qui saranno verranno automaticamente ridotte a-capo");
define("CHBLAN_19", "Aggiorna Impostazioni");
define("CHBLAN_20", "Impostazioni Chatbox");
define("CHBLAN_21", "Pulizia");
define("CHBLAN_22", "Elimina i messaggi più vecchi a un determinato periodo");
define("CHBLAN_23", "Elimina i messaggi più vecchi di ");
define("CHBLAN_24", "Un giorno");
define("CHBLAN_25", "Una Settimana");
define("CHBLAN_26", "Un Mese");
define("CHBLAN_27", "- Elimina tutti messaggi -");
define("CHBLAN_28", "Chatbox Pulita.");
define("CHBLAN_29", "Visualizza la chatbox entro un determinato layer");
define("CHBLAN_30", "Altezza Layer");
define("CHBLAN_31", "Mostra faccine");
?>