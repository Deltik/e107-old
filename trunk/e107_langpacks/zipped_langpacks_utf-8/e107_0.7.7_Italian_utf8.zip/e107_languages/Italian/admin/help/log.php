<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Da questa pagina attivi le Statistiche del Sito. Se disponi di poco spazio sul
tuo server seleziona solo il box Dominio, in questo modo verranno rilevate le statistiche del
solo dominio in sostituzione dell'url completa, es. 'jalist.com' invece di 'http://jalist.com/links.php' ";

$ns -> tablerender("Help Statistiche", $text);
?>
