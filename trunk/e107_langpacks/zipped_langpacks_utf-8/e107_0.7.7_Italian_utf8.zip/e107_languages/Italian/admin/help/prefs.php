<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Da questo Pannello puoi impostare le tue Preferenze: tutte opzioni essenziali
per la gestione del sito, dall'impostazione del Nome e descrizione del sito, alla Protezione flood
e impostazione filtri di sicurezza.";

$ns -> tablerender("Help Preferenze", $text);
?>
