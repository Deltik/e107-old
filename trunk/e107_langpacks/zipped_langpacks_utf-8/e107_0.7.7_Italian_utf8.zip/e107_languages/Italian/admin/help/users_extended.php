<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Il Pannello Campi Completi Utente consente di definire eventuali campi supplementari
da aggiungere al Profilo Personale degli utenti registrati.";

$ns -> tablerender("Help Campi Completi Utente", $text);
?>
