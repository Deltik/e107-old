<?php
//|     Italian Translation:
//|           e107 Italian Team http://www.e107it.org
//|           con la collaborazione di Stefano Vecchi

$text = "Imposta da qui le tue preferenze per la chatbox.<br />Se la casella sostituisci link è selezionata, qualunque link inserito verrà sostituito dal testo inserito nel box di testo. Questo eviterà che link troppo lunghi causino problemi al display. Wordwrap sostituirà il testo più lungo di quanto qui specificato.";

$ns -> tablerender("Chatbox", $text);
?>
