<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$caption = "Pagina Principale Help";
$text = "Da questo Pannello puoi segliere quale Modulo impostare come Pagina Principale del sito.
News è il Modulo predefinito.";
$ns -> tablerender("Help Pagina Principale", $text);
?>
