<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Da questo Pannello puoi creare Menù e Pagine personalizzati con il contenuto da te scelto.<br /><br />
Per spiegazioni più dettagliate vedi <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a>.";

$ns -> tablerender(CUSLAN_18, $text);
?>
