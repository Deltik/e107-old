<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Da qui puoi abilitare/disabilitare l'opzione di inserimento immagini da parte degli utenti.
Imposta il metodo di ridimensionamento e verifichi gli avatars caricati.";
$ns -> tablerender("Help Immagini", $text);
?>
