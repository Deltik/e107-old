<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_links.php,v $
|     $Revision: 1.13 $
|     $Date: 2005/11/23 18:08:28 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("LCLAN_1", "Opzioni salvate");
define("LCLAN_2", "Link salvato nel database.");
define("LCLAN_3", "Link aggiornato nel database.");
// define("LCLAN_4", "Link deleted.");

define("LCLAN_6", "Ordinamento Aggiornato.");
define("LCLAN_8", "Link Esistenti");
define("LCLAN_12", "Tipo di rendirizzazione Link");
define("LCLAN_15", "Nome Link");
define("LCLAN_16", "URL Link");
define("LCLAN_17", "Descrizione Link");
define("LCLAN_18", "Buttone / Icona Link");
define("LCLAN_19", "Tipo apertura del Link");
define("LCLAN_20", "Apri nella stessa finestra");
define("LCLAN_23", "Apri in una nuova finestra");
define("LCLAN_24", "Apri in minifinestra di 600x400");
define("LCLAN_25", "Classe Link");
define("LCLAN_26", "La spunta renderà visibile il link ai soli utenti della classe scelta");
define("LCLAN_27", "Aggiorna");
define("LCLAN_28", "Crea");
define("LCLAN_29", "Links");
define("LCLAN_30", "muovi su");
define("LCLAN_31", "muovi giu");
define("LCLAN_39", "Vedi Immagini");
define("LCLAN_53", "Link");
define("LCLAN_54", "Elimina");
define("LCLAN_58", "Sei sicuro di vole cancellare il link?");
define("LCLAN_61", "Nessun links");
define("LCLAN_62", "Home Links");
define("LCLAN_63", "Crea Nuovo");
define("LCLAN_68", "Opzioni");
define("LCLAN_78", "Mostra descrizione come Screen-Tip");
define("LCLAN_79", "La descrizione sarà mostrata al passaggio del mouse sul link");
define("LCLAN_80", "Attiva sottomenù espandibili");
define("LCLAN_81", "Sub-menus saranno visualizzati solo dopo aver premuto la categoria principale a cui appartengono. (La categoria principale non sarà abilitata)");
define("LCLAN_83", "Generatore Sottomenù");
define("LCLAN_88", "Ozioni");
define("LCLAN_89", "Immagine");
define("LCLAN_90", "Nome Link");
define("LCLAN_91", "Muovi");
define("LCLAN_95", "Classe");

define("LCLAN_96", "Visualizzato nel tuo tema come");


define("LINKLAN_1", "Apri in finestra 800x600");
define("LINKLAN_2", "Menù principale");
define("LINKLAN_3", "Nessun Menù Principale (Link Normale)");
define("LINKLAN_4", "Generatore sottomenù");
define("LINKLAN_5", "Genera Sottomenù");
define("LINKLAN_6", "Crea sottomenù da:");
define("LINKLAN_7", "Sotto quale menù crei i link?");
define("LINKLAN_8", "Categorie News");
define("LINKLAN_9", "Categorie Download");
define("LINKLAN_10", "Crea Sottomenù");

?>
