<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_filemanager.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/14 23:35:15 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg
+----------------------------------------------------------------------------+
*/

define("FMLAN_1", "Caricato");
define("FMLAN_2", "nella");
define("FMLAN_3", "cartella");
define("FMLAN_4", "Il file caricato eccede le impostazioni della variabile upload_max_filesize impostate nel php.ini.");
// define("FMLAN_5", "Il file caricato eccede le impostazioni di MAX_FILE_SIZE specificate nel modulo html.");
// define("FMLAN_6", "File caricato parzialmente.");
// define("FMLAN_7", "Nessun file caricato.");
// define("FMLAN_8", "Dimensioni File caricato 0 bytes");
// define("FMLAN_9", "File non caricato. Nome File");
// define("FMLAN_10", "Errore");
// define("FMLAN_11", "Probabilmente permessi non corretti della cartella di upload.");
define("FMLAN_12", "File");
define("FMLAN_13", "Files");
define("FMLAN_14", "Cartella");
define("FMLAN_15", "Cartelle");
define("FMLAN_16", "Root");
define("FMLAN_17", "Nome");
define("FMLAN_18", "Dimensione");
define("FMLAN_19", "Ultima modifica");

define("FMLAN_21", "Carica il file in questa cartella");
define("FMLAN_22", "Carica");

define("FMLAN_26", "Elimina");
define("FMLAN_27", "con successo");
define("FMLAN_28", "Impossibile eliminare");
define("FMLAN_29", "Path");
define("FMLAN_30", "Livello superiore");
define("FMLAN_31", "cartella");

define("FMLAN_32", "Cartella selezionata");
define("FMLAN_33", "Seleziona");
define("FMLAN_34", "Scelta Cartella");
define("FMLAN_35", "Cartella Files");

define("FMLAN_36", "Cartella Menù Personalizzati");
define("FMLAN_37", "Cartella Pagine Personalizzate");

define("FMLAN_38", "File mosso con successo in");
define("FMLAN_39", "Impossibile muovere il file in");
define("FMLAN_40", "Cartella Newspost-Images");


define("FMLAN_43", "Elimina i file selezionati");


define("FMLAN_46", "Conferma che vuoi ELIMINARE i File selezionati.");
define("FMLAN_47", "Allegati Utenti");

define("FMLAN_48", "Muovi selezionati in");
define("FMLAN_49", "Conferma che vuoi muovere i file selezionati.");
define("FMLAN_50", "Muovi");


?>
