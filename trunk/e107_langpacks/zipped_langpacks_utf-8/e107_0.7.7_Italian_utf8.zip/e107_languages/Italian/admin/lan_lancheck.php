<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_lancheck.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/11/05 03:50:19 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Seleziona Lingua da verificare");
define("LAN_CHECK_2", "Inizia verifica");
define("LAN_CHECK_3", "Verifica di");
define("LAN_CHECK_4", "File mancanti!");
define("LAN_CHECK_5", "Frase mancante!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "Frase");
define("LAN_CHECK_8", "Un file è mancante...");
define("LAN_CHECK_9", " files mancano...");
define("LAN_CHECK_10", "Errore Critico: ");
define("LAN_CHECK_11", "Nessun file mancante !");
define("LAN_CHECK_12", "Un file non è valido...");
define("LAN_CHECK_13", " files sono invalidi...");
define("LAN_CHECK_14", "Tutti i files sono validi !");

define("LAN_CHECK_15", "Caratteri non validi trovati prima '&lt;?php'");
define("LAN_CHECK_16", "File Originale ");
define("LAN_CHECK_17", "Problema di scrittura tentando di salvare il file.");
define("LAN_CHECK_18", "I file di linguaggio nel formato standard NON sono disponibili per questo plugin/tema.");
define("LAN_CHECK_19", "Trovati caratteri Non-UTF-8 !");

?>