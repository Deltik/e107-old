<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Cancellati tutti gli Utenti dal Gruppo.");
define("UCSLAN_2", "Gruppo Utenti aggiornato.");
define("UCSLAN_3", "Gruppo Utenti cancellato.");
define("UCSLAN_4", "Spunta per cancellare questo Gruppo Utenti");
define("UCSLAN_5", "Gruppo Utenti aggiornato.");
define("UCSLAN_6", "Gruppo Utenti salvato nel database.");
define("UCSLAN_7", "Nessun Gruppo Utenti esistente.");
define("UCSLAN_8", "Gruppi Utenti esistenti");
//define("UCSLAN_9", "Edit");
//define("UCSLAN_10", "Cancella");
define("UCSLAN_11", "seleziona per confermare");
define("UCSLAN_12", "Nome Gruppo");
define("UCSLAN_13", "Descrizione Gruppo");
define("UCSLAN_14", "Aggiorna Gruppo Utenti");
define("UCSLAN_15", "Crea nuovo Gruppo Utenti");
define("UCSLAN_16", "Assegna utenti al Gruppo");
define("UCSLAN_17", "Rimuovi");
define("UCSLAN_18", "Pulisci");
define("UCSLAN_19", "Assegna utenti a");
define("UCSLAN_20", "Gruppo");
define("UCSLAN_21", "Impostazioni Gruppo Utenti");
define("UCSLAN_22", "Utenti - clicca per spostare ...");
define("UCSLAN_23", "Utenti in questo Gruppo ...");
define("UCSLAN_24", "Chi può gestire Gruppo");
?>