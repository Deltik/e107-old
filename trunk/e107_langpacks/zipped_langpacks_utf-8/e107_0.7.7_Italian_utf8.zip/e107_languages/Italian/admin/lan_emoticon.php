<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_emoticon.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/06/13 16:16:13 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("EMOLAN_1", "Attivazione Faccine.");
define("EMOLAN_2", "Nome.");
define("EMOLAN_3", "Faccine.");
define("EMOLAN_4", "Attivare le Faccine?");
define("EMOLAN_5", "Immagine");
define("EMOLAN_6", "Codice Faccina");
define("EMOLAN_7", "Separa inserimenti multipli con spazi");
define("EMOLAN_8", "Status");
define("EMOLAN_9", "Opzioni");
define("EMOLAN_10", "Attiva");
define("EMOLAN_11", "Set Attivo");

define("EMOLAN_12", "Modifica / configura questo set");
define("EMOLAN_13", "Set Installato");

define("EMOLAN_14", "Salva configurazione");
define("EMOLAN_15", "Edita / configura faccine");
define("EMOLAN_16", "Configurazione faccine salvate");
define("EMOLAN_17", "Hai  un set di faccine che contiene spazi non permessi!");
define("EMOLAN_18", "per fvore rinomina le istanze elencate così che non contengano spazi:");
define("EMOLAN_19", "Nome");
define("EMOLAN_20", "Locazione");
define("EMOLAN_21", "Errore");



?>
