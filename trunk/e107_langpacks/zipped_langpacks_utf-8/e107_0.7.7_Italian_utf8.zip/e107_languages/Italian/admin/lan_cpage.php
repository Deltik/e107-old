<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/22 17:08:01 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg
+----------------------------------------------------------------------------+
*/

define("CUSLAN_1", "Titolo");
define("CUSLAN_2", "Tipo");
define("CUSLAN_3", "Opzioni");
define("CUSLAN_4", "Vuoi cancellare questa pagina ?");
define("CUSLAN_5", "Pagine esistenti");
define("CUSLAN_7", "Nome Menù");
define("CUSLAN_8", "Titolo / Didascalia");
define("CUSLAN_9", "Testo");
define("CUSLAN_10", "Consenti che la pagina sia votata");
define("CUSLAN_11", "Pagina principale");
define("CUSLAN_12", "Crea pagina");
define("CUSLAN_13", "Consenti invio commenti ?");
define("CUSLAN_14", "Password protezione pagina");
define("CUSLAN_15", "Inserisci password per proteggere pagina");
define("CUSLAN_16", "Crea link nel menù principale");
define("CUSLAN_17", "inserisci il nome del link da creare");
define("CUSLAN_18", "Pagina / link visibile a");
define("CUSLAN_19", "Aggiorna Pagina");
define("CUSLAN_20", "Crea Pagina");
define("CUSLAN_21", "Aggiorna Menù");
define("CUSLAN_22", "Crea Menù");
define("CUSLAN_23", "Edita pagina");
define("CUSLAN_24", "Crea una nuova pagina");
define("CUSLAN_25", "Edita menù");
define("CUSLAN_26", "Crea un nuovo menù");
define("CUSLAN_27", "Pagina salvata nel database.");
define("CUSLAN_28", "Pagina cancellata");
define("CUSLAN_29", "Lista delle pagine se non è selezionata alcuna pagina");
define("CUSLAN_30", "Tempo scadenza cookie (in secondi)");
define("CUSLAN_31", "Crea menù");
define("CUSLAN_32", "Converti pagine/menù vecchi");
define("CUSLAN_33", "Opzioni Pagina");
define("CUSLAN_34", "Inizio conversione");
define("CUSLAN_35", "Terminato aggiornamento pagine personalizzate");
define("CUSLAN_36", "Per impostare le tue preferenze per ciascuna pagina, ritorna alla Pagina Principale e modifica le pagine.");
define("CUSLAN_37", "Aggiorna Pagine Personalizzate");
define("CUSLAN_38", "Si");
define("CUSLAN_39", "No");
define("CUSLAN_40", "Salva le Opzioni");

define("CUSLAN_41", "Mostra informazioni Autore e Data");
define("CUSLAN_42", "Nessuna pagina ancora impostata");

?>
