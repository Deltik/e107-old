﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "год");
define("LANDT_02", "месяц");
define("LANDT_03", "неделя");
define("LANDT_04", "день");
define("LANDT_05", "час");
define("LANDT_06", "минута");
define("LANDT_07", "секунда");
define("LANDT_01s", "лет");
define("LANDT_02s", "месяцев");
define("LANDT_03s", "недель");
define("LANDT_04s", "дней");
define("LANDT_05s", "часов");
define("LANDT_06s", "минут");
define("LANDT_07s", "секунд");

define("LANDT_08", "мин");
define("LANDT_08s", "мин");
define("LANDT_09", "сек");
define("LANDT_09s", "сек");
define("LANDT_AGO", "назад");


?>