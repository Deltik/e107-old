﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Сайт");
define("FOOTLAN_2", "Главный Админ");
define("FOOTLAN_3", "Версия");
define("FOOTLAN_4", "сборка");
define("FOOTLAN_5", "Тема");
define("FOOTLAN_6", "автор:");
define("FOOTLAN_7", "Информация");
define("FOOTLAN_8", "Дата установки");
define("FOOTLAN_9", "Сервер");
define("FOOTLAN_10", "хост");
define("FOOTLAN_11", "Версия PHP");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Информация о сайте");
define("FOOTLAN_14", "Показать документацию");
define("FOOTLAN_15", "Документация");
define("FOOTLAN_16", "База данных");
define("FOOTLAN_17", "Кодировка");
define("FOOTLAN_18", "Локализация:");
?>