﻿<?php
## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "При помощи этой фичи можно добавлять на сайт обычные странички. Ссылка на новую страничку появится в 'навигации'.";
$ns -> tablerender("Справка", $text);
?>