﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Выбрать язык для проверки");
define("LAN_CHECK_2", "Начать проверку");
define("LAN_CHECK_3", "Проверка ");
define("LAN_CHECK_4", "Файл утерян!");
define("LAN_CHECK_5", "Фраза утеряна!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "фраза");

define("LAN_CHECK_8", "Файл утерян...");
define("LAN_CHECK_9", " файлов утеряно...");
define("LAN_CHECK_10", "Критическая ошибка: ");
define("LAN_CHECK_11", "Нет потерянных файлов !");
define("LAN_CHECK_12", "Файл ошибочный...");
define("LAN_CHECK_13", " ошибочных файлов...");
define("LAN_CHECK_14", "Все существующие файлы правильны !");

?>
