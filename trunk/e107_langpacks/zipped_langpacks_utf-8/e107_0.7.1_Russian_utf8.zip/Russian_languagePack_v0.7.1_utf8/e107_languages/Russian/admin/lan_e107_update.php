﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_1", "Обновить");
define("LAN_UPDATE_2", "Действие");
define("LAN_UPDATE_3", "Не нужно");
define("LAN_UPDATE_4", "Обновить");
define("LAN_UPDATE_5", "Обновление доступно");
define("LAN_UPDATE_6", "Обновить всё");
define("LAN_UPDATE_7", "Выполнено");
define("LAN_UPDATE_8", "Обновить с ");
define("LAN_UPDATE_9", "на");
define("LAN_UPDATE_10", "Возможные обновления");

?>