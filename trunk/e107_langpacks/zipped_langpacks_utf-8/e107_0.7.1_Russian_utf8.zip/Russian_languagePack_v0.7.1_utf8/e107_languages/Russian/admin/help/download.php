﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Заливай свои файлы в ".e_FILE.",</br> картинки в ".e_FILE."downloadimages и эскизы в ".e_FILE."downloadthumbs.</br></br>Чтобы создать Загрузку, нужно сперва создать Родительскую категорию в Главном каталоге, затем в этой категории надо создать раздел, а уже в нем создавать файл. Тогда он станет доступным для загрузки.";
$ns -> tablerender("Справка", $text);
?>