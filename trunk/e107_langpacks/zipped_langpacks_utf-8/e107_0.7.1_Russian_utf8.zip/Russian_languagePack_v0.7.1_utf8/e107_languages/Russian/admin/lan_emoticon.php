﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Активировать смайлики");
define("EMOLAN_2", "Имя ");
define("EMOLAN_3", "Эмоции");
define("EMOLAN_4", "Активировать смайлики?");

define("EMOLAN_5", "Рисунок");
define("EMOLAN_6", "Код эмоции");
define("EMOLAN_7", "разделить пробелами");

define("EMOLAN_8", "Статус");
define("EMOLAN_9", "Опции");
define("EMOLAN_10", "Активно");
define("EMOLAN_11", "Активировать набор");

define("EMOLAN_12", "Редактировать/настроить набор");
define("EMOLAN_13", "Установленные наборы");

define("EMOLAN_14", "Сохранить настройки");
define("EMOLAN_15", "Редактировать/настроить смайлики");
define("EMOLAN_16", "Настройки смайликов сохранены");
define("EMOLAN_2", "Имя");
define("EMOLAN_2", "Имя");
define("EMOLAN_2", "Имя");
define("EMOLAN_2", "Имя");
define("EMOLAN_2", "Имя");
define("EMOLAN_2", "Имя");

?>