﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Ты можешь разделить новости по категориям и позволить посетителям смотреть новости только выбранных категорий. <br /><br />Иконки для новостей можно загружить как в</br>".e_THEME."-yourtheme-/images/ </br>так и в </br>themes/shared/newsicons/.";
$ns -> tablerender("Справка", $text);
?>