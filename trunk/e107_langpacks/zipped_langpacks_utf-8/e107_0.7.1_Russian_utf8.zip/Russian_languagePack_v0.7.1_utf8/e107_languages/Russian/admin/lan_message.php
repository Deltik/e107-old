﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Принятые сообщения");
define("MESSLAN_2", "Удалить сообщение");
define("MESSLAN_3", "Сообщение удалено.");
define("MESSLAN_4", "Удалить все сообщения");
define("MESSLAN_5", "Подтвердите");
define("MESSLAN_6", "Все сообщения удалены.");
define("MESSLAN_7", "Нет сообщений.");
define("MESSLAN_8", "Тип сообщений");
define("MESSLAN_9", "Сообщено");

define("MESSLAN_10", "Сообщил ");
define("MESSLAN_11", "открыть в новом окне");
define("MESSLAN_12", "Сообщение");
define("MESSLAN_13", "Ссылка");


?>