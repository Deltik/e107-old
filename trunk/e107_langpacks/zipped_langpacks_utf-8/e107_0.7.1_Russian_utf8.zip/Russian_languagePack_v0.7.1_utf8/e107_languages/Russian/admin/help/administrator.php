﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$caption = "Справка";
$text = "Страница для удаления/создания админиов сайта. Админ можеть пользовать только те фичи, которые отмечены галочкой.";
$ns -> tablerender($caption, $text);
?>