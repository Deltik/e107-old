﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Здесь вы можете установить и настроить различные дополнительные модули е107. Кроме того, здесь же можно загрузить архивы с плагинами.";
$ns -> tablerender("Плагины", $text);
unset($text);
?>