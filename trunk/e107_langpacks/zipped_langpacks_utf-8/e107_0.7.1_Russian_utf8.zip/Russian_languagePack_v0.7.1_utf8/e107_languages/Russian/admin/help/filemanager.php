﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Эта страница предназначена для управления файлами в каталоге /e107_files. Если появлется сообщение об ошибке при загрузке фалов установи CHMOD 777 на каталог, в который происходит загрузка.";
$ns -> tablerender("Справка", $text);
?>