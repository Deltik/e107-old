﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$caption = "Справка";
$text = "Здесь ты выбираешь, что будет отображаться на главной странице сайта (по умолчанию - новости).";
$ns -> tablerender($caption, $text);
?>