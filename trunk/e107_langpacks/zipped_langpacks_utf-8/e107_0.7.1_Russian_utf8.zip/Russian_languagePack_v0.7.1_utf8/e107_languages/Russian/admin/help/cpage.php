﻿<?php
$text = "На этой странице вы можете создать собственные меню и выборочные страницы со своим собственным содержанием.<br /><br />
Для подробностей смотрите <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a>.";

$ns -> tablerender('Свои меню и страницы', $text);
?>