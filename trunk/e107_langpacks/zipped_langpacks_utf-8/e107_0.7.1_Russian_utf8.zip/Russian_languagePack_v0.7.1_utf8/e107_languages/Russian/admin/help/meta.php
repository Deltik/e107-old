﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Любые введенные метатеги будут расположенны там, где надо.";

$ns -> tablerender("Справка", $text);
?>