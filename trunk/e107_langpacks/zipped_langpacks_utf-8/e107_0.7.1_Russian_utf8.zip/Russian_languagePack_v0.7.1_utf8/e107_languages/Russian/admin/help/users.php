﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Эта страница модерирования участников. Здесь ты можешь изменить их настройки, дать права администратора, изменить их класс и тд.";
$ns -> tablerender("Справка", $text);
unset($text);
?>