﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("ADLAN_0", "Новости");
define("ADLAN_1", "Доб/ред/удал тем новостей");
define("ADLAN_2", "Категории новостей");
define("ADLAN_3", "Доб/ред/удал категорий новостей");
define("ADLAN_4", "Настройки сайта");
define("ADLAN_5", "Ред. свойств сайта");
define("ADLAN_6", "Меню"); 
define("ADLAN_7", "Порядок расположения Ваших меню");
define("ADLAN_8", "Администраторы");
define("ADLAN_9", "Доб/удаление администраторов сайта");
define("ADLAN_10", "Пароль админа");
define("ADLAN_11", "Смена Вашего пароля");
define("ADLAN_12", "Форумы");
define("ADLAN_13", "Доб/ред Форумов");
define("ADLAN_14", "Статьи");
define("ADLAN_15", "Доб нов/ред/удаление статей");
define("ADLAN_16", "Содержимое");
define("ADLAN_17", "Доб нов/ред/удаление содержимого страниц");
define("ADLAN_18", "Обзоры");
define("ADLAN_19", "Доб нов/ред/удаление обзоров"); 
define("ADLAN_20", "Ссылки");
define("ADLAN_21", "Доб нов/ред/удаление ссылок");
define("ADLAN_22", "Категории ссылок");
define("ADLAN_23", "Доб нов/ред/удаление категорий ссылок");
define("ADLAN_24", "Закачки");
define("ADLAN_25", "Менеджер закачек");
define("ADLAN_26", "Категории закачек");
define("ADLAN_27", "Доб нов/ред/удаление категорий закачек");
define("ADLAN_28", "Приветствие");
define("ADLAN_29", "Установить постоянное приветствие");
define("ADLAN_30", "Файловый менеджер");
define("ADLAN_31", "Изменение/загрузка файлов");
define("ADLAN_32", "Размещение новостей");
define("ADLAN_33", "Просмотр размещённых пользователями новостей");
define("ADLAN_34", "Банлист");
define("ADLAN_35", "Бан визитёров");
define("ADLAN_36", "Пользователи");
define("ADLAN_37", "Модерация пользователей сайта");
define("ADLAN_38", "Классы пользователей");
define("ADLAN_39", "Открытие/ред классов юзеров");
define("ADLAN_40", "Закрытие");
define("ADLAN_41", "Страница закрытия сайта");
define("ADLAN_42", "Свои меню/страницы");
define("ADLAN_43", "Открытие тем выборочных меню");
define("ADLAN_44", "База данных");
define("ADLAN_45", "Утилиты базы");
define("ADLAN_46", "Выход");
define("ADLAN_47", "Привет");
define("ADLAN_48", "Вход");
define("ADLAN_49", "администраторы сайта");
define("ADLAN_50", "возможности");
define("ADLAN_51", "Пожалуйста, войдите под своим ником, чтобы получить доступ к Админцентру");
define("ADLAN_52", "Админцентр");
define("ADLAN_53", "На сайт");
define("ADLAN_54", "Баннеры");
define("ADLAN_55", "Настройка баннеров");
define("ADLAN_56", "Чатбокс");
define("ADLAN_57", "Настойка чатбокса");
define("ADLAN_58", "Смайлики");
define("ADLAN_59", "Настройка смайликов");
define("ADLAN_60", "Главная страница");
define("ADLAN_61", "Настройка содержимого главной страницы");
define("ADLAN_62", "Источник Новостей");
define("ADLAN_63", "Настроить источник новостей");
define("ADLAN_64", "Статистика логов");
define("ADLAN_65", "Логи стат/страны и т.п.");
define("ADLAN_66", "Метатэги");
define("ADLAN_67", "Доб/ред метатэги сайта");
define("ADLAN_68", "Версия PHP");
define("ADLAN_69", "Страница версии PHP");
define("ADLAN_70", "Опрос");
define("ADLAN_71", "Доб/ред опросов");
define("ADLAN_72", "Общие загрузки");
define("ADLAN_73", "Настройка общих загрузок файлов");
define("ADLAN_74", "Кэш");
define("ADLAN_75", "Установка статуса кэширования");
define("ADLAN_77", "Пользователь добавил статью - пожалуйста, нажмите здесь, чтобы ее проверить.");
define("ADLAN_78", "Поля пользователей");
define("ADLAN_79", "Удаление");
define("ADLAN_80", "Кликнуть для подтверждения");
define("ADLAN_81", "Обновление ");
define("ADLAN_82", "Открыть ");
define("ADLAN_83", "Существующие ");
define("ADLAN_84", "Открыть HTML Редактор ");
define("ADLAN_85", "Подтвердить ");
define("ADLAN_86", "Неверный пароль ");
define("ADLAN_87", "Имя администратора не найдено в базе данных ");
define("ADLAN_88", "Неверный логин ");
define("ADLAN_89", "Имя админа ");
define("ADLAN_90", "Пароль админа ");
define("ADLAN_91", "Вход");
define("ADLAN_92", "Пожалуйста, войдите под своим ником, чтобы перейти к Админцентру ...");
define("ADLAN_93", "Показать функции админа");
define("ADLAN_94", "Показать установленные плагины");
define("ADLAN_95", "Управление плагинами");
define("ADLAN_96", "Нет");
define("ADLAN_97", "Кликните тут для перехода в FAQ");
define("ADLAN_98", "Управление плагинами");
define("ADLAN_99", "Установка/обновление и т.п. плагинов");
define("ADLAN_100", "Выбор темы");
define("ADLAN_101", "Дизайнер шаблонов");
define("ADLAN_102", "Вы меняли свой пароль более 30 дней назад, это небезопасно! ");
define("ADLAN_103", "Нажмите здесь, чтобы сменить его сейчас");
define("ADLAN_104", "Безопасность");

define("ADLAN_105", "Изображения");
define("ADLAN_106", "Настройки изображений");

define("ADLAN_107", "Непроверенных сообщенных новостей");
define("ADLAN_108", "Непроверенных добавленных файлов");
define("ADLAN_109", "Информация");
define("ADLAN_110", "Зарегистрированых пользователей");
define("ADLAN_111", "Неактивированых пользователей");
define("ADLAN_112", "Забаненых");
define("ADLAN_113", "Сообщений в форуме");
define("ADLAN_114", "Комментариев");
define("ADLAN_115", "Сообщений в чат-боксе");
define("ADLAN_116", "Админ логи ... ");
define("ADLAN_117", "Показать все цепочки");
define("ADLAN_118", "Очистить логи");

define("ADLAN_119", "Непроверенных сообщенных ссылок");

define("ADLAN_120", "Возможен апгрейд базы данных, нажмите на кнопку ...");
define("ADLAN_121", "Установить");
define("ADLAN_122", "Обновить");

define("ADLAN_123", "Непроверенных новостей");
define("ADLAN_124", "Непроверенных обзоров");
define("ADLAN_125", "Непроверенных сообщений в форуме");

define("ADLAN_126", "Основные настройки");
define("ADLAN_127", "Пользователи");
define("ADLAN_128", "Содержание");
define("ADLAN_129", "Связь");
define("ADLAN_130", "Управление файлами");
define("ADLAN_131", "Другие инструменты");

define("ADLAN_132", "Язык");
define("ADLAN_133", "по умолчанию");

define("ADLAN_134", "Статус");
define("ADLAN_135", "Логи Админа");

define("ADLAN_136", "Почта");
define("ADLAN_137", "Настройки и отправка Email");

define("ADLAN_138", "Ссылки сайта");
define("ADLAN_139", "Доб нов/ред/удаление ссылок");

define("ADLAN_140", "Менеджер Тем");
define("ADLAN_141", "Установка / выбор тем и т.д.");

define("ADLAN_142", "Поиск");
define("ADLAN_143", "Настройки поиска");
define("ADLAN_144", "Вы находитесь в режиме простого вида, чтобы переключиться в расширенный вид");
define("ADLAN_145", "нажмите сюда");

define("ADLAN_146", "Неудавшиеся попытки логина");
define("ADLAN_147", "Файлы системы");
define("ADLAN_148", "Сканировать файлы сайта");

define("ADLAN_149", "Уведомления");
define("ADLAN_150", "Уведомления для админа по Email");

define("ADLAN_151", "Главная");

define('ADLAN_CL_1', 'Настройки');
define('ADLAN_CL_2', 'Пользователи');
define('ADLAN_CL_3', 'Содержание');
define('ADLAN_CL_4', 'Coms');
define('ADLAN_CL_5', 'Файлы');
define('ADLAN_CL_6', 'Инструменты');
define('ADLAN_CL_7', 'Плагины');
define('ADLAN_CL_8', 'ЧаВо (FAQ)');

define("ADLAN_LAT_1", "Новое на сайте");

define("ADLAN_LAT_2", "Сообщено новостей");
define("ADLAN_LAT_3", "Прислано статей");
define("ADLAN_LAT_4", "Прислано обзоров");
define("ADLAN_LAT_5", "Сообщено ссылок");
define("ADLAN_LAT_6", "Новых сообщений форума");
define("ADLAN_LAT_7", "Добавлено файлов");
define("ADLAN_LAT_8", "Непроверенных сообщений");

// Common Terms
define("LAN_EDIT","Редактировать");
define("LAN_DELETE","Удалить");
define("LAN_CREATE","Создать");
define("LAN_UPDATE","Обновить");
define("LAN_SAVE","Сохранить");
define("LAN_SAVED","Сохранено");
define("LAN_SETSAVED","Ваши настройки были сохранены");
define("LAN_ERROR","Ошибка");
define("LAN_CONFIRMDEL","Подтвердите желание удалить");
define("LAN_OPTIONS","Опции");
define("LAN_PREFS","Настройки");
define("LAN_DELETED","Успешно удалено");
define("LAN_UPDATED","Успешно обновлено");
define("LAN_CREATED","Успешно создано");
define("LAN_CREATED_FAILED","Создать не удалось");
define("LAN_DELETED_FAILED","Удалить не удалось");
define("LAN_UPDATED_FAILED","Обновить не удалось");
define("LAN_NO_CHANGE","Обновление не удалось, так как никакие изменения не были внесены.");
define("LAN_TRY_AGAIN","Попробуйте снова.");

define("LAN_RESET","Сброс");
define("LAN_CLEAR","Очистить");
define("LAN_OK","OK");

define("LAN_PRESET","Предустановки");
define("LAN_PRESET_SAVED","Предустановки успешно сохранены");
define("LAN_PRESET_DELETED","Предустановки успешно удалены");
define("LAN_PRESET_CONFIRMDEL","Уверены, что хотите удалить эти предустановки?");
define("LAN_NOTWRITABLE"," не записываема, нужно поставить на папку CHMOD 777.");
define("LAN_DATE","Дата");
define("LAN_TIME","Время");
define("LAN_YES","Да");
define("LAN_NO","Нет");
define("LAN_EMPTY","В БД еще нет записей");
define("LAN_EXISTING","Существующие записи");

define("LAN_CANCEL","Отмена");
define("LAN_CONFDELETE","Подтвердить удаление");
define("LAN_PLUGIN","Плагин");
define("LAN_ORDER","Порядок");

define("LAN_SELECT","Выбрать ...");
define("LAN_ADMIN","Админ");
define("LAN_DISPLAYOPT", "Редактировать вид");
define("LAN_GOPAGE", "Перейти на страницу:");
define("LAN_DATESTAMP","Установка даты");
define("LAN_OPTIONAL", "необязательно");
define("LAN_INACTIVE","Неактивен");


?>