﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("BNRLAN_1", "Баннер удалён.");
define("BNRLAN_2", "Пожалуйста, подтвердите удаление этого баннера");
define("BNRLAN_3", "Отмена");
define("BNRLAN_4", "Подтвердить удаление");
define("BNRLAN_5", "Подтверждение удаления баннера");
define("BNRLAN_6", "Удаление отменено."); 
define("BNRLAN_7", "Существующие баннеры");
define("BNRLAN_8", "ID баннера");
define("BNRLAN_9", "Клиент");

define("BNRLAN_10", "Кликов");
define("BNRLAN_11", "Кликов в %");
define("BNRLAN_12", "Показов");
define("BNRLAN_13", "Осталось");
define("BNRLAN_14", "Опции");
define("BNRLAN_15", "Нет баннеров.");
define("BNRLAN_16", "Неограниченно");
define("BNRLAN_17", "Нет");
define("BNRLAN_18", "Удалить");
define("BNRLAN_19", "Да");
define("BNRLAN_20", "Нет");
define("BNRLAN_21", "Конец");
define("BNRLAN_22", "Обновить баннер");
define("BNRLAN_23", "Добавить новый баннер");
define("BNRLAN_24", "Кампания");

define("BNRLAN_25", "Сменить настоящую кампанию");
define("BNRLAN_26", "Ввести новую кампанию");
define("BNRLAN_27", "Клиент");
define("BNRLAN_28", "Сменить настоящего клиента");
define("BNRLAN_29", "Ввести нового клиента");
define("BNRLAN_30", "Логин клиента");
define("BNRLAN_31", "Пароль клиента");
define("BNRLAN_32", "Изображение баннера");
define("BNRLAN_33", "Переход на URL");
define("BNRLAN_34", "Куплено показов");
define("BNRLAN_35", "Неограниченно");
define("BNRLAN_36", "Начальная дата");

define("BNRLAN_37", "Конечная дата");
define("BNRLAN_38", "Чистое = без лимита");
define("BNRLAN_39", "Активен");
define("BNRLAN_40", "Обновить баннер");
define("BNRLAN_41", "Открыть новый баннер");
define("BNRLAN_42", "Обмен баннерами");

define("BNRLAN_43", "Выберите изображение баннера.");
define("BNRLAN_44", "Редактировать");
define("BNRLAN_45", "Старт");
define("BNRLAN_46", "Код");
define("BNRLAN_58", "Главная страница Баннеров");
define("BNRLAN_59", "Создать новый Баннер");
define("BNRLAN_60", "Кампания");
define("BNRLAN_61", "Меню баннеров");
define("BNRLAN_62", "Опции баннеров");
define("BNRLAN_63", "Баннер создан");
define("BNRLAN_64", "Баннер обновлен");

define("BANNER_MENU_L1", "Реклама");
define("BANNER_MENU_L2", "Настройки меню баннеров сохранены");

//v.617
define("BANNER_MENU_L3", "Заголовок");
define("BANNER_MENU_L5", "Конфигурация баннера"); 
define("BANNER_MENU_L6", "выберите кампании для показа в меню");
define("BANNER_MENU_L7", "доступные кампании");
define("BANNER_MENU_L8", "отобранные кампании");
define("BANNER_MENU_L9", "удалить выбранные");
define("BANNER_MENU_L10", "Укажите тип");
define("BANNER_MENU_L12", "простой");
define("BANNER_MENU_L13", "в озаглавленном блоке");
define("BANNER_MENU_L18", "Обновить настройки меню");

?>