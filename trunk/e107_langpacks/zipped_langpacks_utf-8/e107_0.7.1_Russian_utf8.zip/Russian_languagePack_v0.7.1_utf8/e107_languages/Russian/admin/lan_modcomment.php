﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Отмодерировано.");
define("MDCLAN_2", "Здесь нет комментариев");
define("MDCLAN_3", "Пользователь");
define("MDCLAN_4", "Гость");
define("MDCLAN_5", "разблокировать");
define("MDCLAN_6", "заблокировать");

define("MDCLAN_8", "Модерировать комментарии");
define("MDCLAN_9", "Внимание! Удаление родительских комментариев удалит все ответы!");

define("MDCLAN_10", "опции");
define("MDCLAN_11", "комментарий");
define("MDCLAN_12", "комментарии");
define("MDCLAN_13", "заблокировано");
define("MDCLAN_14", "блокировать комментарии");
define("MDCLAN_15", "открыть");
define("MDCLAN_16", "заблокировано");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>