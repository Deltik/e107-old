﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "На этой странице включается система ведения статистики посещения сайта. </br></br>  Если места на вашем сервере не так уж много  - можно включить опцию 'только домены', соответственно в лог будет писаться только домен, а не полный url, т.e. 'jalist.com' вместо 'http://jalist.com/links.php' ";
$ns -> tablerender("Справка", $text);
?>