﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Message for Guests");
// define("WMGLAN_2", "Message for Members");
// define("WMGLAN_3", "Message for Administrators");
// define("WMGLAN_4", "Submit");
// define("WMGLAN_5", "Set Welcome Message");
// define("WMGLAN_6", "Activate?");
// define("WMGLAN_7", "Welcome message settings updated.");

define("WMLAN_00","Приветственное сообщение");
define("WMLAN_01","Создать новое сообщение");
define("WMLAN_02","Сообщение");
define("WMLAN_03","Видимость");
define("WMLAN_04","Текст сообщения");

define("WMLAN_05","Включите");
define("WMLAN_06","Если отмечено, сообщение появится внутри блока");
define("WMLAN_07","Отменить стандартную систему для использования {WMESSAGE} кода:");
// define("WMLAN_08","Preferences");

define("WMLAN_09","Еще нет приветственных сообщений");

?>