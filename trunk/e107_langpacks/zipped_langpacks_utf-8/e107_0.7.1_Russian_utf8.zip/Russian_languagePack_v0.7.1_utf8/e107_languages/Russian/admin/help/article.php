﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Здесь ты можешь добавлять одно- и многостраничные статьи.<br />
 Для разделения многостраничных статей используй тег [newpage], т.e. <br /><code>Teст1 [newline] Teст2</code><br /> создаст статью с текстом 'Teст1' на первой странице и с текстом 'Teст2' на второй.
<br /><br />
Если в статье есть HTML теги, то их можно сохранить при помощи тега [preserve] [/preserve]. например, если ты введешь текст '&lt;table>&lt;tr>&lt;td>Привет &lt;/td>&lt;/tr>&lt;/table>' в статье, то получится таблица со словом привет. Если же написать '[preserve]&lt;table>&lt;tr>&lt;td>Hello &lt;/td>&lt;/tr>&lt;/table>[/preserve]' то теги обрабатываться не будут и отобразятся в статье.";
$ns -> tablerender("Справка", $text);
?>