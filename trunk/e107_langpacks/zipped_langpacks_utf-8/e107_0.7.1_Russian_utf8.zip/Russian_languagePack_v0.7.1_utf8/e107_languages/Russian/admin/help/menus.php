﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

if(IsSet($_POST['reset'])){
	for($mc=1;$mc<=5;$mc++){
		$sql -> db_Select("menus","*", "menu_location='$mc' ORDER BY menu_order");
		$count = 1;
		$sql2 = new db;
		while(list($menu_id, $menu_name, $menu_location, $menu_order) = $sql-> db_Fetch()){
			$sql2 -> db_Update("menus", "menu_order='$count' WHERE menu_id='$menu_id' ");
			$count++;
		}
		$text = "<b>Menus reset in database</b><br /><br />";
	}
}else{
	unset($text);
}



$text .= "Здесь ты можешь настроить расположение пунктов меню. Стрелками можно перемещать пункты меню вверх и вниз.<br />Для просмотра изменений нажми на кнопку 'обновить'.

<br />
<form method=\"post\" action=\"".$_SERVER['PHP_SELF']."\">
<input class=\"button\" type=\"submit\" name=\"reset\" value=\"Обновить\" />
</form>";

$ns -> tablerender("Справка", $text);
?>