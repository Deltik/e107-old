﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Если ты апгрейдишь ПО или если тебе просто надо что бы сайт был в оффлайне - установи флаг ремонта и все посетители будут направляться на страницу sitedown.php. Пока сайт в оффлайне - используй ссылку .../e107_admin/admin.php для входа на сайт.";

$ns -> tablerender("Ремонт", $text);
?>