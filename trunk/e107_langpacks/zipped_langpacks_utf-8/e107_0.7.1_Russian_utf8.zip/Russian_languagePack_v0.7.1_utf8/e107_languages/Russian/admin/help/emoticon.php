﻿<?php

## Russian Language Pack for e107 Version 0.617
##      Copyright © 2004 - Russian e107
##	     	  http://e107.org.ru

$text = "Эта фича предназначена для замены текстовых смалйликов на графические.<br /><br />
Внизу есть форма для добавления своих смайликов.";

$ns -> tablerender("Справка", $text);
?>