﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Текстовое поле");
define("UE_LAN_2", "Радио-кнопка");
define("UE_LAN_3", "Выпадающее меню");
define("UE_LAN_4", "Поле таблицы в БД");
define("UE_LAN_5", "Область текста");
define("UE_LAN_6", "Целое число");
define("UE_LAN_7", "Дата");
define("UE_LAN_8", "Язык");

define("UE_LAN_9", "Имя");
define("UE_LAN_10", "Тип");
define("UE_LAN_11", "Использовать");

define("UE_LAN_HIDE", "Скрыть от пользователей");

define("UE_LAN_LOCATION", "Расположение");
define("UE_LAN_LOCATION_DESC", "Место жительства");
define("UE_LAN_AIM", "AIM");
define("UE_LAN_AIM_DESC", "AIM");
define("UE_LAN_ICQ", "ICQ");
define("UE_LAN_ICQ_DESC", "ICQ");
define("UE_LAN_YAHOO", "Yahoo!");
define("UE_LAN_YAHOO_DESC", "Yahoo!");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN");
define("UE_LAN_HOMEPAGE", "Домашняя страница");
define("UE_LAN_HOMEPAGE_DESC", "url сайта пользователя");
define("UE_LAN_BIRTHDAY", "День рождения");
define("UE_LAN_BIRTHDAY_DESC", "День рождения");

?>