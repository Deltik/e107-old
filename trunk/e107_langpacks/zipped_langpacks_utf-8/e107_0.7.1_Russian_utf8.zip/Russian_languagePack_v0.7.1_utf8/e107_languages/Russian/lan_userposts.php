﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Сообщения пользователей");

define("UP_LAN_0", "Все сообщения ");
define("UP_LAN_1", "Все комментарии ");
define("UP_LAN_2", "Тема");
define("UP_LAN_3", "Просмотр");
define("UP_LAN_4", "Ответы");
define("UP_LAN_5", "Последнее сообщение");
define("UP_LAN_6", "Темы");
define("UP_LAN_7", "Нет комментариев");
define("UP_LAN_8", "нет сообщений");
define("UP_LAN_9", " на ");
define("UP_LAN_10", "Ответ на:");
define("UP_LAN_11", "Сообщено: ");
define("UP_LAN_12", "Поиск");
define("UP_LAN_13", "Комментарии");
define("UP_LAN_14", "Сообщения форума");
define("UP_LAN_15", "Ответ на:");
define("UP_LAN_16", "IP адрес");
?>