﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------  ------+
*/

define("CHATBOX_L1", "Невозможно принять сообщение, так как это имя занято другим пользователем. Если это ваше имя, войдите в систему под ним");
define("CHATBOX_L2", "Мини-чат");
define("CHATBOX_L3", "Вы должны быть зарегистрированы, чтобы оставлять сообщения. Нажмите <a href='".e_BASE."signup.php'>здесь</a> для регистрации");
define("CHATBOX_L4", "Отправить");
define("CHATBOX_L5", "Сброс");
define("CHATBOX_L6", "[заблокировано Админом]");
define("CHATBOX_L7", "Разблокировать");
define("CHATBOX_L8", "Информация");
define("CHATBOX_L9", "Блокировать");
define("CHATBOX_L10", "Удалить");
define("CHATBOX_L11", "Сообщений нет.");
define("CHATBOX_L12", "Смотреть все сообщения");
define("CHATBOX_L13", "Модерировать");
define("CHATBOX_L14", "Смайлики");
define("CHATBOX_L15", "Сообщение слишком длинное, или пустое");
define("CHATBOX_L16", "Аноним");
define("CHATBOX_L17", "Двойное сообщение");
define("CHATBOX_L18", "Сообщения чатбокса отмодерированы");
define("CHATBOX_L19", "Вы можете размещать одно сообщение каждые ".FLOODTIMEOUT." секунд(ы)");

define("LAN_11", "Мини-чат (все сообщения)");
define("LAN_12", "Сообщения чата");
define("LAN_13", "вкл");
define("LAN_14", "Ошибка!");
define("LAN_15", "Вы не имеете разрешений просматривать эту страницу.");
define("LAN_16", "[ заблокировано Админом ]");
// Notify
define("NT_LAN_CB_1", "События в чатбоксе");
define("NT_LAN_CB_2", "добавленные сообщения");
define("NT_LAN_CB_3", "Добавлено");
define("NT_LAN_CB_4", "IP-адрес");
define("NT_LAN_CB_5", "Сообщение");
define("NT_LAN_CB_6", "Сообщение в чат-боксе");

?>