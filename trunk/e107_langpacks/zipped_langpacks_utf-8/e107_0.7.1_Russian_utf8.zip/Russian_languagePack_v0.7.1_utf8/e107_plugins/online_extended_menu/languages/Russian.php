﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
	
define("ONLINE_EL1", "Гостей: ");
define("ONLINE_EL2", "Пользователей: ");
define("ONLINE_EL3", "На этой странице: ");
define("ONLINE_EL4", "В Сети");
define("ONLINE_EL5", "Пользователей");
define("ONLINE_EL6", "Новичок");
define("ONLINE_EL7", "смотрит");
	
define("ONLINE_EL8", "рекорд он-лайн: ");
define("ONLINE_EL9", "в");

define("TRACKING_MESSAGE", "Отслеживание пользователей он-лайн в настоящий момент отключено, пожалуйста включите его <a href='".e_ADMIN."users.php?options'>здесь</a><br />");

?>