﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/22 18:20:52 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "Настроить обратную связь");
define("TRACKBACK_L2", "Плагин позволяет организовать обратную связь в ваших новостях.");
define("TRACKBACK_L3", "Плагин установлен и включен.");
define("TRACKBACK_L4", "Настройки сохранены.");
define("TRACKBACK_L5", "Вкл");
define("TRACKBACK_L6", "выкл");
define("TRACKBACK_L7", "Активировать обратную связь");
define("TRACKBACK_L8", "URL текста обратной связи");
define("TRACKBACK_L9", "Сохранить настройки");
define("TRACKBACK_L10", "Настройки");
define("TRACKBACK_L11", "Адрес обратной связи для этого сообщения:");

define("TRACKBACK_L12", "Для этого элемента нет обратной связи");
define("TRACKBACK_L13", "Модерировать обратную связь");
define("TRACKBACK_L14", "Удалить");
define("TRACKBACK_L15", "Удалено.");

?>