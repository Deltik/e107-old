﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Статистика");
	
define("ADSTAT_L1", "Этот плагин зарегистрирует все посещения вашего сайта, и сформирует детальные статистические отчеты, основанные на собранной информации.");
define("ADSTAT_L2", "Плагин статистики был успешно установлен. Для конвертирования вашей статистики в новую систему, <a href='".e_PLUGIN."log/update_routine.php'>щелкните здесь для запуска подпрограммы обновления</a>.");
define("ADSTAT_L3", "Статистика включена");
define("ADSTAT_L4", "У вас нет прав для просмотра этой страницы.");
define("ADSTAT_L5", "Особенности на этой странице были отключены.");
define("ADSTAT_L6", "Статистика сайта");
define("ADSTAT_L7", "Статистика для этого типа не собирается.");
define("ADSTAT_L8", "Статистика за Сегодня");
define("ADSTAT_L9", "Статистика за все время");
define("ADSTAT_L10", "Ежедневно");
define("ADSTAT_L11", "Ежемесячно");
define("ADSTAT_L12", "Браузеры");
define("ADSTAT_L13", "Операционные системы");
define("ADSTAT_L14", "Домены");
define("ADSTAT_L15", "Разрешение экрана / глубина цвета");
define("ADSTAT_L16", "Рефералы");
define("ADSTAT_L17", "Поисковые запросы");
define("ADSTAT_L18", "Последние посетители");
define("ADSTAT_L19", "Страница");
define("ADSTAT_L20", "Посещения Сегодня");
define("ADSTAT_L21", "Всего");
define("ADSTAT_L22", "Уникальных");
define("ADSTAT_L23", "Всего посещений");
define("ADSTAT_L24", "Всего уникальных посещений");
define("ADSTAT_L25", "Статистики еще нет.");
define("ADSTAT_L26", "Браузер");
define("ADSTAT_L27", "Операционная система");
define("ADSTAT_L28", "Страны / Домены");
define("ADSTAT_L29", "Разрешение экрана");
define("ADSTAT_L30", "Сайты-рефералы");
define("ADSTAT_L31", "Запросы с поисковых систем");
define("ADSTAT_L32", "Пришли с");
define("ADSTAT_L33", "Посещений в последнее время");
define("ADSTAT_L34", "Посещений");
define("ADSTAT_L35", "Уникальных посещений в последнее время");
define("ADSTAT_L36", "дней на странице");
define("ADSTAT_L37", "Посещений в месяц");
define("ADSTAT_L38", "Уникальных посещений в месяц");
define("ADSTAT_L39", "удалить эту запись");
define("ADSTAT_L40", "дней");
define("ADSTAT_L41", "Ошибка");

?>