﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
	
define("CM_L1", "Нет комментариев.");
define("CM_L2", "");
define("CM_L3", "Заголовок");
define("CM_L4", "Количество ввыодимых комментариев?");
define("CM_L5", "Количество выводимых символов?");
define("CM_L6", "Постфикс для слишком длинных комментариев?");
define("CM_L7", "Показывать название новости в заголовке?");
define("CM_L8", "Настройка меню комментариев");
define("CM_L9", "Обновить настройки меню");
define("CM_L10", "Настроки меню комментариев сохранены");
	
	
?>