﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
	
define("CLOCK_AD_L1", "Настройки часов сохранены");
define("CLOCK_AD_L2", "Заголовок");
define("CLOCK_AD_L3", "Обновить настройки меню");
define("CLOCK_AD_L4", "Настройки меню часов");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Если отмечено, будет отображать время в БУРЖУЙСКОМ формате (0-12 формат AM/PM). Если не отметить, будете отображен 'наш' формат 0-24");
define("CLOCK_AD_L7", "Преффикс даты");
define("CLOCK_AD_L8", "Если ваш язык требует приставки к Дате (в русском языке - это не нужно...), используйте это поле. Если нет - оставьте пусто.");
define("CLOCK_AD_L9", "Суффикс 1");
define("CLOCK_AD_L10", "Суффикс 2");
define("CLOCK_AD_L11", "Суффикс 3");
define("CLOCK_AD_L12", "Суффикс 4 и дальше");
define("CLOCK_AD_L13", "Если в вашем языке нужно проставить суффикс после номера даты, заполните эти поля нужными суффиксами (Пример: 'е' для 1, 'е' для 2, и т.д.). Если вам это не нужно - оставьте пустым.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>