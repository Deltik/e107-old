﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', 'Конфигурация сохранена');
define('CLOCK_MENU_L2', 'Заголовок');
define('CLOCK_MENU_L3', 'Обновить настройки');
define('CLOCK_MENU_L4', 'Настройки меню Часов');
define('CLOCK_MENU_L5', 'Понедельник,');
define('CLOCK_MENU_L6', 'Вторник,');
define('CLOCK_MENU_L7', 'Среда,');
define('CLOCK_MENU_L8', 'Четверг,');
define('CLOCK_MENU_L9', 'Пятница,');
define('CLOCK_MENU_L10', 'Суббота,');
define('CLOCK_MENU_L11', 'Воскресенье,');
define('CLOCK_MENU_L12', 'Января');
define('CLOCK_MENU_L13', 'Февраля');
define('CLOCK_MENU_L14', 'Марта');
define('CLOCK_MENU_L15', 'Апреля');
define('CLOCK_MENU_L16', 'Мая');
define('CLOCK_MENU_L17', 'Июня');
define('CLOCK_MENU_L18', 'Июля');
define('CLOCK_MENU_L19', 'Августа');
define('CLOCK_MENU_L20', 'Сетября');
define('CLOCK_MENU_L21', 'Октября');
define('CLOCK_MENU_L22', 'Ноября');
define('CLOCK_MENU_L23', 'Декабря');
define('CLOCK_MENU_L24', '');
?>