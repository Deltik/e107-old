﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " могут транслироваться, используя rss-транслятор.");
define("BACKEND_MENU_L2", "RSS-Транслятор");

define("BACKEND_MENU_L3", "Наши новости");
define("BACKEND_MENU_L4", "Наши комментарии");
define("BACKEND_MENU_L5", "Темы нашего форума");
define("BACKEND_MENU_L6", "Сообщения нашего форума");

define("BACKEND_MENU_L7", "Сообщения нашего миничата");
define("BACKEND_MENU_L8", "Сообщения bugtracker");
define("BACKEND_MENU_L9", "Наши загрузки");

define("RSS_LAN01", "Включить отдельное транслирование для каждой категории новостей?");
define("RSS_LAN02", "Включить отдельное транслирование для каждой категории загрузок?");

define("RSS_NEWS","Новости");
define("RSS_COM","Комментарии"); 
define("RSS_ART","Статьи");
define("RSS_REV", "Обзоры");
define("RSS_FT","Темы форума");
define("RSS_FP","Сообщения форума");
define("RSS_FSP","Специфические сообщения форума");
define("RSS_BUG","Bugtracker");
define("RSS_FOR","Форум");
define("RSS_DL","Загрузки");
?>