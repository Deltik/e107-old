﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     Russian Language Pack for e107 V.0.7
|     $Revision: 1.0 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: DeepMaster $
+----------------------------------------------------------------------------+
*/

define("ONLINE_L1", "Гостей: ");
define("ONLINE_L2", "Пользователей: ");
define("ONLINE_L3", "На этой странице: ");
define("ONLINE_L4", "Он-лайн");
define("ONLINE_L5", "Пользователей");
define("ONLINE_L6", "новичок");
define("TRACKING_MESSAGE", "Отслеживание пользователей он-лайн в настоящий момент отключено, пожалуйста включите его <a href='".e_ADMIN."users.php?options'>здесь</a><br />");
?>