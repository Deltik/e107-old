<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Hungarian/admin/lan_userclass.php,v $
|     $Revision: 1.3 $
|     $Date: 2008/04/04 21:03:58 $
|     $Author: e107hungary.org team $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Értesítés küldése");
define("UCSLAN_2", "Jogosultságok frissítése");
define("UCSLAN_3", "Kedves");
define("UCSLAN_4", "Jogosultságaid frissítve a következő oldalon:");
define("UCSLAN_5", "Mostantól elérheted a következő részleg(ek)et:");
define("UCSLAN_6", "Csoport beállítása felhasználóra");
define("UCSLAN_7", "Csoport beállítása");
define("UCSLAN_8", "Felhasználó értesítése");
define("UCSLAN_9", "Csoportok frissítve");
define("UCSLAN_10", "Üdvözlettel");
define('UCSLAN_12', 'Csak tagság joggal');
?>