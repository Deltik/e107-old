<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("TPVLAN_1", "Ez a(z) <b>'".PREVIEWTHEMENAME."'</b> theme előnézete. Ez nem az oldalad theme-je, csak azt mutatja meg, hogy néz ki az oldalad e theme-vel.<br />A theme használatához lépj <a href='".e_ADMIN."theme.php'>a theme kezelőbe</a> és válaszd a 'Beállítás az oldal témájaként' opciót.<br /><a href='".e_ADMIN."theme.php'>További témák előnézete</a>");
define("TPVLAN_2", "Theme előnézet");
define("TPVLAN_3", "Az oldal témája:");
define("TPVLAN_4", "Készítette");
define("TPVLAN_5", "Weboldal");
define("TPVLAN_6", "Kiadás dátuma");
define("TPVLAN_7", "Információ");
define("TPVLAN_8", "Opciók");
define("TPVLAN_9", "Theme előnézete");
define("TPVLAN_10", "Beállítás az oldal témájaként");
define("TPVLAN_11", "Verzió");
define("TPVLAN_12", "Nincs előnézet");

define("TPVLAN_13", "Theme feltöltése (.zip vagy .tar.gz formátum)");
define("TPVLAN_14", "Theme feltöltése");
define("TPVLAN_15", "Az automatikus feltöltés nem lehetséges, mert a(z) ".e_THEME." könyvtár nem írható - adj rá írási jogot (CHMOD 777).");
define("TPVLAN_16", "Admin üzenet");
define("TPVLAN_17", "A file nem tűnik ténylegesen .zip vagy .tar archívnak.");
define("TPVLAN_18", "Hiba: a file kicsomagolása nem sikerült");
define("TPVLAN_19", "A theme feltöltve és kicsomagolva, görgesd lefelé az oldalt, ha látni akarod a theme-t a  listában.");
define("TPVLAN_20", "Az automatikus feltöltés és kicsomagolás nem lehetséges, mert a themes könyvtár nem írható - adj rá írási jogot (CHMOD 777).");

define("TPVLAN_21", "Jelenleg ez a beállított theme");

define("TPVLAN_22", "a theme több stíluslapot tartalmaz");
define("TPVLAN_23", "alapértelmezett stíluslap");
define("TPVLAN_24", "nincs információ");
define("TPVLAN_25", "A használandó stíluslap kiválasztásához lépj a <a href='".e_ADMIN."prefs.php'>beállítások</a> részbe, és kattints a 'Theme'-re.");

define("TPVLAN_26", "Theme Manager");
define("TPVLAN_27", "Válaszd ki a használandó stíluslapot");
define("TPVLAN_28", "be");
define("TPVLAN_29", "ki");
define("TPVLAN_30", "Theme képek előtöltése:");

define("TPVLAN_31", "Jelenleg ez az admin theme");
define("TPVLAN_32", "Beállítás admin theme-ként");

define("TPVLAN_33", "Jelenlegi oldal theme");
define("TPVLAN_34", "Jelenlegi admin theme");
define("TPVLAN_35", "Beállítások mentése");
define("TPVLAN_36", "Admin üzenet");
define("TPVLAN_37", "Theme beállítások elmentve");
define("TPVLAN_38", "Theme feltöltése");
define("TPVLAN_39", "Használható theme-k");
define("TPVLAN_40", "Beállítás admin theme-ként");

define("TPVLAN_41", "Válaszd ki a használandó admin elrendezési stílust");
define("TPVLAN_42", "Admin beállítások mentése");
define("TPVLAN_43", "Admin beállítások elmentve");


define("TPVLAN_46", "PCLZIP kicsomagolási hiba:");
define("TPVLAN_47", "PCLTAR kicsomagolási hiba: ");
define("TPVLAN_48", "kód:");

?>
