<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UGFLAN_1", "Karbantartási beállítások frissítve");
define("UGFLAN_2", "Bekapcsolás");
define("UGFLAN_3", "Beállítások mentése");
define("UGFLAN_4", "Karbantartási beállítások");

define("UGFLAN_5", "Karbantartási üzenet");
define("UGFLAN_6", "Hagyd üresen az alapértelmezett üzenet megjelenítéséhez");

?>