<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ŠSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/banlist.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/02/11 10:33:58 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Kitiltások súgó";
$text = "Kitilthatsz felhasználókat az oldalról itt.<br />
Add meg a teljes IP címet, vagy használj *-ot egy IP cím tartomány kitiltásához.<br /><br />
<b>Kitiltás IP címmel:</b><br />
Az 123.123.123.123 IP cím megadásával letiltod az erről a címről érkező felhasználókat.<br />
Az 123.123.123.* IP cím megadásával letiltod az erről az IP cím tartományról érkező felhasználókat.<br /><br />
<b>Kitiltás email címmel</b><br />
A foo@bar.com email cím megadása letiltja ennek az email címnek a használatát, így e címmel senki nem fog tudni regisztrálni.<br />
Az *@bar.com cím megadása a bar.com domain-t tiltja le, így e domainről semmilyen email címmel senki nem fog tudni regisztrálni.<br /><br />
<b>Kitiltás felhasználónévvel</b><br />
Ezt végrehajthatod a felhasználók adminisztrációs oldalról.";
$ns -> tablerender($caption, $text);
?>
