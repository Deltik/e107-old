<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.7 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("EMOLAN_1", "Emotikonok bekapcsolása");
define("EMOLAN_2", "Név");
define("EMOLAN_3", "Emotikon");
define("EMOLAN_4", "Emotikonok bekapcsolása?");

define("EMOLAN_5", "Emotikon kép");
define("EMOLAN_6", "Emotikon kód");
define("EMOLAN_7", "összetett beíráshoz használj szóközt");

define("EMOLAN_8", "Állapot");
define("EMOLAN_9", "Beállítások");
define("EMOLAN_10", "Aktív");
define("EMOLAN_11", "Aktiválás");

define("EMOLAN_12", "Módosít / beállít");
define("EMOLAN_13", "Telepített csomagok");

define("EMOLAN_14", "Beállítások mentése");
define("EMOLAN_15", "Emotikon módosítása / beállítása");
define("EMOLAN_16", "Emotikon beállítások elmentve");
define("EMOLAN_17", "Ha az emotikon csomag szóközt tartalmaz, akkor az nem lesz engedélyezve !");
define("EMOLAN_18", "nevezd át az alábbi listában lévőket, hogy ne tartalmazzanak szóközt:");
define("EMOLAN_19", "Név");
define("EMOLAN_20", "Hely");
define("EMOLAN_21", "Hiba");
//define("EMOLAN_2", "Name");
define("EMOLAN_22", "Új emotikon csoport:");
define("EMOLAN_23", "Új emotikon xml csoport:");
define("EMOLAN_24", "Új emotikon php:");
define("EMOLAN_25", "Új emotikon php telepítése: ");
define("EMOLAN_26", "Csomag újra-ellenőrzése");
define("EMOLAN_27", "Hiba történt a csomag feldolgozásában: ");
define("EMOLAN_28", "XML létrehozása");
define("EMOLAN_29", "XML file létrehozva: ");
define("EMOLAN_30", "Hiba az XML file írásakor: ");


?>
