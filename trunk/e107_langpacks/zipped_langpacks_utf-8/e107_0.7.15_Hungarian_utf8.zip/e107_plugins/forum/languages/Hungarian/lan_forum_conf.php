<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FORLAN_5", "Szavazás törölve");
define("FORLAN_6", "Téma törölve");
define("FORLAN_7", "Válaszok törölve");
define("FORLAN_8", "Törlés visszavonva");
define("FORLAN_9", "Téma áthelyezve");
define("FORLAN_10", "Áthelyezés visszavonva");
define("FORLAN_11", "Vissza a fórumokhoz");
define("FORLAN_12", "Fórum beállítások");
define("FORLAN_13", "Biztos, hogy törölni akarod ezt a szavazást?<br /><b><u>Nem lehet</u></b> majd visszaállítani");
define("FORLAN_14", "Mégse");
define("FORLAN_15", "Hozzászólás törlése");
define("FORLAN_16", "Szavazás törlése");
define("FORLAN_17", "Írta:");
define("FORLAN_18", "Biztos, hogy törölni akarod ezt");
define("FORLAN_19", "a témát az összes hozzászólással együtt?");
define("FORLAN_20", "a szavazás szintén törlésre kerül.");
define("FORLAN_21", "Törlés után");
define("FORLAN_22", "a hozzászólást?<br />Törlés után");
define("FORLAN_23", "nem</u></b> állítható(k) vissza");
define("FORLAN_24", "Téma áthelyezése az adott fórumba");
define("FORLAN_25", "Téma áthelyezése");
define("FORLAN_26", "Válasz törölve");

define("FORLAN_27", "áthelyezve");

define("FORLAN_28", "Nem lehet átnevezni a téma címét");
define("FORLAN_29", "Hozzáad");
define("FORLAN_30", "a címhez");
define("FORLAN_31", "Átnevezés erre:");
define("FORLAN_32", "Téma beállítások átnevezése:");

?>
