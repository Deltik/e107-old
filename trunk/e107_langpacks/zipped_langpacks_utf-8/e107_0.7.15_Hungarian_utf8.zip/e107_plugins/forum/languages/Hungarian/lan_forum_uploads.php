<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.1 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Fórum feltöltések");

define('FRMUP_1','Feltöltött file-ok a fórumban');
define('FRMUP_2','File törölve');
define('FRMUP_3','Hiba: A file nem törölhető');
define('FRMUP_4','File törlés');
define('FRMUP_5','File neve');
define('FRMUP_6','Eredmény');
define('FRMUP_7','Találat a témában');
define('FRMUP_8','Nincs találat');
define('FRMUP_9','Nincs feltöltött file');
define('FRMUP_10','Törlés');

?>
