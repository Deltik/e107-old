<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CLOCK_AD_L1","Beállítás elmentve");
define("CLOCK_AD_L2","Címsor");
define("CLOCK_AD_L3","Beállítás frissítése");
define("CLOCK_AD_L4","Beállítás");
define("CLOCK_AD_L5","AM/PM");
define("CLOCK_AD_L6","Ha bejelölt, az idő US formátumban (12 órás, AM/PM) lesz kijelezve. Ha nincs bejelölve, az idő 'katonai' formátumban (24 órás) lesz kijelezve.");
define("CLOCK_AD_L7","Dátum előtag");
define("CLOCK_AD_L8","Ha a nyelvedben a dátum elé egy rövid szó kell (például 'le' a franciában, vagy 'den' a németben...), használd ezt a mezőt. Ha nem kell, hagyd üresen.");
define("CLOCK_AD_L9","Utótag 1");
define("CLOCK_AD_L10","Utótag 2");
define("CLOCK_AD_L11","Utótag 3");
define("CLOCK_AD_L12","Utótag 4 és több");
define("CLOCK_AD_L13","Ha a nyelvedben a dátum számai után egy utótag kell, töltsd ki ezeket a mezőket csak az utótagokkal. (Példa: 'st' az 1 után, 'nd' a 2 után, 'rd' a 3 után és 'th' a 4 és több után az english nyelvben). Ha nem kell, hagyd üresen.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>
