<?php
# --------------------------------------------------------------------------
# e107 Hungarian language file - $Version: 1.00 $ - $Author: e107hungary.org team $ - $Date: 2008 $
# --------------------------------------------------------------------------

define('LAN_UMENU_THEME_1', 'Theme kiválasztás');
define('LAN_UMENU_THEME_2', 'Theme kiválasztása');
define('LAN_UMENU_THEME_3', 'felhasználók:');
define('LAN_UMENU_THEME_4', 'Azon theme-k engedélyezése, melyeket a felhasználók kiválaszthatnak');
define('LAN_UMENU_THEME_5', 'Frissítés');
define('LAN_UMENU_THEME_6', 'A felhasználók rendelkezésére álló theme-k');
define('LAN_UMENU_THEME_7', 'Csoport, amely theme-ket tud választani');

?>