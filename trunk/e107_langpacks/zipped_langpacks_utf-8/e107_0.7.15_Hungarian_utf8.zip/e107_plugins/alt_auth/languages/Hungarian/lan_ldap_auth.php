<?php

define("LDAPLAN_1", "Szerver cím");
define("LDAPLAN_2", "Base (Bázis) DN vagy Domain<br />Ha LDAP - Írd be BaseDN<br />Ha AD - Írd be a domain-t");
define("LDAPLAN_3", "LDAP felhasználó keresése<br />A Felhasználó teljes kontextusa, aki kereshet könyvtárat.");
define("LDAPLAN_4", "LDAP jelszó keresése<br />LDAP felhasználó keresés jelszava.");
define("LDAPLAN_5", "LDAP Verzió");
define("LDAPLAN_6", "LDAP auth beállítása");
define("LDAPLAN_7", "eDirectory keresés szűrő:");
define("LDAPLAN_8", "Ennek használata biztosíthatja a felhasználónév elrendezését a megfelelő fa szerkezetben, <br />Pl.: '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Jelenlegi keresés szűrő lehet:");
define("LDAPLAN_10", "Beállítások frissítve");
define("LDAPLAN_11", "Figyelmeztetés:  Megjelenik, ha az ldap modul nincs engedélyezve, az auth method beállításai az LDAP-hoz valószínűleg nem fognak működni!");
define("LDAPLAN_12", "Szerver Típus");
define("LDAPLAN_13", "Beállítások frissítése");
?>
