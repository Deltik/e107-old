<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF létrehozás támogatás");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "A plugin használatra kész.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF beállítások");
define("PDF_LAN_3", "Engedélyezve");
define("PDF_LAN_4", "Letiltva");
define("PDF_LAN_5", "Oldal margó balra");
define("PDF_LAN_6", "Oldal margó jobbra");
define("PDF_LAN_7", "Oldal margó felül");
define("PDF_LAN_8", "Betűtípus");
define("PDF_LAN_9", "Alapértelmezett betű méret");
define("PDF_LAN_10", "Oldalnév betűmérete");
define("PDF_LAN_11", "Oldal URL betűmérete");
define("PDF_LAN_12", "Oldalszámozás betűmérete");
define("PDF_LAN_13", "Megjelenítse a logo-t a pdf-ben?");
define("PDF_LAN_14", "Megjelenítse az oldal nevét a pdf-ben?");
define("PDF_LAN_15", "Megjelenítse a készítő oldalának url-jét a pdf-ben?");
define("PDF_LAN_16", "Megjelenítse az oldalszámot a pdf-ben?");
define("PDF_LAN_17", "Frissítés");
define("PDF_LAN_18", "PDF beállítások sikeresen frissítve");
define("PDF_LAN_19", "Oldal");
define("PDF_LAN_20", "hiba jelentése");

?>
