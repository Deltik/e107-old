<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107 Hungary team - 2004
# --------------------------------------------------------------------------

define("TD_MENU_L1", "Egyéb hírek");
define("TD_MENU_L2", "Egyéb hírek");

?>
