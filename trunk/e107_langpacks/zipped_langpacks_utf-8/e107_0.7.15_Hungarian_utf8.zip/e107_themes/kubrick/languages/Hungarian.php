<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ŠSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/kubrick/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/08/29 16:22:56 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' by <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Based on original theme by Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Hozzászólás kikapcsolva");
define("LAN_THEME_3", "Hozzászólás: ");
define("LAN_THEME_4", "Tovább ...");
define("LAN_THEME_5", "Trackback: ");


?>