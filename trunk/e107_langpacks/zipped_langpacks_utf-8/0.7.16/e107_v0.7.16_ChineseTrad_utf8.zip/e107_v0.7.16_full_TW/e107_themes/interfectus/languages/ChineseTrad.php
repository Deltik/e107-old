<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/interfectus/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/03/21 11:27:11 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'interfectus' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "閱讀/發表評論: ");
define("LAN_THEME_3", "此內容關閉評論");
define("LAN_THEME_4", "閱讀更多 ...");
define("LAN_THEME_5", "引用追蹤: ");

?>
