<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/e107v4a/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/03/21 10:50:01 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "閱讀/發表評論: ");
define("LAN_THEME_2", "此內容關閉評論");
define("LAN_THEME_3", "閱讀更多...");
define("LAN_THEME_4", "作者");
define("LAN_THEME_5", "發表時間");
define("LAN_THEME_6", "e107.v4 theme by <a href='http://e107.org' rel='external'>jalist</a>");

?>
