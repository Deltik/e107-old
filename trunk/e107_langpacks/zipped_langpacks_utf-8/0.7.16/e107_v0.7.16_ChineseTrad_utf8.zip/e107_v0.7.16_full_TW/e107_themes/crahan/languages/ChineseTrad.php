<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/crahan/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/21 11:49:22 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'CraHan' by <a href='http://e107.org' rel='external'>jalist</a>, based on the theme by CraHan at his homepage <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "此內容關閉評論");
define("LAN_THEME_3", "評論數: ");
define("LAN_THEME_4", "閱讀更多 ...");
define("LAN_THEME_5", "引用追蹤: ");
define("LAN_THEME_6", "評論於");


?>
