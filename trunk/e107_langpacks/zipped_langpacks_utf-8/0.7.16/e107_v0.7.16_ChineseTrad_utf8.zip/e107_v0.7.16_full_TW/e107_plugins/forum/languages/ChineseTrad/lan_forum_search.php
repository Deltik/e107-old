<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/zhtw/lan_forum_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "版面");
define("FOR_SCH_LAN_2", "選擇版面");
define("FOR_SCH_LAN_3", "所有版面");
define("FOR_SCH_LAN_4", "全部的內容");
define("FOR_SCH_LAN_5", "部分內容");

?>