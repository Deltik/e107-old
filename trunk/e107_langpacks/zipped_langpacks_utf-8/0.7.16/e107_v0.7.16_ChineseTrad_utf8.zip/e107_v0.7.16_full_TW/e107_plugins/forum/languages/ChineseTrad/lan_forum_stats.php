<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/zhtw/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "討論區狀態統計");

define("FSLAN_1", "一般");
define("FSLAN_2", "討論區啟動日期");
define("FSLAN_3", "經歷時間");
define("FSLAN_4", "全部文章數");
define("FSLAN_5", "主題數");
define("FSLAN_6", "回覆數");
define("FSLAN_7", "瀏覽人數");
define("FSLAN_8", "資料大小 (僅限於討論區資料表)");
define("FSLAN_9", "討論區資料表平均長度大小");
define("FSLAN_10", "最多人瀏覽");
define("FSLAN_11", "等級");
define("FSLAN_12", "文章");
define("FSLAN_13", "回覆數");
define("FSLAN_14", "作者");
define("FSLAN_15", "日期");
define("FSLAN_16", "最多人瀏覽文章");
define("FSLAN_17", "瀏覽次數");
define("FSLAN_18", "最多發表文章");
define("FSLAN_19", "名稱");
define("FSLAN_20", "發表");
define("FSLAN_21", "最多發表文章會員");
define("FSLAN_22", "最多回覆會員");
define("FSLAN_23", "討論區統計");
define("FSLAN_24", "平均每天發表數");

?>