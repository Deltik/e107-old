<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/07 02:54:20 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("TREE_L1", "設定樹狀選單");
define("TREE_L2", "更新樹狀選單設定");
define("TREE_L3", "已儲存樹狀選單設定.");
define("TREE_L4", "開啟");
define("TREE_L5", "關閉");
define("TREE_L6", "CSS 可使用於非開放性連結");
define("TREE_L7", "CSS 可使用於開放性連結");
define("TREE_L8", "CSS 可使用於已開放連結");
define("TREE_L9", "使用空白鍵分離兩個主要連結");

?>