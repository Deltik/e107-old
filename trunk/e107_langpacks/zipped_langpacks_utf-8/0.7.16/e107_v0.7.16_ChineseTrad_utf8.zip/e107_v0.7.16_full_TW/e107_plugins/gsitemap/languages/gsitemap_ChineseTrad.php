<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/gsitemap/languages/gsitemap_zhtw.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "網站地圖");
define("GSLAN_1", "網站連結");
define("GSLAN_2", "匯入?");
define("GSLAN_3", "類型");
define("GSLAN_4", "名稱");
define("GSLAN_5", "連結");
define("GSLAN_6", "勾選連結匯入 ...");
define("GSLAN_7", "匯入連結");
define("GSLAN_8", "匯入於:");
define("GSLAN_9", "比重");
define("GSLAN_10", "頻率");
define("GSLAN_11", "永遠");
define("GSLAN_12", "每小時");
define("GSLAN_13", "每天");
define("GSLAN_14", "每週");
define("GSLAN_15", "每月");
define("GSLAN_16", "每年");
define("GSLAN_17", "從來沒有");
define("GSLAN_18", "匯入勾選連結");
define("GSLAN_19", "Google 網站的提");
define("GSLAN_20", "列出清單中");
define("GSLAN_21", "導引");
define("GSLAN_22", "新增目錄");
define("GSLAN_23", "匯入");
define("GSLAN_24", "Google 地圖目錄");
define("GSLAN_25", "名稱");
define("GSLAN_26", "URL");
define("GSLAN_27", "最後修改");
define("GSLAN_28", "頻率.");
define("GSLAN_29", "Google 網站地圖設定n");
define("GSLAN_30", "顯示順序");
define("GSLAN_31", "瀏覽權限設於");
define("GSLAN_32", "如何使用 Google 網站地圖");
define("GSLAN_33", "GSiteMap 導覽");
define("GSLAN_34", "首先, 新增您希望的網站連結.您可以匯入連結點選 '匯入' 按鈕");
define("GSLAN_35", "假如您曾經匯入連結,點選 '匯入' 然後確認您希望匯入的連結");
define("GSLAN_36", "您可以輸入個別的連結點選 '新增目錄'");
define("GSLAN_37", "您有一些目錄, 前往 <a href='https://www.google.com/webmasters/sitemaps/stats'>https://www.google.com/webmasters/sitemaps/stats</a> 並輸入下列網址 -> <b>".SITEURL."gsitemap.php</b> - 假如該連結無法觀看,請確認您的網站連結於管理後台 -> 偏好設定");
define("GSLAN_38", "更多訊息有關於 Google Sitemap protocol, 前往 <a href='http://www.google.com/webmasters/sitemaps/docs/en/protocol.html'>http://www.google.com/webmasters/sitemaps/docs/en/protocol.html</a>.");
define("GSLAN_39", "目前沒有網站地圖連結 - 匯入網站連結?");
define("GSLAN_40", "Google 網站地圖目錄");

?>