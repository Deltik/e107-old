<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| 咎teve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
| $Date: 2006/11/08 12:57:27 $
| $Author: Hanklu-www.phpbs.com-正體中文製作$
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
	
define("CM_L1", "目前沒有評論.");
define("CM_L2", "");
define("CM_L3", "標題");
define("CM_L4", "顯示多少評論?");
define("CM_L5", "顯示多少字元?");
define("CM_L6", "評論字尾太長?");
define("CM_L7", "顯示原始新聞標題於選單中?");
define("CM_L8", "新聞評論選單設定");
define("CM_L9", "更新選單設定");
define("CM_L10", "評論選單設定已儲存");
define("CM_L11", "在");
define("CM_L12", "Re:");
define("CM_L13", "發表於");
	
	
?>