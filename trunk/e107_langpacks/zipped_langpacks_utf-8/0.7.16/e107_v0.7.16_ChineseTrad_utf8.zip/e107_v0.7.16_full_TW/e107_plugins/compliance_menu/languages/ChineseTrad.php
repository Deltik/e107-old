<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/compliance_menu/languages/zhtw.php,v $
|     $Revision: 1.3 $
| $Date: 2006/11/08 12:57:27 $
| $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
	
define("COMPLIANCE_L1", "符合 W3C 規範");

?>