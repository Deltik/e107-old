<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/zhtw/lan_content_search.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "內容");
define("CONT_SCH_LAN_2", "所有內容分區");
define("CONT_SCH_LAN_3", "回覆該項目");
define("CONT_SCH_LAN_4", "於");

?>