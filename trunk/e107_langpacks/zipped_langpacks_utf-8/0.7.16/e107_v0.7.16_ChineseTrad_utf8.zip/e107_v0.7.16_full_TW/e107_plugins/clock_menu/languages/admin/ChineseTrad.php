<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/admin/zhtw.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
	
define("CLOCK_AD_L1", "時鐘選單設定已儲存");
define("CLOCK_AD_L2", "標題");
define("CLOCK_AD_L3", "更新選單設定");
define("CLOCK_AD_L4", "時鐘選單設定");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "假如選擇後,將會顯示12小時時區 (0-12 AM/PM ). 不選擇將會顯示24小時時區 0-24 ");
define("CLOCK_AD_L7", "Date Prefix");
define("CLOCK_AD_L8", "假如您的語言於需要簡短字體顯示於日期前 (例如： 法文的'le' 或是德文 'den' ...), 請使用該欄位.假如不需要請留空");
define("CLOCK_AD_L9", "字尾 1");
define("CLOCK_AD_L10", "字尾 2");
define("CLOCK_AD_L11", "字尾 3");
define("CLOCK_AD_L12", "字尾 4 或是更多");
define("CLOCK_AD_L13", "假如您的語言於需要簡短字體顯示於日期後面, 請填寫這些欄位 (例如:英語中的 'st' 為 1, 'nd' 為 2, 'rd' 為 3 和 'th' 為 4 等等). 假如不需要請留空.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>