<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/zhtw.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', '時鐘選單設定已儲存');
define('CLOCK_MENU_L2', '標題');
define('CLOCK_MENU_L3', '更新選單設定');
define('CLOCK_MENU_L4', '時鐘選單設定');
define('CLOCK_MENU_L5', '星期一,');
define('CLOCK_MENU_L6', '星期二,');
define('CLOCK_MENU_L7', '星期三,');
define('CLOCK_MENU_L8', '星期四,');
define('CLOCK_MENU_L9', '星期五,');
define('CLOCK_MENU_L10', '星期六,');
define('CLOCK_MENU_L11', '星期日,');
define('CLOCK_MENU_L12', '一月');
define('CLOCK_MENU_L13', '二月');
define('CLOCK_MENU_L14', '三月');
define('CLOCK_MENU_L15', '四月');
define('CLOCK_MENU_L16', '五月');
define('CLOCK_MENU_L17', '六月');
define('CLOCK_MENU_L18', '七月');
define('CLOCK_MENU_L19', '八月');
define('CLOCK_MENU_L20', '九月');
define('CLOCK_MENU_L21', '十月');
define('CLOCK_MENU_L22', '十一月');
define('CLOCK_MENU_L23', '十二月');
define('CLOCK_MENU_L24', '');
?>