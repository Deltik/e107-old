<?php
	
define("NFPM_LAN_1", "主題");
define("NFPM_LAN_2", "作者");
define("NFPM_LAN_3", "瀏覽");
define("NFPM_LAN_4", "回覆");
define("NFPM_LAN_5", "最新發表");
define("NFPM_LAN_6", "主題");
define("NFPM_LAN_7", "於");
	
define("NFPM_L1", "該外掛將會顯示討論區最新文章於首頁中");
define("NFPM_L2", "最新討論區文章");
define("NFPM_L3", "請點選連結設定該外掛基本設定");
define("NFPM_L4", "啟動於哪個區域?");
define("NFPM_L5", "未啟動");
define("NFPM_L6", "頁面頂端");
define("NFPM_L7", "頁面底端");
define("NFPM_L8", "標題");
define("NFPM_L9", "顯示最新發表數目?");
define("NFPM_L10", "顯示於內部下拉階層?");
define("NFPM_L11", "階層高度");
define("NFPM_L12", "最新討論區文章設定");
define("NFPM_L13", "更新最新討論區文章設定");
define("NFPM_L14", "最新討論區文章設定已更新.");
define("NFPM_L15", "確認顯示最新文章.<br />預設為最少主題.");
define('NFPM_L16', '[該會員被刪除]');
	
	
?>