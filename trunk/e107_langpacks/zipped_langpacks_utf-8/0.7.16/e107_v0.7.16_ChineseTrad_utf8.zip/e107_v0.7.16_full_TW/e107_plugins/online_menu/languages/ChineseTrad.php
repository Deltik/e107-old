<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_menu/languages/English.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/10/13 13:12:13 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("ONLINE_L1", "線上訪客: ");
define("ONLINE_L2", "線上會員: ");
define("ONLINE_L3", "瀏覽頁頁 ");
define("ONLINE_L4", "線上情況");
define("ONLINE_L5", "會員");
define("ONLINE_L6", "最新的");
define("TRACKING_MESSAGE", "顯示線上會員功能關閉, 請到這裡 <a href='".e_ADMIN."users.php?options'>開啟</a><br />");
?>