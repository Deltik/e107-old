<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/powered_by_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/01/27 19:53:15 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
	
define("POWEREDBY_L1", "Powered by");
	
?>