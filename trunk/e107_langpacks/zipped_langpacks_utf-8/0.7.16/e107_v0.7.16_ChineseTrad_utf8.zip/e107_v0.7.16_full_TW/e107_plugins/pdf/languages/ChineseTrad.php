<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/16 10:36:59 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF 主要支援");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "外掛正在使用.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF 基本設定");
define("PDF_LAN_3", "開啟");
define("PDF_LAN_4", "關閉");
define("PDF_LAN_5", "頁面向左對齊");
define("PDF_LAN_6", "頁面向右對齊");
define("PDF_LAN_7", "頁面向上對齊");
define("PDF_LAN_8", "字型家族");
define("PDF_LAN_9", "預設字型大小");
define("PDF_LAN_10", "網站名稱字體大小");
define("PDF_LAN_11", "頁面連結字體大小");
define("PDF_LAN_12", "頁面數字字體大小");
define("PDF_LAN_13", "顯示 Logo 於 pdf?");
define("PDF_LAN_14", "顯示網站名稱於 pdf?");
define("PDF_LAN_15", "顯示新增頁面連結於 pdf?");
define("PDF_LAN_16", "顯示頁面編碼於pdf?");
define("PDF_LAN_17", "更新");
define("PDF_LAN_18", "PDF 基本設定更新");
define("PDF_LAN_19", "頁面");
define("PDF_LAN_20", "錯誤回報中");

?>