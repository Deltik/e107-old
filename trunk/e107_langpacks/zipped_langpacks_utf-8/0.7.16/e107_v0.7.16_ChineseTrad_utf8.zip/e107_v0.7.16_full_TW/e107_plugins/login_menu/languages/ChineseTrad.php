<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/login_menu/languages/ChineseTrad.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/01/27 19:53:08 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
	
define("LOGIN_MENU_L1", "帳號: ");
define("LOGIN_MENU_L2", "密碼: ");
define("LOGIN_MENU_L3", "註冊");
define("LOGIN_MENU_L4", "忘記密碼?");
define("LOGIN_MENU_L5", "歡迎光臨");
define("LOGIN_MENU_L6", "自動登入");
define("LOGIN_MENU_L7", "不建議使用特定模式 (可能會改變cookie).<br />請 <a href=\"".e_BASE."index.php?logout\">點選這裡</a>變更刪除此cookie.");
define("LOGIN_MENU_L8", "登出");
define("LOGIN_MENU_L9", "登入錯誤");
define("LOGIN_MENU_L10", "目前為維修狀態 - 代表一般訪客將會被帶往sitedown.php. 您可以到管理控制台/維修設定變更設定.");
define("LOGIN_MENU_L11", "管理控制台");
define("LOGIN_MENU_L12", "個人設定");
define("LOGIN_MENU_L13", "個人檔案");
define("LOGIN_MENU_L14", "新聞項目");
define("LOGIN_MENU_L15", "新聞項目");
define("LOGIN_MENU_L16", "聊天室文章");
define("LOGIN_MENU_L17", "聊天室文章");
define("LOGIN_MENU_L18", "評論");
define("LOGIN_MENU_L19", "評論");
define("LOGIN_MENU_L20", "版面討論");
define("LOGIN_MENU_L21", "版面討論");
define("LOGIN_MENU_L22", "新網站會員");
define("LOGIN_MENU_L23", "新網站會員");
define("LOGIN_MENU_L24", "點選這裡瀏覽新聞項目名單");
define("LOGIN_MENU_L25", "自從上次您訪問後至今");
define("LOGIN_MENU_L26", "沒有");
define("LOGIN_MENU_L27", "和");
define("LOGIN_MENU_L28", "登入");
	
define("LOGIN_MENU_L29", "新文章");
define("LOGIN_MENU_L30", "新文章");
	
// New config options
define('LOGIN_MENU_L31', '顯示新的新聞');
define('LOGIN_MENU_L32', '顯示新的文章');
define('LOGIN_MENU_L33', '顯示新的聊天室留言');
define('LOGIN_MENU_L34', '顯示新的評論');
define('LOGIN_MENU_L35', '顯示討論區新的發表');
define('LOGIN_MENU_L36', '顯示新註冊的會員');

define('LOGIN_MENU_L39', '離開管理控制台');
define("LOGIN_MENU_L40", "重新寄出認證信件");
define("LOGIN_MENU_L41", "登入選單設定");
	
?>