<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| 咎teve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
	
define("BLOGCAL_L1", "新聞於 ");
define("BLOGCAL_L2", "資料庫");
	
define("BLOGCAL_D1", "一");
define("BLOGCAL_D2", "二");
define("BLOGCAL_D3", "三");
define("BLOGCAL_D4", "四");
define("BLOGCAL_D5", "五");
define("BLOGCAL_D6", "六");
define("BLOGCAL_D7", "日");
	
define("BLOGCAL_M1", "一月");
define("BLOGCAL_M2", "二月");
define("BLOGCAL_M3", "三月");
define("BLOGCAL_M4", "四月");
define("BLOGCAL_M5", "五月");
define("BLOGCAL_M6", "六月");
define("BLOGCAL_M7", "七月");
define("BLOGCAL_M8", "八月");
define("BLOGCAL_M9", "九月");
define("BLOGCAL_M10", "十月");
define("BLOGCAL_M11", "十一月");
define("BLOGCAL_M12", "十二月");
	
define("BLOGCAL_1", "新聞項目");
	
define("BLOGCAL_CONF1", "每月/行");
define("BLOGCAL_CONF2", "表格邊框距離設定");
define("BLOGCAL_CONF3", "更先選單設定");
define("BLOGCAL_CONF4", "日誌日曆選單設定");
define("BLOGCAL_CONF5", "日誌日曆選單設定已儲存");
	
define("BLOGCAL_ARCHIV1", "選擇資料庫");
	
?>