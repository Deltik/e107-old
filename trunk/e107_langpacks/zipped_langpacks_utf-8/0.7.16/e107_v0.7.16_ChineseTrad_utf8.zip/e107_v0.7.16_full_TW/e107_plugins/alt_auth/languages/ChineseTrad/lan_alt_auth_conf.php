<?php
define("LAN_ALT_1", "目前認證方式");
define("LAN_ALT_2", "更新設定");
define("LAN_ALT_3", "使用間隔性的認證方式");
define("LAN_ALT_4", "設定參數於");
define("LAN_ALT_5", "設定認證參數");
define("LAN_ALT_6", "失敗連結動作");
define("LAN_ALT_7", "假如連線有間隔性的失敗, 該如何處理?");
define("LAN_ALT_8", "會員沒有找到動作");
define("LAN_ALT_9", "假如沒找到相關會員這動作有間隔性,該如何處理?");

define("LAN_ALT_FALLBACK", "使用 e107 會員資料表");
define("LAN_ALT_FAIL", "失敗的登入");

?>
