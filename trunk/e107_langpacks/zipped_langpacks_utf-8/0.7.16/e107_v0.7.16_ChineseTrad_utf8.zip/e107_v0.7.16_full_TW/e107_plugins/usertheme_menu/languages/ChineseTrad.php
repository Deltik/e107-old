<?php
	
define('LAN_UMENU_THEME_1', '設定風格');
define('LAN_UMENU_THEME_2', '選擇風格');
define('LAN_UMENU_THEME_3', '會員:');
define('LAN_UMENU_THEME_4', '開放風格給會員指定');
define('LAN_UMENU_THEME_5', '更新');
define('LAN_UMENU_THEME_6', '風格可以給會員使用');
define('LAN_UMENU_THEME_7', '選擇風格的權限');
	
?>