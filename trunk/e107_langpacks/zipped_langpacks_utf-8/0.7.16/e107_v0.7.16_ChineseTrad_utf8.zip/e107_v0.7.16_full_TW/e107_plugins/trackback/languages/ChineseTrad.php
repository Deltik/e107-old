<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/22 18:20:52 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "設定引用追蹤");
define("TRACKBACK_L2", "該外掛將會使用引用追蹤於您的文章中.");
define("TRACKBACK_L3", "引用追蹤已經安裝並開啟.");
define("TRACKBACK_L4", "引用追蹤已儲存設定.");
define("TRACKBACK_L5", "開啟");
define("TRACKBACK_L6", "關閉");
define("TRACKBACK_L7", "啟動引用追蹤");
define("TRACKBACK_L8", "引用追蹤連結文字");
define("TRACKBACK_L9", "儲存設定");
define("TRACKBACK_L10", "引用追蹤設定");
define("TRACKBACK_L11", "引用追蹤位址於該文章:");

define("TRACKBACK_L12", "目前沒有引用追蹤於該項目中");
define("TRACKBACK_L13", "編輯引用追蹤");
define("TRACKBACK_L14", "刪除");
define("TRACKBACK_L15", "引用追蹤已刪除.");

?>