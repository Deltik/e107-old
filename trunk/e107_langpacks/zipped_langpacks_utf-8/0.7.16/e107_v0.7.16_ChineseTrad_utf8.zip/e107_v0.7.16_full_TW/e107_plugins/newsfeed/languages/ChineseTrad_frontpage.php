<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsfeed/languages/English_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/07 20:56:04 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "新聞提供");
define("NWSF_FP_2", "首頁");

?>