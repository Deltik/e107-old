

tinyMCELang['lang_insert_emoticons_title'] = '插入表情圖示';
tinyMCELang['lang_emoticons_desc'] = '表情圖示';

