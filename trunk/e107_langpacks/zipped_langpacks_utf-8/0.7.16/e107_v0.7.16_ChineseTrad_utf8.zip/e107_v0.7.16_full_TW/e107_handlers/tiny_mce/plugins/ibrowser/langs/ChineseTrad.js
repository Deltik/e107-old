// UK lang variables

tinyMCELang['lang_ibrowser_title'] = '插入 / 編輯圖片';
tinyMCELang['lang_ibrowser_desc'] = '插入 / 編輯圖片';
tinyMCELang['lang_ibrowser_library'] = '圖庫';
tinyMCELang['lang_ibrowser_preview'] = '預覽';
tinyMCELang['lang_ibrowser_img_sel'] = '圖片選擇';
tinyMCELang['lang_ibrowser_img_info'] = '圖片資訊';
tinyMCELang['lang_ibrowser_img_upload'] = '圖片上傳';
tinyMCELang['lang_ibrowser_images'] = '圖片';
tinyMCELang['lang_ibrowser_src'] = '來源';
tinyMCELang['lang_ibrowser_alt'] = '描述';
tinyMCELang['lang_ibrowser_size'] = '大小';
tinyMCELang['lang_ibrowser_align'] = '文字方向';
tinyMCELang['lang_ibrowser_height'] = '高度';
tinyMCELang['lang_ibrowser_width'] = '寬度';
tinyMCELang['lang_ibrowser_reset'] = '重新設定尺寸';
tinyMCELang['lang_ibrowser_border'] = 'Border';
tinyMCELang['lang_ibrowser_hspace'] = 'HSpace';
tinyMCELang['lang_ibrowser_vspace'] = 'VSpace';
tinyMCELang['lang_ibrowser_select'] = '儲存';
tinyMCELang['lang_ibrowser_delete'] = '刪除';
tinyMCELang['lang_ibrowser_cancel'] = '取消';
tinyMCELang['lang_ibrowser_uploadtxt'] = '檔案';
tinyMCELang['lang_ibrowser_uploadbt'] = '上傳';
// error messages
tinyMCELang['lang_ibrowser_error'] = '發生錯誤';
tinyMCELang['lang_ibrowser_errornoimg'] = '請選擇圖片';
tinyMCELang['lang_ibrowser_errornodir'] = '圖庫並不存在';
tinyMCELang['lang_ibrowser_errorupload'] = '處理檔案上傳時發生錯誤.\n請稍後嘗試';
tinyMCELang['lang_ibrowser_errortype'] = '圖片檔案格式錯誤';
tinyMCELang['lang_ibrowser_errordelete'] = '刪除失敗';
tinyMCELang['lang_ibrowser_confirmdelete'] = '點選刪除圖片!';
tinyMCELang['lang_ibrowser_error_width_nan'] = '寬度不是一個數字!';
tinyMCELang['lang_ibrowser_error_height_nan'] = '高度不是一個數字!';
tinyMCELang['lang_ibrowser_error_border_nan'] = 'Border不是一個數字!';
tinyMCELang['lang_ibrowser_error_hspace_nan'] = 'Horizontal space不是一個數字!';
tinyMCELang['lang_ibrowser_error_vspace_nan'] = 'Vertical space不是一個數字!';	