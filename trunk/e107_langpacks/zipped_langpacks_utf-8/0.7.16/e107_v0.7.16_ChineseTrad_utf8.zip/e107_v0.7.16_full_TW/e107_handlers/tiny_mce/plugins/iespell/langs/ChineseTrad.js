// UK lang variables

tinyMCE.addToLang('',{
iespell_desc : '執行拼字檢查',
iespell_download : "無 ieSpell 拼字檢查功能。點按「確定」後下載安裝."
});

