<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_userclass.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "每個人 (公開)");
define("UC_LAN_1", "訪客");
define("UC_LAN_2", "沒有人(尚未啟動)");
define("UC_LAN_3", "會員");
define("UC_LAN_4", "僅供閱讀");
define("UC_LAN_5", "管理員");
define("UC_LAN_6", "站長");
?>