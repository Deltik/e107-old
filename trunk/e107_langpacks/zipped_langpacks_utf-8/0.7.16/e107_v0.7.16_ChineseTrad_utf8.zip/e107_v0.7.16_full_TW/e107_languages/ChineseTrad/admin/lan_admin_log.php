<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "管理紀錄");
define("LAN_ADMINLOG_1", "日期");
define("LAN_ADMINLOG_2", "標題");
define("LAN_ADMINLOG_3", "描述");
define("LAN_ADMINLOG_4", "會員 IP");
define("LAN_ADMINLOG_5", "會員 ID");
define("LAN_ADMINLOG_6", "有益的圖標");
define("LAN_ADMINLOG_7", "有益的訊息");
define("LAN_ADMINLOG_8", "注意圖標");
define("LAN_ADMINLOG_9", "注意訊息");
define("LAN_ADMINLOG_10", "警告圖標");
define("LAN_ADMINLOG_11", "警告訊息");
define("LAN_ADMINLOG_12", "毀滅性的圖標");
define("LAN_ADMINLOG_13", "毀滅性的訊息");

?>