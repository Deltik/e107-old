<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_submitnews.php,v $
|     $Revision: 1.5 $
|     $Date: 2009/09/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "新聞提供");
define("LAN_7", "登入名稱: ");
define("LAN_62", "主題: ");
define("LAN_112", "電子信箱: ");
define("LAN_133", "感謝您");
define("LAN_134", "已經收到您提供的資料，管理員將會儘快處理.");
define("LAN_135", "新聞項目: ");
define("LAN_136", "提供新聞項目");
define("NWSLAN_6", "分區");
define("NWSLAN_10", "目前沒有新聞分區");
define("NWSLAN_11", "您無法進入此區域.");
define("NWSLAN_12", "禁止進入.");

define("SUBNEWSLAN_1", "您必須輸入標題.\\n");
define("SUBNEWSLAN_2", "您必須輸入文字於內容中.\\n");
define("SUBNEWSLAN_3", "您的附加檔案必須為jpg, gif 或 png 檔案格式");
define("SUBNEWSLAN_4", "檔案太大");
define("SUBNEWSLAN_5", "圖片檔案");
define("SUBNEWSLAN_6", "(jpg, gif 或 png)");
define('SUBNEWSLAN_7', '您必須提供您的登入名稱和電子信箱');
define('SUBNEWSLAN_8', '上傳圖片時發生錯誤');


?>