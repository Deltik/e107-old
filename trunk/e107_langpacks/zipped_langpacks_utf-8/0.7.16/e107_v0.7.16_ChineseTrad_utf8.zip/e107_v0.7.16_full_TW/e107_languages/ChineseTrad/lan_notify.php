<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "會員註冊");

define("NT_LAN_UV_1", "完成認證會員");
define("NT_LAN_UV_2", "會員ID: ");
define("NT_LAN_UV_3", "會員登入名稱: ");
define("NT_LAN_UV_4", "會員 IP: ");

define("NT_LAN_LI_1", "登入完成");

define("NT_LAN_LO_1", "登出完成");
define("NT_LAN_LO_2", "登出網站");

define("NT_LAN_FL_1", "連續發表封鎖");
define("NT_LAN_FL_2", "IP 封鎖於連續發表");

define("NT_LAN_SN_1", "完成送出新聞項目");

define("NT_LAN_NU_1", "更新完成");

define("NT_LAN_ND_1", "刪除新聞完成");
define("NT_LAN_ND_2", "完成刪除新聞 id");

?>