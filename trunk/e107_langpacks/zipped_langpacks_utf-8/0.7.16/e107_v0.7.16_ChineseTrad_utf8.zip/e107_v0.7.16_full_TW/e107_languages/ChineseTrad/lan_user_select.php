<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "選擇會員");
define("US_LAN_2", "選擇會員等級");
define("US_LAN_3", "所有會員");
define("US_LAN_4", "尋找會員");
define("US_LAN_5", "找到會員");
define("US_LAN_6", "搜尋");
?>