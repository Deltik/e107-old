<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "維護設定完成更新");
define("UGFLAN_2", "啟動維護暫停公告");
define("UGFLAN_3", "更新維護設定");
define("UGFLAN_4", "維護設定");

define("UGFLAN_5", "顯示網站維護原因");
define("UGFLAN_6", "保留空白則顯示預設的訊息");

?>