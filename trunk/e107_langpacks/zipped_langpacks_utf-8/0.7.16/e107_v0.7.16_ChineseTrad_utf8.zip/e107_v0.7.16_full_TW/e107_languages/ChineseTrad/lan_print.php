<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_print.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "友善列印"); }

define("LAN_PRINT_86", "分區:");
define("LAN_PRINT_87", "於");
define("LAN_PRINT_94", "發表於");
define("LAN_PRINT_135", "新聞項目: ");
define("LAN_PRINT_303", "該新聞項目來自於 ");
define("LAN_PRINT_304", "標題: ");
define("LAN_PRINT_305", "子標題: ");
define("LAN_PRINT_306", "來自於: ");
define("LAN_PRINT_307", "列印該頁面");

define("LAN_PRINT_1", "友善列印");

?>