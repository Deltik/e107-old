<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "首頁設定更新完成.");
define("FRTLAN_2", "設定首頁連結");
define("FRTLAN_6", "連結");
// define("FRTLAN_7", "內容頁面");
define("FRTLAN_12", "更新首頁設定設定");
define("FRTLAN_13", "首頁設定");
define("FRTLAN_15", "其他 (輸入連結):");
define("FRTLAN_16", "錯誤: 已選擇的上一層沒有內容");
define("FRTLAN_17", "錯誤: 已選擇的子分區沒有內容");
define("FRTLAN_18", "錯誤: 已選擇的項目沒有內容");
define("FRTLAN_19", "上一層主要的內容");
define("FRTLAN_20", "內容分區");
define("FRTLAN_21", "內容項目");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "所有的會員");
define("FRTLAN_27", "訪客");
define("FRTLAN_28", "會員");
define("FRTLAN_29", "管理員");
define("FRTLAN_31", "所有的會員");
define("FRTLAN_32", "會員權限");
define("FRTLAN_33", "目前設定");
define("FRTLAN_34", "頁面");

?>