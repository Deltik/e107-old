<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     咎teve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/help/filemanager.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "您可以管理 /files 目錄檔案. 假如有錯誤訊息是有關於權限， 請上傳時變更 CHMOD 該目錄於 777.";
$ns -> tablerender("檔案管理說明", $text);
?>