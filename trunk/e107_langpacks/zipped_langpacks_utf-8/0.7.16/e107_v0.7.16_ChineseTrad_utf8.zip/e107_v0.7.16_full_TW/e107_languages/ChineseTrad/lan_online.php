<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "訪客: ");
define("ONLINE_EL2", "會員: ");
define("ONLINE_EL3", "目前頁面: ");
define("ONLINE_EL4", "線上");
define("ONLINE_EL5", "會員");
define("ONLINE_EL6", "最新註冊會員");
define("ONLINE_EL7", "瀏覽中");
define("ONLINE_EL8", "最多線上會員人數: ");
define("ONLINE_EL9", "於");
define("ONLINE_EL10", "會員名稱");
define("ONLINE_EL11", "瀏覽頁面");
define("ONLINE_EL12", "回覆於");
define("ONLINE_EL13", "版面");
define("ONLINE_EL14", "主題");
define("ONLINE_EL15", "頁面");
define("CLASSRESTRICTED", "私人保護頁面");
define("ARTICLEPAGE", "文章/回顧");
define("CHAT", "聊天");
define("COMMENT", "評論");
define("DOWNLOAD", "下載");
define("EMAIL", "email.php");
define("FORUM", "討論區首頁");
define("LINKS", "連結");
define("NEWS", "新聞");
define("OLDPOLLS", "舊的投票");
define("POLLCOMMENT", "投票");
define("PRINTPAGE", "列印");
define("LOGIN", "登入中");
define("SEARCH", "搜尋中");
define("STATS", "網站統計");
define("SUBMITNEWS", "提供新聞");
define("UPLOAD", "上傳");
define("USERPAGE", "個人資訊");
define("USERSETTINGS", "個人設定");
define("ONLINE", "觀看線上會員");
define("LISTNEW", "列出新聞清單");
define("USERPOSTS", "會員發表");
define("SUBCONTENT", "送出 文章回顧");
define("TOP", "最多發表和最多人回覆主題");
define("ADMINAREA", "管理控制台");
define("BUGTRACKER", "錯誤追蹤");
define("EVENT", "事件清單");
define("CALENDAR", "事件行事曆");
define("FAQ", "常見問題");
define("PM", "私人訊息");
define("SURVEY", "投票");
define("ARTICLE", "文章");
define("CONTENT", "內容頁面");
define("REVIEW", "回顧");

?>