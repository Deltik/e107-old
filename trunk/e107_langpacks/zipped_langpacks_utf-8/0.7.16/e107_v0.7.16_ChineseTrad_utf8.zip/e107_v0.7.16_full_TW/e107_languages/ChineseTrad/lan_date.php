<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_date.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "年");
define("LANDT_02", "月");
define("LANDT_03", "週");
define("LANDT_04", "日");
define("LANDT_05", "小時");
define("LANDT_06", "分鐘");
define("LANDT_07", "秒");
define("LANDT_01s", "年");
define("LANDT_02s", "月");
define("LANDT_03s", "週");
define("LANDT_04s", "日");
define("LANDT_05s", "小時");
define("LANDT_06s", "分鐘");
define("LANDT_07s", "秒");

define("LANDT_08", "分鐘");
define("LANDT_08s", "分鐘");
define("LANDT_09", "秒");
define("LANDT_09s", "秒");
define("LANDT_AGO", "之前");


?>