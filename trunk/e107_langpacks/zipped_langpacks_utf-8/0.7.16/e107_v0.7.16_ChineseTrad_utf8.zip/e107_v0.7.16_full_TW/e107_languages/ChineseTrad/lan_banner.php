<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_banner.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "播放廣告設定");

define("BANNERLAN_16", "會員名稱: ");
define("BANNERLAN_17", "密碼: ");
define("BANNERLAN_18", "繼續");
define("BANNERLAN_19", "請輸入您的客戶帳號與密碼");
define("BANNERLAN_20", "抱歉, 沒有發現相對應的資料. 請聯絡管理員.");
define("BANNERLAN_21", "廣告欄位統計");
define("BANNERLAN_22", "客戶");
define("BANNERLAN_23", "廣告 ID");
define("BANNERLAN_24", "點選經過");
define("BANNERLAN_25", "點選 %");
define("BANNERLAN_26", "次數");
define("BANNERLAN_27", "購買的次數");
define("BANNERLAN_28", "剩餘次數");
define("BANNERLAN_29", "沒有廣告欄位");
define("BANNERLAN_30", "沒有限制");
define("BANNERLAN_31", "沒有適合的");
define("BANNERLAN_32", "是");
define("BANNERLAN_33", "否");
define("BANNERLAN_34", "結束於:");
define("BANNERLAN_35", "點選經過 IP 位址");
define("BANNERLAN_36", "啟動:");
define("BANNERLAN_37", "開始於:");
define("BANNERLAN_38", "錯誤");

?>