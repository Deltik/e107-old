<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_mail_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "由 e107 網站系統提供");
define("LANMAILH_2", "此格式為多元訊息（ MIME 格式）.");
define("LANMAILH_3", "不是正確的格式");
define("LANMAILH_4", "伺服器拒絕此網址");
define("LANMAILH_5", "伺服器沒有回應");
define("LANMAILH_6", "無法找到此 E-Mail 伺服器.");
define("LANMAILH_7", "為有效的.");


?>