<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_admin.php,v $
|     $Revision: 1.60 $
|     $Date: 2008/06/29 15:23:37 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("ADLAN_0", "新聞管理");
define("ADLAN_1", "新增/編輯/刪除新聞或是日誌");
//define("ADLAN_2", "新聞分區");
//define("ADLAN_3", "新增/編輯/刪除新聞分區");
define("ADLAN_4", "基本設定");
define("ADLAN_5", "編輯網站的基本設定");
define("ADLAN_6", "選單管理");
define("ADLAN_7", "新增修改選單順序");
define("ADLAN_8", "管理員管理");
define("ADLAN_9", "新增/刪除網站管理員");
define("ADLAN_10", "密碼變更");
define("ADLAN_11", "變更您的管理員密碼");
//define("ADLAN_12", "版面");
//define("ADLAN_13", "新增/編輯版面");
//define("ADLAN_14", "文章");
//define("ADLAN_15", "新增/編輯/刪除文章");
//define("ADLAN_16", "內容");
//define("ADLAN_17", "新增/編輯/刪除內容頁面");
//define("ADLAN_18", "評論");
//define("ADLAN_19", "新增/編輯/刪除評論");
//define("ADLAN_22", "連結分區");
//define("ADLAN_23", "新增/編輯/刪除連結分區");
define("ADLAN_24", "檔案下載");
define("ADLAN_25", "管理/新增檔案給會員或是非會員下載");
//define("ADLAN_26", "下載分區");
//define("ADLAN_27", "新增新的/編輯/刪除下載分區");
define("ADLAN_28", "歡迎訊息");
define("ADLAN_29", "設定基本的歡迎訊息");
define("ADLAN_30", "檔案總管");
define("ADLAN_31", "管理/上傳檔案");
//define("ADLAN_32", "提供的新聞");
//define("ADLAN_33", "檢查會員提供的新聞項目");
define("ADLAN_34", "會員黑名單");
define("ADLAN_35", "封鎖訪客或是特定IP");
define("ADLAN_36", "會員資料管理");
define("ADLAN_37", "編輯網站會員");
define("ADLAN_38", "會員權限管理");
define("ADLAN_39", "新增/編輯會員等級");
define("ADLAN_40", "維護公告");
define("ADLAN_41", "網站維護公告設定");
define("ADLAN_42", "自訂選單/頁面");
define("ADLAN_43", "自訂選單項目或是獨立頁面");
define("ADLAN_44", "資料庫管理");
define("ADLAN_45", "資料庫線上輔助管理工具");
define("ADLAN_46", "登出離開");
define("ADLAN_47", "歡迎");
define("ADLAN_48", "登入完成");
define("ADLAN_49", "超級網站管理員");
//define("ADLAN_50", "權限");
define("ADLAN_51", "請登入管理控制台");
define("ADLAN_52", "管理控制台首頁");
define("ADLAN_53", "離開管理控制台");
define("ADLAN_54", "廣告管理");
define("ADLAN_55", "廣告欄位設定");
//define("ADLAN_56", "聊天室");
//define("ADLAN_57", "聊天室設定");
define("ADLAN_58", "表情圖案");
define("ADLAN_59", "表情圖案設定");
define("ADLAN_60", "首頁設定");
define("ADLAN_61", "可以指定首頁");
//define("ADLAN_62", "提供新聞");
//define("ADLAN_63", "設定提供新聞");
//define("ADLAN_64", "登入統計");
//define("ADLAN_65", "登入統計/計數器等");
define("ADLAN_66", "關鍵字/標籤");
define("ADLAN_67", "新增/編輯（Meta）");
define("ADLAN_68", "PHP 資訊");
define("ADLAN_69", "PHP資訊頁面");
//define("ADLAN_70", "問卷");
//define("ADLAN_71", "新增/編輯問卷");
define("ADLAN_72", "檔案上傳");
define("ADLAN_73", "設定公開上傳");
define("ADLAN_74", "快取管理");
define("ADLAN_75", "設定快取狀態");
//define("ADLAN_77", "您的新聞項目已經送出- 請點選這裡確認.");
define("ADLAN_78", "會員欄位管理");
define("ADLAN_79", "編輯延伸會員欄位");


//define("ADLAN_86", "錯誤的密碼 ");
//define("ADLAN_87", "管理員名稱不存在資料庫 ");
//define("ADLAN_88", "無法登入 ");
define("ADLAN_89", "管理員名稱 ");
define("ADLAN_90", "管理員密碼 ");
define("ADLAN_91", "登入");
define("ADLAN_92", "登入管理員介面中 ...");
define("ADLAN_93", "顯示管理選項");
//define("ADLAN_94", "顯示已安裝外掛");
define("ADLAN_95", "外掛管理");
//define("ADLAN_96", "沒有");
//define("ADLAN_97", "瀏覽常見問題");
define("ADLAN_98", "外掛管理");
define("ADLAN_99", "安裝/更新外掛");
//define("ADLAN_100", "風格外觀");
//define("ADLAN_101", "模板製作");
define("ADLAN_102", "你超過三十天未更新超級管理員密碼");
define("ADLAN_103", "點選這裡變更密碼");
define("ADLAN_104", "安全設定");

define("ADLAN_105", "圖片設定");
define("ADLAN_106", "圖片顯示設定");

//define("ADLAN_107", "尚未確認會員提供的新聞項目");
//define("ADLAN_108", "尚未確認檔案上傳");
//define("ADLAN_109", "資訊");
define("ADLAN_110", "註冊會員數");
define("ADLAN_111", "未啟動會員數");
define("ADLAN_112", "封鎖會員數");
define("ADLAN_113", "最新文章數");
define("ADLAN_114", "會員評論數");
define("ADLAN_115", "聊天室文章數");
define("ADLAN_116", "管理員紀錄 ...");
define("ADLAN_117", "顯示所有登入操作");
define("ADLAN_118", "清除紀錄");

define("ADLAN_119", "尚未確認會員提供的連結");

define("ADLAN_120", "資料庫更新成功,請點選安裝 ...");
define("ADLAN_121", "安裝");


//define("ADLAN_123", "尚未確認的會員提供的文章");
//define("ADLAN_124", "尚未確認的會員提供的回顧");

//define("ADLAN_125", "尚未確認問題文章");

//define("ADLAN_126", "重要選項");
//define("ADLAN_127", "會員");
//define("ADLAN_128", "內容");
//define("ADLAN_129", "通訊");
//define("ADLAN_130", "檔案管理");
//define("ADLAN_131", "其他工具");

define("ADLAN_132", "語系管理");
define("ADLAN_133", "初始設定");

define("ADLAN_134", "統計資訊");
define("ADLAN_135", "管理員登入紀錄");

define("ADLAN_136", "E-Mail通知會員");
define("ADLAN_137", "電子郵件設定和外部信箱設定");

define("ADLAN_138", "網站連結");
define("ADLAN_139", "新增/編輯/刪除連結");

define("ADLAN_140", "風格管理");
define("ADLAN_141", "安裝/設定風格等");

define("ADLAN_142", "搜尋管理");
define("ADLAN_143", "搜尋設定");
define("ADLAN_144", "您現在位於簡單模式,請切換到進階模式");
define("ADLAN_145", "點選這裡");

define("ADLAN_146", "登入失敗紀錄");
define("ADLAN_147", "檔案檢查");
define("ADLAN_148", "瀏覽網站檔案");

define("ADLAN_149", "提醒信件");
define("ADLAN_150", "寄信給管理員提醒網站狀態");

define("ADLAN_151", "管理首頁");
define("ADLAN_152", "輸入編碼");

define("ADLAN_153", "管理控制台");
define('ADLAN_154', "確認新版本時,與 Sourceforge 連線發生錯誤");
define('ADLAN_CL_1', '網站設定');
define('ADLAN_CL_2', '會員管理');
define('ADLAN_CL_3', '內容管理');
define('ADLAN_CL_4', '評論管理');
define('ADLAN_CL_5', '檔案管理');
define('ADLAN_CL_6', '維護工具');
define('ADLAN_CL_7', '外掛列表');
define('ADLAN_CL_8', '說明文件');

define("ADLAN_LAT_1", "最新狀況");

define("ADLAN_LAT_2", "會員提供新聞");
//define("ADLAN_LAT_3", "會員提供的文章");
//define("ADLAN_LAT_4", "會員提供的回顧");
define("ADLAN_LAT_5", "會員提供連結");
define("ADLAN_LAT_6", "回報的文章");
define("ADLAN_LAT_7", "上傳的檔案");
define("ADLAN_LAT_8", "未處理的通知訊息");

//define("ADLAN_ERR_1", "警告!");
define("ADLAN_ERR_2", "你伺服器上的檔案室很容易被其他人入侵寫入.  <b>請趕快移除</b>. 這些檔案室關於舊的0.6xx版本. 請刪除下列目錄和所有內容:");
define("ADLAN_ERR_3", "目前有一個或是多個檔案在您的公開上傳目錄，這不是e107預先設定需要的. 這些將會造成駭客攻擊請儘速 <b>移除</b>. 請<b>不要開啟</b> 這些檔案可能會內藏惡意的程式碼. 請不要用您的瀏覽器開啟.<br /><br />如果您知道這些檔案為合法的, 並且很像最近允許變更的檔案類型, 該檔案您該允許存在不久所以建議您重新新增他(請到管理台 =>上傳). 建議不要允許上傳 .html, .txt, 等等，很容易造成駭客利用此檔案置入惡意的javascript. 當然也不要允許php檔案.<br /><br />下列檔案可能容易植入惡意程式碼的危險:");
define("ADLAN_ERR_4", "找到非必要的外掛檔案");
define("ADLAN_ERR_5", "下列檔案必須重新命名");
define("ADLAN_ERR_6", "然後, 點選這裡重新掃描您的外掛資料夾.");

// Common Terms
define("LAN_EDIT","編輯");
define("LAN_DELETE","刪除");
define("LAN_CREATE","新增");
define("LAN_UPDATE","更新");
define("LAN_SAVE","儲存");
define("LAN_SAVED","完成儲存");
define("LAN_SETSAVED","您的設定已被儲存的");
define("LAN_CONFIRMDEL","請確認後刪除");
define("LAN_OPTIONS","選項設定");
define("LAN_PREFS","基本設定");
define("LAN_DELETED","已成功刪除");
define("LAN_UPDATED","已成功更新");
define("LAN_CREATED","已成功新增");
define("LAN_CREATED_FAILED","新增失敗");
define("LAN_DELETED_FAILED","刪除失敗");
define("LAN_UPDATED_FAILED","更新失敗");
define("LAN_NO_CHANGE","更新失敗無任何變更.");
define("LAN_TRY_AGAIN","請再次嘗試.");

define("LAN_RESET","清除重設");
define("LAN_CLEAR","清除");
define("LAN_OK","可以");

define("LAN_PRESET","初始設定");
define("LAN_PRESET_SAVED","初始設定已成功儲存");

define("LAN_PRESET_DELETED","初始設定已刪除成功");
define("LAN_PRESET_CONFIRMDEL","您確定要刪除此初始設定?");
define("LAN_NOTWRITABLE"," 為不可寫入, 您必須 CHMOD 777 該資料夾權限.");
define("LAN_DATE","日期");
define("LAN_TIME","時間");
define("LAN_YES","是");
define("LAN_NO","否");
define("LAN_EMPTY","目前沒有任何目錄於資料庫");
define("LAN_EXISTING","已存在目錄");

define("LAN_CANCEL","取消");
define("LAN_CONFDELETE","確認刪除");
define("LAN_PLUGIN","外掛");
define("LAN_ORDER","排序");

define("LAN_SELECT","選擇 ...");
define("LAN_ADMIN","管理控制台");
define("LAN_DISPLAYOPT", "編輯顯示選項");
define("LAN_GOPAGE", "前往頁面:");
define("LAN_DATESTAMP","日期格式");
define("LAN_OPTIONAL", "選項");
define("LAN_INACTIVE","尚未啟動");

define("LAN_BAN","封鎖");
define("LAN_BAN","封鎖");
define("LAN_RATING", "評比中");

define("LAN_UPLOAD", "上傳");
define("LAN_UPLOAD_IMAGES","上傳圖片");
define("LAN_UPLOAD_FILES","上傳檔案");
define("LAN_UPLOAD_ADDFILE","另外新增檔案");
define("LAN_UPLOAD_CONFIRM","任何未儲存的變更將會遺失.確定繼續嗎?");
define("LAN_UPLOAD_777","資料夾遺失或是不可以寫入, 您必須 CHMOD 777 下列資料夾:");
define("LAN_UPLOAD_SERVEROFF", "您的伺服器不支援檔案上傳");

define("LAN_DISABLED","完成關閉");
define("LAN_ENABLED", "完成開啟");

define("LAN_PRESET_CONFIRMSAVE","儲存目前表格上的值給此頁面?");
define("LAN_CONFIGURE", "基本設定");

define("LAN_BACK","返回");

define("LAN_CREDITS","感謝人員");
define("LAN_NEWVERSION","目前有新的版本");
?>
