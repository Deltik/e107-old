<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_prefs.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107 Powered Website");
define("LAN_PREF_2", "e107 Website System");
define("LAN_PREF_3", "網站程式 <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>,遵循<a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL 條款.中文維護 <a href=&quot;http://phpbs.com/&quot; rel=&quot;external&quot;>PHP黑店</a>");
define("LAN_PREF_4", "審查完成");
define("LAN_PREF_5", "討論區");

?>