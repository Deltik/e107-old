<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "僅限於會員");

define("LAN_MEMBERS_0", "認證區域");
define("LAN_MEMBERS_1", "這是一個認證區域");
define("LAN_MEMBERS_2","僅接受會員 <a href=".e_LOGIN.">登入</a>");
define("LAN_MEMBERS_3","或 <a href='".e_SIGNUP."'>註冊</a>會員");
define("LAN_MEMBERS_4","點選返回首頁");

?>