<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_db.php,v $
|     $Revision: 1.8 $
|     $Date: 2009/02/14 21:17:42 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "核心設定備份於資料庫.");
define("DBLAN_2", "點選按鈕儲存備份於您的e107資料庫");
define("DBLAN_3", "備份SQL資料庫");
define("DBLAN_4", "點選按鈕確認e107資料庫的有效資料");
define("DBLAN_5", "確認資料庫有效性");
define("DBLAN_6", "點選按鈕進行e107資料庫優化");
define("DBLAN_7", "優化 SQL 資料庫");
define("DBLAN_8", "點選按鈕備份您的核心設定");
define("DBLAN_9", "備份核心設定");
define("DBLAN_10", "資料庫工具");
define("DBLAN_11", "MySQL資料庫");
define("DBLAN_12", "已優化");
define("DBLAN_13", "返回");
define("DBLAN_14", "執行");
define("DBLAN_15", "點選按鈕確認任何資料庫的更新");
define("DBLAN_16", "確認更新");
define("DBLAN_17", "Pref. 名稱");
define("DBLAN_18", "Pref. 值");
define("DBLAN_19", "點選按鈕開啟偏好設定編輯器 (僅限於特殊會員)");
define("DBLAN_20", "偏好設定編輯器");
define("DBLAN_21", "確認刪除");
define("DBLAN_22", "外掛: 瀏覽和掃描");
define("DBLAN_23", "掃描完畢");
define("DBLAN_24", "名稱");
define("DBLAN_25", "目錄");
define("DBLAN_26", "內含附加");
define("DBLAN_27", "已安裝");
define("DBLAN_28", "點選掃描外掛目是否變更");
define("DBLAN_29", "掃描外掛目錄");
define("DBLAN_30", " (如果發生錯誤, 請確認是否有額外的字元於 PHP 開啟和關閉的標籤中)");
define("DBLAN_31", "通過");
define("DBLAN_32", "錯誤");
define("DBLAN_33", "無法接受");
define("DBLAN_34", "尚未確認");
define('DBLAN_35', '按一下按鈕來檢查會員資料表的有效性');
define('DBLAN_36', '確認會員資料表');


?>