<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_e107_update.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "行動");
define("LAN_UPDATE_3", "尚未需要");

define("LAN_UPDATE_5", "有效的更新");
define("LAN_UPDATE_7", "已實施");
define("LAN_UPDATE_8", "更新於");
define("LAN_UPDATE_9", "到");
define("LAN_UPDATE_10", "有效的更新");
define("LAN_UPDATE_11", "繼續.617 到 .7 更新");
define("LAN_UPDATE_12", "您的資料表之一包含相同的項目.");

?>