<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "刪除新聞.");
define("NWSLAN_2", "刪除新聞請勾選確認盒.");
define("NWSLAN_3", "目前沒有新聞.");
define("NWSLAN_4", "現有的新聞");
define("NWSLAN_5", "開啟 HTML 編輯器");
define("NWSLAN_6", "分區");
define("NWSLAN_7", "編輯");
define("NWSLAN_8", "刪除");
define("NWSLAN_9", "勾選確認");
define("NWSLAN_10", "目前沒有分區.");
define("NWSLAN_11", "新增/編輯分區");
define("NWSLAN_12", "標題");
define("NWSLAN_13", "內容");
define("NWSLAN_14", "延伸資訊");
define("NWSLAN_15", "評論");
define("NWSLAN_16", "開啟");
define("NWSLAN_17", "關閉");
define("NWSLAN_18", "開啟新聞評論");
define("NWSLAN_19", "啟動狀態");
define("NWSLAN_20", "保留空白則將會關閉自動啟動");
define("NWSLAN_21", "啟動於");
define("NWSLAN_22", "瀏覽權限");
define("NWSLAN_23", "勾選可以瀏覽新聞項目會員等級");
define("NWSLAN_24", "再次預覽");
define("NWSLAN_25", "更新新聞");
define("NWSLAN_26", "發表新聞");
define("NWSLAN_27", "預覽");
define("NWSLAN_28", "新聞故事");
define("NWSLAN_29", "新聞發表");

define("NWSLAN_30", "僅顯示標題");

?>