<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "錯誤 - 請重新送出");
define("UDALAN_2", "設定完成更新");
define("UDALAN_3", "設定完成更新-");
define("UDALAN_4", "管理員名稱");
define("UDALAN_5", "管理員密碼");
define("UDALAN_6", "重新輸入密碼");
define("UDALAN_7", "變更密碼");
define("UDALAN_8", "密碼更新-");

?>