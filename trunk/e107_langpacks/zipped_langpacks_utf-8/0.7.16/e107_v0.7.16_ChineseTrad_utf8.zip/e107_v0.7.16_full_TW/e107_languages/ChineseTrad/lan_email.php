<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_email.php,v $
|     $Revision: 1.7 $
|     $Date: 2007/04/12 22:51:34 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }

define("LAN_EMAIL_1", "寄件人:");
define("LAN_EMAIL_2", "寄件人的IP:");
define("LAN_EMAIL_3", "寄來的內容來自於 ");
define("LAN_EMAIL_4", "寄出信件");
define("LAN_EMAIL_5", "寄給朋友");
define("LAN_EMAIL_6", "我想您可能這些內容有興趣");
define("LAN_EMAIL_7", "寄給某人");
define("LAN_EMAIL_8", "評論");
define("LAN_EMAIL_9", "很抱歉 - 無法寄出信件");
define("LAN_EMAIL_10", "郵件寄給");
define("LAN_EMAIL_11", "郵件寄出");
define("LAN_EMAIL_12", "錯誤");
define("LAN_EMAIL_13", "寄出文章");
define("LAN_EMAIL_14", "寄出新聞");
define("LAN_EMAIL_15", "登入名稱: ");
define("LAN_EMAIL_106", "此為無效的電子信箱");
define("LAN_EMAIL_185", "寄出文章");
define("LAN_EMAIL_186", "寄出新聞");
define("LAN_EMAIL_187", "收件人電子信箱");
define("LAN_EMAIL_188", "我想您可能有興趣知道該故事來自於");
define("LAN_EMAIL_189", "我想您可能有興趣知道該文章來自於");
define("LAN_EMAIL_190", "輸入認證碼");

?>