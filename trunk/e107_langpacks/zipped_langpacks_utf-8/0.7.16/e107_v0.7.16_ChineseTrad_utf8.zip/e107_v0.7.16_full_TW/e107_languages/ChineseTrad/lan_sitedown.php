<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_sitedown.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "網站暫時關閉");
define("LAN_SITEDOWN_00", "暫時關閉");
define("LAN_SITEDOWN_01", "我們暫時關閉網站做部份維修更新. 這不會花太多時間 - 請稍後回來確認, 很抱歉照成您的不便.");
?>