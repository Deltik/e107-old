<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_userinfo.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "無法找到發表人 IP 位址 - 目前沒有相關資訊.");
// define("USFLAN_2", "錯誤");
define("USFLAN_3", "訊息發表來自於 IP ");
define("USFLAN_4", "主機");
define("USFLAN_5", "點選這裡將 IP 位址轉到控制台封鎖頁面");
define("USFLAN_6", "會員ID");
define("USFLAN_7", "會員資訊");

?>