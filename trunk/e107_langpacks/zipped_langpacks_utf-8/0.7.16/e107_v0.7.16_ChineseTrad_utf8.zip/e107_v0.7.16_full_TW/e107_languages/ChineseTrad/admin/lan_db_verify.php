<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_db_verify.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/05/29 18:53:04 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "無法讀取sql的資料檔案<br /><br />請確認檔案 <b>core_sql.php</b> 存在於 <b>/admin/sql</b> 目錄中.");
define("DBLAN_2", "檢查全部");

define("DBLAN_4", "資料表");
define("DBLAN_5", "欄位");
define("DBLAN_6", "狀態");
define("DBLAN_7", "備註");
define("DBLAN_8", "未吻合");
define("DBLAN_9", "目前");
define("DBLAN_10", "應該有");
define("DBLAN_11", "欄位遺失");
define("DBLAN_12", "多餘的欄位!");
define("DBLAN_13", "資料表遺失!");
define("DBLAN_14", "選擇資料表驗證檢查");
define("DBLAN_15", "開始檢查");
define("DBLAN_16", "SQL檢查");
define("DBLAN_17", "返回");
define("DBLAN_18", "資料表");
define("DBLAN_19", "試圖修正");
define("DBLAN_20", "試圖修正資料表");
define("DBLAN_21", "修正已選擇的項目");
define("DBLAN_22", " 權限無法讀取");
?>