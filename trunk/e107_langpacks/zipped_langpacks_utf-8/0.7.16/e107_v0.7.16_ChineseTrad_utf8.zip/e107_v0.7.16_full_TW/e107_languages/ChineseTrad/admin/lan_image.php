<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_image.php,v $
|     $Revision: 1.8 $
|     $Date: 2008/12/04 22:29:14 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("IMALAN_1", "開啟圖片顯示");
define("IMALAN_2", "會員發表圖片顯示, 他將會採用網站寬度 (適用範圍新聞,評論,...等等)");
define("IMALAN_3", "變更圖片大小模式");
define("IMALAN_4", "可以採用 GD1/2 library, 或 ImageMagick功能來進行圖片大小調整");
define("IMALAN_5", "ImageMagick路徑");
define("IMALAN_6", "ImageMagick 轉換的系統路徑[如有選擇,請填寫]");
define("IMALAN_7", "圖片顯示設定");
define("IMALAN_8", "更新設定");
define("IMALAN_9", "顯示設定更新完成");
define("IMALAN_10", "發佈圖片權限");
define("IMALAN_11", "可以設定發表圖片的會員權限");
define("IMALAN_12", "關閉圖片顯示");
define("IMALAN_13", "當圖片已經發佈,但是系統管理員關閉圖片顯示,所顯示的訊息");
define("IMALAN_14", "開啟顯示圖片");
define("IMALAN_15", "關閉顯示");
define("IMALAN_16", "顯示上傳頭像");
define("IMALAN_17", "點選這裡");
define("IMALAN_18", "完成上傳圖片");
define("IMALAN_19", "顯示 '圖片功能關閉'字樣");

define("IMALAN_21", "使用於");
define("IMALAN_22", "圖片沒有使用");
define("IMALAN_23", "頭像");
define("IMALAN_24", "相片");
define("IMALAN_25", "點選這裡刪除所有未使用的圖片");
define("IMALAN_26", "圖片已刪除");

define("IMALAN_28", "已刪除");
define("IMALAN_29", "沒有圖片");
define("IMALAN_30", "每個人 (公開)");
define("IMALAN_31", "僅限於訪客");
define("IMALAN_32", "僅限於會員");
define("IMALAN_33", "僅限於管理員");
define("IMALAN_34", "開啟特殊功能");
define("IMALAN_35", "修正可穿透性 PNG-24'於最初的幻燈片，執行於 IE 5 / 6 (採用於網站全部)");

define("IMALAN_36", "檢查頭像圖片大小");
define("IMALAN_37", "頭像檢查");
define("IMALAN_38", "允許的最大寬度");
define("IMALAN_39", "允許的最大高度");
define("IMALAN_40", "太寬");
define("IMALAN_41", "太高");
define("IMALAN_42", "沒有找到");
define("IMALAN_43", "刪除已經上傳的頭像檔案");
define("IMALAN_44", "刪除外部連結圖片檔案");
define("IMALAN_45", "沒有找到");
define("IMALAN_46", "太大");
define("IMALAN_47", "全部上傳頭像圖片");
define("IMALAN_48", "全部的外部連結頭像圖片");
define("IMALAN_49", "會員使用頭像圖片");
define("IMALAN_50", "全部");
define("IMALAN_51", "頭像");
define("IMALAN_52", "ImageMagick 路徑錯誤");
define("IMALAN_53", "ImageMagick 路徑錯誤, 轉換過的檔案不一定為有效的");
define("IMALAN_54", "安裝的 GD 版本:");
define('IMALAN_55', '尚未安裝');
?>