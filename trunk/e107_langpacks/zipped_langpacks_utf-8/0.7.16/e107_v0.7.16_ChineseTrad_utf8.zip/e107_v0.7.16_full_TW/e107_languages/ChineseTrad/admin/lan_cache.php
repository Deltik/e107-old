<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "快取系統狀態");
define("CACLAN_2", "設定快取狀態");
define("CACLAN_3", "快取系統");
define("CACLAN_4", "快取狀態設定");
define("CACLAN_5", "清空快取");
define("CACLAN_6", "快取已清空");

define("CACLAN_7", "取消快取");
// define("CACLAN_8", "快取資料儲存於 MySQL資料庫");
define("CACLAN_9", "快取資料已儲存於磁碟檔案");
define("CACLAN_10", "該 cache目錄無法寫入. 請確認該目錄設定為 CHMOD 0777");
?>