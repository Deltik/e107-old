<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "已接收的訊息");
define("MESSLAN_2", "刪除訊息");
define("MESSLAN_3", "已刪除的訊息.");
define("MESSLAN_4", "刪除所有的訊息");
define("MESSLAN_5", "確認");
define("MESSLAN_6", "所有的訊息已刪除.");
define("MESSLAN_7", "沒有訊息.");
define("MESSLAN_8", "訊息類型");
define("MESSLAN_9", "回報於");

define("MESSLAN_10", "已送出的");
define("MESSLAN_11", "開啟於新的視窗");
define("MESSLAN_12", "訊息");
define("MESSLAN_13", "連結");


?>