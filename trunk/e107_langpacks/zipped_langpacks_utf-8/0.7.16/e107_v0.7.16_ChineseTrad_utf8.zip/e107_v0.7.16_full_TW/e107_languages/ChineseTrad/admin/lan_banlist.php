<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_banlist.php,v $
|     $Revision: 1.9 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "完成移除封鎖設定.");
define("BANLAN_2", "目前沒有封鎖.");
define("BANLAN_3", "目前被封鎖");
define("BANLAN_4", "移除封鎖");
define("BANLAN_5", "輸入 IP, email, 或主機");
define("BANLAN_7", "理由");
define("BANLAN_8", "IP封鎖");
define("BANLAN_9", "封鎖網站中的會員");
define("BANLAN_10", "IP / 電子信箱 / 理由");
define("BANLAN_11", "自動封鎖: 登入失敗過十次");
define("BANLAN_12", "注意: 撤銷 DNS 目前已經關閉, 他必須於主機上開啟允許封鎖.  封鎖 IP 和 email 的方式一樣正常.");
define("BANLAN_13", "注意: 如想要使用會員名稱封鎖會員, 請到管理控制台: ");
define('BANLAN_78','點擊量過高 (--HITS-- 在一定時間內的點擊量)');

?>