<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "會員發表");

define("UP_LAN_0", "所有討論區發表 ");
define("UP_LAN_1", "所有評論 ");
define("UP_LAN_2", "主題");
define("UP_LAN_3", "瀏覽");
define("UP_LAN_4", "回覆");
define("UP_LAN_5", "最後發表");
define("UP_LAN_6", "主題");
define("UP_LAN_7", "沒有評論");
define("UP_LAN_8", "沒有文章");
define("UP_LAN_9", " 在 ");
define("UP_LAN_10", "回覆");
define("UP_LAN_11", "發表於: ");
define("UP_LAN_12", "搜尋");
define("UP_LAN_13", "評論");
define("UP_LAN_14", "討論區文章");
define("UP_LAN_15", "回覆");
define("UP_LAN_16", "IP 位址");
?>