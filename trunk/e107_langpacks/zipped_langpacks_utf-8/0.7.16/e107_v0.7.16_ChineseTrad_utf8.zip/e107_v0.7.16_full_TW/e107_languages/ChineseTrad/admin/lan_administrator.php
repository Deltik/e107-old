<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_administator.php,v $
|     $Revision: 1.17 $
|     $Date: 2009/09/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_0", "新增會員/管理員登入並新增於");
define("ADMSLAN_1", "目前於管理模式.");
define("ADMSLAN_2", "已更新於資料庫.");
define("ADMSLAN_3", "一定要主要的網站管理員否則不能編輯.");
define("ADMSLAN_4", "繼續");
define("ADMSLAN_5", "發生錯誤!");
define("ADMSLAN_6", "一定要主要的網站管理員否則不能編輯.");

define("ADMSLAN_13", "現存管理員");


define("ADMSLAN_16", "管理員名稱");
define("ADMSLAN_17", "管理員密碼");
define("ADMSLAN_18", "權限");
define("ADMSLAN_19", "修改網站設定");
define("ADMSLAN_20", "修改選單");
define("ADMSLAN_21", "新增網站管理員");
define("ADMSLAN_22", "編輯會員資料或封鎖會員等等");
define("ADMSLAN_23", "新增/編輯自訂頁面/選單");
define("ADMSLAN_24", "管理下載分區");
define("ADMSLAN_25", "上傳管理檔案");
define("ADMSLAN_26", "檢查新聞分區");
define("ADMSLAN_27", "檢查連結分區");
define("ADMSLAN_28", "將網站設為維修模式");
define("ADMSLAN_29", "管理廣告欄位");
define("ADMSLAN_30", "設定頭條新聞提供");
define("ADMSLAN_31", "設定表情圖樣");
define("ADMSLAN_32", "設定首頁內容");
define("ADMSLAN_33", "設定登入統計狀態");
define("ADMSLAN_34", "設定 meta 標前");
define("ADMSLAN_35", "設定公開檔案上傳");
define("ADMSLAN_36", "設定圖片");
define("ADMSLAN_37", "管理修改評論");
// define("ADMSLAN_38", "Moderate/configure chatbox");
define("ADMSLAN_39", "發表新聞");
define("ADMSLAN_40", "發表連結");
//define("ADMSLAN_41", "發表文章");
//define("ADMSLAN_42", "發表回顧");
//define("ADMSLAN_43", "發表內容頁面");
define("ADMSLAN_44", "發表下載");
define("ADMSLAN_45", "發表投票");
define("ADMSLAN_46", "歡迎訊息");
define("ADMSLAN_47", "修改已送出新聞");

define("ADMSLAN_49", "選擇全部");
define("ADMSLAN_51", "全部取消");
define("ADMSLAN_52", "更新管理員");
define("ADMSLAN_53", "新增管理員");
define("ADMSLAN_54", "網站管理員");

define("ADMSLAN_55", "欄位留下空白");

define("ADMSLAN_56", "網站管理員");

define("ADMSLAN_58", "主要網站管理員");
define("ADMSLAN_59", "移除管理統計");
define("ADMSLAN_60", "您確定要移除管理統計");
define("ADMSLAN_61", "已刪除管理員");

define("ADMSLAN_62", "外掛管理");

define("ADMSLAN_64", "清除該網站快取");
define("ADMSLAN_65", "設定郵件和外部郵件");
define("ADMSLAN_66", "設定搜尋");
define("ADMSLAN_67", "使用檔案檢查");
define("ADMSLAN_68", "信件通知設定");
define("ADMSLAN_69", "已經是管理員而且已經被編輯.");

define("ADMSLAN_70", "回到管理選單");
define("ADMSLAN_71", "點選這裡顯示權限 ");  

?>