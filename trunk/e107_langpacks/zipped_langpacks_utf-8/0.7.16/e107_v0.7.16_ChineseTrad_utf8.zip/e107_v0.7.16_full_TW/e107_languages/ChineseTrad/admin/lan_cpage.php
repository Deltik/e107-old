<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "標題");
define("CUSLAN_2", "類型");
define("CUSLAN_3", "選項");
define("CUSLAN_4", "刪除該頁面?");
define("CUSLAN_5", "現有的頁面");
define("CUSLAN_7", "選單名稱");
define("CUSLAN_8", "抬頭/ 標題");
define("CUSLAN_9", "文字");
define("CUSLAN_10", "允許頁面被投票");
define("CUSLAN_11", "首頁");
define("CUSLAN_12", "新增頁面");
define("CUSLAN_13", "允許評論");
define("CUSLAN_14", "密碼保護頁面");
define("CUSLAN_15", "輸入密碼保護該頁面");
define("CUSLAN_16", "點選連結於主要的選單");
define("CUSLAN_17", "輸入連結名稱以便於新增");
define("CUSLAN_18", "頁面/連結可見權限");
define("CUSLAN_19", "更新頁面");
define("CUSLAN_20", "新增頁面");
define("CUSLAN_21", "更新選單");
define("CUSLAN_22", "新增選單");
define("CUSLAN_23", "編輯頁面");
define("CUSLAN_24", "新增新的頁面");
define("CUSLAN_25", "編輯選單");
define("CUSLAN_26", "新增新的選單");
define("CUSLAN_27", "頁面已儲存到資料庫.");
define("CUSLAN_28", "已刪除頁面");
define("CUSLAN_29", "假如沒有被選擇的顯示頁面");
define("CUSLAN_30", "過期的cookie (已秒計算)");
define("CUSLAN_31", "新增選單");
define("CUSLAN_32", "轉換舊的頁面/選單");
define("CUSLAN_33", "頁面選項");
define("CUSLAN_34", "開始轉換");
define("CUSLAN_35", "完成自訂頁面更新- 已更新");
define("CUSLAN_36", "設定每個頁面設定, 請會到首頁和編輯該頁面.");
define("CUSLAN_37", "自訂頁面更新");
define("CUSLAN_38", "開啟");
define("CUSLAN_39", "關閉");
define("CUSLAN_40", "儲存選項");

define("CUSLAN_41", "顯示作者跟日期資訊");
define("CUSLAN_42", "尚未有頁面定義出來");
define('CUSLAN_43', '沒有標題的選單: ');
define('CUSLAN_44', '沒有標題的頁面');
?>
