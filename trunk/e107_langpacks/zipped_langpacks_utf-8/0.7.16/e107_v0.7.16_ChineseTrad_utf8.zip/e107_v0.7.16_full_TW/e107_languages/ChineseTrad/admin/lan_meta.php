<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta標籤已更新於資料庫");
define("METLAN_2", "輸入附加的Meta標籤");
define("METLAN_3", "輸入新的Meta標籤設定");
define("METLAN_4", "已更新");
define("METLAN_5", "輸入您的網站描述");
define("METLAN_6", "輸入一個有關於您的關鍵字名單");
define("METLAN_7", "輸入您的版權資訊");
define("METLAN_8", "Meta標籤");

define("METLAN_9", "描述");
define("METLAN_10", "關鍵字");
define("METLAN_11", "版權");
define("METLAN_12", "在新聞頁面中使用新聞標題和概述於meta描述欄位.");
define("METLAN_13", "作者");

?>