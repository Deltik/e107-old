<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/08 12:57:27 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "討論區最多發表會員");
define("TOP_LAN_1", "會員名稱");
define("TOP_LAN_2", "發表數");
define("TOP_LAN_3", "最多評論會員");
define("TOP_LAN_4", "評論數");
define("TOP_LAN_5", "最會聊天會員");
define("TOP_LAN_6", "網站評比");

//v.616
define("LAN_1", "主題");
define("LAN_2", "發表會員");
define("LAN_3", "瀏覽");
define("LAN_4", "回覆");
define("LAN_5", "最新發表");
define("LAN_6", "主題");
define("LAN_7", "最熱門話題");
define("LAN_8", "最多發表會員");


?>