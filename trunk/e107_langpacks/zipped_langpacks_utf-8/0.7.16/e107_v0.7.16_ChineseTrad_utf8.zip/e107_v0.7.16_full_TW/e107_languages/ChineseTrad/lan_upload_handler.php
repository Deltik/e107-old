<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/ChineseTrad/lan_upload_handler.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/07/23 20:05:31 $
|     $Author: Hanklu-www.phpbs.com-正體中文製作$
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "檔案類型");
define("LANUPLOAD_2", "是不被允許將會被刪除.");
define("LANUPLOAD_3", "上傳成功");
define("LANUPLOAD_4", "相關的資料夾或是相關權限未不可寫入. (chmod 777)");
define("LANUPLOAD_5", "檔案大於php.ini的 upload_max_filesize 設定大小 .");
define("LANUPLOAD_6", "上傳檔案超過e MAX_FILE_SIZE 設定.");
define("LANUPLOAD_7", "完成上傳檔案僅有部份成功.");
define("LANUPLOAD_8", "沒有任何檔案已上傳.");
define("LANUPLOAD_9", "完成上傳檔案大小為 0 bytes");
define("LANUPLOAD_10", "上傳失敗 [Duplicate filename] - 檔案名稱已存在.");
define("LANUPLOAD_11", "檔案未上傳. 檔案名稱: ");
define("LANUPLOAD_12", "錯誤");
define("LANUPLOAD_13", "暫時的資料夾遺失");
define("LANUPLOAD_14", "寫入檔案失敗");
define("LANUPLOAD_15", "無法允許上傳");
define("LANUPLOAD_16", "未知的錯誤");
define("LANUPLOAD_17", "上傳檔案的檔案名稱無效");
define("LANUPLOAD_18", "檔案太大.");
define("LANUPLOAD_19", "太多檔案 - 完成刪除多餘檔案.");

?>