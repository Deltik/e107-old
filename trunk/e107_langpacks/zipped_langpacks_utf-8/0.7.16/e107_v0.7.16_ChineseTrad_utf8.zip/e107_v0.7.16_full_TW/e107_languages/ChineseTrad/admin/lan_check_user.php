<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_check_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/01/06 20:58:08 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

define('LAN_CKUSER_01','檢查會員資料庫');
define('LAN_CKUSER_02','這將會檢查您的會員資料看是否有問題在裡面');
define('LAN_CKUSER_03','假如您有很都會員,將會花較多時間甚至超時');
define('LAN_CKUSER_04','繼續');
define('LAN_CKUSER_05','檢查重複的登入名稱');
define('LAN_CKUSER_06','選擇功能來執行');
define('LAN_CKUSER_07','發現重複的會員名稱');
define('LAN_CKUSER_08','沒有找到重複的會員名稱');
define('LAN_CKUSER_09','會員名稱');
define('LAN_CKUSER_10','會員 ID');
define('LAN_CKUSER_11','顯示名稱');
define('LAN_CKUSER_12','檢查重複的電子信箱');
define('LAN_CKUSER_13','發現重複的電子信箱');
define('LAN_CKUSER_14','電子信箱');
define('LAN_CKUSER_15','沒有重複發現');
define('LAN_CKUSER_16','尋討比對，看其會員名稱是別人登入名稱');
define('LAN_CKUSER_17','衝突的會員名稱和登入名稱');
define('LAN_CKUSER_18','會員 A');
define('LAN_CKUSER_19','會員 B');
define('LAN_CKUSER_20','');

?>