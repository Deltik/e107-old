﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_mail_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LANMAILH_1", "Produit par le portail web e107");
  define("LANMAILH_2", "Ceci est un message multiple en format MIME.");
  define("LANMAILH_3", " n'est pas correctement formaté");
  define("LANMAILH_4", "Le serveur a rejeté l'adresse");
  define("LANMAILH_5", "Aucune réponse depuis le serveur");
  define("LANMAILH_6", "Ne peut pas trouver le serveur de Courrier électronique.");
  define("LANMAILH_7", " semble être valide.");
  ?>
