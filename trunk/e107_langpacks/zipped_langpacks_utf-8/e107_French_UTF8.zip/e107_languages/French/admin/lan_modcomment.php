<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("MDCLAN_1", "Modéré.");
  define("MDCLAN_2", "Aucun commentaire pour cette actualité");
  define("MDCLAN_3", "Membre");
  define("MDCLAN_4", "Invité");
  define("MDCLAN_5", "débloquer");
  define("MDCLAN_6", "bloquer");
  define("MDCLAN_8", "Modérer les commentaires");
  define("MDCLAN_9", "Attention ! La suppression d'une catégorie de commentaires, supprimera tous les commentaires !");
  define("MDCLAN_10", "option");
  define("MDCLAN_11", "commentaire");
  define("MDCLAN_12", "commentaires");
  define("MDCLAN_13", "Bloqué(s)");
  define("MDCLAN_14", "Activer les commentaires ");
  define("MDCLAN_15", "Oui");
  define("MDCLAN_16", "Non");
  //  define("MDCLAN_17", "");
  //  define("MDCLAN_18", "");
  //  define("MDCLAN_19", "");
  //  define("MDCLAN_20", "");
  ?>
