<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/userclass2.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $caption = "Aide Groupe utilisateur";
  $text = "Vous pouvez créer/éditer/supprimer des groupes à partir de cette page.<br />C'est utile pour restrindre les membres à certaines parties de votre site. Par exemple, vous pouvez créer un groupe appelé TEST, puis créer un forum qui n'autorise que les membres du groupe TEST à y accéder.";
  $ns -> tablerender($caption, $text);
  ?>
