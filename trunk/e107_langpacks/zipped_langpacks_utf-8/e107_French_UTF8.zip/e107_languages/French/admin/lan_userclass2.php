<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_userclass2.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("UCSLAN_1", "Ce groupe à été vidé des membres qu'il contient.");//modifié par juan
  define("UCSLAN_2", "Groupe d'utilisateurs Mis à jour.");//corrigé par Juan
  define("UCSLAN_3", "Groupe supprimé.");
  define("UCSLAN_4", "Veuillez cocher la case de confirmation pour supprimer ce groupe d'utilisateurs");
  define("UCSLAN_5", "Groupe Mis à jour.");
  define("UCSLAN_6", "Groupe sauvegardé dans la base de données.");
  define("UCSLAN_7", "Aucun groupe d'utilisateurs pour le moment.");//corrigé par Juan
  define("UCSLAN_8", "Groupes existants");
  //  define("UCSLAN_9", "Éditer");
  //  define("UCSLAN_10", "Supprimer");
  define("UCSLAN_11", "cocher pour confirmer");
  define("UCSLAN_12", "Nom du groupe");
  define("UCSLAN_13", "Description du groupe");
  define("UCSLAN_14", "Mettre à jour");
  define("UCSLAN_15", "Créer un nouveau groupe");
  define("UCSLAN_16", "Assigner des membres à ce groupe");
  define("UCSLAN_17", "Enlever");
  define("UCSLAN_18", "Vider ce groupe");
  define("UCSLAN_19", "Mettre à jour le groupe");
  define("UCSLAN_20", "");
  define("UCSLAN_21", "Paramètres du groupe");
  define("UCSLAN_22", "Membres - cliquer pour déplacer ...");
  define("UCSLAN_23", "Membres dans ce groupe ...");
  define("UCSLAN_24", "Qui peut gérer ce groupe");
  ?>
