﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_header.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_head_1", "Menu Admin");
  define("LAN_head_2", "Votre serveur n'autorise pas l'upload de fichiers donc il ne sera pas possible pour les membres d'uploader des avatars/fichiers etc. Pour rectifier cela, mettez la variable <strong>file_uploads</strong> sur <strong>On</strong> dans votre <strong>php.ini</strong> et redémarrer votre serveur. Si vous n'avez pas accès à votre php.ini, veuillez contacter votre hébergeur.");
  define("LAN_head_3", "Votre serveur restreint le 'basedir'. Cela interdit l'utilisation de tout fichier en dehors de votre dossier personnel et peut affecter certains scripts comme le gestionnaire de fichiers.");
  define("LAN_head_4", "Zone d'Administration");
  //v0.7
  define("LAN_head_5", "langue affichée dans l'aire d'admistration: ");
  define("LAN_head_6", "Extensions info");
  ?>
