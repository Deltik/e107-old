﻿<?php 
   define("LANDT_01", "année");
   define("LANDT_02", "mois");
   define("LANDT_03", "semaine");
   define("LANDT_04", "jour");
   define("LANDT_05", "heure");
   define("LANDT_06", "minute");
   define("LANDT_07", "seconde");
   define("LANDT_01s", "années");
   define("LANDT_02s", "mois");
   define("LANDT_03s", "semaines");
   define("LANDT_04s", "jours");
   define("LANDT_05s", "heures");
   define("LANDT_06s", "minutes");
   define("LANDT_07s", "secondes");
   define("LANDT_08", "min");	  
   define("LANDT_08s", "mins");
   define("LANDT_09", "sec");
   define("LANDT_09s", "secs");
   define("LANDT_AGO", "plus tôt");
   ?>
