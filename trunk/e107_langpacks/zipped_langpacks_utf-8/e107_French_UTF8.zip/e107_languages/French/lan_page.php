<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_PAGE_1", "La liste des pages n'est pas activée");
  define("LAN_PAGE_2", "Il n'y a pas de pages");
  define("LAN_PAGE_3", "La page demandée n'existe pas");
  define("LAN_PAGE_4", "Noter cette page");
  define("LAN_PAGE_5", "Merci d'avoir noter cette page");
  define("LAN_PAGE_6", "Vous n'avez pas la permission d'accéder à cette page");
  define("LAN_PAGE_7", "Mot de Passe Incorrect");
  define("LAN_PAGE_8", "Page Protégée par un Mot de Passe");
  define("LAN_PAGE_9", "Mot de Passe");
  define("LAN_PAGE_10", "Proposer");
  define("LAN_PAGE_11", "Liste des Pages");
  ?>
