﻿<?php 
  define("NP_1", "Page précédente");
  define("NP_2", "Page suivante");
  define("NP_3", "Aller à la page");
  ?>
