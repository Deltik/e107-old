<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_online.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("ONLINE_EL1", "Invité(s): ");
  define("ONLINE_EL2", "Membre(s): ");
  define("ONLINE_EL3", "Sur cette page : ");
  define("ONLINE_EL4", "En ligne");
  define("ONLINE_EL5", "Membres");
  define("ONLINE_EL6", "Dernier membre");
  define("ONLINE_EL7", "regarde");
  define("ONLINE_EL8", "le plus de membres en ligne : ");
  define("ONLINE_EL9", "le");
  define("ONLINE_EL10", "Nom du membre");
  define("ONLINE_EL11", "Page visitée");
  define("ONLINE_EL12", "Répond à ");
  define("ONLINE_EL13", "Forum");
  define("ONLINE_EL14", "Sujet");
  define("ONLINE_EL15", "Page");
  define("CLASSRESTRICTED", "Page à accès restreint");
  define("ARTICLEPAGE", "Article/Chronique");
  define("CHAT", "Chat");
  define("COMMENT", "Commentaires");
  define("DOWNLOAD", "Téléchargements");
  define("EMAIL", "Courriel");
  define("FORUM", "Index du forum principal");
  define("LINKS", "Liens");
  define("NEWS", "Actualités");
  define("OLDPOLLS", "Anciens sondages");
  define("POLLCOMMENT", "Sondage");
  define("PRINTPAGE", "Page déimpression");
  define("LOGIN", "Page déidentification");
  define("SEARCH", "Recherche");
  define("STATS", "Statistiques du site");
  define("SUBMITNEWS", "Proposition d'actualités");
  define("UPLOAD", "Uploads public");
  define("USERPAGE", "Profil déun membre");
  define("USERSETTINGS", "Paramètres de son compte");
  define("ONLINE", "Membres en ligne");
  define("LISTNEW", "Liste des Nouveautés par catégorie");
  define("USERPOSTS", "Messages déun membre");
  define("SUBCONTENT", "Proposer Article/Chronique");
  define("TOP", "Les meilleurs Posteurs/Sujets les plus actifs");
  define("ADMINAREA", "Administration");
  define("BUGTRACKER", "Rapport de bugs");
  define("EVENT", "Liste des événements");
  define("CALENDAR", "Calendrier des événements");
  define("FAQ", "Faq");
  define("PM", "Message privé");
  define("SURVEY", "Sondage");
  define("ARTICLE", "Article");
  define("CONTENT", "Contenu");
  define("REVIEW", "Chronique");
  ?>
