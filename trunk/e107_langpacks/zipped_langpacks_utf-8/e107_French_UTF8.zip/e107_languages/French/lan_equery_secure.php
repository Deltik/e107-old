﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_equery_secure.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/08 20:09:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("EQSEC_LAN1", "Vous êtes redirigé vers une fonction administrateur, de possibles modifications de base de données pourraient s'ensuivre");
  define("EQSEC_LAN2", "Veuillez confirmer cette action :");
  define("EQSEC_LAN3", "Aucun référant");
  define("EQSEC_LAN4", "Action de :");
  define("EQSEC_LAN5", "Action pour: :");
  define("EQSEC_LAN6", "Confirmer l'action");
  define("EQSEC_LAN7", "Ou annuler");
  ?>
