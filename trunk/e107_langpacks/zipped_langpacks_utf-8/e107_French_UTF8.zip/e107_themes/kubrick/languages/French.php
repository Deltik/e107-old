﻿<?php
  define("LAN_THEME_1", "'kubrick' par <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Basé sur le thème original de Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
  define("LAN_THEME_2", "Commentaires désactivés");
  define("LAN_THEME_3", "commentaire: ");
  define("LAN_THEME_4", "Suite...");
  define("LAN_THEME_5", "Trackbacks: ");
  ?>
