﻿<?php
  define("LAN_THEME_1", "'sebes' par <a href='http://e107.org' rel='external'>jalist</a>");
  define("LAN_THEME_2", "Lire/poster Commentaires: ");
  define("LAN_THEME_3", "Commentaires désactivés");
  define("LAN_THEME_4", "Suite...");
  define("LAN_THEME_5", "Trackbacks: ");
  ?>
