<?php
  define("TD_MENU_L1", "Autres Actualités");
  ?>
