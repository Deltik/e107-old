<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/log/languages/admin/French.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/09 19:00:44 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("ADSTAT_ON", "Activée");
  define("ADSTAT_OFF", "Desactivée");
  define("ADSTAT_L1", "Cette extension enregistrera toutes les visites faites sur votre site, et construira des écrans de statistiques détaillés basés sur les informations recueilies.");
  define("ADSTAT_L2", "L'extension Statistiques de connexion a été installée avec succès. Pour l'activer, veuillez vous rendre sur votre écran de configuration et cliquez Activer.<br /><strong>Vous devez avoir établi les permissions du dossier e107_plugins/log/logs sur 777 (chmod 777)</strong>");
  define("ADSTAT_L3", "Statistiques des Connexions");
  define("ADSTAT_L4", "Activer les statistiques des connexions");
  define("ADSTAT_L5", "Types de statistiques");
  define("ADSTAT_L6", "Navigateurs");
  define("ADSTAT_L7", "Systèmes de Fonctionnement");
  define("ADSTAT_L8", "Stats Résolution d'écran /Profondeur Colorée ");
  define("ADSTAT_L9", "Pays/domaine de provenance des visites");
  define("ADSTAT_L10", "Référants");
  define("ADSTAT_L11", "Requêtes recherche");
  define("ADSTAT_L12", "Relance des stats");
  define("ADSTAT_L13", "cela écrasera vos stats - attention!");
  define("ADSTAT_L14", "^Compte Page ");
  define("ADSTAT_L15", "Mise à  jour Paramètres Statistiques ");
  define("ADSTAT_L16", "Paramètres Statistiques du Site");
  define("ADSTAT_L17", "Paramètres Statistiques mis à  jour");
  define("ADSTAT_L18", "Autoriser l'accès à  la page principale des statistiques à  ...");
  define("ADSTAT_L19", "Visiteurs Récents");
  define("ADSTAT_L20", "Compte visites admin");
  define("ADSTAT_L21", "Maximum d'enregistrement à afficher sur la page des stats");
  define("ADSTAT_L22", "Lancer la routine de mise à jour");
  define("ADSTAT_L23", "Les connections d'une version précédente d'e107 ont été détectés, les mettre à  jour ici");
  define("ADSTAT_L24", "Mis à  jour du script");
  define("ADSTAT_L25", "Selectionner Réinitialisation Stats");
  define("ADSTAT_L26", "Supprimer les entrées des pages");
  define("ADSTAT_L27", "Si vos stats ont des pages incorrectes, vous pouvez les supprimer d'ici");
  define("ADSTAT_L28", "Page Ouverte");
  define("ADSTAT_L29", "Nom de page");
  define("ADSTAT_L30", "Cocher pour enlever");
  define("ADSTAT_L31", "Supprimer les pages sélectionnées");
  define("ADSTAT_L32", "Page Nettoyé"); //"Page Tidy"
  ?>
