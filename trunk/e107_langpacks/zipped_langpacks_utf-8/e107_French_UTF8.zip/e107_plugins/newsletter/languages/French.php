<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsletter/languages/French.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:28 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("NLLAN_MENU_CAPTION", "Newsletter");
  define("NLLAN_01", "Newsletter");
  define("NLLAN_02", "Propose une façon rapide et facile de configurer et d'envoyer des newsletters");
  define("NLLAN_03", "Configurer les Newsletters");
  define("NLLAN_04", "L'extension newsletter a été installée avec succès. Configurez la en retournant sur la page d'administration principale et cliquez sur 'Newsletter' dans la section extensions");
  define("NLLAN_05", "Pas de newsletter définie pour le moment");
  define("NLLAN_06", "Nom");
  define("NLLAN_07", "Souscripteurs");
  define("NLLAN_08", "Options");
  define("NLLAN_09", "Êtes-vous sûrs de vouloir supprimer cette newsletter?");
  define("NLLAN_10", "Newsletters Existantes");
  define("NLLAN_11", "Pas de publications de la Newsletter pour le moment");
  define("NLLAN_12", "Publication");
  define("NLLAN_13", "[ID élément mère ] Sujet/Titre");
  define("NLLAN_14", "Courrielé?");
  define("NLLAN_15", "Options");
  define("NLLAN_16", "oui");
  define("NLLAN_17", "Pas expédié- cliquez pour envoyer");
  define("NLLAN_18", "Êtes-vous sûrs de vouloir expédier par courriel cette publication aux abonnés ?");
  define("NLLAN_19", "Êtes-vous sûrs de vouloir supprimer cette publication de la newsletter?");
  define("NLLAN_20", "Publications Existantes");
  define("NLLAN_21", "Titre");
  define("NLLAN_22", "Description");
  define("NLLAN_23", "Entête");
  define("NLLAN_24", "Pied de page");
  define("NLLAN_25", "Mettre à jour la Newsletter");
  define("NLLAN_26", "Créer une Newsletter");
  define("NLLAN_27", "Newsletter mise à jour dans la base de données.");
  define("NLLAN_28", "Newsletter définie et sauvegardée en base de données.");
  define("NLLAN_29", "Pas de Newsletter pour le moment.");
  define("NLLAN_30", "Newsletter");
  define("NLLAN_31", "Sujet/Titre");
  define("NLLAN_32", "Numéro de publication");
  define("NLLAN_33", "Texte");
  define("NLLAN_34", "Mettre à jour le publipostage");
  define("NLLAN_35", "Créer un publipostage");
  define("NLLAN_36", "Mettre à jour la publication de la Newsletter ");
  define("NLLAN_37", "Créer une publication de la Newsletter ");
  define("NLLAN_38", "Newsletter mise à jour dans la base de données.");
  define("NLLAN_39", "Publication de la Newsletter sauvegardée en base de données. - pour l'expédier,cliquer sur le bouton de ' Mise à jour de la Publication ' dans le menu d'Options.");
  define("NLLAN_40", "Envoi achevé - publication envoyée à ");
  define("NLLAN_41", "Souscripteur(s).");
  define("NLLAN_42", "Newsletter supprimée.");
  define("NLLAN_43", "Publication de la Newsletter supprimée.");
  define("NLLAN_44", "Newsletter Front Page");
  define("NLLAN_45", "Créer une Newsletter");
  define("NLLAN_46", "Créer un publipostage");
  define("NLLAN_47", "Options Newsletter");
  define("NLLAN_48", "Vous vous êtes abonné à cette newsletter - si vous voulez vous désabonner s'il vous plaît cliquez sur le bouton ci-dessous.");
  define("NLLAN_49", "Êtes-vous sûrs de vouloir vous désabonner de cette newsletter?");
  define("NLLAN_50", "Cliquez sur le bouton pour vous abonner ( votre adresse de souscription est");
  define("NLLAN_51", "Désabonnement");
  define("NLLAN_52", "Souscrire");
  define("NLLAN_53", "Êtes-vous sûrs de vouloir vous abonner à cette newsletter?");
  ?>
