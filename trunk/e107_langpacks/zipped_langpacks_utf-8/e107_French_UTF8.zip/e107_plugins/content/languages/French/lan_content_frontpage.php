<?php
  define("CONT_FP_1", "Catégorie de contenu");
  define("CONT_FP_2", "page principale");
  ?>
