<?php
  define("POWEREDBY_L1", "Généré par");
  ?>
