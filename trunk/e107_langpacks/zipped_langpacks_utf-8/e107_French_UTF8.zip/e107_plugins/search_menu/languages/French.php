<?php
  define("LAN_180", "Recherche");
  define("LAN_181", "Recherche sur");
  ?>
