﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/admin/French.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/08 19:49:27 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("CLOCK_AD_L1", "Configuration du menu Horloge sauvegardé");
  define("CLOCK_AD_L2", "Légende");
  define("CLOCK_AD_L3", "Mise à jour des paramètres du menu Horloge");
  define("CLOCK_AD_L4", "Configuration du menu Horloge");
  define("CLOCK_AD_L5", "AM/PM");
  define("CLOCK_AD_L6", "Si choisi, Cela s'affichera les heures au format américain (Format 0-12 AM/PM ). Non choisi affichera les heures au format'militaire' Format 0-24 ");
  define("CLOCK_AD_L7", "Préfixe de la date ");
  define("CLOCK_AD_L8", "Si votre langue nécessite avant la date un mot court (Exemple 'le' pour le français ou 'den' pour l'allemand...), utiliser ce champs. Si cela n'est pas nécessaire, laissez vide.");
  define("CLOCK_AD_L9", "Suffix 1");
  define("CLOCK_AD_L10", "Suffix 2");
  define("CLOCK_AD_L11", "Suffix 3");
  define("CLOCK_AD_L12", "Suffix 4 et plus");
  define("CLOCK_AD_L13", "Si votre langue nécessecite d'afficher un suffix juste après les chiffres de la date, remplissez-ces champs avec les suffix seuls (Exemple: 'st' pout 1, 'nd' pour 2, 'rd' pour 3 et 'th' pour 4 et plus pour utilisateur anglais). Si cela n'est pas nécessaire, laissez vide.");
  /*
  define("CLOCK_AD_L14", "");
  define("CLOCK_AD_L15", "");
  define("CLOCK_AD_L16", "");
  define("CLOCK_AD_L17", "");
  define("CLOCK_AD_L18", "");
  define("CLOCK_AD_L19", "");
  define("CLOCK_AD_L20", "");
  define("CLOCK_AD_L21", "");
  define("CLOCK_AD_L22", "");
  define("CLOCK_AD_L23", "");
  define("CLOCK_AD_L24", "");
  */
  ?>
