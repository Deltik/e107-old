﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/review_menu/languages/French.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:29 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_190", "Revue Proposée");
  define("LAN_RVW_1", "Mise àjour des paramètres du menu");
  define("LAN_RVW_2", "Configuration Menu Revues sauvegardée");
  define("LAN_RVW_3", "Titre:");
  define("LAN_RVW_4", "Nombre de revues à fficher:");
  define("LAN_RVW_5", "Afficher les catégories de revues dans le menu?");
  define("LAN_RVW_6", "Titre pour la page Liste de revues");
  define("LAN_RVW_7", "Voir le lien vers la revue proposée?");
  define("LAN_RVW_8", "Configuration Menu Revues");
  ?>
