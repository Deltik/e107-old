<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/Spanish.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/11/11 11:02:27 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "Campo/s en blanco.");
define("LWLAN_2", "Palabra enlazada guardada.");
define("LWLAN_3", "Palabra enlazada actualizada.");
define("LWLAN_4", "Sin palabras enlazadas definidas aún.");
define("LWLAN_5", "Palabras");
define("LWLAN_6", "Enlace");
define("LWLAN_7", "¿Activa?");
define("LWLAN_8", "Opciones");
define("LWLAN_9", "Si");
define("LWLAN_10", "No");
define("LWLAN_11", "Palabras enlazadas ya existentes");
define("LWLAN_12", "Si");
define("LWLAN_13", "No");
define("LWLAN_14", "Enviar palabra enlazada");
define("LWLAN_15", "Actualizar palabra enlazada");
define("LWLAN_16", "Editar");
define("LWLAN_17", "Eliminar");
define("LWLAN_18", "¿Esta seguro de eliminar esta palabra enlazada?");
define("LWLAN_19", "Palabra enlazada eliminada.");
define("LWLAN_20", "No encuentro la entrada de la palabra enlazada.");
define("LWLAN_21", "Palabra a autoenlace (o separado por comas para lista de palabras).");
define("LWLAN_22", "¿Activar?.");
define("LWLAN_23", "Administración de palabras enlazadas"); 
define("LWLAN_24", "Gestionar Palabras"); 
define("LWLAN_25", "Opciones"); 
define("LWLAN_26", "Áreas en las cuales activar palabras enlazadas"); 
define("LWLAN_27", "Este es el 'contexto' del texto mostrado"); 
define("LWLAN_28", "Páginas donde desactivar palabras enlazadas"); 
define("LWLAN_29", "El mismo formato que el menú de control de visibilidad. Una coincidencia por línea. Especifica una URL parcial o completa. Acabar con '!' para una coincidencia exacta al final de la parte del enlace"); 
define("LWLAN_30", "Guardar opciones"); 
define("LWLAN_31", "Añadir/Editar palabra enlazada"); 
define("LWLAN_32", "Opciones de palabras enlazadas"); 
define("LWLAN_33", 'Áreas de título'); 
define("LWLAN_34", 'Sumario de elementos'); 
define("LWLAN_35", 'Texto del cuerpo'); 
define("LWLAN_36", 'Descripciones (enlaces etc)'); 
define("LWLAN_37", 'Áreas originales'); 
define("LWLAN_38", 'Enlaces clicables'); 
define("LWLAN_39", 'Texto sin procesar'); 

define("LWLANINS_1", "Palabras enlazadas");
define("LWLANINS_2", "Este plugin enlaza palabras a un enlace determinado");
define("LWLANINS_3", "Configurar palabras enlazadas");
define("LWLANINS_4", "Para configurar, haga click en la seccion de plugins del menú del administrador");
?>