<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/mailout.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Use esta página para configurar sus ajustes de email de sus funciones de envíos del sitio. El formulario de envío de correos también le permite enviar un mensaje instantáneo a todos sus usuarios.";
$ns -> tablerender("Ayuda Mail", $text);
?>