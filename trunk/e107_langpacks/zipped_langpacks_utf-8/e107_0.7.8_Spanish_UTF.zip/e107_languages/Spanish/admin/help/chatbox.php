<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/chatbox.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/12/05 06:49:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Fija las preferencias de tu chatbox desde aquí.";

$ns -> tablerender("Chatbox", $text);
?>