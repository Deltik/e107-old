<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_db.php,v $
|     $Revision: 1.9 $
|     $Date: 2006/09/10 22:17:50 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Configuración del nucleo guardada con backup en la base de datos.");
define("DBLAN_2", "Backup BD");
define("DBLAN_3", "Hacer Backup de base de datos SQL");
define("DBLAN_4", "Chequear validación");
define("DBLAN_5", "Chequear validación de la base de datos");
define("DBLAN_6", "Optimizar BD");
define("DBLAN_7", "Optimizar base de datos SQL");
define("DBLAN_8", "Backup del Núcleo");
define("DBLAN_9", "Hacer Backup de núcleo");
define("DBLAN_10", "Utilidades de la base de datos");
define("DBLAN_11", "Base de datos MySQL");
define("DBLAN_12", "Optimizada");
define("DBLAN_13", "Volver");
define("DBLAN_14", "Hecho");
define("DBLAN_15", "Ver actualizaciones disponibles");
define("DBLAN_16", "Buscar actualizaciones");
define("DBLAN_17", "Pref. Nombre"); 
define("DBLAN_18", "Pref. Valor"); 
define("DBLAN_19", "Haga click en el botón para abrir las preferencias del editor (solo ususarios avanzados)"); 
define("DBLAN_20", "Preferencias Editor"); 
define("DBLAN_21", "Eliminar marcados");
define("DBLAN_22", "Plugin: Ver y escanear"); 
define("DBLAN_23", "Escaneado completado"); 
define("DBLAN_24", "Nombre"); 
define("DBLAN_25", "Directorio"); 
define("DBLAN_26", "Complementos incluídos"); 
define("DBLAN_27", "Instalado"); 
define("DBLAN_28", "Click en el botón para escanear cambios en los directorios"); 
define("DBLAN_29", "Escanear directorios de los plugins");
define("DBLAN_30", " (Si un añadido muestra un error, compruebe los carácteres fuera de los tags abiertos/cerrados de PHP)");
define("DBLAN_31", "Ok");
define("DBLAN_32", "Error");
define("DBLAN_33", "Inaccesible");
define("DBLAN_34", "Sin comprobar");
?>