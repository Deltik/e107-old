<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_banlist.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/11/18 21:14:48 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Expulsión eliminada.");
define("BANLAN_2", "No hay expulsados.");
define("BANLAN_3", "Expulsados existentes");
define("BANLAN_4", "Eliminar expulsión");
define("BANLAN_5", "Expulsar por IP, email o host");

define("BANLAN_7", "Razón");
define("BANLAN_8", "Expulsar dirección");
define("BANLAN_9", "Expulsar usuarios del sitio por el correo, IP o dirección del host");
define("BANLAN_10", "IP / Email / Razón");
define("BANLAN_11", "Auto-expulsión: Más de 10 intentos de conexión fallidos");
define("BANLAN_12", "Nota: DNS reversa está actualmente desactivada, debe activarse para permitir expulsar un dominio. La expulsión por IP y correo seguirá funcionando correctamente.");
define("BANLAN_13", "Nota: Para banear a un usuario por su nombre, vaya a la página de administración de usuarios: ");
?>