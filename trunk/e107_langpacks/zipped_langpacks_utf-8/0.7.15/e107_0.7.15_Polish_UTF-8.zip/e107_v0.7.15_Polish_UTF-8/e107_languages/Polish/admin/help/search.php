<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/search.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/search.php rev. 1.6
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Jeśli Twoja wersja serwera MySQL wspiera ta opcję możesz przełączyć na metodę sortowania MySQL, ponieważ jest ona szybsza niż metoda sortowania PHP. Zobacz w preferencjach.<br /><br />
Jeśli Twoja strona zawiera języki ideograficzne takie jak chiński oraz japoński, musisz używać metody sortowania PHP oraz musisz również wyłączyć opcję <i>Tylko pełne słowa</i>.";
$ns -> tablerender("Wyszukiwanie", $text);

?>
