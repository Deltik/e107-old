<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:05:17 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_mail_handler.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_mail_handler.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("LANMAILH_1", "Dostarczone przez e107 website system");
define("LANMAILH_2", "To jest wieloczęściowa wiadomość w formacie MIME.");
define("LANMAILH_3", " jest niewłaściwie sformatowana");
define("LANMAILH_4", "Serwer odrzucił adres");
define("LANMAILH_5", "Brak odpowiedzi z serwera");
define("LANMAILH_6", "Nie mogę odnaleźć serwera poczty.");
define("LANMAILH_7", " wydaje się być prawidłowy.");

?>
