<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "год");
define("LANDT_02", "месяц");
define("LANDT_03", "неделя");
define("LANDT_04", "день");
define("LANDT_05", "час");
define("LANDT_06", "минута");
define("LANDT_07", "секунда");
define("LANDT_01s", "лет");
define("LANDT_02s", "месяцев");
define("LANDT_03s", "недель");
define("LANDT_04s", "дней");
define("LANDT_05s", "часов");
define("LANDT_06s", "минут");
define("LANDT_07s", "секунд");

define("LANDT_08", "мин");
define("LANDT_08s", "мин");
define("LANDT_09", "сек");
define("LANDT_09s", "сек");
define("LANDT_AGO", "назад");


?>