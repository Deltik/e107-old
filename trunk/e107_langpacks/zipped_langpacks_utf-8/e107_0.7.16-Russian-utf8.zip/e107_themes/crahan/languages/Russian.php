<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'CraHan' от <a href='http://e107.org' rel='external'>jalist</a>, основано на теме от CraHan <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "комментарии: ");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекебки: ");
define("LAN_THEME_6", "Комментарий");

?>
