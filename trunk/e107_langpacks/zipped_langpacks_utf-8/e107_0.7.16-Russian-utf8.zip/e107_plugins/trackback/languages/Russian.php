<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "Настроить трекбек");
define("TRACKBACK_L2", "Этот плагин позволяет использовать трекбек в ваших новостях.");
define("TRACKBACK_L3", "Трекбек установлен и включен.");
define("TRACKBACK_L4", "Настройки трекбека сохранены.");
define("TRACKBACK_L5", "Вкл");
define("TRACKBACK_L6", "выкл");
define("TRACKBACK_L7", "Активировать трекбек");
define("TRACKBACK_L8", "Трекбек URL текста");
define("TRACKBACK_L9", "Сохранить настройки");
define("TRACKBACK_L10", "Настройки трекбека");
define("TRACKBACK_L11", "Адрес трекбека для этого сообщения:");

define("TRACKBACK_L12", "Для этого элемента нет трекбека");
define("TRACKBACK_L13", "Модерировать трекбек");
define("TRACKBACK_L14", "Удалить");
define("TRACKBACK_L15", "Трекбеки удалены.");

?>