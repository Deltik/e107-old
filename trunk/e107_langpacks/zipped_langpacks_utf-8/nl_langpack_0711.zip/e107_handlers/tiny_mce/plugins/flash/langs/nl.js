// NL lang variables

tinyMCELang['lang_insert_flash']      = 'Invoegen / bewerken Flash animatie';
tinyMCELang['lang_insert_flash_file'] = 'Flash-bestand (.swf)';
tinyMCELang['lang_insert_flash_size'] = 'omvang';
tinyMCELang['lang_insert_flash_list'] = 'Flash bestanden';
tinyMCELang['lang_flash_props'] = 'Flash eigenschappen';