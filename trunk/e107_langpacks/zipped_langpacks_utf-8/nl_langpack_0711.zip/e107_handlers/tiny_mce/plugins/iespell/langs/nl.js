// NL lang variables

tinyMCELang['lang_iespell_desc'] = 'Start spellingcontrole';
tinyMCELang['lang_iespell_download'] = "ieSpell niet gevonden. Klik OK voor de download pagina."
