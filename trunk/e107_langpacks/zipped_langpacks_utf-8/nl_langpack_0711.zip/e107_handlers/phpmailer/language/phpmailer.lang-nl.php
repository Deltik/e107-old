<?php
/**
* PHPMailer language file.
* Dutch Version
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'Er moet minimaaléén ' . 'ontvangers e-mailadres worden opgegeven.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer wordt niet ondersteund.';
$PHPMAILER_LANG["execute"] = 'Niet uit te voeren: ';
$PHPMAILER_LANG["instantiate"] = 'Kon mailfunctie niet starten.';
$PHPMAILER_LANG["authenticate"] = 'SMTP fout: geen authenticatie.';
$PHPMAILER_LANG["from_failed"] = 'Het volgende adres mislukte: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP fout: De volgende ' . 'ontvangers mislukt: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP fout: Data niet geaccepteerd.';
$PHPMAILER_LANG["connect_host"] = 'SMTP fout: geen verbinding met SMTP server.';
$PHPMAILER_LANG["file_access"] = 'Kon bestand niet benaderen: ';
$PHPMAILER_LANG["file_open"] = 'Bestandsfout: niet te openen: ';
$PHPMAILER_LANG["encoding"] = 'Onbekende codering: ';
?>