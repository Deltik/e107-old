<?php
define("OTHERDB_LAN_1", "Database Type:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Gebruikersnaam:");
define("OTHERDB_LAN_4", "Wachtwoord:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Tabel");
define("OTHERDB_LAN_7", "Veld Gebruikersnaam:");
define("OTHERDB_LAN_8", "Veld Wachtwoord:");
define("OTHERDB_LAN_9", "Wachtwoord method:");
define("OTHERDB_LAN_10", "Configureren otherdb auth");
define("OTHERDB_LAN_11", "** De volgende velden zijn niet verplicht bij gebruik van een e107 database");
?>
