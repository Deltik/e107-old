<?php

define("LAN_350", "Instellen thema");
define("LAN_351", "Selecteer thema");

?>