<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Dutch_formal/lan_content_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:44:44 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Content");
define("CONT_SCH_LAN_2", "Alle contentcategorieën");
define("CONT_SCH_LAN_3", "Geplaatst als reactie op onderwerp");
define("CONT_SCH_LAN_4", "in");
?>