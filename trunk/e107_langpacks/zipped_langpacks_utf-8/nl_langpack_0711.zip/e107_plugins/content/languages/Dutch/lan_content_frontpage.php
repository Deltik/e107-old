<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Dutch/lan_content_frontpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/19 05:55:59 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("CONT_FP_1", "Contentcategorie");
define("CONT_FP_2", "Hoofdpagina");

?>