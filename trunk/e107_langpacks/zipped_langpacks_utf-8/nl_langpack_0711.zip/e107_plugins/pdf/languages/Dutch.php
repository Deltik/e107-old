<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/pdf/languages/Dutch.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/16 18:57:42 $
|     $Author: mijnheer $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF ondersteuning");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Deze plugin kan nu worden gebruikt.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF voorkeuren");
define("PDF_LAN_3", "geactiveerd");
define("PDF_LAN_4", "gedeactiveerd");
define("PDF_LAN_5", "linker paginamarge");
define("PDF_LAN_6", "rechter paginamarge");
define("PDF_LAN_7", "bovenmarge");
define("PDF_LAN_8", "font familie");
define("PDF_LAN_9", "standaard font grootte");
define("PDF_LAN_10", "font groott sitenaam");
define("PDF_LAN_11", "font grootte pagina url");
define("PDF_LAN_12", "font grootte paginanummer");
define("PDF_LAN_13", "tonen logo in pdf?");
define("PDF_LAN_14", "tonen sitenaam in pdf?");
define("PDF_LAN_15", "tonen herkomst pagina url in pdf?");
define("PDF_LAN_16", "tonen paginanummers in pdf?");
define("PDF_LAN_17", "bijwerken");
define("PDF_LAN_18", "PDF voorkeuren succesvol bijgewerkt");
define("PDF_LAN_19", "Pagina");
define("PDF_LAN_20", "foutrapportage");

?>