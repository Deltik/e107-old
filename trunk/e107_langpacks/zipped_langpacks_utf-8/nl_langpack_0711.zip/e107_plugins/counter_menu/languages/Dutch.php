<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("COUNTER_L1", "Beheerbezoek wordt niet geteld.");
define("COUNTER_L2", "Deze pagina vandaag ...");
define("COUNTER_L3", "totaal");
define("COUNTER_L4", "Deze pagina ooit ...");
define("COUNTER_L5", "uniek");
define("COUNTER_L6", "Site ...");
define("COUNTER_L7", "Teller");
define("COUNTER_L8", "Beheerboodschap: <b>Statistiek logging is gedeactiveerd.</b><br />Om te activeren moet je de Statistiek logging plugin in je <a href='".e_ADMIN."plugin.php'>plugin manager</a> installeren, daarna kun je de functie activeren in het <a href='".e_PLUGIN."log/admin_config.php'>configuratie scherm</a>.");
?>