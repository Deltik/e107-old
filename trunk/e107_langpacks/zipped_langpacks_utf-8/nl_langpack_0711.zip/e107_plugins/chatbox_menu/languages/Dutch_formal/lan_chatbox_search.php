<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Dutch_formal/lan_chatbox_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:44:12 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");

?>