<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/human_condition/languages/Dutch_formal.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/10/15 21:20:36 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' door <a href='http://e107.org' rel='external'>jalist</a>, gebaseerd op het Wordpress thema, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Reacties bij dit onderwerp niet mogelijk");
define("LAN_THEME_3", "reactie(s): ");
define("LAN_THEME_4", "Lees verder ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Reactie van");


?>
