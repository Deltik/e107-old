<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/kubrick/languages/Dutch_formal.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:48:42 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' door <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> & <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Gebaseerd op een origineel thema van Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Reacties bij dit onderwerp niet mogelijk");
define("LAN_THEME_3", "reactie: ");
define("LAN_THEME_4", "Lees verder ...");
define("LAN_THEME_5", "Trackbacks: ");


?>
