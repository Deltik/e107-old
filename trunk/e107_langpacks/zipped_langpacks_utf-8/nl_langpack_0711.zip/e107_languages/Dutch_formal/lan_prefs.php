<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch_formal/lan_prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/03/31 21:05:40 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 powered website");
define("LAN_PREF_2", "e107 website systeem");
define("LAN_PREF_3", "Alle merknamen zijn auteursrechtelijk beschermd door hun respectievelijke eigenaars, alle andere content is eigendom van deze e107 powered website.<br />e107 is © e107.org 2002-2005 en is gepubliceerd onder de <a href=\"http://www.gnu.org/\" rel=\"external\">GNU GPL licentie</a>.");
define("LAN_PREF_4", "gecensureerd");
define("LAN_PREF_5", "Forums");

?>