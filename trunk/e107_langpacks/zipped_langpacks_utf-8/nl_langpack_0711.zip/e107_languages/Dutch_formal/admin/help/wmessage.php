<?php

if (!defined('e107_INIT')) { exit; }

$text = "Op deze pagina kunt u een boodschap instellen die (bij activering) altijd bovenaan de startpagina wordt getoond. U kunt een verschillende melding instellen voor gasten, geregistereerde/ingelogde leden en voor beheerders.";
$ns -> tablerender("Welkomsmelding Help", $text);
?>