<?php

if (!defined('e107_INIT')) { exit; }

$text = "De Voorkeuren functie laat u alle belangrijke instellingen van uw site vastleggen. Dat varieert van bijvoorbeeld van de naam van uw site tot de beveiligingsfuncties en het ongewenste woorden filter.";
$ns -> tablerender("Voorkeurenhulp", $text);
?>