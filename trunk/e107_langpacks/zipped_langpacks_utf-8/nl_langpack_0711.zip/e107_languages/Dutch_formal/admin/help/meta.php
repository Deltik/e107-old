<?php

if (!defined('e107_INIT')) { exit; }

$text = "De meta tags die u hier opgeeft worden op de juiste plaats naar het scherm gestuurd.";

$ns -> tablerender("Meta Tags", $text);
?>