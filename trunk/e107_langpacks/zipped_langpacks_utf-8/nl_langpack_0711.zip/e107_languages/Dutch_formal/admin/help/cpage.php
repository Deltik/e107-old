<?php

if (!defined('e107_INIT')) { exit; }

$text = "In dit scherm kun je maatwerkmenu's en maatwerkpagina's maken waarin u uw eigen content opvoert.<br /><br />
Zie <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a> voor een uitleg van alle functies.";

$ns -> tablerender('Maatwerkmenu/Helppagina', $text);
?>