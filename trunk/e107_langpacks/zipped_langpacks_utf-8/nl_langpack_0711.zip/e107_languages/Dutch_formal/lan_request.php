<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch_formal/lan_request.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:43:29 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Download Fout");
define("LAN_dl_62", "Het downloaden van dit bestand is geblokkeerd wegens quota-overschrijding");
define("LAN_dl_63", "U hebt niet de juiste autorisaties om dit bestand te downloaden.");
define("LAN_dl_64", "Terug");
define("LAN_dl_65", "Bestand niet gevonden");

?>