<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        lan_print.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 13th Sep 2004
+---------------------------------------------------------------+
*/

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Printervriendelijk"); }
define("LAN_PRINT_1", "printervriendelijk");
define("LAN_PRINT_86", "Categorie:");
define("LAN_PRINT_87", "door ");
define("LAN_PRINT_94", "Geplaatst door");
define("LAN_PRINT_135", "Nieuwsbericht: ");
define("LAN_PRINT_303", "Dit nieuwsbericht is van ");
define("LAN_PRINT_304", "Titel van het artikel: ");
define("LAN_PRINT_305", "Onderkop: ");
define("LAN_PRINT_306", "Dit artikel is van: ");
define("LAN_PRINT_307", "Druk deze pagina af");

?>