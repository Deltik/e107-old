<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        lan_equery_secure.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 10th Sep 2004
+---------------------------------------------------------------+
*/

define("EQSEC_LAN1", "U wordt doorgeleid naar een beheerfunctie, er kan een databasemutatie plaatsvinden");
define("EQSEC_LAN2", "Bevestig deze actie:");
define("EQSEC_LAN3", "Geen verwijzer");
define("EQSEC_LAN4", "Actie van:");
define("EQSEC_LAN5", "Actie op:");
define("EQSEC_LAN6", "Bevestig actie");
define("EQSEC_LAN7", "Of annuleer");


?>