<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch/lan_contact.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/18 19:55:40 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Contact Details");
define("LANCONTACT_02", "Contactformulier");
define("LANCONTACT_03", "Invoeren naam:");
define("LANCONTACT_04", "E-mailadres:");
define("LANCONTACT_05", "Onderwerp:");
define("LANCONTACT_06", "Je bericht:");
define("LANCONTACT_07", "E-mail een kopie naar je eigen adres ");
define("LANCONTACT_08", "Verzenden");
define("LANCONTACT_09", "Je bericht werd verzonden.");
define("LANCONTACT_10", "Er was een probleem bij het versturen.");
define("LANCONTACT_11", "Je e-mailadres lijkt niet juist.\\nControleer het en probeer het nogmaals.");
define("LANCONTACT_12", "Het bericht is te kort.");
define("LANCONTACT_13", "Geef een onderwerp op."); 
define("LANCONTACT_14", "Stuur bericht aan:");
define("LANCONTACT_15", "Onjuiste code ingevoerd");
define("LANCONTACT_16", "Invoeren code");
?>