<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        lan_userposts.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 14th Sep 2004
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Gebruikersberichten");
define("UP_LAN_0", "Alle forumberichten van ");
define("UP_LAN_1", "Alle reacties van ");
define("UP_LAN_2", "Discussie");
define("UP_LAN_3", "Bekeken");
define("UP_LAN_4", "reacties");
define("UP_LAN_5", "Laatste");
define("UP_LAN_6", "Discussies");
define("UP_LAN_7", "Geen reacties");
define("UP_LAN_8", "Geen berichten");
define("UP_LAN_9", "op ");
define("UP_LAN_10", "Betr.");
define("UP_LAN_11", "Geplaatst op: ");
define("UP_LAN_12", "Zoeken");
define("UP_LAN_13", "Reacties");
define("UP_LAN_14", "Forumberichten");
define("UP_LAN_15", "Betr.");
define("UP_LAN_16", "IP adres");

?>