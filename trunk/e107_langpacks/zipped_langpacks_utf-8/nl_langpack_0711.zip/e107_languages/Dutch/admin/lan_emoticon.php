<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_emoticon.php Dutch-utf language file
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("EMOLAN_1", "Emoticon activering.");
define("EMOLAN_2", "Naam");
define("EMOLAN_3", "Emoticons");
define("EMOLAN_4", "Emoticons activeren?");
define("EMOLAN_5", "Afbeelding");
define("EMOLAN_6", "Smiley Code");
define("EMOLAN_7", "meerdere mogelijkheden scheiden met spaties");
define("EMOLAN_8", "Status");
define("EMOLAN_9", "Opties");
define("EMOLAN_10", "Actief pakket");
define("EMOLAN_11", "Pakket activeren");
define("EMOLAN_12", "Bewerk/configureer dit pakket");
define("EMOLAN_13", "Genstalleerde pakketten");
define("EMOLAN_14", "Bewaren configuratie");
define("EMOLAN_15", "Bewerken/configureren smileys");
define("EMOLAN_16", "Smiley configuratie opgeslagen");
define("EMOLAN_17", "Er is een emoticon pack met spaties aanwezig, die zijn niet toegestaan !");
define("EMOLAN_18", "hernoem de onderstaande objecten, zodat ze geen spaties bevatten:");
define("EMOLAN_19", "Naam");
define("EMOLAN_20", "Locatie");
define("EMOLAN_21", "Fout");
define("EMOLAN_22", "Nieuw emote pak gevonden:");
define("EMOLAN_23", "Nieuw emote xml pak gevonden:");
define("EMOLAN_24", "Nieuw emote php gevonden:");
define("EMOLAN_25", "Installeren nieuwe PHP emotes: ");
define("EMOLAN_26", "Opnieuw scannen pakket");
define("EMOLAN_27", "Fout bij verwerken pakket: ");
define("EMOLAN_28", "Genereren XML");
define("EMOLAN_29", "XML bestand gegenereerd: ");
define("EMOLAN_30", "Fout bij wegschrijven XML bestand: ");
?>