<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_banlist.php Dutch language file
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("BANLAN_1", "Blokkade verwijderd.");
define("BANLAN_2", "Geen blokkades.");
define("BANLAN_3", "Huidige blokkades");
define("BANLAN_4", "Verwijder blokkade");
define("BANLAN_5", "Blokkeer IP-adres");
define("BANLAN_7", "Reden");
define("BANLAN_8", "Blokkeer gebruiker");
define("BANLAN_9", "Blokkeer deze site voor gebruikers");
define("BANLAN_10", "IP / E-mail / Reden");
define("BANLAN_11", "Auto-blok: Meer dan 10 mislukte inlogpogingen");
define("BANLAN_12", "Let op: Reverse DNS is op dit moment niet geactiveerd. Dat moet wel om blokkade voor hosts mogelijk te maken.  Blokkeren op IP-adres en op e-mailadres werkt wel.");
define("BANLAN_13", "Let op: Om een gebruiker te blokkeren op gebruikersnaam, ga naar de leden beheerpagina: ");
?>