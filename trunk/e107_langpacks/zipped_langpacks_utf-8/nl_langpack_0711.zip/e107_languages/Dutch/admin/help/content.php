<?php

if (!defined('e107_INIT')) { exit; }

$text = "Je kunt hier een normale pagina toevoegen aan je site. Er wordt automatisch een link in het hoofdmenu opgenomen. Als je bijvoorbeeld een pagina met de Link Naam 'Test' opgeeft, wordt een link met de naam 'Test' aan de Links sectie toegevoegd.<br />
Als je wilt dat er een titel wordt getoond, geef die dan op in het koptekst veld.";
$ns -> tablerender("Inhoud Hulp", $text);
?>