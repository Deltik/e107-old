<?php

if (!defined('e107_INIT')) { exit; }

$text = "Met deze functie kun je gebruikers al dan niet toestaan om bestanden te uploaden naar je site en kun je de geuploade bestanden ook beheren.";
$ns -> tablerender("Openbare Uploads hulp", $text);
?>