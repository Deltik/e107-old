<?php

if (!defined('e107_INIT')) { exit; }

$text = "De thema manager laat je zowel het thema van je gepubliceerde site, als het eventueel afwijkende thema van je beheerscherm instellen.";
$ns -> tablerender("Thema Manager hulp", $text);
?>