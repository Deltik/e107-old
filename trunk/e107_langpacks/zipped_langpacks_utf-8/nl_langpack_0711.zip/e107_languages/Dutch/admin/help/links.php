<?php

if (!defined('e107_INIT')) { exit; }

$text = "Voer hier al je links op. Links die hier worden toegevoegd, verschijnen in het hoofdmenu, voor andere links kun je de Links Page plugin gebruiken";
$ns -> tablerender("Links Hulp", $text);
?>