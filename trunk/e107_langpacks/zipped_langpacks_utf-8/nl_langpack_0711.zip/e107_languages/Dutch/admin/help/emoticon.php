<?php

if (!defined('e107_INIT')) { exit; }


$text = "Kruis het vakje aan om text emoticons te vervangen door plaatjes.<br /><br />
Voer de wijzigingen in en klik op Bijwerken om de instellingen te bewaren. Gebruik het invoerformulier onderaan dit scherm om nieuwe emotes toe te voegen.";

$ns -> tablerender("Emoticon Hulp", $text);
?>