<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch/lan_page.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/07 20:47:20 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Paginaoverzicht uitgeschakeld");
define("LAN_PAGE_2", "Er zijn geen pagina's");
define("LAN_PAGE_3", "Opgevraagde pagina bestaat niet");
define("LAN_PAGE_4", "Beoordeel deze pagina");
define("LAN_PAGE_5", "Bedankt voor het beoordelen van deze pagina");
define("LAN_PAGE_6", "Je hebt geen toestemming om deze pagina te bekijken");
define("LAN_PAGE_7", "Onjuist wachtwoord");
define("LAN_PAGE_8", "Wachtwoord beveiligde pagina");
define("LAN_PAGE_9", "Wachtwoord");
define("LAN_PAGE_10", "Aanmelden");
define("LAN_PAGE_11", "Paginaoverzicht");
define("LAN_PAGE_12", "Ongeldige pagina");
define("LAN_PAGE_13", "Pagina");
?>