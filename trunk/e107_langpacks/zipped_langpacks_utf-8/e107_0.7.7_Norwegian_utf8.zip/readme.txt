/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/11/24  $
|     $Author: eelay $
+----------------------------------------------------------------------------+
*/

This is a complete norwegian languagefile for e107 CMS created by eelay..

This is the first rev so if there is any spelling errors ect. , my apologies.

If you got any corrections or comments, you can email me : eelay@e107norway.org
------------------
Installation
------------------
Just uppload the files in your root e107 folder.
The folders are already correct.
------------------

eelay@e107norway.org