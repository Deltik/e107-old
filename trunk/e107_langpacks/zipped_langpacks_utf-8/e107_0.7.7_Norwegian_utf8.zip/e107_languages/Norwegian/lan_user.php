<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_user.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 01:47:32 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Medlemmer");
define("LAN_20", "Feil");
define("LAN_112", "Epostadresse");
define("LAN_115", "ICQ-nummer");
define("LAN_116", "AIM adresse");
define("LAN_117", "MSN Messenger");
define("LAN_118", "Fødselsdag");
define("LAN_119", "Sted");
define("LAN_120", "Signatur");
define("LAN_137", "Det finnes ingen informasjon på denne brukeren siden han ikke er registrert på");
define("LAN_138", "Registrerte medlemmer: ");
define("LAN_139", "Rekkefølge: ");
define("LAN_140", "Registrerte medlemmer");
define("LAN_141", "Ingen registrerte medlemmer enda.");
define("LAN_142", "Medlem");
define("LAN_143", "[skjult etter ønske]");
define("LAN_144", "Nettsted URL");
define("LAN_145", "Medlem siden");
define("LAN_146", "Besøk her siden registrering");
define("LAN_147", "Chatruteinnlegg");
define("LAN_148", "Antall kommentarer");
define("LAN_149", "Foruminnlegg");
define("LAN_308", "Virkelig navn");
define("LAN_400", "Det er ingen gyldig bruker.");
define("LAN_401", "ingen informasjon");
define("LAN_402", "Medlemsprofil");
define("LAN_403", "Nettsidestatistikk");
define("LAN_404", "Siste besøk");
define("LAN_405", "dagar sedan");
define("LAN_406", "Nivå");
define("LAN_407", "ingen");
define("LAN_408", "intet foto");
define("LAN_409", "poeng");
define("LAN_410", "Diverse");
define("LAN_411", "Klikk her for å oppdatere brukerinformasjonen din");
define("LAN_412", "Klikk her for å endre denne brukerens informasjon");
define("LAN_413", "slett foto");
define("LAN_414", "forrige medlem");
define("LAN_415", "neste medlem");
define("LAN_416", "Du må være innlogget for å benytte denne siden");
define("LAN_417", "Nettstedets hovedadministrator");
define("LAN_418", "Nettstedsadministrator");
define("LAN_419", "Vis");
define("LAN_420", "Fallende.");
define("LAN_421", "Stigende.");
define("LAN_422", "Kjør");
define("LAN_423", "Klikk her for å se brukerkommentarer");
define("LAN_424", "Klikk her for å se foruminnlegg");
define("LAN_425", "Send privat melding");
define("LAN_426", "siden");
define("USERLAN_1", "Peer nivå");
define("USERLAN_2", "Du har ikke adgang til å se denne siden.");


?>