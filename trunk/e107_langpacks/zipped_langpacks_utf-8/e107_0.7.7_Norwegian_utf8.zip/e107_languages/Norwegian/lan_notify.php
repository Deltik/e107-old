<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_notify.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/02 16:13:37 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Brukerregistrering");

define("NT_LAN_UV_1", "Brukerregistrering bekreftet");
define("NT_LAN_UV_2", "Brukeres sesjonsstreng");
define("NT_LAN_UV_3", "Brukers loginnavn: ");
define("NT_LAN_UV_4", "Brukers IP: ");

define("NT_LAN_LI_1", "Brukere logget inn");

define("NT_LAN_LO_1", "Brukere logget ut");
define("NT_LAN_LO_2", " logget ut fra nettstedet");

define("NT_LAN_FL_1", "Floodingsperret");
define("NT_LAN_FL_2", "IP-adresse sperret p.g.a. floodning");

define("NT_LAN_SN_1", "Nyhetsemne postet");

define("NT_LAN_NU_1", "Oppdatert");

define("NT_LAN_ND_1", "Nyhetsemne slettet");
define("NT_LAN_ND_2", "Slettet nyhetsemnets ID");

?>
