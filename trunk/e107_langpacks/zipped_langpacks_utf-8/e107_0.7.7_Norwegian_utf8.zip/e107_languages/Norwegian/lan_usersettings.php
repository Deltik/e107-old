<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_usersettings.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/3 02:22:19 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Brukerinnstillinger");
define("LAN_7", "Visningsnavn: ");
define("LAN_8", "navnet som vises på nettstedet");
define("LAN_9", "Innloggingsnavn: ");
define("LAN_10", "navnet du bruker for innlogging");
define("LAN_11", "navnet du bruker for innlogging - dette kan ikke endres, kontakt en administrator om du behøver endre det av sikkerhetsgrunner.");
define("LAN_20", "Feil");
define("LAN_105", "De to passordene er ikke like");
define("LAN_106", "Det ser ikke ut som en gyldig epostadresse");
define("LAN_112", "Epostadresse: ");
define("LAN_113", "Skjul epostaddresse?: ");
define("LAN_114", "Dette hindrer at epostadressen din vises på nettstedet");
define("LAN_115", "ICQ-nummer: ");
define("LAN_116", "AIM adresse: ");
define("LAN_117", "MSN Messenger: ");
define("LAN_118", "Fødselsdag: ");
define("LAN_119", "Sted: ");
define("LAN_120", "Signatur: ");
define("LAN_121", "Avatar: ");
define("LAN_122", "Tidssone:");
define("LAN_144", "Nettsted URL: ");
define("LAN_150", "Innstillingene oppdatert og lagret i databasen.");
define("LAN_151", "OK");
define("LAN_152", "Nytt passord: ");
define("LAN_153", "Nytt passord igjen: ");
define("LAN_154", "Lagre innstillinger");
define("LAN_155", "Oppdater brukerinnstillinger");
define("LAN_185", "Du lot passordfeltet stå tomt ");
define("LAN_308", "Virkelig navn: ");
define("LAN_401", "La stå tomt for å beholde nåværende passord");
define("LAN_402", "Oppgi sti eller velg avatar");
define("LAN_403", "Velg avatar");
define("LAN_404", "NB: Et bilde som lastes opp til denne serveren og som av administratorene anses å være av tvilsom karakter kommer til å slettes umiddelbart.");
define("LAN_410", "Instillinger for");
define("LAN_411", "Oppdater innstillingene dine");
define("LAN_412", "Endre passord");
define("LAN_413", "Velg en avatar");
define("LAN_414", "Last opp foto");
define("LAN_415", "Last opp avatar");
define("LAN_416", "Ja");
define("LAN_417", "Nei");
define("LAN_418", "Registreringsinformasjon");
define("LAN_419", "Personlig / kontaktinformasjon");
define("LAN_420", "avatar");
define("LAN_421", "Velg en avatar fra nettstedet");
define("LAN_422", "Bruk en avatar fra et annet nettsted");
define("LAN_423", "Oppgi den fullstendige adressen til bildet");
define("LAN_424", "Klikk på knappen for åt se avatarer lagret på nettstedet");
define("LAN_425", "Fotografi");
define("LAN_426", "Dette vil vises på profilsiden din");
define("LAN_427", "Send ...");
define("LAN_428", "Nyhet");
define("LAN_429", "Link");
define("LAN_430", "Fil");
define("LAN_431", "Artikkel");
define("LAN_432", "Anmeldelse");
define("LAN_433", "URL til XUP filen din");
define("LAN_434", "Hva er en XUP fil?");
define("LAN_435", "XML brukerprotokollfil");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "tegn");
define("LAN_SIGNUP_4", "Passordet ditt må være minst ");
define("LAN_SIGNUP_5", " tegn langt.");
define("LAN_SIGNUP_6", "Din ");
define("LAN_SIGNUP_7", " kreves");
define("LAN_USET_1", "Avataren er for bred");
define("LAN_USET_2", "Maksimal tillatt bredde er");
define("LAN_USET_3", "Din avatar er for høy");
define("LAN_USET_4", "Maksimal tillatt høyde er");
define("LAN_CUSTOMTITLE", "Egen tittel");
define("LAN_ICQNUMBER", "ICQ-nummer kan kun inneholde siffer");
define("LAN_408", "En bruker med den epostadressen finnes allerede. ");
define("MAX_AVWIDTH", "Maksimal avatarstørrelse (B x H) er ");
define("MAX_AVHEIGHT", " x ");
define("GIF_RESIZE", "Vennligst endre størrelse på gif-bildet, eller konverter til annet format");
define("RESIZE_NOT_SUPPORTED", "Metode for størrelsesendring støttes ikke av serveren. Vennligst endre størrelsen selv, eller velg et annet bilde. Filen slettes.");
define("LAN_USET_5", "Abonner på");
define("LAN_USET_6", "Abonner på vår(e) epostlist(r) og/eller seksjoner av nettstedet.");
define("LAN_USET_7", "Diverse");
define("LAN_USET_8", "Signatur / Tidssone");
define("LAN_USET_9", "Et/noen av de nedenforliggende feltene (markert med *) mangler i dine instillinger.");
define("LAN_USET_10", "Vennligst oppdater dine innstillinger nå for å kunne fortsette.");
define("LAN_USET_11", "Det brukernavnet kan ikke aksepteres som gyldig, velg noe annet");


?>