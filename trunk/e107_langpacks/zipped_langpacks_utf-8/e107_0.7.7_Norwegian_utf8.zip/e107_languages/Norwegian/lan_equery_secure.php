<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_equery_secure.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/30 03:25:42 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Du blir omdirigert til en adminfunksjon, databaseendringer kan inntreffe");
define("EQSEC_LAN2", "Vennligst bekreft denne handlingen:");
define("EQSEC_LAN3", "Ingen henvisning");
define("EQSEC_LAN4", "Handling fra:");
define("EQSEC_LAN5", "Handling til:");
define("EQSEC_LAN6", "Bekreft handling ");
define("EQSEC_LAN7", "eller avbryt");


?>