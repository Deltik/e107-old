<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_user_select.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 12:42:35 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Velg brukere");
define("US_LAN_2", "Velg brukerklasse");
define("US_LAN_3", "Alle brukere");
define("US_LAN_4", "Søk brukernavn");
define("US_LAN_5", "Brukere funnet");
define("US_LAN_6", "Søk");


?>