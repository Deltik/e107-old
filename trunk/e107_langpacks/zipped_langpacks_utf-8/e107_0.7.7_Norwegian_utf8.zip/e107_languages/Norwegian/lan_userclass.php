<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_userclass.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 02:00:36 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Alle (offentlig)");
define("UC_LAN_1", "Gjester");
define("UC_LAN_2", "Ingen (inaktiv)");
define("UC_LAN_3", "Medlemmer");
define("UC_LAN_4", "Skrivebeskyttet");
define("UC_LAN_5", "Admin");
define("UC_LAN_6", "Hovedmeny");


?>