<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_plugin.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 04:39:11 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("EPL_ADLAN_0", "Installer");
define("EPL_ADLAN_1", "Avinstaller");
define("EPL_ADLAN_2", "Er du sikker på at du vil avinstallere denne plugin?");
define("EPL_ADLAN_3", "Bekreft avinstallasjon");
define("EPL_ADLAN_4", "Avinstallasjon avbrutt.");
define("EPL_ADLAN_5", "Installasjonsprosessen kommer til å skape nye preferanseinstillinger.");
define("EPL_ADLAN_6", "... klikk deretter her for å begynne installasjonen");
define("EPL_ADLAN_7", "Databaestabeller oppgradert.");
define("EPL_ADLAN_8", "Preferanseinstillinger opprettet.");
define("EPL_ADLAN_9", "SQL-kommandoen mislyktes. Kontroller at alle oppgraderingsendringer er ok.");
define("EPL_ADLAN_10", "Navn");
define("EPL_ADLAN_11", "Versjon");
define("EPL_ADLAN_12", "Forfattere");
define("EPL_ADLAN_13", "Kompatibilitet");
define("EPL_ADLAN_14", "Beskrivelse");
define("EPL_ADLAN_15", "Les README-filen for mer informasjon");
define("EPL_ADLAN_16", "Plugin informasjon");
define("EPL_ADLAN_17", "Mer info...");
define("EPL_ADLAN_18", "Kunne ikke opprette tabell(er) for denna plugin.");
define("EPL_ADLAN_19", "Databasetabeller opprettet.");
define("EPL_ADLAN_21", "Plugin er allerede installert.");
define("EPL_ADLAN_22", "Innstallert");
define("EPL_ADLAN_23", "Ikke installert");
define("EPL_ADLAN_24", "Oppgradering tilgjengelig");
define("EPL_ADLAN_25", "Ingen installasjon kreves");
define("EPL_ADLAN_26", "... klikk deretter her for å begynne avinstallasjonen");
define("EPL_ADLAN_27", "Kunne ikke slette");
define("EPL_ADLAN_28", "Databasetabeller slettet.");
define("EPL_ADLAN_29", "Preferanseinstillinger slettet.");
define("EPL_ADLAN_30", "Vennligst fjern dem manuelt.");
define("EPL_ADLAN_31", "Fjern katalogen nå");
define("EPL_ADLAN_32", "og alle filer inni den for å avslutte avinstallasjonen.");
define("EPL_ADLAN_33", "Plugin installert.");
define("EPL_ADLAN_34", "Plugin oppdatert.");
define("EPL_ADLAN_35", "Tolkinnstillinger opprettet.");
define("EPL_ADLAN_36", "Innlegging av tolkekode mislyktes, feil formattert.");
define("EPL_ADLAN_37", "Last opp plugin (.zip eller .tar.gz format)");
define("EPL_ADLAN_38", "Last opp  plugin");
define("EPL_ADLAN_39", "Filen kunne ikke lastes opp ettersom ".e_PLUGIN." katalogen ikke har korrekte - endre til CHMOD 777 og forsøk igjen.");
define("EPL_ADLAN_40", "Adminmelding");
define("EPL_ADLAN_41", "Denne filen ser ikke ut til å være gyldig.zip eller .tar arkiv.");
define("EPL_ADLAN_42", "En feil har oppstått, kan ikke pakke opp arkivfilen");
define("EPL_ADLAN_43", "Plugin'en er lastet opp og pakket ut, bla nedover for å se plugin'en i listen.");
define("EPL_ADLAN_44", "Auto plugin opplastning og utpakking er deaktivert ettersom pluginfolderen ikke har korrekte rettighetet - endre din e107_plugins katalog til CHMOD 777.");
define("EPL_ADLAN_45", "Ditt menyobjekt har blitt lastet opp og pakket ut, gå til <a href='".e_ADMIN."menus.php'>din menyside</a> for å aktivera det.");
define("EPL_WEBSITE", "Nettsted");
define("EPL_NOINSTALL", "Ingen installasjon kreves, aktiver bare fra din menyside. For å avinstallere, slette ");
define("EPL_DIRECTORY", "katalogen.");
define("EPL_NOINSTALL_1", "Ingen installasjon kreves. For å ta bort, slett");
define("EPL_UPGRADE", "Oppgrader");
define("EPL_ADLAN_50", "Kommentarer slettet.");
define("EPL_ADLAN_53", "Mappen er ikke srivbar");
define("EPL_ADLAN_54", "Venligst velg alternativet for sletting av plugin:");
define("EPL_ADLAN_55", "Avinstaller plugin");
define("EPL_ADLAN_57", "Slette plugintabeller");
define("EPL_ADLAN_58", "Om tabellene ikke blir fjernet kan pluginen bli reinstallert uten noe datatap.  Opprattningen av tabeller vil feile under reinstalasjonen. Tabellene må slettes manuelt for å fjernes.");
define("EPL_ADLAN_59", "Slett pluginfiler");
define("EPL_ADLAN_60", "e107 vil prøve å slette alle pluginrelaterte filer.");
define("EPL_ADLAN_62", "Avbryt avinstallering");
define("EPL_ADLAN_63", "Avinstaller:");
define("LAN_UPGRADE_SUCCESSFUL", "Oppdateringen var suksessfull");
define("LAN_INSTALL_SUCCESSFUL", "Installasjonen var suksessfull");


?>