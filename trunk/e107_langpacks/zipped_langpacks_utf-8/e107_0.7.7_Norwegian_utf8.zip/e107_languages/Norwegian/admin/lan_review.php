﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_review.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 05:24:45 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("REVLAN_1", "Anmeldelse lagt inn i databasen.");
define("REVLAN_2", "Felt latt stå tomt.");
define("REVLAN_3", "Anmeldelse oppdatert i databasen.");
define("REVLAN_4", "Anmeldelse slettet.");
define("REVLAN_5", "Marker i bekreftelsesruten for å slette denne anmeldelsen");
define("REVLAN_6", "Ingen anmeldelse enda.");
define("REVLAN_7", "Eksisterende anmeldelser");
define("REVLAN_8", "Endra");
define("REVLAN_9", "Slett");
define("REVLAN_10", "marker for å bekrefte");
define("REVLAN_11", "Åpne HTML-editor");
define("REVLAN_12", "Overskrift");
define("REVLAN_13", "Underoverskrift");
define("REVLAN_14", "Sammendrag");
define("REVLAN_15", "Ameldelse");
define("REVLAN_16", "Karakter");
define("REVLAN_17", "Velg karakter");
define("REVLAN_18", "Tillat kommentarer?");
define("REVLAN_19", "På");
define("REVLAN_20", "Av");
define("REVLAN_21", "Synlig for");
define("REVLAN_22", "Uppdatera anmeldelse");
define("REVLAN_23", "Send anmeldelse");
define("REVLAN_24", "Anmeldelser");




define("REVLAN_25", "Anmeldelsesskategori lagret");
define("REVLAN_26", "Anmeldelsesskategori oppdatert");
define("REVLAN_27", "Kategori slettet");
define("REVLAN_28", "Kategori");
define("REVLAN_29", "Alternativ");
define("REVLAN_30", "Endre");
define("REVLAN_31", "Slette");
define("REVLAN_32", "Ingen anmeldelsesskategori");
define("REVLAN_33", "Eksisterende Anmeldelsesskategori");
define("REVLAN_34", "Kategorinavn");
define("REVLAN_35", "Kategori ikon");
define("REVLAN_36", "Vis bilder");
define("REVLAN_37", "Kategorisammendrag");
define("REVLAN_38", "Oppdatert anmeldelseskategori");
define("REVLAN_39", "Opprett anmeldelseskategori");
define("REVLAN_40", "Ingen anmeldelser");
define("REVLAN_41", "Eksisterende anmeldelser");
define("REVLAN_42", "Åpne HTML-editorer");
define("REVLAN_43", "Kategori");
define("REVLAN_44", "Ingen");
define("REVLAN_45", "Anmeldelsenes førsteside");
define("REVLAN_46", "Opprett ny anmeldelse");
define("REVLAN_47", "Kategorier");
define("REVLAN_48", "Anmeldelsesalternativ");
define("REVLAN_49", "Er du sikker på at du vil slette denne kategorien?");
define("REVLAN_50", "Er du sikker på at du vil slette denne anmeldelsen?");
define("REVLAN_51", "Forfatterdetaljer");
define("REVLAN_52", "la stå tomt om du har skrevet anmeldelsen");
define("REVLAN_53", "Forfatterens navn");
define("REVLAN_54", "Forfatterens epostadresse");

define("REVLAN_55", "Tillat av anmeldelser blir sendt inn");
define("REVLAN_56", "Tillt besøkere å sende inn anmeldelser til nettstedet");
define("REVLAN_57", "Klasse for innsendning");
define("REVLAN_58", "Velg hvilke brukere som kan sende inn anmeldelser");
define("REVLAN_59", "Oppdater alternativ");
define("REVLAN_60", "Anmeldelsesalternativ");
define("REVLAN_61", "Anmeldelsesalternativ oppdatert");

define("REVLAN_62", "Innsendte anmeldelser");
define("REVLAN_63", "Ingen innsendte anmeldelser");
define("REVLAN_64", "Ingen epostadresse angitt");
define("REVLAN_65", "Anmeldelsesoverskrift");
define("REVLAN_66", "Post");
define("REVLAN_67", "Post brukerinnsendt artikkel");
define("REVLAN_68", "Bruker innsendte anmeldelser lagret i databasen");

define("REVLAN_69", "Tøm skjema");
define("REVLAN_70", "Klikk her for å fylle ut forfatterfeltet");
define("REVLAN_71", "Lgg til epost/skriv-ut ikoner?");
define("REVLAN_72", "Ja");
define("REVLAN_73", "Nei");

?>
