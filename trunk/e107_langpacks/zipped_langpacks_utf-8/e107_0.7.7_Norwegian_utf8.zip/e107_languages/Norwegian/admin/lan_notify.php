<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_notify.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 03:24:45 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Systemmeldinger");
define("NT_LAN_2", "Ta imot epostmeldinger om");
define("NT_LAN_3", "Av");
define("NT_LAN_4", "Hovedadmin");
define("NT_LAN_5", "Klasse");
define("NT_LAN_6", "Epost");
define("NU_LAN_1", "Brukerhendelse");
define("NU_LAN_2", "Brukerregistrering");
define("NU_LAN_3", "Brukerkonto bekreftet");
define("NU_LAN_4", "Brukerinnlogging");
define("NU_LAN_5", "Brukerutlogging");
define("NS_LAN_1", "Sikkerhetshendelse");
define("NS_LAN_2", "IP blokkert pga flooding av nettstedet");
define("NN_LAN_1", "Nyhetshendelse");
define("NN_LAN_2", "Nyhetspost innsendt av bruker");
define("NN_LAN_3", "Nyhet postet av admin");
define("NN_LAN_4", "Nyhet redigert av admin");
define("NN_LAN_5", "Nyhet slettet av admin");
define("NF_LAN_1", "Filehendelser");
define("NF_LAN_2", "Fil opplastet av bruker");


?>