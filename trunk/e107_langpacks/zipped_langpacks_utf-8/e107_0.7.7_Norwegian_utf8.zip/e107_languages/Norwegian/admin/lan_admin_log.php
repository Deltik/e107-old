<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "Dato");
define("LAN_ADMINLOG_2", "Tittel");
define("LAN_ADMINLOG_3", "Beskrivelse");
define("LAN_ADMINLOG_4", "Bruker IP");
define("LAN_ADMINLOG_5", "Bruker ID");
define("LAN_ADMINLOG_6", "Informativt ikon");
define("LAN_ADMINLOG_7", "Informativ beskjed");
define("LAN_ADMINLOG_8", "Notisikon");
define("LAN_ADMINLOG_9", "Notisbeskjed");
define("LAN_ADMINLOG_10", "Advarselsikon");
define("LAN_ADMINLOG_11", "Advarselsbeskjed");
define("LAN_ADMINLOG_12", "Dødelig ikon");
define("LAN_ADMINLOG_13", "Dødelig feilbeskjed");


?>