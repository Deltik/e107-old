<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_download.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 18:47:54 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("DOWLAN_1", "Nedlasting lagt til i databasen.");
define("DOWLAN_2", "Nedlasting oppdatert i databasen.");
define("DOWLAN_3", "Nedlasting slettet.");
define("DOWLAN_4", "Marker i bekreftelsesruten for å slette nedlastingen");
define("DOWLAN_5", "Det finnes ingen nedlastingskategorier definiert enda, før du har definert en kan du ikke legge til noen nedlasting.");
define("DOWLAN_6", "Ingen eksisterende nedlastinger");
define("DOWLAN_7", "Eksisterende nedlastingar");
define("DOWLAN_11", "Kategori");
define("DOWLAN_12", "Navn");
define("DOWLAN_13", "Fil");
define("DOWLAN_14", "Oppgi adresse om nedlastingen er en ekstern fil");
define("DOWLAN_15", "Forfatter");
define("DOWLAN_16", "Forfatterens epost");
define("DOWLAN_17", "Forfatterens nettsted");
define("DOWLAN_18", "Beskrivelse");
define("DOWLAN_19", "Hovedbilde");
define("DOWLAN_20", "Miniatyrbilde");
define("DOWLAN_21", "Status");
define("DOWLAN_24", "Oppdater nedlasting");
define("DOWLAN_25", "Post nedlasting");
define("DOWLAN_27", "Nedlasting");
define("DOWLAN_29", "Førsteside nedlasting ");
define("DOWLAN_30", "Opprett nedlasting");
define("DOWLAN_31", "Kategorier");
define("DOWLAN_32", "Nedlastingsalternativ");
define("DOWLAN_33", "Er du sikker på at du vil slette denne nedlastingen?");
define("DOWLAN_34", "Er du sikker på at du vil slette denne nedlastingskategorien?");
define("DOWLAN_36", "slettet");
define("DOWLAN_37", "Server");
define("DOWLAN_38", "Ingen eksisterende kategorier");
define("DOWLAN_39", "Nedlastingskategorier");
define("DOWLAN_40", "Ingen - hovedserver");
define("DOWLAN_41", "Ikon");
define("DOWLAN_42", "Vis bilder");
define("DOWLAN_43", "Synlig for");
define("DOWLAN_44", "Markering kommer til å gjøre kategorien synlig kun for medlemmene i denne brukerklassen");
define("DOWLAN_45", "Opprett kategori");
define("DOWLAN_46", "Oppdater kategori");
define("DOWLAN_47", "Kategori opprettet");
define("DOWLAN_48", "Kategori oppdatert");
define("DOWLAN_49", "Nedlastingskategori");
define("DOWLAN_51", "Søk etter nedlastinger");
define("DOWLAN_52", "Filer");
define("DOWLAN_53", "Underkategori");
define("DOWLAN_54", "Nedlastingsalternativer");
define("DOWLAN_55", "Antall nedlastingar å vise per sida");
define("DOWLAN_56", "Sorter etter ");
define("DOWLAN_59", "Filnavn");
define("DOWLAN_62", "Stigende");
define("DOWLAN_63", "Fallende");
define("DOWLAN_64", "Oppdater alternativ");
define("DOWLAN_65", "Alternativ oppdatert");
define("DOWLAN_66", "Angi filstørrelse");
define("DOWLAN_67", "ID");
define("DOWLAN_68", "Fil mangler!");
define("DOWLAN_69", "Nedlastingar håndteres av PHP");
define("DOWLAN_70", "Markering av dette vil sende alle nedlastingsforespørsler via PHP.");
define("DOWLAN_100", "Aktiver nedlastingsavtale");
define("DOWLAN_101", "Avtaletekst");
define("DOWLAN_102", "Tillat kommentarer?");
define("DOWLAN_103", "Fjern fra opplastninger");
define("DOWLAN_104", "slettes fra opplastninger");
define("DOWLAN_105", "Tillbake til offentlige opplastninger");
define("DOWLAN_106", "Nedlasting tilgjengelig for");
define("DOWLAN_107", "Begrens antall nedlastinger");
define("DOWLAN_108", "Begrens nedlastingsbåndbredde");
define("DOWLAN_109", "hver");
define("DOWLAN_110", "dager");
define("DOWLAN_111", "kB");
define("DOWLAN_112", "Begrensninger");
define("DOWLAN_113", "Brukerklasse");
define("DOWLAN_114", "Legg til ny begrensning");
define("DOWLAN_115", "Oppdater begrensninger");
define("DOWLAN_116", "Begrensning for den brukerklassen finnes allerede");
define("DOWLAN_117", "Begrensning ble korrekt lagt til");
define("DOWLAN_118", "Begrensning ikke innlagt - ukjent feil");
define("DOWLAN_119", "Begrensning ble korrekt fjernet");
define("DOWLAN_120", "Begrensning ikke fjernet - ukjent feil");
define("DOWLAN_121", "Begrensning ble korrekt oppdatert");
define("DOWLAN_122", "Inaktiv");
define("DOWLAN_123", "Aktiv - Filen har begrensninger");
define("DOWLAN_124", "Aktiv - Filen har INGEN begrensninger");
define("DOWLAN_125", "Nedlastingsbegrensninger aktive");
define("DOWLAN_126", "Aktiveringsstatus oppdatert");
define("DOWLAN_127", "Angi bare filstørrelse om nedlastingen er en ekstern fil");
define("DOWLAN_128", "Speiling");
define("DOWLAN_129", "la stå åpent om speiling ikke benyttes");
define("DOWLAN_130", "Legg til ny speiling");
define("DOWLAN_131", "Velg lokal fil");
define("DOWLAN_132", "Angi speil å bruke, deretter nedlastingsadressen");
define("DOWLAN_133", "Speil oppdatert i databasen");
define("DOWLAN_134", "Speil lagret i databasen");
define("DOWLAN_135", "Speil slettet");
define("DOWLAN_136", "Bilde");
define("DOWLAN_137", "Er du sikker på at du vil slette dette speilet?");
define("DOWLAN_138", "Eksisterende speil");
define("DOWLAN_139", "Adresse");
define("DOWLAN_140", "Last opp lokale bilder till e107_files/downloadimages for å vise dem her, eller angi fullstendig adresse om bildet er eksternt");
define("DOWLAN_141", "Sted");
define("DOWLAN_142", "Oppdater speil");
define("DOWLAN_143", "Opprett speil");
define("DOWLAN_144", "Ingen speil definert, gå til speilingsseksjonen for å legge dem til.");
define("DOWLAN_145", "Nedlasting synlig for");
define("DOWLAN_146", "Eget 'Nektet nedlasting' melding eller URL");
define("DOWLAN_147", "Ikon for tom kategori");
define("DOWLAN_148", "Marker for å oppdatere datostempelet til nåværende tid");
define("DOWLAN_149", "Eller klikk her for å bruke en ekstern fil");
define("DOWLAN_150", "Send epost til admin for å rapportere ikke-fungerende nedlasting");
define("DOWLAN_151", "Ødelagt nedlastningsrapportering tilgjengelig for");
define("DOWLAN_152", "Kunne ikke flytte fil");
define("DOWLAN_153", "Flytt fil til nedlastningsmappe");


?>