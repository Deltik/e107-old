<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_theme.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 04:41:04 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("TPVLAN_1", "Du ser på en forhåndsvisning av <b>'".PREVIEWTHEMENAME."'</b> temaet. Det er ikke satt som hovedtema for nettstedet enda, det er bare aktivert for forhåndsvisning av hvordan temaet ser ut.<br />For å sette dette som nettstedets tema, <a href='".e_ADMIN."theme.php'>gå tilbake til temahånterer</a> og velg 'Sett som nettstedstema'.<br />For å forhåndsvise flere temaer <a href='".e_ADMIN."theme.php'>klikk her</a>");
define("TPVLAN_2", "Temaforhandsvisning");
define("TPVLAN_3", "Nettstedstema satt til");
define("TPVLAN_4", "Forfatter");
define("TPVLAN_5", "Nettsted");
define("TPVLAN_6", "Publiseringsdato");
define("TPVLAN_7", "Informasjon");
define("TPVLAN_8", "Alternativ");
define("TPVLAN_9", "Forhåndsvis tema");
define("TPVLAN_10", "Sett som nettstedstema");
define("TPVLAN_11", "Versjon");
define("TPVLAN_12", "Ingen forhåndsvisning tilgjengelig");

define("TPVLAN_13", "Last opp tema (.zip eller .tar.gz format)");
define("TPVLAN_14", "Last opp tema ");
define("TPVLAN_15", "Filen kunne ikke lastes opp ettersom ".e_THEME." katalogen ikke har korrekte rettigheter - sett den til CHMOD 777 og prøv igjen.");
define("TPVLAN_16", "Adminmelding");
define("TPVLAN_17", "Filen ser ikke ut til p være et .zip eller .tar arkiv.");
define("TPVLAN_18", "Feil har oppstått, kan ikke pakke opp arkivfilen");
define("TPVLAN_19", "Temaet er lastet opp og har blitt utpakket, bla ned for å se temaet i listen.");
define("TPVLAN_20", "Autoopplasting av tema og utpalling er deaktivert etterom temakatalogen ikke har korrekterettigheter - sett e107_themes katalogen til CHMOD 777.");

define("TPVLAN_21", "Dette er eksisterende nettstedstema");

define("TPVLAN_22", "dette temaet har flere stilmaler");
define("TPVLAN_23", "standard stilmal");
define("TPVLAN_24", "ingen informasjon");
define("TPVLAN_25", "For å velge stilmal, gå til<a href='".e_ADMIN."prefs.php'>innstillinger</a> og klikk på 'Tema'.");

define("TPVLAN_26", "Temahåndterer");
define("TPVLAN_27", "Velg stilmal å bruke");
define("TPVLAN_28", "på");
define("TPVLAN_29", "av");
define("TPVLAN_30", "Forhåndslast temabilder:");

define("TPVLAN_31", "Dette er det nåværende admintemaet");
define("TPVLAN_32", "Sett som admintema");

define("TPVLAN_33", "Eksisterende nettstedstema");
define("TPVLAN_34", "Eksisterende admintema");
define("TPVLAN_35", "Lagre alternativ");
define("TPVLAN_36", "Adminmelding");
define("TPVLAN_37", "Temaalternativ lagret");
define("TPVLAN_38", "Last opp tema");
define("TPVLAN_39", "Tilgjengelige tema");
define("TPVLAN_40", "Admintema satt til");

define("TPVLAN_41", "Velg admin layoutstil å bruke");
define("TPVLAN_42", "Lagre adminalternativ");
define("TPVLAN_43", "Adminalternativ lagret");

?>
