<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_userclass2.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 04:12:06 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Fjernet alle brukere fra klasse.");
define("UCSLAN_2", "Klassebrukere oppdater.");
define("UCSLAN_3", "Klasse slettet.");
define("UCSLAN_4", "Marker for å bekrefte sletting av denne brukerklassen");
define("UCSLAN_5", "Klasse oppdatert.");
define("UCSLAN_6", "Klasse lagret i databasen.");
define("UCSLAN_7", "Ingen brukerklasser enda.");
define("UCSLAN_8", "Eksisterende klasser");
define("UCSLAN_11", "marker for å bekrefte");
define("UCSLAN_12", "Klassenavn");
define("UCSLAN_13", "Klassebeskrivelse");
define("UCSLAN_14", "Oppdater brukerklasse");
define("UCSLAN_15", "Opprett ny klasse");
define("UCSLAN_16", "Legg til brukere til klasse");
define("UCSLAN_17", "Fjern");
define("UCSLAN_18", "Rydd opp i klasse");
define("UCSLAN_19", "Legg til brukere til");
define("UCSLAN_20", "klasse");
define("UCSLAN_21", "Brukerklasseinnstillinger");
define("UCSLAN_22", "Brukere - klikk for å flytte...");
define("UCSLAN_23", "Brukere i denne klassen...");
define("UCSLAN_24", "Hvem kan håndtere klassen");


?>