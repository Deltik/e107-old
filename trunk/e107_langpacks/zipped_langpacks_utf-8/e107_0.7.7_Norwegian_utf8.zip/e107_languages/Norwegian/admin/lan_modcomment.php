<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_modcomment.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 01:09:57 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderert.");
define("MDCLAN_2", "Ingen kommentarer til denne posten");
define("MDCLAN_3", "Medlem");
define("MDCLAN_4", "Gjest");
define("MDCLAN_5", "fjern blokkering");
define("MDCLAN_6", "blokker");
define("MDCLAN_8", "Moderer kommentarer");
define("MDCLAN_9", "Advarsel! Sletting av toppkommentarer sletter også alle svar!");
define("MDCLAN_10", "Alternativ");
define("MDCLAN_11", "kommentar");
define("MDCLAN_12", "kommentarer");
define("MDCLAN_13", "blokkert");
define("MDCLAN_14", "les kommentarer");
define("MDCLAN_15", "Åpen");
define("MDCLAN_16", "lest");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>