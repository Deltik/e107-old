<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_cpage.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 17:44:43 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Tittel");
define("CUSLAN_2", "Type");
define("CUSLAN_3", "Alternativ");
define("CUSLAN_4", "Slett denne siden?");
define("CUSLAN_5", "Eksisterende sider");
define("CUSLAN_7", "Menynavn");
define("CUSLAN_8", "Tittel / Overskrift");
define("CUSLAN_9", "Tekst");
define("CUSLAN_10", "Tillat karaktergivning på siden");
define("CUSLAN_11", "Førsteside");
define("CUSLAN_12", "Opprett side");
define("CUSLAN_13", "Tillat kommentarer");
define("CUSLAN_14", "Passordbeskyttet side");
define("CUSLAN_15", "oppgi passord for beskyttelse av siden");
define("CUSLAN_16", "Opprett link i hovedmenyen");
define("CUSLAN_17", "oppgi linknavn å opprette");
define("CUSLAN_18", "Side / link synlig for");
define("CUSLAN_19", "Oppdater side");
define("CUSLAN_20", "Opprett side");
define("CUSLAN_21", "Oppdater meny");
define("CUSLAN_22", "Opprett meny");
define("CUSLAN_23", "Rediger side");
define("CUSLAN_24", "Opprett ny side");
define("CUSLAN_25", "Rediger meny");
define("CUSLAN_26", "Opprett ny meny");
define("CUSLAN_27", "Siden lagret til databasen.");
define("CUSLAN_28", "Sidan slettet");
define("CUSLAN_29", "List opp sider om ingen side er valgt");
define("CUSLAN_30", "Cookiens varighet (i sekunder)");
define("CUSLAN_31", "Opprett meny");
define("CUSLAN_32", "Konverter gamle sider/menyer");
define("CUSLAN_33", "Alternativ for side");
define("CUSLAN_34", "Starter konvertering");
define("CUSLAN_35", "Avsluttet innholdssideoppdatering - uppdatert");
define("CUSLAN_36", "For å sette innstillinger for hver side gå tilbake til førstesiden og Rediger sidene.");
define("CUSLAN_37", "Oppdatering av egne sider");
define("CUSLAN_38", "til");
define("CUSLAN_39", "fra");
define("CUSLAN_40", "Lagre alternativ");
define("CUSLAN_41", "Vis informasjon om forfattere og datoer");
define("CUSLAN_42", "Ingen side definert enda");


?>