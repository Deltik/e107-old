<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_message.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 11:07:35 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Mottatte meldinger");
define("MESSLAN_2", "Slett melding");
define("MESSLAN_3", "Melding slettet.");
define("MESSLAN_4", "Slett alle meldinger");
define("MESSLAN_5", "Bekreft");
define("MESSLAN_6", "Alle meldinger slettet.");
define("MESSLAN_7", "Ingen meldinger.");
define("MESSLAN_8", "Meldingstype");
define("MESSLAN_9", "Rapportert den");
define("MESSLAN_10", "Sendt av");
define("MESSLAN_11", "Åpnes i nytt vindu");
define("MESSLAN_12", "Melding");
define("MESSLAN_13", "Link");


?>