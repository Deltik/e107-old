<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/list_menu_conf.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "I denne seksjonen kan du konfigurere 3 menyer<br>
<b>Nye artikkler meny</b> <br>
Skriv in et nummer, eks. '5' i det første feltet for å vise de fem første artikklene. Lad det stå tomt for å vise alle. Du konfigurerer hva rubrikken til linken skal være for resten av artikklene i det andre feltet, om du lar det siste valget stå tomt så skapes ingen link, eks.: 'Alle artikkler'<br>
<b>Kommentarer/Forum meny</b> <br>
Antallet kommentarer er 5 som standard, antalet tegn er 10000 som standard. Postfixet er til for at om en rad er for lang så kuttes den og så legges postfixet til slutt. En bra verdi kan være '...', marker originalnavnene om du vil vise disse i oversikten.<br>

";
$ns -> tablerender("Menykonfigurasjonshjelp", $text);

?>
