<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Melde fra sender e-postbeskjeder når en e107-hendelse oppstår.<br /><br />
For eksempel, om du setter 'IP blokkert pga flooding av nettstedet' til klassen 'Admin' så kommer alle admins til å få et brev på e-post når 
siden blir flooded.<br /><br />
Du kan også, som et annet eksempel, sette 'Nyhet postet av admin' til brukerklasse 'Medlemmer' oså kommer alle medlemmene å få en e-post sent til seg når du poster en nyhet på siden.<br /><br />
Om du vil at notisene skal sendes til en alternativ e-postadresse - velg da 'E-post' alternativet og
 angi e-postadressen i feltet for dette.";

$ns -> tablerender("Melde fra hjelp", $text);

?>
