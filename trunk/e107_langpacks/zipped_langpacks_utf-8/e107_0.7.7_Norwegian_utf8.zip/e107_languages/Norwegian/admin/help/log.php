<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/log.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan aktivere statistikklogging fra denne siden. Om du har lite plass på serverren kan du markere bare domenelogging istede for logging av henvisninger, det kommer da bare til å logges domenet og ikke hele Urlen, eks. 'jalist.com' istedet for 'http://jalist.com/links.php' ";
$ns -> tablerender("Loggingshjelp", $text);

?>
