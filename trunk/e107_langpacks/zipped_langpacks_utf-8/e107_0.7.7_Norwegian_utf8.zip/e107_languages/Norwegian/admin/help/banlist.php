<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/banlist.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Blokkere brukere fra siden din";
$text = "Fra denne siden kan du blokkere brukere fra å ha tilgang til siden din.<br />
Enten skriver du inne en fullstendig IP-adresse eller så bruker du et wildcard for angi et område av IP-adresser. Du kan også angi e-postadresser for å hildre at disse brukes til å registere seg på siden.<br /><br />
<b>Blokkere via IP-adresse:</b><br />
Skriver du inn IP-adressen 123.123.123.123 kommer det til å hindre personen med denne IP-adressen i å besøke siden din.<br />
Skriver du inn adressen 123.123.123.* istedet, kommer det til å hindre alle med IP-adresse fra 123.123.123.0 til 123.123.123.255 å besøke siden din.<br /><br />
<b>Blokkere via e-postadresse</b><br />
Om du Skriver inn e-postadressen foo@bar.com kan brukeren ikke regestrere seg på siden her med denne e-postadressen.<br />
Om du Skriver inn e-postadressen *@bar.com istedet, kan ingen brukere med epost fra domenet bar.com registrere seg på siden din.";
$ns -> tablerender($caption, $text);

?>
