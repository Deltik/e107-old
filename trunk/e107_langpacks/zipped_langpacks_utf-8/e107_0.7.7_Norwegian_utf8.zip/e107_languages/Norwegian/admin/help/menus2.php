<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/menus2.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Menyhjelp";
$text .= "Du kan bestemme hvor og i hvilken rekekfølge menyene dine skal vises herifra.
Bruk pilene for å flytte opp og ned på menyene til du er helt fornøyd med plasseringen deres.<br />
Menyene i mitten av skjermen er ikke aktiverte. Du kan aktivere dem gjenom å velge en plass å vise dem.
";

$ns -> tablerender("Menyhjelp", $text);

?>
