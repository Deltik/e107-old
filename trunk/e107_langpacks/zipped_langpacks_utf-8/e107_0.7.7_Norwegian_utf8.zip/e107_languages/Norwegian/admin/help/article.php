<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/article.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Fra denne siden kan du legge til en- eller flersidige artikkler.<br />
 Fo en flersidig artikkel kan du separere sidene med teksten [newpage], eks. kommer<br /><code>Test1 [newpage] Test2</code><br /> til å skape en tosidig artikkel med 'Test1' på side 1 og 'Test2' på side 2.
<br /><br />
Om artikkelen din inneholder HTML tagger som du vil bevare så kapsler du inn disse mellom [html] [/html]. Eks. om du skriver teksten '&lt;table>&lt;tr>&lt;td>Hallå &lt;/td>&lt;/tr>&lt;/table>' i artikelen din kommer en tabell som inneholder ordet Hallå til å vises. Om du skriver '[html]&lt;table>&lt;tr>&lt;td>Hello &lt;/td>&lt;/tr>&lt;/table>[/html]' kommer HTMlkoden du skrev til og vises og ikke tabellen som koden skaper.";
$ns -> tablerender("Artikkelhjelp", $text);

?>