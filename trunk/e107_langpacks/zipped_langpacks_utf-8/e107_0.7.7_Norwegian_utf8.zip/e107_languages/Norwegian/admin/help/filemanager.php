<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/filemanager.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan håntere filene i din /files mappe fra denne siden. Om du får en feilmelding om filrettigheter når du laster opp, så kan du prøve å sette mappen du prøver å laste opp til CHMOD 777.";
$ns -> tablerender("Filbehandlerhjelp", $text);

?>
