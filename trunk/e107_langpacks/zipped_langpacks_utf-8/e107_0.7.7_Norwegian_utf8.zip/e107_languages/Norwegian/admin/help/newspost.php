<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/newspost.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Nyhetsposthjelp";
$text = "<b>Generelt</b><br />
Teksten kommer til å vises på hovedsiden. Deu utvidede teksten vises ved å trykke på 'Les mere' linken.
<br />
<br />
<b>Vis bare tittelen</b>
<br />
Aktiver dette for å bare vise nyhetstittelen på førstesiden, med en link til hele nyhetesartikkelen.
<br /><br />
<b>Aktivering</b>
<br />
Om du setter en start og/eller sluttdato på nyheten din kommer den bare til å vises mellom disse datoene.
";
$ns -> tablerender($caption, $text);

?>
