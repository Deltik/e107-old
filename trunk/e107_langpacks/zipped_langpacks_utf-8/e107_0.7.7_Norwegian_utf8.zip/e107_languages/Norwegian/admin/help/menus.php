<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/menus.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

if(!defined('e_HTTP')){ die("Uautorisert tillgang");}
if (!getperms("2")) {
	header("location:".e_BASE."index.php");
	 exit;
}
global $sql;
if(isset($_POST['reset'])){
		for($mc=1;$mc<=5;$mc++){
			$sql -> db_Select("menus","*", "menu_location='".$mc."' ORDER BY menu_order");
			$count = 1;
			$sql2 = new db;
			while(list($menu_id, $menu_name, $menu_location, $menu_order) = $sql-> db_Fetch()){
				$sql2 -> db_Update("menus", "menu_order='$count' WHERE menu_id='$menu_id' ");
				$count++;
			}
			$text = "<b>Menyer er tilbakestilt i databasen</b><br /><br />";
		}
}else{
	unset($text);
}

$text .= "
Du kan bestemme hvor og i hvilken rekekfølge menyene dine skal vises herifra.
Bruk rullegardinmenyen for å flytte opp og ned på menyene til du er helt fornøyd med plasseringen deres.
<br />
<br />
Om menyene dine ikke oppfører seg som de skal så trykk på oppdateringsknappen.
<br />
<form method='post' id='menurefresh' action='".$_SERVER['PHP_SELF']."'>
<div><input type='submit' class='button' name='reset' value='Oppdater' /></div>
</form>
<br />
<div class='indent'><span style='color:red'>*</span> Indikerer at synligheten til menyen er endret</div>
";

$ns -> tablerender("Menyhjelp", $text);

?>
