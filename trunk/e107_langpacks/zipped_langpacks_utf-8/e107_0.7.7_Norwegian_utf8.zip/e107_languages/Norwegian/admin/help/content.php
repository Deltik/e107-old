<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/content.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan legge til en vanlig side til din webside med denne funksjonen. En link til den sye siden kommer til å bli opprettet i sidens hovedlinkmeny. Om du for eksempel lager en side med linknavnet 'Test' kommer en link kalt 'Test' dukke opp i linkmenyen din etter at du har opprettet siden.<br />
Om du vill att din sida skall ha en rubrik, ange den i rutan för sidhuvud.";
$ns -> tablerender("Innholdshjelp", $text);

?>
