<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/upload.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Herfra kan du tillate/forby at brukere laster opp filer, og du kan håntere filene som er lastet opp.";
$ns -> tablerender("Hjelp til offentilge opplastninger", $text);

?>
