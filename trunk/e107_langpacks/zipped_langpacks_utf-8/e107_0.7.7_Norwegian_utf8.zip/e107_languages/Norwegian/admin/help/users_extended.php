<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/users_extended.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Utvidede brukerfelt brukes til å legge til ekstra datafelt av ulike typer som brukerne kan fylle inn på sin profil. Eks. MSN-adresse.";
$ns -> tablerender("Hjelp til utvidede brukerfelt", $text);

?>
