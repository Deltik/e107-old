<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/poll.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du oppretter avstemninger/undersøkelser fra denne siden. Bare skriv inn rubrikken og de ulike alternativene. Forhondsvis det så det ser bra ut og marker ruten for å aktivere den.<br /><br />
For å vise avstemmningen, gå til menysiden og aktiver poll_menu.";

$ns -> tablerender("Avstemmninger", $text);

?>
