<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/wmessage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "På siden her kan du opprette en melding som alltid vises på toppen av førstesiden din når den er akrivert.
 Du kan ha ulike meldinger for gjester, registrete/innloggede medlemmer og administratorer.";
$ns -> tablerender("Hjelp for Velkomstmeldingen", $text);

?>
