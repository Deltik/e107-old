<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/frontpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Førstesiden Hjelp";
$text = "Fra denne siden velger du hva som skal vises som førstesiden på hjemmesiden din. Nyheter er standard.";
$ns -> tablerender($caption, $text);

?>
