<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/review.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Recensioner er linkede artikkler, men de listes i egne menyer.<br />
For en flersidig recension, separer sidene med teksten [newpage], eks. <br /><code>Test1 [newpage] Test2</code><br /> skaper en tosidig recension med 'Test1' på side 1 og 'Test2' på side 2.";
$ns -> tablerender("Recensionshjelp", $text);

?>
