<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/download.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Last opp filene dine til ".e_FILE."downloads mappen, bildene dine til ".e_FILE."downloadimages mappen og thumbnailsbildene til ".e_FILE."downloadthumbs meppen.
<br /><br />
For å opprette en nedlastning så må du først opprette en kategori, og så en underkategori av denne. Etter det kan du gjøre nedlastningen tilgjengelig i underkategorien.";
$ns -> tablerender("Nedlastningshjelp", $text);

?>
