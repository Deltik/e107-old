<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/newsfeed.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan hente og vise andre siders RRS nyhetsfeed på din egen side herifra.<br />Anngi er fulstendige URLen til feeden (eks. http://e107.org/news.xml). Di kan anngi søkevei til et bilde om du ikke liker standardbildet, eller om det ikke er definert noe. Du kan aktiver og deaktivere feeden om siden skulle gå ned.<br /><br />For å se rubrikkene på din side må du aktivere headlines_menu i menysiden.";

$ns -> tablerender("Nyhetsfeed", $text);

?>
