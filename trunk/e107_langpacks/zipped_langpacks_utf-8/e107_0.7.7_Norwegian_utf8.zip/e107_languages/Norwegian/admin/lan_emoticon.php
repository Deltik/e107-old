<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_emoticon.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 11:07:35 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Smilaktivering");
define("EMOLAN_2", "Navn");
define("EMOLAN_3", "Smil");
define("EMOLAN_4", "Aktiver smil?");
define("EMOLAN_5", "Bilde");
define("EMOLAN_6", "Smilkode");
define("EMOLAN_7", "separer flere smilkoder med mellomrom");
define("EMOLAN_8", "Status");
define("EMOLAN_9", "Alternativ");
define("EMOLAN_10", "Aktiv");
define("EMOLAN_11", "Aktiver pakke");
define("EMOLAN_12", "Rediger/konfigurer denne pakken");
define("EMOLAN_13", "Installerte pakker");
define("EMOLAN_14", "Lagre konfigurasjon");
define("EMOLAN_15", "Rediger/konfigurer smil");
define("EMOLAN_16", "Smilkonfigurasjon lagret");
define("EMOLAN_17", "Du har en smilikonpakke som inneholder mellomrom, som ikke er tillatt!");
define("EMOLAN_18", "Venligst skift navn på tilfellene nedenfor slik at de ikke inneholder mellomrom lenger:");
define("EMOLAN_19", "Navn");
define("EMOLAN_20", "Plassering");
define("EMOLAN_21", "Feil");


?>