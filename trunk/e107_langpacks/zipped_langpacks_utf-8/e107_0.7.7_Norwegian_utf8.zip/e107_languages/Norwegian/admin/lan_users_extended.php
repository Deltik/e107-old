<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_users_extended.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 02:54:32 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("EXTLAN_1", "Navn");
define("EXTLAN_2", "Forhåndsvis");
define("EXTLAN_3", "Verdier");
define("EXTLAN_4", "Obligatorisk");
define("EXTLAN_5", "Gjeldende");
define("EXTLAN_6", "Leserrettigheter");
define("EXTLAN_7", "Skriverettigheter");
define("EXTLAN_8", "Handling");
define("EXTLAN_9", "Utvidede brukerfelt");
define("EXTLAN_10", "Feltnavn");
define("EXTLAN_11", "Dette er navnet på feltet som lagres i tabellen, å derfor være unikt");
define("EXTLAN_12", "Felttekst");
define("EXTLAN_13", "Dette er navnet på feltet slik det vises på sidene");
define("EXTLAN_14", "Felttype");
define("EXTLAN_15", "Feltinkludert tekst");
define("EXTLAN_16", "Standardverdi");
define("EXTLAN_17", "Angi hver mulige verdi på en egen rad<br />For DB tabell, se hjelp.");
define("EXTLAN_18", "Obligatorisk");
define("EXTLAN_19", "Brukere må angi er verdi i dette feltet når de oppdaterer innstillingene sine.");
define("EXTLAN_20", "Avgjør hvilke brukere dette feltet gjelder for.");
define("EXTLAN_21", "Dette avgjør hvilke brukere som kommer til å se dette feltet i sine innstillinger.");
define("EXTLAN_22", "Dette avgjør hvem som kan se verdien på brukersiden.<br />OBS: Å sette dette til 'Kun lesning' gjør at det kun er synlig for admin og medlemmen.");
define("EXTLAN_23", "Legg til utvidet felt");
define("EXTLAN_24", "Oppdater utvidet felt");
define("EXTLAN_25", "flytt ned");
define("EXTLAN_26", "flytt opp");
define("EXTLAN_27", "Bekreft sletting");
define("EXTLAN_28", "Ingen utvidede felt definert");
define("EXTLAN_29", "Utvidede brukerfelt lagret.");
define("EXTLAN_30", "Utvidede felt slettet");
define("EXTLAN_33", "Avbryt redigering");
define("EXTLAN_34", "Utvidede felt");
define("EXTLAN_35", "Kategorier");
define("EXTLAN_36", "Ingen tildelt kategori");
define("EXTLAN_37", "Ingen kategorier definerte");
define("EXTLAN_38", "Kategorinavn");
define("EXTLAN_39", "Legg til kategori");
define("EXTLAN_40", "Kategori opprettet");
define("EXTLAN_41", "Kategori slettet");
define("EXTLAN_42", "Oppdater kategori");
define("EXTLAN_43", "Kategori oppdatert");
define("EXTLAN_44", "Kategori");
define("EXTLAN_45", "Legg til nytt felt");
define("EXTLAN_46", "Hjelp");
define("EXTLAN_47", "Legg til nytt parameter");
define("EXTLAN_48", "Legg til ny verdi");
define("EXTLAN_49", "Tillat brukere å skjule");
define("EXTLAN_50", "Sett dette til ja for å la brukeren skjule denne verdien for ikke-admins");
define("EXTLAN_51", "Et hvert gyldig w3c parameter kan angis her<br />f.eks. <i><b>class='tbox' size='40' maxlength='80'</i></b>");
define("EXTLAN_52", "regex valideringskode");
define("EXTLAN_53", "Angi den regex koden som må matches for at det skal være en gyldig innlegning<br />**regex skilletegn kreves**");
define("EXTLAN_54", "regex feiltekst");
define("EXTLAN_55", "Angi feilmeldingen som skal vises om regex valideringen mislykkes.");
define("EXTLAN_56", "Fordefinerte felt");
define("EXTLAN_57", "Aktivert");
define("EXTLAN_58", "Ikke aktivert");
define("EXTLAN_59", "Aktiver");
define("EXTLAN_60", "Deaktiver");
define("EXTLAN_61", "Ingen");
define("EXTLAN_62", "Velg tabell");
define("EXTLAN_63", "Velg felt-ID");
define("EXTLAN_64", "Velg vist verdi");
define("EXTLAN_65", "Nei - Kommer ikke til å vises på registreringssiden");
define("EXTLAN_66", "Ja - Kommer til å vises på registreringssiden");
define("EXTLAN_67", "Nei - Vis p registreringssiden");
define("EXTLAN_68", "Felt:");
define("EXTLAN_69", "har blitt aktivert");
define("EXTLAN_70", "FEIL!! Felt:");
define("EXTLAN_71", "ble ikke aktivert!");
define("EXTLAN_72", "har blitt deaktivert");
define("EXTLAN_73", "ble ikke deaktivert!");
define("EXTLAN_74", "er et reservert feltnavn og kan ikke bli brukt.");
define("EXTLAN_HELP_1", "<b><i>Parametre:</i></b><br />size - størrelse på felt<br />maxlength - maks feltlengde<br /><br />class - feltets css klasse<br />style - css stilstreng<br /><br />regex - regex valideringskode<br />regexfail - validering feiltekst");
define("EXTLAN_HELP_2", "Dette kommer til å være radioknappshjelpeteksten");
define("EXTLAN_HELP_3", "Dette kommer til å være rullegardinhjelpteksten");
define("EXTLAN_HELP_4", "<b><i>Verdier:</i></b><br />Det skal ALLTID finnes tre verdier angitt:<br /><ol><li>dbtable</li><li>felt inneholdende ID</li><li>felt inneholdende verdi</li></ol><br />");
define("EXTLAN_HELP_5", "Dette kommer til å være tekstområdehjelpeteksten");
define("EXTLAN_HELP_6", "Dette kommer til å være integerhjelpeteksten");
define("EXTLAN_HELP_7", "Dette kommer til å være datohjelpeteksten");


?>