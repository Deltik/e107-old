<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_banlist.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 17:14:30 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Blokkering fjernet.");
define("BANLAN_2", "Ingen blokkeringer.");
define("BANLAN_3", "Eksisterende blokkeringer");
define("BANLAN_4", "Ta bort blokkering");
define("BANLAN_5", "Angi IP, epostadresse, eller server");
define("BANLAN_7", "Begrunnelse");
define("BANLAN_8", "Blokker bruker");
define("BANLAN_9", "Blokker bruker fra nettstedet");
define("BANLAN_10", "IP / Epost / Begrunnelse");
define("BANLAN_11", "Auto-blokkering: Flere enn 10 mislykkede innloggingsforsøk");
define("BANLAN_12", "Noter: Reverser DNS er for tiden slått av. Det må slåes på for å tillate banning av vert. Banning ved IP eller e-post fungerer fortsatt som vanlig.");


?>