<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_e107_update.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 02:22:10$
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Handling");
define("LAN_UPDATE_3", "Behøves ikke");
define("LAN_UPDATE_5", "Oppdatering tilgjengelig");
define("LAN_UPDATE_7", "Utført");
define("LAN_UPDATE_8", "Oppdater fra");
define("LAN_UPDATE_9", "til");
define("LAN_UPDATE_10", "Tilgjengelige oppdateringer");
define("LAN_UPDATE_11", ".617 til .7 Oppdatering fortsatt");
define("LAN_UPDATE_12", "En av tabellene innheloder dobble innlegg.");


?>