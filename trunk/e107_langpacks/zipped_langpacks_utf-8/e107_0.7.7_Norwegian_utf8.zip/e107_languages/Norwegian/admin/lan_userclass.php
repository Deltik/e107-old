<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_userclass.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 03:31:03 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Sender informasjonsbrev til");
define("UCSLAN_2", "Oppdaterte privilegier");
define("UCSLAN_3", "Hei");
define("UCSLAN_4", "Dine privilegier er blitt oppdatert på");
define("UCSLAN_5", "Du har nå tilgang til følgende område(r)");
define("UCSLAN_6", "Sett klasse for bruker");
define("UCSLAN_7", "Sett klasser");
define("UCSLAN_8", "Informer bruker");
define("UCSLAN_9", "Klasser oppdatert.");
define("UCSLAN_10", "Hilsen,");


?>