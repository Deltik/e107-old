<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_language.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 18:16:11 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "kunne ikke opprettes. (Finnes allerede)");
define("LANG_LAN_01", "ble slettet(hvis eksisterende) og opprettet.");
define("LANG_LAN_02", "kunne ikke slettes");
define("LANG_LAN_03", "Tabeller");
define("LANG_LAN_05", "Ikke installert");
define("LANG_LAN_06", "Opprett tabeller");
define("LANG_LAN_07", "Slette eksisterende tabeller?");
define("LANG_LAN_08", "Erstatt eksisterende tabeller (alt datainnhold vil gå tapt).");
define("LANG_LAN_10", "Bekreft sletting");
define("LANG_LAN_11", "Slett ikke-markerte tabeller ovenfor (om de eksisterer).");
define("LANG_LAN_12", "Aktiver fler-språkstabeller");
define("LANG_LAN_13", "Flerspråkspreferanser");
define("LANG_LAN_14", "Nettstedets standardspråk");
define("LANG_LAN_15", "Marker for å kopiere data fra standardspråket.(nyttig for linker, nyhetskategorier etc) ");
define("LANG_LAN_16", "Multi-språklig databasebruk");
define("LANG_LAN_17", "Gjeldende språk - Ingen ekstra tabeller trengs.");
define("LANG_LAN_18", "Bruk parkerte Underdomener for å sette språk.");
define("LANG_LAN_19", "eks. se.mittdomene.com for å sette språket til Svensk.");
define("LANG_LAN_20", "Skriv inne hoveddomenet for å muliggjøre eks mittdomene.com");
define("LANG_LAN_21", "Språkverktøy");


?>