<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_administrator.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 16:24:43 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_0", "Ny bruker/admin post opprettet for");
define("ADMSLAN_1", "har nå status.");
define("ADMSLAN_2", "oppdatert i databasen.");
define("ADMSLAN_3", "er nettstedets hovedadministrator og kan ikke endres.");
define("ADMSLAN_4", "Fortsett");
define("ADMSLAN_5", "Feil!");
define("ADMSLAN_6", "er nettstedets hovedadministrator og kan ikke slettes.");
define("ADMSLAN_13", "Eksisterende administratorer");
define("ADMSLAN_16", "Adminnavn");
define("ADMSLAN_17", "Adminpassord");
define("ADMSLAN_18", "Tillatelser");
define("ADMSLAN_19", "Endre nettstedsinnstillinger");
define("ADMSLAN_20", "Endre menyer");
define("ADMSLAN_21", "Legg til nettstedsadministratorer");
define("ADMSLAN_22", "Moderer brukere/blokkeringer etc");
define("ADMSLAN_23", "Opprett/endre egne sider/menyer");
define("ADMSLAN_24", "Behandle filkategorier");
define("ADMSLAN_25", "Last opp/behandle filer");
define("ADMSLAN_26", "Se over nyhetskategorier");
define("ADMSLAN_27", "Se over linkkategorier");
define("ADMSLAN_28", "Ta ned nettstedet for vedlikehold");
define("ADMSLAN_29", "Behandle banner");
define("ADMSLAN_30", "Konfigurer nyhetsstrømmens rubrikker");
define("ADMSLAN_31", "Konfigurer smil");
define("ADMSLAN_32", "Konfigurer innholdet på førstesiden");
define("ADMSLAN_33", "Konfigurer logg/statistikk");
define("ADMSLAN_34", "Konfigurer metatager");
define("ADMSLAN_35", "Konfigurer offentlige filopplastninger");
define("ADMSLAN_36", "Konfigurer bildeinstillinger");
define("ADMSLAN_37", "Moderer kommentarer");
define("ADMSLAN_39", "Post nyheter");
define("ADMSLAN_40", "Post linker");
define("ADMSLAN_41", "Post artikler");
define("ADMSLAN_42", "Post anmeldelser");
define("ADMSLAN_43", "Post innholdssider");
define("ADMSLAN_44", "Post nedlastinger");
define("ADMSLAN_45", "Post avstemninger");
define("ADMSLAN_46", "Velkomstmeldinger");
define("ADMSLAN_47", "Moderer innsendte nyheter");
define("ADMSLAN_49", "Marker alle");
define("ADMSLAN_51", "Fjern alle avmerkninger");
define("ADMSLAN_52", "Oppdater administrator");
define("ADMSLAN_53", "Legg til administrator");
define("ADMSLAN_54", "Nettstedsadministratorer");
define("ADMSLAN_55", "Tomt felt");
define("ADMSLAN_56", "Nettstedsadministrator");
define("ADMSLAN_58", "Nettstedets hovedadministrator");
define("ADMSLAN_59", "Ta bort adminstatus");
define("ADMSLAN_60", "Er du sikker på at du vil fjerne adminstatus fra");
define("ADMSLAN_61", "Administrator slettet");
define("ADMSLAN_62", "Pluginbehandler");
define("ADMSLAN_64", "Tøm systemcache");
define("ADMSLAN_65", "Konfigurer epostinnstillinger og epostutsendelse");
define("ADMSLAN_66", "Konfigurer søk");
define("ADMSLAN_67", "Skan med filinspektøren");
define("ADMSLAN_68", "Konfigurer epostvarsling");
define("ADMSLAN_69", "er allerede en administrator og må endres.");
define("ADMSLAN_70", "Tilbake til administratorlisten");
define("ADMSLAN_71", "Klikk her for å vise privilegier");


?>