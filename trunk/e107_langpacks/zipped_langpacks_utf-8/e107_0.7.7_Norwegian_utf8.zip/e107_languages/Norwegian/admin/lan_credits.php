<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_credits.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 18:25:43 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "e107 credits");
define("CRELAN_1", "Takk til");
define("CRELAN_2", "Nedenfor er en liste over tredjeparts programvare / ressurser brukt i e107. e107's utviklingsteam vil personlig få takke utviklerne av følgende for at de tillater oss å videredistribuere dereskode med e107, og for at de utgir sin programvare under GPL lisensen.");
define("CRELAN_3", "alle retigheter er reservert");
define("CRELAN_4", "Vis e107 utviklingsteamet");
define("CRELAN_5", "Vis tredjepersonsskript");
define("CRELAN_6", "e107 v0.7 ble brakt til deg av ...");
define("CRELAN_7", "versjon");
define("CRELAN_8", "Tilatelse er innvilget|");
define("CRELAN_9", "Lisens");
define("CRELAN_10", "MagpieRSS sørger for en XMLbasert RSSskriver i PHP.");
define("CRELAN_11", "PclZip bibloteket tilbyr kompresjon og dekompresjon av ZIPformaterte arkiv (WinZip,PKZIP).");
define("CRELAN_12", "PclTar tilbyr muligheten å arkivere en liste av filer eller mapper med eller uten kompresjon. Arkivene som blir laget av PclTar er lasbare av de fleste gzip/tar aplikasjoner og av Windows Winzipaplikasjonen.");
define("CRELAN_13", "TinyMCE er en plattforuavhengig webbasert Javascript HTML WYSIWYG editor som er utgitt som åpen kildekode under LGPL av Moxiecode Systems AB. Den har myligheten til å konvertere HTML TEXAREA felt eller andre HTML elementer til editorinnlegg.");
define("CRELAN_14", "Ikoner brukt av e107");
define("CRELAN_15", "E-post overføringsklasse med alle muligheter for PHP");
define("CRELAN_16", "Meny system brukt i JJayyatemaet");
define("CRELAN_17", "Popupkalender widget");
define("CRELAN_18", "PDF støtte");
define("CRELAN_19", "UTF-8 PDF støtte");
define("CRELAN_20", "");
define("CRELAN_21", "Always a pressure..err..pleasure!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Wot? No tea?? 0_0\"");
define("CRELAN_28", "");


?>