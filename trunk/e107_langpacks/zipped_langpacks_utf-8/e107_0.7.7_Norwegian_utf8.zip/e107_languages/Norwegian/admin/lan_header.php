<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_header.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 17:41:27 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Adminnavigering");
define("LAN_head_2", "Serveren din tillater ikke HTTP filopplastninger, så brukerne dine kommer ikke til å kunne laste opp avatarer/filer etc. For å rette på dette, sett file_uploads til On i php.ini og restart serveren. Om du ikke har tilgang til php.ini må du kontakte din webserveradministratoren.");
define("LAN_head_3", "Serveren din kjøres med en 'basekatalog' restriksjon aktivert. Dette forbyr bruken av filer utanfor hjemmekatalogen din og kan med det påvirke visse skript som f.eks. filbehandleren.");
define("LAN_head_4", "Adminområdet");
define("LAN_head_5", "språk vist i adminområdet: ");
define("LAN_head_6", "Plugininfo");


?>