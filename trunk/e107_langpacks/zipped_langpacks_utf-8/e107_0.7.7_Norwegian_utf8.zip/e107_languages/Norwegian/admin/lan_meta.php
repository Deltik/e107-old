<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_meta.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 20:09:16 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Metatager oppdatert i databasen");
define("METLAN_2", "Angi ytterligere metatager");
define("METLAN_3", "Angi nye metataginstillinger");
define("METLAN_4", "Oppdatert");
define("METLAN_5", "skriv inn beskrivelsen din");
define("METLAN_6", "skriv, en, liste, med, dine, nøkkelord, her");
define("METLAN_7", "skriv inn din copyrightinfo her");
define("METLAN_8", "Metatager");
define("METLAN_9", "Beskrivelse");
define("METLAN_10", "Nøkkelord");
define("METLAN_11", "Copyright");
define("METLAN_12", "Bruk nyhetstittel og sammendrag som mestabeskrivelse for nyhetssider.");
define("METLAN_13", "Forfatter");


?>