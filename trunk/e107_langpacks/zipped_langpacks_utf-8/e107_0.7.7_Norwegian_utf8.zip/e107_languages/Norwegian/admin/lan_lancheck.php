<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_lancheck.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 17:53:08 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Velg språk å verifisere");
define("LAN_CHECK_2", "Start verifisering");
define("LAN_CHECK_3", "Verifisering av");
define("LAN_CHECK_4", "Fil mangler!");
define("LAN_CHECK_5", "Uttrykk mangler!");
define("LAN_CHECK_7", "uttrykk");
define("LAN_CHECK_8", "En fil mangler...");
define("LAN_CHECK_9", " filer mangler...");
define("LAN_CHECK_10", "Kritiskt feil: ");
define("LAN_CHECK_11", "Ingen filer mangler!");
define("LAN_CHECK_12", "En fil er mangelfull...");
define("LAN_CHECK_13", " filer er mangelfulle...");
define("LAN_CHECK_14", "Alle eksisterende filer er gyldige!");
define("LAN_CHECK_15", "Ulovlig tegn funnet før '&lt;?php'");
define("LAN_CHECK_16", "Orginal fil");
define("LAN_CHECK_17", "Et skriveproblem oppsto under lagring av fil.");
define("LAN_CHECK_18", "Språkfiler i standard format er IKKE tilgjengelig for denne plugin/tema.");
define("LAN_CHECK_19", "Ikke-UTF-8 tegn er funnet!");


?>