<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_frontpage.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 14:09:06 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Førstesideinstillinger oppdatert.");
define("FRTLAN_2", "Sett førsteside for");
define("FRTLAN_6", "Linker");
define("FRTLAN_12", "Oppdater førstesidens instillinger");
define("FRTLAN_13", "Førstesideinstillinger");
define("FRTLAN_15", "Annet (oppgi URL):");
define("FRTLAN_16", "Feil: ingen hovedinnholdstittel valgt");
define("FRTLAN_17", "Feil: ingen innholdsunderkategori valgt");
define("FRTLAN_18", "Feil: ingen innholdspost valgt");
define("FRTLAN_19", "hovedinnholdstittel");
define("FRTLAN_20", "innholdskategori");
define("FRTLAN_21", "innholdspost");
define("FRTLAN_26", "Alle brukere");
define("FRTLAN_27", "Gjester");
define("FRTLAN_28", "Medlemmer");
define("FRTLAN_29", "Administratorer");
define("FRTLAN_31", "Alle brukere");
define("FRTLAN_32", "Brukerklasse");
define("FRTLAN_33", "Eksisterende instillinger");
define("FRTLAN_34", "Side");


?>