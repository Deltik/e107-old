<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_footer.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 14:07:19 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Nettsted");
define("FOOTLAN_2", "Hovedadmin");
define("FOOTLAN_3", "Versjon");
define("FOOTLAN_4", "bygg");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "av");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installasjonsdato");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "vert");
define("FOOTLAN_11", "PHP versjon");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Nettstedsinfo");
define("FOOTLAN_14", "Vis dok.");
define("FOOTLAN_15", "Dokumentasjon");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Tegnoppsett");
define("FOOTLAN_18", "Filer");
define("FOOTLAN_19", "Mapper");
define("FOOTLAN_20", "Totalt");
define("FOOTLAN_21", "Størrelse");

?>
