<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_ugflag.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 04:39:14 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "vedlikeholdsinnstillinger lagret");
define("UGFLAN_2", "Aktiver vedlikeholdsflagget");
define("UGFLAN_3", "Oppdater vedlikeholdsinnstillinger");
define("UGFLAN_4", "Vedlikeholdsinnstillinger");
define("UGFLAN_5", "Tekst å vise når nettstedet er nede");
define("UGFLAN_6", "La stå tomt for å vise standardmelding");


?>