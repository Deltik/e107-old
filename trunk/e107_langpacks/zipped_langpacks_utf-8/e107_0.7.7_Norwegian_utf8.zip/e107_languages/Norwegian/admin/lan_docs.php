﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_docs.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 18:46:51 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

?>
