<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_db_verify.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 18:41:36 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Kan ikke lese SQL-datafilen<br /><br />Forsikre deg om at filen <b>core_sql.php</b> finnes i <b>/admin/sql</b> katalogen.");
define("DBLAN_2", "Bekrefter alt");
define("DBLAN_4", "Tabell");
define("DBLAN_5", "Felt");
define("DBLAN_6", "Status");
define("DBLAN_7", "Notater");
define("DBLAN_8", "Stemmer ikke");
define("DBLAN_9", "Eksisterende");
define("DBLAN_10", "skal være");
define("DBLAN_11", "Felt mangler");
define("DBLAN_12", "Ekstra felt!");
define("DBLAN_13", "Tabell mangler!");
define("DBLAN_14", "Velg tabell(er) å validere");
define("DBLAN_15", "Start verifisering");
define("DBLAN_16", "SQL verifisering");
define("DBLAN_17", "Tilbaka");
define("DBLAN_18", "tabeller");
define("DBLAN_19", "Forsøk å korrigere");
define("DBLAN_20", "Forsøker å korrigere tabeller");
define("DBLAN_21", "Korriger valgt objekt");


?>