<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_image.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 11:07:35 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("IMALAN_1", "Aktiver bildeposting");
define("IMALAN_2", "Vis bilder, detta påvirker hele nettstedet (kommentarer, chatruta etc)");
define("IMALAN_3", "Metode for størrelsesendring");
define("IMALAN_4", "Metode som benyttes til å endre størrelse på bilder, enten GD1/2 biblioteket, eller ImageMagick");
define("IMALAN_5", "Sti til ImageMagick (hvis valgt)");
define("IMALAN_6", "Full sti til ImageMagick konverteringsmodul");
define("IMALAN_7", "Billedinnstillinger");
define("IMALAN_8", "Oppdater billedinnstillinger");
define("IMALAN_9", "Billedinnstillinger oppdatert");
define("IMALAN_10", "Klasse for bildeposting");
define("IMALAN_11", "Begrens hvilke brukere som kan poste bilder (hvis bildeposting er aktivert ovenfor)");
define("IMALAN_12", "Metode ved inaktive bilder");
define("IMALAN_13", "Hva som skal gjøres med postede bilder om posting avaktiveres");
define("IMALAN_14", "Vis bildets URL");
define("IMALAN_15", "Vis ingenting");
define("IMALAN_16", "Vis opplastede avatarer");
define("IMALAN_17", "Klikk her");
define("IMALAN_18", "Opplastede bilder");
define("IMALAN_21", "Bildet brukt av");
define("IMALAN_22", "Bildet ikke i bruk");
define("IMALAN_23", "Avatar");
define("IMALAN_24", "Fotografi");
define("IMALAN_25", "Klikk her for å slette alle ubrukte bilder");
define("IMALAN_26", "bilde(r) slettet");
define("IMALAN_28", "slettet");
define("IMALAN_29", "Ingen bilder");
define("IMALAN_30", "Alle (offentlig)");
define("IMALAN_31", "Kun gjester");
define("IMALAN_32", "Kun medlemmer");
define("IMALAN_33", "Kun admin");
define("IMALAN_34", "Aktiver sleight");
define("IMALAN_35", "Fikser transparente PNG-24 bilder med alpha transparens i IE 5/6 (Gjelder hele nettstedet)");
define("IMALAN_36", "Valider avatarstørrelse og adgang");
define("IMALAN_37", "Avatarvalidering");
define("IMALAN_38", "Maksimum tillatt bredde");
define("IMALAN_39", "Maksimum tillatt høyde");
define("IMALAN_40", "For bred");
define("IMALAN_41", "For høy");
define("IMALAN_42", "Ikke funnet");
define("IMALAN_43", "Slett opplastet avatar");
define("IMALAN_44", "Slett ekstern avatar");
define("IMALAN_45", "Ikke funnet");
define("IMALAN_46", "For stor");
define("IMALAN_47", "Totalt antall opplastede avatarer");
define("IMALAN_48", "Totalt antall eksterne avatarer");
define("IMALAN_49", "Brukere med avatarer");
define("IMALAN_50", "Totalt");
define("IMALAN_51", "Avatar for");


?>