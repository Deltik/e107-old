<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_updateadmin.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 04:36:07 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Feil - send igjen");
define("UDALAN_2", "Innstillinger oppdatert");
define("UDALAN_3", "Innstillinger oppdatert for");
define("UDALAN_4", "Navn");
define("UDALAN_5", "Passord");
define("UDALAN_6", "Oppgi passord igjen");
define("UDALAN_7", "Endre passord");
define("UDALAN_8", "Passordoppdatering for");


?>