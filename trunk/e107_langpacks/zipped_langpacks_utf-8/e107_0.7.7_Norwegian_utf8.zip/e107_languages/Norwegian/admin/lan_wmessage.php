<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_wmessage.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 02:49:00 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Melding for gjester");
// define("WMGLAN_2", "Melding for medlemmer");
// define("WMGLAN_3", "Melding for administratorer");
// define("WMGLAN_4", "Send");
// define("WMGLAN_5", "Sett velkomstmelding");
// define("WMGLAN_6", "Aktiver?");
// define("WMGLAN_7", "Innstilling for velkomstmelding oppdatert.");

define("WMLAN_00","Velkomstmelding");
define("WMLAN_01","Opprett ny melding");
define("WMLAN_02","Melding");
define("WMLAN_03","Synlighet");
define("WMLAN_04","Meldingstekst");

define("WMLAN_05","Kapsle inn");
define("WMLAN_06","Hvis merket kommer meldingen til å vises inne i en rute");
define("WMLAN_07","Overstyr systemstandard for å bruke {WMESSAGE} kortkode:");
// define("WMLAN_08","Innstillinger");

define("WMLAN_09","Ingen velkomsthilsen satt enda");
define("WMLAN_10","Meldingens overskrift");

?>
