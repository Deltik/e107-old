<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_mailout.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 18:40:43 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "Lagre endringer");
define("PRFLAN_63", "Send testepost");
define("PRFLAN_64", "Når du klikker på knappen kommer et testbrev til å sendes til hovedadmins epostadresse");
define("PRFLAN_65", "Klikk for å sende brev til");
define("PRFLAN_66", "Testbrev fra");
define("PRFLAN_67", "Dett er et testbrev. Det ser ut til at e-postinnstillingene dine fungerer!\n\nHilsen\n e107-nettstedssystemet.");
define("PRFLAN_68", "E-posten kunne ikke sendes. Det ser ut til at epostserveren ikke er riktig konfigurertfor å sende epost, prøv heller å benyttet SMTP eller kontakt webserveradministrator og be om at sendmail/epostserverinstillingene blir kontrollert.");
define("PRFLAN_69", "Brevet ble sendt, kontroller innboksen din.");
define("PRFLAN_70", "Epost sendemetode");
define("PRFLAN_71", "Om du er usikker, la stå som PHP");
define("PRFLAN_72", "SMTP server");
define("PRFLAN_73", "SMTP brukernavn");
define("PRFLAN_74", "SMTP passord");
define("PRFLAN_75", "Epostbrevet kunne ikke sendes. Kontroller SMTP instillingene, eller deaktiver SMTP og prøv igjen.");
define("MAILAN_01", "Fra navn");
define("MAILAN_02", "Fra epost");
define("MAILAN_03", "Til");
define("MAILAN_04", "Cc");
define("MAILAN_05", "Bcc");
define("MAILAN_06", "Emne");
define("MAILAN_07", "Vedlegg");
define("MAILAN_08", "Send epost");
define("MAILAN_09", "Bruk temastil");
define("MAILAN_10", "Bruker abonnement");
define("MAILAN_11", "Sett inn variabler");
define("MAILAN_12", "Alle medlemmer");
define("MAILAN_13", "Alle ubekreftede medlemmer ");
define("MAILAN_14", "Det anbefales at du bruker SMTP for å sende store mengder epost - still inn i innstillinger nedenfor.");
define("MAILAN_15", "Epostutsendelse");
define("MAILAN_16", "Brukernavn");
define("MAILAN_17", "Registreringslink");
define("MAILAN_18", "Bruker-id");
define("MAILAN_19", "Det finnes ingen epostadresse angitt for nettstedsadmin. Kontroller innstillingene og prøv igjen.");
define("MAILAN_20", "Sti til sendmail");
define("MAILAN_21", "Massebrev-poster");
define("MAILAN_22", "Det finnes for tiden ingen lagrede poster");
define("MAILAN_23", "brukerklasse: ");
define("MAILAN_24", "brev(et) er klart/klare til å sendes");
define("MAILAN_25", "Pause");
define("MAILAN_26", "Pause av massemailig vær");
define("MAILAN_27", "eposterer");
define("MAILAN_28", "Pauselengde");
define("MAILAN_29", "sekunder");
define("MAILAN_30", "Mere en 30 sekunder kan få nettleseren til å time ut");
define("MAILAN_31", "Bearbeiding av retunerte eposter");
define("MAILAN_32", "Epost adresse");
define("MAILAN_33", "Inkommende mail");
define("MAILAN_34", "Kontonavn");
define("MAILAN_35", "Passord");
define("MAILAN_36", "Slett retunerte eposter etter sjekk");
define("MAILAN_37", "Fortsett");
define("MAILAN_38", "Avbryt");
define("MAILAN_39", "E-posting");
define("MAILAN_40", "Du må forandre navn fra <b>e107.htaccess</b> til <b>.htaccess</b> i");
define("MAILAN_41", "før du sender mail fra denne siden.");
define("MAILAN_42", "Advarsel");
define("MAILAN_43", "Brukernavn");
define("MAILAN_44", "Brukers Login");
define("MAILAN_45", "Brukers E-post");
define("MAILAN_46", "Brukermach");
define("MAILAN_47", "inneholder");
define("MAILAN_48", "er lik");
define("MAILAN_49", "Id");
define("MAILAN_50", "Forfatter");
define("MAILAN_51", "Emne");
define("MAILAN_52", "Lastmod");
define("MAILAN_53", "Adminer");
define("MAILAN_54", "Self");
define("MAILAN_55", "Brukerklasse");
define("MAILAN_56", "Send E-post");
define("MAILAN_57", "Hold SMTPsesjon i live");
define("MAILAN_58", "Det var et problem med vedlegget:");
define("MAILAN_59", "E-psot prossess");
define("MAILAN_60", "Sender...");
define("MAILAN_61", "Det er ingen gjennværende e-poster å sende.");
define("MAILAN_62", "E-poster som er send:");
define("MAILAN_63", "E-poster som feilet:");
define("MAILAN_64", "Totalt til som er gått:");
define("MAILAN_65", "sekunder");
define("MAILAN_66", "Suksessfult kanselert");
define("MAILAN_67", "bruk 'POP før SMTP' godkjenning");


?>