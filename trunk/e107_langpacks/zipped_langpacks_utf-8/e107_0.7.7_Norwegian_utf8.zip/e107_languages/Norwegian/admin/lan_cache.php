<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_cache.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 17:38:39 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Cachesystemstatus");
define("CACLAN_2", "Sett cachestatus");
define("CACLAN_3", "Cachesystem");
define("CACLAN_4", "Cachestatus satt");
define("CACLAN_5", "Tøm cache");
define("CACLAN_6", "Cache tøm");
define("CACLAN_7", "Cache inaktivert");
define("CACLAN_9", "Cachedata lagret til diskfil");
define("CACLAN_10", "Cachebiblioteket skrivebeskyttat. Kontoller at katalogen er satt til CHMOD 0777");


?>