<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_userinfo.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 03:27:28 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Kunne ikke finne posterens IP-adresse - ingen informasjon tilgjengelig.");
define("USFLAN_3", "Meldingen postet fra IP-adresse");
define("USFLAN_4", "Server");
define("USFLAN_5", "Klikk her for å overføre IP-adressen til admins blokkeringsside");
define("USFLAN_6", "BrukerID");
define("USFLAN_7", "Brukerinformasjon");


?>