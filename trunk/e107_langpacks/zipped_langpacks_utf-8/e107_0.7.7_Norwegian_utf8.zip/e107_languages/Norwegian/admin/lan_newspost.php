<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_newspost.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/05 01:15:10 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Nyhet slettet.");
define("NWSLAN_2", "Marker bekreftelsesruten for å slette denne nyheten.");
define("NWSLAN_3", "Ingen nyheter enda.");
define("NWSLAN_4", "Eksisterende nyheter");
define("NWSLAN_5", "Åpne HTML-editor");
define("NWSLAN_6", "Kategori");
define("NWSLAN_9", "marker for å bekrefte");
define("NWSLAN_10", "Ingen nyhetskategorier");
define("NWSLAN_11", "Legg til/rediger kategorier");
define("NWSLAN_12", "Tittel");
define("NWSLAN_13", "Tekst");
define("NWSLAN_14", "Utvidet");
define("NWSLAN_15", "Kommentarer");
define("NWSLAN_18", "Tillat at kommentarer postes til denne nyheten");
define("NWSLAN_19", "Aktivering");
define("NWSLAN_21", "Aktiv mellom");
define("NWSLAN_22", "Synlighet");
define("NWSLAN_24", "Forhåndsvis igjen");
define("NWSLAN_25", "Oppdater nyhet i databasen");
define("NWSLAN_26", "Post nyhet til databasen");
define("NWSLAN_27", "Forhåndsvisning");
define("NWSLAN_29", "Nyhet");
define("NWSLAN_31", "Nyhetsemne");
define("NWSLAN_32", "slettet");
define("NWSLAN_33", "Nyhetskategori");
define("NWSLAN_34", "Innsendt nyhet");
define("NWSLAN_35", "Nyhetskategori lagret");
define("NWSLAN_36", "Nyhetskategori oppdatert");
define("NWSLAN_37", "Er du sikker på at du vil slette denne kategori?");
define("NWSLAN_38", "Er du sikker på at du vil slette denne innsendte nyheten?");
define("NWSLAN_39", "Er du sikker på at du vil slette denne nyheten?");
define("NWSLAN_40", "Tittel");
define("NWSLAN_42", "Ingen tittel");
define("NWSLAN_43", "Ingen nyheter");
define("NWSLAN_44", "Nyheter førstesida");
define("NWSLAN_45", "Opprett nyhet");
define("NWSLAN_46", "Kategorier");
define("NWSLAN_47", "Innsendte nyheter");
define("NWSLAN_48", "Nyhetsalternativ");
define("NWSLAN_49", "Innsendt av");
define("NWSLAN_51", "Eksisterende nyhetskategorier");
define("NWSLAN_52", "Kategorinavn");
define("NWSLAN_53", "Kategoriikon");
define("NWSLAN_54", "Vis bilder");
define("NWSLAN_55", "Oppdater nyhetskategori");
define("NWSLAN_56", "Opprett nyhetskategori");
define("NWSLAN_57", "Artikell");
define("NWSLAN_58", "Post");
define("NWSLAN_59", "Ingen innsendte nyheter");
define("NWSLAN_62", "Gå til siden: ");
define("NWSLAN_63", "Søk i nyheter");
define("NWSLAN_66", "Last opp");
define("NWSLAN_67", "Bilde");
define("NWSLAN_68", "Fil");
define("NWSLAN_69", "Last opp et bilde eller en fil for bruke i nyheten");
define("NWSLAN_72", "Vis bare nyheter mellom visse datoer");
define("NWSLAN_73", "Visningstype");
define("NWSLAN_74", "Velg hvor og hvordan nyheten skal postes");
define("NWSLAN_75", "Standard - post på førstesiden");
define("NWSLAN_76", "Kun tittel - post på førstesiden");
define("NWSLAN_77", "Post til annen nyhetsmeny");
define("NWSLAN_79", "Tøm skjemaet");
define("NWSLAN_83", "Utvidet nyhetspost");
define("NWSLAN_84", "Velg hvilke brukere som vil se nyheten");
define("NWSLAN_86", "Vis nyhetskategoriens fotmeny");
define("NWSLAN_87", "Nyhetskategorikolonner?");
define("NWSLAN_88", "Antall nyheter å vise pr side?");
define("NWSLAN_89", "Lagre nyhetsinnstillinger");
define("NWSLAN_90", "Nyhetsinnstillinger");
define("NWSLAN_100", "Aktiver bildeopplastning på siden for innsending av nyhet");
define("NWSLAN_101", "Automatisk skalering av innsendt bilde");
define("NWSLAN_102", "bredde i pixler<br /> eller la stå åpent for deaktivering.");
define("NWSLAN_103", "Post igjen");
define("NWSLAN_104", "av");
define("NWSLAN_105", "Marker ruten for å oppdatere tidsstempelet på nyheten til aktuell tid");
define("NWSLAN_106", "Tilgang til Send inn nyhet for:");
define("NWSLAN_107", "Aktiver WYSIWYG editor på Send inn nyhet siden.");
define("NWSLAN_108", "på");
define("NWSLAN_111", "Vis nytt dato-hode");
define("NWSLAN_112", "Om denne ruten er avkrysset kommer en rute med dato til å vises over nyheter postet på en ny dag. Nyttig for å skille mellom nyheter postet på ulike dager.");
define("NWSLAN_113", "Bruk en ikke-standard mal for nyhetslayouten");
define("NWSLAN_114", "om temaet du bruker har en layoutmal for nyheter, bruk dette i stedet for standardlayouten");
define("NWSLAN_115", "Nyhetsposter å vise i arkiv?");
define("NWSLAN_116", "Oppdater først preferensene med det endrede antallet pr side, oppdatter deretter igjen etter at du har satt preferansene for nyhetsarkivet. (0 er deaktivert)");
define("NWSLAN_117", "Sett rubrikken for nyhetsarkivet");
define("NWSLAN_119", "Innstillinger lagret");
define("NWSLAN_120", "Tekst til å vise høyest opp på Send inn nyhet");
define("LAN_NEWS_5", "Feil! - Kunne ikke oppdatere nyhetsemnet i databasen!");
define("LAN_NEWS_6", "Nyhet innlagt i databasen.");
define("LAN_NEWS_7", "Feil! - Kunne ikke lagre nyheten i databasen!");
define("LAN_NEWS_9", "Kun overskrift valgt - <b>kun nyhetsoverskriften kommer til å vises</b>");
define("LAN_NEWS_10", "Denne nyheten er <b>inaktiv</b> (Den kommer inte att synas pÃ¥ fÃ¶rstasidan). ");
define("LAN_NEWS_11", "Denne nyheten er <b>aktiv</b> (Den kommer til å vises på førstesiden). ");
define("LAN_NEWS_12", "Kommentarer er <b>på</b>.");
define("LAN_NEWS_13", "Kommentarer er <b>av</b>.");
define("LAN_NEWS_14", "<br />Aktivert periode: ");
define("LAN_NEWS_15", "Tekstlengde: ");
define("LAN_NEWS_16", "t. utvidet lengde: ");
define("LAN_NEWS_17", "t.");
define("LAN_NEWS_18", "Info");
define("LAN_NEWS_19", "Nå");
define("LAN_NEWS_21", "Nyhet uppdatert i databasen.");
define("LAN_NEWS_22", "Minibilde");
define("LAN_NEWS_23", "Velg et minibilde/ikon for denne nyheten");
define("LAN_NEWS_24", "Bilde + Auto-minibilde");
define("LAN_NEWS_25", "Auto-minibildestørrelse");
define("LAN_NEWS_26", "legg til en ny opplastning");
define("LAN_NEWS_27", "Sammendrag");
define("LAN_NEWS_28", "Klistret");
define("LAN_NEWS_29", "Velg om nyheten skal være 'klistret'");
define("LAN_NEWS_30", "Hvis valgt kommer nyheten til å vises over alle andre");
define("LAN_NEWS_31", "Denne nyheten er <b>klistret</b> (den kommer til å vises over alle andre). ");
define("LAN_NEWS_32", "Tidstempel");
define("LAN_NEWS_33", "Sett tidsstempel for denne nyheten.");
define("LAN_NEWS_34", "Kilder");
define("LAN_NEWS_35", "Angi kilders URL'er");
define("LAN_NEWS_36", "<b>Pingback</b> (send en pingback til alle URL'er i denne posten)");
define("LAN_NEWS_37", "<b>Kilders URL'er:</b> (en URL pr rad)");
define("LAN_NEWS_38", "Sett inn bilder");
define("LAN_NEWS_39", "klikk på fil for å sette inn ved markørposisjon");
define("LAN_NEWS_40", "Sett inn nedlastningslinker");
define("LAN_NEWS_42", "Filer");
define("LAN_NEWS_44", "Kilder ikke aktivert.");
define("LAN_NEWS_45", "ID");
define("LAN_NEWS_46", "Nyhetsemnet ble ikke oppdatert, så ingen endringer ble gjort.");
define("LAN_NEWS_48", "Ingen bilder");
define("LAN_NEWS_49", "Render-type");


?>