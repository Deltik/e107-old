<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/admin/lan_banner.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/04 17:17:31 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("BNRLAN_1", "Banner slettet.");
define("BNRLAN_2", "Vennligst bekreft at du vil slette dette banneret - når det er slettet kan det ikke gjenopprettes");
define("BNRLAN_5", "Bekreft sletting av banner");
define("BNRLAN_6", "Sletting avbrutt.");
define("BNRLAN_7", "Eksisterende banner");
define("BNRLAN_8", "Banner ID");
define("BNRLAN_9", "Klient");
define("BNRLAN_10", "Klikk");
define("BNRLAN_11", "Klikk %");
define("BNRLAN_12", "Visninger");
define("BNRLAN_13", "Visninger igjen");
define("BNRLAN_15", "Foreløpig ingen banner.");
define("BNRLAN_16", "Ubegrenset");
define("BNRLAN_17", "Ingen");
define("BNRLAN_21", "Slutter");
define("BNRLAN_22", "Oppdater banner");
define("BNRLAN_23", "Legg til nytt banner");
define("BNRLAN_24", "Kampanje");
define("BNRLAN_25", "velg eksisterende kampanje");
define("BNRLAN_26", "oppgi ny kampanje");
define("BNRLAN_27", "Klient");
define("BNRLAN_28", "velg eksisterende klient");
define("BNRLAN_29", "oppgi ny klient");
define("BNRLAN_30", "Klientinnlogging");
define("BNRLAN_31", "Klientpassnord");
define("BNRLAN_32", "Bannerbilde");
define("BNRLAN_33", "Klikk URL");
define("BNRLAN_34", "Visninger innkjøpt");
define("BNRLAN_35", "ubegrenset");
define("BNRLAN_36", "Startdato");
define("BNRLAN_37", "Sluttdato");
define("BNRLAN_38", "tom = ingen tidsbegrensning");
define("BNRLAN_39", "Vises for brukerklasse");
define("BNRLAN_40", "Oppdater banner");
define("BNRLAN_41", "Opprett nytt banner");
define("BNRLAN_42", "Banner rotationssystem");
define("BNRLAN_43", "VÃ¤lj bannerbild");
define("BNRLAN_45", "Startar");
define("BNRLAN_46", "Kod");
define("BNRLAN_58", "banners fÃ¶rstasida");
define("BNRLAN_59", "skapa ny banner");
define("BNRLAN_60", "kampanjer");
define("BNRLAN_61", "bannermeny ");
define("BNRLAN_62", "banneralternativ");
define("BNRLAN_63", "Banner opprettet");
define("BNRLAN_64", "Banner uppdatert");
define("BANNER_MENU_L1", "Annonse");
define("BANNER_MENU_L2", "Bannermenykonfigurasjon lagret");
define("BANNER_MENU_L3", "Overskrift");
define("BANNER_MENU_L5", "Bannerkonfigurasjon");
define("BANNER_MENU_L6", "Velg kampanjer å vise i menyen");
define("BANNER_MENU_L7", "Tilgjengelige kampanjer");
define("BANNER_MENU_L8", "Valgte kampanjer");
define("BANNER_MENU_L9", "Slett valgte");
define("BANNER_MENU_L10", "Rendertype");
define("BANNER_MENU_L12", "enkel");
define("BANNER_MENU_L13", "i rute med overskrift");
define("BANNER_MENU_L18", "Oppdater menyinnstillinger");
define("BANNER_MENU_L19", "antall bannere å vise:<br />dette blir bare brukt når flere kanpanjer er valgt.");


?>