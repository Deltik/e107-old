﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_subcontent.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 01:07:52 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "Takk, artikkelen din er blitt lagret og vil bli gjennomlest av en nettstedsadministrator så snart som mulig.");
define("ARLAN_1", "Tomt felt.");
define("ARLAN_2", "Takk, anmeldelsen din er blitt lagret og vil bli gjennomlest av en nettstedsadministrator så snart som mulig.");
define("ARLAN_15", "Send inn artikkel");
define("ARLAN_17", "Tittel");
define("ARLAN_18", "Undertittel");
define("ARLAN_19", "Oppsumering");
define("ARLAN_20", "Artikkel");
define("ARLAN_21", "Tillat kommentarer?");
define("ARLAN_22", "På");
define("ARLAN_23", "Av");
define("ARLAN_24", "Legg til epost/utskrift-ikoner?");
define("ARLAN_25", "Ja");
define("ARLAN_26", "Nei");
define("ARLAN_27", "Send inn artikkel");
define("ARLAN_28", "Forhåndsvisning");
define("ARLAN_55", "Synlig for");
define("ARLAN_73", "Åpne HTML-editor");
define("ARLAN_74", "Kategori");
define("ARLAN_75", "Ingen");
define("ARLAN_82", "Forfatterdetaljer");
define("ARLAN_84", "forfatterens navn");
define("ARLAN_85", "forfatterens epostadresse");
define("ARLAN_86", "Anmeldelse");
define("ARLAN_87", "Karakter");
define("ARLAN_88", "Velg karakter");
define("ARLAN_89", "Send inn anmeldelsen");

define("ARLAN_90", "Tomt felt, klikk på tilbakeknappen i nettleseren din og se til at alle felt er utfylt.");
define("ARLAN_91", "Forhåndsvis igjen");
define("ARLAN_92", "Oppgi navn/epostadresse");


define("ARLAN_93", "artikkel");
define("ARLAN_94", "anmeldelse");
define("ARLAN_95", "Innsending av artikler fra brukerne er midlertidig stengt");
define("ARLAN_96", "Innsending av anmeldelser fra brukerne er midlertidig stengt");
define("ARLAN_97", "Du har ikke tilstrekkelige rettigheter til å sende inn artikler");
define("ARLAN_98", "Du har ikke tilstrekkelige rettigheter til å sende inn anmeldelser");


define("ARLAN_99", "Hva ønsker du å sende inn?");
define("ARLAN_100", "Nyhet");
define("ARLAN_101", "Hendelse");
define("ARLAN_102", "Artikkel");
define("ARLAN_103", "Anmeldelse");
define("ARLAN_104", "Link");
define("ARLAN_105", "Fil");
define("ARLAN_106", "Send inn");

?>
