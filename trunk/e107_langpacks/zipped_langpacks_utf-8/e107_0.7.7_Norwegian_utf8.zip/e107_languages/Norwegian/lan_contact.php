<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANCONTACT_01", "Kontaktsdetaljer");
define("LANCONTACT_02", "Kontaktsjema");
define("LANCONTACT_03", "Skriv navnet ditt:");
define("LANCONTACT_04", "Epostadresse:");
define("LANCONTACT_05", "Beskjedens emne:");
define("LANCONTACT_06", "Skriv din beskjed:");
define("LANCONTACT_07", "Send en kopi av meldingen til din egen epost ");
define("LANCONTACT_08", "Send");
define("LANCONTACT_09", "Beskjeden din ble sent.");
define("LANCONTACT_10", "Det oppsto et problem med sending av beskjeden din.");
define("LANCONTACT_11", "Epostadressen din ser ikke ut til å være gyldig. Venligst sjekk denne og prøv igjen.");
define("LANCONTACT_12", "Beskjeden din var for kort.");
define("LANCONTACT_13", "Vensligst inkluder et emne.");
define("LANCONTACT_14", "Send beskjed til:");
define("LANCONTACT_15", "Feil kode ble skrevet:");
define("LANCONTACT_16", "Skriv kode:");


?>