<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_parser_functions.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:32:53 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Gjest");
define("LAN_WROTE", "skerv"); // as in John wrote.."");


?>