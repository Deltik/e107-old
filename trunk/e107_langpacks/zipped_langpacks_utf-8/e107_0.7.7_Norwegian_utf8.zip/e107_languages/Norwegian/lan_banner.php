<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_banner.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/29 19:20:49 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner");
define("BANNERLAN_16", "Brukernavn:");
define("BANNERLAN_17", "Passord:");
define("BANNERLAN_18", "Fortsett");
define("BANNERLAN_19", "Venligst skriv inn din klientlogin og passord for å fortsette");
define("BANNERLAN_20", "Beklager men vi var ikke i stand til å finne disse detaljene i databasen. Venligst kontakt sidens administrator for detaljer.");
define("BANNERLAN_21", "Banner Statistikk");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "Banner ID");
define("BANNERLAN_24", "Clickthroughs");
define("BANNERLAN_25", "Klikk %");
define("BANNERLAN_26", "Inntrykk");
define("BANNERLAN_27", "Inntrykk kjøpt");
define("BANNERLAN_28", "Inntrykk igjen");
define("BANNERLAN_29", "Ingen banner");
define("BANNERLAN_30", "ubegrenset");
define("BANNERLAN_31", "Ikke anvendelig");
define("BANNERLAN_32", "Ja");
define("BANNERLAN_33", "Nei");
define("BANNERLAN_34", "Slutter:");
define("BANNERLAN_35", "Clickthrough IPadresser");
define("BANNERLAN_36", "Aktiv:");
define("BANNERLAN_37", "Starter:");
define("BANNERLAN_38", "Feil");


?>