<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_ren_help.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:34:49 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LANHELP_1", "Svart");
define("LANHELP_2", "Blå");
define("LANHELP_3", "Brun");
define("LANHELP_4", "Cyan");
define("LANHELP_5", "Mørkeblå");
define("LANHELP_6", "Mørkerød");
define("LANHELP_7", "Grønn");
define("LANHELP_8", "Indigo");
define("LANHELP_9", "Oliven");
define("LANHELP_10", "Oransje");
define("LANHELP_11", "Rød");
define("LANHELP_12", "Fiolett");
define("LANHELP_13", "Hvit");
define("LANHELP_14", "Gul");
define("LANHELP_15", "Mini");
define("LANHELP_16", "Liten");
define("LANHELP_17", "Normal");
define("LANHELP_18", "Stor");
define("LANHELP_19", "Større");
define("LANHELP_20", "Massiv");
define("LANHELP_21", "Klikk for å åpne fargedialogboks ...");
define("LANHELP_22", "Klikk for å åpne størrelsesdialogboks ...");
define("LANHELP_23", "Sett inn link: [link]http://minside.no[/link] eller [link=http://dinside.com]Besøk min side[/link]");
define("LANHELP_24", "Fet stil: [b]Denne teksten blir fet[/b]", "font-weight:bold; width: 20px");
define("LANHELP_25", "Kursiv tekst: [i]Denne teksten blir kursiv[/i]", "font-style:italic; width: 20px");
define("LANHELP_26", "Understreket tekst: [u]Denne teksten blir understrket[/u]", "text-decoration: underline; width: 20px");
define("LANHELP_27", "Sett inn bilde: [img]minbild.jpg[/img]");
define("LANHELP_28", "Midtstillt: [center]Denne teksten blir Midtstilt[/center]");
define("LANHELP_29", "Vensterjustering: [left]Denne teksten blir venstrejustert[/left]");
define("LANHELP_30", "Høyrejustering: [right]Denne teksten blir høyrejustert[/right]");
define("LANHELP_31", "Innrykket tekst: [blockquote]Denne teksten blir innrykket[/blockquote]");
define("LANHELP_32", "Kode - preformattert tekst: [code]\$foo = bah;[/code]");
define("LANHELP_33", "HTML - tar bort tekstbrytning fra tekst: [html]<table><tr><td> etc[/html]");
define("LANHELP_34", "[newpage] eller [newpage=title] Setter inn sideskift, deler artikkelen på flere enn en side");
define("LANHELP_35", "hyperlenke url");
define("LANHELP_36", "Usortert liste: [list]line1*line2*line3[/list] Sortert liste: [list=typ]line1*line2*line3[/list]");
define("LANHELP_37", "Sett inn bilde fra e107_images/newspost_images/ mappen");
define("LANHELP_38", "Link til det store bildet vil bli generert");
define("LANHELP_39", "Sett inn nedlastnigslink fra eksisterende nedlastninger");
define("LANHELP_40", "Det er for øyeblikket ingen eksisterende nedlastninger");
define("LANHELP_41", "Skriftstørrelse...");
define("LANHELP_42", "Velg bilde...");
define("LANHELP_43", "Velg nedlastningsfil...");
define("LANHELP_44", "Klikk for å åpne/lukke smiliesdialog ...");
define("LANHELP_45", "Sett inn bilde fra mappe:");
define("LANHELP_46", "* Ingen filer funnet i:");
define("LANHELP_47", "Sett inn flash:
[flash=width,height]http://www.example.com/file.swf[/flash]");


?>