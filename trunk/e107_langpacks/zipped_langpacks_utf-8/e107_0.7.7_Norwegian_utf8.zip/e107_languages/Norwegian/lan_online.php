<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_online.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/02 16:21:04$
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Gjester: ");
define("ONLINE_EL2", "Medlemmer: ");
define("ONLINE_EL3", "På denne siden: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Medlemmer");
define("ONLINE_EL6", "Nyeste medlem");
define("ONLINE_EL7", "leser");
define("ONLINE_EL8", "flest online samtidig: ");
define("ONLINE_EL9", "den");
define("ONLINE_EL10", "Medlemsnavn");
define("ONLINE_EL11", "Leser siden");
define("ONLINE_EL12", "Svarer til");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Tråd");
define("ONLINE_EL15", "Side");
define("CLASSRESTRICTED", "Klassebegrenset side");
define("ARTICLEPAGE", "Artikkel/Anmeldelse");
define("CHAT", "Chat");
define("COMMENT", "Kommentarer");
define("DOWNLOAD", "Filer");
define("EMAIL", "email.php");
define("FORUM", "Forum hovedindex");
define("LINKS", "Linker");
define("NEWS", "Nyheter");
define("OLDPOLLS", "Gamle avstemninger");
define("POLLCOMMENT", "Avstemning");
define("PRINTPAGE", "Skriv ut");
define("LOGIN", "Logger inn");
define("SEARCH", "Søker");
define("STATS", "Sidestatistikk");
define("SUBMITNEWS", "Send inn nyhet");
define("UPLOAD", "Opplastninger");
define("USERPAGE", "Brukerprofiler");
define("USERSETTINGS", "Brukerinnstillinger");
define("ONLINE", "Brukere online");
define("LISTNEW", "Vis nye");
define("USERPOSTS", "Brukerinnlegg");
define("SUBCONTENT", "Send inn Artikkel/Anmeldelse");
define("TOP", "Toppostere/Mest aktive tråder");
define("ADMINAREA", "Adminområde");
define("BUGTRACKER", "Feilsøkere");
define("EVENT", "Hendelser");
define("CALENDAR", "Kalender");
define("FAQ", "Faq");
define("PM", "Private meldinger");
define("SURVEY", "Undersøkelse");
define("ARTICLE", "Artikkel");
define("CONTENT", "Innholdsside");
define("REVIEW", "Anmeldelse");


?>