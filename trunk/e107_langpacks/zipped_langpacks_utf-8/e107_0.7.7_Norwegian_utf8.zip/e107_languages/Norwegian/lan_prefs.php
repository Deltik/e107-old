<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_prefs.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:30:21 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107-drevet nettsted");
define("LAN_PREF_2", "e107 nettstedssystem");
define("LAN_PREF_3", "Dette nettstedet drives av <a href="http://e107.org/" rel="external">e107</a>, som distribueres under vilkårene i <a href="http://www.gnu.org/" rel="external">GNU</a> GPL Lisensen.");
define("LAN_PREF_4", "sensurert");
define("LAN_PREF_5", "Forum");


?>