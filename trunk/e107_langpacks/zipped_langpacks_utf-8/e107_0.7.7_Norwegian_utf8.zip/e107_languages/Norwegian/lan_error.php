<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_error.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/31 01:37:01 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Feil");
define("LAN_ERROR_1", "Feil 401 - Tillatelse nektet");
define("LAN_ERROR_2", "Du har ikke tillatelse til å mota URLen som du ønsket.");
define("LAN_ERROR_3", "Venligst informer administrator om denne siden om du mener feilmeldingen ikke bør være der.");
define("LAN_ERROR_4", "Feil 403 - Bekreftelse feilet");
define("LAN_ERROR_5", "URLen du ønsket trenger rett brukernavn og passord. Enten tastet du feil brukernavn/passord, ellers støtter ikke nettleseren din dette.");
define("LAN_ERROR_6", "Venligst informer administrator om denne siden om du mener feilmeldingen ikke bør være der.");
define("LAN_ERROR_7", "Feil 404 - Dokumentet ble ikke funent");
define("LAN_ERROR_9", "Venligst informer administrator om denne siden om du mener feilmeldingen ikke bør være der.");
define("LAN_ERROR_10", "Error 500 - Misformet tittel");
define("LAN_ERROR_11", "Serveren støtte på en intern feil eller miskonfigurasjon og er dermed ikke i stand til å utføre ønsket ditt");
define("LAN_ERROR_12", "Venligst informer administrator om denne siden om du mener feilmeldingen ikke bør være der.");
define("LAN_ERROR_13", "Feil - Ukjent");
define("LAN_ERROR_14", "Serveren støtte på  en feil");
define("LAN_ERROR_15", "Venligst informer administrator om denne siden om du mener feilmeldingen ikke bør være der.");
define("LAN_ERROR_16", "Ditt misslykkede forsøk på å nå");
define("LAN_ERROR_17", "har blitt registrert");
define("LAN_ERROR_18", "Tilsynelatende ble du henvist hit av");
define("LAN_ERROR_19", "Beklagelivis er dette en foreldet linkadresse.");
define("LAN_ERROR_20", "Venligst trykk her for å gå til sidens startside.");
define("LAN_ERROR_21", "Den ønskede URL kunne ikke bli funnet på serveren. Linken du fulgte er sannsynlegvis utdatert.");
define("LAN_ERROR_22", "Venligst trykk her for å gå til sidens søkefunksjon");
define("LAN_ERROR_23", "Ditt forsøk på å få adgang til");
define("LAN_ERROR_24", "mislykktes.");
define("LAN_ERROR_25", "[1]: Ikke i stand til å lese kjerneinnstillinger fra databasen - Kjerneinstillinger finnes men kan ikke bli brukt. Prøver å gjenopprette kjerneinstillinger ...");
define("LAN_ERROR_26", "[2]: Ikke i stand til å lese kjerneinstillinger fra databasen - Kjerneinstillinger finnes ikke.");
define("LAN_ERROR_27", "[3]: Kjerneinstillinger er lagret - backup er nå tilgjenngelig.");
define("LAN_ERROR_28", "[4]: Ingen kjernebackupfil finnes. Vennligst kjør <a href='".e_FILE."resetcore/resetcore.php'>Resett_Kjerne</a> programmet for å gjenoppbygge kjerneinstillingene. <br /> Etter gjenoppbygging av kjernen kan du lagre en backupfil fra admin/sql skjermen.  ");
define("LAN_ERROR_29", "[5]: Felt har blitt latt være blanke. Venligst send skjemaet på nytt med de manglene feltene utfylt.");
define("LAN_ERROR_30", "[6]: Var ikke i stand til å forme en gyldig tilkobling til mySQL. Venligst sjekk at e107_config.php inneholder rett informasjon.");
define("LAN_ERROR_31", "[7]: mySQL kjører men databasen ({$mySQLdefaultdb}) kunne ikke kobles til.<br />Sjekk at den eksisterer, og rett informasjon er registrert i e107_config.php.");
define("LAN_ERROR_32", "For å fullføre oppdateringen må du kopiere følgende tekst inn i e107_config.php filen:");


?>