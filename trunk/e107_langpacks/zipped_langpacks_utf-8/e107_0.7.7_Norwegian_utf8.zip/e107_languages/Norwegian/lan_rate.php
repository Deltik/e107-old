<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_rate.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:27:51 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("RATELAN_0", "stem");
define("RATELAN_1", "stemmer");
define("RATELAN_2", "Hvilken karakter vil du sette på dette objektet?");
define("RATELAN_3", "Takk for din stemme");
define("RATELAN_4", "Ikke karaktersatt");
define("RATELAN_5", "Karakter");


?>