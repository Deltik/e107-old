<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_user_extended.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 02:01:47 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Tekstrute");
define("UE_LAN_2", "Radioknapper");
define("UE_LAN_3", "Rullegardinmeny");
define("UE_LAN_4", "DB-tabellfelt");
define("UE_LAN_5", "Tekstområde");
define("UE_LAN_6", "Heltall");
define("UE_LAN_7", "Dato");
define("UE_LAN_8", "Språk");

define("UE_LAN_9", "Navn");
define("UE_LAN_10", "Type");
define("UE_LAN_11", "Bruk");

define("UE_LAN_HIDE", "Skjul for brukere");

define("UE_LAN_LOCATION", "Sted");
define("UE_LAN_LOCATION_DESC", "Brukerens sted");
define("UE_LAN_AIM", "AIM adresse");
define("UE_LAN_AIM_DESC", "AIM adresse");
define("UE_LAN_ICQ", "ICQ nummer");
define("UE_LAN_ICQ_DESC", "ICQ nummer");
define("UE_LAN_YAHOO", "Yahoo! adresse");
define("UE_LAN_YAHOO_DESC", "Yahoo! adresse");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN adresse");
define("UE_LAN_HOMEPAGE", "Hjemmeside");
define("UE_LAN_HOMEPAGE_DESC", "URL til brukerens hjememside");
define("UE_LAN_BIRTHDAY", "Fødselsdag");
define("UE_LAN_BIRTHDAY_DESC", "Fødselsdag");

define("UE_LAN_LANGUAGE", "Språk");
define("UE_LAN_LANGUAGE_DESC", "Brukerspråk");
define("UE_LAN_COUNTRY", "Land");
define("UE_LAN_COUNTRY_DESC", "Brukerland (inkluderer db tabell)");

?>
