<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_newspost.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/02 16:03:48 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Nyhet slettet.");
define("NWSLAN_2", "Sett merke i ruten for å bekrefte sletting av denne nyheten.");
define("NWSLAN_3", "Foreløpig ingen nyheter.");
define("NWSLAN_4", "Eksisterende nyheter");
define("NWSLAN_5", "Åpne HTML-editor");
define("NWSLAN_6", "Kategori");
define("NWSLAN_7", "Endre");
define("NWSLAN_8", "Slett");
define("NWSLAN_9", "marker for å bekrefte");
define("NWSLAN_10", "Foreløpig ingen kategorier satt.");
define("NWSLAN_11", "Legg til/Endre kategorier");
define("NWSLAN_12", "Tittel");
define("NWSLAN_13", "Tekst");
define("NWSLAN_14", "Utvidet");
define("NWSLAN_15", "Kommentarer");
define("NWSLAN_16", "Aktiv");
define("NWSLAN_17", "Inaktiv");
define("NWSLAN_18", "Tillat posting av kommentarer til denne nyheten");
define("NWSLAN_19", "Aktivering");
define("NWSLAN_20", "La stå åpent for ikke å bruke auto-aktivering");
define("NWSLAN_21", "Aktiver mellom");
define("NWSLAN_22", "Synlighet");
define("NWSLAN_23", "Markering gjør nyheten synlig kun for brukere i denne klassen");
define("NWSLAN_24", "Forhåndsvis igjen");
define("NWSLAN_25", "Oppdater nyhet i databasen");
define("NWSLAN_26", "Legg til nyhet i databasen");
define("NWSLAN_27", "Forhåndsvis");
define("NWSLAN_28", "Ny nyhet");
define("NWSLAN_29", "Nyhetspost");
define("NWSLAN_30", "Vis kun tittel");


?>