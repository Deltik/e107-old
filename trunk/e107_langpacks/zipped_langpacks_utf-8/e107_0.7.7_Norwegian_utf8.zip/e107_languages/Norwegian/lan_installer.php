<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_installer.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 12:05:47 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LANINS_001", "e107 Installasjon");
define("LANINS_002", "Trinn ");
define("LANINS_003", "1");
define("LANINS_004", "Språkvalg");
define("LANINS_005", "Velg språk for installasjonsprosessen");
define("LANINS_006", "Velg språk");
define("LANINS_007", "4");
define("LANINS_008", "PHP & MySQL versjonskontroll / Kontroll av filrettigheter");
define("LANINS_009", "Test filrettighetene igjen");
define("LANINS_010", "Kan ikke skrive til fil: ");
define("LANINS_010a", "Katalogen er skrivebeskyttet: ");
define("LANINS_011", "Feil");
define("LANINS_012", "MySQL funksjoner ser ikke ut til å finnes. Dette tyder på at MySQL PHP modulen enten ikke er installert eller ikke er korrekt konfigurert+\\\\\\\\\\\\.");
define("LANINS_013", "Kunne ikke finne MySQL versjon. Detta er ikke en blokkerende feil, så fortsett å installere, men vær oppmerksom på at e107 krever MySQL >= 3.23 for å fungere korrekt.");
define("LANINS_014", "Filrettigheter");
define("LANINS_015", "PHP versjon");
define("LANINS_016", "MySQL");
define("LANINS_017", "Ferdig");
define("LANINS_018", "Forsikre deg om at alle listede filer eksisterer og at serveren har skrivetilgang til dem. Dette innebærer vanligvis å sette dem til CHMOD 777, men miljøer kan være ulike - kontakt din webserveradministrator om du får problemer.");
define("LANINS_019", "PHP versjonen installert på serveren din kan ikke kjøre e107. e107 krever minst PHP versjon 4.3.0 for å kjøre korrekt. Oppgrader PHP selv, eller kontakt om nødvendig webserveradministrator for oppgradering.");
define("LANINS_020", "Fortsett installasjon");
define("LANINS_021", "2");
define("LANINS_022", "MySQL serverdetaljer");
define("LANINS_023", "Angi dine MySQL innstllinger her.<br /><br />Om du har roottilgang kan du opprette en ny database ved å klikke i ruten 'Opprett database', om ikke må du opprette en database manuelt eller benytte en eksisterende.<br /><br />Om du bare har en database, bruk et prefiks slik at andre skript kan dele på samme database.<br />Om du ikke kjenner dine MySQL instillinger, kontakta din webserveradministrato.");
define("LANINS_024", "MySQL Server:");
define("LANINS_025", "MySQL brukernavn:");
define("LANINS_026", "MySQL passord:");
define("LANINS_027", "MySQL database:");
define("LANINS_028", "Opprett database?");
define("LANINS_029", "Tabellprefiks:");
define("LANINS_030", "MySQL serveren du vil at e107 skal benytte. Kan også inneholde portnummer, f.eks. \"servernavn:port\" eller stien til en lokal socket f.eks. \":/sti/til/socket\" for den lokal serveren.");
define("LANINS_031", "Brukernavnet e107 skal bruke for å koble til MySQL serveren din");
define("LANINS_032", "Passordet for brukeren du nettopp oppga");
define("LANINS_033", "MySQL databasen du vil at e107 skal befinna seg i, i vissa tilfeller kalt skjema. Om brukeren har rettigheter til å opprette en database kan du be om at en ny database opprettes om den ikke allerde finnes.");
define("LANINS_034", "Prefikset du vil at e107 skal benytte når tabellene skal opprettes. Kan brukes til til å kjøre flere ulike e107 eller andre applikasjoner i samme database/skjema.");
define("LANINS_035", "Fortsett");
define("LANINS_036", "3");
define("LANINS_037", "Verifiering av MySQL tilkobling");
define("LANINS_038", " og opprettelse av database");
define("LANINS_039", "Pass på at du fyller ut alle felt, viktigst er MySQL Server, MySQL brukernavn og MySQL database (Disse kreve alltid av MySQL serveren)");
define("LANINS_040", "Feil");
define("LANINS_041", "e107 kunne ikke koble til MySQL med den informasjonen du har oppgitt. Gå tilbake til forrige side og kontroller at informasjonen er korrekt.");
define("LANINS_042", "Tilkobling til MySQL serveren opprettet og verifisert.");
define("LANINS_043", "Kunne ikke opprette en database. Kontroller at du har tilstrekkelige rettigheter for å opprette nye databaser på serveren din.");
define("LANINS_044", "Database opprettet uten feil.");
define("LANINS_045", "Klikk på knappen for å gå videre til neste trinn.");
define("LANINS_046", "5");
define("LANINS_047", "Administratorinformasjon");
define("LANINS_048", "Gå tilbake til forrige trinn");
define("LANINS_049", "De to passordene er ikke like, prøv igjen.");
define("LANINS_050", "XML modul");
define("LANINS_051", "Installert");
define("LANINS_052", "Ikke installert");
define("LANINS_053", "e107 .700 krever at PHP XML modulen er installert. Kontakt webserveradministrator eller se informasjon på");
define("LANINS_054", " før du fortsetter.");
define("LANINS_055", "Installasjonsbekreftelse");
define("LANINS_056", "6");
define("LANINS_057", "e107 har nå all informasjon som kreves for å avslutte installasjonen.<br /><br />Klikk på knappen for å opprette databasetabellene og lagre alle dine innstillinger.");
define("LANINS_058", "7");
define("LANINS_060", "Kan ikke lese SQL datafilen.<br /><br />Forsikre deg om at filen  <b>core_sql.php</b> eksisterer i <b>/e107_admin/sql</b> katalogen.");
define("LANINS_061", "e107 kunne ikke opprette alle nødvendige databasetabeller.<br />Vennligst tøm databasen og korriger eventuelle problem før du prøver igjen.");
define("LANINS_062", "[b]Velkommen til ditt nye nettsted![/b]
e107 er korrekt installert og klar til å ta imot innhold.<br />Administrasjonsseksjonen er [link=e107_admin/admin.php]plassert her[/link], klikk for å gå dit nå. Du er nødt til å logge inn med det brukernavnet og passordet du oppga under installasjonsprosessen.

[b]Brukerstøtte[/b]
e107 hjemmeside: [link=http://e107.org]http://e107.org[/link], du vil finne FAQ och dokumentasjon her.
Forum: [link=http://e107.org/e107_plugins/forum/forum.php]http://e107.org/e107_plugins/forum/forum.php[/link]

[b]Nedlastninger[/b]
Plugins: [link=http://e107coders.org]http://e107coders.org[/link]
Tema: [link=http://e107styles.org]http://e107styles.org[/link] | [link=http://e107themes.org]http://e107themes.org[/link]

Takk for at du prøver e107, vi håper at den oppfyller dine nettstedsbehov.
(Du kan fjerne denne beskjeden fra adminseksjonen din.)");
define("LANINS_063", "Velkommen til e107");
define("LANINS_069", "e107 er korrekt installert!<br /><br />Av sikkehetshensyn skal du nå sette filrettighetene på <b>e107_config.php</b> filen tilbake til 644.<br /><br />Slett også install.php og e107_install katalogen fra serveren etter at du har klikket på knappen nedenfor.");
define("LANINS_070", "e107 kunne ikke lagre hovedkonfigurasjonsfilen på serveren din.<br /><br />Forsikre deg om at filen <b>e107_config.php</b> har korrekte rettigheter");
define("LANINS_071", "Avslutter installasjon");
define("LANINS_072", "Adminbrukernavn");
define("LANINS_073", "Dette er navnet du bruker for å logge inn på nettstedet. Du kan også benytte dette som ditt synlige navn.");
define("LANINS_074", "Synlig Adminnavn");
define("LANINS_075", "Dette er navnet som du vil at brukerne skal se på profilen din, i forum og i andre områder. Om du vil vise samme navn som innloggingsnavnet, la dette feltet stå tomt.");
define("LANINS_076", "Adminpassord");
define("LANINS_077", "Oppgi passordet du ønsker for admin.");
define("LANINS_078", "Admin passordbekreftelse");
define("LANINS_079", "Oppgi admins passord igjen for verifisering.");
define("LANINS_080", "Admin epost");
define("LANINS_081", "Oppgi epostadressen din her.");
define("LANINS_082", "navn@dinside.no");
define("LANINS_083", "MySQL raporterte feil:");
define("LANINS_084", "Installereren kunne ikke oprette en forbindelse med databasen");
define("LANINS_085", "Installereren klarte ikke å velge database:");
define("LANINS_086", "Admin brukernavn, Admin passord og Admin e-post er <b>nødvendige</b> felt. Venligst gå tilbake til forige side og sjekk at informasjonen er riktig.");


?>