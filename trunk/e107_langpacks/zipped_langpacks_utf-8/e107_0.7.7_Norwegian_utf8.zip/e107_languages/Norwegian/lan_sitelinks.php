<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_sitelinks.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 01:03:27 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Hovedmeny");
define("LAN_SITELINKS_502", "Adminområde");


?>