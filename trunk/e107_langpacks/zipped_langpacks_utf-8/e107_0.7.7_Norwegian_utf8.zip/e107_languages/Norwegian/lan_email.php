<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_email.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/29 03:22:23 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "E-post");}
define("LAN_EMAIL_1", "Fra:");
define("LAN_EMAIL_2", "IPadressen til senderen:");
define("LAN_EMAIL_3", "Sente sak fra");
define("LAN_EMAIL_4", "Send e-post");
define("LAN_EMAIL_5", "Sent saken til en venn");
define("LAN_EMAIL_6", "Jeg tenkte du kunne være interessert i denne saken fra ");
define("LAN_EMAIL_7", "send e-post til noen");
define("LAN_EMAIL_8", "Kommentar");
define("LAN_EMAIL_9", "Beklager - var ikke i stant til å sende e-post");
define("LAN_EMAIL_10", "E-posten ble sent til");
define("LAN_EMAIL_11", "E-post sent");
define("LAN_EMAIL_12", "Feil");
define("LAN_EMAIL_13", "Send artikkelen til en venn");
define("LAN_EMAIL_14", "Send news_item til en venn");
define("LAN_EMAIL_15", "Innloggingsnavn ");
define("LAN_EMAIL_106", "Det ser ikke ut til å være en gyldig e-postadresse");
define("LAN_EMAIL_185", "Send artikkel");
define("LAN_EMAIL_186", "Send Nyhetssak");
define("LAN_EMAIL_187", "E-postadressen det skal sendes til");
define("LAN_EMAIL_188", "Jeg tenkte du kunne være interessert i denne nyheten fra ");
define("LAN_EMAIL_189", "Jeg tenkte du kunne være interessert i denne artikkelen fra ");
define("LAN_EMAIL_190", "Skriv inn koden");


?>