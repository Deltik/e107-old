﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_request.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:45:24$
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Nedlastningsfeil");
define("LAN_dl_62", "Du har blitt hindret fra å laste ned filen, du har overskredet nedlastningskvoten din");
define("LAN_dl_63", "Du har tilgang til å laste ned denne filen.");
define("LAN_dl_64", "Tilbake");
define("LAN_dl_65", "Fant ikke filen");

?>
