<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_upload.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 01:30:09 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Last opp");
define("LAN_20", "Feil");
define("LAN_61", "Navn: ");
define("LAN_112", "Epostadresse: ");
define("LAN_144", "Nettsted URL: ");
define("LAN_402", "Du må være registrert medlem for å få laste opp filer til denne serveren.");
define("LAN_403", "Du har ikke rettigheter til å laste opp filer til denne serveren.");
define("LAN_404", "Takk. Opplastningen din vil bli sjekket av en nettstedsadministrator så snart som mulig lagt ut på nettstedet om den anses som passende.");
define("LAN_405", "Filen overskrider maximal tillatt størrelse - slettet.");
define("LAN_406", "NB");
define("LAN_407", "Alle andre filtyper som lastes opp vil bli slettet umiddelbart.");
define("LAN_408", "Understreket");
define("LAN_409", "Filnavn");
define("LAN_410", "Versjon");
define("LAN_411", "Fil");
define("LAN_412", "Skjermbilde");
define("LAN_413", "Beskrivelse");
define("LAN_414", "Fungerende demo");
define("LAN_415", "oppgi URL til et nettsted der en demo vises");
define("LAN_416", "Bekreft og last opp");
define("LAN_417", "Last opp fil");
define("LAN_418", "Maksimal filstørrelse: ");
define("DOWLAN_11", "Kategori");
define("LAN_419", "Tillatte filtyper");
define("LAN_420", "felt er obligatoriske");


?>