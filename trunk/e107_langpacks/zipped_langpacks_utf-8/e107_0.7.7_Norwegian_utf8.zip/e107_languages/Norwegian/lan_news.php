<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_news.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 14:14:45 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Nyheter");
define("LAN_NEWS_1", "Nyheter kun for spesielle medlemmer");
define("LAN_NEWS_2", "Du har ikke tilgang til denne nyhetent");
define("LAN_NEWS_5", "<b>Feil!</b> Kunne ikke oppdatere nyhetsemne i databasen!</b>");
define("LAN_NEWS_6", "Nyhet lagt inn i databasen.");
define("LAN_NEWS_7", "<b>Feil!</b> Kunne ikke legge inn nyhet i databasen!</b>");
define("LAN_NEWS_8", "Nyhet lagt inn i databasen for alle språk. ID: ");
define("LAN_NEWS_9", "Kun tittel er aktivt - <b>kun nyhetens tittel kommer til å vises</b><br />");
define("LAN_NEWS_10", "Denne nyhetsposten er <b>inaktiv</b> (Den kommer ikke til å vises på førstesiden). ");
define("LAN_NEWS_11", "Denne nyhetsposten er <b>aktiv</b> (Den kommer til å vises på førstesiden). ");
define("LAN_NEWS_12", "Kommentarer er <b>på</b>. ");
define("LAN_NEWS_13", "Kommentarer er <b>av</b>. ");
define("LAN_NEWS_14", "<br />Aktiveringsperiode: ");
define("LAN_NEWS_15", "Tekstlengde: ");
define("LAN_NEWS_16", "t. utvidet lengde: ");
define("LAN_NEWS_17", "t.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Nå");
define("LAN_NEWS_20", "Nyhet uppdatert i databasen for følgende språk: ");
define("LAN_NEWS_21", "Nyhet uppdatert i databasen.");
define("LAN_NEWS_23", "Nyhetskategorier");
define("LAN_NEWS_24", "lag en pdf av dette nyhetsemnet");
define("LAN_NEWS_82", "Nyheter - Kategori");
define("LAN_NEWS_83", "Ingen nyheter for øyeblikket - Venligst sjekk tilbake senere.");
define("LAN_NEWS_84", "Nyhetssak");
define("LAN_NEWS_99", "Kommentarer");
define("LAN_NEWS_100", "på");
define("LAN_NEWS_307", "Totalt antall poster i denne kategorien:");
define("LAN_NEWS_462", "Ingen nyhetssaker for den spesifiserte måneden");


?>