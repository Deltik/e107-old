<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_upload_handler.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 01:37:54 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Filtypen");
define("LANUPLOAD_2", "er ikke tillatt og slettes derfor.");
define("LANUPLOAD_3", "Opplastningen var vellykket");
define("LANUPLOAD_4", "Enten finnes ikke mottagende mappe, eller så er den ikke skrivbar.");
define("LANUPLOAD_5", "Den opplastede filen overskrider upload_max_filesize direktivet i php.ini.");
define("LANUPLOAD_6", "Den opplastede filen overskrider MAX_FILE_SIZE direktivet som spesfiseres i html-formularet.");
define("LANUPLOAD_7", "Filen ble bare delvis lastet opp.");
define("LANUPLOAD_8", "Ingen fil ble lastet opp.");
define("LANUPLOAD_9", "Opplastet filstørrelse 0 bytes");
define("LANUPLOAD_10", "Opplastningen mislyktes [Duplisert filnavn] - En fil med samme navn finnes allerede.");
define("LANUPLOAD_11", "Filen ble ikke lastet opp. Filnavn: ");
define("LANUPLOAD_12", "Feil");


?>