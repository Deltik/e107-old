<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_print.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:25:59 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Utskriftsvennlig");}
define("LAN_PRINT_86", "Kategori:");
define("LAN_PRINT_87", "av");
define("LAN_PRINT_94", "Postet av");
define("LAN_PRINT_135", "Nyhetssak:");
define("LAN_PRINT_303", "Denne nyhetssaken er fra");
define("LAN_PRINT_304", "Tittel:");
define("LAN_PRINT_305", "Underskrift:");
define("LAN_PRINT_306", "Dette er fra:");
define("LAN_PRINT_307", "Skriv ut siden");
define("LAN_PRINT_1", "printervennlig");


?>