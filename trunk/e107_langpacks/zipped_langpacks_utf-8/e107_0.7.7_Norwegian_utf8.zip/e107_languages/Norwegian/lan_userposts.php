<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_userposts.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 02:06:20 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Brukerinnlegg");
define("UP_LAN_0", "Alle foruminnlegg fra ");
define("UP_LAN_1", "Alle kommentarer fra ");
define("UP_LAN_2", "Tråd");
define("UP_LAN_3", "Visninger");
define("UP_LAN_4", "Svar");
define("UP_LAN_5", "Siste innlegg");
define("UP_LAN_6", "Tråder");
define("UP_LAN_7", "Ingen kommentarer");
define("UP_LAN_8", "Ingen innlegg");
define("UP_LAN_9", " den ");
define("UP_LAN_10", "Sv");
define("UP_LAN_11", "Postet den");
define("UP_LAN_12", "Søk");
define("UP_LAN_13", "Kommentarer");
define("UP_LAN_14", "Foruminnlegg");
define("UP_LAN_15", "Sv");
define("UP_LAN_16", "IP-adresse");


?>