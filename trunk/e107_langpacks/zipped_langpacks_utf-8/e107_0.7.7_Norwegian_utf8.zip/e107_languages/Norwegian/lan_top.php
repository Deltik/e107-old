<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_top.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 01:04:40 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "Mest aktive brukere i forum");
define("TOP_LAN_1", "Brukernavn");
define("TOP_LAN_2", "Innlegg");
define("TOP_LAN_3", "Mest aktive brukere, kommentarer");
define("TOP_LAN_4", "Kommentarer");
define("TOP_LAN_5", "Mest aktive brukere, chatruta");
define("TOP_LAN_6", "Nettstedskarakter");
define("LAN_1", "Tråd");
define("LAN_2", "Postere");
define("LAN_3", "Visninger");
define("LAN_4", "Svar");
define("LAN_5", "Nyeste post");
define("LAN_6", "Tråder");
define("LAN_7", "Mest aktive trådar");
define("LAN_8", "Mest aktive brukere");


?>