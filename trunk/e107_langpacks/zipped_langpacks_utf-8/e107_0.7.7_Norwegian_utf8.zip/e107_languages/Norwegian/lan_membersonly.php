<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_membersonly.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/02 14:10:03 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Kun for medlemmer");
define("LAN_MEMBERS_0", "tilgangsbegrenset område");
define("LAN_MEMBERS_1", "Dette er et tilgangsbegrenset område");
define("LAN_MEMBERS_2", "For å få tilgang, <a href='login.php'>logg inn</a>");
define("LAN_MEMBERS_3", "eller <a href='".e_SIGNUP."'>registrer</a> deg som medlem");
define("LAN_MEMBERS_4", "Klikk her for å gå tilbake til forsiden");


?>