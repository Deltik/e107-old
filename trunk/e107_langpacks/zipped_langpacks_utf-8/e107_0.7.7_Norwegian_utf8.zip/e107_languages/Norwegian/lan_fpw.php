<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_fpw.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 00:24:05 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Tilbakestilling av passord");
define("LAN_02", "Beklager, kunne ikke sende epost - kontakt sidens hovedadministrator.");
define("LAN_03", "Tilbakestilling av passord");
define("LAN_05", "For å tilbakestille passordet ditt, fyll ut følgende informasjon");
define("LAN_06", "Forsøk på tilbakestilling av passord");
define("LAN_07", "Noen med ip adresse ");
define("LAN_08", "forsøkte å tilbakestille hovedadministrators passord.");
define("LAN_09", "Tilbakestilling av passord fra ");
define("LAN_112", "Epostadresse benyttet ved registrering ");
define("LAN_156", "Send");
define("LAN_213", "Brukernavnet/epostadressen ble ikke funnet i databasen.");
define("LAN_214", "Kunne ikke tilbakestille passordet");
define("LAN_216", "Kan ikke bekrefte ditt nye passord, gå til følgende URL ...");
define("LAN_217", "Ditt nye passord er nå bekreftet, du kan nå logge inn med det nye passordet.");
define("LAN_218", "Brukernavnet ditt er:");
define("LAN_219", "Passordet som tilhører denne epostadressen har allerede blitt tilbakestilt og kan ikke tilbakestilles igjen. Kontakt administrator for mer informasjon.");
define("LAN_FPW1", "Brukernavn");
define("LAN_FPW2", "Angi kode");
define("LAN_FPW3", "Feil kode");
define("LAN_FPW4", "En forespørsel om tilbaketilling har allerede blitt sendt for dette passordet. Om du ikke har fått melding via epost, kontakt administratoren for hjelp.");
define("LAN_FPW5", "En forespørsel om tilbaketilling av passordet for");
define("LAN_FPW6", "Epost har blitt sendt til deg med link som lar deg tilbakestille passordet ditt.");
define("LAN_FPW7", "Dette er ikke en gyldig link for å tilbakestille passordet ditt.<br />Kontakt administratoren for mer informasjon.");
define("LAN_FPW8", "Passordet for brukernavn");
define("LAN_FPW9", "har blitt endret.<br /><br />Det nye passordet er:");
define("LAN_FPW10", "Vennligst");
define("LAN_FPW11", "logg inn nå");
define("LAN_FPW12", "og forandre passordet umiddelbart av sikkerhetsgrunner.");
define("LAN_FPW13", "vennligst følg instruksjonene i eposten for å bekrefte passordet ditt.");
define("LAN_FPW14", "har blitt ønsket av noen med IP-adressen");
define("LAN_FPW15", "Dette betyr ikke at passordet ditt tilbakestilles enda.  Du må gå til linken nedenfor for å fullføre endringen.");
define("LAN_FPW16", "Om du ikke selv har bedt om denne tilbakestillingen, og du IKKE vil ha det tilbakestilt så kan du helt enkelt overse denne eposten");
define("LAN_FPW17", "Linken nedenfor er gyldig i 48 timer.");


?>