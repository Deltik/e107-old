<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 02:16:04 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, "no_NO");
define("CORE_LC", "no");
define("CORE_LC2", "NO");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Feil: Tema mangler.\\n\\nBytt det brukte temaet i dine preferanser (adminområdet) eller last opp filene for det aktuelle temaet til din server.");
define("CORE_LAN2", "\\1 skrev:");// "\\1");
define("CORE_LAN3", "filvedlegg er slått av");
define("CORE_LAN4", "venligst slett install.php fra serveren din");
define("CORE_LAN5", "om du ikke gjør dette er det en potensiell sikkerhetsrisiko");
define("CORE_LAN6", "Floodingbeskyttelsen på siden her er aktivert. Du er nå advart om at om du fortsetter å spørr etter sider så vil du bli bannet.");
define("CORE_LAN7", "Kjernen forsøker å gjenopprette preferansene fra en automatisk backup");
define("CORE_LAN8", "Kjernepreferansefeil");
define("CORE_LAN9", "Kjernen kunne ikke gjenopprette fra en automatisk backup. Utførelsen venter.");
define("CORE_LAN10", "Korrupt coockiefil fantes - logger ut");
define("LAN_WARNING", "Advarsel!");
define("LAN_ERROR", "Feil");
define("LAN_ANONYMOUS", "Anonym");


?>