<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_np.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/02 16:18:43 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("NP_1", "Forrige side");
define("NP_2", "Neste side");
define("NP_3", "Gå til siden");


?>