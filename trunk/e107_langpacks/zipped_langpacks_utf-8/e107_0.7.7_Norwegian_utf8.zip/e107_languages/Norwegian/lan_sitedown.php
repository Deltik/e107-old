<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_sitedown.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/02 00:58:00$
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Nettstedet er midlertidig stengt");
define("LAN_SITEDOWN_00", "er midlertidig stengt");
define("LAN_SITEDOWN_01", "Vi har midlertidig stengt siden for essensiellt vedlikehold. Det bør ikke ta så lang tid - Venligst sjekk tilbake snart. Beklager for all ulempe dette måtte medføre.");


?>