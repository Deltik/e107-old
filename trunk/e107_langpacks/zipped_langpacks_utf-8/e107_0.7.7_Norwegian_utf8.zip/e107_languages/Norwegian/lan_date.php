<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_date.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/29 19:55:36 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LANDT_01", "år");
define("LANDT_02", "måned");
define("LANDT_03", "uke");
define("LANDT_04", "dag");
define("LANDT_05", "time");
define("LANDT_06", "minutt");
define("LANDT_07", "sekund");
define("LANDT_01s", "år");
define("LANDT_02s", "måneder");
define("LANDT_03s", "uker");
define("LANDT_04s", "dager");
define("LANDT_05s", "timer");
define("LANDT_06s", "minutter");
define("LANDT_07s", "sekunder");
define("LANDT_08", "min");
define("LANDT_08s", "min");
define("LANDT_09", "sek");
define("LANDT_09s", "sek");
define("LANDT_AGO", "siden");


?>