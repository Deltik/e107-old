<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_signup.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/02 16:55:38 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Registrering");
define("LAN_7", "Visningsnavn: ");
define("LAN_8", "navnet som kommer til å vises på siden");
define("LAN_9", "Innloggingsnavn: ");
define("LAN_10", "navnet du bruker for innlogging");
define("LAN_17", "Passord: ");
define("LAN_103", "Det brukernavnet kan ikke aksepteres som gyldig, velg noe annet");
define("LAN_104", "Den innloggingen finnes allerede i databasen, velg et annet innloggingsnavn");
define("LAN_105", "De to passordene er ikke like");
define("LAN_106", "Det ser ikke ut som en gyldig epostadresse");
define("LAN_107", "Takk! Du er nå et registrert medlem på");
define("LAN_108", "Registrering komplett");
define("LAN_109", "Denne siden følger det internasjonale regelverket for beskyttelse av barn på internett, 'The Children's Online Privacy Protection Act of 1998 (COPPA)' og derfor aksepterer vi ikke registrering av brukere under 13 år uten skriftlig tillatelse fra foreldre eller foresatte. For mer informasjon henvises til COPPA ( http://www.coppa.org/ )");
define("LAN_110", "Registrering");
define("LAN_111", "Oppgi passord igen: ");
define("LAN_112", "Epostadresse: ");
define("LAN_113", "Skjul epostaddresse?: ");
define("LAN_114", "Dette hindrar at epostadressen din vises på nettstedet");
define("LAN_123", "Registrer");
define("LAN_185", "Du har latt et obligatorisk felt stå tomt");
define("LAN_201", "Ja");
define("LAN_200", "Nei");
define("LAN_202", "Du har allerede en konto. Om du har glemt passordet ditt, klikk på \'Glemt passord\' linken.");
define("LAN_309", "Oppgi informasjonen din nedenfor.");
define("LAN_399", "Fortsett");
define("LAN_400", "Brukernavn og passord <b>skiller mellom store og små bokstaver</b>");
define("LAN_401", "Kontoen din er nå aktivert, vennligst");
define("LAN_402", "Registrering aktivert");
define("LAN_403", "Velkommen til");
define("LAN_404", "Registreringsdetaljer for");
define("LAN_405", "Dette trinnet i registreringen er nå ferdig. Du kommer til å få en epost med en bekreftelse og innloggingsopplysninger. Vennligst følg linken i brevet for å fullføre prosessen ogh aktivere kontoen din.");
define("LAN_406", "Takk!");
define("LAN_407", "Ta vare på dette brevet med din egen informasjon. Passordet ditt er kryptert og kan ikke  finnes igjen om du mister det. Derimot kan du be om et nytt passord om dette skulle skje.\n\nTakk for at du registrerte deg.\n\nFra");
define("LAN_408", "En bruker med den epostadressen finnes allerede. Bruk 'Glemt passord' funksjonen for å få nytt passord.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "tegn");
define("LAN_SIGNUP_3", "Kodebekreftelse mislyktes.");
define("LAN_SIGNUP_4", "Passordet ditt må være minst ");
define("LAN_SIGNUP_5", " tegn langt.");
define("LAN_SIGNUP_6", "Din ");
define("LAN_SIGNUP_7", " kreves");
define("LAN_SIGNUP_8", "Takk!");
define("LAN_SIGNUP_9", "Kan ikke fortsette.");
define("LAN_SIGNUP_10", "Ja");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Ugyldige tegn i brukernavnet");
define("LAN_410", "Oppgi koden som vises i bildet");
define("LAN_411", "DEt visnigsnavnet eksisterer allerede. Venligst velg et annet visnigsnavn");
define("LAN_SIGNUP_12", "Vennligst ha brukernavn og passord nedskrevet og lagret på et sikkert sted, om du mister det kan det ikke finnes igjen.");
define("LAN_SIGNUP_13", "Nå kan du logge inn fra innloggingsruten, eller <a href='".e_BASE."login.php'>herfra</a>.");
define("LAN_SIGNUP_14", "her");
define("LAN_SIGNUP_15", "Vennligst kontakt nettstedets hovedadmin");
define("LAN_SIGNUP_16", "om du trenger hjelp.");
define("LAN_SIGNUP_17", "Vennligst bekreft at du er 13 år eller eldre.");
define("LAN_SIGNUP_18", "Registreringen er mottatt og følgende innloggingsinformasjon er lagret...");
define("LAN_SIGNUP_19", "Brukernavn:");
define("LAN_SIGNUP_20", "Passord:");
define("LAN_SIGNUP_21", "Kontoen din er foreløpig inaktivt, for å aktivere den, gå til følgende link ...");
define("LAN_SIGNUP_22", "klikk her");
define("LAN_SIGNUP_23", "for åt logge inn.");
define("LAN_SIGNUP_24", "Takk for din registrering hos");
define("LAN_SIGNUP_25", "Last opp avatar");
define("LAN_SIGNUP_26", "Last opp foto");
define("LAN_SIGNUP_27", "Vis");
define("LAN_SIGNUP_28", "valg av innhold/epostlister");
define("LAN_SIGNUP_29", " Et bekreftelsesbrev vil bli sendt til den epostadressen du oppgir her, så den må være gyldig.");
define("LAN_SIGNUP_30", "Om du ikke vil vise epostadressen din på nettstedet, sett da merke i ruten med 'Gjem epostadresse'.");
define("LAN_SIGNUP_31", "URL til XUP filen din");
define("LAN_SIGNUP_32", "Hva er en XUP fil?");
define("LAN_SIGNUP_33", "Oppgi sti eller velg figur");
define("LAN_SIGNUP_34", "NB: Et bilde som lastes opp til denne serveren og som av administratorene anses å være av tvilsom karakter kommer til å slettes umiddelbart.");
define("LAN_SIGNUP_35", "Klikk her for å registrere med en XUP fil");
define("LAN_SIGNUP_36", "En feil oppsto under oppretting av dine brukerdata, venligst kontakt sideadministratoren");
define("LAN_LOGINNAME", "Innloggingsnavn");
define("LAN_PASSWORD", "Passord");
define("LAN_USERNAME", "Vis navn");
define("LAN_EMAIL_01", "Hei");
define("LAN_EMAIL_04", "Ta vare på opplysningene i dette epostbrevet.");
define("LAN_EMAIL_05", "Passordet ditt er kryptert i vår database og kan ikke gjennopprettes om du glemmer det. Derimot kan du be om et nytt passord om dette skulle skje.");
define("LAN_EMAIL_06", "Takk for at du registrerte deg.");
define("LAN_SIGNUP_37", "Dette trinnet i registreringen er nå ferdig. En nettstedsadministrator må nå godkjenne medlemskapet.  Når det er gjort kommer du til å få et bekreftelsesbrev via epost som opplyser deg om at medlemskapet er godkjent.");
define("LAN_SIGNUP_38", "Du oppga to ulike epostadresser. Oppgi samme korrekte epostadresse i begge de to feltene for dette.");
define("LAN_SIGNUP_39", "Oppgi epostadressen igjen:");
define("LAN_SIGNUP_40", "Aktivering er ikke nødvendig");
define("LAN_SIGNUP_41", "Din konto er allerede aktivert.");
define("LAN_SIGNUP_42", "Det oppsto et problem og regristreringsmailen ble ikke sent. venligst kontakt administratoren.");
define("LAN_SIGNUP_43", "E-post er sent");
define("LAN_SIGNUP_44", "Aktiveringsepost er sent til:");
define("LAN_SIGNUP_45", "Venligst sjekk innoksen din.");
define("LAN_SIGNUP_47", "Resend Aktiveringsepost");
define("LAN_SIGNUP_48", "Brukernavn eller E-post");
define("LAN_SIGNUP_49", "Om du registrerte feil epostadresse kan du skrive inn en ny og passordet ditt her:");
define("LAN_SIGNUP_50", "Ny E-post");
define("LAN_SIGNUP_51", "Gammelt passord");
define("LAN_SIGNUP_52", "Feil passord");
define("LAN_SIGNUP_53", "feltet feilet bekreftelsestest");


?>