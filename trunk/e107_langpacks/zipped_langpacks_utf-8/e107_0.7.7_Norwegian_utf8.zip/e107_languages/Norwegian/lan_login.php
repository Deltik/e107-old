<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_login.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:20:23 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_27", "Du glemte å fylle ut et obligatorisk felt");
define("LAN_300", "Feil i innlogging. Oppgitte data passer ikke overens med noen registrert bruker. Kontroller om CAPS-LOCK er på. Innloggingen skiller mellom små og store bokstaver.");
define("LAN_302", "Du har ikke aktivert kontoen din. Du skal ha fått en epost med instruksjoner om hvordan du aktiverer kontoen. Om du ikke har mottatt denne, kontakt en sideadministrator.");
define("LAN_303", "Feil kode oppgitt.");
define("LAN_304", "Denne brukernavn/passordkombinasjonen er allerede i bruk.");
define("LAN_LOGIN_1", "Brukernavn");
define("LAN_LOGIN_2", "Passord");
define("LAN_LOGIN_3", "Beskyttet server");
define("LAN_LOGIN_4", "Oppgi dine opplysninger for å få tilgang.");
define("LAN_LOGIN_5", "Klikk her for registrering");
define("LAN_LOGIN_6", "Tar ikke imot nye medlemmer akkurat nå");
define("LAN_LOGIN_7", "Oppgi koden i bildet");
define("LAN_LOGIN_8", "Husk meg");
define("LAN_LOGIN_9", "Logg inn");
define("LAN_LOGIN_10", "Klikk for inlogging");
define("LAN_LOGIN_11", "Registrer som ny bruker");
define("LAN_LOGIN_12", "Glemt passord");
define("LAN_LOGIN_13", "Oppgi teksten i bildet");
define("LAN_LOGIN_14", "Bruker forsøker å logge inn med ukjent brukernavn");
define("LAN_LOGIN_15", "Bruker forsøker å logge inn med feil passord");
define("LAN_LOGIN_16", "Bruker forsøker å logge inn med brukernavn/passordskombinasjon som allerede finnes");
define("LAN_LOGIN_17", "Passord(hashed)");
define("LAN_LOGIN_18", "Auto-stenging: Mer enn 10 mislykkede innloggingsforsøk");
define("LAN_LOGIN_19", "> 10 mislykkede innloggingsforsøk");


?>