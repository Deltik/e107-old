<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_comment.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/29 19:37:24$
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("COMLAN_0", "[blokkert av admin]");
define("COMLAN_1", "Avblokker");
define("COMLAN_2", "Blokker");
define("COMLAN_3", "Slett");
define("COMLAN_4", "info");
define("COMLAN_5", "Kommentarer ...");
define("COMLAN_6", "Du må være logget inn for å poste kommentarer på siden her - venligst logg inn, eller om du ikke er registrert, klikk");
define("COMLAN_7", "Hovedadministrator");
define("COMLAN_8", "Kommentar");
define("COMLAN_9", "Send inn kommentar");
define("COMLAN_10", "Administrator");
define("COMLAN_11", "Var ikke i stand til å legge til kommentaren din i databasen. Venligst skriv den igjen, og utelat alle ikkestandard tegn");
define("COMLAN_16", "Brukernavn:");
define("COMLAN_99", "Kommenterer");
define("COMLAN_100", "Nyheter");
define("COMLAN_101", "Avstemmning");
define("COMLAN_102", "Svarer til:");
define("COMLAN_103", "Artikkel:");
define("COMLAN_104", "Se over");
define("COMLAN_105", "Innhold");
define("COMLAN_145", "Registrert:");
define("COMLAN_194", "Gjest");
define("COMLAN_195", "Registrert medlem");
define("COMLAN_310", "Var ikke i stand til å poste pga at dette brukernavnet allereie er registrert - om det er ditt brukernavn, vnligst logg inn");
define("COMLAN_312", "Dobbel post - kan ikke akseptere.");
define("COMLAN_313", "Plassering");
define("COMLAN_314", "moderer kommentarer");
define("COMLAN_315", "Trackbacks");
define("COMLAN_316", "Ingen trackbacks for denne nyhetsposten");
define("COMLAN_317", "Moderer trackbacks");
define("COMLAN_318", "Redigere kommentar");
define("COMLAN_319", "redigert");
define("COMLAN_320", "Oppdater kommentar");
define("COMLAN_321", "her");
define("COMLAN_322", "til innmelding");
define("COMLAN_323", "Feil!");
define("COMLAN_324", "Emne");
define("COMLAN_325", "Sv:");
define("COMLAN_326", "Svar på dette");
define("COMLAN_327", "Rangering");
define("COMLAN_328", "Kommentarer er stengt");
define("COMLAN_329", "Uautroisert");
define("COMLAN_330", "IP:");
define("COMLAN_TYPE_1", "nyheter");
define("COMLAN_TYPE_2", "nedlastning");
define("COMLAN_TYPE_3", "faq");
define("COMLAN_TYPE_4", "avstamming");
define("COMLAN_TYPE_5", "docs");
define("COMLAN_TYPE_6", "bugtrack");
define("COMLAN_TYPE_7", "ideer");
define("COMLAN_TYPE_8", "brukerprofil");


?>