<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_links.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/01 01:14:26$
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Linker");
define("LAN_61", "Linkkategorier");
define("LAN_62", "kategorier");
define("LAN_63", "kategori");
define("LAN_64", "i denne kategorien");
define("LAN_65", "link");
define("LAN_66", "linker");
define("LAN_67", "Vis alla linker");
define("LAN_68", "rediger");
define("LAN_69", "slett");
define("LAN_86", "Kategori:");
define("LAN_88", "Henvisninger:");
define("LAN_89", "Admin: ");
define("LAN_90", "legg til ny link i denne kategori");
define("LAN_91", "legg til ny kategor1");
define("LAN_92", "Send innen link");
define("LAN_93", "Etter at du har sendt inn en link kommer den til å granskes av en admin og om den er passende kommer den til å legges inn i linksamlingen.");
define("LAN_94", "linknavn:");
define("LAN_95", "link URL:");
define("LAN_96", "linkbeskrivelse:");
define("LAN_97", "URL til linkknapp:");
define("LAN_98", "Send link");
define("LAN_99", "Takk");
define("LAN_100", "Linken din er lagret og vil bli gransket av en nettstedsadministrator.");
define("LAN_101", "Klikk her for å sende inn en link");
define("LAN_102", "Det");
define("LAN_103", "finnes");
define("LAN_104", "finnse");
define("LAN_105", "totalt i");
define("LAN_106", "Understrekede felt er nødvendige.");
define("LAN_Links_1", "Linker totalt");
define("LAN_Links_2", " Aktive linker totalt");
define("LAN_LINKS_3", "Anonym");


?>