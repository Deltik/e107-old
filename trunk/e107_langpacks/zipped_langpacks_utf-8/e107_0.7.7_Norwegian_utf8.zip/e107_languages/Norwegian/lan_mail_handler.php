<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Norwegian/lan_mail_handler.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/02 13:49:34 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Produsert av e107 nettstedssystem");
define("LANMAILH_2", "Dette er en flerdelt melding i MIME format.");
define("LANMAILH_3", " er ikke korrekt formatert");
define("LANMAILH_4", "Serveren forkastet adressen");
define("LANMAILH_5", "Ingen respons fra serveren");
define("LANMAILH_6", "Kan ikke finne epostserveren.");
define("LANMAILH_7", " ser ut til å være gyldig.");


?>