﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/phpmailer/language/phpmailer.lang-no,v$
|     $Revision: 1.0 $
|     $Date: 2006/01/29 19:13:11 $
|     $Author: Asta $
|
+----------------------------------------------------------------------------+
*/

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Du må angi minst en ' . 'mottakerepostadresse.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer støttes ikke.';
$PHPMAILER_LANG["execute"] = 'Kan ikke utføre: ';
$PHPMAILER_LANG["instantiate"] = 'Kunne ikke opprette en instans for mailfunksjonen.';
$PHPMAILER_LANG["authenticate"] = 'SMTP feil: Kunde inte autentisera.';
$PHPMAILER_LANG["from_failed"] = 'Følgende avsenderadresse mislyktes: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP feil: Følgende ' . 'mottagare mislyktes: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP feil: Data ikke akseptert.';
$PHPMAILER_LANG["connect_host"] = 'SMTP feil: Kunne ikke koble til SMTP server.';
$PHPMAILER_LANG["file_access"] = 'Ikke tilgang til filen: ';
$PHPMAILER_LANG["file_open"] = 'Filfeil: Kunne ikke åpne filen: ';
$PHPMAILER_LANG["encoding"] = 'Ukjent koding: ';

?>