﻿/*
+ ----------------------------------------------------------------------------+
|     Norwegian lang variables.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/ibrowser/langs/no.js,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/29 22:51:50 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

tinyMCELang['lang_ibrowser_title'] = 'Sett inn / Rediger bilde';
tinyMCELang['lang_ibrowser_desc'] = 'Sett inn / Rediger bilde';
tinyMCELang['lang_ibrowser_library'] = 'Bibliotek';
tinyMCELang['lang_ibrowser_preview'] = 'Forhåndsvisning';
tinyMCELang['lang_ibrowser_img_sel'] = 'Bildevalg';
tinyMCELang['lang_ibrowser_img_info'] = 'Bildeinformasjon';
tinyMCELang['lang_ibrowser_img_upload'] = 'Last opp bilde';
tinyMCELang['lang_ibrowser_images'] = 'Bilder';
tinyMCELang['lang_ibrowser_src'] = 'Kilde';
tinyMCELang['lang_ibrowser_alt'] = 'Beskrivelse';
tinyMCELang['lang_ibrowser_size'] = 'Størrelse';
tinyMCELang['lang_ibrowser_align'] = 'Tekstbrytning';
tinyMCELang['lang_ibrowser_height'] = 'Høyde';
tinyMCELang['lang_ibrowser_width'] = 'Bredde';
tinyMCELang['lang_ibrowser_reset'] = 'Tilbakestill bilde';
tinyMCELang['lang_ibrowser_border'] = 'Ramme';
tinyMCELang['lang_ibrowser_hspace'] = 'H-avstand';
tinyMCELang['lang_ibrowser_vspace'] = 'V-avstand';
tinyMCELang['lang_ibrowser_select'] = 'Lagre';
tinyMCELang['lang_ibrowser_delete'] = 'Slett';
tinyMCELang['lang_ibrowser_cancel'] = 'Avbryt';
tinyMCELang['lang_ibrowser_uploadtxt'] = 'Fil';
tinyMCELang['lang_ibrowser_uploadbt'] = 'Last opp';
// error messages
tinyMCELang['lang_ibrowser_error'] = 'Feil';
tinyMCELang['lang_ibrowser_errornoimg'] = 'Velg et bilde';
tinyMCELang['lang_ibrowser_errornodir'] = 'Fysiskt bibliotek mangler';
tinyMCELang['lang_ibrowser_errorupload'] = 'En feil oppstod ved opplastningen.\nPrøv igjen seinere..';
tinyMCELang['lang_ibrowser_errortype'] = 'Feil filtype på bilde';
tinyMCELang['lang_ibrowser_errordelete'] = 'Sletting mislykket';
tinyMCELang['lang_ibrowser_confirmdelete'] = 'Klikk OK for å slette bilde!';
tinyMCELang['lang_ibrowser_error_width_nan'] = 'Bredden er ikke et tall!';
tinyMCELang['lang_ibrowser_error_height_nan'] = 'Høyden er ikke et tall!';
tinyMCELang['lang_ibrowser_error_border_nan'] = 'Rammen er ikke et tall!';
tinyMCELang['lang_ibrowser_error_hspace_nan'] = 'Horisontal avstand er ikke et tall!';
tinyMCELang['lang_ibrowser_error_vspace_nan'] = 'Vertikalt avstand er ikke et tall!';