﻿/*
+ ----------------------------------------------------------------------------+
|     Norwegian (NO) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/iespell/langs/no.js,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/31 00:32:52 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
iespell_desc : 'Kjør stavekontroll',
iespell_download : "Ser ikke ut til at ieSpell er installert. Klikk OK for å laste den ned."
});
