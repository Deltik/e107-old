﻿/*
+ ----------------------------------------------------------------------------+
|     Norwegian (NO) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/emoticons/langs/no.js,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/29 22:44:10 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

tinyMCELang['lang_insert_emotions_title'] = 'Sett inn smil';
tinyMCELang['lang_emotions_desc'] = 'Smil';
