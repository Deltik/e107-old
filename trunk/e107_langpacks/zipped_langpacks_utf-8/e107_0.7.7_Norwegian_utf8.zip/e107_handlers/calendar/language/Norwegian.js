﻿/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     Calendar NO language
|     Encoding: UTF-8
|     Distributed under the same terms as the calendar itself.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/calendar/language/Norwegian.js,v $
|     $Revision: 1.0 $
|     $Date: 2006/01/29 19:10:42$
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

// full day names
Calendar._DN = new Array
("Søndag",
 "Mandag",
 "Tirsdag",
 "Onsdag",
 "Torsdag",
 "Fredag",
 "Lørdag",
 "Søndag");

// Please note that the following array of short day names (and the same goes
// for short month names, _SMN) isn't absolutely necessary.  We give it here
// for exemplification on how one can customize the short day names, but if
// they are simply the first N letters of the full name you can simply say:
//
//   Calendar._SDN_len = N; // short day name length
//   Calendar._SMN_len = N; // short month name length
//
// If N = 3 then this is not needed either since we assume a value of 3 if not
// present, to be compatible with translation files that were written before
// this feature.

// short day names
Calendar._SDN = new Array
("Søn",
 "Man",
 "Tir",
 "Ons",
 "Tor",
 "Fre",
 "Lør",
 "Søn");

// First day of the week. "0" means display Sunday first, "1" means display
// Monday first, etc.
Calendar._FD = 1;

// full month names
Calendar._MN = new Array
("Januar",
 "Februar",
 "Mars",
 "April",
 "Mai",
 "Juni",
 "Juli",
 "August",
 "September",
 "Oktober",
 "November",
 "Desember");

// short month names
Calendar._SMN = new Array
("Jan",
 "Feb",
 "Mar",
 "Apr",
 "Mai",
 "Jun",
 "Jul",
 "Aug",
 "Sep",
 "Okt",
 "Nov",
 "Des");

// tooltips
Calendar._TT = {};
Calendar._TT["INFO"] = "Om kalenderen";

Calendar._TT["ABOUT"] =
"DHTML Dato/Tidsvelger\n" +
"(c) dynarch.com 2002-2005 / Author: Mihai Bazon\n" + // don't translate this ;-)
"For siste versjon, besøk: http://www.dynarch.com/projects/calendar/\n" +
"Distribueres under GNU LGPL.  Se http://gnu.org/licenses/lgpl.html for detaljer." +
"\n\n" +
"Datovalg\n" +
"- Bruk \xab, \xbb knappene for å velge år\n" +
"- Bruk " + String.fromCharCode(0x2039) + ", " + String.fromCharCode(0x203a) + " knappene for å velge måned\n" +
"- Hold nede museknappen på en av de ovenforstående knappene for å bla raskere.";
Calendar._TT["ABOUT_TIME"] = "\n\n" +
"Valg av tid:\n" +
"- Klikk på en av delen på klokken for å flytte fremover\n" +
"- eller shift-klikk for å flytte bakover\n" +
"- eller klikk og dra for å endre den raskere.";

Calendar._TT["PREV_YEAR"] = "Forrige år (hold for meny)";
Calendar._TT["PREV_MONTH"] = "Forrige måned(hold for meny)";
Calendar._TT["GO_TODAY"] = "Til idag";
Calendar._TT["NEXT_MONTH"] = "Neste måned(hold for meny)";
Calendar._TT["NEXT_YEAR"] = "Neste år(hold for meny)";
Calendar._TT["SEL_DATE"] = "Velg dato";
Calendar._TT["DRAG_TO_MOVE"] = "Dra for å flytte";
Calendar._TT["PART_TODAY"] = " (idag)";

// the following is to inform that "%s" is to be the first day of week
// %s will be replaced with the day name.
Calendar._TT["DAY_FIRST"] = "Vis %s først";

// This may be locale-dependent.  It specifies the week-end days, as an array
// of comma-separated numbers.  The numbers are from 0 to 6: 0 means Sunday, 1
// means Monday, etc.
Calendar._TT["WEEKEND"] = "0,6";

Calendar._TT["CLOSE"] = "Lukk";
Calendar._TT["TODAY"] = "Idag";
Calendar._TT["TIME_PART"] = "(Shift-)klikk eller dra for å endre verdi";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "%d-%m-%Y";
Calendar._TT["TT_DATE_FORMAT"] = "%a, %b %e";

Calendar._TT["WK"] = "uke";
Calendar._TT["TIME"] = "Tid:";
