<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/interfectus/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 17:58:24 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'interfectus' av <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Les/Post kommentar: ");
define("LAN_THEME_3", "Kommentarer er deaktivert for dette objektet");
define("LAN_THEME_4", "Les resten ...");
define("LAN_THEME_5", "Tilbakelink: ");
?>
