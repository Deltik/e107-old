<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Norwegian language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/e107v4a/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 17:52:01 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Les/Post kommentar: ");
define("LAN_THEME_2", "Kommentarer er deaktivert for dette objektet");
define("LAN_THEME_3", "Les resten ...");
define("LAN_THEME_4", "Kommentar av");
define("LAN_THEME_5", "den");
define("LAN_THEME_6", "e107.v4 tema av <a href='http://e107.org' rel='external'>jalist</a>");

?>
