<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Norwegian language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/leaf/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 18:09:54 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Kommentar(er) ");
define("LAN_THEME_2", "Kommentarer er deaktivert for dette objektet");
define("LAN_THEME_3", "kommentar(er): ");
define("LAN_THEME_4", "Les resten ...");
define("LAN_THEME_5", "Tilbakelink: ");
define("LAN_THEME_6", "Kommentar av");
?>
