<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Norwegian language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/jayya/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 18:01:22 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Kommentarer er deaktivert for dette objektet");
define("LAN_THEME_2", "Les/Post kommentar: ");
define("LAN_THEME_3", "Les resten ...");
define("LAN_THEME_4", "Tilbakelink: ");
define("LAN_THEME_5", "Kommentar av");
define("LAN_THEME_6", "den");

?>
