<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Norwegian language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/crahan/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 17:47:03 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'CraHan' av <a href='http://e107.org' rel='external'>jalist</a>, basert på tame av CraHan p� hans hjemmeside <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Kommentarer er deaktivert for dette objektet");
define("LAN_THEME_3", "kommentar(er): ");
define("LAN_THEME_4", "Les resten ...");
define("LAN_THEME_5", "Tilbakelink: ");
define("LAN_THEME_6", "Kommentar av");


?>