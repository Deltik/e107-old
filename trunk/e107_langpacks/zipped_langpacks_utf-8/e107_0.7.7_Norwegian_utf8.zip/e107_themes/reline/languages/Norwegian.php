<?php
/*
+---------------------------------------------------------------+
|        e107 website system Norwegian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_themes/reline/languages/Norwegian.php $
|        $Revision: 1.0 $
|        $Date: 2006/11/24 11:27:45 $
|        $Author: eelay $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Kommentarter er slått av for denne saken");
define("LAN_THEME_2", "Les/post kommentar:");
define("LAN_THEME_3", "Les resten ...");
define("LAN_THEME_4", "Trackbacks:");
define("LAN_THEME_5", "Postet av");
define("LAN_THEME_6", "på");
define("LAN_THEME_7", "Søk ...");


?>