<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Norwegian language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/human_condition/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 17:55:13 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'Human Condition' av <a href='http://e107.org' rel='external'>jalist</a>, basert på Wordpress temaet, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Kommentarer er deaktivert for dette objektet");
define("LAN_THEME_3", "kommentar(er): ");
define("LAN_THEME_4", "Les resten ...");
define("LAN_THEME_5", "Tilbakelink: ");
define("LAN_THEME_6", "Kommentar av");


?>