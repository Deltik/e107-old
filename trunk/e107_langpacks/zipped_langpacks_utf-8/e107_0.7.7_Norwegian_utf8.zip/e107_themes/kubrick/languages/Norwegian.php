<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Norwegian language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/kubrick/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 18:05:41 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'kubrick' av <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> & <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Basert på originaltema av Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Kommentarer er deaktivert for dette objektet");
define("LAN_THEME_3", "kommentar(er): ");
define("LAN_THEME_4", "Les resten ...");
define("LAN_THEME_5", "Tilbakelink: ");


?>