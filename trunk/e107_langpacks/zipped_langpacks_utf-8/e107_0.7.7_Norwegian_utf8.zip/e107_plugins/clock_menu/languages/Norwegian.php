<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/11 03:11:00 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CLOCK_MENU_L1", "Klokkemenykonfigurasjon lagret");
define("CLOCK_MENU_L2", "Overskrift");
define("CLOCK_MENU_L3", "Oppdater menyinnstillinger");
define("CLOCK_MENU_L4", "Klokkemenykonfigurasjon");
define("CLOCK_MENU_L5", "Mandag,");
define("CLOCK_MENU_L6", "Tirsdag,");
define("CLOCK_MENU_L7", "Onsdag,");
define("CLOCK_MENU_L8", "Torsdag,");
define("CLOCK_MENU_L9", "Fredag,");
define("CLOCK_MENU_L10", "Lørdag,");
define("CLOCK_MENU_L11", "Søndag,");
define("CLOCK_MENU_L12", "Januar");
define("CLOCK_MENU_L13", "Februar");
define("CLOCK_MENU_L14", "Mars");
define("CLOCK_MENU_L15", "April");
define("CLOCK_MENU_L16", "Mai");
define("CLOCK_MENU_L17", "Juni");
define("CLOCK_MENU_L18", "Juli");
define("CLOCK_MENU_L19", "August");
define("CLOCK_MENU_L20", "September");
define("CLOCK_MENU_L21", "Oktober");
define("CLOCK_MENU_L22", "November");
define("CLOCK_MENU_L23", "Desember");
define("CLOCK_MENU_L24", "");


?>