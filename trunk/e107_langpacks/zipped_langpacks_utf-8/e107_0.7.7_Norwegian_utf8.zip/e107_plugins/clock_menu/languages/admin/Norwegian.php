<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/admin/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/11 03:18:24 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Klokkemenykonfigurasjon lagret");
define("CLOCK_AD_L2", "Overskrift");
define("CLOCK_AD_L3", "Oppdater menyinnstillinger");
define("CLOCK_AD_L4", "Klokkemenykonfigurasjon");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Hvis markert kommer tid til å vises i amerikansk format (0-12 AM/PM format). Uten merke vises tid i 'militært/europeisk' format 0-24.");
define("CLOCK_AD_L7", "Datoprefiks");
define("CLOCK_AD_L8", "Om språket ditt krever et kort ord foran datoen (f.eks.'le' på fransk eller 'den' på norsk...), så bruk dette feltet. Hvis ikke, la stå tomt.");
define("CLOCK_AD_L9", "Suffiks 1");
define("CLOCK_AD_L10", "Suffiks 2");
define("CLOCK_AD_L11", "Suffiks 3");
define("CLOCK_AD_L12", "Suffiks 4 og mer");
define("CLOCK_AD_L13", "Om språket ditt krever et suffix rett etter datoens siffer, fyll da ut disse feltene med kun suffikset. (T.ex: 'ste' for 1, 'e' for 2, 'e' for 3 og 'de' for 4 og så videre). Hvis ikke, la stå tomt.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");


?>