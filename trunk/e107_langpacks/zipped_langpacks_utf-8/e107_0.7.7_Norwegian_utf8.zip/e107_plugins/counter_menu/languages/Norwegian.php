<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/counter_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/08 11:04:32 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "Adminbesøk regnes ikke.");
define("COUNTER_L2", "Denne siden idag");
define("COUNTER_L3", "Totalt");
define("COUNTER_L4", "Siden starten på denne siden...");
define("COUNTER_L5", "unike");
define("COUNTER_L6", "Nettsted...");
define("COUNTER_L7", "Teller");
define("COUNTER_L8", "Adminbeskjed: <b>Statistikklogging er ikke aktivert.</b><br />For å aktivere må du installere statistikkloggingplugin'en fra <a href='".e_ADMIN."plugin.php'>pluginhåndtereren</a>, og aktiver den deretter fra <a href='".e_PLUGIN."log/admin_config.php'>konfigurasjonssiden</a>.");


?>