<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/userlanguage_menu/languages/Norwegian.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/03 03:04:49 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("UTHEME_MENU_L1", "Sett språk");
define("UTHEME_MENU_L2", "Velg språk");
define("UTHEME_MENU_L3", "Tabeller");


?>