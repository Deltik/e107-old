<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/pm/languages/admin/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 18:41:01 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("ADLAN_PM", "Private meldinger
");
define("ADLAN_PM_1", "For å aktivere, gå til dine menyer og velg private_msg i et av menyområdene.<br /><br />Om du trenger konverter meldinger fra en tidligere versjon, gå til hovedkonfigurasjonssiden for denne plugin'en og velg linken 'konverter'.");
define("ADLAN_PM_2", "Konfigurer private meldinger");
define("ADLAN_PM_3", "PM innstillinger ikke funnet, bruker standardinnstillinger");
define("ADLAN_PM_4", "Alternativene oppdatert");
define("ADLAN_PM_5", "Begrensning for valgt brukerklasse finnes allerede");
define("ADLAN_PM_6", "Begrensning lagt til");
define("ADLAN_PM_7", "Begrensning ikke lagt til - ukjent feil");
define("ADLAN_PM_8", "Begrensningsstatus oppdatert");
define("ADLAN_PM_9", " - Begrensning fjernet");
define("ADLAN_PM_10", " - Begrensning ikke fjernet - ukjent feil");
define("ADLAN_PM_11", " - Begrensning oppdatert");
define("ADLAN_PM_12", "PM alternativer");
define("ADLAN_PM_13", "PM konvertering");
define("ADLAN_PM_14", "PM begrensninger ");
define("ADLAN_PM_15", "Legg til PM begrensning");
define("ADLAN_PM_16", "Plugin tittel");
define("ADLAN_PM_17", "Vis ny PM animasjon");
define("ADLAN_PM_18", "Vis rullegardinmeny for brukere");
define("ADLAN_PM_19", "Tidsbegrensning for LESTE meldinger");
define("ADLAN_PM_20", "Tidsbegrensning for ULESTE meldinger");
define("ADLAN_PM_21", "Popupbeskjed om ny PM");
define("ADLAN_PM_22", "Popup tidsutsettelse");
define("ADLAN_PM_23", "Begrens PM til");
define("ADLAN_PM_24", "Antall PM pr side");
define("ADLAN_PM_25", "Aktiver epostbeskjed for PM");
define("ADLAN_PM_26", "Tillat brukere å be om mottakskvittering via e-post");
define("ADLAN_PM_27", "Tillat posting av vedlegg");
define("ADLAN_PM_28", "Maksimal størrelse på vedlegg");
define("ADLAN_PM_29", "Tillat sending til alle medlemmer");
define("ADLAN_PM_30", "Tillat sending til flere mottakere");
define("ADLAN_PM_31", "Aktiver sending til brukerklasse");
define("ADLAN_PM_32", "Oppdater innstillinger");
define("ADLAN_PM_33", "Inaktiv (ingen begrensninger)");
define("ADLAN_PM_34", "PM teller");
define("ADLAN_PM_35", "PM vindusstørrelse");
define("ADLAN_PM_36", "Brukerklasse");
define("ADLAN_PM_37", "Regnerbegrensninger");
define("ADLAN_PM_38", "Størrelsesbegrensning(i kB)");
define("ADLAN_PM_39", "Innboks :");
define("ADLAN_PM_40", "Utboks :");
define("ADLAN_PM_41", "Det er for tiden ikke satt noen begrensninger.");
define("ADLAN_PM_42", "Oppdater begrensninger");
define("ADLAN_PM_43", "Legg til ny begrensning");
define("ADLAN_PM_44", "sekunder");
define("ADLAN_PM_45", "Begrens PM med: ");
define("ADLAN_PM_46", "PM konvertering");
define("ADLAN_PM_47", "Det virker ikke som du har noen gamle meldinger fra tidligere versjoner, det er ok å avinstallere den gamle pluginmodulen.");
define("ADLAN_PM_48", "Du har {OLDCOUNT} meldinger fra en tidligere versjon, velg hva du vil gjøre med disse meldingene<br /><br />Om du konverterer meldingene, kommer riktig konvertertemeldinger til å bli fjernet fra det gamle systemet.");
define("ADLAN_PM_49", "Konverter til nye PM");
define("ADLAN_PM_50", "Forkast gamle meldinger");
define("ADLAN_PM_51", "PM #{PMNUM} ble ikke konvertert");
define("ADLAN_PM_52", "meldinger konvertert");
define("ADLAN_PM_53", "Fant ingen poster å konvertere.");
define("ADLAN_PM_54", "Hovedinnstillinger");
define("ADLAN_PM_55", "Begrensninger");
define("ADLAN_PM_56", "Konvertering");
define("ADLAN_PM_57", "Denne plugin er et privat meldingsplugin med alle funksjoner.");
define("ADLAN_PM_58", "Private Meldinger");


?>