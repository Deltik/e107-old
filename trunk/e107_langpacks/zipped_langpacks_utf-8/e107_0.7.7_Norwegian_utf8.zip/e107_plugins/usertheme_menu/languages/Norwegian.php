<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/usertheme_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 03:03:27 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_350", "Sett tema");
define("LAN_351", "Velg tema");


?>