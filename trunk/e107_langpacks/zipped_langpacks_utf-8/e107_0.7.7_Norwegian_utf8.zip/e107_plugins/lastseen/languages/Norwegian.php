<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/lastseen/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 01:44:30 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LSP_LAN_1", "Siste innloggede");


?>