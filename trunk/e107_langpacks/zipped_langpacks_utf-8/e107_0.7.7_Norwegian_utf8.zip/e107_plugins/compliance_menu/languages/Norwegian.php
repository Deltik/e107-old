<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/compliance_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/11 03:06:09 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("COMPLIANCE_L1", "W3C kompatibelt");


?>