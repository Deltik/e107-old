<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/calendar_menu/languages/Norwegian_search.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/11 12:42:35 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CM_SCH_LAN_1", "Kalender");


?>