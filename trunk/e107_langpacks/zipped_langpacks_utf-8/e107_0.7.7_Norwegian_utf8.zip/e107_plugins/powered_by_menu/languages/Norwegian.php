<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/powered_by_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 12:00:44 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("POWEREDBY_L1", "Kjører på ");


?>