<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/links_page/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 02:13:30 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LCLAN_PLUGIN_LAN_1", "Linkside");
define("LCLAN_PLUGIN_LAN_2", "Linkside for å vise eksterne weblinker");
define("LCLAN_PLUGIN_LAN_3", "Konfigurer linkside");
define("LCLAN_PLUGIN_LAN_4", "Linker");
define("LCLAN_PLUGIN_LAN_5", "Linksiden ble korrekt installert, gå til linksiden fra adminførstesiden for å konfigurere den.");
define("LCLAN_PLUGIN_LAN_6", "Linksiden ble korrekt oppdatert, nå brukes versjon");
define("LCLAN_OPT_MENU_1", "Generelle alternativ");
define("LCLAN_OPT_MENU_2", "Personlige linkbehandlere");
define("LCLAN_OPT_MENU_3", "Kategoriside");
define("LCLAN_OPT_MENU_4", "Linkvisning");
define("LCLAN_OPT_MENU_5", "Henvisninger side");
define("LCLAN_OPT_MENU_6", "Karakterside");
define("LCLAN_OPT_MENU_7", "Meny");
define("LCLAN_PAGETITLE_1", "Linker");
define("LCLAN_PAGETITLE_2", "Alle kategorier");
define("LCLAN_PAGETITLE_3", "Alle linker");
define("LCLAN_PAGETITLE_4", "kategori");
define("LCLAN_PAGETITLE_5", "Toppkarakter");
define("LCLAN_PAGETITLE_6", "Topp henvisere");
define("LCLAN_PAGETITLE_7", "Personlig linkbehandler");
define("LCLAN_PAGETITLE_8", "Linkkommentarer");
define("LCLAN_PAGETITLE_9", "Send inn link");
define("LCLAN_PAGETITLE_10", "");
define("LCLAN_OPT_1", "Generelle alternativ");
define("LCLAN_OPT_2", "Linkside alternativ");
define("LCLAN_OPT_3", "aktivert");
define("LCLAN_OPT_4", "deaktivert");
define("LCLAN_OPT_5", "pxl");
define("LCLAN_OPT_6", "");
define("LCLAN_OPT_7", "Del kategorier til individuelle sider");
define("LCLAN_OPT_8", "Tillat innsending av linker");
define("LCLAN_OPT_9", "Hvem får sende inn linker?");
define("LCLAN_OPT_10", "Bruk flere sider for å vise linker");
define("LCLAN_OPT_11", "Antall linker pr side");
define("LCLAN_OPT_12", "Kategoriside");
define("LCLAN_OPT_13", "Vis hvilke seksjoner");
define("LCLAN_OPT_14", "Ikon");
define("LCLAN_OPT_15", "Beskrivelse");
define("LCLAN_OPT_16", "Mengde");
define("LCLAN_OPT_17", "Henvisning");
define("LCLAN_OPT_18", "URL");
define("LCLAN_OPT_19", "Total kategori infolinje (linjen lengst ned)");
define("LCLAN_OPT_20", "Link til topp henvisninger");
define("LCLAN_OPT_21", "Link til toppbetyg");
define("LCLAN_OPT_22", "Vis standardikon om ingen andre finnes");
define("LCLAN_OPT_23", "Standard sorteringsmetode");
define("LCLAN_OPT_24", "Standard metode for rekkefølge");
define("LCLAN_OPT_25", "Standard skaleringsverdi");
define("LCLAN_OPT_26", "Linksida");
define("LCLAN_OPT_27", "Tillat brukere å sette karakterer på linker");
define("LCLAN_OPT_28", "Vis standardikon om andre finnes");
define("LCLAN_OPT_29", "Vis sorter og ordn meny");
define("LCLAN_OPT_30", "Stigende");
define("LCLAN_OPT_31", "Fallende");
define("LCLAN_OPT_32", "sett tilside linkers åpningsmetode");
define("LCLAN_OPT_33", "Standard skaleringsverdi");
define("LCLAN_OPT_34", "Navn");
define("LCLAN_OPT_35", "URL");
define("LCLAN_OPT_36", "Rekkefølge");
define("LCLAN_OPT_37", "Henvisning");
define("LCLAN_OPT_38", "");
define("LCLAN_OPT_39", "");
define("LCLAN_OPT_40", "Navn");
define("LCLAN_OPT_41", "ID");
define("LCLAN_OPT_42", "Bruk individuelle linkinnstillinger");
define("LCLAN_OPT_43", "Åpnes i samme vindu");
define("LCLAN_OPT_44", "Åpnes i nytt vindu");
define("LCLAN_OPT_45", "Åpnes i 600x400 minivindu");
define("LCLAN_OPT_46", "Hvem kan håndtere linker");
define("LCLAN_OPT_47", "Disse brukerne kan legga til/redigera sine egne personlige linker");
define("LCLAN_OPT_48", "Tillat direktepostning");
define("LCLAN_OPT_49", "Om aktivert kommer linker til å postes direkte, ellers må en nettstedsadministrator godkjenne dem først");
define("LCLAN_OPT_50", "Tillat direkte sletting");
define("LCLAN_OPT_51", "Om aktivert kan linkhåndterere selv slette sine egne linker");
define("LCLAN_OPT_52", "Personlig linkhåndterere");
define("LCLAN_OPT_53", "Dato");
define("LCLAN_OPT_54", "Tillat personlig håndtering av linker");
define("LCLAN_OPT_55", "Tillat kommentarer til alle linker");
define("LCLAN_OPT_56", "Minimum henvisningsverdi");
define("LCLAN_OPT_57", "Kun linker med flere henvisninger enn det gitte antallet vises (0 eller tomt = alle)");
define("LCLAN_OPT_58", "Link for å sende inn link");
define("LCLAN_OPT_59", "Link til den personlige håndtereren (bare hvis tillatt)");
define("LCLAN_OPT_60", "Link til linkers førsteside");
define("LCLAN_OPT_61", "Link til alle kategorier");
define("LCLAN_OPT_62", "Vis disse navigeringslinker");
define("LCLAN_OPT_63", "Minimum karakterverdi");
define("LCLAN_OPT_64", "Kun linker med høyere karakter enn angitt verdi kommer til å vises(0 eller tomt = alle)");
define("LCLAN_OPT_65", "Vis tomme kategorier");
define("LCLAN_OPT_66", "Link til hver kategori");
define("LCLAN_OPT_67", "Link til alle linker");
define("LCLAN_OPT_68", "Vis alle linker");
define("LCLAN_OPT_69", "Visningstype navigatorlinker");
define("LCLAN_OPT_70", "Vis kategorilinker");
define("LCLAN_OPT_71", "Visningstype kategorilinker");
define("LCLAN_OPT_72", "Vis tidligere linker");
define("LCLAN_OPT_73", "Hvilke data skal vises");
define("LCLAN_OPT_74", "Hvor mange tidligere linker skal vises");
define("LCLAN_OPT_75", "Hyperlinker");
define("LCLAN_OPT_76", "Rullegardinmeny");
define("LCLAN_OPT_77", "Kategori");
define("LCLAN_OPT_78", "Beskrivelse");
define("LCLAN_OPT_79", "Navigatoroverskrift");
define("LCLAN_OPT_80", "Overskrift kategorier");
define("LCLAN_OPT_81", "Overskrift tidligere liste");
define("LCLAN_OPT_82", "Navigator");
define("LCLAN_OPT_83", "Kategorier");
define("LCLAN_OPT_84", "Liste, tidligere");
define("LCLAN_OPT_85", "Menyoverskrift");
define("LCLAN_OPT_86", "Link meny");
define("LCLAN_OPT_87", "Antall linker å vise");
define("LCLAN_ADMIN_1", "Oppdater");
define("LCLAN_ADMIN_2", "Link lagret til databasen.");
define("LCLAN_ADMIN_3", "Link oppdatert i databasen.");
define("LCLAN_ADMIN_4", "Linkkategori lagret");
define("LCLAN_ADMIN_5", "Linkkategori oppdatert");
define("LCLAN_ADMIN_6", "Alternativ lagrede");
define("LCLAN_ADMIN_7", "Linkikon opplastet!");
define("LCLAN_ADMIN_8", "Linkikon ble ikke lastet opp!");
define("LCLAN_ADMIN_9", "Rekkefølge oppdatert");
define("LCLAN_ADMIN_10", "Link");
define("LCLAN_ADMIN_11", "slettet");
define("LCLAN_ADMIN_12", "Linkkategori");
define("LCLAN_ADMIN_13", "Innsendt link slettet");
define("LCLAN_ADMIN_14", "Linker");
define("LCLAN_ADMIN_15", "Denne kategorien inneholder fortatt linker, venligst fjern/flytt disse først");
define("LCLAN_SL_1", "Innsendte linker");
define("LCLAN_SL_2", "Ingen innsendte linker");
define("LCLAN_SL_3", "Link");
define("LCLAN_SL_4", "Innsendt av");
define("LCLAN_SL_5", "Alternativ");
define("LCLAN_SL_6", "Post");
define("LCLAN_SL_7", "Slett");
define("LCLAN_SL_8", "Er du sikker på at du vil slette denne innsendte linken?");
define("LCLAN_SL_9", "Etter at du har sendt inn linken vil den bli sett på av en nettstedsadministrator, og om den anses å være passende vil den legges til på linksiden.");
define("LCLAN_SL_10", "Kategori:");
define("LCLAN_SL_11", "Navn");
define("LCLAN_SL_12", "URL");
define("LCLAN_SL_13", "Beskrivelse");
define("LCLAN_SL_14", "URL til linkknapp:");
define("LCLAN_SL_15", "Understrekede felt er obligatoriske.");
define("LCLAN_SL_16", "Send inn link");
define("LCLAN_SL_17", "");
define("LCLAN_SL_18", "");
define("LCLAN_CAT_1", "Bilde");
define("LCLAN_CAT_2", "Kategori");
define("LCLAN_CAT_3", "Alternativ");
define("LCLAN_CAT_4", "Flytt");
define("LCLAN_CAT_5", "Ordne");
define("LCLAN_CAT_6", "Endre");
define("LCLAN_CAT_7", "Er");
define("LCLAN_CAT_8", "Er du sikker på at du vil slette denne kategorien?");
define("LCLAN_CAT_9", "Vis linker");
define("LCLAN_CAT_10", "Endre rekkefølge");
define("LCLAN_CAT_11", "Ingen linkkategorier");
define("LCLAN_CAT_12", "Eksisterende linkkategorier");
define("LCLAN_CAT_13", "Navn:");
define("LCLAN_CAT_14", "Beskrivelse:");
define("LCLAN_CAT_15", "Last opp et nytt ikon:");
define("LCLAN_CAT_16", "Auto minibilde:");
define("LCLAN_CAT_17", "Dette alternativet er deaktivert ettersom filopplastning ikke er aktivert på din server");
define("LCLAN_CAT_18", "");
define("LCLAN_CAT_19", "katalogen er skrivebeskyttet, du må sette den til CHMOD 777 før du kan laste opp");
define("LCLAN_CAT_20", "pxl");
define("LCLAN_CAT_21", "Last opp");
define("LCLAN_CAT_22", "Velg et ikon:");
define("LCLAN_CAT_23", "Vis bilder");
define("LCLAN_CAT_24", "Synlig for:");
define("LCLAN_CAT_25", "Marker for å oppdatere tidsstempelet til nåværende tid");
define("LCLAN_CAT_26", "Oppdater linkkategori");
define("LCLAN_CAT_27", "Tøm skjemaet");
define("LCLAN_CAT_28", "Opprett linkkategori");
define("LCLAN_CAT_29", "Linkkategori");
define("LCLAN_ITEM_1", "Innsendt av");
define("LCLAN_ITEM_2", "Kategori:");
define("LCLAN_ITEM_3", "Ingen kategorier enda");
define("LCLAN_ITEM_4", "Navn:");
define("LCLAN_ITEM_5", "URL:");
define("LCLAN_ITEM_6", "Beskrivelse:");
define("LCLAN_ITEM_7", "LAst opp et ikon:");
define("LCLAN_ITEM_8", "Auto minibilde:");
define("LCLAN_ITEM_9", "Dette alternativet er deaktivert ettersom filopplastning ikke er aktivert på serveren");
define("LCLAN_ITEM_10", "");
define("LCLAN_ITEM_11", "katalogen er skrivebeskyttet, du må sette den til CHMOD 777 før du kan laste opp");
define("LCLAN_ITEM_12", "pxl");
define("LCLAN_ITEM_13", "Last opp");
define("LCLAN_ITEM_14", "Velg et ikon:");
define("LCLAN_ITEM_15", "Vis bilder");
define("LCLAN_ITEM_16", "Åpningsmetode:");
define("LCLAN_ITEM_17", "Åpne i samme vindu");
define("LCLAN_ITEM_18", "Åpne i nytt vindu");
define("LCLAN_ITEM_19", "Åpne i 600x400 minivindu");
define("LCLAN_ITEM_20", "Synlig for:");
define("LCLAN_ITEM_21", "Marker for å oppdatere tidsstempelet til nåværende tid");
define("LCLAN_ITEM_22", "Oppdater link");
define("LCLAN_ITEM_23", "Opprett link");
define("LCLAN_ITEM_24", "Linker");
define("LCLAN_ITEM_25", "Bilde");
define("LCLAN_ITEM_26", "Linknavn");
define("LCLAN_ITEM_27", "Alternativ");
define("LCLAN_ITEM_28", "Flytt");
define("LCLAN_ITEM_29", "Rekkefølge");
define("LCLAN_ITEM_30", "Endre rekkefølge");
define("LCLAN_ITEM_31", "Endre");
define("LCLAN_ITEM_32", "Slett");
define("LCLAN_ITEM_33", "Er du sikker på at du vil slette denne linken?");
define("LCLAN_ITEM_34", "Ingen ikon");
define("LCLAN_ITEM_35", "Håndtere egne linker");
define("LCLAN_ITEM_36", "Kjør");
define("LCLAN_ITEM_37", "Vis alle linker");
define("LCLAN_ITEM_38", "Alle linker");
define("LCLAN_ITEM_39", "Rangering");
define("LCLAN_ADMINMENU_1", "Linkalternativ");
define("LCLAN_ADMINMENU_2", "Håndter linkkategorier");
define("LCLAN_ADMINMENU_3", "Opprett linkkategori");
define("LCLAN_ADMINMENU_4", "Håndter linker");
define("LCLAN_ADMINMENU_5", "Opprett link");
define("LCLAN_ADMINMENU_6", "Alternativ");
define("LCLAN_ADMINMENU_7", "Innsendte linker");
define("LCLAN_ADMINMENU_8", "Kategorier");
define("NT_LAN_LP_1", "Linksidens hendelser");
define("NT_LAN_LP_2", "Link innsendt av bruker");
define("NT_LAN_LP_3", "Link innsendt");
define("LNK_SCH_LAN_2", "Alle linkkategorier");
define("LNK_SCH_LAN_3", "Alle linkdetaljer");
define("LAN_LINKS_MANAGER_0", "Ikon");
define("LAN_LINKS_MANAGER_1", "Link");
define("LAN_LINKS_MANAGER_2", "Alternativ");
define("LAN_LINKS_MANAGER_3", "Opprett ny link");
define("LAN_LINKS_MANAGER_4", "Du har ingen tilgjengelige linker");
define("LAN_LINKS_MANAGER_5", "Kategori");
define("LAN_LINKS_MANAGER_6", "");
define("LAN_LINKS_MANAGER_7", "");
define("LAN_LINKS_MANAGER_8", "");
define("LAN_LINKS_MANAGER_9", "");
define("LAN_LINKS_1", "Totalt linker");
define("LAN_LINKS_2", "Totalt aktive linker");
define("LAN_LINKS_3", "Anonym");
define("LAN_LINKS_4", "Overskrift");
define("LAN_LINKS_5", "URL");
define("LAN_LINKS_6", "Rekkefølge");
define("LAN_LINKS_7", "Henvist");
define("LAN_LINKS_8", "STIGENDE");
define("LAN_LINKS_9", "FALLENDE");
define("LAN_LINKS_10", "Topplinker: Henvisning");
define("LAN_LINKS_11", "Topplinker: Karakter");
define("LAN_LINKS_12", "Vis pr henvisning");
define("LAN_LINKS_13", "Vis pr brukerkarakter");
define("LAN_LINKS_14", "Vis linkers førstesida");
define("LAN_LINKS_15", "Sorter etter");
define("LAN_LINKS_16", "i denne kategorien");
define("LAN_LINKS_17", "link");
define("LAN_LINKS_18", "linker");
define("LAN_LINKS_19", "kategorier");
define("LAN_LINKS_20", "kategori");
define("LAN_LINKS_21", "Det");
define("LAN_LINKS_22", "finnes");
define("LAN_LINKS_23", "finnes");
define("LAN_LINKS_24", "totalt i");
define("LAN_LINKS_25", "Vis alle linker");
define("LAN_LINKS_26", "Henvisninger:");
define("LAN_LINKS_27", "Send inn en link");
define("LAN_LINKS_28", "Takk");
define("LAN_LINKS_29", "Din link er lagret og kommer til å bli sett på av en nettstedsadministrator.");
define("LAN_LINKS_30", "Linkkategorier");
define("LAN_LINKS_31", "Send inn en link");
define("LAN_LINKS_32", "Kategori:");
define("LAN_LINKS_33", "Ingen karaktersatte linker enda.");
define("LAN_LINKS_34", "Det finnes for tiden ingen linker");
define("LAN_LINKS_35", "Personlig linkhåndterer");
define("LAN_LINKS_36", "Linkkommentarer");
define("LAN_LINKS_37", "Kommentarer:");
define("LAN_LINKS_38", "Dato");
define("LAN_LINKS_39", "Linker");
define("LAN_LINKS_40", "Kategori");
define("LAN_LINKS_41", "Ingen kategorier enda");
define("LAN_LINKS_42", "Ingen linker har blitt henvist til enda");
define("LAN_LINKS_43", "Vis alle kategorier");
define("LAN_LINKS_44", "ID");
define("LAN_LINKS_45", "Linkkategori");
define("LAN_LINKS_46", "Link underkategorier");
define("LAN_LINKS_47", "Linknavigatør...");
define("LAN_LINKS_48", "-- se kategori --");
define("LAN_LINKS_49", "");
define("LAN_ADMIN_HELP_0", "Linksidens hjelp");
define("LAN_ADMIN_HELP_1", "<i>Siden Håndter linkkategorier viser alle tilgjengelige kategorier.</i><br /><br /><b>Detaljert liste</b><br />Her ser du en liste med alle kategorier og deres ikoner, navn, beskrivelse, alternativ og sorteringsinnstillinger.<br /><br /><b>Forklaring av ikoner</b><br />
".LINK_ICON_LINK." : Link til kategorien<br /><br />
".LINK_ICON_EDIT." : Rediger kategorien<br /><br />
".LINK_ICON_DELETE." : Slett kategorien<br /><br />
".LINK_ICON_ORDER_UP." : Oppoverknappen lar deg flytte kategorien en plassering oppover på listen.<br /><br />
".LINK_ICON_ORDER_DOWN." : Nedoverknappen lar deg flytte kategorien en plassering nedover på listen.<br />
<br />
<b>Ordning</b><br />Her kan du manuelt sette rekkefølgen på alle kategoriene. Du må endre rekkefølgen i valgrutene til den ønskede rekkefølgen og deretter klikke på Sorter igjen knappen nedenfor for å lagre den nye rekkefølgen.<br />");
define("LAN_ADMIN_HELP_2", "<i>Opprett linkkategori lar deg legge til nye kategorier</i><br /><br />Du kan laste opp et nytt ikon og tildele den til kategorien etter opplastning.");
define("LAN_ADMIN_HELP_3", "<i>Siden for linkhåntering viser først alle kategorier.</i><br /><br />".LINK_ICON_LINK." : Link til kategorien<br /><br />".LINK_ICON_EDIT." : Trykk på ikonet for se linkene i denne kategorien<br />");
define("LAN_ADMIN_HELP_4", "<i>Opprett link lar deg skape en ny link</i><br /><br />Du kan laste opp et nytt ikon og tildele det til linken etter opplastning.<br /><br />Åpningsmetoden lar deg bestemme hvilken måte linken skal åpnes når en bruker trykker på den.");
define("LAN_ADMIN_HELP_5", "<i>Siden for innsendte linker viser alle linker som brukere har sent inn</i><br /><br /><b>Detaljert liste</b><br />Du ser en link URL, navnet på brukeren som sende inn linken og alternativ.<br /><br /><b>Forklaring av ikoner</b><br />
".LINK_ICON_EDIT." : Post den innsendte linken til opprett linkskjemaet for å opprette en link<br /><br />
".LINK_ICON_DELETE." : Slett den innsente linken<br />
");
define("LAN_ADMIN_HELP_6", "<i>Siden med alternativ lar deg endre innstillingene for linksidepluginen</i><br /><br />
Generelle alternativ<br />
Disse alternativene brukes på alle linksider.<br /><br />
Hånder personlige linker<br />
Desse brukerne har rettigheter til å redigere sine egene linker.<br /><br />
Kategoriside<br />
Her endrer du innstillingene for kategorisiden.<br /><br />
Linkside<br />
Desse innstillingene brukes på linksidene.<br /><br />
Henvisningsside<br />
Desse innstillingene brukes på henvisningssiden.<br /><br />
Rangeringsside<br />
Desse innstillingene brukes på rangeringssiden.<br />");
define("LAN_ADMIN_HELP_7", "<i>Siden for redigering av kategorier lar deg redigere eksisterende kategorier</i><br /><br />Du kan laste opp et nytt ikon og tildele det til kategorien etter opplastning.<br />Du kan også oppdatere tidsstempelet for linken med å markere dette i kryssruten.");
define("LAN_ADMIN_HELP_8", "<i>Denne siden viser alle eksisterende linker i den valgte kategorien.</i><br /><br /><b>Detaljert liste</b><br />Du ser en liste med linker og bildet deres, navnet, alternativ og sortringsrekkefølge.<br /><br /><b>Forklaring av ikoner</b><br />
".LINK_ICON_LINK." : Link til websiden<br /><br />
".LINK_ICON_EDIT." : Rediger linken<br /><br />
".LINK_ICON_DELETE." : Slett linken<br /><br />
".LINK_ICON_ORDER_UP." : Pil oppover lar deg flytte linken en plassering opp i listen.<br /><br />
".LINK_ICON_ORDER_DOWN." : Pil nedover lar deg flytte linken en plassering ned i listen.<br />
<br />
<b>Rekkefølge</b><br />Her kan du sette rekkefølgen på linker manuelt. Du må endre rekkefølgen i boksene til den ønskede verdien manuelt og så kan du trykke på sorter om knappen for å lagre den nye rekkefølgen.<br />");
define("LAN_ADMIN_HELP_9", "<i>Siden for å redigere en link lar deg redigere en eksisterende link</i><br /><br />Du kan laste opp et nytt ikon og tildele det til linken etter opplastning.<br /><br />Åpningsmetoden lar deg bestemme hvilken måte linken skal åpnes når en bruker trykker på den.");
define("LAN_ADMIN_HELP_10", "<i>Siden for å poste en innsent linklar deg legge til den innsente linken til de eksisterende linkene</i><br /><br />En kort tekst om linken legges til i feltet for beskrivelse.<br /><br />Du kan laste opp et nytt ikon og tildele det til linken etter opplastning.<br /><br />Åpningsmetoden lar deg bestemme hvilken måte linken skal åpnes når en bruker trykker på den.");


?>