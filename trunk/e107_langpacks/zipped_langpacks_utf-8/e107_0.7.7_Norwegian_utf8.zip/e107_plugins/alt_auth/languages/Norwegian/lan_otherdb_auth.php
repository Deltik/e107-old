<?php
/*
+---------------------------------------------------------------+
|        e107 website system Norwegian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/alt_auth/languages/Norwegian/lan_otherdb_auth.php $
|        $Revision: 1.0 $
|        $Date: 2006/11/24 09:29:50 $
|        $Author: eelay $
+---------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Databasetype:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Brukernavn:");
define("OTHERDB_LAN_4", "Passord:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Tabell");
define("OTHERDB_LAN_7", "Brukernavnfelt:");
define("OTHERDB_LAN_8", "Passordfelt:");
define("OTHERDB_LAN_9", "Passordmetode:");
define("OTHERDB_LAN_10", "Konfigurer enannendb autorisasjon");
define("OTHERDB_LAN_11", "** Følgende felt er ikke nødvendige ved bruk av en e107database");


?>