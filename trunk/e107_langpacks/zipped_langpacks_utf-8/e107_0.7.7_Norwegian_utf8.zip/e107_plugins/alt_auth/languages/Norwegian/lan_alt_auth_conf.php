<?php
/*
+---------------------------------------------------------------+
|        e107 website system Norwegian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/alt_auth/languages/Norwegian/lan_alt_auth_conf.php $
|        $Revision: 1.0 $
|        $Date: 2006/11/24 09:20:55 $
|        $Author: eelay $
+---------------------------------------------------------------+
*/

define("LAN_ALT_1", "Gjeldende autorisasjonstype
");
define("LAN_ALT_2", "Oppdater innstillinger");
define("LAN_ALT_3", "velg alternativ autoriseringsrtype");
define("LAN_ALT_4", "Konfigurer parametre for");
define("LAN_ALT_5", "Konfigurer autorisasjonsparametre");
define("LAN_ALT_6", "Tilkobling feilet");
define("LAN_ALT_7", "Om tilkoblig til alternativ autorisasjon feilet, hvordan skal dette hånteres?");
define("LAN_ALT_8", "Bruker ble ikke funnet");
define("LAN_ALT_9", "Om brukernavn ikke blir funnet ved bruk av alternativ autorisasjon, hvordan skal dette hånteres?");
define("LAN_ALT_FALLBACK", "Bruk e107 Brukertabell");
define("LAN_ALT_FAIL", "Login feilet");


?>