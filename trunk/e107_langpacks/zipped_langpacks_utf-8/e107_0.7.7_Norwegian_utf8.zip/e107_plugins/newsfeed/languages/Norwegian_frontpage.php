<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsfeed/languages/Norwegian_frontpage.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 22:06:57 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("NWSF_FP_1", "Nyhetsstrømmen");
define("NWSF_FP_2", "Hovedside");


?>