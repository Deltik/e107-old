<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/tree_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 03:06:09 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Konfigurer tremeny");
define("TREE_L2", "Oppdater innstillinger for tremeny");
define("TREE_L3", "Tremenykonfigurasjon lsgret.");
define("TREE_L4", "På");
define("TREE_L5", "Av");
define("TREE_L6", "CSSklasse som brukes for linker som ikke kan åpnes.");
define("TREE_L7", "CSSklasse som brukes for linker som kan åpnes");
define("TREE_L8", "CSSklasse for åpnede linker");
define("TREE_L9", "Bruk mellomromklasse mellom hovedlinker");


?>