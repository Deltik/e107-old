<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/login_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 22:45:13 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LOGIN_MENU_L1", "Brukernavn: ");
define("LOGIN_MENU_L2", "Passord: ");
define("LOGIN_MENU_L3", "Registrer");
define("LOGIN_MENU_L4", "Glemt passord?");
define("LOGIN_MENU_L5", "Velkommen");
define("LOGIN_MENU_L6", "Husk meg");
define("LOGIN_MENU_L7", "Bruker-ID gjenkjennes ikke (muligens en korrupt cookie).<br />Vennligst <a href=\"".e_BASE."index.php?logout\">klikk her</a> for å ødelegge cookien.");
define("LOGIN_MENU_L8", "Logg ut");
define("LOGIN_MENU_L9", "Innloggingsfeil");
define("LOGIN_MENU_L10", "Vedlikeholdsflagget satt - dette betyr at vanlige brukere omdirigeres til sitedown.php. For å slå av flagget, gå til admin/vedlikehold.");
define("LOGIN_MENU_L11", "Adminområde");
define("LOGIN_MENU_L12", "Innstillinger");
define("LOGIN_MENU_L13", "Profil");
define("LOGIN_MENU_L14", "nyhetsobjekt");
define("LOGIN_MENU_L15", "nyhetsobjekter");
define("LOGIN_MENU_L16", "chatruteinnlegg");
define("LOGIN_MENU_L17", "chatruteinnlegg");
define("LOGIN_MENU_L18", "kommentar");
define("LOGIN_MENU_L19", "kommentarer");
define("LOGIN_MENU_L20", "foruminnlegg");
define("LOGIN_MENU_L21", "foruminnlegg");
define("LOGIN_MENU_L22", "nytt medlem");
define("LOGIN_MENU_L23", "nye medlemmer");
define("LOGIN_MENU_L24", "Klikk her for å se en liste over nye objekter");
define("LOGIN_MENU_L25", "Siden ditt forrige besøk har det vært");
define("LOGIN_MENU_L26", "ingen");
define("LOGIN_MENU_L27", "og");
define("LOGIN_MENU_L28", "Logg inn");
define("LOGIN_MENU_L29", "ny artikkel");
define("LOGIN_MENU_L30", "nye artikler");
define("LOGIN_MENU_L31", "Vis nye nyheter");
define("LOGIN_MENU_L32", "Vis nye artikler");
define("LOGIN_MENU_L33", "Vis nye chatruteinnlegg");
define("LOGIN_MENU_L34", "Vis nye kommentarer");
define("LOGIN_MENU_L35", "Vis nye foruminnlegg");
define("LOGIN_MENU_L36", "Vis nye medlemmer");
define("LOGIN_MENU_L39", "Forlat admin");
define("LOGIN_MENU_L40", "Resend aktiveringsepost");
define("LOGIN_MENU_L41", "Loginmeyinstillinger");


?>