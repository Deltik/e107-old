<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/sitebutton_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 11:37:29 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("SITEBUTTON_MENU_L1", "Link til oss");


?>