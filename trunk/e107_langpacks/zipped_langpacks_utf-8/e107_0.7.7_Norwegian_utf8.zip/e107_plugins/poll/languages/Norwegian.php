<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/poll/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 12:11:15 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("POLL_ADLAN01", "Avstemninger");
define("POLL_ADLAN02", "Avstemningspluginen lar deg opprette avstemningar enten i en meny eller i foruminnlegg.");
define("POLL_ADLAN03", "Konfigurer avstemninger");
define("POLL_ADLAN04", "Plugin for avstemninger er nå installert. For åt legge til avstemninger, klikk på stemmegivningsikonet i pluginseksjonen på admins førsteside, og husk å aktivere menyobjektet fra menysiden din.");
define("POLLAN_MENU_CAPTION", "Avstemning");
define("POLLAN_1", "Åpne avstemninger");
define("POLLAN_2", "Opprett/endre avstemninger");
define("POLLAN_3", "Avstemningsspørsmål");
define("POLLAN_4", "Alternativ");
define("POLLAN_5", "Endre");
define("POLLAN_6", "Slett");
define("POLLAN_7", "Foreløpig ingen avstemninger.");
define("POLLAN_8", "Legg til alternativ");
define("POLLAN_9", "Tillat flere alternativ?");
define("POLLAN_10", "Ja");
define("POLLAN_11", "Nei");
define("POLLAN_12", "Vis resultat");
define("POLLAN_13", "etter stemmegivning");
define("POLLAN_14", "ved å klikke på vis-resultat-linken - kommentarer må være aktivert for å benytte dette alternativet");
define("POLLAN_15", "Tillat stemmegivning i denne avstemningen");
define("POLLAN_16", "Stemmegivningsmetode");
define("POLLAN_17", "cookie");
define("POLLAN_18", "IP-adresse");
define("POLLAN_19", "BrukerID(kun medlemmer kan stemme)");
define("POLLAN_20", "Tillat kommentarer til denne avstemningen?");
define("POLLAN_21", "Forhåndsvis igjen");
define("POLLAN_22", "Oppdater avstemning");
define("POLLAN_23", "Opprett avstemning");
define("POLLAN_24", "Forhåndsvisning");
define("POLLAN_25", "Tøm skjema");
define("POLLAN_26", "stemmer");
define("POLLAN_27", "kommentarer");
define("POLLAN_28", "Tidligere avstemninger");
define("POLLAN_29", "postet av");
define("POLLAN_30", "Send");
define("POLLAN_31", "stemmer");
define("POLLAN_32", "Klikk her for å se resultatet");
define("POLLAN_33", "Ingen tidligere avstemninger.");
define("POLLAN_34", "Tittel");
define("POLLAN_35", "Postet av");
define("POLLAN_36", "Aktiv");
define("POLLAN_37", "aktivere fra");
define("POLLAN_38", "til");
define("POLLAN_39", "Takk for din stemme!");
define("POLLAN_40", "Klikk her for å se resultatene");
define("POLLAN_41", "Denne avstemningen er kun for medlemmer");
define("POLLAN_42", "Denne avstemningen er kun for administratorer");
define("POLLAN_43", "Du har ikke tillatelse til å stemme i denne avstemningen");
define("POLLAN_44", "Slett denne avstemningen?");
define("POLLAN_45", "Avstemningen er oppdatert");
define("POLLAN_46", "Felt(er) er blanke");


?>