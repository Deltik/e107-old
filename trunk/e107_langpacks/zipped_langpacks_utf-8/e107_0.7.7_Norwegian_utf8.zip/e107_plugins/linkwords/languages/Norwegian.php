<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 00:23:31 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "Felt latt stå tomt.");
define("LWLAN_2", "Linkord lagret.");
define("LWLAN_3", "Linkord oppdatert.");
define("LWLAN_4", "Ingen linkord definert enda.");
define("LWLAN_5", "Ord");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Alternativ");
define("LWLAN_9", "ja");
define("LWLAN_10", "nei");
define("LWLAN_11", "Eksisterende linkord");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nei");
define("LWLAN_14", "Send inn linkord");
define("LWLAN_15", "Oppdater linkord");
define("LWLAN_16", "Endre");
define("LWLAN_17", "Slett");
define("LWLAN_18", "Er du sikker på at du vil slette dette linkordet?");
define("LWLAN_19", "Linkord slettet.");
define("LWLAN_20", "Kan ikke finne denne linkordsposten.");
define("LWLAN_21", "Ord å autolinke");
define("LWLAN_22", "Aktiver?");
define("LWLANINS_1", "Linkord");
define("LWLANINS_2", "Denne plugin'en kommer til å linke spesifiserte ord til en definert link");
define("LWLANINS_3", "Konfigurer linkord");
define("LWLANINS_4", "For å konfigurere, klikk på linken i pluginseksjonen på adminførstesiden");


?>