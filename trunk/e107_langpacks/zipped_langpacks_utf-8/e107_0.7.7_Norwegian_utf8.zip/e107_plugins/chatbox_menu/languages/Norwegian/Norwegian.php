<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Norwegian/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/11 04:09:28 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CHATBOX_L1", "Kan ikke akseptere innlegget siden brukernavnet er registret - om det er ditt navn, logg inn for å poste innlegg.");
define("CHATBOX_L2", "Chatrute");
define("CHATBOX_L3", "Du må være innlogget for å poste kommentarer på dette nettstedet - logg inn, eller om du ikke er registrert klikk <a href='".e_BASE."signup.php'>her</a> for å registrere deg");
define("CHATBOX_L4", "Send");
define("CHATBOX_L5", "Tilbakestill");
define("CHATBOX_L6", "[blokert av admin]");
define("CHATBOX_L7", "Fjern blokkering");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Blokker");
define("CHATBOX_L10", "Slett");
define("CHATBOX_L11", "Inen meldinger enda.");
define("CHATBOX_L12", "Vis alle poster");
define("CHATBOX_L13", "moderer chatrute");
define("CHATBOX_L14", "Smil");
define("CHATBOX_L15", "Innlegget er for langt, eller tomt innlegg sendt");
define("CHATBOX_L16", "Anonym");
define("CHATBOX_L17", "Dublettinnlegg");
define("CHATBOX_L18", "Chatrutens meldinger moderert");
define("CHATBOX_L19", "Du kan bare skrive et innlegg pr ".FLOODTIMEOUT." sekunder");
define("CHATBOX_L20", "Chatrute (alle innlegg)");
define("CHATBOX_L21", "Chatinnlegg");
define("CHATBOX_L22", "den");
define("CHATBOX_L23", "Feil!");
define("CHATBOX_L24", "Du har ikke rettigheter til å se denne siden.");
define("CHATBOX_L25", "[ dette innlegget er blokkert av admin ]");
define("NT_LAN_CB_1", "Chatrutebegivenheter");
define("NT_LAN_CB_2", "Meldingen postet");
define("NT_LAN_CB_3", "Postet av");
define("NT_LAN_CB_4", "IP-adresse");
define("NT_LAN_CB_5", "Melding");
define("NT_LAN_CB_6", "Chatruteinnlegg postet");


?>