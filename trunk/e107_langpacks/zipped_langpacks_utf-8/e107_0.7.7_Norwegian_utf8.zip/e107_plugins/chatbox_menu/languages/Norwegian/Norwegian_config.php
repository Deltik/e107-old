<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Norwegian/Norwegian_config.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/11 04:00:29 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Chatruteinnstillinger oppdatert.");
define("CHBLAN_2", "Moderert.");
define("CHBLAN_3", "Ingen chatruteinnlegg enda.");
define("CHBLAN_4", "Medlem");
define("CHBLAN_5", "Gjest");
define("CHBLAN_6", "fjern blokkering");
define("CHBLAN_7", "blokker");
define("CHBLAN_8", "slett");
define("CHBLAN_9", "Moderer chatrute");
define("CHBLAN_10", "Moderer innlegg");
define("CHBLAN_11", "Chatruteinnlegg å vise");
define("CHBLAN_12", "mengde innlegg vist i chatruten");
define("CHBLAN_13", "Bytt ut linkar");
define("CHBLAN_14", "om markert kommer linkar til å byttes ut mot teksten i ruten nedenfor");
define("CHBLAN_15", "Utbyttetekst hvis aktivert");
define("CHBLAN_16", "kommer linker til å byttes ut mot denn teksten");
define("CHBLAN_17", "Tekstbrytningslengde");
define("CHBLAN_18", "ord lengre enn det antall teg du angir her kommer til å brytes");
define("CHBLAN_19", "Oppdater chatruteinsstillinger");
define("CHBLAN_20", "Chatruteinsstillinger");
define("CHBLAN_21", "Rydd opp");
define("CHBLAN_22", "Slett innlegg eldre enn en viss tid");
define("CHBLAN_23", "Slett innlegg eldre enn ");
define("CHBLAN_24", "En dag");
define("CHBLAN_25", "En uke");
define("CHBLAN_26", "En måned");
define("CHBLAN_27", "- Slett alle innlegg-");
define("CHBLAN_28", "Chatruten ryddet.");
define("CHBLAN_29", "Vis chatruten inne i et rullerende lag");
define("CHBLAN_30", "Lagets høyde");
define("CHBLAN_31", "Vis smil");
define("CHBLAN_32", "Moderatorbrukerklasse");
define("CHBLAN_33", "Brukere omregnet");
define("CHBLAN_34", "Regn om brukerpostinger");
define("CHBLAN_35", "Regn om");
define("CHBLAN_36", "Visningsalternativ for chatrute");
define("CHBLAN_37", "Normal chatrute");
define("CHBLAN_38", "Bruk javascriptkode for å oppdatere innholdet dynamisk(AJAX)");


?>