<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Norwegian/lan_chatbox_search.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/11 03:19:21 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CB_SCH_LAN_1", "Chatrute");


?>