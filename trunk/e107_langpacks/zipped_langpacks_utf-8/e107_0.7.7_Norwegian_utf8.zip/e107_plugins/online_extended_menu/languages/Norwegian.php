<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_extended_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 19:36:26 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Gjester: ");
define("ONLINE_EL2", "Medlemmer: ");
define("ONLINE_EL3", "På denne siden: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Medlemmer");
define("ONLINE_EL6", "Nyaste medlem");
define("ONLINE_EL7", "leser");
define("ONLINE_EL8", "flest online noen gang: ");
define("ONLINE_EL9", "den");
define("TRACKING_MESSAGE", "Online brukersporing er for øyeblikket deaktivert, aktiver den <a href='".e_ADMIN."users.php?options'>her</a></span><br />");


?>