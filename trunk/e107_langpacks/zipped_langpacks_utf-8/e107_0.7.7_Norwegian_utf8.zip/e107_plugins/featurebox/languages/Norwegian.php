<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/featurebox/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 17:32:20 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("FBLAN_01", "Sistenyttrute");
define("FBLAN_02", "Denne plugin'en lar deg vise en rute med siste nytt eller hva du vil annet i. Disse meldingene kan enten byttes ut på slump eller være dynamisk tonet.");
define("FBLAN_03", "Konfigurer sistenyttruten");
define("FBLAN_04", "Sistenyttrutens plugin er installert. For å legge til meldinger og konfigurere, gå tilbake till adminhovedsiden og klikk på ikonet for sistenyttruten i pluginseksjonen.");
define("FBLAN_05", "Ingen meldinger definert for ruten enda");
define("FBLAN_06", "Eksisterende meldinger i sistenyttruten");
define("FBLAN_07", "Tittel/Overskrift");
define("FBLAN_08", "Beskjedtekst");
define("FBLAN_09", "Meldingens synlighet");
define("FBLAN_10", "Opprett melding");
define("FBLAN_11", "Oppdater melding");
define("FBLAN_12", "Type");
define("FBLAN_13", "Tilfeldig visning");
define("FBLAN_14", "Vis kun denne meldingen");
define("FBLAN_15", "Meldingen lagt til i databasen.");
define("FBLAN_16", "Meldingen oppdatert i databasen.");
define("FBLAN_17", "Felt latt stå tomt");
define("FBLAN_18", "Meldingen slettet");
define("FBLAN_19", "Alternativ");
define("FBLAN_20", "Endre");
define("FBLAN_21", "Slette");
define("FBLAN_22", "Visningstype");
define("FBLAN_23", "I temarute");
define("FBLAN_24", "Enkel");
define("FBLAN_25", "Mal");
define("FBLAN_26", "Du kan bruke en egen mal for hver melding, legg til maler i e107_plugins/featurebox/templates/ katalogen");


?>