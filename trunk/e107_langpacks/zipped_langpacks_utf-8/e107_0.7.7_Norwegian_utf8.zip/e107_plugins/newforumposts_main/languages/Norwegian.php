<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newforumposts_main/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 22:36:57 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Tråd");
define("NFPM_LAN_2", "Forfatter");
define("NFPM_LAN_3", "Visninger");
define("NFPM_LAN_4", "Svar");
define("NFPM_LAN_5", "Nyeste innlegg");
define("NFPM_LAN_6", "Tråder");
define("NFPM_LAN_7", "av");
define("NFPM_L1", "Denne plugin viser en liste over nye foruminnlegg på førstesiden");
define("NFPM_L2", "Nyeste foruminnlegg");
define("NFPM_L3", "For å konfigurere, klikk på linken i pluginsseksjonen på adminførstesiden");
define("NFPM_L4", "Aktiver i hvilket område?");
define("NFPM_L5", "Inaktiv");
define("NFPM_L6", "Sidens begynnelse");
define("NFPM_L7", "Sidens slutt");
define("NFPM_L8", "Tittel");
define("NFPM_L9", "Antall nye innlegg å vise?");
define("NFPM_L10", "Vise i et rullende lag?");
define("NFPM_L11", "Lagets høyde");
define("NFPM_L12", "Konfigurasjon for nye foruminnlegg");
define("NFPM_L13", "Oppdater innstillinger for nye foruminnlegg");
define("NFPM_L14", "Innstillingene oppdatert.");
define("NFPM_L15", "Marker for å vise nyeste foruminnlegg.<br />Standard er nyeste emner.");
define("NFPM_L16", "[bruker slettet]");


?>