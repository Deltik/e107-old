<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Norwegian/lan_forum_frontpage.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 14:58:11 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("FOR_FP_1", "Forum");


?>