<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Norwegian/lan_forum_conf.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 14:58:58 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "Avstemning slettet.");
define("FORLAN_6", "Tråd slettet");
define("FORLAN_7", "svar slettet");
define("FORLAN_8", "Sletting avbrutt.");
define("FORLAN_9", "Tråd flyttet.");
define("FORLAN_10", "Flytting avbrutt.");
define("FORLAN_11", "Tilbake til forum");
define("FORLAN_12", "Forumkonfigurasjon");
define("FORLAN_13", "Er du helt sikker på at du vil slette denne avstemningen?<br />Når den er slettet kan den <b><u>ikke</u></b> gjenfinnes.");
define("FORLAN_14", "Avbryt");
define("FORLAN_15", "Bekreft sletting av innlegg");
define("FORLAN_16", "Bekreft sletting av avstemning");
define("FORLAN_17", "lagt inn av");
define("FORLAN_18", "Er du helt sikker på at du vil slette dette forumet");
define("FORLAN_19", "tråd og relaterte innlegg?");
define("FORLAN_20", "avstemningen kommer også til å bli slettet");
define("FORLAN_21", "Når de er slettet kan ");
define("FORLAN_22", "innlegg?<br />Når den er slettet kan ");
define("FORLAN_23", "ikke</u></b> gjenfinnes");
define("FORLAN_24", "Flytt tråd til forum");
define("FORLAN_25", "Flytt tråd");
define("FORLAN_26", "Svar slettet");
define("FORLAN_27", "flyttet");
define("FORLAN_28", "Ikke forandre navn på trådtittelen");
define("FORLAN_29", "Legg til");
define("FORLAN_30", "til tittel");
define("FORLAN_31", "Forandre navn til:");
define("FORLAN_32", "Forandre navn på trådalternativer:");


?>