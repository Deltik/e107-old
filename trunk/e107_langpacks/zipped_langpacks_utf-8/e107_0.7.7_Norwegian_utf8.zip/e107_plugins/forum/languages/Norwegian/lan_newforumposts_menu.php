<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Norwegian/lan_newforumposts_menu.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 02:31:19 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Alle nyeste innlegg er utenfor din brukerklasse, kan ikke vise dem.");
define("NFP_2", "Ingen innlegg enda");
define("NFP_3", "Menykonfigurasjon for nye foruminnleg lagret");
define("NFP_4", "Overskrift");
define("NFP_5", "Antall innlegg å vise?");
define("NFP_6", "Antall tegn å vise?");
define("NFP_7", "Postfiks for for lange innlegg?");
define("NFP_8", "Vise opprinnelige emner i meny?");
define("NFP_9", "Oppdater menyinnstillinger");
define("NFP_10", "Menykonfigurasjon for nye foruminnlegg");
define("NFP_11", "Postet av");


?>