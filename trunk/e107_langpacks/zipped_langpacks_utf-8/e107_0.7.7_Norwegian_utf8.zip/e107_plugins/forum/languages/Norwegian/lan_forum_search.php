<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Norwegian/lan_forum_search.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 13:57:31 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Velg forum");
define("FOR_SCH_LAN_3", "Alle forum");
define("FOR_SCH_LAN_4", "Hele innlegget");
define("FOR_SCH_LAN_5", "Som del av en tråd");


?>