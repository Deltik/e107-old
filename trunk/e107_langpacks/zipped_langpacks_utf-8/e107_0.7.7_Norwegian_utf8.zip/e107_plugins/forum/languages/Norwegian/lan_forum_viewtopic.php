<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Norwegian/lan_forum_viewtopic.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 13:06:49 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum");
define("LAN_01", "Forum");
define("LAN_02", "Gå til siden");
define("LAN_03", "Kjør");
define("LAN_04", "Forrige");
define("LAN_05", "Neste");
define("LAN_06", "Registrert");
define("LAN_07", "Sted");
define("LAN_08", "Nettsted");
define("LAN_09", "Besøk siden registrering");
define("LAN_10", "Tilbake til toppen");
define("LAN_65", "Hopp");
define("LAN_66", "Denne tråden er nå stengt");
define("LAN_67", "innlegg");
define("LAN_194", "Gjest");
define("LAN_195", "Registrert medlem");
define("LAN_321", "Moderatorer: ");
define("LAN_389", "Forrige tråd");
define("LAN_390", "Neste tråd");
define("LAN_391", "overvåk denne tråden");
define("LAN_392", "avslutt overvåking av denne tråden");
define("LAN_393", "Hurtigsvar");
define("LAN_394", "Forhåndsvis");
define("LAN_395", "Svar til tråd");
define("LAN_396", "Nettsted");
define("LAN_397", "Epost");
define("LAN_398", "Profil");
define("LAN_399", "Privat melding");
define("LAN_400", "Endre");
define("LAN_401", "Siter");
define("LAN_402", "Forfatter");
define("LAN_403", "Post");
define("LAN_404", "Ingen tidligere tråder");
define("LAN_405", "Ingen flere tråder");
define("LAN_406", "Moderator: Endre");
define("LAN_435", "Moderator: Slett");
define("LAN_408", "Moderator: Flytt");
define("LAN_409", "Er du sikker på at du vil slette denne tråden med alle svar?");
define("LAN_410", "Er du sikker på at du vil slette dette svaret?");
define("LAN_411", "postet av ");
define("LAN_412", "Overskrift");
define("LAN_413", "Rapporter");
define("LAN_414", "Rapporter denne tråden til en moderator");
define("LAN_415", "Trådoverskrift");
define("LAN_416", "Skriv din rapport");
define("LAN_417", "Admin vil bli gjort oppmerksom på denne tråden. Du kan skrive en melding der du forklarer hva du synes er tvilsomt.");
define("LAN_418", "Bruk <b>ikke</b> dette skjemaet til å kontakte admin av andre grunner.");
define("LAN_419", "Send rapport");
define("LAN_420", "Klikk for å se innlegg");
define("LAN_421", "Rapport om forumtråd fra");
define("LAN_422", "Dette innlegget er innrapportert fra nettstedet");
define("LAN_423", "Meldingen kunne ikke sendes. ");
define("LAN_424", "Innlegger er blitt rapportert til en moderator.<br />Takk.");
define("LAN_425", "Melding fra: ");
define("LAN_426", "Rappoerterer innlegg i emnet: ");
define("LAN_427", "Feil ved sending av epost");
define("LAN_428", "Innlegget er innrapportert");
define("LAN_429", "Klikk her for å gå tilbake til forumet");
define("LAN_430", "avstemning");
define("FORLAN_26", "Svar slettet");
define("FORLAN_10", "Start ny tråd");
define("LAN_29", "Endret");
define("LAN_431", "Distribuer denne tråden: rss 0.92");
define("LAN_432", "Distribuer denne tråden: rss 2.0");
define("LAN_433", "Distribuer denne tråden: RDF");
define("FORLAN_101", "Epost tråd");
define("FORLAN_102", "Skriv ut");
define("FORLAN_103", "[bruker slettet]");
define("FORLAN_104", "Tråd ikke funnet");
define("FORLAN_HIDDEN", "SJULT - LOGG INN OG SVAR PÅ FOR Å AVSLØRE");


?>