<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Norwegian/lan_forum_uploads.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 13:45:10 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forumopplastninger");
define("FRMUP_1", "Opplastede filer i forum");
define("FRMUP_2", "Fil slettet");
define("FRMUP_3", "Feil: Kan ikke slette filen");
define("FRMUP_4", "Filsletting");
define("FRMUP_5", "Filnavn");
define("FRMUP_6", "Resultat");
define("FRMUP_7", "Funnet i tråd");
define("FRMUP_8", "IKKE FUNNET");
define("FRMUP_9", "Ingen opplastede filer funnet");
define("FRMUP_10", "Slett");


?>