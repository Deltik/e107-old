<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Norwegian/lan_forum.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 03:55:55 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Forum");
define("LAN_30", "Velkommen");
define("LAN_31", "Det finnes ingen nye innlegg");
define("LAN_32", "Det finnes 1 nytt innlegg ");
define("LAN_33", "Det finnes");
define("LAN_34", "nye innlegg");
define("LAN_35", "siden ditt forrige besøk.");
define("LAN_36", "Du var her sist ");
define("LAN_37", "Det er nå ");
define("LAN_38", ", alle tider er ");
define("LAN_41", "Nyeste medlem: ");
define("LAN_42", "Registrerte medlemmer: ");
define("LAN_44", "Dette forumet kan brukes av ikke-registrerte brukere, men vær klar over at IPadressen din blir logget om du skriver et innlegg.<br />For å kunne benytte alle funksjoner i dette forumet må du");
define("LAN_45", "I dette forumet kan kun registrerte og innloggede brukere skrive, vennligst klikk");
define("LAN_46", "Forum");
define("LAN_47", "Tråder");
define("LAN_48", "Svar");
define("LAN_49", "Nyeste innlegg");
define("LAN_51", "Ingen forum enda, kom tilbake senere.");
define("LAN_52", "Ingen forum i denne seksjonen enda, kom tilbake senere.");
define("LAN_79", "Nye innlegg");
define("LAN_80", " Ingen nye innlegg");
define("LAN_81", "Stengt tråd");
define("LAN_100", "artikler");
define("LAN_180", "Søk");
define("LAN_191", "Informasjon");
define("LAN_192", "Brukerne har skrevet totalt ");
define("LAN_196", "Du har lest ");
define("LAN_197", " av disse innleggene.");
define("LAN_198", " Alle ny innlegg er lest.");
define("LAN_199", "Marker alle innlegg som leste");
define("LAN_204", "Du <b>kan</b> start nye tråder");
define("LAN_205", "Du <b>kan ikke</b> starte nye tråder");
define("LAN_206", "Du <b>kan</b> sende svar");
define("LAN_207", "Du <b>kan ikke</b> sende svar");
define("LAN_208", "Du <b>kan</b> endre innleggene dine");
define("LAN_209", "Du <b>kan ikke</b> endre innleggene dine");
define("LAN_392", "slutt å overvåke denne tråden");
define("LAN_393", "List overvåkede tråder");
define("LAN_394", "Stengt forum");
define("LAN_397", "Overvåkede tråder");
define("LAN_398", "Stengt");
define("LAN_399", "Begrenset");
define("LAN_400", "Dette forumet kan kun sees av registrerte medlemmer");
define("LAN_401", "Kun medlemmer");
define("LAN_402", "Dette forumet er skrivebeskyttet");
define("LAN_403", "Ingen innlegg enda");
define("LAN_404", "innlegg");
define("LAN_405", "Skrivebeskyttet");
define("LAN_406", "Dette forumet er begrenset til kun administratorer");
define("LAN_407", "Dette forumet er begrenset til kun medlemmer");
define("LAN_408", "Dette er et skrivebeskyttet forum");
define("LAN_409", "Dette forumet er begrenset til brukerklasse");
define("LAN_410", "Velkommen Gjest");
define("LAN_411", "tråd");
define("LAN_412", "svar");
define("LAN_413", "tråder");
define("LAN_414", "svar");
define("LAN_415", "bruker leser i forumet akkurat nå");
define("LAN_416", "brukere leser i forumet akkurat nå");
define("LAN_417", "medlem");
define("LAN_418", "gjest");
define("LAN_419", "medlemmer");
define("LAN_420", "gjester");
define("LAN_421", "Vis nye innlegg");
define("LAN_422", "Nye innlegg siden ditt forrige besøk");
define("LAN_423", "Postet av");
define("LAN_424", "Nye tråder");
define("LAN_425", "Ang:");
define("LAN_426", "Hvem er online: ");
define("LAN_427", "Vis detaljert liste.");
define("LAN_428", "Ang:");
define("LAN_429", "Flest innlegg");
define("LAN_430", "Mest aktive tråder");
define("LAN_431", "Mine innlegg");
define("LAN_432", "Mine innstillinger");
define("LAN_433", "Forumregler");
define("LAN_434", "Tilbake til forum");
define("LAN_435", "Min profil");
define("LAN_436", " (Åpner et nytt vindu.)");
define("LAN_437", "registrer");
define("LAN_438", "og logg inn.");
define("LAN_439", "her");
define("LAN_440", "for å gå til registreringssiden.");
define("LAN_441", "Vis forumstatistikk");
define("FORLAN_441", "Ingen regler oppgitt.");
define("FORLAN_442", "Mine opplastninger");
define("FORLAN_443", "[bruker slettet]");
define("FORLAN_444", "underforum");


?>