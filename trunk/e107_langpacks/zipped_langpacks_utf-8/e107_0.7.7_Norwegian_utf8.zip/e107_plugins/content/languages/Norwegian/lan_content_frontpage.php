<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Norwegian/lan_content_frontpage.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 15:45:55 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CONT_FP_1", "Innholdskategori");
define("CONT_FP_2", "Hovedside");


?>