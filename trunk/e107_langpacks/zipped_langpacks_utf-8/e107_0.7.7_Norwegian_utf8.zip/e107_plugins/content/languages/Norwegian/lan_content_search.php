<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Norwegian/lan_content_search.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/10 06:23:04 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Innhold");
define("CONT_SCH_LAN_2", "Alle innholdskategorier");
define("CONT_SCH_LAN_3", "Postet som svar til");
define("CONT_SCH_LAN_4", "i");


?>