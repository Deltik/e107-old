<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/integrity_check/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 02:18:19 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("Integ_01", "Lagret");
define("Integ_02", "Lagring mislyktes");
define("Integ_03", "Manglende filer:");
define("Integ_04", "CRC-feil:");
define("Integ_05", "Kan ikke åpne fil...");
define("Integ_06", "Kontroller fil-integritet");
define("Integ_07", "Ingen filer tilgjengelige");
define("Integ_08", "Kontroller integritet");
define("Integ_09", "Opprett sfv-fil");
define("Integ_10", "Den valgte katalogen kommer <u>ikke</u> til å lagres i crc-filen.");
define("Integ_11", "Filnavn:");
define("Integ_12", "Opprett sfv-fil");
define("Integ_13", "Kontrollerer integritet");
define("Integ_14", "Kan ikke opprette SFV ettersom katalogen ".e_PLUGIN."integrity_check/<b>{output}</b> er skrivebeskyttet. Sett chmod på denne katalogen til 777!");
define("Integ_15", "Alle filer er kontrollert og funnet i orden!");
define("Integ_16", "Ingen kjerne-crc-fil tilgjenglig");
define("Integ_17", "Ingen plugin-crc-filer tilgjengelige");
define("Integ_18", "Opprett plugin-CRC-fil");
define("Integ_19", "Kjerne-checksum-filer");
define("Integ_20", "Plugin-checksum-filer");
define("Integ_21", "Velg den plugin'en du vil opprette en crc-fil for.");
define("Integ_22", "Bruk gzip");
define("Integ_23", "Kontroller bare installerte tema");
define("Integ_24", "Adminførsteside");
define("Integ_25", "Forlat adminområdet");
define("Integ_26", "Last nettsted med normal header");
define("Integ_27", "BRUK FILINSPEKTØREN FOR Å SJEKKE KJERNEFILER");
define("Integ_30", "For lavere cpu-belastning kan du utføre kontrollene i 1 - 10 trinn.");
define("Integ_31", "Trinn: ");
define("Integ_32", "Det finnes en fil med navnet <b>log_crc.txt</b> i crc-folderen. Slett den! (Eller prøv å oppdatere)");
define("Integ_33", "Det finnes en fil med navnet <b>log_miss.txt</b> i crc-folderen. Slett den! (Eller prøv å oppdatere)");
define("Integ_34", "Crc-folderen er skrivebeskyttet!");
define("Integ_35", "På grunn av følgende årsak(er) kan du bare velge <b>ett</b> trinn:");
define("Integ_36", "Klikk her om du ikke vil vente 5 sekunder til neste trinn:");
define("Integ_37", "Klikk her");
define("Integ_38", "Nå er det <u><i>{counts}</i></u> rader igjen å gjøre...");
define("Integ_39", "Vennligst slett filen:<br />".e_PLUGIN."integrity_check/<u><i>do_core_file.php</i></u>!<br />Den er gammel og aldri ment for offentlig distribusjon...");


?>