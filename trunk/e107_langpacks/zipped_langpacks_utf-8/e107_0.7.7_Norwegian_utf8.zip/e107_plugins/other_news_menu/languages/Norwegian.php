<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/other_news_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 19:29:35 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("TD_MENU_L1", "Andre nyheter");


?>