<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/banner_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 05:08:15 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("BANNER_MENU_L1", "Annonse");
define("BANNER_MENU_L2", "Bannermenykonfigurasjon lagret");
define("BANNER_MENU_L3", "Overskrift");
define("BANNER_MENU_L4", "Kampanje");
define("BANNER_MENU_L5", "Bannermenykonfigurasjon");
define("BANNER_MENU_L6", "velg kampanje å vise i meny");
define("BANNER_MENU_L7", "tilgjengelige kampanjer");
define("BANNER_MENU_L8", "valgte kampanjer");
define("BANNER_MENU_L9", "ta bort valgt(e)");
define("BANNER_MENU_L10", "hvordan skal valgte kampanjer vises?");
define("BANNER_MENU_L11", "velg visningstype...");
define("BANNER_MENU_L12", "en kampanje i en meny");
define("BANNER_MENU_L13", "alle valgte kampanjer i en meny");
define("BANNER_MENU_L14", "alle valgte kampanjer i separate menyer");
define("BANNER_MENU_L15", "hvor mange banner skal vises?");
define("BANNER_MENU_L16", "denne innstillingen brukes bare med valgene 2 og 3.<br />om det finnes færre banner enn denne maksverdien kommer alle tilgjengelige banner til å brukes.");
define("BANNER_MENU_L17", "sett antall...");
define("BANNER_MENU_L18", "Oppdater menyinnstillingene");


?>