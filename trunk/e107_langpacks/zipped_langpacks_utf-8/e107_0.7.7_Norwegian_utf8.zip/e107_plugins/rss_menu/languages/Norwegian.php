<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/rss_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 11:50:58 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("RSS_LAN05", "Antall saker (0=avslått)");
define("RSS_MENU_L1", "kan bli syndikert av å bruke disse rrsfeedene");
define("RSS_MENU_L2", "RSS Feeds");
define("RSS_MENU_L3", "Våre nyheter");
define("RSS_MENU_L4", "Våre kommentarer");
define("RSS_MENU_L5", "våre forumtråder");
define("RSS_MENU_L6", "Våre forumposter");
define("RSS_MENU_L7", "Våre chatbox poster");
define("RSS_MENU_L8", "Våre bugtracker raporter");
define("RSS_MENU_L9", "Våre nedlastninger");
define("RSS_NEWS", "Nyheter");
define("RSS_COM", "Kommentarer");
define("RSS_ART", "Artikler");
define("RSS_REV", "Anmeldelser");
define("RSS_FT", "Forumtråder");
define("RSS_FP", "Foruminnlegg");
define("RSS_FSP", "Forumspesifikt innlegg");
define("RSS_BUG", "Feilsporing");
define("RSS_FOR", "Forum");
define("RSS_DL", "Nedlastning");
define("RSS_PLUGIN_LAN_1", "RSS");
define("RSS_PLUGIN_LAN_6", "Feed linker");
define("RSS_PLUGIN_LAN_7", "RRSfeeden for nyheter");
define("RSS_PLUGIN_LAN_8", "RRSfeeden fornedlastningene");
define("RSS_PLUGIN_LAN_9", "RRSfeeden for kommentarene");
define("RSS_PLUGIN_LAN_10", "RSfeeden for nyhetskategori:");
define("RSS_PLUGIN_LAN_11", "RRSfeeden for nedlastningskategori:");
define("RSS_PLUGIN_LAN_14", "Kommentarer");
define("RSS_LAN_ADMINMENU_1", "RRSalternativer");
define("RSS_LAN_ADMINMENU_2", "Listing");
define("RSS_LAN_ADMINMENU_4", "Importer");
define("RSS_LAN_ERROR_1", "Dette er ikke en gyldig rrsfeed<br /><a href='".e_SELF."'><< returner til rrsfeedlisten</a>");
define("RSS_LAN_ERROR_2", "Din e107config.php eller språkfiler inneholder mellomrom eller Ã¯Â»Â¿ï»¿ tegn før &lt;? tegnene. Du bør fjerne disse med en ikke-utf8 tekst-editor om du ønsker å ha en gyldig RRSfeed.");
define("RSS_LAN_ERROR_3", "Ingen rrsfeed er tilstede enda<br />venligst bruk importfunksjonen for å importere tilgjengelige rrsfeeds eller lag en rrsfeed manuelt");
define("RSS_LAN_ERROR_4", "Ingen rrsfeeds er tilgjengelige enda");
define("RSS_LAN_ERROR_5", "Dette rrsinnlegget eksisterer ikke");
define("RSS_LAN_ERROR_6", "Det er ingen rrsfeeds å importere");
define("RSS_LAN_ERROR_7", "Noen nødvendige felt mangler.");
define("RSS_LAN_ADMIN_1", "Eksisterende RRSfeeds");
define("RSS_LAN_ADMIN_2", "Id");
define("RSS_LAN_ADMIN_3", "Sti");
define("RSS_LAN_ADMIN_4", "Navn");
define("RSS_LAN_ADMIN_5", "Url");
define("RSS_LAN_ADMIN_6", "Tekst");
define("RSS_LAN_ADMIN_7", "Grense");
define("RSS_LAN_ADMIN_8", "Synlighet");
define("RSS_LAN_ADMIN_9", "Type");
define("RSS_LAN_ADMIN_10", "rrsfeed lag innlegg");
define("RSS_LAN_ADMIN_11", "rrsfeed importer feeds");
define("RSS_LAN_ADMIN_12", "Emne Id");
define("RSS_LAN_ADMIN_13", "Inkluder andre-nyheter emne i Nyhetsfeeden?");
define("RSS_LAN_ADMIN_14", "Slå på");
define("RSS_LAN_ADMIN_15", "Marker linker for å importere ...");
define("RSS_LAN_ADMIN_16", "importere?");
define("RSS_LAN_ADMIN_17", "importerer merkerte likner");
define("RSS_LAN_ADMIN_18", "rrsfeed(s) er importert.");
define("RSS_LAN_ADMIN_21", "aktiv og synlig i rrsfeedliste");
define("RSS_LAN_ADMIN_22", "aktiv og ikke synlig i rrsfeedliste");
define("RSS_LAN_ADMIN_23", "uaktiv");
define("RSS_LAN_ADMIN_26", "Velg alle");
define("RSS_LAN_ADMIN_27", "Avvelg alle");
define("RSS_LAN_ADMIN_31", "grense for rrsinnlegg er oppdatert");
define("RSS_LAN_0", "RSS");
define("RSS_LAN_2", "@nospam.com");
define("RSS_LAN_3", "ingenforfatter@nospam.com");


?>