<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/log/languages/admin/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/07 00:12:28 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("ADSTAT_ON", "Til");
define("ADSTAT_OFF", "Fra");
define("ADSTAT_L1", "Denne plugin'en kommer til å logge alle besøk på nettstedet og bygge detaljerte statistikkbilder basert på den innsamlede informasjonen.");
define("ADSTAT_L2", "Statistikkloggingen er innstallert. For åt aktivere, gå til konfigurasjonsbildet og klikk på Aktiver.<br /><b>Du må sette filrettighetene på katalogen e107_plugins/log/logs til 777 (chmod 777)</b>");
define("ADSTAT_L3", "Statistikklogging");
define("ADSTAT_L4", "Aktiver statistikklogging");
define("ADSTAT_L5", "Statistikktyper");
define("ADSTAT_L6", "Weblesere");
define("ADSTAT_L7", "Operativsystem");
define("ADSTAT_L8", "Skjermoppløsninger / fargedybde");
define("ADSTAT_L9", "Besøk fra land/domener");
define("ADSTAT_L10", "Henvisninger");
define("ADSTAT_L11", "Søkestrenger");
define("ADSTAT_L12", "Nullstill statistikk");
define("ADSTAT_L13", "dette sletter statistikken - vær forsiktig!");
define("ADSTAT_L14", "Sideteller");
define("ADSTAT_L15", "Oppdater statistikkinnstillinger");
define("ADSTAT_L16", "Nettstedsstatistikkinnstillinger");
define("ADSTAT_L17", "Statistikkinnstillinger oppdatert");
define("ADSTAT_L18", "Tillat tilgang til hovedstatistikksiden for...");
define("ADSTAT_L19", "Nyeste besøkere");
define("ADSTAT_L20", "Regn adminbesøk");
define("ADSTAT_L21", "Maksimum poster å vise på statistikksiden");
define("ADSTAT_L22", "Kjør oppdateringsrutine");
define("ADSTAT_L23", "Logger fra en tidligere versjon av e107 er funnet, oppdater dem her");
define("ADSTAT_L24", "Gå til oppdateringsskriptet");
define("ADSTAT_L25", "Valgt statistikk nullstilt");
define("ADSTAT_L26", "Slett sideposter");
define("ADSTAT_L27", "om statistikken har noen feilaktige sider kan du fjerne dem her");
define("ADSTAT_L28", "Åpne siden");
define("ADSTAT_L29", "Sidenavn");
define("ADSTAT_L30", "Marker for å fjerne");
define("ADSTAT_L31", "Fjern valgte sider");
define("ADSTAT_L32", "Rydd sider");


?>