<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/search_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/03 11:40:35 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("LAN_180", "Søk");


?>