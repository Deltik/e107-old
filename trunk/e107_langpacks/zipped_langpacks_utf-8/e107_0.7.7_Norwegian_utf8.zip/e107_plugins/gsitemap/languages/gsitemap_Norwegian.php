<?php
/*
+---------------------------------------------------------------+
|        e107 website system Norwegian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/gsitemap/languages/gsitemap_Norwegian.php $
|        $Revision: 1.0 $
|        $Date: 2006/11/24 11:26:23 $
|        $Author: eelay $
+---------------------------------------------------------------+
*/

define("GSLAN_Name", "Sidekart");
define("GSLAN_1", "Sidelink");
define("GSLAN_2", "Importer?");
define("GSLAN_3", "Type");
define("GSLAN_4", "Navn");
define("GSLAN_5", "Url");
define("GSLAN_6", "Velg linker for å markere dem for import ...");
define("GSLAN_7", "Importer linker");
define("GSLAN_8", "Importer med:");
define("GSLAN_9", "Prioritet");
define("GSLAN_10", "Frekvens");
define("GSLAN_11", "alltid");
define("GSLAN_12", "en gang i timen");
define("GSLAN_13", "daglig");
define("GSLAN_14", "ukentilg");
define("GSLAN_15", "månedlig");
define("GSLAN_16", "årlig");
define("GSLAN_17", "aldrig");
define("GSLAN_18", "Importer valgte linker");
define("GSLAN_19", "Google Sidekart");
define("GSLAN_20", "Listing");
define("GSLAN_21", "Instruksjoner");
define("GSLAN_22", "Lag nytt innlegg");
define("GSLAN_23", "Importer");
define("GSLAN_24", "Google Sidekartinnlegg");
define("GSLAN_25", "Navn");
define("GSLAN_26", "URL");
define("GSLAN_27", "Lastmod");
define("GSLAN_28", "Frekvens");
define("GSLAN_29", "Google Sidekartkonfigurasjon");
define("GSLAN_30", "Visningsrekkefølge");
define("GSLAN_31", "Synlig for");
define("GSLAN_32", "Hvordan breuke Google Sidekart");
define("GSLAN_33", "GSidekart instruksjoner");
define("GSLAN_34", "Først lager du linkene du ønsker å ha listet i sidekartet ditt. Du kan importere de fleste linkene ved å trykke på 'Importer' knappen til høyre");
define("GSLAN_35", "Om du har valgt å importere linker så trykker du på 'importer' og velg linkene du vil importere");
define("GSLAN_36", "Du kan også lage individuelle linker ved å trykke på 'Lag nytt innlegg'");
define("GSLAN_37", "Når du har noen innlegg går du til <a href='https://www.google.com/webmasters/sitemaps/stats'>https://www.google.com/webmasters/sitemaps/stats</a> og skriver inn følgende URL <b>".SITEURL."gsitemap.php</b> - om denne URLen ikke ser rett ut for deg, så må du forsikre deg om at din sideURL er korrekt i admin -> Innstillinger");
define("GSLAN_38", "For mere informasjon om Google Sidekartprotokollen så kan du gå til <a href='http://www.google.com/webmasters/sitemaps/docs/en/protocol.html'>http://www.google.com/webmasters/sitemaps/docs/en/protocol.html</a>.");
define("GSLAN_39", "Ingen linker i sidekart - Importer sidelinker?");
define("GSLAN_40", "Google Sidekartinnlegg");


?>