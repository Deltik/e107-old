<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_menu/languages/Norwegian.php,v $
|     $Revision: 1.0 $
|     $Date: 2006/02/06 19:31:23 $
|     $Author: Asta $
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Gjester: ");
define("ONLINE_L2", "Medlemmer: ");
define("ONLINE_L3", "På denne siden: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Medlemmer");
define("ONLINE_L6", "nyeste");
define("TRACKING_MESSAGE", "Online brukersporing er for øyeblikket deaktivert, aktiver den <a href='".e_ADMIN."users.php?options'>her</a></span><br />");


?>