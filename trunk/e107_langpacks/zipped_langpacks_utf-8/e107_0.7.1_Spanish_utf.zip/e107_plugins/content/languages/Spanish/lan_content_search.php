<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Spanish/lan_content_search.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Contenidos");
define("CONT_SCH_LAN_2", "Todas las categorías de contenidos");
define("CONT_SCH_LAN_3", "Enviado en respuesta al elemento");
?>