<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/tree_menu/languages/Spanish.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/01/19 00:30:15 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Configurar árbol de menú");
define("TREE_L2", "Actualizar opciones del árbol de menú");
define("TREE_L3", "Configuración guardada.");
define("TREE_L4", "On");
define("TREE_L5", "Off");
define("TREE_L6", "Clase CSS para usar en enlaces sin poder abrir");
define("TREE_L7", "Clase CSS para usar en enlaces normales");
define("TREE_L8", "Clase CSS para usar en enlaces abiertos");
define("TREE_L9", "Use la clase spacer entre los enlaces principales");

?>
