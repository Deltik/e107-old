<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/search.php,v $
|     $Revision: 1.13 $
|     $Date: 2006/01/16 23:45:35 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Si su versión de servidor MySQL lo soporta usted puede cambiar método corto de MySql  que es más rápido que el método corto de PHP.<br />Ver Preferencias<br />Si su sitio incluye idiomas ideográficos como el Chino o Japonés debe usar el método corto de PHP y desactivar la coincidencia total de la palabra.";
$ns -> tablerender("Ayuda búsquedas", $text);
?>