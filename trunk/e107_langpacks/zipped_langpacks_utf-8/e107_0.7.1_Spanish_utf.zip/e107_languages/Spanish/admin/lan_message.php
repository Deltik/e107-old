<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_message.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/03 22:17:41 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Mensajes recibidos");
define("MESSLAN_2", "Eliminar mensaje");
define("MESSLAN_3", "Mensaje borrado.");
define("MESSLAN_4", "Borrar todos los mensajes");
define("MESSLAN_5", "Confirmar");
define("MESSLAN_6", "Todos los mensajes borrados.");
define("MESSLAN_7", "Sin mensajes.");
define("MESSLAN_8", "Tipo de mensaje");
define("MESSLAN_9", "Informe");
define("MESSLAN_10", "Enviado por");
define("MESSLAN_11", "Abrir en nueva ventana");
define("MESSLAN_12", "Mensaje");
define("MESSLAN_13", "Enlace");
?>