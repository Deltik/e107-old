<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_db.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Configuración del nucleo guardada con backup en la base de datos.");
define("DBLAN_2", "Backup BD");
define("DBLAN_3", "Hacer Backup de base de datos SQL");
define("DBLAN_4", "Chequear validación");
define("DBLAN_5", "Chequear validación de la base de datos");
define("DBLAN_6", "Optimizar BD");
define("DBLAN_7", "Optimizar base de datos SQL");
define("DBLAN_8", "Backup del Núcleo");
define("DBLAN_9", "Hacer Backup de núcleo");
define("DBLAN_10", "Utilidades de la base de datos");
define("DBLAN_11", "Base de datos MySQL");
define("DBLAN_12", "Optimizada");
define("DBLAN_13", "Volver");
define("DBLAN_14", "Hecho");
define("DBLAN_15", "Ver actualizaciones disponibles");
define("DBLAN_16", "Buscar actualizaciones");
?>