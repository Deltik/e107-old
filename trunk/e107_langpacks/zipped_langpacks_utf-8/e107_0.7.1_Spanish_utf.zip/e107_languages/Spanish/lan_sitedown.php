<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_sitedown.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sitio cerrado temporalmente");
define("LAN_00", "<b>- Temporalmente cerrado -</b><br /><br />Hemos cerrado temporalmente nuestro portal para realizar un mantenimiento del mismo e implementar nuevas utilidades. Este proceso durará pocas horas - Le rogamos nos disculpe por los inconvenientes que este proceso le pueda causar..");
define("LAN_01", "Este sitio está cerrado temporalmente por mantenimiento. El sitio estará disponible lo antes posible, por favor disculpe las molestias.");
?>