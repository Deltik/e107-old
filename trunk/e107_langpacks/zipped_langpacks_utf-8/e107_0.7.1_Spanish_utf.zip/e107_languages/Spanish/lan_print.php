<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_print.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vista para Impresión");

define("LAN_86", "Categoría:");
define("LAN_87", "por ");

define("LAN_94", "Enviada por");

define("LAN_135", "Noticias: ");

define("LAN_303", "Esta noticia proviene de ");
define("LAN_304", "Título del artículo: ");
define("LAN_305", "Encabezado: ");
define("LAN_306", "Este artículo es de ");
define("LAN_307", "Imprimir esta página");

?>