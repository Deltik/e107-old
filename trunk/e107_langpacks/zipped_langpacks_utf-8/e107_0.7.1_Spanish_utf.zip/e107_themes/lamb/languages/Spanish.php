<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/lamb/languages/Spanish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/03 22:41:15 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'lamb' por <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Comentarios desactivados ");
define("LAN_THEME_3", "Comentario(s):");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");


?>