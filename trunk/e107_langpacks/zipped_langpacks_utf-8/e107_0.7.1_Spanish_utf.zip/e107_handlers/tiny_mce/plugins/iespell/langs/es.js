// ES lang variables by Natxo CC

tinyMCE.addToLang('',{
iespell_desc : 'Ejecutar corrector ortográfico',
iespell_download : "ieSpell no detectado. Haga click en OK para ir a la página de descarga."
});

