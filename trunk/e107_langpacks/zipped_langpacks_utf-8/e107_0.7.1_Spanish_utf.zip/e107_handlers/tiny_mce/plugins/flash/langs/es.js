// ES lang variables by Natxo CC

tinyMCE.addToLang('flash',{
title : 'Insertar / editar Flash',
desc : 'Insertar / editar Flash',
file : 'Archivo (.swf)',
size : 'Tamaño',
list : 'Archivos',
props : 'Propiedades',
general : 'General'
});
