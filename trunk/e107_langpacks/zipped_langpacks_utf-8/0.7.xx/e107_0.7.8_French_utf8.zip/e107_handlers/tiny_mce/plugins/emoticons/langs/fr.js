// Variable lang Fr

tinyMCELang['lang_insert_emoticons_title'] = 'Ins&eacute;rer une �motic&ocirc;ne';
tinyMCELang['lang_emoticons_desc'] = 'Emotic&ocirc;nes';
