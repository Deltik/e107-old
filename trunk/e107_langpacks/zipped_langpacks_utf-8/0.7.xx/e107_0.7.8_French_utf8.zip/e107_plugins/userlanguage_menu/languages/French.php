<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/userlanguage_menu/languages/French.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/04 21:44:53 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("UTHEME_MENU_L1", "Choisir le langage");
define("UTHEME_MENU_L2", "Choisir le langage");
define("UTHEME_MENU_L3", "tables");


?>
