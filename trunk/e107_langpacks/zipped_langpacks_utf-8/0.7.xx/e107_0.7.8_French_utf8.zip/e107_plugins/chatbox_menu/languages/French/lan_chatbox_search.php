<?php
define("CB_SCH_LAN_1", "".GLOBAL_LAN_CHATBOX_2."");
?>
