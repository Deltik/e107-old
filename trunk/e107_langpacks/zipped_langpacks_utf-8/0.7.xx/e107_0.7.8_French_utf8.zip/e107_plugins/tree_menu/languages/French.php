<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/tree_menu/languages/French.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/04 21:44:40 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("TREE_L1", "Configurer le Tree Menu");
define("TREE_L2", "Mettre à jour les paramètres du Tree Menu ");
define("TREE_L3", "Configuration du Tree Menu sauvegardée.");
define("TREE_L4", "Activé");
define("TREE_L5", "Désactivé");
define("TREE_L6", "Classe CSS à utiliser pour les liens non ouvrables");
define("TREE_L7", "Classe CSS à utiliser pour les liens ouvrables");
define("TREE_L8", "Classe CSS à utiliser pour les liens ouverts");
define("TREE_L9", "Utiliser la classe Espace (spacer) entre les liens principaux");
?>
