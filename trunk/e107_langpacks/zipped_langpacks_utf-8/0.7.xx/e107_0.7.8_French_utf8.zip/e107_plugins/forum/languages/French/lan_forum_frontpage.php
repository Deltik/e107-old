<?php 
define("FOR_FP_1", "Forum");
?>
