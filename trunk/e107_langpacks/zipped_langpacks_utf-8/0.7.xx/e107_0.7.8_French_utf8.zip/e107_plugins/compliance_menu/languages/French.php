<?php
define("COMPLIANCE_L1", "Compatibilité W3C");	
?>
