<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Créé automatiquement par le fichier e107_languages/French/French_config.php
| Outil développé par Daddy Cool at e107educ.org
| Modifié par: Daddy Cool
| Date: 2006-12-15, 19:05h
+---------------------------------------------------------------+
*/
$custom_lan['news']	= array('f','actualité');
$custom_lan['chatbox']	= array('m','mégaphone');

define("GLOBAL_LAN_NEWS_1", "actualité");
define("GLOBAL_LAN_NEWS_2", "Actualité");
define("GLOBAL_LAN_NEWS_3", "actualités");
define("GLOBAL_LAN_NEWS_4", "Actualités");
define("GLOBAL_LAN_D_PREFIX_NEWS", "&#39;");
define("GLOBAL_LAN_L_PREFIX_NEWS", "&#39;");
define("GLOBAL_LAN_DU_PREFIX_NEWS", "de l&#39;");

define("GLOBAL_LAN_CHATBOX_1", "mégaphone");
define("GLOBAL_LAN_CHATBOX_2", "Mégaphone");
define("GLOBAL_LAN_CHATBOX_3", "mégaphones");
define("GLOBAL_LAN_CHATBOX_4", "Mégaphones");
define("GLOBAL_LAN_D_PREFIX_CHATBOX", "e ");
define("GLOBAL_LAN_L_PREFIX_CHATBOX", "e ");
define("GLOBAL_LAN_DU_PREFIX_CHATBOX", "du ");
?>