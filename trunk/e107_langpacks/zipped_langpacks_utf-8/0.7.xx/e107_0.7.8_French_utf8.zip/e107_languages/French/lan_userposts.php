<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Messages Utilisateurs"); 
define("UP_LAN_0", "Tous les messages du forum de ");
define("UP_LAN_1", "Tous les commentaires de ");
define("UP_LAN_2", "Sujet");
define("UP_LAN_3", "Vues");
define("UP_LAN_4", "Réponses");
define("UP_LAN_5", "Dernier message");
define("UP_LAN_6", "Sujets");
define("UP_LAN_7", "Aucun commentaire");
define("UP_LAN_8", "Aucun message");
define("UP_LAN_9", " le ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Posté le : ");
define("UP_LAN_12", "Rechercher");
define("UP_LAN_13", "Commentaires");
define("UP_LAN_14", "Messages Forum :");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "Adresse IP");
?>
