<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_top.php,v $
|     $Revision: 1.7 $
|     $Date: 2007/02/27 01:57:03 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("TOP_LAN_0", "Les utilisateurs postant le plus sur le Forum");
define("TOP_LAN_1", "Identifiant");
define("TOP_LAN_2", "Messages");
define("TOP_LAN_3", "Les utilisateurs postant le plus de commentaires");
define("TOP_LAN_4", "Commentaires");
define("TOP_LAN_5", "Les utilisateurs postant le plus dans l".GLOBAL_LAN_L_PREFIX_CHATBOX.GLOBAL_LAN_CHATBOX_2."");
define("TOP_LAN_6", "Évaluation du Site");
  //v.616
define("LAN_1", "Discussion");
define("LAN_2", "Posté par");
define("LAN_3", "Vues");
define("LAN_4", "Réponses");
define("LAN_5", "Dernier message");
define("LAN_6", "Discussions");
define("LAN_7", "Discussions les plus actives");
define("LAN_8", "Les utilisateurs participant le plus");
?>
