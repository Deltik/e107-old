<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_updateadmin.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/12/04 21:32:32 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("UDALAN_1", "Erreur - veuillez recommencer");
define("UDALAN_2", "Paramètres mis à jour");
define("UDALAN_3", "Paramètres mis à jour pour");
define("UDALAN_4", "Identifiant");
define("UDALAN_5", "Saisir le mot de passe");
define("UDALAN_6", "Resaisir le mot de passe");
define("UDALAN_7", "Changer de mot de passe");
define("UDALAN_8", "Mot de passe mis à jour pour");


?>