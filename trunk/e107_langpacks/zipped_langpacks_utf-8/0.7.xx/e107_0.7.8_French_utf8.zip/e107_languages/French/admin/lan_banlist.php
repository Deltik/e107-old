<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_banlist.php,v $
|     $Revision: 1.8 $
|     $Date: 2007/02/27 01:57:03 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("BANLAN_1", "Bannissement supprimé.");
define("BANLAN_2", "Aucun bannissement.");
define("BANLAN_3", "Liste des bannissements");
define("BANLAN_4", "Supprimer le bannissement");
define("BANLAN_5", "Entrer une adresse IP/courriel ou un nom de domaine");
define("BANLAN_6", "Bannir par adresse électronique"); 
define("BANLAN_7", "Raison");
define("BANLAN_8", "Bannir l&#39;adresse");
define("BANLAN_9", "Bannir les utilisateurs du site à partir du courriel, de l'adresse IP ou du nom de domaine");
define("BANLAN_10", "IP - Courriel - Domaine / Raison");
define("BANLAN_11", "Bannissement automatique: Plus de 10 essais de connexions infructueuses");
define("BANLAN_12", "Note : Reverse DNS est actuellement désactivé, il doit être activé pour permettre le bannissement selon l'hébergeur. Bannir selon l'IP ou le courriel fonctionnera tout de même normalement.");
define("BANLAN_13", "Note: Pour bannir un utilisateur par son identifiant, rendez-vous sur la page de gestion des utilisateurs: ");
?>
