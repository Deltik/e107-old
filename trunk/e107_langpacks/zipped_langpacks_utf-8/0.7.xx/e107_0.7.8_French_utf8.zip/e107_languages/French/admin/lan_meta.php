<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_meta.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/12/10 08:43:18 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("METLAN_1", "Les Méta-tags ont été mis à jour dans la base de données");
define("METLAN_2", "Entrer les méta-tags");
define("METLAN_3", "Entrer les nouveaux méta-tags");
define("METLAN_4", "Mis à jour");
define("METLAN_5", "saisissez votre description ici");
define("METLAN_6", "saisissez, une, liste, de, mots, clés, ici");
define("METLAN_7", "saisissez les infos de droits d'auteur ici");
define("METLAN_8", "Méta Tags");
define("METLAN_9", "Description");
define("METLAN_10", "Mots clés");
define("METLAN_11", "Copyright");
define("METLAN_12", "Utiliser le titre et le sommaire des ".GLOBAL_LAN_NEWS_4." comme méta-description des pages d".GLOBAL_LAN_D_PREFIX_NEWS.GLOBAL_LAN_NEWS_3.".");
define("METLAN_13", "Auteur");
?>
