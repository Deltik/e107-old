<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/emoticon.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/04 21:32:31 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Lorsque les émoticônes sont activées, les chaines de caractères émoticônes standards sont remplacées par leurs images Smiley respectives et ce sur l'ensemble de votre site.";
$ns -> tablerender("Aide émoticônes ", $text);
?>
