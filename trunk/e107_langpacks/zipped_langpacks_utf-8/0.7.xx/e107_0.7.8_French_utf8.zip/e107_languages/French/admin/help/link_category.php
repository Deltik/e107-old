<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/link_category.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/04 21:32:31 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Vous pouvez séparer vos liens en différentes catégories. Cela rend la navigation plus simple et améliore la mise en page.";
$ns -> tablerender("Catégories de liens", $text);
?>
