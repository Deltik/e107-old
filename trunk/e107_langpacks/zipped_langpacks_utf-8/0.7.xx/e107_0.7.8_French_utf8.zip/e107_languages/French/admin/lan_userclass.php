<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_userclass.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/12/04 21:32:32 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("UCSLAN_1", "Envoyer une alerte par courriel à");
define("UCSLAN_2", "Privilèges mis à jour");
define("UCSLAN_3", "Chère / Cher");
define("UCSLAN_4", "Vos privilèges ont été modifier sur le site");
define("UCSLAN_5", "Vous êtes désormais membre du ou des groupes suivants");
define("UCSLAN_6", "Configurer l'appartenance au(x) groupe(s) de l'utilisateur");
define("UCSLAN_7", "Enregistrer les groupes");
define("UCSLAN_8", "Avertir l'utilisateur");
define("UCSLAN_9", "Groupe mis à jour");
define("UCSLAN_10", "Cordialement");
?>
