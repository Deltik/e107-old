<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_ugflag.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/12/04 21:32:32 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("UGFLAN_1", "Paramètres de maintenance mises à jour");
define("UGFLAN_2", "Activer la maintenance du site");
define("UGFLAN_3", "Mettre à jour");
define("UGFLAN_4", "Paramètres de maintenance");
define("UGFLAN_5", "Texte à afficher lorsque le site est en maintenance");
define("UGFLAN_6", "Laisser vide pour afficher le message par défaut");
?>
