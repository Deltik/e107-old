<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/chatbox.php,v $
|     $Revision: 1.5 $
|     $Date: 2007/02/27 01:57:03 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$caption = "Aide ".GLOBAL_LAN_CHATBOX_2."";
$text = "Configurez vos paramètres pour l".GLOBAL_LAN_L_PREFIX_CHATBOX.GLOBAL_LAN_CHATBOX_2." ici.";
$ns -> tablerender($caption, $text);
?>
