<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_frontpage.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/12/04 21:32:32 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("FRTLAN_1", "Les paramètres de la page d'accueil ont été mis à jour.");
define("FRTLAN_2", "Page d'accueil pour");
define("FRTLAN_6", "Liens");
  //define("FRTLAN_7", "Page de Contenu");
define("FRTLAN_12", "Mettre à jour les paramètres");
define("FRTLAN_13", "Paramètres de la page d'accueil");
define("FRTLAN_15", "Autre (entrer l'URL):");
define("FRTLAN_16", "erreur: pas de catégorie principale de pages de contenu");
define("FRTLAN_17", "erreur: pas de sous catégorie de pages de contenu sélectionnée");
define("FRTLAN_18", "erreur: pas de page de contenu sélectionnée");
define("FRTLAN_19", "Catégorie principale de pages de contenu");
define("FRTLAN_20", "catégorie de  pages de contenu");
define("FRTLAN_21", "pages de contenu");
define("FRTLAN_22", "");
define("FRTLAN_23", "");
define("FRTLAN_24", "");
define("FRTLAN_25", "");
define("FRTLAN_26", "tous les utilisateurs");
define("FRTLAN_27", "Visiteurs");
define("FRTLAN_28", "Utilisateurs");
define("FRTLAN_29", "Administrateurs");
define("FRTLAN_31", "Tous les utilisateurs");
define("FRTLAN_32", "Groupe d'utilisateurs");
define("FRTLAN_33", "Paramètres actuels");
define("FRTLAN_34", "Page d'accueil");
?>
