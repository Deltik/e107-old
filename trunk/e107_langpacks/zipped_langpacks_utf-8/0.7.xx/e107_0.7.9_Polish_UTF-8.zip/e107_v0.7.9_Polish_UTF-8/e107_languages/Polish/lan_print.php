<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2007/04/21 13:37:29 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_print.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_print.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Strona do druku"); }

define("LAN_PRINT_86", "Kategoria:");
define("LAN_PRINT_87", "przez ");
define("LAN_PRINT_94", "Dodane przez");
define("LAN_PRINT_135", "Tytuł wiadomości");
define("LAN_PRINT_303", "Ta wiadomość pochodzi ze strony ");
define("LAN_PRINT_304", "Tytuł: ");
define("LAN_PRINT_305", "Podtytuł: ");
define("LAN_PRINT_306", "Ten artykuł pochodzi ze strony: ");
define("LAN_PRINT_307", "Drukuj stronę");

define("LAN_PRINT_1", "Szybkie drukowanie");

?>
