<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ŠSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/leaf/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/27 06:19:47 $
|     $Author: qnome $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Hozzászólás ");
define("LAN_THEME_2", "Hozzászólás kikapcsolva");
define("LAN_THEME_3", "Hozzászólás ");
define("LAN_THEME_4", "Tovább ...");
define("LAN_THEME_5", "Trackback: ");
define("LAN_THEME_6", "Hozzászólást írta");


?>