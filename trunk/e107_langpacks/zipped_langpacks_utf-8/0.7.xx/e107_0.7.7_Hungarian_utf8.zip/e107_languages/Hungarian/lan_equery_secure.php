<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("EQSEC_LAN1", "Egy admin funkcióhoz leszel átirányítva, módosulhat az adatbázis");
define("EQSEC_LAN2", "Erősítsd meg a műveletet:");
define("EQSEC_LAN3", "Nincs utaló");
define("EQSEC_LAN4", "Honnan:");
define("EQSEC_LAN5", "Hova:");
define("EQSEC_LAN6", "Megerősítés");
define("EQSEC_LAN7", "vagy kilépés");
?>