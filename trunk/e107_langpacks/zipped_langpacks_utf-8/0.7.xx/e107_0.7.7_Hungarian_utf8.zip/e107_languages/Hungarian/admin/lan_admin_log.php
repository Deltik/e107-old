<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Napló (Log)");
define("LAN_ADMINLOG_1", "Dátum");
define("LAN_ADMINLOG_2", "Cím");
define("LAN_ADMINLOG_3", "Leírás");
define("LAN_ADMINLOG_4", "Felhasználó IP");
define("LAN_ADMINLOG_5", "Felhasználó ID");
define("LAN_ADMINLOG_6", "Tájékoztató Ikon");
define("LAN_ADMINLOG_7", "Tájékoztató Üzenet");
define("LAN_ADMINLOG_8", "Figyelmeztető Ikon");
define("LAN_ADMINLOG_9", "Figyelmeztető Üzenet");
define("LAN_ADMINLOG_10", "Riasztás Ikon");
define("LAN_ADMINLOG_11", "Riasztás Üzenet");
define("LAN_ADMINLOG_12", "Végzetes hiba Ikon");
define("LAN_ADMINLOG_13", "Végzetes hiba Üzenet");

?>
