<?php
$caption  = "Chatbox súgó";
$text = "Chatbox beállításait végezheted el itt.<br />Ha a link cseréje aktív, akkor a rendszer minden linket az itt megadott karaktersorra cserél le, így megakadályozva, hogy a hosszú linkek megjelenítési problémákat okozzanak. A sortörés minden, az itt megadott értéknél hoszabb szót megtördel.";

$ns -> tablerender($caption, $text);
?>
