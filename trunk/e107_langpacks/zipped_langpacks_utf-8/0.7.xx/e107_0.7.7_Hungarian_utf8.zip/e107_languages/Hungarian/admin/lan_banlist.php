<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("BANLAN_1", "Kitiltás kikapcsolva.");
define("BANLAN_2", "Nincs kitiltás.");
define("BANLAN_3", "Érvényben lévő kitiltások");
define("BANLAN_4", "Kitiltás törlése");
define("BANLAN_5", "Add meg az IP címet, az e-mail címet vagy a host-ot");
define("BANLAN_7", "Indoklás");
define("BANLAN_8", "Felhasználó kitiltása");
define("BANLAN_9", "Felhasználók kitiltása");
define("BANLAN_10", "IP / E-mail cím / Indok");
define("BANLAN_11", "Automatikus-Kitiltás: Több, mint 10 hibás bejelentkezési kisérlet");
define("BANLAN_12", "Megjegyzés: A DNS megváltoztatása jelenleg letiltva, a host alapján történő kitiltáshoz engedélyezni kell. Az IP és email alapján történő kitiltás még normálisan műkődik.");
?>
