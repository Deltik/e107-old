<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CACLAN_1", "Cache rendszer állapot");
define("CACLAN_2", "Cache bekapcsolása");
define("CACLAN_3", "Cache rendszer");
define("CACLAN_4", "Cache bekapcsolva");
define("CACLAN_5", "Cache ürítése");
define("CACLAN_6", "Cache kiürítve");

define("CACLAN_7", "Cache kikapcsolása");
// define("CACLAN_8", "Cache adat mentése a MySQL adatbázisba");
define("CACLAN_9", "Cache tartalmának mentése fájlba");
define("CACLAN_10", "A cache könyvtár nem írható. Ellenőrizd, hogy a szerver megfelelő jogosultságokkal rendelkezik az e107_files/cache mappán. Ha nem, adj CHMOD 0777-et a mappára");
?>