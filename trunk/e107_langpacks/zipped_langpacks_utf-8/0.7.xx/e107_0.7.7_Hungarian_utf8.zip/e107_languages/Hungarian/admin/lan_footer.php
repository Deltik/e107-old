<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FOOTLAN_1", "Weboldal");
define("FOOTLAN_2", "Fő admin");
define("FOOTLAN_3", "Verzió");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Theme");
define("FOOTLAN_6", "-");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Telepítés dátuma");
define("FOOTLAN_9", "Szerver");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "PHP verzió");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Weboldal Info");
define("FOOTLAN_14", "Dokumentáció megtekintése");
define("FOOTLAN_15", "Dokumentáció");
define("FOOTLAN_16", "Adatbázis");
define("FOOTLAN_17", "Karakterkészlet");

?>
