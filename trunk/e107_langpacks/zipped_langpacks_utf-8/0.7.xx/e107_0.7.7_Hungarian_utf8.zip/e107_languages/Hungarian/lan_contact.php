<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Kapcsolat részletei");
define("LANCONTACT_02", "Kapcsolat");
define("LANCONTACT_03", "Írd be a neved:");
define("LANCONTACT_04", "E-mail cím:");
define("LANCONTACT_05", "Üzenet tárgya:");
define("LANCONTACT_06", "Írd be az üzenetet:");
define("LANCONTACT_07", "Email üzenet másolatának elküldése a saját címre ");
define("LANCONTACT_08", "Küldés");
define("LANCONTACT_09", "Üzeneted elküldve.");
define("LANCONTACT_10", "Probléma merült fel az üzenet elküldése folyamán.");
define("LANCONTACT_11", "Az email címed érvénytelen.\\nEllenőrizd, majd próbáld újra.");
define("LANCONTACT_12", "Az üzeneted nagyon rövid.");
define("LANCONTACT_13", "Add meg az üzenet tárgyát.");


define("LANCONTACT_14", "Üzenet küldése a következőnek:");
define("LANCONTACT_15", "Érvénytelen kódot írtál be");
define("LANCONTACT_16", "Kód beírása");




?>
