<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

if (!defined("PAGE_NAME")) {define("PAGE_NAME", "E-mail");}

define("LAN_EMAIL_1", "Feladó:");
define("LAN_EMAIL_2", "Küldő IP címe:");
define("LAN_EMAIL_3", "Új üzenet... ");
define("LAN_EMAIL_4", "Email küldése");
define("LAN_EMAIL_5", "Email küldése");
define("LAN_EMAIL_6", "Úgy gondoltam érdekelni fog...");
define("LAN_EMAIL_7", "email valakinek");
define("LAN_EMAIL_8", "Üzenet");
define("LAN_EMAIL_9", "Hiba: e-mail küldése sikertelen");
define("LAN_EMAIL_10", "Levél címzettje");
define("LAN_EMAIL_11", "E-mail elküldve");
define("LAN_EMAIL_12", "Hiba");
define("LAN_EMAIL_13", "Cikk küldése");
define("LAN_EMAIL_14", "Hír küldése");
define("LAN_EMAIL_15", "Felhasználónév: ");
define("LAN_EMAIL_106", "Érvénytelen email cím");
define("LAN_EMAIL_185", "Cikk küldése");
define("LAN_EMAIL_186", "Hír küldése");
define("LAN_EMAIL_187", "Címzett e-mail címe");
define("LAN_EMAIL_188", "Úgy gondoltam érdekelni fog ez a hír...");
define("LAN_EMAIL_189", "Úgy gondoltam érdekelni fog ez a cikk...");
define("LAN_EMAIL_190", "Írd be a látható kódot");


?>
