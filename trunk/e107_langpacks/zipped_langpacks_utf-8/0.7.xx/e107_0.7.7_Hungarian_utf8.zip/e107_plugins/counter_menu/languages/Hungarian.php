<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.5 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("COUNTER_L1", "Admin látogatások nincsennek számlálva.");
define("COUNTER_L2", "Ma");
define("COUNTER_L3", "Összesen");
define("COUNTER_L4", "Legtöbb");
define("COUNTER_L5", "Egyedi");
define("COUNTER_L6", "Oldal ...");
define("COUNTER_L7", "Számláló");
define("COUNTER_L8", "Admin üzenet: <b>Statisztika naplózása letiltva.</b><br />Az aktiváláshoz telepíteni kell a Statisztika naplózása plugin-t a <a href='".e_ADMIN."plugin.php'>plugin manager</a>-ben, majd aktiválni <a href='".e_PLUGIN."log/admin_config.php'>a beállítások felületen</a>.");

?>