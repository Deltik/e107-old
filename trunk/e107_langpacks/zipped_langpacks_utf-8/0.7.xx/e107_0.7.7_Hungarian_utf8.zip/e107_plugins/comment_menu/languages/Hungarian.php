<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CM_L1", "Nincs hozzászólás.");
define("CM_L2", "");
define("CM_L3", "Cím/fejléc");
define("CM_L4", "Megjelenített hozzászólások száma?");
define("CM_L5", "Megjelenített karakterek száma?");
define("CM_L6", "Túl hosszú hozzászólások levágása?");
define("CM_L7", "Eredeti hír címének mutatása a menüben?");
define("CM_L8", "Új hozzászólások menü beállítás");
define("CM_L9", "Menü beállítások frissítése");
define("CM_L10", "Hozzászólások menü beállítások elmentve");
define("CM_L11", "-");
define("CM_L12", "Válasz:");
define("CM_L13", "Beküldte");
?>
