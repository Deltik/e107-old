<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.1 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NWSF_FP_1", "Hírforrások");
define("NWSF_FP_2", "Főoldal");

?>
