<?php
/**
* PHPMailer language file.
* Hungarian Version
*/

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Legalább egy címet meg kell adnod ' . 'címzettek email címe.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer nem támogatott.';
$PHPMAILER_LANG["execute"] = 'Nem végrehajtható: ';
$PHPMAILER_LANG["instantiate"] = 'Nem rendelkezik sürgősségi mail funkcióval.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Hiba: Nincs hitelesítés.';
$PHPMAILER_LANG["from_failed"] = 'A következő címtől hiba: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Hiba: A következő ' . 'címzettek hibásak: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Hiba: Adat nincs elfogadva.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Hiba: Nem lehet csatlakozni az SMTP kiszolgálóhoz.';
$PHPMAILER_LANG["file_access"] = 'Nincs hozzáférés file: ';
$PHPMAILER_LANG["file_open"] = 'File Hiba: Nem lehet megnyitni a file-t: ';
$PHPMAILER_LANG["encoding"] = 'Ismeretlen kódolás: ';
?>