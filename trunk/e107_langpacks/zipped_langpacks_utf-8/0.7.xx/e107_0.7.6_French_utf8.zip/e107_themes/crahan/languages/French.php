<?php
  define("LAN_THEME_1", "'CraHan' by <a href='http://e107.org' rel='external'>jalist</a>, based on the theme by CraHan at his homepage <a href='http://n00.be' rel='external'>n00.be</a>");
  define("LAN_THEME_2", "Commentaires désactivés");
  define("LAN_THEME_3", "commentaires: ");
  define("LAN_THEME_4", "Suite...");
  define("LAN_THEME_5", "Trackbacks: ");
  define("LAN_THEME_6", "Commentaire par");
  ?>
