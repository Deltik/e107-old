<?php
define("LAN_THEME_1", "Les commentaires sont désactivés pour cet item");
define("LAN_THEME_2", "Lire/Poster des commentaires: ");
define("LAN_THEME_3", "Lire la suite...");
define("LAN_THEME_4", "Trackbacks: ");
define("LAN_THEME_5", "Posté par");
define("LAN_THEME_6", "le");
define("LAN_THEME_7", "Rechercher...");
?>
