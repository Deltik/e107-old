<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_print.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Impression d'une page");
  define("LAN_PRINT_86", "Catégorie ");
  define("LAN_PRINT_87", "par ");
  define("LAN_PRINT_94", "Posté par");
  define("LAN_PRINT_135", "Actualité");
  define("LAN_PRINT_303", "Cette actualité a été imprimée depuis le site ");
  define("LAN_PRINT_304", "Titre de l'article : ");
  define("LAN_PRINT_305", "Sous-titre : ");
  define("LAN_PRINT_306", "Cet article a été imprimé depuis le site ");
  define("LAN_PRINT_307", "Imprimer cette page");
  define("LAN_PRINT_1", "version imprimable");
  ?>
