<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_upload_handler.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LANUPLOAD_1", "Le type de fichier");
  define("LANUPLOAD_2", "n'est pas autorisé et a été supprimé.");
  define("LANUPLOAD_3", "chargé avec succès");
  define("LANUPLOAD_4", "Le dossier de destination n'existe pas ou n'est pas modifiable.");
  define("LANUPLOAD_5", "Le fichier chargé excède la valeur indiquée par la variable upload_max_filesize dans php.ini.");
  define("LANUPLOAD_6", "Le fichier chargé excède la valeur indiquée par la variable MAX_FILE_SIZE qui était précisé dans le formulaire HTML.");
  define("LANUPLOAD_7", "Le fichier chargé a été partiellement envoyé.");
  define("LANUPLOAD_8", "Aucun fichier n'a été envoyé.");
  define("LANUPLOAD_9", "Le fichier envoyé fait 0 octet");
  define("LANUPLOAD_10", "L'Upload a échoué [Nom du fichier dupliqué] - Un fichier existant porte déjàle même nom.");
  define("LANUPLOAD_11", "Le fichier n'a pas été chargé. Nom du fichier : ");
  define("LANUPLOAD_12", "Erreur");
  ?>
