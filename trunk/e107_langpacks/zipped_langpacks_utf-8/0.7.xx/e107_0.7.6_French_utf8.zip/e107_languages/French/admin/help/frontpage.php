<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $caption = "Page d'accueil";
  $text = "A partir de cette section, vous pouvez choisir ce qu'il faut afficher sur la page d'accueil de votre site, par défaut ce sont les actualités.";
  $ns -> tablerender($caption, $text);
  ?>
