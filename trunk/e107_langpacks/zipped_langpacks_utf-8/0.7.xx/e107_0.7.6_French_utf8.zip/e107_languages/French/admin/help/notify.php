<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Alerter par courriel lorsque des événements e107 se produisent.<br /><br />
  Par exemple, l'ensemble' IP exclus pour inondation de site ' au groupe 'Admin ' 
  et tous les administrateurs recevront un courriel si votre site est inondé.<br /><br />
  Vous pouvez également alerter vos utilisateurs lorsqu'une actualité est postée.<br /><br />
  Si vous voulez que les alertes par courriel soient envoyées à une adresse électronique alternative - 
  sélectionnez l'option 'Courriel' et entrez dans le champ l'adresse électronique.";
  $ns -> tablerender("Aide Alertes", $text);
  ?>
