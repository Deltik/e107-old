<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/users.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Cette page permet de modérer les membres enregistrés. Vous pouvez modifier leurs paramètres, leur donner le statut d'administrateur, les intégrer dans un groupe ...";
  $ns -> tablerender("Aide Membres", $text);
  unset($text);
  ?>
