<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_emoticon.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/05/27 13:23:44 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("EMOLAN_1", "Activation des émoticônes");
  define("EMOLAN_2", "Nom");
  define("EMOLAN_3", "Émoticônes");
  define("EMOLAN_4", "Activer les émoticônes ?");
  define("EMOLAN_5", "Image");
  define("EMOLAN_6", "Code de l'émoticône");
  define("EMOLAN_7", "Entrées multiples séparées avec des espaces");
  define("EMOLAN_8", "Statut");
  define("EMOLAN_9", "Options");
  define("EMOLAN_10", "Activé");
  define("EMOLAN_11", "Activer");
  define("EMOLAN_12", "Éditer / configurer ce pack");
  define("EMOLAN_13", "Packs Installés");
  define("EMOLAN_14", "Sauvegarder la configuration");
  define("EMOLAN_15", "Éditer / configurer les émoticônes");
  define("EMOLAN_16", "Configuration des émoticônes sauvegardé");
  ?>
