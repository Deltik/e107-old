<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/cpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/10 03:15:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "A partir de cette page,vous pouvez créer des menus ou des pages personnifiés 
  et y insérer votre propre contenu.<br />
  <br/><strong>Pour plus d'explications sur les menus et les pages personnifiés:</strong>
  <br/><br/>Consulter <strong>en anglais</strong>
  <br/> en cliquant sur la page <br />
  <a href='http://e107.org/e107_plugins/docs/docs.php?133'target='_blank'>
  <strong>Using Custom Pages and Custom Menus</strong></a> 
  <br/><br />ou la page <strong>en français</strong>
  <br /><a href='http://trans.voila.fr/voila?systran_lp=en_fr&systran_id=Voila-fr&systran_url=http://e107.org/e107_plugins/docs/docs.php?133&systran_f=100000000000'target='_blank'><strong>Utilisation des pages et menus personnifiés</strong></a>
  <br/>Approximativement traduite par le moteur de traduction Systran installé sur le site de voila.fr";
  $ns -> tablerender(CUSLAN_0, $text);
  ?>
