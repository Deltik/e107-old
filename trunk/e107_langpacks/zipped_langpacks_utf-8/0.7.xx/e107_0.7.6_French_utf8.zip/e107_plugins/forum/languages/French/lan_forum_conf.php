<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/French/lan_forum_conf.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("FORLAN_5", "Sondage supprimé.");
  define("FORLAN_6", "Sujet supprimé");
  define("FORLAN_7", "réponses supprimées");
  define("FORLAN_8", "Suppression annulée.");
  define("FORLAN_9", "Sujet déplacé.");
  define("FORLAN_10", "Déplacement annulé.");
  define("FORLAN_11", "Revenir aux Forums");
  define("FORLAN_12", "Configuration du Forum");
  define("FORLAN_13", "êtes-vous absolument certain(e) de vouloir supprimer ce sondage ?<br />Une fois supprimé il sera <strong><u>impossible</u></strong> de le réactiver.");
  define("FORLAN_14", "Annuler");
  define("FORLAN_15", "Confirmer la suppression de ce message");
  define("FORLAN_16", "Confirmer la suppression de ce sondage");
  define("FORLAN_17", "posté par");
  define("FORLAN_18", "êtes-vous absolument certain(e) de vouloir supprimer ce forum, ses");
  define("FORLAN_19", "sujets et tous ses messages ?");
  define("FORLAN_20", "le sondage sera aussi supprimé");
  define("FORLAN_21", "Une fois supprimé ils");
  define("FORLAN_22", "message ?<br />Une fois cela supprimé");
  define("FORLAN_23", "ne pourront pas</u></strong> être retrouvés");
  define("FORLAN_24", "Déplacer ce sujet dans le forum");
  define("FORLAN_25", "Déplacer le Sujet");
  define("FORLAN_26", "Réponse supprimée");
  define("FORLAN_27", "déplacé");
  define("FORLAN_28", "Ne pas renommer le sujet");
  define("FORLAN_29", "Ajouter");
  define("FORLAN_30", "au titre");
  define("FORLAN_31", "Renommer:");
  define("FORLAN_32", "Options de renommage du sujet:");
  ?>
