<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/French/lan_newforumposts_menu.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("NFP_1", "Les derniers messages appartiennent tous à d'autres groupes d'utilisateurs, et ne peuvent donc pas être affichés");
  define("NFP_2", "Pas encore de message");
  define("NFP_3", "Paramètres du menu newforumposts enregistrés");
  define("NFP_4", "Légende");
  define("NFP_5", "Nombres de messages à afficher?");
  define("NFP_6", "Nombres de caractères à afficher?");
  define("NFP_7", "Suffixe pour message trop longs ?");
  define("NFP_8", "Affiché les sujets d'origine dans le menu?");
  define("NFP_9", "Mettre les paramètres du menu à jour ");
  define("NFP_10", "Configuration du menu newforumposts");
  define("NFP_11", "Posté par");
  ?>
