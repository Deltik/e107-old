<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/alt_auth/languages/French/lan_ldap_auth.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LDAPLAN_1", "Adresse du serveur");
  define("LDAPLAN_2", "Base DN or Domain<br />Si LDAP - Enter BaseDN<br />If AD - Enter domain");
  define("LDAPLAN_3", "Utilisateur LDAP<br />Nom (full context) de l'utilisateur autorisé à scaner le directory.");
  define("LDAPLAN_4", "Mot de passe LDAP<br />Mot de passe pour l'utilisateur.");
  define("LDAPLAN_5", "Version LDAP");
  define("LDAPLAN_6", "Configurer LDAP auth");
  ?>
