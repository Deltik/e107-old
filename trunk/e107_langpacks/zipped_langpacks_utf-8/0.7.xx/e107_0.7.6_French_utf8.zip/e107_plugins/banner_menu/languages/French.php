<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/banner_menu/languages/French.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("BANNER_MENU_L1", "Publicité");
  define("BANNER_MENU_L2", "Configuration du menu bannière sauvegardée");
  //v.617
  define("BANNER_MENU_L3", "Légende");
  define("BANNER_MENU_L4", "Campagne");
  define("BANNER_MENU_L5", "Configuration menu bannière  ");
  define("BANNER_MENU_L6", "choisissez la campagne à afficher dans le menu");
  define("BANNER_MENU_L7", "Campagnes disponibles");
  define("BANNER_MENU_L8", "Campagnes selectionnées");
  define("BANNER_MENU_L9", "Supprimer la sélection");
  define("BANNER_MENU_L10", "comment afficher les campagnes choisies ?");
  define("BANNER_MENU_L11", "Choisissez le type de rendu ...");
  define("BANNER_MENU_L12", "une campagne dans le menu simple");
  define("BANNER_MENU_L13", "toutes les campagnes choisies dans un seul menu");
  define("BANNER_MENU_L14", "toutes les campagnes choisies dans des menus indépendants");
  define("BANNER_MENU_L15", "combien de bannières devront être affichées?");
  define("BANNER_MENU_L16", "ce paramètre sera seulement utilisé avec les options 2 et 3. <br />  s'il y a moins de bannières sont présentes la somme disponible maximale sera utilisée.");
  define("BANNER_MENU_L17", "mettre la somme de ...");
  define("BANNER_MENU_L18", "Mise à jour des paramètres du menu ");
  ?>
