<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_extended_menu/languages/French.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("ONLINE_EL1", "Invit&eacute;s : "); //ne pas changer cette syntaxe ascii!
  define("ONLINE_EL2", "Membres : ");
  define("ONLINE_EL3", "Sur cette page : ");
  define("ONLINE_EL4", "En ligne");
  define("ONLINE_EL5", "Membres");
  define("ONLINE_EL6", "Dernier membre");
  define("ONLINE_EL7", "sur");
  define("ONLINE_EL8", "Record :");
  define("ONLINE_EL9", "le");
  define("TRACKING_MESSAGE", "Le traçer d'utilisateur en ligne est pour le moment désactivé, activez-le <a href='".e_ADMIN."users.php?options'>ici</a></span><br />");
  ?>
