<?php
/*
+---------------------------------------------------------------+
|        e107 website system thai Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_themes/crahan/languages/Thai.php,v $
|        $Revision: 1.1 $
|        $Date: 2007/04/11 05:41:12 $
|        $Author: e107coders $
+---------------------------------------------------------------+
/*แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 มีนาคม.2550
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 March 2007 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com(Official International Sites)
*/
define("LAN_THEME_1", "ชุดแบบกราฟิกชื่อ 'CraHan' โดย <a href='http://e107.org' rel='external'>jalist</a>, พัฒนาต่อจากแบบชุดกราฟิกโฮมเพจของ CraHan<a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "ปิดแสดงความเห็น");
define("LAN_THEME_3", "ความเห็นที่มี");
define("LAN_THEME_4", "อ่านต่อ ...");
define("LAN_THEME_5", "ติดตาม: ");
define("LAN_THEME_6", "ความเห็นโดย");


?>