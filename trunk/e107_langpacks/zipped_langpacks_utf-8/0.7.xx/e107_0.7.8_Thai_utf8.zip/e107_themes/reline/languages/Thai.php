<?php
/*
+---------------------------------------------------------------+
|        e107 website system thai Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_themes/reline/languages/Thai.php,v $
|        $Revision: 1.1 $
|        $Date: 2007/04/11 05:41:13 $
|        $Author: e107coders $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "ปิดแสดงความคิดเห็น");
define("LAN_THEME_2", "อ่าน-เขียนความคิดเห็น");
define("LAN_THEME_3", "อ่านต่อ...");
define("LAN_THEME_4", "ติดตาม");
define("LAN_THEME_5", "ส่งโดย");
define("LAN_THEME_6", "เมื่อ");
define("LAN_THEME_7", "สืบค้น");


?>