<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/lan_prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/03/22 00:34:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("LAN_PREF_1", "e107 CMS:Thai Edition");

define("LAN_PREF_2", "e107 CMS");

define("LAN_PREF_3", "powered by <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, ภายใต้สิทธิอนุญาตตาม<a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a>ลิขสิทธิ์ GPL|Thai Translator & Developer : ผศ.ประชิด ทิณบุตร :<a href=http://www.prachid.com> prachid.com </a>  <a href=http://www.e107thailand.com> | e107thailand.com</a>");
define("LAN_PREF_4", "ตรวจสอบแล้ว");
define("LAN_PREF_5", "การอภิปราย");



?>