<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/admin/lan_footer.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/22 00:34:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("FOOTLAN_1", "ชื่อเว็ปไซท์");
define("FOOTLAN_2", "ชื่อผู้บริหารระบบหลัก");
define("FOOTLAN_3", "เวอร์ชั่น");
define("FOOTLAN_4", "เมื่อ");
define("FOOTLAN_5", "ชื่อชุดรูปแบบกราฟิกเว็ป");
define("FOOTLAN_6", "เขียนโดย");
define("FOOTLAN_7", "ข้อมูลระบบของเว็ปไซท์");
define("FOOTLAN_8", "วันที่ติดตั้งระบบ");
define("FOOTLAN_9", "โปรแกรมบริการอินเตอร์เน็ตของเครื่องแม่ข่าย");
define("FOOTLAN_10", "เก็บเว็ปไฟล์ไว้ที่");
define("FOOTLAN_11", "PHPเวอร์ชั่น");
define("FOOTLAN_12", "ใช้ระบบฐานข้อมูล MySQL เวอร์ชั่น");
define("FOOTLAN_13", "ข้อมูลของเว็ปไซท์คุณ");
define("FOOTLAN_14", "แสดงเอกสารแนะนำ");
define("FOOTLAN_15", "เอกสารแนะนำ");
define("FOOTLAN_16", "ชื่อฐานข้อมูล");
define("FOOTLAN_17", "ใช้ชุดรหัสอักษร");
define("FOOTLAN_18", "ชุดรูปแบบกราฟิกเว็ปไซท์");


?>