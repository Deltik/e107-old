<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/admin/lan_modcomment.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/22 00:34:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("MDCLAN_1", "ตรวจสอบ.");
define("MDCLAN_2", "ยังไม่มีความเห็น");
define("MDCLAN_3", "สมาชิก");
define("MDCLAN_4", "บุคคลทั่วไป");
define("MDCLAN_5", "ไม่ห้าม");
define("MDCLAN_6", "ห้าม");

define("MDCLAN_8", "ตรวจสอบความเห็น");
define("MDCLAN_9", "คำเตือน! การลบรายการความคิดเห็นที่ตั้งเป็นหลักนี้ จะเป็นการลบความคิดเห็นอื่นๆที่มีในกลุ่มที่ตอบนี้ออกไปด้วย!");

define("MDCLAN_10", "เลือกค่า");
define("MDCLAN_11", "ความเห็น");
define("MDCLAN_12", "ความเห็นทั้งหมด");
define("MDCLAN_13", "ปิดแล้ว");
define("MDCLAN_14", "ปิดความเห็น");
define("MDCLAN_15", "เปิด");
define("MDCLAN_16", "ปิดแล้ว");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>