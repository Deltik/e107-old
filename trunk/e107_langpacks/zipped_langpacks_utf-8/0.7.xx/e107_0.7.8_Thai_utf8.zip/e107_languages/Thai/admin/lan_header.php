<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/admin/lan_header.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/22 00:34:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("LAN_head_1", "เมนูการจัดการระบบ");
define("LAN_head_2", "เครื่องแม่ข่ายบริการของคุณ ไม่อนุญาตให้มีกาส่งไฟล์ขึ้นทาง HTTP  ดังนั้นสมาชิกจึงไม่สามารถส่งไฟล์รูปแทนตน( avatars)หรือไฟล์ภาพขึ้นได้. การแก้ไขให้ใช้งานได้นั้น ต้องเปิดคำสั่งให้ระบบสามารถทำงานได้ก่อน โดยต้องไปแก้ไขค่าในไฟล์php.ini ของเครื่องบริการแม่ข่าย ในบรรทัด file_uploadsให้เป็น On แล้ว เปิดระบบบริการใหม่(Restart). หากคุณไม่ได้ทำหน้าที่บริหารจัดการเครื่องแม่ข่ายเอง ให้แจ้งต่อผู้ที่เป็นผู้ให้บริการแม่ข่ายดำเนินการให้.");
define("LAN_head_3", "เครื่องแม่ข่ายบริการของคุณกำหนดให้ใชังานได้เฉพาะไฟล์และคำสั่งภายในระบบที่กำหนดให้ใช้เท่านั้น . การใช้งานไฟล์หรือการนำไฟล์ ไฟล์คำสั่งนอกระบบคำสั่งเข้ามาร่วมใช้งานในเว็ปไซท์ของคุณจึงไม่สมบูรณ์ .");

define("LAN_head_4", "ศูนย์กลางจัดการระบบ");

define("LAN_head_5", "แสดงภาษาในศูนย์กลางการจัดการ: ");
define("LAN_head_6", "ข้อมูลเกี่ยวกับโปรแกรมเสริม");

?>
