<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/admin/lan_meta.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/22 00:34:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("METLAN_1", "ได้ปรับปรุง Meta tags ลงในฐานข้อมูลแล้ว");
define("METLAN_2", "พิมพ์ข้อความของmeta-tags");
define("METLAN_3", "ตั้งค่า meta tag ใหม่");
define("METLAN_4", "แก้ไขแล้ว");
define("METLAN_5", "ให้พิมพ์คำอธิบายเว็ปไซท์ที่นี่");
define("METLAN_6", "พิมพ์คำสำคัญค้นหาที่นี่ แยกคำด้วยเครื่องหมายคอมม่า(,)");
define("METLAN_7", "พิมพ์ข้อมูลลิขสิทธิ์ที่นี่");
define("METLAN_8", "Meta Tags(ข้อมูลเพื่อการสืบค้นหาเว็ปไซท์ของคุณทางอินเตอร์เน็ต");

define("METLAN_9", "คำอธิบาย");
define("METLAN_10", "คำสำคัญค้น");
define("METLAN_11", "ลิขสิทธิ์");
define("METLAN_12", "ใช้หัวข้อข่าวและสรุปย่อข่าวเป็นคำอธิบายข้อมูลMetaของหน้าข่าว/เนื้อหานั้นๆ.");
define("METLAN_13", "ผู้เขียน");

?>