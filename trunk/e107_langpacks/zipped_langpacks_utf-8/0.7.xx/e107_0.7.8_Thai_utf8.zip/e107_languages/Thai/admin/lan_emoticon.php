<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/admin/lan_emoticon.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/22 00:34:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("EMOLAN_1", "การใช้งานสัญรูปอารมณ์");
define("EMOLAN_2", "ชื่อไฟล์");
define("EMOLAN_3", "สัญรูปอารมณ์");
define("EMOLAN_4", "คลิกเปิด-ปิดการใช้งานสัญรูปอารมณ์");
define("EMOLAN_5", "ภาพ");
define("EMOLAN_6", "รหัสสัญรูปอารมณ์");
define("EMOLAN_7", "แยกคำ้โดยการเว้นวรรค");
define("EMOLAN_8", "สถานะระบบ");
define("EMOLAN_9", "เลือกค่า");
define("EMOLAN_10", "เปิดใช้งาน");
define("EMOLAN_11", "ชุดสัญรูปอารมณ์ที่ให้ใช้'");
define("EMOLAN_12", "แก้ไข / ตั้งค่าชุดสัญรูปอารมณ์นี้");
define("EMOLAN_13", "ติดตั้งชุดรวม");
define("EMOLAN_14", "บันทึกการตั้งค่า");
define("EMOLAN_15", "แก้ไข / ตั้งค่าสัญรูปอารมณ์");
define("EMOLAN_16", "บันทึกการตั้งค่าสัญรูปอารมณ์แล้ว");
define("EMOLAN_17", "คุณมีชุดสัญรูปอารมณ์ที่มีการเว้นวรรค ซึ่งระบบจะไม่อนุญาตให้ใช้!");
define("EMOLAN_18", "กรุณาเปลี่ยนชื่อไฟล์รายการข้างล่างนี้ อย่าให้มีเว้นวรรค:");
define("EMOLAN_19", "ชื่อ");
define("EMOLAN_20", "ที่อยู่");
define("EMOLAN_21", "ผิดพลาด");
define("EMOLAN_22", "พบแฟ้มemote ชุดใหม่");
define("EMOLAN_23", "พบแฟ้มemote xml ชุดใหม่");
define("EMOLAN_24", "พบแฟ้มemote php ชุดใหม่");


?>