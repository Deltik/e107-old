<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/03/22 00:34:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("LANUPLOAD_1", "ชนิดของไฟล์");
define("LANUPLOAD_2", "ไม่สามารถส่งไฟล์ขึ้นได้และไฟล์จะถูกลบ.");
define("LANUPLOAD_3", "ส่งไฟล์ขึ้นสำเร็จ");
define("LANUPLOAD_4", "ไม่มีแฟ้มปลายทางหรือมีแต่ไม่อนุญาตให้เขียนไฟล์ให้เปลี่ยนโหมดไฟล์เป็นโหมด 777หรืออนุญาตให้เขียนไฟล์ลงได้");
define("LANUPLOAD_5", "ขนาดไฟล์มีขนาดเกินกว่าที่ระบบแม่ข่ายกำหนดไว้ในไฟล์ php.ini.");
define("LANUPLOAD_6", "ไฟล์ที่ส่งขึ้นมีขนาดเกินกว่าที่คำสั่ง MAX_FILE_SIZE ของรูปแบบไฟล์ html.");
define("LANUPLOAD_7", "สามารถส่งไฟล์ขึ้นได้เพียงบางส่วนเท่าั้นั้น.");
define("LANUPLOAD_8", "ไม่มีไฟล์ที่จะทำการส่งขึ้น.");
define("LANUPLOAD_9", "ขนาดของไฟล์ีีที่ส่งไฟล์ขึ้นคือ 0 bytes");
define("LANUPLOAD_10", "การส่งไฟล์ขึ้นล้มเหลว เพราะมีไฟล์ชื่อนี้อยู่แล้ว.");
define("LANUPLOAD_11", "ไม่สามารถส่งไฟล์ขึ้นได้. คือไฟล์ชื่อ: ");
define("LANUPLOAD_12", "ผิดพลาด");

?>