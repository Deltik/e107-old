<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/03/22 00:34:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "อีเมล");}
define("LAN_EMAIL_1", "จาก");
define("LAN_EMAIL_2", "ส่งจากหมายเลข IP");
define("LAN_EMAIL_3", "อีเมลจาก");
define("LAN_EMAIL_4", "ส่งอีเมล");
define("LAN_EMAIL_5", "ส่งอีเมลให้เพื่อน");
define("LAN_EMAIL_6", "เราเห็นว่า คุณอาจจะสนใจในข่าว:เนื้อหานี้");
define("LAN_EMAIL_7", "ส่งอีเมลให้ผู้อื่น");
define("LAN_EMAIL_8", "ความเห็น");
define("LAN_EMAIL_9", "ขออภัย-ไม่สามารถส่งอีเมลได้");
define("LAN_EMAIL_10", "อีเมลที่ส่งถึง");
define("LAN_EMAIL_11", "อีเมลที่ส่งแล้ว");
define("LAN_EMAIL_12", "ผิดพลาด");
define("LAN_EMAIL_13", "ส่งอีเมลบทความให้เพื่อนๆ");
define("LAN_EMAIL_14", "ส่งอีเมลหัวข้อข่าวที่น่าสนใจให้เพื่อนๆ");
define("LAN_EMAIL_15", "ชื่อสมาชิกที่เข้าใช้ระบบ: ");
define("LAN_EMAIL_106", "ชื่อที่อยู่อีเมลไม่ถูกต้อง");
define("LAN_EMAIL_185", "ส่งบทความ");
define("LAN_EMAIL_186", "ส่งข่าว:เนื้อหา");
define("LAN_EMAIL_187", "ชื่อที่อยู่อีเมลที่จะส่งถึง");
define("LAN_EMAIL_188", "เราเห็นว่า คุณอาจจะสนใจในข่าว:เนื้อหาที่ส่งให้นี้");
define("LAN_EMAIL_189", "เราเห็นว่า คุณอาจจะสนใจในบทความที่ส่งให้นี้");
define("LAN_EMAIL_190", "กรุณาพิมพ์รหัสอักขระตามที่เห็นข้างล่างนี้");


?>