<?php
/*
+ ----------------------------------------------------------------------------+
  e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/03/22 00:34:28 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
/*แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("PAGE_NAME", "ป้ายโฆษณา");
define("BANNERLAN_16", "ชื่อผู้ใช้:");
define("BANNERLAN_17", "รหัสผ่าน: ");
define("BANNERLAN_18", "ต่อไป");
define("BANNERLAN_19", "กรุณาแจ้งชื่อลูกค้าและรหัสผ่านเพื่อเข้าสู่ระบบขั้นต่อไป");
define("BANNERLAN_20", "ขออภัย ไม่พบรายละเอียดในฐานข้อมูล กรุณาติดต่อผู้จัดการระบบเพื่อขอทราบรายละเอียด");
define("BANNERLAN_21", "สถิติของป้าย");
define("BANNERLAN_22", "ลูกค้า");
define("BANNERLAN_23", "รหัสป้าย");
define("BANNERLAN_24", "คลิกเข้า");
define("BANNERLAN_25", "% คลิก");
define("BANNERLAN_26", "จำนวนคลิก");
define("BANNERLAN_27", "จำนวนคลิกที่กำหนดไว้");
define("BANNERLAN_28", "จำนวนคลิกที่คงเหลือ");
define("BANNERLAN_29", "ไม่มีป้ายโฆษณา");
define("BANNERLAN_30", "ไม่จำกัด");
define("BANNERLAN_31", "ยังไม่ใช้");
define("BANNERLAN_32", "ใช่");
define("BANNERLAN_33", "ไม่");
define("BANNERLAN_34", "จนถึง");
define("BANNERLAN_35", "คลิกมาจากหมายเลข IP");
define("BANNERLAN_36", "กำลังใช้");
define("BANNERLAN_37", "เริ่ม");
define("BANNERLAN_38", "ผิดพลาด");


?>