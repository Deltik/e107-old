<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Thai/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/03/22 00:34:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 พย.2549
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 nov 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com
*/
define("NWSLAN_1", "ได้ลบข่าวสารออกไปแล้ว.");
define("NWSLAN_2", "กรุณาคลิกในช่องเพื่อยืนยันการลบ.");
define("NWSLAN_3", "ยังไม่มีข่าวใหม่.");
define("NWSLAN_4", "ข่าวที่มีอยู่แล้ว");
define("NWSLAN_5", "เปิดการแก้ไข HTML");
define("NWSLAN_6", "ประเภท");
define("NWSLAN_7", "แก้ไข");
define("NWSLAN_8", "ลบ");
define("NWSLAN_9", "คลิกเพื่อยืนยัน");
define("NWSLAN_10", "ยังไม่ได้ทำการจัดประเภท.");
define("NWSLAN_11", "เพิ่ม/แก้ไขประเภท");
define("NWSLAN_12", "หัวข้อข่าว");
define("NWSLAN_13", "เนื้อหาข่าว");
define("NWSLAN_14", "ข่าวเพิ่มเติม");
define("NWSLAN_15", "ความคิดเห็น");
define("NWSLAN_16", "อนุญาต");
define("NWSLAN_17", "ไม่อนุญาต");
define("NWSLAN_18", "อนุญาตให้แสดงความคิดเห็นได้");
define("NWSLAN_19", "เปิดใช้");
define("NWSLAN_20", "ปล่อยว่างไว้เพื่อยกเลิกการเปิดใช้งานแบบอัตโนมัติ");
define("NWSLAN_21", "เปิดใช้ในระหว่าง");
define("NWSLAN_22", "ให้อ่านได้");
define("NWSLAN_23", "การคลิกถูก จะเป็นการกำหนดให้ข่าวนี้แสดงให้อ่านได้เฉพาะระดับสมาชิกที่ระบุไว้นี้");
define("NWSLAN_24", "ตรวจสอบอีกครั้ง");
define("NWSLAN_25", "ปรับปรุงข่าวสาร");
define("NWSLAN_26", "ส่งข่าวเข้าฐานข้อมูล");
define("NWSLAN_27", "ตรวจสอบ");
define("NWSLAN_28", "เรื่องใหม่");
define("NWSLAN_29", "ส่งข่าว");

define("NWSLAN_30", "แสดงหัวข้อเท่านั้น");

?>