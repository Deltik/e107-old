<?php
/*
+---------------------------------------------------------------+
|        e107 website system thai Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/compliance_menu/languages/Thai.php,v $
|        $Revision: 1.2 $
|        $Date: 2007/04/11 05:41:11 $
|        $Author: e107coders $
+---------------------------------------------------------------+
*/

define("COMPLIANCE_L1", "โครงสร้างเว็ปมาตรฐาน W3C");


?>