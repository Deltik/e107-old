<?php
/*แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 มีนาคม.2550
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 March 2007 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com(Official International Sites)
*/
define("LAN_ALT_1", "ระบบฐานข้อมูลสิทธิ์สมาชิก");
define("LAN_ALT_2", "ปรับปรุงการตั้งค่า");
define("LAN_ALT_3", "การใช้ระบบฐานข้อมูลสิทธิ์สมาชิก");
define("LAN_ALT_4", "ตั้งค่าพารามิเตอร์สำหรับ");
define("LAN_ALT_5", "ตั้งค่าพารามิเตอร์การตรวจ-รับรองสิทธิ์");
define("LAN_ALT_6", "ข้อปฏิบัติเมื่อการติดต่อกับระบบล้มเหลว (ให้เลือกแจ้งหรือใช้แทน)");
define("LAN_ALT_7", "หากระบบที่ต้องการเลือกใช้ใหม่ ไม่สามารถติดต่อหรือใช้งานร่วมกันได้ ให้เลือกใช้คำสั่งแทนด้วยตัวเลือกวิธีใด?");
define("LAN_ALT_8", "การปฏิบัติเมื่อค้นหาข้อมูลสมาชิกไม่พบ");
define("LAN_ALT_9", "หากระบบที่ต้องการเลือกใช้ใหม่ ไม่สามารถติดต่อหรือใช้งานร่วมกันได้ ให้เลือกใช้คำสั่งแทนด้วยตัวเลือกวิธีใด?");
define("LAN_ALT_FALLBACK", "ให้ใช้ตารางชื่อสมาชิกของ e107 ");
define("LAN_ALT_FAIL", "การเข้าใช้ระบบล้มเหลว");

?>