<?php
/*แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 มีนาคม.2550
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 March 2007 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com(Official International Sites)
*/
define("LDAPLAN_1", "ที่อยู่ของแม่ข่ายบริการ");
define("LDAPLAN_2", "ภายใต้ DN หรือ Domain<br />หากเป็น LDAP - ให้ใส่ BaseDN<br />หากเป็น AD - ให้ใส่ชื่อ domain");
define("LDAPLAN_3", "ชื่อผู้เข้าใช้ LDAP <br />ชื่อเต็มของผู้มีสิทธิ์เข้าค้นหาแฟ้มข้อมูลสมาชิก");
define("LDAPLAN_4", "รหัสผ่านเข้าใช้ LDAP <br />รหัสผ่านของผู้มีสิทธิ์เข้าค้นหาขแฟ้มข้อมูลสมาชิก( LDAP Browsing user.)");
define("LDAPLAN_5", "LDAP เวอร์ชั่น");
define("LDAPLAN_6", "ตั้งค่าสิทธิ์ของ LDAP");
define("LDAPLAN_7", "ตัวกรองค้นหา eDirectory:");
define("LDAPLAN_8", "ต้องแน่ใจว่ามีชื่อและสิทธิ์ นการเข้าใช้ฐานข้อมูลระบบอย่างถูกต้องไว้ก่อนแล้ว, <br />ie '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "ตัวกรองค้นหาปัจจุบันนี้คือ:");
define("LDAPLAN_10", "ปรับปรุงการตั้งค่าแล้ว");
define("LDAPLAN_11", "คำเตือน:ระบบตรวจเข้ารหัสสิทธิ์Ldap ยังไม่ถูกเปิดใช้หรือให้บริการ การตั้งค่าการใช้งานระบบตรวจสอบสิทธิ์Ldap ของระบบคุณ อาจจะยังใช้งานไม่ได้!");
define("LDAPLAN_12", "ประเภทของเครื่องแม่ข่ายบริการ");
define("LDAPLAN_13", "ตั้งค่าการปรับรุ่น");
?>
