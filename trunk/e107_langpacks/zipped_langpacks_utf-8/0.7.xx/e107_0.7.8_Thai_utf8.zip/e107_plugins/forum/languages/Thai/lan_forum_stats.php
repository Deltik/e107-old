<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Thai/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/04/11 05:41:12 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
/*แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 มีนาคม.2550
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 March 2007 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com(Official International Sites)
*/
define("e_PAGETITLE", "สถิติกระทู้");

define("FSLAN_1", "ทั่วไป");
define("FSLAN_2", "กระทู้ที่เปิดแล้ว");
define("FSLAN_3", "เปิดไปที่");
define("FSLAN_4", "จำนวนกระทู้");
define("FSLAN_5", "หัวข้อกระทู้");
define("FSLAN_6", "ตอบกระทู้");
define("FSLAN_7", "ดูกระทู้เข้า");
define("FSLAN_8", "ขนาดฐานข้อมูล (ตารางการอภิปรายเท่านั้น)");
define("FSLAN_9", "ความยาวโดยเฉลี่ยของแถวตารางการอภิปราย");
define("FSLAN_10", "หัวข้อยอดนิยม");
define("FSLAN_11", "อันดับ");
define("FSLAN_12", "หัวข้อ");
define("FSLAN_13", "ตอบ");
define("FSLAN_14", "เริ่มโดย");
define("FSLAN_15", "วันที่");
define("FSLAN_16", "กระทู้ที่มีผู้ดูมากที่สุด");
define("FSLAN_17", "เข้าอ่าน");
define("FSLAN_18", "ผู้ส่งมากที่สุุด");
define("FSLAN_19", "ชื่อ");
define("FSLAN_20", "กระทู้");
define("FSLAN_21", "ผู้ตั้งกระทู้มากที่สุด");
define("FSLAN_22", "ผู้ตอบมากที่สุด");
define("FSLAN_23", "สถิติกระทู้");
define("FSLAN_24", "จำนวนกระทู้ต่อวัน");

?>