<?php
/*แปลและพัฒนาส่วนระบบภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  แก้ไขล่าสุด 28 มีนาคม.2550
อาจารย์ประจำสาขาวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900.โทร.(66) 0 2942 6900  ต่อ 3011,3014
Thai Developer & Translation : Assistant Professor Prachid Tinnabutr : Division of Art ,Chandrakasem Rajabhat University,Jatuchak,Bangkok ,Thailand.10900. Tel :(66) 02 9426900 ext:3011,3014
Last update:28 March 2007 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 2962 9505  prachid@prachid.com,prachid@wittycomputer.com ,Mobile Phone : (66) 08 9667 0091
URL : http://www.prachid.com, http://www.wittycomputer.com, http://www.e107thailand.com(Official International Sites)
*/
define("NFPM_LAN_1", "ข่าว:กระทู้อภิปรายใหม่");
define("NFPM_LAN_2", "ผู้ส่ง");
define("NFPM_LAN_3", "เข้าอ่าน");
define("NFPM_LAN_4", "ตอบ");
define("NFPM_LAN_5", "ส่งล่าสุด");
define("NFPM_LAN_6", "กระทู้เข้า");
define("NFPM_LAN_7", "โดย");
	
define("NFPM_L1", "โปรแกรมเสริมนี้ เป็นส่วนแสดงรายการของกระทู้ที่ส่งเข้ามาใหม่ โดยจะจัดแสดงไว้ในหน้าแรกของเว็ปไซท์");
define("NFPM_L2", "กระทู้อภิปรายล่าสุด");
define("NFPM_L3", "การตั้งค่า ให้ไปคลิกตั้งค่าที่หน้าศูนย์กลางการบริหารจัดการระบบ ในส่วนของโปรแกรมเสริม");
define("NFPM_L4", "เปิดแสดงในพื้นที่ส่วนใดของหน้าหลัก?");
define("NFPM_L5", "ยังไม่ใช้งาน");
define("NFPM_L6", "อยู่ส่วนบนสุดของหน้า");
define("NFPM_L7", "อยู่ส่วนล่างสุดของหน้า");
define("NFPM_L8", "ตั้งชื่อหัวข้อของบล๊อค/กรอบแสดงว่า");
define("NFPM_L9", "จำนวนกระทู้ที่จะให้แสดงในกรอบ?");
define("NFPM_L10", "เปิดแสดงภายในกรอบมีแถบเลื่อน?</b>");
define("NFPM_L11", "ความสูงของสูงกรอบแสดงกระทู้");
define("NFPM_L12", "การตั้งค่าหน้าแสดงส่งกระทู้เข้าใหม่");
define("NFPM_L13", "บันทึกการตั้งค่า่");
define("NFPM_L14", "ได้ปรับปรุงการตั้งค่าหน้าแสดงกระทู้ที่ส่งเข้าใหม่แล้ว");
define("NFPM_L15", "คลิกในช่องเพื่อให้แสดงกระทู้ล่าสุด.<br />ค่าเริ่มต้นคือหัวข้อล่าสุด.");
define('NFPM_L16', '[ลบสมาชิกแล้ว]');
	
	
?>