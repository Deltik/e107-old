<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_news.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/11 18:13:29 $
|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "News");

define("LAN_82", "News - Categoria");
define("LAN_83", "Nessuna news in archivio - Prego riprova più tardi.");
define("LAN_84", "News");
define("LAN_99", "Commenti");
define("LAN_100", "On");
define("LAN_307", "News presenti in questa categoria: ");

define("LAN_NEWS_1", "News solo per utenti specifici");
define("LAN_NEWS_2", "Spiacente, non sei autorizzato a leggere questa news");
//define("LAN_NEWS_3", "ATTENZIONE: Il file install.php è ancora sul server.");
//define("LAN_NEWS_4", "Non farlo rappresenta un potenziale pericolo per il tuo sito Web.");

define("LAN_NEWS_5", "<b>Errore!</b> Impossibile aggiornare la news nel database!</b>");
define("LAN_NEWS_6", "News inserita nel database.");
define("LAN_NEWS_7", "<b>Errore!</b> Impossibile inserire l'articolo!</b>");
define("LAN_NEWS_8", "News inserita per tutte le lingue. ID: ");
define("LAN_NEWS_9", "Impostato solo Titolo - <b>sarà mostrato solo il titolo della news</b><br />");
define("LAN_NEWS_10", "Questa news è <b>inattiva</b> (Non sarà visualizzata in Homepage). ");
define("LAN_NEWS_11", "Questa news è <b>attiva</b> (Sarà visualizzata in Homepage). ");
define("LAN_NEWS_12", "Commenti <b>abilitati</b>. ");
define("LAN_NEWS_13", "Commenti <b>disabilitati</b>. ");
define("LAN_NEWS_14", "<br />Periodo di attivazione: ");
define("LAN_NEWS_15", "Lunghezza testo: ");
define("LAN_NEWS_16", "b. Testo completo: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Adesso");
define("LAN_NEWS_20", "News aggiornata nelle seguenti lingue: ");
define("LAN_NEWS_21", "News aggiornata nel database.");
//define("LAN_NEWS_22", "Vai a pagina: ");
define("LAN_NEWS_23", "Categorie News");
define("LAN_NEWS_24", "crea pdf di questa news");
define("LAN_462", "Nessuna News per il mese selezionato");
?>