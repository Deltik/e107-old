<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_comment.php,v $
|     $Revision: 1.7$
|     $Date: 2005/06/30 14:18:21 $|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+*/
define("PAGE_NAME","Commenti");
define("LAN_0", "[Bloccato Amministazione]");
define("LAN_1", "Sblocca");
define("LAN_2", "Blocca");
define("LAN_3", "Cancella");
define("LAN_4", "Info");
define("LAN_5", "Commenti ...");
define("LAN_6", "Devi essere registrato per inviare commenti - fai Login oppure se non sei ancora registrato clicca");
define("LAN_7", "Amministratore Principale");
define("LAN_8", "Commento");
define("LAN_9", "Invia commento");
define("LAN_10", "Amministratore");
define("LAN_11", "Non è stato possibile inserire il tuo commento nel database - Per favore riscrivi eliminando i caratteri non-standard.");
define("LAN_16", "Nome Utente: ");
define("LAN_99","Commenti");
define("LAN_100", "News");
define("LAN_101", "Sondaggio");
define("LAN_102", "Replica a:");
define("LAN_103", "Articolo");
define("LAN_104", "Recensione");
define("LAN_105", "Contenuto");
define("LAN_145", "Registrato: ");
define("LAN_194", "Ospite");
define("LAN_195", "Utente registrato");
define("LAN_310", "Impossibile accettare il messaggio in quanto questo Nome Utente risulta già registrato - se non è il tuo Nome Utente per favore fai Login per inviare il messaggio.");
define("LAN_312", "Messaggio duplicato - Impossibile accettare.");
define("LAN_313", "Provenienza");
define("LAN_314", "modera commenti");
define("COMLAN_1", "qui");
define("COMLAN_2", "per registrarti");
define("COMLAN_3", "Errore!");
define("COMLAN_4", "Oggetto");
define("COMLAN_5", "Re:");
define("COMLAN_6", "Replica");
define("COMLAN_7", "Voto");
define("COMLAN_8", "Commenti bloccati");
define("LAN_315", "Trackbacks");
define("LAN_316", "Nessun trackbacks per questa news.");
define("LAN_317", "Modera trackbacks");
define("LAN_318", "Edita commento");
define("LAN_319", "editato");
define("LAN_320", "Aggiorna commento");
?>