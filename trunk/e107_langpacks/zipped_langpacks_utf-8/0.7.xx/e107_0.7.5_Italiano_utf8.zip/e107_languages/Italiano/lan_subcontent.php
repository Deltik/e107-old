<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_subcontent.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/09 03:32:07 $
|     $Author: chavo $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "Grazie, il tuo articolo è stato salvato e verrà sottoposto al più presto alla valutazione dell'Amministratore.");
define("ARLAN_1", "Riempi i campi vuoti.");
define("ARLAN_2", "Grazie, la tua recensione è stata salvata e verrà sottoposta al più presto alla valutazione dell'Amministratore.");
define("ARLAN_15", "Invia Articolo");
define("ARLAN_17", "Intestazione");
define("ARLAN_18", "Sottointestazione");
define("ARLAN_19", "Sommario");
define("ARLAN_20", "Articolo");
define("ARLAN_21", "Consenti commenti?");
define("ARLAN_22", "On");
define("ARLAN_23", "Off");
define("ARLAN_24", "Inserisci icone email/stampa?");
define("ARLAN_25", "Si");
define("ARLAN_26", "No");
define("ARLAN_27", "Invia Articolo");
define("ARLAN_28", "Anteprima");
define("ARLAN_55", "Visibile a");
define("ARLAN_73", "Apri Editor HTML)");
define("ARLAN_74", "Categoria");
define("ARLAN_75", "Nessuna");
define("ARLAN_82", "Dettagli Autore");
define("ARLAN_84", "Nome Autore");
define("ARLAN_85", "Indirizzo email Autore");
define("ARLAN_86", "Recensione");
define("ARLAN_87", "Valutazione");
define("ARLAN_88", "Seleziona valutazione");
define("ARLAN_89", "Invia Recensione");

define("ARLAN_90", "Campi lasciati vuoti, per favore torna indietro e verifica che tutti i campi siano compilati and confirm all fields are filled in.");
define("ARLAN_91", "Anteprima");
define("ARLAN_92", "Inserisci il tuo Nome/Indirizzo email");


define("ARLAN_93", "Articolo");
define("ARLAN_94", "Recensione");
define("ARLAN_95", "La funzione invio Articoli è al momento disabilitata");
define("ARLAN_96", "La funzione invio Recensioni è al momento disabilitata");
define("ARLAN_97", "Non hai le autorizzazioni necessarie per inviare Articoli");
define("ARLAN_98", "Non hai le autorizzazioni necessarie per inviare Recensioni");


define("ARLAN_99", "Cosa desideri inviare?");
define("ARLAN_100", "News");
define("ARLAN_101", "Evento");
define("ARLAN_102", "Articolo");
define("ARLAN_103", "Recensione");
define("ARLAN_104", "Link");
define("ARLAN_105", "Download");
define("ARLAN_106", "Invia");

?>
