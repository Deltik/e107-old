<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_equery_secure.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Stai per essere reindirizzato ad una funzione Amministratore, potrebbero verificarsi modifiche al database");
define("EQSEC_LAN2", "Conferma questa azione:");
define("EQSEC_LAN3", "Nessun referrer");
define("EQSEC_LAN4", "Azione da:");
define("EQSEC_LAN5", "Azione verso:");
define("EQSEC_LAN6", "Conferma azione");
define("EQSEC_LAN7", "Oppure cancella");
?>