<?php
/*+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Source: /cvsroot/e107/e107/e107_languages/English/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+*/
define("PAGE_NAME", "Invia News");
define("LAN_7", "Nome di Login: ");
define("LAN_62", "Titolo: ");
define("LAN_112", "Indirizzo Email: ");
define("LAN_133", "Grazie");
define("LAN_134", "La tua News è stata inoltrata e verrà sottoposta al vaglio dell'Amministratore del Sito prima di essere pubblicata.");
define("LAN_135", "Testo della News: ");
define("LAN_136", "Invia News");
define("NWSLAN_6", "Categoria");
define("NWSLAN_10", "Nessuna categoria");
define("NWSLAN_11", "Spiacenti: non hai i permessi di accesso a quest'area del sito.");
define("NWSLAN_12", "Accesso Negato.");
define("SUBNEWSLAN_1", "Devi inserire un Titolo.\\n");
define("SUBNEWSLAN_2", "Devi inserire del testo nella News.\\n");
define("SUBNEWSLAN_3", "Allegati consentiti: .jpg, .gif o .png");
define("SUBNEWSLAN_4", "Dimensioni file superiori al consentito");
define("SUBNEWSLAN_5", "File Immagine");
define("SUBNEWSLAN_6", "(jpg, gif or png)");
?>