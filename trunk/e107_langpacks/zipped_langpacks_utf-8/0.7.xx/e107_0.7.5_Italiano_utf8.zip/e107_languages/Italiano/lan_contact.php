﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/


define("LANCONTACT_01", "Dettagli Contatti");
define("LANCONTACT_02", "Modulo Contatti");
define("LANCONTACT_03", "Inserisci il tuo nome:");
define("LANCONTACT_04", "Indirizzo E-mail:");
define("LANCONTACT_05", "Soggetto del Messaggio:");
define("LANCONTACT_06", "Inserisci il tuo messaggio:");
define("LANCONTACT_07", "Inviati una copia di questo messaggio al tuo indirizzo E-mail ");
define("LANCONTACT_08", "Invia");
define("LANCONTACT_09", "Il tuo messaggio è stato inviato.");
define("LANCONTACT_10", "Ci sono problemi nell'invio del messaggio.");
define("LANCONTACT_11", "Il tuo indirizzo email sembra non essere valido.\\nVerifica e prova ancora.");
define("LANCONTACT_12", "Il messaggio è troppo corto.");
define("LANCONTACT_13", "Inserisci il soggetto."); 

?>