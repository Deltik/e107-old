<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: mrpete $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Stampa Veloce");
define("LAN_86", "Categoria:");
define("LAN_87", "da ");
define("LAN_94", "Inviato da");
define("LAN_135", "News: ");
define("LAN_303", "Questa news proviene da ");
define("LAN_304", "Titolo: ");
define("LAN_305", "Sottotitolo: ");
define("LAN_306", "Questa news proviene da ");
define("LAN_307", "Stampa questa pagina");

define("LAN_PRINT_1", "stampa friendly");
?>