<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|	Traduzione Italiana a cura di:
|   e107 italian team http://e107it.org
|
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

setlocale(LC_ALL, 'it');
define("CORE_LC", 'it');
define("CORE_LC2", 'it');
define("CHARSET", "UTF-8");
define("CORE_LAN1","Errore : Manca il tema.\\n\\nCambia il tema impostato nelle preferenze (admin area) o fai l'upload del files del tema corrente sul server.");

//v.616
define("CORE_LAN2"," \\1 scrisse:");// "\\1" represents the username.
define("CORE_LAN3","Caricamento dei Files disabiltato");

//v0.7+
define("CORE_LAN4", "Elimina install.php dal tuo server");
define("CORE_LAN5", "lasciarlo sul server costituisce una fonte di pericolo");

?>
