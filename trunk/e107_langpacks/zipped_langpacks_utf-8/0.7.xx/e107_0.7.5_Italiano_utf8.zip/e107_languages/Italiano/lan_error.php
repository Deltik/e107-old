<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Source: /cvsroot/e107/e107/e107_languages/English/lan_error.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/28 12:10:30 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Errore");
define("LAN_1", "Errore 401 - Autorizzazione negata");
define("LAN_2", "Non sei autorizzato ad accedere al link richiesto.");
define("LAN_3", "Contatta l'amministratore se ritieni che questo errore non sia valido.");
define("LAN_4", "Errore 403 - Errore di autenticazione");
define("LAN_5", "La URL richiesta richiede username e password valide. I dati inseriti sono errati o il browser non supporta la visualizzazione della pagina.");
define("LAN_6", "Contatta amministratore se ritieni che questo errore non sia valido.");
define("LAN_7", "Errore 404 - Documento non trovato");
define("LAN_9", "Contatta l'amministratore se ritieni che questo errore non sia valido.");
define("LAN_10", "Errore 500 - Malformed Header");
define("LAN_11", "Riscontrato un errore interno al server o una incompatibilità di configurazione: non è possibile soddisfare la richiesta.");
define("LAN_12", "Contatta amministratore se ritieni che questo errore non sia valido.");
define("LAN_13", "Errore sconosciuto ");
define("LAN_14", "Riscontrato un errore sul server");
define("LAN_15", "Contatta amministratore se ritieni che questo errore non sia valido.");
define("LAN_16", "Il tuo tentativo di accesso senza successo");
define("LAN_17", "è stato archiviato.");
define("LAN_18", "Sei stato riportato qui da");
define("LAN_19", "Purtroppo, il link a questo indirizzo è obsoleto.");
define("LAN_20", "Prego clicca qui per tornare alla home page");
define("LAN_ERROR_01", "La URL richiesta non può essere trovata su questo server. Il link probabilmente non è aggiornato.");
define("LAN_ERROR_02", "Prego clicca qui per andare alla Pagina di Ricerca del sito");
define("LAN_ERROR_03", "Il tuo tentativo di accesso ");
define("LAN_ERROR_04", " non ha avuto successo.");
?>