<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Questa pagina ti consente di moderare gli Utenti del sito. Puoi aggiornare le loro impostazioni,
abilitare lo status di Amministratore e, soprattutto, impostare il Gruppo Utenti di appartenenza.";

$ns -> tablerender("Help Utenti", $text);
unset($text);
?>
