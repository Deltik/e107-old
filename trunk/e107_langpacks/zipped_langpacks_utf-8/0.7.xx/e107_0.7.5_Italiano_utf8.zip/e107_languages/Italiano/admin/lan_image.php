<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_image.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/05/19 20:41:08 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("IMALAN_1", "Abilita inserimento di immagini");
define("IMALAN_2", "Visualizza immagini - questo sarà applicato a tutto il sito (commenti, chatbox etc)");
define("IMALAN_3", "Metodo di ridimensionamento");
define("IMALAN_4", "Metodo usato per ridimensionare le immagini, librerie GD1/2 o ImageMagick, etc.");
define("IMALAN_5", "Path di ImageMagick (se selezionato)");
define("IMALAN_6", "Path completo dell'utility di conversione ImageMagick (Convert utility)");
define("IMALAN_7", "Impostazioni Immagini");
define("IMALAN_8", "Aggiorna impostazioni immagini");
define("IMALAN_9", "Impostazioni immagini aggiornate");
define("IMALAN_10", "Gruppi che possono inserire immagini");
define("IMALAN_11", "Gruppo ristretto di utenti che possono inserire immagini (se abilitato sopra)");
define("IMALAN_12", "Metodo di alternativo di inserimento immagini");
define("IMALAN_13", "Cosa fare se è disabilitata l'opzione di inerimento immagini");
define("IMALAN_14", "Mostra URL immagine");
define("IMALAN_15", "Non mostrare nulla");
define("IMALAN_16", "Mostra avatars caricati");
define("IMALAN_17", "Premi qui");
define("IMALAN_18", "Immagini caricate");

define("IMALAN_21", "Usato da");
define("IMALAN_22", "Immagini non in uso");
define("IMALAN_23", "Avatar");
define("IMALAN_24", "Fotoprafia");
define("IMALAN_25", "Premi qui per eliminare le immagini non usate");
define("IMALAN_26", "immagine/i eliminate");

define("IMALAN_28", "eliminato");
define("IMALAN_29", "Nessuna immagine");
define("IMALAN_30", "Tutti (pubblico)");
define("IMALAN_31", "Solo ospiti");
define("IMALAN_32", "Solo membri");
define("IMALAN_33", "Solo amministratori");
define("IMALAN_34", "Abilita Sleight");
define("IMALAN_35", "Fissa la trasparenza delle immagini PNG-24 con alpha transparency in IE 5 / 6' (applicato in tutto il sito)");

?>
