<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Qui puoi aggiornare la tua password di Amministratore.";


$ns -> tablerender("Help Password per Admin", $text);
?>
