<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org

$text = "Questa pagina consente di impostare un messaggio che verrà visualizzato
in testa alla Pagina iniziale una volta attivato. Potrai impostare un messaggio
diversificato per Ospiti, Utenti Registrati e Amministratori.";

$ns -> tablerender("Help Messaggio di Benvenuto", $text);
?>
