﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/09/06 19:34:04 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags aggiornati nel database");
define("METLAN_2", "Inserisci meta-tags addizionali");
define("METLAN_3", "Inserisci nuove impostazioni meta tag");
define("METLAN_4", "Aggiornati");
define("METLAN_5", "scrivi qui la tua descrizione");
define("METLAN_6", "scrivi, una, lista, delle, tue, keywords, qui");
define("METLAN_7", "scrivi qui le tue informazioni sul Copyright");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "Descrizione");
define("METLAN_10", "Keywords (Parole 'chiave')");
define("METLAN_11", "Copyright");

?>
