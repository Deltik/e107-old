<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Backup delle Impostazione Core eseguito nel database.");
define("DBLAN_2", "Salvataggio backup database di e107");
define("DBLAN_3", "Backup SQL database");
define("DBLAN_4", "Verifica integrità del database di e107");
define("DBLAN_5", "Verifica");
define("DBLAN_6", "Ottimizza il database di e107");
define("DBLAN_7", "Optimizza il database SQL");
define("DBLAN_8", "Effettua il backup delle impostazioni del CORE");
define("DBLAN_9", "Backup CORE");
define("DBLAN_10", "Utilità Database");
define("DBLAN_11", "Database mySQL");
define("DBLAN_12", "ottimizzato");
define("DBLAN_13", "Indietro");
define("DBLAN_14", "Fatto");
define("DBLAN_15", "Verifica aggiornamenti del db disponibili");
define("DBLAN_16", "Verifica Aggiornamenti");
?>
