<?php
/*+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Source: /cvsroot/e107/e107/e107_languages/English/admin/lan_custommenu.php,v $
|     $Revision: 1.4 $|     $Date: 2004/09/06 09:55:17 $|     $Author: e107coders
|	Traduzione Italiana a cura di:
|   e107 italian team http://e107it.org
$+----------------------------------------------------------------------------+*/
define("CUSLAN_1", "Campi non completi.");
define("CUSLAN_2", "Impossibile creare menu personalizzato - verifica il tuo ");
define("CUSLAN_3", "la directory personalizzata è settata CHMODD 777.");
define("CUSLAN_4", "Menu/pagina personalizzata aggiornata.");
define("CUSLAN_5", "Menu personalizzato creato. Per attivarlo vai alla pagina impostazione menu.");
define("CUSLAN_6", "Impossibile aprire menu/pagina");
define("CUSLAN_7", "per lettura");
define("CUSLAN_8", "Menu esistenti");
define("CUSLAN_9", "Edita");
define("CUSLAN_10", "Nessuno");
define("CUSLAN_11", "Nome File Menu/Pagina");
define("CUSLAN_12", "Titolo Menu/Pagina");
define("CUSLAN_13", "Testo Menu/Pagina");
define("CUSLAN_14", "Nuova Anteprima");
define("CUSLAN_15", "Anteprima");
define("CUSLAN_16", "Aggiorna Menu/Pagina");
define("CUSLAN_17", "Crea Menu/Pagina");
define("CUSLAN_18", "Menu/Pagine personalizzate");
// New for .617
define("CUSLAN_19", "Pagine esistenti");
define("CUSLAN_20", "Impossibile creare pagina personalizzata - verifica il tuo ");
define("CUSLAN_21", "La directory delle pagine personalizzate è settata a CHMODD 777.");
define("CUSLAN_22", "Menu");
define("CUSLAN_23", "Pagina");
define("CUSLAN_24", "Pagina Personalizzata creata. L'URL sarà:");
define("CUSLAN_25", "Creare un link nel menu principale?");
define("CUSLAN_26", "Il Link sarà visualizzato da tutti e si aprirà nella stessa finestra !");
define("CUSLAN_27", "Hai già un link nel tuo menu principale per questa pagina o con le stesso nome...");
define("CUSLAN_28", "Link a questa pagina creato !!! Vai alla sezione Links per aggiornarne le proprietà.");
define("CUSLAN_29", "e107_plugins/custompages/");
define("CUSLAN_30", "Se richiesto edita le proprietà dei link qui ");
?>