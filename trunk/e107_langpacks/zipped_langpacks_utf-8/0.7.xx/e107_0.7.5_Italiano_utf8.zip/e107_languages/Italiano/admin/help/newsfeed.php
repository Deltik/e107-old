<?php
//     Italian Translation:
//           e107 Italian Team http://www.e107it.org
//           con la collaborazione di Stefano Vecchi

$text = "Da qui puoi recuperare e processare flussi RSS di notizie da altri siti visualizzandoli sul tuo sito.<br />Inserisci il percorso URL completo del flusso RSS (es. http://e107.org/news.xml). Puoi aggiungere il percorso dell'immagine se non ti piace quella di default o non è definita. Puoi attivare e disattivare il collegamento se il sito pubblicatore non risponde.<br /><br />Per vedere le ultime notizie, assicurati che headlines_menu sia attivato dalla tua pagina dei menu.";

$ns -> tablerender("Headlines", $text);
?>
