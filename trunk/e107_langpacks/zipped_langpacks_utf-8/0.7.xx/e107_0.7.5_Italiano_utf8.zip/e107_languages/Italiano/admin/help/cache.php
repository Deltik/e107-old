<?php
$caption = "Impostazioni Cache";
$text = "Attivando la cache migliorerai notevolmente la velocità del sito e diminuirai la somma di query al database sql.<br /><br /><b>IMPORTANTE! Se stai creando un tema personalizzato disattiva la cache poichè le modifiche da te fatte non saranno visibili.</b>";
$ns -> tablerender($caption, $text);
?>
