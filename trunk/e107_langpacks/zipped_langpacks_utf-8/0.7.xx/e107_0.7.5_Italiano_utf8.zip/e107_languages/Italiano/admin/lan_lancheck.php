<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/10 21:31:57 $
|     $Author: loloirie $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Seleziona Lingua da verificare");
define("LAN_CHECK_2", "Inizia verifica");
define("LAN_CHECK_3", "Verifica di");
define("LAN_CHECK_4", "File mancanti!");
define("LAN_CHECK_5", "Frase mancante!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "Frase");
define("LAN_CHECK_8", "Un file è mancante...");
define("LAN_CHECK_9", " files mancano...");
define("LAN_CHECK_10", "Errore Critico: ");
define("LAN_CHECK_11", "Nessun file mancante !");
define("LAN_CHECK_12", "Un file non è valido...");
define("LAN_CHECK_13", " files sono invalidi...");
define("LAN_CHECK_14", "Tutti i files sono validi !");
?>