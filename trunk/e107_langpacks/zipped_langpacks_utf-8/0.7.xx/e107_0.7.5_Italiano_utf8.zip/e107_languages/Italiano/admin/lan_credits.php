<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_credits.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/10 15:40:55 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg
+----------------------------------------------------------------------------+
*/

define("CRELAN_1", "Crediti");
define("CRELAN_2", "Lista software terze-parti/ risorse usate in e107. Il Team di sviluppo di e107 ha piacere di ringraziare personalmente gli sviluppatori dei codici seguenti che hanno contribuito alla distribuizione di e107, e per la realizzazione del loro software sotto la Licenza GPL .");
// define("CRELAN_3", "Risorsa");
// define("CRELAN_4", "Descrizione");
// define("CRELAN_5", "Sito Web");
// define("CRELAN_6", "Permessi");
define("CRELAN_7", "Versione");
?>
