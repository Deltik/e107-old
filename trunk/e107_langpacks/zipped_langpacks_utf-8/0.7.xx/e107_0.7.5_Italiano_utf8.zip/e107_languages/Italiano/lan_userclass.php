<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/05/13 01:03:35 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team ttp://www.e107it.0rg
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Tutti (pubblico)");
define("UC_LAN_1", "Ospiti");
define("UC_LAN_2", "Nessuno (inattivo)");
define("UC_LAN_3", "Utenti registrati");
define("UC_LAN_4", "Sola Lettura");
define("UC_LAN_5", "Amministratori");
?>
