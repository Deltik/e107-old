------------------------------------------------------
-------------------------------------------------------
Traduzione Italiana e107v07 a cura di e107 Team Italia
mail: info@e107it.org
-------------------------------------------------------
--------------------------------------------------------

A. INSTALLAZIONE

1) scompattare il file ZIP in una cartella del disco fisso
2) Uploadare il contenuto delle cartelle e107_languages ed e107_plugins nel Vostro sito web sovrascrivendo
i files di linguaggio esistenti. Nessun file di sistema verr� sovrascritto.


RC maggio 2006