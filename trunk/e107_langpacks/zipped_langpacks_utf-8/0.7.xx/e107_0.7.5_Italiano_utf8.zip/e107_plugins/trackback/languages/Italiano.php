<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/22 18:20:52 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("TRACKBACK_L1", "Configura Trackback");
define("TRACKBACK_L2", "Questo plugin ti permette di usare il trackback nelle tue news.");
define("TRACKBACK_L3", "Trackback è intallato e abilitato.");
define("TRACKBACK_L4", "Settaggio Trackback Salvato.");
define("TRACKBACK_L5", "On");
define("TRACKBACK_L6", "Off");
define("TRACKBACK_L7", "Attiva trackback");
define("TRACKBACK_L8", "Trackback URL text");
define("TRACKBACK_L9", "Salva Impostazioni");
define("TRACKBACK_L10", "Impostazioni Trackback");
define("TRACKBACK_L11", "Indirizzo Trackback per questo messaggio:");

define("TRACKBACK_L12", "Nessun trackbacks per questo oggetto");
define("TRACKBACK_L13", "Modera trackbacks");
define("TRACKBACK_L14", "Elimina");
define("TRACKBACK_L15", "Trackbacks Eliminato.");

?>