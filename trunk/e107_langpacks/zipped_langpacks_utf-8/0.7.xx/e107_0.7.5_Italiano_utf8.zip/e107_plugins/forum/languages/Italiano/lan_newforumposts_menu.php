<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_newforumposts_menu.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/14 20:43:58 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Tutti gli ultimi messaggi non possono essere letti dal gruppo utenti al quale appartieni, impossibile visualizzare i messaggi.");
define("NFP_2", "Ancora nessun messaggio");
define("NFP_3", "Menù di configurazione dei Nuovi Messaggi Forum salvato");
define("NFP_4", "Titolo");
define("NFP_5", "Numero di messaggi da visualizzare?");
define("NFP_6", "Numero di caratteri da visulizzare?");
define("NFP_7", "Suffisso per messaggi troppo lunghi?");
define("NFP_8", "Mostra i topics originali nel menù?");
define("NFP_9", "Aggiorna impostazioni");
define("NFP_10", "Menù di configurazione Nuovi Messaggi Forum");
define("NFP_11", "Inviato da: ");

?>
