<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_admin.php,v $
|     $Revision: 1.18 $
|     $Date: 2006/01/15 19:07:41 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("FORLAN_1", "Numero di giorni in cui effettuare la pulizia.");
define("FORLAN_2", "Seleziona se vuoi eliminare i messaggi da pulire, o renderli inattivi (non eliminati ma non visibili nel forum)");
define("FORLAN_3", "Elimina");
define("FORLAN_4", "Rendi inarrivi");
define("FORLAN_5", "Pulisci");
define("FORLAN_6", "Cancella");
define("FORLAN_7", "Opzioni Forum");
define("FORLAN_8", "Pulizia Effettuata");
define("FORLAN_9", "Pulizia non richiesta");
define("FORLAN_10", "Opzioni salvate");
define("FORLAN_11", "Forum Creato");
define("FORLAN_12", "Forum aggiornato");
define("FORLAN_13", "Categoria principale creata");
define("FORLAN_14", "Forum principale aggiornato");
define("FORLAN_15", "Spunta il box di conferma per eliminare il forum");
define("FORLAN_16", "Forums");
define("FORLAN_17", "Ancora nessuna categoria principale");
define("FORLAN_18", "Categoria Principale Esistente");
define("FORLAN_19", "Modifica");
define("FORLAN_20", "Elimina");
define("FORLAN_21", "Spunta per confermare");
define("FORLAN_22", "Categoria Principale");
define("FORLAN_23", "Visibile da");
define("FORLAN_24", "Imposta chi può visualizzare il forum");
define("FORLAN_25", "Aggiorna Categoria Principale");
define("FORLAN_26", "Crea Categoria Principale");
define("FORLAN_27", "Devi definire un forum principale prima di poter creare un forum.");
define("FORLAN_28", "Forums");
define("FORLAN_29", "Ancora nessun forum.");
define("FORLAN_30", "Forum esistente");
define("FORLAN_31", "Nome");
define("FORLAN_32", "Descrizione");
define("FORLAN_33", "Moderatori");
define("FORLAN_34", "Seleziona un gruppo di utenti per moderare questo forum");
define("FORLAN_35", "Aggiorna Forum");
define("FORLAN_36", "Crea Forum");
define("FORLAN_37", "Ordinamento");
define("FORLAN_38", "Chiuso");
define("FORLAN_39", "Solo Utenti Registrati");
define("FORLAN_40", "Riservato");
define("FORLAN_41", "Muovi su");
define("FORLAN_42", "Muovi giu");
define("FORLAN_43", "Anteprima / Ordinamento Forum");
define("FORLAN_44", "Includi Tabelle");
define("FORLAN_45", "Spunta questa opzione per visualizzare il forum con le tabelle del tema");
define("FORLAN_46", "Titolo da mostrare nell'intestazione se Includi Tabelle è spuntato");
define("FORLAN_47", "Permetti notifica via mail");
define("FORLAN_48", "Spunta questa opzione per permettere agli utenti di ricevere una email quando qualcuno risponde ai loro messaggi");
define("FORLAN_49", "Abilita sondaggi");
define("FORLAN_50", "Spunta questa opzione per abilitare gli utenti ad impostare sonadggi nel forum - il plugin dei Sondaggi deve essere installato per poter usare questa opzione");
define("FORLAN_51", "Abilita 'Traccia'");
define("FORLAN_52", "Spunta questa opzione per permettere agli utenti di 'tracciare' le discussioni e di ricevere una email in caso di risposta");
define("FORLAN_53", "Prefisso Email");
define("FORLAN_54", "Il testo inserito sarà usato come soggetto di ogni email inviata attraverso il forum");
define("FORLAN_55", "Soglia per il messaggio 'In evidenza'");
define("FORLAN_56", "Numero minimo di messaggi che rendono una discussione 'In evidenza'");
define("FORLAN_57", "Messaggi per pagina");
define("FORLAN_58", "Numero di messaggi visualizzati per pagina");
define("FORLAN_59", "Pulizia");
define("FORLAN_60", "Questo eliminerà tutte le discussioni che non hanno ricevuto una risposta in un numero di giorni stabilito. <br /><b>Funzione da usare con cautela!</b>");
define("FORLAN_61", "Aggiorna Opzioni");
define("FORLAN_62", "Opzioni Forum");
define("FORLAN_63", "Livelli Utenti");
define("FORLAN_64", "Inserisci qui i livelli personalizzati, se lasciato in bianco una stella generica segnalerà i livelli. Separare i lvelli con una virgola. Massimo 10 livelli, il più basso prima.");
define("FORLAN_65", "Titolo Forum");

define("FORLAN_70", "Abilita allegati file / immagini ");
define("FORLAN_71", "Permetti agli utenti di caricare file o immagini nei loro messaggi,");
define("FORLAN_72", "Aggiorna Ordinamento");
define("FORLAN_73", "Ordinamento Aggiornato");

define("FORLAN_75", "Categorie Principali");
define("FORLAN_76", "Pagina Principale Forums");
define("FORLAN_77", "Crea Forum");
define("FORLAN_78", "Ordinamento Forum");
define("FORLAN_79", "Preferenze");
define("FORLAN_80", "Opzioni");
define("FORLAN_81", "Sei sicuro di voler elimare questa categoria principale? - i forum contenuti verranno eliminati");
define("FORLAN_82", "Sei sicuro di voler eliminare il forum?");
define("FORLAN_83", "Crea Categoria Principale");
define("FORLAN_84", "Solo Utenti Registrati");
define("FORLAN_85", "Sola Lettura");
define("FORLAN_86", "Solo Amministratori");
define("FORLAN_87", "Pulizia delle discussioni senza risposta in questo numero di giorni:");

define("FORLAN_88", "Pulizia delle discussioni senza risposta in questo numero di giorni:");

define("FORLAN_89", "Elimina Messaggi completamente");
define("FORLAN_90", "Rendi i messaggi inattivi");

define("FORLAN_91", "messaggio/i resi inattivi");
define("FORLAN_92", "discussione/i eliminate");
define("FORLAN_93", "risposta/e elimiante");

define("FORLAN_94", "Imposta livelli");
define("FORLAN_95", "Livelli salvati");
define("FORLAN_96", "Forum eliminato");
define("FORLAN_97", "Categoria primaria eliminata");

define("FORLAN_98", "Nome del livello");
define("FORLAN_99", "numero di messaggi prima del cambiamento");
define("FORLAN_100", "carica le immagini in e107_themes/Your_Theme/forum/");
define("FORLAN_101", "Amministratore Principale");
define("FORLAN_102", "Soglia");
define("FORLAN_103", "Amministratore Sito");
define("FORLAN_104", "Immagine del Livello");
define("FORLAN_105", "Moderatore Forum");


define("FORLAN_106", "Tipo di Pulizia:");
define("FORLAN_107", "Forum");
define("FORLAN_108", " eliminato");
define("FORLAN_109", "giorni:");
define("FORLAN_110", "Pulizia");
define("FORLAN_111", "disattivato");

define("FORLAN_112", "Abilita Reindirizzamento");
define("FORLAN_113", "Spunta questa opzione per essere reindirizzato alla pagina del forum dopo una risposta");
define("FORLAN_114", "Titolo personalizzato Utenti");
define("FORLAN_115", "Spunta questa opzione per permettere agli utenti di cambiare il loro titolo personalizzato");
define("FORLAN_116", "Messaggi Segnalati");
define("FORLAN_117", "Cancellerà i record dei messaggi segnalati. Non i messaggi stessi.");
define("FORLAN_118", "Messaggi segnalati eliminati");
// define("FORLAN_119", "Clicking links will open forum in a new window.");
define("FORLAN_120", "Spunta questa opzione per permettere agli utenti di cambiare il loro titolo personalizzato");
define("FORLAN_121", "Nessun messaggio segnalato");
define("FORLAN_122", "Premi qui per inviare una mail all'Amministratore quando qualcuno segnala un messaggio");
define("FORLAN_123", "Regolamento del forum");
define("WMGLAN_1", "Regole per Ospiti");
define("WMGLAN_2", "Regole per Utenti Registrati");
define("WMGLAN_3", "Regole per Amministratori");
define("WMGLAN_4", "Invia");
define("WMGLAN_5", "Imposta le regole");
define("WMGLAN_6", "Attivare?");
define("FORLAN_124", "Links in una nuova finestra");
define("FORLAN_125", "Spunta questa opzione per far aprire tutti i links in una nuova finestra (<i>sarà applicato a tutto il sito</i>). ");
define("FORLAN_126", "Mostra Tooltips");
define("FORLAN_127", "Spunta questa opzione per mostrare un tooltip contenente il primo messaggio della discussione al passaggio del mouse sul titolo della discussione. ");
define("FORLAN_128", "Lunghezza del tooltip");
define("FORLAN_129", "Numero di caratteri da visualizzare nel tooltip. ");
define("FORLAN_130", "premi qui");
define("FORLAN_131", "Imposta la massima dimensione dei file, estensioni permesse etc");
define("FORLAN_132", "Enfatizza Discussioni Fissate");
define("FORLAN_133", "Da enfasi extra alle discussioni fissate (sezione messaggi e intestazioni diverse)");
define("FORLAN_134", "Massima larghezza delle immagini da caricare");
define("FORLAN_135", "Lasciare bianco per disabilitare l'auto-ridimensionamento delle immagini");
define("FORLAN_136", "Crea un link all'immmagine intera");
define("FORLAN_137", "Se si abilita questa opzione un'immagine di grandi dimesioni verrà ridimensionata e verrà contemporaneamente creato un link all'immagine originale.  Se disabilitito, l'immagine originale non sarà caricata");
define("FORLAN_138", "Pulisci questi forum");
define("FORLAN_139", "Per usare questa opzopne devi impostare 'Abilita Inserisci Immagine' nell'amministrazione <a href='".e_ADMIN."image.php'>immagini</a>");
define("FORLAN_140", "Mostra");
define("FORLAN_141", "Messaggi");
define("FORLAN_142", "Permessi messaggi");
define("FORLAN_143", "Indica chi può scrivere messaggi nel forum");
define("FORLAN_144", "Imposta Moderatori");
define("FORLAN_145", "Configura sub-forums");
define("FORLAN_146", "Ancora nessun sub-forums");
define("FORLAN_147", "Aggiorna sub-forum");
define("FORLAN_148", "Crea sub-forum");
define("FORLAN_149", "sub-forums");
define("FORLAN_150", "sub-forum");
define("FORLAN_151", "ID");
define("FORLAN_152", "messaggi");
define("FORLAN_153", "Utilità");
define("FORLAN_154", "Risposta eliminata");
define("FORLAN_155", "Categorie Forum");

define("FORLAN_156", "Seleziona uno o più forum su cui eseguire l'operazione");
define("FORLAN_157", "Tutti i Forum");
define("FORLAN_158", "Ricalcola le informazioni sugli ultimi messaggi del forum");
define("FORLAN_159", "Seleziona per ricalcolare le informazioni sugli ultimi messaggi del forum");
define("FORLAN_160", "Seleziona per esguire l'oprazione solo sui forums, non sulle discussioni");
define("FORLAN_161", "Ricalcola il numero dei messaggi / risposte");
define("FORLAN_162", "Seleziona per ricalcolare il numero dei messaggi/rispote del forum");
define("FORLAN_163", "Ricalcola il numero dei messaggi degli utenti");
define("FORLAN_164", "Seleziona per ricalcolare il numero dei messaggi degli utenti");
define("FORLAN_165", "Esegui funzione");
define("FORLAN_166", "Utilità Forum");
define("FORLAN_167", "Numeri aggiornati per forum");
define("FORLAN_168", "Informazioni ultimi messaggi aggiornate per forum");
define("FORLAN_169", "Numeri utenti aggiornati");
define("FORLAN_170", "Segnalazioni");
define("FORLAN_171", "Segnalazioni sui messaggi del forum");
define("FORLAN_172", "Elimina questa segnalazione");
define("FORLAN_173", "Titolo Discussione");
define("FORLAN_174", "Segnalato dall'utente");
define("FORLAN_175", "Segnalazione Inviata");
define("FORLAN_176", "Segnalazione");

define("FORLAN_177", "notifica email ON di default");
define("FORLAN_178", "spunta per abilitare il checkbox della notifica email su ON per default");
define("FORLAN_179", "(Aggiungere un * all'inizio del nome del forum  significa fare in modo che il forum contenga SOLO subforums.  Il tema del forum deve supportare questa funzione!)");

define("FORLAN_180", "Conferma l'operazione di elimina");
define("FORLAN_181", "Conferma Elimina");
?>
