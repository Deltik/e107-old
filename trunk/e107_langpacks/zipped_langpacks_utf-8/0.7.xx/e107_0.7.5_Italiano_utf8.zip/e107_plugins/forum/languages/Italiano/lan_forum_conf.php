<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_conf.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:52:49 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/

define("FORLAN_5", "Sondaggio Eliminato.");
define("FORLAN_6", "Discussione Eliminata");
define("FORLAN_7", "Risposta eliminata");
define("FORLAN_8", "Elimina cancellazione.");
define("FORLAN_9", "Discussione spostata.");
define("FORLAN_10", "Elimina Muovi.");
define("FORLAN_11", "Torna al forum");
define("FORLAN_12", "Configurazione Forum");
define("FORLAN_13", "Sei assolutamente certo di voler eliminare il sondaggio?<br />Una volta eliminato <b><u>NON POTRAI</u></b> recuperarlo.");
define("FORLAN_14", "Cancella");
define("FORLAN_15", "Conferma eliminazione messaggi");
define("FORLAN_16", "Conferma eliminazione sondaggio");
define("FORLAN_17", "inviato da");
define("FORLAN_18", "Sei assolutamente sicuro di voler eliminare questo forum");
define("FORLAN_19", "discussione con i relativi messaggi?");
define("FORLAN_20", "il sondaggio verrà anch'esso eliminato");
define("FORLAN_21", "Una volta eliminati");
define("FORLAN_22", "messaggio?<br />Una volta eliminato");
define("FORLAN_23", "non potrà essere</u></b> recuperato");
define("FORLAN_24", "Muovi la discussione al forum");
define("FORLAN_25", "Muovi discussione");
define("FORLAN_26", "Risposta eliminata");
	
define("FORLAN_27", "Spostato");

define("FORLAN_28", "Non rinominare il titolo della Discussione");
define("FORLAN_29", "Aggiungi");
define("FORLAN_30", "al titolo");
define("FORLAN_31", "Rinomina in:");
define("FORLAN_32", "Rinomina le opzioni della Discussione:");

	
?>
