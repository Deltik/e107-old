<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org

define("CM_SCH_LAN_1", "Calendario");

?>