<?php

// Italian Translation: e107 Italian Team http://www.e107it.org
define("LWLAN_1", "Campo/i richiesti non compliati");
define("LWLAN_2", "Link word salvata.");
define("LWLAN_3", "Link word aggiornata.");
define("LWLAN_4", "Ancora nessuna link words definita.");
define("LWLAN_5", "Parola");
define("LWLAN_6", "Link");
define("LWLAN_7", "Attivi?");
define("LWLAN_8", "Opzioni");
define("LWLAN_9", "Sì");
define("LWLAN_10", "No");
define("LWLAN_11", "Linkwords esistente");
define("LWLAN_12", "Sì");
define("LWLAN_13", "No");
define("LWLAN_14", "Invia LinkWord");
define("LWLAN_15", "Aggiorna LinkWord");
define("LWLAN_16", "Edita");
define("LWLAN_17", "Elimina");
define("LWLAN_18", "Sei sicuro di volere eliminare questa linkword?");
define("LWLAN_19", "Linkword eliminata.");
define("LWLAN_20", "Impossibile trovare la linkword inserita.");
define("LWLAN_21","Word da auto-linkare");
define("LWLAN_22","Attivi?");

define("LWLANINS_1", "Linkwords");
define("LWLANINS_2", "Questo plugin ti permette di associare determinate parole ad un link");
define("LWLANINS_3", "Configura LinkWords");
define("LWLANINS_4", "Per configurare click sul link Gestione Plugins");

?>