<?php
define("LDAPLAN_1", "Indirizzo Server");
define("LDAPLAN_2", "Base DN o Dominio<br />Se LDAP - Inserisci BaseDN<br />Se AD - Inserisci dominio");
define("LDAPLAN_3", "LDAP Browsing user<br />Full context dell'utene abilitato alla ricerca delle cartelle.");
define("LDAPLAN_4", "LDAP Browsing password<br />Password per LDAP Browsing user.");
define("LDAPLAN_5", "Versione LDAP");
define("LDAPLAN_6", "Configura LDAP auth");
?>
