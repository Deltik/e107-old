<?php
define("CB_SCH_LAN_1", "Chatbox");
?>
