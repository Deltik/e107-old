<?php
define("NWSF_FP_1", "Ressources d'".GLOBAL_LAN_NEWS_2."s");
define("NWSF_FP_2", "Page principale");
?>
