<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/French/lan_forum_search.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/04 21:35:16 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Sélectionner un forum");
define("FOR_SCH_LAN_3", "Tous les forums");
define("FOR_SCH_LAN_4", "Message entier");
define("FOR_SCH_LAN_5", "En tant que partie d'un message");
?>
