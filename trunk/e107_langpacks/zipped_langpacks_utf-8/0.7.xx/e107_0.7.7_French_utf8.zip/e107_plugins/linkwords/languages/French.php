<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/French.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:36:13 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LWLAN_1", "Champ(s) resté(s) en blanc.");
define("LWLAN_2", "Mot-Lien sauvegardé.");
define("LWLAN_3", "Mot-Lien mis à jour.");
define("LWLAN_4", "Aucun Mot-Lien défini pour l'instant.");
define("LWLAN_5", "Mot");
define("LWLAN_6", "Lien");
define("LWLAN_7", "Activer?");
define("LWLAN_8", "Options");
define("LWLAN_9", "oui");
define("LWLAN_10", "non");
define("LWLAN_11", "Mot-Lien Existants");
define("LWLAN_12", "Oui");
define("LWLAN_13", "Non");
define("LWLAN_14", "Soumettre le Mot-Lien");
define("LWLAN_15", "Mettre à jour le Mot-Lien");
define("LWLAN_16", "Éditer");
define("LWLAN_17", "Supprimer");
define("LWLAN_18", "Êtes vous sûr de vouloir supprimer ce Mot-Lien?");
define("LWLAN_19", "Mot-Lien supprimé.");
define("LWLAN_20", "Impossible de trouver l'entrée de ce Mot-Lien.");
define("LWLAN_21", "Mots comme lien automatique");
define("LWLAN_22", "Activer?");
define("LWLANINS_1", "Mots-Lien");
define("LWLANINS_2", "Cette extension vous permet d'associer dans vos pages des hyperliens à des mots spécifiques");
define("LWLANINS_3", "Configurer LinkWords");
define("LWLANINS_4", "Pour configurer, veuillez cliquer sur le lien dans la section des extensions de la zone admin");


?>