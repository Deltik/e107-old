<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_menu/languages/French.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/12/04 21:37:38 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("ONLINE_L1", "Visiteurs: ");
define("ONLINE_L2", "Utilisateurs: ");
define("ONLINE_L3", "Sur cette page: ");
define("ONLINE_L4", "En ligne");
define("ONLINE_L5", "Utilisateurs");
define("ONLINE_L6", "Le plus récent");
define("TRACKING_MESSAGE", "Le traçeur d'utilisateur en ligne est en ce moment désactivé, activez le <a href='".e_ADMIN."user.php?options'>ici</a><br />");
?>
