<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/French/lan_content_search.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:34:35 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Contenus");
define("CONT_SCH_LAN_2", "Toutes les catégories de contenu ");
define("CONT_SCH_LAN_3", "Publié en réponse à un contenu");
define("CONT_SCH_LAN_4", "dans");
?>
