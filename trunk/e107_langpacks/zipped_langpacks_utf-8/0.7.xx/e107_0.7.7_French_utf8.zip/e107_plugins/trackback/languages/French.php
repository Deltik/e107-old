<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/trackback/languages/French.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:44:28 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("TRACKBACK_L1", "Configurer les Trackbacks");
define("TRACKBACK_L2", "Cette extension vous permet d'utiliser le trackback dans les ".GLOBAL_LAN_NEWS_1."s publiées.");
define("TRACKBACK_L3", "Trackback est maintenant installé et activé.");
define("TRACKBACK_L4", "Paramètres des trackbacks  sauvegardés.");
define("TRACKBACK_L5", "Activer");
define("TRACKBACK_L6", "Désactiver");
define("TRACKBACK_L7", "Activer les trackbacks");
define("TRACKBACK_L8", "Texte URL dans le trackback");
define("TRACKBACK_L9", "Sauvegarder les paramètres");
define("TRACKBACK_L10", "Paramètres des trackback");
define("TRACKBACK_L11", "Adresse de trackback pour ce message:");
define("TRACKBACK_L12", "Pas de trackback pour cette ".GLOBAL_LAN_NEWS_1."");
define("TRACKBACK_L13", "Modérer les trackbacks");
define("TRACKBACK_L14", "Supprimer");
define("TRACKBACK_L15", "Trackback supprimé.");
?>
