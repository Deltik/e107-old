<?php
/*
define("LAN_THEME_0","<br /><i>NewsRoom Thème de CaMer0n v1.0 </i>");//"THEME_DISCLAIMER"
define("LAN_THEME_1","Ce thème affiche quelques une des ".GLOBAL_LAN_NEWS_1."s fonctionnalités de 0.7<br />
  Pour avoir les meilleurs résultats, créer les ".GLOBAL_LAN_NEWS_1."s avec des vignettes de 65x50 pixels.
  <br />Pour placer ces occurences tout en en haut dans la section de droite, choisissez 'othernews2' pour ce type d'".GLOBAL_LAN_NEWS_1."s.
  <br />'othernews' peut être utiliser pour de simples puces pour les menus listes.
  <br />Ce theme peut-être utiliser librement sous licence GPL quand l&#39image 'e107 newsroom'est replacée.
  ");//$themeinfo
define("LAN_THEME_5", "Posté par ");//{NEWSAUTHOR}
define("LAN_THEME_6", "le ");//{NEWSDATE}
*/
define("LAN_THEME_1", "Commentaires");
define("LAN_THEME_2", "Commentaires désactivés");
define("LAN_THEME_3", "HISTOIRE COMPLÈTE");
define("LAN_THEME_4", "Posté le");
?>
