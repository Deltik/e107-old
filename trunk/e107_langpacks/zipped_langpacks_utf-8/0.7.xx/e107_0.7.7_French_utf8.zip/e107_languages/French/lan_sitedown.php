<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_sitedown.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Site temporairement fermé");
define("LAN_SITEDOWN_00", "est temporairement fermé");
define("LAN_SITEDOWN_01", "Nous avons fermé temporairement le site pour cause de maintenance. Cela ne devrait pas être trop long. Veuillez revenir bientôt, et nous excuser pour la gène occasionnée.");
?>
