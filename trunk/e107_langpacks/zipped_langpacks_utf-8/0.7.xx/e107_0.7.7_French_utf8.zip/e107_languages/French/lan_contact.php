<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_contact.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/12/04 21:32:25 $
|     $Author: daddycool78 $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Détails de contact");
define("LANCONTACT_02", "Formulaire de contact");
define("LANCONTACT_03", "Entrez votre nom:");
define("LANCONTACT_04", "Adresse électronique:");
define("LANCONTACT_05", "Sujet:");
define("LANCONTACT_06", "Votre message:");
define("LANCONTACT_07", "Recevoir une copie du courriel ");
define("LANCONTACT_08", "Envoyer");
define("LANCONTACT_09", "Message envoyé.");
define("LANCONTACT_10", "Erreur, votre message n'a pas pu nous parvenir.");
define("LANCONTACT_11", "Votre adresse électronique ne semble pas valide.\\nVeuillez la vérifier et recommencer.");
define("LANCONTACT_12", "Votre message est trop court.");
define("LANCONTACT_13", "Veuillez inclure un sujet.");
define("LANCONTACT_14", "Envoyer le message à :");
define("LANCONTACT_15", "Le code entré est incorrect");
define("LANCONTACT_16", "Copiez le Code");

?>
