<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_comment.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/12/04 21:32:25 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("COMLAN_0", "[bloqué par un admin]");
define("COMLAN_1", "Débloquer");
define("COMLAN_2", "Bloquer");
define("COMLAN_3", "Supprimer");
define("COMLAN_4", "Infos");
define("COMLAN_5", "Commentaires ...");
define("COMLAN_6", "Vous devez être identifié pour poster un commentaire sur ce site - merci de vous identifier ou de vous enregistrer en cliquant");
define("COMLAN_7", "Admin principal");
define("COMLAN_8", "Commentaire");
define("COMLAN_9", "Envoyer le commentaire");
define("COMLAN_10", "Administrateur");
define("COMLAN_11", "Impossible d'enregistrer votre commentaire dans la base de données - merci de retaper votre commentaire en supprimant les caractères spéciaux.");
define("COMLAN_16", "Nom : ");
define("COMLAN_99", "Commentaires");
define("COMLAN_100", "".GLOBAL_LAN_NEWS_2."");
define("COMLAN_101", "Sondages");
define("COMLAN_102", "Réponse à : ");
define("COMLAN_103", "Article");
define("COMLAN_104", "Chronique");
define("COMLAN_105", "Contenu");
define("COMLAN_145", "Enregistré : ");
define("COMLAN_194", "Visiteur");
define("COMLAN_195", "Utilisateur enregistré");
define("COMLAN_310", "Impossible d'accepter ce commentaire car cet identifiant existe déjà - si c'est votre identifiant, merci de vous enregistrer pour poster.");
define("COMLAN_312", "Message dupliqué - impossible d'accepter.");
define("COMLAN_313", "Emplacement");
define("COMLAN_314", "Modérer les commentaires");
define("COMLAN_315", "Références externes à votre contenu (Trackbacks)");
define("COMLAN_316", "Pas de références externes à votre contenu (Trackback) pour cet apport d'".GLOBAL_LAN_NEWS_1.".");
define("COMLAN_317", "Modérer les références externes à votre contenu (Trackbacks)");
define("COMLAN_318", "Éditer le commentaire");
define("COMLAN_319", "édité");
define("COMLAN_320", "Mise à jour du commentaire");
define("COMLAN_321", "ici");
define("COMLAN_322", "pour vous inscrire.");
define("COMLAN_323", "Erreur!");
define("COMLAN_324", "Sujet");
define("COMLAN_325", "Re:");
define("COMLAN_326", "Répondre à ceci");
define("COMLAN_327", "Évaluation");
define("COMLAN_328", "Les commentaires sont verrouillés");
define("COMLAN_329", "Non-autorisé");
define("COMLAN_330", "IP:");

define("COMLAN_TYPE_1", "".GLOBAL_LAN_NEWS_1."");
define("COMLAN_TYPE_2", "téléchargements");
define("COMLAN_TYPE_3", "faq");
define("COMLAN_TYPE_4", "sondage");
define("COMLAN_TYPE_5", "docs");
define("COMLAN_TYPE_6", "traceur de bugs");
define("COMLAN_TYPE_7", "idées");
define("COMLAN_TYPE_8", "profil utilisateur");
?>
