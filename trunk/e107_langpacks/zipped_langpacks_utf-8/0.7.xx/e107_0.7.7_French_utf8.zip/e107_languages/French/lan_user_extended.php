<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_user_extended.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("UE_LAN_1", "Boite de texte");
define("UE_LAN_2", "Boutons radio");
define("UE_LAN_3", "Liste déroulante");
define("UE_LAN_4", "Champ d'une table MySQL");
define("UE_LAN_5", "Zone étendue de texte");
define("UE_LAN_6", "Nombre entier");
define("UE_LAN_7", "Date");
define("UE_LAN_8", "Langage");
define("UE_LAN_9", "Nom");
define("UE_LAN_10", "Type");
define("UE_LAN_11", "Utilise");
define("UE_LAN_HIDE", "Cacher aux utilisateurs");
define("UE_LAN_LOCATION", "Résidence");
define("UE_LAN_LOCATION_DESC", "Résidence de l'utilisateur");
define("UE_LAN_AIM", "AIM");
define("UE_LAN_AIM_DESC", "Adresse AIM");
define("UE_LAN_ICQ", "ICQ");
define("UE_LAN_ICQ_DESC", "Numéro ICQ");
define("UE_LAN_YAHOO", "Yahoo!");
define("UE_LAN_YAHOO_DESC", "Adresse Yahoo!");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "Adresse MSN");
define("UE_LAN_HOMEPAGE", "Votre site Web");
define("UE_LAN_HOMEPAGE_DESC", "URL du site web de l'utilisateur");
define("UE_LAN_BIRTHDAY", "Date de naissance");
define("UE_LAN_BIRTHDAY_DESC", "Date de Naissance");
define("UE_LAN_LANGUAGE", "Langage");
define("UE_LAN_LANGUAGE_DESC", "Langage de l'utilisateur");
define("UE_LAN_COUNTRY", "Pays");
define("UE_LAN_COUNTRY_DESC", "Pays de l'utilisateur (inclus la table de BdD)");
?>
