<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_mail_handler.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LANMAILH_1", "Produit par le système de sites web e107");
define("LANMAILH_2", "Ceci est un message multivolets au format MIME."); //??? à débattre
define("LANMAILH_3", " n'est pas correctement formaté");
define("LANMAILH_4", "Le serveur a rejeté l'adresse");
define("LANMAILH_5", "Aucune réponse depuis le serveur");
define("LANMAILH_6", "Ne peut pas trouver le serveur de courrier électronique.");
define("LANMAILH_7", " semble être valide.");
?>
