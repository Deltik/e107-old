<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_user_select.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("US_LAN_1", "Sélectionner un utilisateur");
define("US_LAN_2", "Sélectionner un groupe d'utilisateur");
define("US_LAN_3", "Tous les utilisateurs");
define("US_LAN_4", "Trouver un utilisateur");
define("US_LAN_5", "Utilisateurs(s) trouvé(s)");
define("US_LAN_6", "Recherche");
?>
