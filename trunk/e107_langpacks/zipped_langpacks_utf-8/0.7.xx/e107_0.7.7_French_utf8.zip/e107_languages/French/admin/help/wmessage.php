<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/wmessage.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/12/04 21:32:31 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Cette page vous permet de rédiger un message de bienvenue, ou un message informatif qui se placera en haut de votre page d'accueil.
Le message peut être différent pour les visiteurs, les utilisateurs et les administrateurs.";
$ns -> tablerender("Aide du Message d'accueil", $text);
?>