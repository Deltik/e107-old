<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/users_extended.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:32:31 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Les champs étendus de profil vous permettent d'ajouter des compléments d'informations que les utilisateurs peuvent préciser dans leur profil.";
$ns -> tablerender(" Aide des profil étendus", $text);
?>
