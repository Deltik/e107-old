<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/content.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$caption = "Gestion de contenu";
$text = "Vous pouvez ajouter une simple page à votre site en utilisant cette fonctionnalité. Un lien vers la nouvelle page sera créé dans le menu principal. Par exemple, si vous créez une nouvelle page avec le nom 'Test', un lien appelé 'Test' apparaitra dans la liste des liens.<br />
Si vous voulez que votre page ait une barre de titre, entrez le titre dans le champ 'Titre de la page'.";
$ns -> tablerender($caption, $text);
?>
