<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_banlist.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/12/04 21:32:32 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("BANLAN_1", "Bannissement supprimé.");
define("BANLAN_2", "Aucun bannissement.");
define("BANLAN_3", "Liste des bannissements");
define("BANLAN_4", "Supprimer le bannissement");
define("BANLAN_5", "Entrer une adresse IP/courriel ou un nom de domaine");
define("BANLAN_6", "Bannir par adresse électronique"); 
define("BANLAN_7", "Raison");
define("BANLAN_8", "Bannir l&#39;utilisateur");
define("BANLAN_9", "Bannir les utilisateurs du site");
define("BANLAN_10", "IP - Courriel - Domaine / Raison");
define("BANLAN_11", "Bannissement automatique: Plus de 10 essais de connexions infructueuses");
define("BANLAN_12", "Note : Reverse DNS est actuellement désactivé, il doit être activé pour permettre le bannissement selon l'hébergeur. Bannir selon l'IP ou le courriel fonctionnera tout de même normalement.");
?>
