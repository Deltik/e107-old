<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_notify.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:32:32 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("NT_LAN_1", "Alertes");
define("NT_LAN_2", "Recevoir un courriel d'alerte en cas de ");
define("NT_LAN_3", "Désactivé");
define("NT_LAN_4", "Admin principal");
define("NT_LAN_5", "Groupe");
define("NT_LAN_6", "Courriel");
  
define("NU_LAN_1", "Événements Utilisateur ");
define("NU_LAN_2", "Inscription d'un utilisateur ");
define("NU_LAN_3", "Validation d'un compte d'utilisateur");
define("NU_LAN_4", "Connexion d'un utilisateur");
define("NU_LAN_5", "Déconnexion d'un utilisateur");
  
define("NS_LAN_1", "Événements de Sécurité");
define("NS_LAN_2", "IP bannie pour flood du site");
  
define("NN_LAN_1", "Événements des ".GLOBAL_LAN_NEWS_2."s");
define("NN_LAN_2", "".GLOBAL_LAN_NEWS_2." proposée par un utilisateur");
define("NN_LAN_3", "".GLOBAL_LAN_NEWS_2." postée par un admin");
define("NN_LAN_4", "".GLOBAL_LAN_NEWS_2." éditée par un admin");
define("NN_LAN_5", "".GLOBAL_LAN_NEWS_2." supprimée par un admin");
define("NF_LAN_1", "Événements des fichiers");
define("NF_LAN_2", "Fichier uploadé par un utilisateur");
?>
