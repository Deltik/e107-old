<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/mailout.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/04 21:32:31 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Utiliser cette page pour configurer vos paramètres courriel pour des fontions d'envois massif de courrier. Le fomulaire d'envoi de courriel vous permet également de faire un envoi groupé de courrier à tous vos utilisateurs.";
$ns -> tablerender("Aide Courrier massif", $text);
?>
