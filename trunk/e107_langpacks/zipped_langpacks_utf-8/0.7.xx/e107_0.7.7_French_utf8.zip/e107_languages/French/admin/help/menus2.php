<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/menus2.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/04 21:32:31 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text .= "Vous pouvez choisir où et dans quel ordre seront affichés vos menus par rapport aux autres. Utilisez les flêches pour déplacer les menus vers le haut ou vers le bas jusqu';à que vous soyez satisfait de leur placement.<br />Les menus au milieu de la page sont désactivés, vous pouvez les activer en choisissant l'endroit où les mettre.";
$ns -> tablerender(Aide, $text);
?>
