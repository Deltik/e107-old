<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_submitnews.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Proposer une ".GLOBAL_LAN_NEWS_1."");
define("LAN_7", "Identifiez-vous: ");
define("LAN_62", "Sujet: ");
define("LAN_112", "Adresse courriel: ");
define("LAN_133", "Merci");
define("LAN_134", "Votre ".GLOBAL_LAN_NEWS_1." a bien été enregistrée et sera examinée par un administrateur prochainement.");
define("LAN_135", "Corps du texte: ");
define("LAN_136", "Proposer une ".GLOBAL_LAN_NEWS_1."");
define("NWSLAN_6", "Catégorie");
define("NWSLAN_10", "Aucune catégorie d'".GLOBAL_LAN_NEWS_1."");
define("NWSLAN_11", "Vous n'avez pas accès à cette page.");
define("NWSLAN_12", "Accès refusé.");
define("SUBNEWSLAN_1", "Vous devez inclure un titre.\\n");
define("SUBNEWSLAN_2", "Vous devez inclure un texte dans le corps de l'".GLOBAL_LAN_NEWS_2.".\\n");
define("SUBNEWSLAN_3", "Votre fichier joint doit être en jpg, gif ou png");
define("SUBNEWSLAN_4", "Votre fichier est trop volumineux");
define("SUBNEWSLAN_5", "Fichier image");
define("SUBNEWSLAN_6", "(jpg, gif ou png)");
?>
