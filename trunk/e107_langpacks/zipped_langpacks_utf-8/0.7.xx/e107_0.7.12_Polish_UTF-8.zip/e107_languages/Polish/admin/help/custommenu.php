<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:05 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/custommenu.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/custommenu.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Z poziomu tej strony możesz utworzyć własne menu oraz własne strony wraz z ich zawartością.<br /><br />
Więcej możesz przeczytać na stronie <a href='http://e107.org/e107_plugins/docs/docs.php?133'>Używanie narzędzia Własne menu oraz własne strony (po angielsku)</a>.";

$ns -> tablerender(CUSLAN_18, $text);

?>
