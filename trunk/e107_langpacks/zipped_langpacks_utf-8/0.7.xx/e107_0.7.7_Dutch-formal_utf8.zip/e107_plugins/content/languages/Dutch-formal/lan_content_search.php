<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Dutch-formal/lan_content_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/09/25 13:37:59 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Content");
define("CONT_SCH_LAN_2", "Alle contentcategorieën");
define("CONT_SCH_LAN_3", "Geplaatst als reactie op onderwerp");
define("CONT_SCH_LAN_4", "in");
?>