<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_forum_conf.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 10th Sep 2004
+---------------------------------------------------------------+
*/

define("FORLAN_5", "Peiling verwijderd.");
define("FORLAN_6", "Discussie verwijderd");
define("FORLAN_7", "reacties verwijderd");
define("FORLAN_8", "Verwijdering geannuleerd.");
define("FORLAN_9", "Discussie verplaatst.");
define("FORLAN_10", "Verplaatsing geannuleerd.");
define("FORLAN_11", "Terug naar forums");
define("FORLAN_12", "Forum configuratie");
define("FORLAN_13", "Weet u zeker dat u deze peiling wilt verwijderen?&lt;br /&gt;Eenmaal verwijderd, is terughalen &lt;b&gt;&lt;u&gt;niet meer&lt;/u&gt;&lt;/b&gt; mogelijk.");
define("FORLAN_14", "Annuleren");
define("FORLAN_15", "Bevestig verwijderen forumbericht");
define("FORLAN_16", "Bevestig verwijderen peiling");
define("FORLAN_17", "geplaatst door");
define("FORLAN_18", "Weet u zeker dat u deze forumdiscussie");
define("FORLAN_19", " en de bijbehorende reacties wilt verwijderen ?");
define("FORLAN_20", "de peiling wordt ook verwijderd");
define("FORLAN_21", "Eenmaal verwijderd kunnen ze");
define("FORLAN_22", " bericht?&lt;br /&gt;Eenmaal verwijderd kan het ");
define("FORLAN_23", "niet&lt;/u&gt;&lt;/b&gt; worden teruggehaald");
define("FORLAN_24", "Verplaats de discussie naar forum");
define("FORLAN_25", "Verplaats discussie");
define("FORLAN_26", "Reactie verwijderd");
define("FORLAN_27", "verplaatst");
define("FORLAN_28", "Deze discussie niet hernoemen");
define("FORLAN_29", "Toevoegen");
define("FORLAN_30", "aan titel");
define("FORLAN_31", "Hernoemen als:");
define("FORLAN_32", "Hernoemen discussie opties:");


?>