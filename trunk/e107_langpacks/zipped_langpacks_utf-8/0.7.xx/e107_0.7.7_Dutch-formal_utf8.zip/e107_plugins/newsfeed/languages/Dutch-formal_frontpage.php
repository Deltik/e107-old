<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsfeed/languages/Dutch-formal_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/18 16:57:43 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "News Feeds");
define("NWSF_FP_2", "hoofdpagina");

?>