<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Banner");
define("BANNER_MENU_L2", "Banner menu configuratie opgeslagen");
define("BANNER_MENU_L3", "Titelbalk");
define("BANNER_MENU_L4", "Campagne");
define("BANNER_MENU_L5", "Banner menu configuratie");
define("BANNER_MENU_L6", "kies de in het menu te tonen campagnes");
define("BANNER_MENU_L7", "beschikbare campagnes");
define("BANNER_MENU_L8", "geselecteerde campagnes");
define("BANNER_MENU_L9", "verwijder selectie");
define("BANNER_MENU_L10", "hoe moeten de geselecteerde campagnes worden getoond ?");
define("BANNER_MENU_L11", "kies render type ...");
define("BANNER_MENU_L12", "een campagne in een enkelvoudig menu");
define("BANNER_MENU_L13", "alle geselecteerde campagnes in een enkelvoudig menu");
define("BANNER_MENU_L14", "alle geselecteerde campagnes in afzonderlijke menu");
define("BANNER_MENU_L15", "hoeveel banners moeten worden getoond ?");
define("BANNER_MENU_L16", "deze instelling geldt alleen bij optie 2 en 3.<br />als er minder banners aanwezig zijn wordt het maximale aantal gebruikt.");
define("BANNER_MENU_L17", "instellen aantal ...");
define("BANNER_MENU_L18", "Bijwerken menu instellingen");
?>