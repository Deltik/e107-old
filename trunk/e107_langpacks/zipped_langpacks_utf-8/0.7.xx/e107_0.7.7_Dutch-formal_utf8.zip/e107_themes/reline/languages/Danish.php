<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_themes/reline/languages/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2006/05/15 13:49:22 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Kommentarer er slået fra på dette emne");
define("LAN_THEME_2", "Læs/Skriv Kommentar: ");
define("LAN_THEME_3", "Læs resten...");
define("LAN_THEME_4", "Trackbacks: ");
define("LAN_THEME_5", "Skrevet af");
define("LAN_THEME_6", "d");
define("LAN_THEME_7", "Søg...");


?>