<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch-formal/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/16 15:18:02 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "stem");
define("RATELAN_1", "stemmen");
define("RATELAN_2", "hoe beoordeelt u dit onderwerp?");
define("RATELAN_3", "bedankt voor uw stem");
define("RATELAN_4", "niet beoordeeld");
define("RATELAN_5", "Waardering");
?>