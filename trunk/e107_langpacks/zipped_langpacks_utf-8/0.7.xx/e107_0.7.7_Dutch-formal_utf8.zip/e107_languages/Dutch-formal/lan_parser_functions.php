<?php

define("LAN_GUEST", "Gast");
define("LAN_WROTE", "schreef"); // as in John wrote.."  ";
?>