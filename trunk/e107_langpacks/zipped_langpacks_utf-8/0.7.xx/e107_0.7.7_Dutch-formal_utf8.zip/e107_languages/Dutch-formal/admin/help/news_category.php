<?php

if (!defined('e107_INIT')) { exit; }

$text = "U kunt nieuwsberichten in verschillende categorieën onderverdelen en u kunt bezoekers berichten per categorie laten zien. <br /><br />Upload uw nieuwspictogrammen naar ofwel ".e_THEME."-uwthema-/images/ of themes/shared/newsicons/.";
$ns -> tablerender("Nieuws categorie Hulp", $text);
?>