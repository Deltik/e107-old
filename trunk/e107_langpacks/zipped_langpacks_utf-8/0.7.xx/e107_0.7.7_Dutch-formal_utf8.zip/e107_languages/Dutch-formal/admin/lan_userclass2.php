<?php

define("UCSLAN_1", "Alle leden verwijderd uit de klasse.");
define("UCSLAN_2", "Leden in de klasse bijgewerkt.");
define("UCSLAN_3", "Klasse verwijderd.");
define("UCSLAN_4", "aankruisen om het verwijderen van de ledenklasse te bevestigen");
define("UCSLAN_5", "Klasse bijgewerkt.");
define("UCSLAN_6", "Klasse opgeslagen in de database.");
define("UCSLAN_7", "Nog geen ledenklassen.");
define("UCSLAN_8", "Aanwezige klassen");
define("UCSLAN_11", "aankruisen om te bevestigen");
define("UCSLAN_12", "Naam klasse");
define("UCSLAN_13", "Beschrijving klasse");
define("UCSLAN_14", "Bijwerken ledenklasse");
define("UCSLAN_15", "Opvoeren nieuwe ledenklasse");
define("UCSLAN_16", "Wijs leden toe aan de klasse");
define("UCSLAN_17", "Verwijderen");
define("UCSLAN_18", "Klasse opschonen");
define("UCSLAN_19", "Wijs leden toe aan");
define("UCSLAN_20", "klasse");
define("UCSLAN_21", "Ledenklasse instellingen");
define("UCSLAN_22", "Leden - klik om te verplaatsen ...");
define("UCSLAN_23", "Leden in deze klasse ...");
define("UCSLAN_24", "Wie kan de klasse beheren");
?>