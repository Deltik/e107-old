<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch-formal/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/08/01 13:35:41 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Beheerlog");
define("LAN_ADMINLOG_1", "Datum");
define("LAN_ADMINLOG_2", "Titel");
define("LAN_ADMINLOG_3", "Omschrijving");
define("LAN_ADMINLOG_4", "Gebruikers IP");
define("LAN_ADMINLOG_5", "Gebruikers ID");
define("LAN_ADMINLOG_6", "Informatief pictogram");
define("LAN_ADMINLOG_7", "Informatie melding");
define("LAN_ADMINLOG_8", "Meldingspictogram");
define("LAN_ADMINLOG_9", "Melding");
define("LAN_ADMINLOG_10", "Waarschuwingspictogram");
define("LAN_ADMINLOG_11", "Waarschuwingsmelding");
define("LAN_ADMINLOG_12", "Fatale fout pictogram");
define("LAN_ADMINLOG_13", "Fatale fout boodschap");

?>