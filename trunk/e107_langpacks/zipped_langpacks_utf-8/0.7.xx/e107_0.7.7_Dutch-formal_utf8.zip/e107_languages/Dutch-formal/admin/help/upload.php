<?php

if (!defined('e107_INIT')) { exit; }

$text = "Met deze functie kunt u gebruikers al dan niet toestaan om bestanden te uploaden naar uw site en kunt u de geuploade bestanden ook beheren.";
$ns -> tablerender("Openbare Uploads hulp", $text);
?>