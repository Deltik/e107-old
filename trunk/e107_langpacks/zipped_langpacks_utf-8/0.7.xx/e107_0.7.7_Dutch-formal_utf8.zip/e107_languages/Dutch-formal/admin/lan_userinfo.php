<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_userinfo.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 10th Sep 2004
+---------------------------------------------------------------+
*/

define("USFLAN_1", "Kan het IP adres van de deelnemer niet vinden - er is geen informatie beschikbaar.");
define("USFLAN_3", "Berichten afkomstig van dit IP adres");
define("USFLAN_4", "Systeem");
define("USFLAN_5", "Klik hier om dit IP adres naar de blokkade pagina over te zetten");
define("USFLAN_6", "UserID");
define("USFLAN_7", "Gebruikersinformatie");

?>