<?php

if (!defined('e107_INIT')) { exit; }

$text = "De thema manager laat u zowel het thema van uw gepubliceerde site, als het eventueel afwijkende thema van uw beheerscherm instellen.";
$ns -> tablerender("Thema Manager hulp", $text);
?>