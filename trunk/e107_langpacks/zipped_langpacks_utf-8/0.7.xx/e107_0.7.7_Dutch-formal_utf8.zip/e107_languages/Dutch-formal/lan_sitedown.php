<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        lan_sitedown.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 14th Sep 2004
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Site is tijdelijk gesloten");
define("LAN_SITEDOWN_00", "is tijdelijk gesloten");
define("LAN_SITEDOWN_01", "We hebben deze site tijdelijk gesloten om het nodige onderhoud uit te kunnen voeren. Dit zal niet lang duren, dus komt u binnenkort terug. Onze excuses voor het ongemak!");

?>

