<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/11/19 17:06:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/online_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/online_menu/languages/English.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("ONLINE_L1", "Gości: ");
define("ONLINE_L2", "Użytkowników: ");
define("ONLINE_L3", "Na tej stronie: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Użytkowników");
define("ONLINE_L6", "Najnowszy");
define("TRACKING_MESSAGE", "Śledzenie użytkowników online jest obecnie wyłączone. Proszę odblokować tę opcję <a href='".e_ADMIN."users.php?options'>tutaj</a><br />");

?>
