<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:37:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_forum.php rev. 1.7
+-----------------------------------------------------------------------------+
*/
 
define("e_PAGETITLE", "Forum");

define("LAN_30", "Witaj");
define("LAN_31", "Od czasu Twojej ostatniej wizyty na forum nie zamieszczono nowych"); //Obecnie na forum nie ma nowych wypowiedzi
define("LAN_32", "Od czasu Twojej ostatniej wizyty na forum jest jedna nowa ");
define("LAN_33", "Od czasu Twojej ostatniej wizyty na forum jest ");
define("LAN_34", "nowych");
define("LAN_35", " wypowiedzi.");
define("LAN_36", "Ostatnio odwiedziłeś nasze forum dnia: ");
define("LAN_37", "Dzisiaj jest: ");
define("LAN_38", ", wszystkie czasy są ");
define("LAN_41", "Najnowszy użytkownik: ");
define("LAN_42", "Zarejestrowanych: ");
define("LAN_44", "Na forum mogą się wypowiadać niezarejestrowani użytkownicy, lecz proszę być świadomym tego, że adres IP z jakiego opublikujesz swoją wypowiedź zostanie zapisany do wglądu dla moderatorów.<br />Aby uzyskać dostęp do wszystkich funkcji tego forum musisz się");
define("LAN_45", "Na forum mogą się wypowiadać tylko zarejestrowani użytkownicy, jeśli posiadasz już swoje konto <a href='".e_BASE."login.php'>zaloguj się</a>, w przeciwnym wypadku dokonaj rejestracji");
define("LAN_46", "Forum");
define("LAN_47", "Tematy");
define("LAN_48", "Posty");
define("LAN_49", "Ostatni post");
define("LAN_51", "W tej chwili nie ma jeszcze żadnych dyskusji. Zapraszamy wkrótce.");
define("LAN_52", "Obecnie w tym dziale nie ma jeszcze żadnych tematów. Zapraszamy wkrótce.");
define("LAN_79", "Nowe posty");
define("LAN_80", "Brak nowych postów");
define("LAN_81", "Temat zamknięty");
define("LAN_100", "artykuły"); //articles
define("LAN_180", "Szukaj");
define("LAN_191", "Informacje");
define("LAN_192", "Użytkownicy tego forum opublikowali łącznie ");
define("LAN_196", "Przeczytałeś już ");
define("LAN_197", " wypowiedzi.");
define("LAN_198", " Wszystkie nowe wypowiedzi zostały przeczytane.");
define("LAN_199", "Oznacz wszystkie wypowiedzi jako przeczytane");
define("LAN_204", "<b>Możesz</b> rozpoczynać nowe tematy");
define("LAN_205", "<b>Nie możesz</b> rozpoczynać nowych tematów");
define("LAN_206", "<b>Możesz</b> odpowiadać w tematach");
define("LAN_207", "<b>Nie możesz</b> odpowiadać w tematach");
define("LAN_208", "<b>Możesz</b> redagować swoje posty");
define("LAN_209", "<b>Nie możesz</b> redagować swoich postów");
define("LAN_392", "Zakończ śledzenie tematu");
define("LAN_393", "Wykaz śledzonych tematów");
define("LAN_394", "Forum zamknięte");
define("LAN_397", "Śledzone tematy");
define("LAN_398", "Zamknięty");
define("LAN_399", "Dostęp ograniczony");
define("LAN_400", "Wskazane forum może być tylko przeglądane przez zarejestrowanych użytkowników");
define("LAN_401", "Strefa tylko dla zarejestrowanych");

define("LAN_402", "Obecnie to forum jest przeznaczone tylko do odczytu");
	
define("LAN_403", "Nie ma jeszcze postów");
define("LAN_404", "wypowiedzi");
define("LAN_405", "Tylko do odczytu");
	
define("LAN_406", "Forum tylko dla administratorów");
define("LAN_407", "Forum tylko dla zarejestrowanych użytkowników");
define("LAN_408", "Forum tylko do odczytu");
define("LAN_409", "Forum tylko dla grupy");
define("LAN_410", "Witaj gościu");
	
define("LAN_411", "tematy");
define("LAN_412", "post");
define("LAN_413", "tematów");
define("LAN_414", "posty(ów)");
define("LAN_415", "użytkownik aktualnie przegląda to forum");
define("LAN_416", "użytkowników aktualnie przegląda to forum");
	
define("LAN_417", "zarejestrowany");
define("LAN_418", "gość");
define("LAN_419", "zarejestrowanych");
define("LAN_420", "gości");
	
define("LAN_421", "Pokaż nowe posty");
define("LAN_422", "Nowe posty od Twojej ostatniej wizyty");
define("LAN_423", "Autor");
define("LAN_424", "Nowe tematy");
define("LAN_425", "Odp:");
	
//v.616
define("LAN_426", "Aktualnie na forum są online: ");
define("LAN_427", "Wyświetl szczegółowy spis.");
define("LAN_428", "Odp:");
define("LAN_429", "Lista Top : Najbardziej aktywni");
define("LAN_430", "Lista Top : Najchętniej czytane");
define("LAN_431", "Moje posty");
define("LAN_432", "Moje ustawienia");
define("LAN_433", "Regulamin forum");
define("LAN_434", "Powrót do forum");
define("LAN_435", "Mój profil");
define("LAN_436", " (Zostanie wyświetlony w nowym oknie.)");

define("LAN_437", "zarejestrować");
define("LAN_438", ", jeśli natomiast posiadasz już swoje konto <a href='".e_BASE."login.php'>zaloguj się</a>.");
define("LAN_439", "tutaj");
define("LAN_440", "w celu uzyskania pełnego dostępu do strony.");

define("LAN_441", "Statystyki forum");
	
define('FORLAN_441', 'Aktualnie nie ma zdefiniowanych reguł.');
define('FORLAN_442', 'Mój upload');
define('FORLAN_443', '[użytkownik usunięty]');
define('FORLAN_444', 'Subfora');

?>
