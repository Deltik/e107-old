<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/22 18:26:10 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/online_extended_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/online_extended_menu/languages/English.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("ONLINE_EL1", "Gości: ");
define("ONLINE_EL2", "Użytkowników: ");
define("ONLINE_EL3", "Na tej stronie: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Użytkowników");
define("ONLINE_EL6", "Najnowszy");
define("ONLINE_EL7", "przegląda");

define("ONLINE_EL8", "Najwięcej online: ");
define("ONLINE_EL9", "dnia");

define("TRACKING_MESSAGE", "Śledzenie użytkowników online jest obecnie wyłączone, proszę odblokować tą opcję <a href='".e_ADMIN."users.php?options'>tutaj</a></span><br />");

?>
