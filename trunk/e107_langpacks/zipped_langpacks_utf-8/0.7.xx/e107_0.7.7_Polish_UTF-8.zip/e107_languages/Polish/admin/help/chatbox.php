<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:05 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/chatbox.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/chatbox.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie możesz ustawić preferencje dla czata..<br />Jeśli zaznaczysz pole <i>Zastąp linki</i>, każdy wpisany link będzie zastąpiony przez tekst, który wpiszesz w pole tekstowe obok zaznaczonego pola - Ta opcja rozwiązuje problem z wyświetlaniem długich linków.<br />Opcja <i>Zawijanie wyrazów</i> będzie zwijać tekst dłuższy niż zdefiniowanej tutaj długości.";

$ns -> tablerender("Czat", $text);

?>
