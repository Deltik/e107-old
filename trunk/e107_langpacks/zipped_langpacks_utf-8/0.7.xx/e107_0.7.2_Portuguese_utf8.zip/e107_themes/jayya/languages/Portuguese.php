<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2001/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "Este item tem os comentários desactivados");
define("LAN_THEME_2", "Ler/Comentar: ");
define("LAN_THEME_3", "Ler mais...");
define("LAN_THEME_4", "Referências: ");
define("LAN_THEME_5", "Escrito por");
define("LAN_THEME_6", "em");


?>
