<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'khatru' por <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Este item tem os comentários desactivados");
define("LAN_THEME_3", "Comentários: ");
define("LAN_THEME_4", "Ler mais...");
define("LAN_THEME_5", "Referências: ");

?>
