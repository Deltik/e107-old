<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'CraHan' por <a href='http://e107.org' rel='external'>jalist</a>, baseado no tema por CraHan na sua página <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Este item tem os comentários desactivados");
define("LAN_THEME_3", "Comentários: ");
define("LAN_THEME_4", "Ler mais...");
define("LAN_THEME_5", "Referências: ");
define("LAN_THEME_6", "Comentário de");

?>
