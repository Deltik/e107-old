<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'interfectus' por <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Ler/Comentar: ");
define("LAN_THEME_3", "Este item tem os comentários desactivados");
define("LAN_THEME_4", "Ler mais...");
define("LAN_THEME_5", "Referências: ");

?>
