+-------------------------------------------------------------------------------+
|     e107 website system - PORTUGUESE (Portugal) Language Files
|
|     Revision: 1.0
|     Release Date: 2006-02-22
|     Author: X-fact0r <xfact0r.pt@gmail.com>
+-------------------------------------------------------------------------------+


# DESCRIPTION #
This archive contains the .utf files in Portuguese for the e107 v0.7.2 system. This translation was based on the original English files for the same release and contains:
- e107_docs
- e107_handlers
- e107_languages\Portuguese
- e107_plugins
- e107_themes
(224 files)

# INSTRUCTIONS #
In order to use this language in your website you have to upload all files (keeping the original file/dir structure) into your server - e107 installation directory.

# DISCLAIMER #
This files are supplied as found in the original distribution archive. You are allowed to update/change them in you personal e107 installation.
The author will not be held responsible for any errors or DB damage in you e107 system due to the incorrect installation / use of this language files.

# FEEDBACK #
The files have been extensively tested on a live e107 system, but it is possible that some typos were missed - mixed letters or lack of translation on some line/expression...
If you detect any of these errors and wish to inform the author, please send an email to <xfact0r.pt@gmail.com> with the following information:
- page where the error was detected;
- wrong word/expression;

# HISTORY #
v1.0 [2006-02-22] => First official release for the PT translation .utf (v0.7.2).


[EOF]