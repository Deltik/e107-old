<?php
/*
+----------------------------------------------------------------------------+
|     PHPMailer language file - PT version.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/27 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'Necessita fornecer pelo menos ' . 'endereço de destino.';
$PHPMAILER_LANG["mailer_not_supported"] = ' o mailer não é suportado.';
$PHPMAILER_LANG["execute"] = 'Não foi possivel executar: ';
$PHPMAILER_LANG["instantiate"] = 'Não foi possivel inicializar a função de mail.';
$PHPMAILER_LANG["authenticate"] = 'Erro SMTP: Naõ foi possivel efectuar a autenticação.';
$PHPMAILER_LANG["from_failed"] = 'O seguinte endereço de remetente (From) falhou: ';
$PHPMAILER_LANG["recipients_failed"] = 'Erro SMTP: Os seguintes ' . 'endereços de destino falharam: ';
$PHPMAILER_LANG["data_not_accepted"] = 'Erro SMTP: Os dados não foram aceites.';
$PHPMAILER_LANG["connect_host"] = 'Erro SMTP: Não foi possivel efectuar a ligação ao servidor SMTP.';
$PHPMAILER_LANG["file_access"] = 'Não foi possivel aceder ao ficheiro: ';
$PHPMAILER_LANG["file_open"] = 'Erro de ficheiro: Não foi possivel abrir: ';
$PHPMAILER_LANG["encoding"] = 'Codificação desconhecida: ';
?>