// PT lang variables by X-fact0r (2006/01/27)

tinyMCE.addToLang('flash',{
title : 'Inserir/Editar arquivo Flash',
desc : 'Inserir/Editar arquivo Flash',
file : 'Arquivo Flash (.swf)',
size : 'Tamanho',
list : 'Lista de arquivos Flash',
props : 'Propriedades do Flash',
general : 'Geral'
});
