// PT lang variables by X-fact0r (2006/01/27)

tinyMCELang['lang_insert_emotions_title'] = 'Inserir emoção';
tinyMCELang['lang_emotions_desc'] = 'Emoções';

