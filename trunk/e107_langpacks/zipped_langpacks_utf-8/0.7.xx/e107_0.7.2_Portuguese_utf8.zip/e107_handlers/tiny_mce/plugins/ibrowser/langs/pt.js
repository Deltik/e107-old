// PT lang variables by X-fact0r (2006/01/27)

tinyMCELang['lang_ibrowser_title'] = 'Inserir/Editar Imagem';
tinyMCELang['lang_ibrowser_desc'] = 'Inserir/Editar Imagem';
tinyMCELang['lang_ibrowser_library'] = 'Livraria';
tinyMCELang['lang_ibrowser_preview'] = 'Prever';
tinyMCELang['lang_ibrowser_img_sel'] = 'Selecção de imagem';
tinyMCELang['lang_ibrowser_img_info'] = 'Informação da imagem';
tinyMCELang['lang_ibrowser_img_upload'] = 'Upload de imagem';
tinyMCELang['lang_ibrowser_images'] = 'Imagens';
tinyMCELang['lang_ibrowser_src'] = 'Origem';
tinyMCELang['lang_ibrowser_alt'] = 'Descrição';
tinyMCELang['lang_ibrowser_size'] = 'Tamanho';
tinyMCELang['lang_ibrowser_align'] = 'Disposição do texto';
tinyMCELang['lang_ibrowser_height'] = 'Altura';
tinyMCELang['lang_ibrowser_width'] = 'Largura';
tinyMCELang['lang_ibrowser_reset'] = 'Eliminar dimensões';
tinyMCELang['lang_ibrowser_border'] = 'Contorno';
tinyMCELang['lang_ibrowser_hspace'] = 'Esp.horiz';
tinyMCELang['lang_ibrowser_vspace'] = 'Esp.vert';
tinyMCELang['lang_ibrowser_select'] = 'Gravar';
tinyMCELang['lang_ibrowser_delete'] = 'Apagar';
tinyMCELang['lang_ibrowser_cancel'] = 'Cancelar';
tinyMCELang['lang_ibrowser_uploadtxt'] = 'Ficheiro';
tinyMCELang['lang_ibrowser_uploadbt'] = 'Upload';
// error messages
tinyMCELang['lang_ibrowser_error'] = 'Erro';
tinyMCELang['lang_ibrowser_errornoimg'] = 'Por favor seleccione uma imagem';
tinyMCELang['lang_ibrowser_errornodir'] = 'A livraria não existe';
tinyMCELang['lang_ibrowser_errorupload'] = 'Foi encontrado um erro durante a transferência do ficheiro.\nPor favor volte a tentar mais tarde';
tinyMCELang['lang_ibrowser_errortype'] = 'Formato inválido de imagem';
tinyMCELang['lang_ibrowser_errordelete'] = 'A remoção falhou';
tinyMCELang['lang_ibrowser_confirmdelete'] = 'Clique OK para apagar a imagem!';
tinyMCELang['lang_ibrowser_error_width_nan'] = 'Tem que introduzir um número na Largura!';
tinyMCELang['lang_ibrowser_error_height_nan'] = 'Tem que introduzir um número na Altura!';
tinyMCELang['lang_ibrowser_error_border_nan'] = 'Tem que introduzir um número no Contorno!';
tinyMCELang['lang_ibrowser_error_hspace_nan'] = 'Tem que introduzir um número no Espaçamento Horizontal!';
tinyMCELang['lang_ibrowser_error_vspace_nan'] = 'Tem que introduzir um número no Espaçamento Vertical!';