// PT lang variables by X-fact0r (2006/01/27)

tinyMCE.addToLang('',{
iespell_desc : 'Executar verificação ortográfica',
iespell_download : "O verificador ieSpell não foi detectado. Clique OK para ir à página de download."
});
