<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CM_L1", "Aínda não existem comentários.");
define("CM_L2", "");
define("CM_L3", "Título");
define("CM_L4", "Número de comentários mostrados?");
define("CM_L5", "Número de caracteres mostrados?");
define("CM_L6", "Sufixo para comentários longos?");
define("CM_L7", "Mostrar título original?");
define("CM_L8", "Definições do menu");
define("CM_L9", "Actualizar definições do menu");
define("CM_L10", "Definições gravadas");
	
?>