<?php/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/15 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LDAPLAN_1", "Endereço do servidor");define("LDAPLAN_2", "Base DN ou domínio<br />Se LDAP - Insira BaseDN<br />Se AD - Insira domínio");define("LDAPLAN_3", "Utilizador LDAP para navegação<br />Contexto completo do utilizador autorizado a pesquisar a directoria.");define("LDAPLAN_4", "Password LDAP para navegação<br />Password para a navegação LDAP do utilizador.");define("LDAPLAN_5", "Versão LDAP");define("LDAPLAN_6", "Configurarar autorização LDAP");
?>
