<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("BANNER_MENU_L1", "Anúncio");
define("BANNER_MENU_L2", "A configuração do menu de anúncios foi gravada");
	
//v.617
define("BANNER_MENU_L3", "Título");
define("BANNER_MENU_L4", "Campanha");
define("BANNER_MENU_L5", "Configuração do menu de anúncios");
define("BANNER_MENU_L6", "Escolha as campanhas a mostrar no menu");
define("BANNER_MENU_L7", "Campanhas disponiveis");
define("BANNER_MENU_L8", "Campanhas seleccionadas");
define("BANNER_MENU_L9", "Remover selecção");
define("BANNER_MENU_L10", "De que forma serão mostradas as campanhas seleccionadas?");
define("BANNER_MENU_L11", "Escolha a forma de visualização...");
define("BANNER_MENU_L12", "Uma campanha num único menu");
define("BANNER_MENU_L13", "Todas as campanhas seleccionadas num único menu");
define("BANNER_MENU_L14", "Todas as campanhas seleccionadas em menus separados");
define("BANNER_MENU_L15", "Quantos anúncios deverão ser mostrados?");
define("BANNER_MENU_L16", "Este parâmtero só deve ser usado com as opções 2 e 3.<br />Se existirem menos anúncios então será usada a quantidade máxima disponivel.");
define("BANNER_MENU_L17", "Definir quantidade...");
define("BANNER_MENU_L18", "Actualizar definições do menu");
	
?>