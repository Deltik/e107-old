<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/03 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Tópico");
define("NFPM_LAN_2", "Iniciado por"); //Poster
define("NFPM_LAN_3", "Visualizações");
define("NFPM_LAN_4", "Respostas");
define("NFPM_LAN_5", "Última mensagem");
define("NFPM_LAN_6", "Tópicos");
define("NFPM_LAN_7", "por");
	
define("NFPM_L1", "Este plugin permite mostrar a lista das novas mensagens do fórum na sua página principal");
define("NFPM_L2", "Últimas mensagens no fórum");
define("NFPM_L3", "Para configurar esta secção devera clicar no link da secção de plugins na página principal de administração");
define("NFPM_L4", "Activar em que área?");
define("NFPM_L5", "Inactivo");
define("NFPM_L6", "Início da página");
define("NFPM_L7", "Final da página");
define("NFPM_L8", "Título");
define("NFPM_L9", "Número de novas mensagens mostradas?");
define("NFPM_L10", "Mostrar dentro de uma janela de scroll?");
define("NFPM_L11", "Altura da janela");
define("NFPM_L12", "Configuração de mensagens novas no fórum");
define("NFPM_L13", "Actualizar definições");
define("NFPM_L14", "Definições actualizadas.");
define("NFPM_L15", "Seleccionar para mostrar as útlimas mensagens no fórum.<br />Por defeito são mostrados os últimos tópicos.");
define('NFPM_L16', '[Utilizador apagado]');

?>