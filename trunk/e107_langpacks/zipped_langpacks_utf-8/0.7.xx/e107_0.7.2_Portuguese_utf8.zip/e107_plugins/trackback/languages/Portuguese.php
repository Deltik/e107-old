<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("TRACKBACK_L1", "Configurar Referências");
define("TRACKBACK_L2", "Este plugin permite-lhe utilizar referências nas suas notícias (links de outros sites que referenciaram a sua notícia).");
define("TRACKBACK_L3", "As referências foram instaladas e estão activadas.");
define("TRACKBACK_L4", "Definições de referências gravadas.");
define("TRACKBACK_L5", "Ligado");
define("TRACKBACK_L6", "Desligado");
define("TRACKBACK_L7", "Activar referência");
define("TRACKBACK_L8", "Texto do URL da referência"); //Trackback URL text
define("TRACKBACK_L9", "Gravar definições");
define("TRACKBACK_L10", "Definições de referências");
define("TRACKBACK_L11", "Endereço de referência para esta mensagem:");

define("TRACKBACK_L12", "Não existem referências para este item");
define("TRACKBACK_L13", "Moderar referências");
define("TRACKBACK_L14", "Apagar");
define("TRACKBACK_L15", "Referências apagadas.");

?>