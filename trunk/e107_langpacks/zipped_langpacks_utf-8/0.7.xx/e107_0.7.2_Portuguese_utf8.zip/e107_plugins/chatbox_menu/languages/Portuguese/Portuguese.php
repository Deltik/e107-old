<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CHATBOX_L1", "Não foi possivel aceitar a sua mensagem uma vez que esse nome de utilizador já está registado - se é o seu deverá efectuar o login para poder enviar a mensagem.");
define("CHATBOX_L2", "Chatbox");
define("CHATBOX_L3", "Necessita estar ligado para poder submeter comentários neste site - por favor efectue o login ou se aínda não tem o seu registo poderá efectuá-lo <a href='".e_BASE."signup.php'>aqui</a>.");
define("CHATBOX_L4", "Submeter");
define("CHATBOX_L5", "Limpar");
define("CHATBOX_L6", "[bloqueado pelo admin]");
define("CHATBOX_L7", "Desbloquear");
define("CHATBOX_L8", "Informação");
define("CHATBOX_L9", "Bloquear");
define("CHATBOX_L10", "Apagar");
define("CHATBOX_L11", "Ainda não existem mensagens.");
define("CHATBOX_L12", "Ver todas as mensagens");
define("CHATBOX_L13", "Moderar chatbox");
define("CHATBOX_L14", "Emoções");
define("CHATBOX_L15", "Mensagem muito longa ou vazia");
define("CHATBOX_L16", "Anónimo");
define("CHATBOX_L17", "Mensagem duplicada");
define("CHATBOX_L18", "Chatbox messages moderated");
define("CHATBOX_L19", "Só pode enviar uma mensagem em cada ".FLOODTIMEOUT." segundos");

define("CHATBOX_L20", "Chatbox (todas as mensagens)");
define("CHATBOX_L21", "Mensagens Chat");
define("CHATBOX_L22", "em");
define("CHATBOX_L23", "Erro!");
define("CHATBOX_L24", "Não tem as permissões correctas para aceder a esta página.");
define("CHATBOX_L25", "[esta mensagem foi bloqueada pelo admin]");

// Notify
define("NT_LAN_CB_1", "Eventos da Chatbox");
define("NT_LAN_CB_2", "Mensagem enviada");
define("NT_LAN_CB_3", "Enviada por");
define("NT_LAN_CB_4", "Endereço IP");
define("NT_LAN_CB_5", "Mensagem");
define("NT_LAN_CB_6", "Mensagem de Chatbox enviada");

?>