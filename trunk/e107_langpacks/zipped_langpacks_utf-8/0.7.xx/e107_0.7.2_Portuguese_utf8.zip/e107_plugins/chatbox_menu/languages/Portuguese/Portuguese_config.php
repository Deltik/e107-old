<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Definições da chatbox actualizadas.");
define("CHBLAN_2", "Moderado.");
define("CHBLAN_3", "Aínda não existem mensagens na chatbox.");
define("CHBLAN_4", "Membro");
define("CHBLAN_5", "Visitante");
define("CHBLAN_6", "Desbloquear");
define("CHBLAN_7", "Bloquear");
define("CHBLAN_8", "Apagar");
define("CHBLAN_9", "Moderar chatbox");
define("CHBLAN_10", "Moderar mensagens");
define("CHBLAN_11", "Mensagens de chatbox a mostrar");
define("CHBLAN_12", "Quantidade de mensagens mostradas na chatbox");
define("CHBLAN_13", "Substituir links");
define("CHBLAN_14", "Se estiver seleccionado os links publicados serão substituidos pelo texto/imagem inserido na caixa em baixo");
define("CHBLAN_15", "Substituir texto se activado");
define("CHBLAN_16", "Os links serão substituidos por este texto");
define("CHBLAN_17", "Número de caracteres a cortar"); //wordwrap count
define("CHBLAN_18", "Todas as palavras com um comprimento superior ao especificado serão cortadas");
define("CHBLAN_19", "Actualizar definições da chatbox");
define("CHBLAN_20", "Definições da chatbox");
define("CHBLAN_21", "Purgar");
define("CHBLAN_22", "Apagar mensagens mais antigas que um determinado período");
define("CHBLAN_23", "Apagar mensagens mais antigas que ");

define("CHBLAN_24", "Um dia");
define("CHBLAN_25", "Uma semana");
define("CHBLAN_26", "Um mês");
define("CHBLAN_27", "- Apagar todas as mensagens -");
define("CHBLAN_28", "Chatbox purgada.");

define("CHBLAN_29", "Mostrar a chatbox dentro de um scroll");
define("CHBLAN_30", "Altura do scroll");
define("CHBLAN_31", "Mostrar icones de emoção");
define("CHBLAN_32", "Moderar classe de utilizadores");

define("CHBLAN_33", "O número de mensagens foi recalculado");
define("CHBLAN_34", "Recalcular nº mensagens do utilizador");
define("CHBLAN_35", "Recalcular");

define("CHBLAN_36", "Opções de visualização da chatbox");
define("CHBLAN_37", "Chatbox normal");
define("CHBLAN_38", "Usar código javascript para actualizar as mensagens de forma dinâmica (AJAX)");

?>