<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Conteúdo");
define("CONT_SCH_LAN_2", "Todas as categorias de conteúdo");
define("CONT_SCH_LAN_3", "Enviado como resposta ao item");

?>