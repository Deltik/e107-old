<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Configurar Menu em Árvore");
define("TREE_L2", "Actualizar definições de menu em árvore");
define("TREE_L3", "Definições de menu em árvore gravadas.");
define("TREE_L4", "Ligado");
define("TREE_L5", "Desligado");
define("TREE_L6", "Classe CSS para links que não abrem");
define("TREE_L7", "Classe CSS para links que abrem");
define("TREE_L8", "Classe CSS para links abertos");
define("TREE_L9", "Usar a classe 'spacer' entre links principais");

?>