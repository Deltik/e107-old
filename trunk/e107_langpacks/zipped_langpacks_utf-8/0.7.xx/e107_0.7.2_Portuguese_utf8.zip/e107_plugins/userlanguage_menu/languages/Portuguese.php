<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("UTHEME_MENU_L1", "Definir idioma");
define("UTHEME_MENU_L2", "Seleccionar idioma");
define("UTHEME_MENU_L3", "Tabelas");

?>