<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/03 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Visitantes: ");
define("ONLINE_EL2", "Membros: ");
define("ONLINE_EL3", "Nesta página: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Membros");
define("ONLINE_EL6", "Novo membro");
define("ONLINE_EL7", "ver");
	
define("ONLINE_EL8", "Máximo online: ");
define("ONLINE_EL9", "em");

define("TRACKING_MESSAGE", "O seguimento de utilizadores online encontra-se desligado, por favor faça a sua activação <a href='".e_ADMIN."users.php?options'>aqui</a></span><br />");

?>