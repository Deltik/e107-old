<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Notícias para ");
define("BLOGCAL_L2", "Arquivo");
	
define("BLOGCAL_D1", "Se");
define("BLOGCAL_D2", "Te");
define("BLOGCAL_D3", "Qu");
define("BLOGCAL_D4", "Qi");
define("BLOGCAL_D5", "Se");
define("BLOGCAL_D6", "Sb");
define("BLOGCAL_D7", "Do");
	
define("BLOGCAL_M1", "Janeiro");
define("BLOGCAL_M2", "Fevereiro");
define("BLOGCAL_M3", "Março");
define("BLOGCAL_M4", "Abril");
define("BLOGCAL_M5", "Maio");
define("BLOGCAL_M6", "Junho");
define("BLOGCAL_M7", "Julho");
define("BLOGCAL_M8", "Agosto");
define("BLOGCAL_M9", "Setembro");
define("BLOGCAL_M10", "Outubro");
define("BLOGCAL_M11", "Novembro");
define("BLOGCAL_M12", "Dezembro");
	
define("BLOGCAL_1", "Notícia");
	
define("BLOGCAL_CONF1", "Meses/coluna");
define("BLOGCAL_CONF2", "Margem interna"); //Cellpadding
define("BLOGCAL_CONF3", "Actualizar definições de menu");
define("BLOGCAL_CONF4", "Configuração do menu BlogCal");
define("BLOGCAL_CONF5", "A configuração do menu BlogCal foi gravada");
	
define("BLOGCAL_ARCHIV1", "Seleccione o arquivo");
	
?>