<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/03 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Suporte de criação PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Este plugin está pronto a ser utilizado.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Definições PDF");
define("PDF_LAN_3", "Activado");
define("PDF_LAN_4", "Desactivado");
define("PDF_LAN_5", "Margem esquerda da pág.");
define("PDF_LAN_6", "Margem direita da pág.");
define("PDF_LAN_7", "Margem superior da pág.");
define("PDF_LAN_8", "Tipo de fonte");
define("PDF_LAN_9", "Tamanho da fonte por defeito");
define("PDF_LAN_10", "Tamanho da fonte - Nome do site");
define("PDF_LAN_11", "Tamanho da fonte - URL da página");
define("PDF_LAN_12", "Tamanho da fonte - Número da página");
define("PDF_LAN_13", "Mostrar logo no PDF?");
define("PDF_LAN_14", "Mostrar nome do site no PDF?");
define("PDF_LAN_15", "Mostrar URL da página no PDF?"); //show creator page url on pdf?
define("PDF_LAN_16", "Mostrar número de páginas no PDF?");
define("PDF_LAN_17", "Actualizar");
define("PDF_LAN_18", "As definições do PDF foram actualizadas com sucesso");
define("PDF_LAN_19", "Página");
define("PDF_LAN_20", "Erro ao reportar");

?>