<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "As visitas dos administradores não são contabilizadas.");
define("COUNTER_L2", "Esta página hoje...");
define("COUNTER_L3", "Total");
define("COUNTER_L4", "Esta página total...");
define("COUNTER_L5", "única");
define("COUNTER_L6", "Site...");
define("COUNTER_L7", "Contador");
define("COUNTER_L8", "Mensagem ao administrador: <b>O registo de estatísticas do site está desligado.</b><br />Para activá-lo necessita de instalar o plugin 'Registo de Estatísticas'a partir do seu <a href='".e_ADMIN."plugin.php'>gestor de plugins</a> e posteriormente activá-lo no <a href='".e_PLUGIN."log/admin_config.php'>ecrã de configuração</a>.");
	
?>