<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/	
define("LWLAN_1", "Campos deixados em branco.");
define("LWLAN_2", "Palavra de link guardada.");
define("LWLAN_3", "Palavra de link actualizada.");
define("LWLAN_4", "Aínda não foram definidas palavras de links.");
define("LWLAN_5", "Palavra");
define("LWLAN_6", "Link");
define("LWLAN_7", "Activo?"); //Active?
define("LWLAN_8", "Opções");
define("LWLAN_9", "Sim");
define("LWLAN_10", "Não");
define("LWLAN_11", "Palavras de links existentes");
define("LWLAN_12", "Sim");
define("LWLAN_13", "Não");
define("LWLAN_14", "Submeter palavra de link");
define("LWLAN_15", "Actualizar palavra de link");
define("LWLAN_16", "Editar");
define("LWLAN_17", "Apagar");
define("LWLAN_18", "Tem a certeza que deseja apagar esta palavra de link?");
define("LWLAN_19", "Palavra de link apagada.");
define("LWLAN_20", "Essa palavra de link não foi encontrada.");
define("LWLAN_21","Palavra para linkar automáticamente");
define("LWLAN_22","Activar?");

define("LWLANINS_1", "Palavras de links");
define("LWLANINS_2", "Este plugin faz a ligação entre palavras e links definidos");
define("LWLANINS_3", "Configurar palavras de links");
define("LWLANINS_4", "Para configurar esta opção deverá clicar no link da secção de plugins, na página principal de administração");

?>