<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/07 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("NWSF_FP_1", "Feeds de notícias");
define("NWSF_FP_2", "Página principal");

?>