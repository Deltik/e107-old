<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Nenhuma das útlimas mensagens pertence à sua classe de utilizador. Não é possivel visualizar.");
define("NFP_2", "Aínda não existem mensagens");
define("NFP_3", "Definições do menu de novas mensagens gravadas");
define("NFP_4", "Título");
define("NFP_5", "Número de mensagens mostradas?");
define("NFP_6", "Número de caracteres mostrados?");
define("NFP_7", "Sufixo para mensagens longas?");
define("NFP_8", "Mostrar tópicos originais no menu?");
define("NFP_9", "Actualizar definições do menu");
define("NFP_10", "Definições do menu de novas mensagens");
define("NFP_11", "Enviado por");
	
?>