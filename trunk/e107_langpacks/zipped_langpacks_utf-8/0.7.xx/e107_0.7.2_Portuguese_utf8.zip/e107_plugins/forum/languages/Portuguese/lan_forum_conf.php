<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "Votação apagada");
define("FORLAN_6", "Tópico apagado");
define("FORLAN_7", "Respostas apagadas");
define("FORLAN_8", "Remoção cancelada");
define("FORLAN_9", "Tópico movido");
define("FORLAN_10", "Movimentação cancelada");
define("FORLAN_11", "Voltar aos fóruns");
define("FORLAN_12", "Configuração do Fórum");
define("FORLAN_13", "Tem a certeza que deseja apagar esta votação?<br />Se for removida <b><u>não</u></b> poderá ser recuperada.");
define("FORLAN_14", "Cancelar");
define("FORLAN_15", "Confirmar a eliminação da mensagem");
define("FORLAN_16", "Confirmar a eliminação da votação");
define("FORLAN_17", "enviado por");
define("FORLAN_18", "Tem a certeza que deseja apagar este fórum?");
define("FORLAN_19", "tópico e mensagens respectivas?");
define("FORLAN_20", "a votação também será apagada");
define("FORLAN_21", "Se forem removidos");
define("FORLAN_22", "mensagem?<br />Se for removida");
define("FORLAN_23", "não</u></b> pode ser recuperda");
define("FORLAN_24", "Mover tópico para o fórum");
define("FORLAN_25", "Mover tópico");
define("FORLAN_26", "Resposta apagada");

define("FORLAN_27", "movido");

define("FORLAN_28", "Não renomear titulo do tópico");
define("FORLAN_29", "Adicionar");
define("FORLAN_30", "ao título");
define("FORLAN_31", "Renomear para:");
define("FORLAN_32", "Opções de renomeação do tópico:");

?>