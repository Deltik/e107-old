<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Fórum");
	
define("LAN_30", "Bem-vindo");
define("LAN_31", "Não existem mensagens novas ");
define("LAN_32", "Existe 1 mensagem nova ");
define("LAN_33", "Existem");
define("LAN_34", "mensagens novas ");
define("LAN_35", "desde a sua última visita.");
define("LAN_36", "A sua última visita foi em ");
define("LAN_37", "São agora ");
define("LAN_38", ", todas as horas são ");
define("LAN_41", "Novo membro: ");
define("LAN_42", "Membros registados: ");
define("LAN_44", "Este fórum pode ser utilizado por membros não registados, mas tenha em atenção que o endereço de IP ficará registado quando enviar uma mensagem.<br />Para aceder sem restrições a este fórum deverá");
define("LAN_45", "Este fórum só pode ser utlizado por membros registados, por favor clique");
define("LAN_46", "Fórum");
define("LAN_47", "Tópicos");
define("LAN_48", "Respostas");
define("LAN_49", "Última mensagem");
define("LAN_51", "Os fóruns aínda não estão definidos, por favor volte mais tarde.");
define("LAN_52", "Ainda não existem fóruns nesta secção, por favor volte mais tarde.");
define("LAN_79", "Novas mensagens");
define("LAN_80", " Não existem mensagens novas");
define("LAN_81", "Tópico fechado");
define("LAN_100", "artigos");
define("LAN_180", "Pesquisar");
define("LAN_191", "Informação");
define("LAN_192", "Os utilizadores do fórum enviaram um total de ");
define("LAN_196", "Já leu ");
define("LAN_197", " destas mensagens.");
define("LAN_198", " Todas as mensagens novas foram lidas.");
define("LAN_199", "Marcar todas as mensagens como lidas");
define("LAN_204", "<b>Pode</b> iniciar novos tópicos");
define("LAN_205", "<b>Não pode</b> iniciar novos tópicos");
define("LAN_206", "<b>Pode</b> enviar respostas");
define("LAN_207", "<b>Não pode</b> enviar respostas");
define("LAN_208", "<b>Pode</b> editar as suas mensagens");
define("LAN_209", "<b>Não pode</b> editar as suas mensagens");
define("LAN_392", "Terminar o rastreio deste tópico");
define("LAN_393", "Listar tópicos rastreados");
define("LAN_394", "Fórum encerrado");
define("LAN_397", "Tópicos rastreados");
define("LAN_398", "Encerrado");
define("LAN_399", "Restrito");
define("LAN_400", "Este forum só pode ser visualizado por membros registados");
define("LAN_401", "Apenas membros");
	
define("LAN_402", "Este fórum é apenas de leitura");
	
define("LAN_403", "Sem mensagens");
define("LAN_404", "mensagens");
define("LAN_405", "Apenas leitura");
	
define("LAN_406", "Este fórum é restrito apenas a administradores");
define("LAN_407", "Este fórum é restrito apenas a membros");
define("LAN_408", "Este fórum é apenas de leitura");
define("LAN_409", "Este fórum é de acesso restrito");
define("LAN_410", "Bem-vindo visitante");
	
define("LAN_411", "tópico");
define("LAN_412", "resposta");
define("LAN_413", "tópicos");
define("LAN_414", "respostas");
define("LAN_415", "utilizador a visualizar o fórum neste momento");
define("LAN_416", "utilizadores a visualizarem o fórum neste momento");
	
define("LAN_417", "membro");
define("LAN_418", "visitante");
define("LAN_419", "membros");
define("LAN_420", "visitantes");
	
define("LAN_421", "Mostrar mensagens novas");
define("LAN_422", "Mensagens novas desde a sua última visita");
define("LAN_423", "Enviado por");
define("LAN_424", "Novos tópicos");
define("LAN_425", "Re:");
	
//v.616
define("LAN_426", "Quem está online: ");
define("LAN_427", "Ver lista detalhada.");
define("LAN_428", "Re:");
define("LAN_429", "Top Autores");
define("LAN_430", "Tópicos mais activos");
define("LAN_431", "As minhas mensagens");
define("LAN_432", "As minhas definições");
define("LAN_433", "Regras do fórum");
define("LAN_434", "Voltar ao fórum");
define("LAN_435", "O meu perfil");
define("LAN_436", " (será aberta uma nova janela.)");
	
define("LAN_437", "registar");
define("LAN_438", "e efectuar o login.");
define("LAN_439", "aqui");
define("LAN_440", "para ir à página de registo.");

define("LAN_441", "Ver estatísticas do fórum");
	
define('FORLAN_441', 'Não existem regras definidas.');
define('FORLAN_442', 'Os meus uploads');
define('FORLAN_443', '[utilizador apagado]');
define('FORLAN_444', 'sub-fóruns');

?>