<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Fórum");
define("FOR_SCH_LAN_2", "Seleccionar fórum");
define("FOR_SCH_LAN_3", "Todos os fóruns");
define("FOR_SCH_LAN_4", "Mensagem completa");
define("FOR_SCH_LAN_5", "Como parte de um tópico");

?>