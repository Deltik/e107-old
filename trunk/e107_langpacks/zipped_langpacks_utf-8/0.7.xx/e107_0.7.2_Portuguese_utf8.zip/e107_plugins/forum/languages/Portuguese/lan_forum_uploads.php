<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Transferências/Uploads do Fórum");

define('FRMUP_1','Ficheiros transferidos no fórum');
define('FRMUP_2','Ficheiro apagado');
define('FRMUP_3','Erro: Não foi possível apagar o ficheiro');
define('FRMUP_4','Eliminação do ficheiro');
define('FRMUP_5','Nome do ficheiro');
define('FRMUP_6','Resultado');
define('FRMUP_7','Encontrado no tópico');
define('FRMUP_8','NÃO ENCONTRADO');
define('FRMUP_9','Não foram encontrados ficheiros transferidos');
define('FRMUP_10','Apagar');
	
?>