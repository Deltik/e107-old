<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Estatísticas do Fórum");

define("FSLAN_1", "Geral");
define("FSLAN_2", "Início do fórum");
define("FSLAN_3", "Iniciado por");
define("FSLAN_4", "Total de mensagens");
define("FSLAN_5", "Tópicos do fórum");
define("FSLAN_6", "Respostas ao fórum");
define("FSLAN_7", "Visualizações dos tópicos do fórum");
define("FSLAN_8", "Tamanho da base de dados (apenas tabelas do fórum)");
define("FSLAN_9", "Comprimento médio das linhas na tabela do fórum");
define("FSLAN_10", "Tópicos mais activos");
define("FSLAN_11", "Escalão");
define("FSLAN_12", "Tópico");
define("FSLAN_13", "Respostas");
define("FSLAN_14", "Iniciado por");
define("FSLAN_15", "Data");
define("FSLAN_16", "Tópicos mais visitados");
define("FSLAN_17", "Visualizações");
define("FSLAN_18", "Top utilizadores");
define("FSLAN_19", "Nome");
define("FSLAN_20", "Mensagens");
define("FSLAN_21", "Top autores - inicio de tópicos");
define("FSLAN_22", "Top autores - respostas");
define("FSLAN_23", "Estatísticas do fórum");
define("FSLAN_24", "Média diária de mensagens");

?>