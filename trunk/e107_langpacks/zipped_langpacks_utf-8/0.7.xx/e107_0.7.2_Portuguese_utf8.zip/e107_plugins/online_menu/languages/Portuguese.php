<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/03 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Visitantes: ");
define("ONLINE_L2", "Membros: ");
define("ONLINE_L3", "Nesta página: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Membros");
define("ONLINE_L6", "Novo membro");
define("TRACKING_MESSAGE", "O seguimento de utilizadores online encontra-se desligado, por favor faça a sua activação <a href='".e_ADMIN."users.php?options'>aqui</a><br />");
?>