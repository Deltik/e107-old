<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define('CLOCK_MENU_L1', 'Configurações do menu do relógio actualizadas');
define('CLOCK_MENU_L2', 'Título');
define('CLOCK_MENU_L3', 'Actualizar definições de menu');
define('CLOCK_MENU_L4', 'Configuração do menu do relógio');
define('CLOCK_MENU_L5', 'Segunda,');
define('CLOCK_MENU_L6', 'Terça,');
define('CLOCK_MENU_L7', 'Quarta,');
define('CLOCK_MENU_L8', 'Quinta,');
define('CLOCK_MENU_L9', 'Sexta,');
define('CLOCK_MENU_L10', 'Sábado,');
define('CLOCK_MENU_L11', 'Domingo,');
define('CLOCK_MENU_L12', 'Janeiro');
define('CLOCK_MENU_L13', 'Fevereiro');
define('CLOCK_MENU_L14', 'Março');
define('CLOCK_MENU_L15', 'Abril');
define('CLOCK_MENU_L16', 'Maio');
define('CLOCK_MENU_L17', 'Junho');
define('CLOCK_MENU_L18', 'Julho');
define('CLOCK_MENU_L19', 'Agosto');
define('CLOCK_MENU_L20', 'Setembro');
define('CLOCK_MENU_L21', 'Outubro');
define('CLOCK_MENU_L22', 'Novembro');
define('CLOCK_MENU_L23', 'Dezembro');
define('CLOCK_MENU_L24', '');
?>