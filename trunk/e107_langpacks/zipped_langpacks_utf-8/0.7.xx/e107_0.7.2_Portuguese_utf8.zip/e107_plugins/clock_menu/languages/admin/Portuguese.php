<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/31 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Configuração do menu do relógio gravada");
define("CLOCK_AD_L2", "Título");
define("CLOCK_AD_L3", "Actualizar definições do menu");
define("CLOCK_AD_L4", "Configuração do menu do relógio");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Se seleccionado mostrará as horas no formato Americano (0-12 AM/PM), caso contrário mostrará as horas no formato 0-24");
define("CLOCK_AD_L7", "Prefixo da data");
define("CLOCK_AD_L8", "Utilize este campo na eventualidade de o seu idioma necessitar um prefixo antes da data (p.exo. 'le' para o Francês, 'den' para o Alemão, etc.), caso contrário deixe este campo em branco.");
define("CLOCK_AD_L9", "Sufixo 1");
define("CLOCK_AD_L10", "Sufixo 2");
define("CLOCK_AD_L11", "Sufixo 3");
define("CLOCK_AD_L12", "Sufixo 4 e mais");
define("CLOCK_AD_L13", "Preencha este campo na eventualidade de o seu idioma requerer um sufixo após os números da data. Insira apenas os sufixos (p.exo. 'st' para 1, 'nd' para 2, 'rd' para 3 e 'th' para 4 ou mais, no caso dos utilizadores Ingleses), caso contrário deixe este campo em branco");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>