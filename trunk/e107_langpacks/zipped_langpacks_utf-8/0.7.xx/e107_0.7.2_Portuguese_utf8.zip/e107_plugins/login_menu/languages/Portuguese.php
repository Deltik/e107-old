<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/03 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/	
define("LOGIN_MENU_L1", "Utilizador: ");
define("LOGIN_MENU_L2", "Password: ");
define("LOGIN_MENU_L3", "Registar");
define("LOGIN_MENU_L4", "Esqueceu a password?");
define("LOGIN_MENU_L5", "Bem-vindo");
define("LOGIN_MENU_L6", "Lembrar");
define("LOGIN_MENU_L7", "A ID única de utilizador não foi reconhecida (possivelmente devido ao cookie estar corrompido)).<br />Por favor <a href=\"".e_BASE."index.php?logout\">clique aqui</a> para apagar o cookie.");
define("LOGIN_MENU_L8", "Logout");
define("LOGIN_MENU_L9", "Erro no Login");
define("LOGIN_MENU_L10", "A manutenção do site está activada - os visitantes estão a ser redireccionados para a página 'sitedown.php'. Para desligar a manutenção deverá ir à secção de administração e escolher a opção respectiva.");
define("LOGIN_MENU_L11", "Administração");
define("LOGIN_MENU_L12", "Definições");
define("LOGIN_MENU_L13", "Perfil");
define("LOGIN_MENU_L14", "notícia");
define("LOGIN_MENU_L15", "notícias");
define("LOGIN_MENU_L16", "mensagem na chatbox");
define("LOGIN_MENU_L17", "mensagens na chatbox");
define("LOGIN_MENU_L18", "comentário");
define("LOGIN_MENU_L19", "comentários");
define("LOGIN_MENU_L20", "mensagem no fórum");
define("LOGIN_MENU_L21", "mensagens no fórum");
define("LOGIN_MENU_L22", "novo membro");
define("LOGIN_MENU_L23", "novos membros");
define("LOGIN_MENU_L24", "Clique aqui par ver a lista de novidades");
define("LOGIN_MENU_L25", "novidades desde a sua última visita");
define("LOGIN_MENU_L26", "Sem");
define("LOGIN_MENU_L27", "e");
define("LOGIN_MENU_L28", "Login");
	
define("LOGIN_MENU_L29", "novo artigo");
define("LOGIN_MENU_L30", "novos artigos");
	
// New config options
define('LOGIN_MENU_L31', 'Mostrar as novas Notícias');
define('LOGIN_MENU_L32', 'Mostrar os novos Artigos');
define('LOGIN_MENU_L33', 'Mostrar as novas mensagens na Chatbox');
define('LOGIN_MENU_L34', 'Mostrar os novos Comentários');
define('LOGIN_MENU_L35', 'Mostrar as novas mensagens no Fórum');
define('LOGIN_MENU_L36', 'Mostrar os novos Membros');
define('LOGIN_MENU_L37', 'Actualizar definições');
define('LOGIN_MENU_L38', 'Definições guardadas');
	
?>