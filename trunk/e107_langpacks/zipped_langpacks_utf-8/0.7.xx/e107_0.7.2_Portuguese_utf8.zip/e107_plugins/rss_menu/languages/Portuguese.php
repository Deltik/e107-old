<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/02 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("BACKEND_MENU_L1", " podem ser usadas através destes feeds RSS.");
define("BACKEND_MENU_L2", "Feeds RSS");

define("BACKEND_MENU_L3", "As nossas notícias");
define("BACKEND_MENU_L4", "Os nossos comentários");
define("BACKEND_MENU_L5", "Os nossos tópicos no fórum");
define("BACKEND_MENU_L6", "As nossas mensagens no fórum");

define("BACKEND_MENU_L7", "As nossas mensagens na chatbox");
define("BACKEND_MENU_L8", "Os nossos relatórios no bugtracker");
define("BACKEND_MENU_L9", "Os nossos downloads");

define("RSS_LAN01", "Activar feeds separados para cada categoria de notícias?");
define("RSS_LAN02", "Activar feeds separados para cada categoria de downloads?");

define("RSS_NEWS","Notícias");
define("RSS_COM","Comentários"); 
define("RSS_ART","Artigos");
define("RSS_REV", "Revisões");
define("RSS_FT","Tópicos no fórum");
define("RSS_FP","Mensagens no fórum");
define("RSS_FSP","Mensagens específicas no fórum");
define("RSS_BUG","Bugtracker");
define("RSS_FOR","Fórum");
define("RSS_DL","Downloads");

?>