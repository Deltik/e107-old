<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "O site encontra-se temporáriamente encerrado");
define("LAN_00", "está temporariamente encerrado");
define("LAN_01", "O site está temporariamente encerrado para manutenção.<br />Por favor volte mais tarde - Prometemos ser breves e gostariamos de pedir desculpa pelo incómodo.");
?>