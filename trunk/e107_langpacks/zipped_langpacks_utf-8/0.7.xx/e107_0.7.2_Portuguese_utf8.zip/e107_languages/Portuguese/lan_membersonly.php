<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Apenas para membros");

define("LAN_MEMBERS_0", "Área restrita");
define("LAN_MEMBERS_1", "Esta é uma área restrita.");
define("LAN_MEMBERS_2","Para aceder deverá efectuar o <a href='".e_LOGIN."'>login</a>");
define("LAN_MEMBERS_3","ou <a href='".e_SIGNUP."'>registar-se</a> como membro");
define("LAN_MEMBERS_4","Clique aqui para voltar à página principal");

?>