<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Caixa de texto");
define("UE_LAN_2", "Botões de radio");
define("UE_LAN_3", "Menu drop-down");
define("UE_LAN_4", "Campo de tabela da BD");
define("UE_LAN_5", "Área de texto");
define("UE_LAN_6", "Inteiro");
define("UE_LAN_7", "Data");
define("UE_LAN_8", "Idioma");

define("UE_LAN_9", "Nome");
define("UE_LAN_10", "Tipo");
define("UE_LAN_11", "Descrição");

define("UE_LAN_HIDE", "Ocultar dos utilizadores");

define("UE_LAN_LOCATION", "Local");
define("UE_LAN_LOCATION_DESC", "Localização/origem");
define("UE_LAN_AIM", "Endereço AIM");
define("UE_LAN_AIM_DESC", "Endereço AIM");
define("UE_LAN_ICQ", "Número ICQ");
define("UE_LAN_ICQ_DESC", "Número ICQ");
define("UE_LAN_YAHOO", "Endereço Yahoo!");
define("UE_LAN_YAHOO_DESC", "Endereço Yahoo!");
define("UE_LAN_MSN", "Endereço MSN");
define("UE_LAN_MSN_DESC", "Endereço MSN-messenger");
define("UE_LAN_HOMEPAGE", "Página web");
define("UE_LAN_HOMEPAGE_DESC", "Página web do utilizador (URL)");
define("UE_LAN_BIRTHDAY", "Data de nascimento");
define("UE_LAN_BIRTHDAY_DESC", "Data de nascimento");

?>