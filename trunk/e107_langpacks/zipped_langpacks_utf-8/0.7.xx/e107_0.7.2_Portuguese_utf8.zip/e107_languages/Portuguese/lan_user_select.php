<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Seleccionar utilizador");
define("US_LAN_2", "Seleccionar classe de utilizadores");
define("US_LAN_3", "Todos os utilizadores");
define("US_LAN_4", "Encontrar utilizador");
define("US_LAN_5", "Utilizador(es) encontrado(s)");
define("US_LAN_6", "Pesquisar");
?>