<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Esta página permite definir uma mensagem que será mostrada no início da página principal enquanto estiver activa. Poderá definir mensagens diferentes para visitantes, utilizadores registados e administradores.";
$ns -> tablerender("Ajuda = Mensagens de Boas-vindas", $text);
?>
