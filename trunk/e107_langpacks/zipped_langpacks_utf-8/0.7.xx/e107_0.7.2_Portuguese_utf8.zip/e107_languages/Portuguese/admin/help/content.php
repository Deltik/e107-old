<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Poderá adicionar uma página normal ao seu site através desta opção. Será criado um link para a nova página no painel principal de navegação do site. Por exemplo se criar uma nova página com o Nome do Link 'Teste', será adicionado ao painel principal uma nova entrada entitulada 'Teste' assim que efectuar a submissão da página.<br />
Se desejar adicionar um pequeno título à sua página deve preencher o campo respectivo.";
$ns -> tablerender("Ajuda = Conteúdo", $text);
?>