<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/27 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Activar o sistema de cache?"); //Cache System Status
define("CACLAN_2", "Definir estado do cache");
define("CACLAN_3", "Sistema de cache");
define("CACLAN_4", "Estado do cache alterado");
define("CACLAN_5", "Limpar cache");
define("CACLAN_6", "Cache limpo");

define("CACLAN_7", "Cache desactivado");
// define("CACLAN_8", "Guardar dados de cache no MySQL");
define("CACLAN_9", "Guardar dados de cache em ficheiro");
define("CACLAN_10", "A directoria de cache não tem permissões de escrita. Por favor certifique-se que as suas propriedades são alteradas com 'CHMOD 777'");
?>