<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Se necessitar de efectuar uma actualização ao seu sistema e107, ou desligar o seu site temporáriamente por algum motivo, deverá ligar a opção de manutenção. Os seus utilizadores serão redireccionados para uma página que os informa que o site está desligado para manutenção/actualização. Após ter desligado esta opção, o seu site voltará ao funcionamento normal.";

$ns -> tablerender("Ajuda = Manutenção do site", $text);
?>