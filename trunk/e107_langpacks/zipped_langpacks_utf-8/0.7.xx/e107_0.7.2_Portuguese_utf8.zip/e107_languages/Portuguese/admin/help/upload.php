<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/0/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "A partir desta secção poderá permitir ou desactivar as transferências públicas de ficheiros (uploads) pelos utilizadores, bem como de todos os ficheiros que foram transferidos para o seu site.";
$ns -> tablerender("Ajuda = Transferências pública (uploads)", $text);
?>