<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/07 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Créditos");
define("CRELAN_2", "Em anexo poderá encontrar uma lista de recursos / software de terceiros utilizados na elaboração do e107. A equipa de desenvolvimento gostaria de agradecer pessoalmente aos autores pela autorização dada na distribuição do seu código com o e107, bem como da distribuição do memsmo sob a licença GPL.");
// define("CRELAN_3", "Recurso");
// define("CRELAN_4", "Descrição");
// define("CRELAN_5", "Página web");
// define("CRELAN_6", "Permissão");
define("CRELAN_7", "versão");

?>