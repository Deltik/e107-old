<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Administrador");
define("FOOTLAN_3", "Versão");
define("FOOTLAN_4", "Revisão");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "por");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Data de instalação");
define("FOOTLAN_9", "Servidor");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "Versão PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Informação do site");
define("FOOTLAN_14", "Ver documentação");
define("FOOTLAN_15", "Documentação");
define("FOOTLAN_16", "Base de dados");
define("FOOTLAN_17", "Charset");

?>