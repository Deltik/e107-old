<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Poderá separar as suas notícias em categorias diferentes e permitir aos seus utilizadores visualizem apenas as notícias nessas categorias. <br /><br />Deverá efectuar o upload dos seus ícones de imagem de noticias para ".e_THEME."-temautilizado-/images/ ou themes/shared/newsicons/.";
$ns -> tablerender("Ajuda = Categorias de notícias", $text);
?>