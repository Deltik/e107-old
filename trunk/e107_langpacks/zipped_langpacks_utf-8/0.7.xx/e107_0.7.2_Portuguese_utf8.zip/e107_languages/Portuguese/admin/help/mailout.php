<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Utilize esta página para configurar as definições de email e funções de envio do seu site. O formulário de envio de email também lhe permite enviar uma mensagem rápida a todos os utilizadores.";
$ns -> tablerender("Ajuda = Mail", $text);
?>