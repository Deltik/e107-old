<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/07 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Activação de ícones de emoção");
define("EMOLAN_2", "Nome");
define("EMOLAN_3", "Ícones de emoção");
define("EMOLAN_4", "Activar ícones de emoção?");

define("EMOLAN_5", "Imagem");
define("EMOLAN_6", "Código da emoção");
define("EMOLAN_7", "Separar as opções com espaços");

define("EMOLAN_8", "Estado");
define("EMOLAN_9", "Opções");
define("EMOLAN_10", "Activo");
define("EMOLAN_11", "Activar pacote");

define("EMOLAN_12", "Editar/configurar este pacote");
define("EMOLAN_13", "Pacotes instalados");

define("EMOLAN_14", "Gravar configuração");
define("EMOLAN_15", "Editar/configurar ícones de emoção");
define("EMOLAN_16", "Configuração de ícones de emoção gravada");
define("EMOLAN_2", "Nome");
define("EMOLAN_2", "Nome");
define("EMOLAN_2", "Nome");
define("EMOLAN_2", "Nome");
define("EMOLAN_2", "Nome");
define("EMOLAN_2", "Nome");

?>