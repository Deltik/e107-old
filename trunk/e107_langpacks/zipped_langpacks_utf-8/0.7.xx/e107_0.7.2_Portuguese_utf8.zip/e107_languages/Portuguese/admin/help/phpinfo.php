<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = " Esta página mostra-lhe todas as definições PHP do seu servidor. ";
$ns -> tablerender("Ajuda = Informação do PHP", $text);
?>