<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Mensagens recebidas");
define("MESSLAN_2", "Apagar mensagens");
define("MESSLAN_3", "Mensagem apagada.");
define("MESSLAN_4", "Apagar todas as mensagens");
define("MESSLAN_5", "Confirmar");
define("MESSLAN_6", "Todas as mensagens foram apagadas.");
define("MESSLAN_7", "Sem mensagens.");
define("MESSLAN_8", "Tipo de mensagem");
define("MESSLAN_9", "Reportado em");

define("MESSLAN_10", "Enviado por");
define("MESSLAN_11", "Abrir numa nova janela");
define("MESSLAN_12", "Mensagem");
define("MESSLAN_13", "Link");

?>