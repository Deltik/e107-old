<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/24 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda = Administração do site";
$text = "Utilize esta página para editar as definições ou apagar administradores do seu site. O administrador só terá permissões de acesso às funções que se encontrem seleccionadas.<br /><br />
Para criar um novo administrador deverá aceder às configurações de utilizadores e conceder permissões de administração a um utilizador existente.";
$ns -> tablerender($caption, $text);
?>