<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Qualquer etiqueta meta inserida neste espaço será enviada para o ecrã no local apropriado.";

$ns -> tablerender("Ajuda = Etiquetas Meta", $text);
?>