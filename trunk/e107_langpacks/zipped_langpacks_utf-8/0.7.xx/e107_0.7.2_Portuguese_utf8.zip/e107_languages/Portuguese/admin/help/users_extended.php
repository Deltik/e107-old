<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = " Esta opção permite ao administrador incluir dados adicionais no perfil de utilizador. Estes campos poderão ser preenchidos pelo utilizador ficando assim a fazer parte do seu perfil.";
$ns -> tablerender(" Ajuda = Campos Adicionais de Utilizador", $text);
?>