<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Enviar email de notificação a");
define("UCSLAN_2", "Previlégios actualizados");
define("UCSLAN_3", "Caro");
define("UCSLAN_4", "Os seus previlégios foram actualizados no");
define("UCSLAN_5", "Tem agora acesso às seguintes áreas");
define("UCSLAN_6", "Definir classe para o utilizador");
define("UCSLAN_7", "Definir classes");
define("UCSLAN_8", "Notificar utilizador");
define("UCSLAN_9", "Classes actualizadas.");
define("UCSLAN_10", "Cumprimentos,");

?>