<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Erro - por favor faça novamente a submissão");
define("UDALAN_2", "Definições actualizadas");
define("UDALAN_3", "Definições actualizadas para");
define("UDALAN_4", "Nome");
define("UDALAN_5", "Password");
define("UDALAN_6", "Escreva novamente a password");
define("UDALAN_7", "Mudar password");
define("UDALAN_8", "Actualização de password para");

?>