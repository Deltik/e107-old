<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Todos os utilizadores desta classe foram apagados.");
define("UCSLAN_2", "Classe de utilizadores actualizada.");
define("UCSLAN_3", "Classe apagada.");
define("UCSLAN_4", "Seleccione a caixa para confirmar a remoção desta classe de utilizadores");
define("UCSLAN_5", "Classe actualizada.");
define("UCSLAN_6", "Classe gravada na base de dados.");
define("UCSLAN_7", "Aínda não foram definidas classes de utilizadores.");
define("UCSLAN_8", "Classes existentes");

// define("UCSLAN_9", "Editar");
// define("UCSLAN_10", "Apagar");
define("UCSLAN_11", "Seleccione para confirmar");
define("UCSLAN_12", "Nome da classse");
define("UCSLAN_13", "Descrição da classe");
define("UCSLAN_14", "Actualizar classe de utilizadores");
define("UCSLAN_15", "Criar uma nova classe");
define("UCSLAN_16", "Atribuir utilizadores à classe");
define("UCSLAN_17", "Apagar");
define("UCSLAN_18", "Limpar classe");
define("UCSLAN_19", "Atribuir utilizadores a");
define("UCSLAN_20", "Classe");
define("UCSLAN_21", "Configuração da classe de utilizadores");

define("UCSLAN_22", "Utilizadores - clique para mover ...");
define("UCSLAN_23", "Utilizadores nesta classe...");

define("UCSLAN_24", "Quem pode gerir a classe");

?>