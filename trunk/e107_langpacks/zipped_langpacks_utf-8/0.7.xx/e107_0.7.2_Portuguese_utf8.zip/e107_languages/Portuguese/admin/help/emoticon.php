<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Ao activar os ícones de emoção, as expressões de texto com smileys serão substituidas pelas respectivas imagens de emoção em todo o conteúdo do seu site.";

$ns -> tablerender("Ajuda = Ícones de emoção", $text);
?>