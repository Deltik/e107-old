<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Este conjunto de ferramentas permite-lhe gerir a sua base de dados.";
$ns -> tablerender("Ajuda = Ferramentas da base de dados", $text);
?>