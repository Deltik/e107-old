<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/07 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Título");
define("CUSLAN_2", "Tipo");
define("CUSLAN_3", "Opções");
define("CUSLAN_4", "Apagar esta página?");
define("CUSLAN_5", "Páginas existentes");
define("CUSLAN_7", "Nome do menu");
define("CUSLAN_8", "Título");
define("CUSLAN_9", "Texto");
define("CUSLAN_10", "Permitir avaliação da página");
define("CUSLAN_11", "Página inicial");
define("CUSLAN_12", "Criar página");
define("CUSLAN_13", "Permitir comentários");
define("CUSLAN_14", "Proteger a página com password");
define("CUSLAN_15", "Escreva a password para proteger a página");
define("CUSLAN_16", "Criar link no menu principal");
define("CUSLAN_17", "Escreva o nome do link a ser criado");
define("CUSLAN_18", "Página/link visivel a");
define("CUSLAN_19", "Actualizar página");
define("CUSLAN_20", "Criar página");
define("CUSLAN_21", "Actualizar menu");
define("CUSLAN_22", "Criar menu");
define("CUSLAN_23", "Editar página");
define("CUSLAN_24", "Criar nova página");
define("CUSLAN_25", "Editar menu");
define("CUSLAN_26", "Criar novo menu");
define("CUSLAN_27", "Página gravada na base de dados.");
define("CUSLAN_28", "Página apagada");
define("CUSLAN_29", "Páginas listadas se não existir selecção de páginas");
define("CUSLAN_30", "Tempo de expiração do cookie (em segundos)");
define("CUSLAN_31", "Criar menu");
define("CUSLAN_32", "Converter páginas/menus antigos");
define("CUSLAN_33", "Opções da página");
define("CUSLAN_34", "Iniciar conversão");
define("CUSLAN_35", "Actualização de página personalizada terminada");
define("CUSLAN_36", "Para editar as definições de cada página deverá voltar à página inicial e alterar as páginas.");
define("CUSLAN_37", "Actualização de página personalizada"); //Custom Page Update
define("CUSLAN_38", "Ligado");
define("CUSLAN_39", "Desligado");
define("CUSLAN_40", "Gravar opções");

define("CUSLAN_41", "Mostrar informação do autor e da data");
define("CUSLAN_42", "Aínda não existem páginas definidas");

?>