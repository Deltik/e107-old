<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderado.");
define("MDCLAN_2", "Não existem comentários");
define("MDCLAN_3", "Membro");
define("MDCLAN_4", "Visitante");
define("MDCLAN_5", "Desbloquear");
define("MDCLAN_6", "Bloquear");

define("MDCLAN_8", "Moderar comentários");
define("MDCLAN_9", "AVISO! Se apagar o comentário principal, irá eliminar também todas as respostas!");

define("MDCLAN_10", "Opções");
define("MDCLAN_11", "Comentário");
define("MDCLAN_12", "Comentários");
define("MDCLAN_13", "Bloqueado");
define("MDCLAN_14", "Bloquear comentários");
define("MDCLAN_15", "Aberto");
define("MDCLAN_16", "Fechado");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>