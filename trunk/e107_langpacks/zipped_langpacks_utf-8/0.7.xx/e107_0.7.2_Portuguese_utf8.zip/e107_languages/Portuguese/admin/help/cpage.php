<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "A partir deste ecrã poderá criar menus e páginas personalizadas com o seu conteúdo.<br /><br />
Por favor visite <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a> para obter uma explicação detalhada de todas as funções.";

$ns -> tablerender(CUSLAN_18, $text);
?>