<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Insira os links da categoria principal do seu site nesta secção. Os links adicionados aqui serão mostrados no menu principal de navegação, todos os outros links deverão ser adicionados através do plugin da 'página de links'.
<br />
";
$ns -> tablerender("Ajuda = Links", $text);
?>