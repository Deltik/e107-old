<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Esta página permite moderar os utilizadores/membros registados. Poderá actualizar as suas definições, dar-lhes status de administração e definir a sua classe entre outros parâmetros.";
$ns -> tablerender("Ajuda = Utilizadores", $text);
unset($text);
?>