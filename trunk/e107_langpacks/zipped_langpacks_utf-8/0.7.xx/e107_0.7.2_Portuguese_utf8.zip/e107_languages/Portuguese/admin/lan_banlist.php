<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/27 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Ban removido.");
define("BANLAN_2", "Não existem bans.");
define("BANLAN_3", "Bans existentes");
define("BANLAN_4", "Remover ban");
define("BANLAN_5", "Insira IP, email, ou host");
define("BANLAN_7", "Razão");
define("BANLAN_8", "Banir Utilizador");
define("BANLAN_9", "Banir utilizadores do site");
define("BANLAN_10", "IP / Email / Razão");
define("BANLAN_11", "Ban Automático: Mais de 10 tentativas falhadas de login");

?>