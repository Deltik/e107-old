<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/07 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Backup das definições de sistema gravado na base de dados.");
define("DBLAN_2", "Clique para efectuar um backup da sua base de dados do e107");
define("DBLAN_3", "Efectuar backup da base de dados SQL");
define("DBLAN_4", "Clique para verificar a validade da base de dados do e107");
define("DBLAN_5", "Verificar validade da base de dados");
define("DBLAN_6", "Clique para optimizar a base de dados do e107");
define("DBLAN_7", "Optimizar a base de dados SQL");
define("DBLAN_8", "Clique para efectuar um backup das suas definições de sistema");
define("DBLAN_9", "Backup das definições de sistema");
define("DBLAN_10", "Utilitários da base de dados");
define("DBLAN_11", "Base de dados MySQL");
define("DBLAN_12", "optimizada");
define("DBLAN_13", "Voltar");
define("DBLAN_14", "Efectuado");
define("DBLAN_15", "Clique para verificar a disponibilidade de actualizações para a BD");
define("DBLAN_16", "Verificar actualizações");

?>