<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Seleccione o idioma a verificar");
define("LAN_CHECK_2", "Iniciar verificação");
define("LAN_CHECK_3", "Verificação de ");
define("LAN_CHECK_4", "Ficheiro em falta!");
define("LAN_CHECK_5", "Frase em falta!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "Frase");

define("LAN_CHECK_8", "Existe um ficheiro em falta...");
define("LAN_CHECK_9", " ficheiros em falta...");
define("LAN_CHECK_10", "Erro crítico: ");
define("LAN_CHECK_11", "Não foram detectados ficheiros em falta!");
define("LAN_CHECK_12", "Existe um ficheiro errado...");
define("LAN_CHECK_13", " ficheiros errados...");
define("LAN_CHECK_14", "Todos os ficheiros foram validados!");

?>
