<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/07 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Acção");
define("LAN_UPDATE_3", "Não necessária");

define("LAN_UPDATE_5", "Actualização disponivel"); //Update available
define("LAN_UPDATE_7", "Executado");
define("LAN_UPDATE_8", "Actualizar desde");
define("LAN_UPDATE_9", "para");
define("LAN_UPDATE_10", "Actualizações disponivieis"); //Available updates
define("LAN_UPDATE_11", "Actualização de .617 para .7");

?>