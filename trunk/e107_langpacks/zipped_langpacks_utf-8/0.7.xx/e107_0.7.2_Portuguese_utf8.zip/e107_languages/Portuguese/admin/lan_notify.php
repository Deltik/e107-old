<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Notificações");
define("NT_LAN_2", "Receber notificações de email para");
define("NT_LAN_3", "Desligado");
define("NT_LAN_4", "Admin principal");
define("NT_LAN_5", "Classe");
define("NT_LAN_6", "Email");

define("NU_LAN_1", "Eventos de utilizador");
define("NU_LAN_2", "Registo de utilizador");
define("NU_LAN_3", "Verificação de conta do utilizador");
define("NU_LAN_4", "Login de utilizador");
define("NU_LAN_5", "Logout de utilizador");

define("NS_LAN_1", "Eventos de segurança");
define("NS_LAN_2", "IP banido por flooding no site");

define("NN_LAN_1", "Eventos de notícias");
define("NN_LAN_2", "Notícia submetida pelo utilizador");
define("NN_LAN_3", "Notícia publicada pelo administrador");
define("NN_LAN_4", "Notícia editada pelo administrador");
define("NN_LAN_5", "Notícia apagada pelo administrador");

?>