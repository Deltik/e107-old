<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Navegação do administrador");
define("LAN_head_2", "O seu servidor não suporta transferências de ficheiros por HTTP, como tal não será possivel aos utilizadores transferirem os seus avatars, ficheiros, etc. Para rectificar esta situação, deverá alterar o seu ficheiro php.ini colocando a opção 'file_uploads' em 'on' e reiniciar o seu servidor. Se não tem acesso ao ficheiro php.ini deverá contactar o administrador do servidor onde o site está alojado.");
define("LAN_head_3", "O seu servidor está a correr com restrições na directoria principal. Esta situação não permite a utilização de qualquer ficheiro fora da directoria principal e poderá afectar determinados scripts tais como o gestor de ficheiros.");

define("LAN_head_4", "Área de administração");

define("LAN_head_5", "Idioma mostrado na área de administração: ");
define("LAN_head_6", "Informação de plugins");

?>