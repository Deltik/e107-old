<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Etiquetas meta actualizadas na base de dados");
define("METLAN_2", "Introduzir etiquetas meta adicionais");
define("METLAN_3", "Introduzir novas definições de etiquetas meta");
define("METLAN_4", "Actualizado");
define("METLAN_5", "Insira a descrição do seu site");
define("METLAN_6", "Insira uma, lista, com, as, suas, palavras, chave");
define("METLAN_7", "Insira a informação de Copyright");
define("METLAN_8", "Etiquetas meta");

define("METLAN_9", "Descrição");
define("METLAN_10", "Palavras chave");
define("METLAN_11", "Copyright");

?>