<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda = Página Principal";
$text = "A partir desta página poderá escolher o tipo de conteúdo que será mostrado na página principal do seu site, por defeito são notícias.";
$ns -> tablerender($caption, $text);
?>