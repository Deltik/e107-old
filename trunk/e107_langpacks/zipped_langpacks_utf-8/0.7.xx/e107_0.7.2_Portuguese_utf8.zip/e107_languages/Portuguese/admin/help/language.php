<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Ao definir um novo idioma, irá permitir que seja disponibilizado no seu site uma versão do seu conteúdo nessa lingua.";
$ns -> tablerender("Ajuda = Idiomas", $text);
?>