<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Definições da página principal gravadas");
define("FRTLAN_2", "Definir página principal para");
define("FRTLAN_6", "Links");
// define("FRTLAN_7", "Página de conteúdo");
define("FRTLAN_12", "Actualizar definições da página principal");
define("FRTLAN_13", "Definições da página principal");
define("FRTLAN_15", "Outro (escreva URL):");
define("FRTLAN_16", "Erro: Não foi seleccionada uma categoria principal de conteúdo");
define("FRTLAN_17", "Erro: Não foi seleccionada uma sub-categoria de conteúdo");
define("FRTLAN_18", "Erro: Não foi seleccionado um item de conteúdo");
define("FRTLAN_19", "Categoria principal de conteúdo");
define("FRTLAN_20", "Sub-categoria de conteúdo");
define("FRTLAN_21", "Item de conteúdo");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Todos os utilizadores");
define("FRTLAN_27", "Visitantes");
define("FRTLAN_28", "Membros");
define("FRTLAN_29", "Administradores");
define("FRTLAN_31", "Todos os utilizadores");
define("FRTLAN_32", "Classe de utilizadores");
define("FRTLAN_33", "Definições actuais");
define("FRTLAN_34", "Página");

?>