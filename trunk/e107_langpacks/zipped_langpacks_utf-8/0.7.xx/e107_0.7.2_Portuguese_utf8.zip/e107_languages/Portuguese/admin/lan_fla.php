<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Tentativas falhadas de login");
define("FLALAN_2", "Não foram registadas tentativas falhadas de login");
define("FLALAN_3", "Tentativa(s) apagada(s)");
define("FLALAN_4", "O utilizador tentou aceder com um login/password incorrecto.");
define("FLALAN_5", "IP's banidos");
define("FLALAN_6", "Data");
define("FLALAN_7", "Dados");
define("FLALAN_8", "Endereço IP / Host");
define("FLALAN_9", "Opções");
define("FLALAN_10", "Apagar / Banir itens marcados");
define("FLALAN_11", "Marcar todas as caixas 'APAGAR'");
define("FLALAN_12", "Desmarcar todas as caixas 'APAGAR'");
define("FLALAN_13", "Marcar todas as caixas 'BANIR'");
define("FLALAN_14", "Desmarcar todas as caixas 'BANIR'");
define("FLALAN_15", "Os seguintes endereços de IP foram banidos automáticamente - Mais de 10 tentativas falhadas de login");
define("FLALAN_16", "Apagar lista de bans automáticos");
define("FLALAN_17", "Lista de bans automáticos apagada");

?>