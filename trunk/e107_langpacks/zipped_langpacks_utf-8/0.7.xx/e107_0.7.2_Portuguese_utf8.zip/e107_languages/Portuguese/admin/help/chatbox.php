<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "As definições da sua chatbox poderão ser ajustadas a partir deste ecrã.<br />Se a caixa 'substituir links' estiver seleccionada, quaisquer links introduzidos serão substituidos pelo texto inserido no campo respectivo. Desta forma evita que os links muito longos causem problemas de visualização aos utilizadores. A opção 'Cortar palavras' irá separar as palavras que ultrapassem o comprimento especificado.";

$ns -> tablerender("Ajuda = Chatbox", $text);
?>