<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Nesta página pode definir as votações/sondagens a incluir no seu site. Apenas necessita de incluir o título da votação, as opções e prever - quando tudo estiver a seu gosto basta seleccionar a caixa para activá-la.<br /><br />
Para mostrar a votação, vá á sua página de menus e certifique-se que as votações estão activadas.";

$ns -> tablerender("Ajuda = Votações", $text);
?>