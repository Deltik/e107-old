<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00","não foi criado (já existe).");
define("LANG_LAN_01","foi removido (se existia) e criado.");
define("LANG_LAN_02","não pode ser apagado.");
define("LANG_LAN_03","Tabelas");

define("LANG_LAN_05","Não instalado");
define("LANG_LAN_06", "Criar tabelas");
define("LANG_LAN_07", "Eliminar tabelas existentes?");
define("LANG_LAN_08", "Substituir tabelas existentes (os dados serão perdidos).");
define("LANG_LAN_10", "Confirmar eliminação");
define("LANG_LAN_11", "Apagar tabelas não marcadas acima (caso existam).");
define("LANG_LAN_12", "Activar tabelas multi-idioma");
define("LANG_LAN_13", "Definições multi-idioma");
define("LANG_LAN_14", "Idioma por defeito");
define("LANG_LAN_15", "Seleccione para copiar os dados do idioma pré-definido (útil para links, categorias de notícias, etc.) ");

?>