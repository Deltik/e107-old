<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda = Classes de utilizadores";
$text = "Nesta página poderá criar e editar/apagar classes de utilizadores.<br />Esta opção é útil para restringir o acesso dos utilizadores a determinadas secções do seu site. Por exemplo, poderá criar uma classe entitulada TESTE e associá-la a uma determinada secção do fórum, que só permitirá o acesso aos utilizadores pertencentes a esta classe.";
$ns -> tablerender($caption, $text);
?>