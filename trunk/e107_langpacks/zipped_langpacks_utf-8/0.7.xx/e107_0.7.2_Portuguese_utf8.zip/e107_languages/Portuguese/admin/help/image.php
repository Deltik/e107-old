<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Nesta seção poderá permitir/desabilitar a publicação de imagens dos utilizadores no seu site, definir o método de alteração automática do seu tamanho e visualizar os avatars transferidos para o seu sites.";
$ns -> tablerender("Ajuda = Imagens", $text);
?>