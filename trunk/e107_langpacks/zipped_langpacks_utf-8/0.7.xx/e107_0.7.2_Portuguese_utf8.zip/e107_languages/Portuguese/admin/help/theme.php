<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2005/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "O gestor de temas permite definir o tema utilizado no seu site e na área de aministração.";
$ns -> tablerender("Ajuda = Gestor de temas", $text);
?>