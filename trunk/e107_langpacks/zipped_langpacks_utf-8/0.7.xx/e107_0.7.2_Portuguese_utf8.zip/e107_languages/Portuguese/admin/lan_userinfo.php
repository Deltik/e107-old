<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Não foi possível encontrar o endereço de IP do utilizador - não existe informação disponivel.");
// define("USFLAN_2", "Erro");
define("USFLAN_3", "Mensagens enviadas deste endereço de IP");
define("USFLAN_4", "Servidor"); //Host
define("USFLAN_5", "Clique aqui para transferir o endereço de IP para a página de administração > banir");
define("USFLAN_6", "ID do utilizador");
define("USFLAN_7", "Informação do utilizador");

?>