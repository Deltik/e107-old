<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/08 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Definições de manutenção actualizadas");
define("UGFLAN_2", "Activar manutenção"); //Activate maintenance flag
define("UGFLAN_3", "Actualizar definições de manutenção");
define("UGFLAN_4", "Definições de manutenção");

define("UGFLAN_5", "Texto mostrado quando o site estiver inacessível");
define("UGFLAN_6", "Deixe em branco para mostrar a mensagem por defeito");

?>