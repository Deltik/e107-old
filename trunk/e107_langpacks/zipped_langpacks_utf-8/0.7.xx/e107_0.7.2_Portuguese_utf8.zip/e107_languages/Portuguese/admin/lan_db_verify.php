<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/02/07 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Não foi possível efectuar a leitura do ficheiro de dados SQL<br /><br />Por favor certifique-se que o ficheiro <b>core_sql.php</b> existe na directoria <b>/admin/sql</b>.");
define("DBLAN_2", "A verificar tudo");

define("DBLAN_4", "Tabela");
define("DBLAN_5", "Campo");
define("DBLAN_6", "Estado");
define("DBLAN_7", "Notas");
define("DBLAN_8", "Diferença"); //Mismatch
define("DBLAN_9", "Actualmente");
define("DBLAN_10", "Deveria ser");
define("DBLAN_11", "Campo em falta");
define("DBLAN_12", "Campo a mais!");
define("DBLAN_13", "Tabela em falta!");
define("DBLAN_14", "Escolha a(s) tabela(s) a validar");
define("DBLAN_15", "Iniciar verificação");
define("DBLAN_16", "Verificação do SQL");
define("DBLAN_17", "Voltar");
define("DBLAN_18", "tabelas");
define("DBLAN_19", "Tentativa de reparação");
define("DBLAN_20", "Tentativa de reparação das tabelas");
define("DBLAN_21", "Reparar itens seleccionados");
?>