<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Pode separar os seus links em diferentes categorias. Desta forma irá facilitar a navegação na página principal de links e ao mesmo tempo melhorar substancialmente o layout/esquema da página.<br /><br />Qualquer link inserido na categoria principal será mostrado no menu principal de navegação.";
$ns -> tablerender("Ajuda = Categoria de Links", $text);
?>