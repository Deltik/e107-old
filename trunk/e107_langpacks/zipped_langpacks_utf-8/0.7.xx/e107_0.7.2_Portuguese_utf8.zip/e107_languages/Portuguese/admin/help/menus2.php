<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda = Menus";
$text .= "Aqui poderá modificar a localização e a ordem pela qual os seus menus são visualizados. Utilize as setas para mover os menus para cima/baixo até ficar satisfeito com o seu posicionamento.<br />
Os menus mostrados no centro do ecrã encontram-se desactivados, poderá torná-los activos escolhendo uma localização para os colocar.
";

$ns -> tablerender("Ajuda = Menus", $text);
?>