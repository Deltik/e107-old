<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "A partir deste ecrã poderá criar menus e páginas personalizadas com o seu próprio conteúdo.<br /><br />
Por favor visite <a href='http://docs.e107.org?Custom Pages'>http://docs.e107.org?Custom Pages</a>";

$ns -> tablerender(CUSLAN_18, $text);
?>