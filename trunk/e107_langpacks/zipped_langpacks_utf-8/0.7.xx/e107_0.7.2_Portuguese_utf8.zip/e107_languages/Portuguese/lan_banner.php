<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/24 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Anúncios");

define("LAN_16", "Utilizador: ");
define("LAN_17", "Password: ");
define("LAN_18", "Continuar");
define("LAN_19", "Por favor insira o seu login e password para continuar");
define("LAN_20", "Lamentamos, os detalhes fornecidos não constam na base de dados. Por favor contacte o administrador do site para mais informações.");
define("LAN_21", "Estatísticas de anúncios");
define("LAN_22", "Cliente");
define("LAN_23", "ID Anúncio");
define("LAN_24", "Visitas"); //Clickthroughs
define("LAN_25", "% Visitas");
define("LAN_26", "Publicações");
define("LAN_27", "Publicações adquiridas");
define("LAN_28", "Publicações em falta");
define("LAN_29", "Sem anúncios");
define("LAN_30", "Ilimitado");
define("LAN_31", "Não aplicável");
define("LAN_32", "Sim");
define("LAN_33", "Não");
define("LAN_34", "Termina:");
define("LAN_35", "Endereços IP visitantes"); //Clickthrough IP addresses
define("LAN_36", "Activo:");
define("LAN_37", "Início:");
define("LAN_38", "Erro");

?>