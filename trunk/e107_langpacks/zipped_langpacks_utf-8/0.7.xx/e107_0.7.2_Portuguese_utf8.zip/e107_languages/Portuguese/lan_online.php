<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
//v.616
define("ONLINE_EL1", "Visitantes: ");
define("ONLINE_EL2", "Membros: ");
define("ONLINE_EL3", "Nesta página: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Membros");
define("ONLINE_EL6", "Novo membro");
define("ONLINE_EL7", "ver");
define("ONLINE_EL8", "Máximo online: ");
define("ONLINE_EL9", "em");
define("ONLINE_EL10", "Nome");
define("ONLINE_EL11", "Ver página");
define("ONLINE_EL12", "A responder");
define("ONLINE_EL13", "Fórum");
define("ONLINE_EL14", "Tópico");
define("ONLINE_EL15", "Página");
define("CLASSRESTRICTED", "Página restrita");
define("ARTICLEPAGE", "Artigo/Revisão");
define("CHAT", "Chat");
define("COMMENT", "Comentários");
define("DOWNLOAD", "Downloads");
define("EMAIL", "Email");
define("FORUM", "Índice fórum");
define("LINKS", "Links");
define("NEWS", "Notícias");
define("OLDPOLLS", "Votações antigas");
define("POLLCOMMENT", "Votações");
define("PRINTPAGE", "Imprimir");
define("LOGIN", "Ligar");
define("SEARCH", "Pesquisar");
define("STATS", "Estatísticas");
define("SUBMITNEWS", "Submeter notícia");
define("UPLOAD", "Uploads");
define("USERPAGE", "Perfil utilizador");
define("USERSETTINGS", "Definições utilizador");
define("ONLINE", "Utilizadores online");
define("LISTNEW", "Lista de novos itens");
define("USERPOSTS", "Mensagens utilizador");
define("SUBCONTENT", "Submeter artigos/revisões");
define("TOP", "Top utilizadores");
define("ADMINAREA", "Área de admin");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Lista eventos");
define("CALENDAR", "Calendário eventos");
define("FAQ", "FAQ");
define("PM", "Mensagens privadas");
define("SURVEY", "Sondagem");
define("ARTICLE", "Artigo");
define("CONTENT", "Conteúdo");
define("REVIEW", "Revisão");

?>