<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Registo de utilizador");

define("NT_LAN_UV_1", "Registo verificado");
define("NT_LAN_UV_2", "Registos das sessões dos utilizadores"); //Users session string

define("NT_LAN_LI_1", "Utilizador ligado");

define("NT_LAN_LO_1", "Utilizador desligado");
define("NT_LAN_LO_2", " desligou-se do site");

define("NT_LAN_FL_1", "Ban por flood");
define("NT_LAN_FL_2", "Endereço de IP banido por flooding");

define("NT_LAN_SN_1", "Notícias submetidas");

define("NT_LAN_NU_1", "Actualizado");

define("NT_LAN_ND_1", "Notícias apagadas");
define("NT_LAN_ND_2", "ID das notícias apagadas");

?>