<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2005/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Produzido pelo sistema e107");
define("LANMAILH_2", "Esta é uma mensagem combinada no formato MIME.");
define("LANMAILH_3", " não está formatado convenientemente");
define("LANMAILH_4", "O servidor rejeitou o endereço");
define("LANMAILH_5", "O servidor não respondeu");
define("LANMAILH_6", "Não foi possivel encontrar o servidor de email.");
define("LANMAILH_7", " aparenta ser válido.");

?>