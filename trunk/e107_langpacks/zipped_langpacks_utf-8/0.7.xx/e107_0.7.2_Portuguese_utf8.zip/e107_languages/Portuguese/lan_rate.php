<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("RATELAN_0", "voto");
define("RATELAN_1", "votos");
define("RATELAN_2", "Qual a avaliação que atribui a este item?");
define("RATELAN_3", "Obrigado pelo seu voto");
define("RATELAN_4", "Sem avaliação");
define("RATELAN_5", "Avaliar");

?>