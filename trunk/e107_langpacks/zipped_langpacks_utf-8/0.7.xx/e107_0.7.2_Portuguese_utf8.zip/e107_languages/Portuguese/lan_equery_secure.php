<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/24 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Está a ser redireccionado para uma função de administração, poderão ocorrer possíveis modificações na base de dados");
define("EQSEC_LAN2", "Por favor confirme esta acção:");
define("EQSEC_LAN3", "Link não referenciado"); //No referer
define("EQSEC_LAN4", "Acção de:");
define("EQSEC_LAN5", "Acção para:");
define("EQSEC_LAN6", "Confirmar acção");
define("EQSEC_LAN7", "Ou cancelar");
?>