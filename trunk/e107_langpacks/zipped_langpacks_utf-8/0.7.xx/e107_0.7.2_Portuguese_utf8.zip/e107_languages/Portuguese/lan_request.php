<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_dl_61", "Erro no download");
define("LAN_dl_62", "Foi impedido de efectuar o download deste ficheiro, a sua quota foi excedida");
define("LAN_dl_63", "Não tem as permissões correctas para efectuar o download deste ficheiro.");
define("LAN_dl_64", "Voltar");
define("LAN_dl_65", "Ficheiro não encontrado");

?>