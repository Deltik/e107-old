<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "Top fórum");
define("TOP_LAN_1", "Utilizador");
define("TOP_LAN_2", "Mensagens");
define("TOP_LAN_3", "Top comentários");
define("TOP_LAN_4", "Comentários");
define("TOP_LAN_5", "Top chatbox");
define("TOP_LAN_6", "Avaliação do site");

//v.616
define("LAN_1", "Tópico");
define("LAN_2", "Autor");
define("LAN_3", "Visualizações");
define("LAN_4", "Respostas");
define("LAN_5", "Último");
define("LAN_6", "Tópicos");
define("LAN_7", "Tópicos mais activos");
define("LAN_8", "Top autores");

?>