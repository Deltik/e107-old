<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Notícia apagada.");
define("NWSLAN_2", "Seleccione a caixa de confirmação para apagar esta notícia.");
define("NWSLAN_3", "Aínda não existem notícias.");
define("NWSLAN_4", "Notícias existentes");
define("NWSLAN_5", "Abrir editor HTML");
define("NWSLAN_6", "Categoria");
define("NWSLAN_7", "Editar");
define("NWSLAN_8", "Apagar");
define("NWSLAN_9", "Seleccionar para confirmar");
define("NWSLAN_10", "Aínda não foram definidas categorias.");
define("NWSLAN_11", "Adicionar/Editar categorias");
define("NWSLAN_12", "Título");
define("NWSLAN_13", "Conteúdo");
define("NWSLAN_14", "Extensão");
define("NWSLAN_15", "Comentários");
define("NWSLAN_16", "Activado");
define("NWSLAN_17", "Desactivado");
define("NWSLAN_18", "Permitir o envio de comentários para esta notícia");
define("NWSLAN_19", "Activação");
define("NWSLAN_20", "Deixe em branco para desligar a auto-activação");
define("NWSLAN_21", "Activar entre");
define("NWSLAN_22", "Visibilidade");
define("NWSLAN_23", "Ao seleccionar fará com que a notícia apenas seja visualizada por utilizadores desta classe");
define("NWSLAN_24", "Prever novamente");
define("NWSLAN_25", "Actualizar notícia na base de dados");
define("NWSLAN_26", "Publicar notícia na base de dados");
define("NWSLAN_27", "Prever");
define("NWSLAN_28", "Nova notícia"); //new history (or news.item?)
define("NWSLAN_29", "Envio de notícias");

define("NWSLAN_30", "Mostrar apenas título");

?>