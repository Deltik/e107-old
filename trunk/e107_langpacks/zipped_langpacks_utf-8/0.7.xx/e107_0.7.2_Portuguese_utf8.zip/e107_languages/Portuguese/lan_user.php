<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Membros");

define("LAN_20", "Erro");
define("LAN_112", "Endereço email");
define("LAN_115", "Número ICQ");
define("LAN_116", "Endereço AIM");
define("LAN_117", "MSN messenger");
define("LAN_118", "Data nascimento");
define("LAN_119", "Local");
define("LAN_120", "Assinatura");
define("LAN_137", "Não existe informação acerca do utilizador uma vez que este não se encontra registado em");
define("LAN_138", "Membros registados: ");
define("LAN_139", "Ordenar: ");
define("LAN_140", "Membros registados");
define("LAN_141", "Aínda não existem membros registados.");
define("LAN_142", "Membro");
define("LAN_143", "[oculto]");
define("LAN_144", "Página web");
define("LAN_145", "Data registo");
define("LAN_146", "Número de visitas desde o registo");
define("LAN_147", "Mensagens chatbox");
define("LAN_148", "Comentários");
define("LAN_149", "Mensagens fórum");
define("LAN_308", "Nome verdadeiro");
define("LAN_400", "Este utilizador é inválido.");
define("LAN_401", "Sem informaçãp");
define("LAN_402", "Perfil do membro");
define("LAN_403", "Estatísticas do site");
define("LAN_404", "Última visita");
define("LAN_405", "dias atrás");
define("LAN_406", "Votação");
define("LAN_407", "Não tem"); //none
define("LAN_408", "Sem foto");
define("LAN_409", "Pontos");
define("LAN_410", "Vários"); //Miscellaneous
define("LAN_411", "Clique aqui para actualizar a sua informação");
define("LAN_412", "Clique aqui para editar a informação deste utilizador");
define("LAN_413", "Apagar foto");
define("LAN_414", "Membro anterior");
define("LAN_415", "Membro seguinte");
define("LAN_416", "Necessita de efectuar o login para aceder a esta página");
define("LAN_417", "Administrador principal");
define("LAN_418", "Administrador");
define("LAN_419", "Mostrar");
define("LAN_420", "DESC");
define("LAN_421", "ASC");
define("LAN_422", "Ir");
define("LAN_423", "Ver os comentários deste utilizador");
define("LAN_424", "Ver as mensagens no fórum deste utilizador");
define("LAN_425", "Enviar Mensagem Privada");
define("LAN_426", "atrás"); //ago

define("USERLAN_1", "Avaliação do Peer"); //Peer Rating

?>