<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "Website e107");
define("LAN_PREF_2", "Portal de Gestão e107");
define("LAN_PREF_3", "Este site é gerido pelo sistema <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, que foi disponibilizado sob os termos da Licença <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL.");
define("LAN_PREF_4", "Censurado");
define("LAN_PREF_5", "Fóruns");

?>