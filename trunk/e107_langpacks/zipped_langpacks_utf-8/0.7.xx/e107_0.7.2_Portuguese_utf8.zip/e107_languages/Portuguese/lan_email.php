<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/24 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Email");

define("LAN_5", "Enviar artigo a um amigo");
define("LAN_6", "Enviar notícia a um amigo");
define("LAN_7", "Nome Login: ");
define("LAN_8", "Comentário");
define("LAN_9", "Lamentamos - não foi possivel enviar o email");
define("LAN_10", "Email enviado para");
define("LAN_11", "Email enviado");
define("LAN_12", "Erro");
define("LAN_106", "Não aparenta ser um endereço de email válido");
define("LAN_185", "Enviar artigo");
define("LAN_186", "Enviar notícia");
define("LAN_187", "Endereço de email do destinatário");
define("LAN_188", "Pensei que poderias estar interessado nesta notícia de");
define("LAN_189", "Pensei que poderias estar interessado neste artigo de");

define("LAN_email_1", "De:");
define("LAN_email_2", "Endereço IP do remetente:");
define("LAN_email_3", "Notícia enviada por ");
define("LAN_email_4", "Enviar email");
define("LAN_email_5", "Enviar este item por email a um amigo");
define("LAN_email_6", "Pensei que poderias estar interessado neste item de");

?>