<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/24 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'pt_PT'); // [pt_PT.utf-8]??
define("CORE_LC", 'pt');
define("CORE_LC2", 'pt');
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","Erro: O tema está em falta.\\n\\nDeverá alterar os temas em utilização (Área de admin > Definições) ou efectuar a transferência para o servidor dos ficheiros relativos ao tema corrente.");

//v.616
define("CORE_LAN2"," \\1 escreveu:");// "\\1" represents the username.
define("CORE_LAN3","Transferência de ficheiros desactivada");
?>