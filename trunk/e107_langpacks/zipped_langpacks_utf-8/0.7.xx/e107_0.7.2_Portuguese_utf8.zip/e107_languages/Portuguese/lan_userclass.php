<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Todos (público)");
define("UC_LAN_1", "Visitantes");
define("UC_LAN_2", "Nenhum (inactivo)");
define("UC_LAN_3", "Membros");
define("UC_LAN_4", "Apenas leitura");
define("UC_LAN_5", "Administrador");
?>