<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2005/11/30 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Mensagens de utilizador");

define("UP_LAN_0", "Todas as mensagens no fórum de ");
define("UP_LAN_1", "Todos os comentários de ");
define("UP_LAN_2", "Tópico");
define("UP_LAN_3", "Visualizações");
define("UP_LAN_4", "Respostas");
define("UP_LAN_5", "Última");
define("UP_LAN_6", "Tópicos");
define("UP_LAN_7", "Sem comentários");
define("UP_LAN_8", "Sem mensagens");
define("UP_LAN_9", " em ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Publicado em");
define("UP_LAN_12", "Pesquisar");
define("UP_LAN_13", "Comentários");
define("UP_LAN_14", "Mensagens fórum");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "Endereço IP");
?>