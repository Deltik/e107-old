<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vista para impressão");

define("LAN_86", "Categoria:");
define("LAN_87", "por ");
define("LAN_94", "Submetido por");
define("LAN_135", "Notícias: ");
define("LAN_303", "Esta notícia é proveniente de ");
define("LAN_304", "Título: ");
define("LAN_305", "Cabeçalho: ");
define("LAN_306", "Este artigo é de: ");
define("LAN_307", "Imprimir esta página");

?>