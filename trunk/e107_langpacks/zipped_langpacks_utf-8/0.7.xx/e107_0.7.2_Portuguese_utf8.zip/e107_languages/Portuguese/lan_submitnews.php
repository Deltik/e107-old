<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Submeter notícias");
define("LAN_7", "Utilizador: ");
define("LAN_62", "Assunto: ");
define("LAN_112", "Email: ");
define("LAN_133", "Obrigado");
define("LAN_134", "A sua notícia foi enviada e será revista por um administrador.");
define("LAN_135", "Notícia: ");
define("LAN_136", "Submeter notícia");
define("NWSLAN_6", "Categoria");
define("NWSLAN_10", "Não estão definidas categorias");
define("NWSLAN_11", "Não tem acesso a esta área.");
define("NWSLAN_12", "Acesso negado.");

define("SUBNEWSLAN_1", "Necessita de indicar um título.\\n");
define("SUBNEWSLAN_2", "Necessita de incluir algum texto na notícia.\\n");
define("SUBNEWSLAN_3", "O seu anexo pode ser um ficheiro do tipo jpg, gif ou png");
define("SUBNEWSLAN_4", "Ficheiro muito grande");
define("SUBNEWSLAN_5", "Ficheiro de imagem");
define("SUBNEWSLAN_6", "(jpg, gif ou png)");

?>