<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LAN_183", "Menu Principal");
define("LAN_502", "Administração");

?>