<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/26 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "O tipo de ficheiro");
define("LANUPLOAD_2", "não é permitido e foi apagado.");
define("LANUPLOAD_3", "Transferência efectuada");
define("LANUPLOAD_4", "A directoria de destino não existe ou não tem permissões de escrita (CHMOD 777).");
define("LANUPLOAD_5", "O ficheiro transferido excede o tamanho máximo definido no php.ini (upload_max_filesize).");
define("LANUPLOAD_6", "O ficheiro transferido excede o tamanho máximo definido pelo administrador (MAX_FILE_SIZE).");
define("LANUPLOAD_7", "A transferência foi parcialmente efectuada.");
define("LANUPLOAD_8", "A transferência não foi efectuada.");
define("LANUPLOAD_9", "O tamanho da transferência foi de 0 bytes");
define("LANUPLOAD_10", "A transferência falhou [ficheiro duplicado] - Já existe um ficheiro com o mesmo nome.");
define("LANUPLOAD_11", "A transferência não foi efectuada. Nome ficheiro: ");
define("LANUPLOAD_12", "Erro");

?>