<?php
/*
+----------------------------------------------------------------------------+
|     e107 website system - PT Language File.
|
|     $Revision: 1.0 $
|     $Date: 2006/01/25 $
|     $Author: X-fact0r $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Links");

define("LAN_61", "Categorias de links");
define("LAN_62", "Categorias");
define("LAN_63", "Categoria");
define("LAN_64", "nesta categoria");
define("LAN_65", "link");
define("LAN_66", "links");
define("LAN_67", "Mostrar Todos os Links");
define("LAN_68", "Editar");
define("LAN_69", "Apagar");
define("LAN_86", "Categoria:");
define("LAN_88", "Referências:");
define("LAN_89", "Admin: ");
define("LAN_90", "Adicionar link a esta categoria");
define("LAN_91", "Adcionar categoria");

define("LAN_92", "Submeter link");
define("LAN_93", "Após submeter o seu link, este será revisto por um administrador do site e adicionado à página principal de links, na eventualidade de o conteúdo ser considerado apropriado.");
define("LAN_94", "Nome do link:");
define("LAN_95", "URL do link:");
define("LAN_96", "Descrição do link:");
define("LAN_97", "URL do botão do link:");
define("LAN_98", "Submeter link");

define("LAN_99", "Obrigado");
define("LAN_100", "O seu link foi gravado e será revisto por um dos administradores do site.");
define("LAN_101", "Clique aqui para submeter um link");

define("LAN_102", "Existem");
define("LAN_103", ""); //is
define("LAN_104", ""); //are
define("LAN_105", "no total em"); //total in
define("LAN_106", "Os campos sublinhados são obrigatórios.");

define("LAN_Links_1", "Total de links");
define("LAN_Links_2", "Total de links activados");
define("LAN_LINKS_3", "Anónimo");
?>