/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/emoticons/langs/es.js,v $
|     $Revision: 1.4 $
|     $Date: 2006/05/16 19:52:10 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

tinyMCELang['lang_insert_emotions_title'] = 'Inserta emoticono';
tinyMCELang['lang_emotions_desc'] = 'Emoticonos';

