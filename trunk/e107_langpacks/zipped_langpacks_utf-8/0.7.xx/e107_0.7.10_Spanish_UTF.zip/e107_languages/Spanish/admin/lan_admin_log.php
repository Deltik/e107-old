<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/17 10:47:07 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Registro del Admin");
define("LAN_ADMINLOG_1", "Fecha");
define("LAN_ADMINLOG_2", "Título");
define("LAN_ADMINLOG_3", "Descripción");
define("LAN_ADMINLOG_4", "Usuario IP");
define("LAN_ADMINLOG_5", "Usuario ID");
define("LAN_ADMINLOG_6", "Icono informativo");
define("LAN_ADMINLOG_7", "Mensaje informativo");
define("LAN_ADMINLOG_8", "Icono aviso");
define("LAN_ADMINLOG_9", "Mensaje aviso");
define("LAN_ADMINLOG_10", "Icono de alarma");
define("LAN_ADMINLOG_11", "Mensaje de alarma");
define("LAN_ADMINLOG_12", "Icono Fatídico");
define("LAN_ADMINLOG_13", "Mensaje de error fatídico");
?>
