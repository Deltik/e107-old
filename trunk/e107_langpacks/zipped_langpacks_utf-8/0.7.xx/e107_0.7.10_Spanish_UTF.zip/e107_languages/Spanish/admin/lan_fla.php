<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_fla.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Fallo en los intentos de conexión");
define("FLALAN_2", "No se han registrado fallos de conexión");
define("FLALAN_3", "Intento(s) eliminado(s)");
define("FLALAN_4", "Un usuario intentó conectar con un nombre o contraseña incorrectas");
define("FLALAN_5", "IP(s) expulsado(s)");

define("FLALAN_6", "Fecha");
define("FLALAN_7", "Datos");
define("FLALAN_8", "IP dirección / Servidor");
define("FLALAN_9", "Opciones");
define("FLALAN_10", "Eliminar / expulsar entradas marcadas");
define("FLALAN_11", "Marca todas la cajas de eliminación");
define("FLALAN_12", "Desmarca todas las cajas de eliminación");
define("FLALAN_13", "Marca todas las cajas de expulsión");
define("FLALAN_14", "Desmarca todas las cajas de expulsión");
define("FLALAN_15", "La(s) siguiente(s) IP(s) han sido autoexpulsadas - El usuario intentó la conexión más de 10 veces");
define("FLALAN_16", "Eliminar esta lista de auto-expulsados");
define("FLALAN_17", "Lista de auto-expulsados eliminada");

?>