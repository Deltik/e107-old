<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_np.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("NP_1", "Página anterior");
define("NP_2", "Página siguiente");
define("NP_3", "Ir a la página");

?>