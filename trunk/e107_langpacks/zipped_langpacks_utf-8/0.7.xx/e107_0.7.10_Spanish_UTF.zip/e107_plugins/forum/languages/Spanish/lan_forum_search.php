<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Spanish/lan_forum_search.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/16 13:46:23 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Foro");
define("FOR_SCH_LAN_2", "Seleccionar foro");
define("FOR_SCH_LAN_3", "Todos los foros");
define("FOR_SCH_LAN_4", "Todo el mensaje");
define("FOR_SCH_LAN_5", "Como parte de un tema");
?>