<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8

|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Bulgarian/lan_prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/25 12:10:32 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "е107 Уебсайт Система");
define("LAN_PREF_2", "e107 Уебсайт Система");
define("LAN_PREF_3", "Този сайт използва <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, който се разпространява с условията залегнали в <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL Лиценза.");
define("LAN_PREF_4", "цензурирано");
define("LAN_PREF_5", "Форуми");

?>