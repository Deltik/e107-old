<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_membersonly.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Само за Потребители");

define("LAN_MEMBERS_0", "зона с ограничен достъп");
define("LAN_MEMBERS_1", "Това е зона с ограничен достъп");
define("LAN_MEMBERS_2","за осигуряване на достъп <a href='login.php'>се логни</a> или");
define("LAN_MEMBERS_3","се регистрирай");
define("LAN_MEMBERS_4","Натисни тук за връщане към заглавната страница");

?>