<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_equery_secure.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Вие ще бъдете пренасочени към администраторска функция, възможно е да се направи промяна в базата данни");
define("EQSEC_LAN2", "Моля, потвърдете:");
define("EQSEC_LAN3", "No referer");
define("EQSEC_LAN4", "Действие от:");
define("EQSEC_LAN5", "Действие към:");
define("EQSEC_LAN6", "Потвърждение");
define("EQSEC_LAN7", "или отказ");
?>
