<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_sitedown.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Сайтът е временно неактивен");
define("LAN_SITEDOWN_00", "е временно неактивен");
define("LAN_SITEDOWN_01", "Сайтът е временно затворен за извършване на профилактика. Моля изчакайте и опитайте отново. Съжаляваме за създаденото неудобство.");
?>