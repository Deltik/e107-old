<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Всеки (public)");
define("UC_LAN_1", "Гости");
define("UC_LAN_2", "Никой (неактивно)");
define("UC_LAN_3", "Потребители");
define("UC_LAN_4", "Само за четене");
define("UC_LAN_5", "Админ");
define("UC_LAN_6", "Главен Администратор");
?>