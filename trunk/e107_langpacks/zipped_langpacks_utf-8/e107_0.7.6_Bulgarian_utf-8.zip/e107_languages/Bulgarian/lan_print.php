<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 83 $
|     $Date: 2006-11-27 14:47:49 +0200 (Mon, 27 Nov 2006) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Изглед за печат");

define("LAN_PRINT_1", "изглед за печат");

define("LAN_PRINT_86", "Категория:");
define("LAN_PRINT_87", "от ");
define("LAN_PRINT_94", "Публикувано от");
define("LAN_PRINT_135", "Новина: ");
define("LAN_PRINT_303", "Новина от ");
define("LAN_PRINT_304", "Заглавие: ");
define("LAN_PRINT_305", "Подзаглавие: ");
define("LAN_PRINT_306", "Това е от: ");
define("LAN_PRINT_307", "Разпечатай тази страница");

?>