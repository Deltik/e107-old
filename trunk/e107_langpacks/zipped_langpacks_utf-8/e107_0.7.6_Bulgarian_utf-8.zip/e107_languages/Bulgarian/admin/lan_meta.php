<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_meta.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/15 15:43:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Мета таговете са обновени");
define("METLAN_2", "Напишете мета тагове");
define("METLAN_3", "Запазване на настройките");
define("METLAN_4", "Обновено");
define("METLAN_5", "напишете описанието тук");
define("METLAN_6", "напиши, списък, от, твоите, ключови, думи, тук");
define("METLAN_7", "напиши твоето copyright инфо тук");
define("METLAN_8", "Мета тагове");

define("METLAN_9", "описание");
define("METLAN_10", "ключови думи");
define("METLAN_11", "copyright");
define("METLAN_12", "Използвай заглавие и обобщение от новини като мета описание на страниците на новини.");
define("METLAN_13", "Автор");

?>
