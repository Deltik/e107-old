<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_footer.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/01/24 16:35:23 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Сайт");
define("FOOTLAN_2", "Главен Админ");
define("FOOTLAN_3", "Версия");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Тема");
define("FOOTLAN_6", "от");
define("FOOTLAN_7", "Инфо");
define("FOOTLAN_8", "Дата на инсталация");
define("FOOTLAN_9", "Сървър");
define("FOOTLAN_10", "хост");
define("FOOTLAN_11", "PHP Версия");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Инфо за сайта");
define("FOOTLAN_14", "Покажи Документация");
define("FOOTLAN_15", "Документация");
define("FOOTLAN_16", "База Данни");
define("FOOTLAN_17", "Чарсет");
?>