<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_e107_update.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/14 16:22:23 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Действие");
define("LAN_UPDATE_3", "Не е необходимо");

define("LAN_UPDATE_5", "Има налични обновявания");
define("LAN_UPDATE_6", "Обнови всичко");
define("LAN_UPDATE_7", "Изпълнен");
define("LAN_UPDATE_8", "Обновяване от");
define("LAN_UPDATE_9", "до");
define("LAN_UPDATE_10", "Достъпни обновявания");
define("LAN_UPDATE_11", ".617 to .7 актуализация");
define("LAN_UPDATE_12", "Някоя от таблиците ви съдържа дублирани записи.");

?>
