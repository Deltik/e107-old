<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_header.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/14 16:59:23 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Навигация");
define("LAN_head_2", "Башият сървър не позволява HTTP добавяне на файлове, така че е възможно потребителите да не могат да добавят файкиве или аватариu. За да го коригирате настройте file_uploads на On в php.ini и рестатртирайте сървъра. Ако нямате достъп до php.ini свържете се с хостинга Ви.");
define("LAN_head_3", "Your server is running with a basedir restriction in effect. This disallows usage of any file outside of your home directory and as such could affect certain scripts such as the filemanager.");

define("LAN_head_4", "Администриране");

define("LAN_head_5", "език за показване в административната част: ");
define("LAN_head_6", "Информация за модулите");

?>
