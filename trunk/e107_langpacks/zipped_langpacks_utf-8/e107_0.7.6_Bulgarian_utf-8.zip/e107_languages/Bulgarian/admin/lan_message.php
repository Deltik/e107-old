<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/15 15:39:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Получени съобщения");
define("MESSLAN_2", "Изтрити съобщения");
define("MESSLAN_3", "Съобщенията са изтрити.");
define("MESSLAN_4", "Изтриване на всички съобщения");
define("MESSLAN_5", "Потвърждение");
define("MESSLAN_6", "Всички съобщения са изтрити.");
define("MESSLAN_7", "Няма съобщения.");
define("MESSLAN_8", "Вид съобщение");
define("MESSLAN_9", "Докладвано но");

define("MESSLAN_10", "Докладвано от");
define("MESSLAN_11", "отваряне в нов прозорец");
define("MESSLAN_12", "Съпбщение");
define("MESSLAN_13", "Линк");


?>
