<?php
$text = "This collection of tools allows you to manage your database.";
$ns -> tablerender("Database Tools", $text);
?>