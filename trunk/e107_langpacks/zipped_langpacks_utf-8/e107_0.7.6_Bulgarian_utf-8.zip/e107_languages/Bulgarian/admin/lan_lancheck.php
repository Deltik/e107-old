<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_lancheck.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/14 17:09:23 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Изберете език за проверка");
define("LAN_CHECK_2", "Започване на проверка");
define("LAN_CHECK_3", "Проверка на");
define("LAN_CHECK_4", "Файлът липсва!");
define("LAN_CHECK_5", "Липсваща фраза!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "фраза");

define("LAN_CHECK_8", "Файлът липсва...");
define("LAN_CHECK_9", " файлове липсват...");
define("LAN_CHECK_10", "Критична грешка: ");
define("LAN_CHECK_11", "Няма липсващи файлове !");
define("LAN_CHECK_12", "Файлът е грешен...");
define("LAN_CHECK_13", " файла са грешни...");
define("LAN_CHECK_14", "Всички файлове са валидни!");

define("LAN_CHECK_15", "Намерени са символи преди '&lt;?php'");
define("LAN_CHECK_16", "Оригинален файл");
define("LAN_CHECK_17", "Грешка при опит за записване на файла - няма права за писане.");
define("LAN_CHECK_18", "Езикови файлове в стандартния формат НЕ СА налични за тази тема/модул.");
define("LAN_CHECK_19", "Намерен е символ, който не е кодиран в UTF-8!");

?>
