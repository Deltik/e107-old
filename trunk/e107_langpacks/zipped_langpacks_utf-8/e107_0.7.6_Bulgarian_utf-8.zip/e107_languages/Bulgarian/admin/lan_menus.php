<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_mailout.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/15 15:37:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Видимо за всеки");
define("MENLAN_2", "Видимо само за регистрирани");
define("MENLAN_3", "Видимо само за администратори");
define("MENLAN_4", "Да се вижда само от:");
// define("MENLAN_5", "class");
define("MENLAN_6", "Запазване на настройките за виждане");
define("MENLAN_7", "Настройка настройки за виждане на меню");
define("MENLAN_8", "Настройките за виждане са обнвени");
define("MENLAN_9", "Инсталирано е ново потребителско меню");
define("MENLAN_10", "Инсталирано е ново меню");
define("MENLAN_11", "Премахнато меню");
define("MENLAN_12", "Активиране: изберете област");
define("MENLAN_13", "Активиране в област");
define("MENLAN_14", "Област");
define("MENLAN_15", "Деактивиране");
define("MENLAN_16", "Настройки");
define("MENLAN_17", "Премести на горе");
define("MENLAN_18", "Премести на доло");
define("MENLAN_19", "Премести в област");
define("MENLAN_20", "Видимо от");

// define("MENLAN_21", "Visible to Guests only");
define("MENLAN_22", "Не активни менюта");

define("MENLAN_23", "Премести най-доло");
define("MENLAN_24", "Премести най-горе");
define("MENLAN_25", "Функции ...");

define("MENLAN_26", "Това меню ще бъде <strong>ПОКАЗВАНО</strong> само в следните страници");
define("MENLAN_27", "Това меню ще бъде <strong>СКРИТО</strong> само в следните страници");
define("MENLAN_28", "Напишете страниците по една на ред, като е достатъчно да напишите правилния URL. Ако искате да напишите конкретен URL ползвайте ! на края.<br /> Пример: <strong>page.php?1!</strong>");

define("MENLAN_29", "Изберете макет");
define("MENLAN_30", "За да видите областите на макета, моля изберете макте от тук:");
define("MENLAN_31", "Стандартен макет");
define("MENLAN_32", "Newsheader Layout");
define("MENLAN_33", "Потребителски макет");
define("MENLAN_34", "Embedded");
define("MENLAN_35", "Настройка на менютата");
define("MENLAN_36", "Изберете меню/менюта за активиране");
define("MENLAN_37", "и ги активирайте.");
define("MENLAN_38", "Задръжте CTRL за да изберете повече от едно меню.");


?>
