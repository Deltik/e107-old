<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Email");

define("LAN_EMAIL_1", "От:");
define("LAN_EMAIL_2", "IP адрес на подателя:");
define("LAN_EMAIL_3", "Изпратено от ");
define("LAN_EMAIL_4", "Изпрати имейл");
define("LAN_EMAIL_5", "Изпрати на приятел");
define("LAN_EMAIL_6", "Мисля, че ще ти бъде интересно да прочетеш това от");
define("LAN_EMAIL_7", "изпрати на приятел");
define("LAN_EMAIL_8", "Коментар");

define("LAN_EMAIL_9", "Съжаляваме - имейлът не беше изпратен");
define("LAN_EMAIL_10", "Изпратен е имейл до");
define("LAN_EMAIL_11", "Имейлът е изпратен");
define("LAN_EMAIL_12", "Грешка");
define("LAN_EMAIL_13", "Изпрати статия на приятел");
define("LAN_EMAIL_14", "Изпрати новина на приятел");
define("LAN_EMAIL_15", "Потребителско име: ");
define("LAN_EMAIL_106", "Това не изглежда да е валиден имейл адрес");
define("LAN_EMAIL_185", "Изпрати статия");
define("LAN_EMAIL_186", "Изпрати новина");
define("LAN_EMAIL_187", "Изпрати на имейл адрес");
define("LAN_EMAIL_188", "Мисля, че ще ти бъде интересно да прочетеш тази новина от");
define("LAN_EMAIL_189", "Мисля, че ще ти бъде интересно да прочетеш тази статия от");
define("LAN_EMAIL_190", "Въведи код");

?>