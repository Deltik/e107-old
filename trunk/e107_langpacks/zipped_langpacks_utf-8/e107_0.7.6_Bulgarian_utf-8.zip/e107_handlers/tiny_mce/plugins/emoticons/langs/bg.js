// UK lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Вмъкване емоции';
tinyMCELang['lang_emotions_desc'] = 'Емоции';

