<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/powered_by_menu/languages/Bulgarian.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:53:15 $
|     $Author: streaky $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/
	
define("POWEREDBY_L1", "С помощта на:");
	
?>
