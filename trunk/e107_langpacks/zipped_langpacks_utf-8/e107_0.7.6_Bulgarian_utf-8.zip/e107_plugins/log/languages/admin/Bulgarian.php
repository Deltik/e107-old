<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/log/languages/admin/English.php,v $
|     $Revision: 1.10 $
|     $Date: 2005/06/24 17:36:38 $
|     $Author: stevedunstan $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/
	
define("ADSTAT_ON", "Включен");
define("ADSTAT_OFF", "Изключен");
define("ADSTAT_L1", "This plugin will log all visits to your site, and build detailed statistic screens based on the information gathered.");
define("ADSTAT_L2", "The statistics logger has been successfully installed. To activate, please go to the config screen and click Activate.<br /><b>You must set the permissions of the e107_plugins/log/logs folder to 777 (chmod 777)</b>");
define("ADSTAT_L3", "Статистика на сайта");
define("ADSTAT_L4", "Активиране на статистиката на сайта");
define("ADSTAT_L5", "На какво да се води статистика");
define("ADSTAT_L6", "Браузъри");
define("ADSTAT_L7", "Операционни системи");
define("ADSTAT_L8", "Разделителна способност на екрана");
define("ADSTAT_L9", "Домейни");
define("ADSTAT_L10", "Препращания");
define("ADSTAT_L11", "Търсене");
define("ADSTAT_L12", "Нулирай");
define("ADSTAT_L13", "това ще нулира статистиката до момента - внимателно!");
define("ADSTAT_L14", "На посетените странници от сайта");
define("ADSTAT_L15", "Обновяване на настройките");
define("ADSTAT_L16", "Настройки на модул Статистика на сайта");
define("ADSTAT_L17", "Настройките са обновени");
define("ADSTAT_L18", "Позволи достъп до статистиката на ...");
define("ADSTAT_L19", "Препратени посетители");
define("ADSTAT_L20", "Добавяй и визитите на администраторите");
define("ADSTAT_L21", "Максимален брой записи за показване на странница");
define("ADSTAT_L22", "Run update routine");
define("ADSTAT_L23", "logs from a previous version of e107 have been detected, update them here");
define("ADSTAT_L24", "Go to update script");
define("ADSTAT_L25", "Избраните статистики са нулирани");
define("ADSTAT_L26", "Премахни записи на странници");
define("ADSTAT_L27", "ако в статистиката има некоректни странници, Вие можете да ги махнете от тук");
define("ADSTAT_L28", "Отвори странница");


define("ADSTAT_L29", "Име на странницата");
define("ADSTAT_L30", "Маркирай за премахване");
define("ADSTAT_L31", "премахни маркираните странница");
define("ADSTAT_L32", "Подредба на странниците");
define("ADSTAT_L10", "Препращания");
define("ADSTAT_L10", "Препращания");



?>