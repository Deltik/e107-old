<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/Bulgarian.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', 'Настройките на меню Часовник са запомнени');
define('CLOCK_MENU_L2', 'Caption');
define('CLOCK_MENU_L3', 'Обновяване на настройките на менютп');
define('CLOCK_MENU_L4', 'Настройки на меню Часовник');
define('CLOCK_MENU_L5', 'Понеделник,');
define('CLOCK_MENU_L6', 'Вторник,');
define('CLOCK_MENU_L7', 'Сряда,');
define('CLOCK_MENU_L8', 'Четвъртък,');
define('CLOCK_MENU_L9', 'Петък,');
define('CLOCK_MENU_L10', 'Събота,');
define('CLOCK_MENU_L11', 'Неделя,');
define('CLOCK_MENU_L12', 'Януари');
define('CLOCK_MENU_L13', 'Февруари');
define('CLOCK_MENU_L14', 'Март');
define('CLOCK_MENU_L15', 'Април');
define('CLOCK_MENU_L16', 'Май');
define('CLOCK_MENU_L17', 'Юни');
define('CLOCK_MENU_L18', 'Юли');
define('CLOCK_MENU_L19', 'Август');
define('CLOCK_MENU_L20', 'Септември');
define('CLOCK_MENU_L21', 'Октомври');
define('CLOCK_MENU_L22', 'Ноември');
define('CLOCK_MENU_L23', 'Декември');
define('CLOCK_MENU_L24', '');
?>