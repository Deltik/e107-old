<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ©Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
| e107BG Team
| http://e107bg.org
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+---------------------------------------------------------------+
*/
	
define("CM_L1", "Все още няма коментари.");
define("CM_L2", "");
define("CM_L3", "Заглавие");
define("CM_L4", "Брой коментари за показване?");
define("CM_L5", "Браой на знаци за показване?");
define("CM_L6", "Постфикс за дълги коментари?");
define("CM_L7", "Показване на заглавието на новината в менюто?");
define("CM_L8", "Настройки на меню Нови Коментари");
define("CM_L9", "Обновяване на настройките на менюто");
define("CM_L10", "Настройките на менюто са запазени");
	
	
?>