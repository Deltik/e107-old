<?php

define("LAN_350", "Запази");
define("LAN_351", "Избери Тема");

?>