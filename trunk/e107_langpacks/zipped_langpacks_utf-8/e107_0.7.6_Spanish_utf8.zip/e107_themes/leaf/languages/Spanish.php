<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/leaf/languages/Spanish.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Comentario(s) ");
define("LAN_THEME_2", "Comentarios desactivados para este artículo");
define("LAN_THEME_3", "Comentario(s) ");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Comentario de");


?>
