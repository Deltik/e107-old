<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/featurebox/languages/Spanish.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FBLAN_01","Caja de Características");
define("FBLAN_02","Este plugin le permite mostrar una caja encima de sus noticias con ciertas características. Los mensajes pueden girar aleatoriamente o apagarse dinámicamente.");
define("FBLAN_03","Configurar la caja de características");
define("FBLAN_04","El plugin se ha instalado con éxito. Para añadir mensajes y configurarlos vaya a la página del administrador y haga click en 'caja de características' de la sección de plugins.");
define("FBLAN_05","No hay mensajes en la caja de características");
define("FBLAN_06","Mensajes de la caja de características");
define("FBLAN_07","Título");
define("FBLAN_08","Texto del mensaje");
define("FBLAN_09","Visibilidad del mensaje");
define("FBLAN_10","Crear mensaje en caja de características");
define("FBLAN_11","Actualizar mensaje en caja de características");
define("FBLAN_12","Modo");
define("FBLAN_13","Girar mensajes aleatoriamente");
define("FBLAN_14","Mostrar solo este mensaje");
define("FBLAN_15","Mensaje añadido a la BD");
define("FBLAN_16","Mensaje actualizado a la BD");
define("FBLAN_17","Campos en blanco");
define("FBLAN_18","Mensaje de la caja de características borrado");
define("FBLAN_19","Opciones");
define("FBLAN_20","Editar");
define("FBLAN_21","Eliminar");
define("FBLAN_22","Tipo de renderizado");
define("FBLAN_23","En el propio tema");
define("FBLAN_24","Plano");
define("FBLAN_25","Plantilla");
define("FBLAN_26","Puede usar diferentes plantillas para cada mensaje. Añada plantillas a la carpeta e107_plugins/featurebox/templates/");

?>