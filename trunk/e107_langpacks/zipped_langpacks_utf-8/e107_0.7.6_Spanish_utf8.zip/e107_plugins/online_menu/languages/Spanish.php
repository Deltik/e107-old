<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_menu/languages/Spanish.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/01/19 00:30:15 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Invitados: ");
define("ONLINE_L2", "Miembros: ");
define("ONLINE_L3", "En esta página: ");
define("ONLINE_L4", "En linea");
define("ONLINE_L5", "Miembros");
define("ONLINE_L6", "Último");

define("TRACKING_MESSAGE", "Tracking de usuario online está actualmente desactivado, por favor actívelo <a href='".e_ADMIN."users.php?options'>aquí</a></span><br />");

?>