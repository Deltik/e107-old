<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newforumposts_main/languages/Spanish.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/14 10:37:10 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Tema");
define("NFPM_LAN_2", "Usuario");
define("NFPM_LAN_3", "Vistas");
define("NFPM_LAN_4", "Respuestas");
define("NFPM_LAN_5", "Último");
define("NFPM_LAN_6", "Temas");
define("NFPM_LAN_7", "por");

define("NFPM_L1", "Este Plugin muestra una lista de nuevos mensajes en los foros en la página principal");
define("NFPM_L2", "Últimos mensajes en los foros");
define("NFPM_L3", "");
define("NFPM_L4", "¿Activar en el área?");
define("NFPM_L5", "Inactivo");
define("NFPM_L6", "Superior");
define("NFPM_L7", "Inferior");
define("NFPM_L8", "Título");
define("NFPM_L9", "Número de mensajes nuevos a mostrar");
define("NFPM_L10", "¿Mostrar en una caja con scroll?");
define("NFPM_L11", "Alto");
define("NFPM_L12", "Configuración");
define("NFPM_L13", "Actualizar configuración");
define("NFPM_L14", "Configuración actualizada.");
define("NFPM_L15", "Marque para ver los últimos mensajes en los foros.<br />Por defecto son los últimos temas.");
define('NFPM_L16', '[Usuario eliminado]');
?>