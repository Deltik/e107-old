<?php
define("LAN_ALT_1", "Tipo de autorización actual");
define("LAN_ALT_2", "Actualizar ajustes");
define("LAN_ALT_3", "Escoja tipo de autorización alternada");
define("LAN_ALT_4", "Configure parámetros para");
define("LAN_ALT_5", "Configure parámetros de autorización");
define("LAN_ALT_6", "Falló la acción de conexión");
define("LAN_ALT_7", "Si falla el método de conexión alternativo, ¿Como será dirigido?");
define("LAN_ALT_8", "El usuario no encontró la acción");
define("LAN_ALT_9", "Si el nombre de usuario no se encuentra usando el método alternativo, ¿Como será dirigido?");

define("LAN_ALT_FALLBACK", "Use la tabla e107");
define("LAN_ALT_FAIL", "Conexión fallida");
?>
