<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/admin/Spanish.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Configuración del menú del reloj guardada");
define("CLOCK_AD_L2", "Título");
define("CLOCK_AD_L3", "Actualizar ajustes de menú");
define("CLOCK_AD_L4", "Config del menú del reloj");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Activado, mostrará la hora en formato (0-12 AM/PM). Desactivado, mostrará la hora en formato de 0-24");
define("CLOCK_AD_L7", "Prefijo de fecha");
define("CLOCK_AD_L8", "Si su idioma requiere una palabra corta antes de la fecha (Ejemplo 'le' for Francés o 'den' para Alemán...), use este campo. En blanco si no se requiere.");
define("CLOCK_AD_L9", "Sufijo 1");
define("CLOCK_AD_L10", "Sufijo 2");
define("CLOCK_AD_L11", "Sufijo 3");
define("CLOCK_AD_L12", "Sufijo 4 y más");
define("CLOCK_AD_L13", "Si su idioma requiere mostrar el sufijo antes de los números de fecha, complete estos campos solo con el sufijo (Ejemplo: 'st' para 1, 'nd' para 2, 'rd' para 3 y 'th' para 4 y más para usuarios Ingleses). En blanco si no se requiere.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>