<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/sitebutton_menu/languages/Spanish.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("SITEBUTTON_MENU_L1", "Enlácenos");
?>