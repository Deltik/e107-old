<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_top.php,v $
|     $Revision: 1.11 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Top usuarios");

define("TOP_LAN_0", "Top foros");
define("TOP_LAN_1", "Usuario");
define("TOP_LAN_2", "Mensajes");
define("TOP_LAN_3", "Top comentarios");
define("TOP_LAN_4", "Comentarios");
define("TOP_LAN_5", "Top chatbox");
define("TOP_LAN_6", "Puntuación del sitio");

//v.616
define("LAN_1", "Tema");
define("LAN_2", "Autor");
define("LAN_3", "Vistas");
define("LAN_4", "Respuestas");
define("LAN_5", "Último");
define("LAN_6", "Temas");
define("LAN_7", "Temas más activos");
define("LAN_8", "Top Autores");
?>