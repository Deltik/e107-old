<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_email.php,v $
|     $Revision: 1.14 $
|     $Date: 2006/06/17 10:47:07 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Email");

define("LAN_EMAIL_1", "Desde:");
define("LAN_EMAIL_2", "Dirección IP del remitente:");
define("LAN_EMAIL_3", "Noticia desde ");
define("LAN_EMAIL_4", "Enviar email");
define("LAN_EMAIL_5", "Email a un amigo");
define("LAN_EMAIL_6", "Creo que estaría interesado de este email de ");
define("LAN_EMAIL_7", "Enviar mail a alguien");
define("LAN_EMAIL_8", "Comentario"); 
define("LAN_EMAIL_9", "Lo sentimos - imposible enviar el correo"); 
define("LAN_EMAIL_10", "Correo enviado a"); 
define("LAN_EMAIL_11", "Correo enviado"); 
define("LAN_EMAIL_12", "Error"); 
define("LAN_EMAIL_13", "Enviar artículo por correo a un amigo"); 
define("LAN_EMAIL_14", "Enviar noticia por correo a un amigo"); 
define("LAN_EMAIL_15", "Nombre conexión: "); 

define("LAN_EMAIL_106", "Esta no parece una dirección de email válida");

define("LAN_EMAIL_185", "Enviar artículo");
define("LAN_EMAIL_186", "Enviar noticia");
define("LAN_EMAIL_187", "Email del destinatario");
define("LAN_EMAIL_188", "Espero que le guste esta noticia de");
define("LAN_EMAIL_189", "Espero que le guste este artículo de");
?>