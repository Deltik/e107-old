<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/Spanish.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/05/01 21:20:34 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'es_ES');
define("CORE_LC", 'es');
define("CORE_LC2", 'es');
define("CHARSET", "utf-8");
define("CORE_LAN1","Error : tema no encontrado.\\n\\nCambie el tema usado en preferencias (administración) o copie los archivos del tema seleccionado al servidor.");
define("CORE_LAN2"," \\1 escribió:");// "\\1" representa el nombre de usuario.
define("CORE_LAN3","archivo adjunto desactivado");

//v0.7+
define("CORE_LAN4", "Por favor, elimine install.php de su servidor");
define("CORE_LAN5", "Si no lo hace, pone en riesgo potencial su sitio web");
?>