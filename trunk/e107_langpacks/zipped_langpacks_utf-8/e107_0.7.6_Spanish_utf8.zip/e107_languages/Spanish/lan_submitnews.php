<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_submitnews.php,v $
|     $Revision: 1.10 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Enviar Noticia");

define("LAN_7", "Usuario: ");

define("LAN_62", "Asunto: ");

define("LAN_112", "Email: ");

define("LAN_133", "Gracias");
define("LAN_134", "Su envio ha sido realizado. Será revisado por uno de los administradores del sitio.");
define("LAN_135", "Noticia: ");
define("LAN_136", "Enviar Noticia");

define("NWSLAN_6", "Categoría");
define("NWSLAN_10", "No hay categorias");
define("NWSLAN_11", "No tiene acceso a este área.");
define("NWSLAN_12", "Acceso denegado.");

define("SUBNEWSLAN_1", "Debe incluir un título.\\n");
define("SUBNEWSLAN_2", "Debe incluir algún texto en la noticia.\\n");
define("SUBNEWSLAN_3", "El archivo adjunto debe ser jpg, gif ó png");
define("SUBNEWSLAN_4", "Archivo demasiado grande");
define("SUBNEWSLAN_5", "Imagen");
define("SUBNEWSLAN_6", "(jpg, gif ó png)");
?>