<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/link_category.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Puede separar sus enlaces en diferentes categorías,
esto hace la navegación por la página de enlaces mucho más fácil y mejora la exposición.<br /><br />
Cualquier enlace introducido bajo la categoría Principal será mostrado en su menú de navegación.";
$ns -> tablerender("Ayuda Categoría enlace", $text);
?>