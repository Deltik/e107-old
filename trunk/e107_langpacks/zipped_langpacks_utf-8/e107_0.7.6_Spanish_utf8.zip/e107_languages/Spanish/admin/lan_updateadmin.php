<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_updateadmin.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Error - por favor re-envia");
define("UDALAN_2", "Configuración actualizada");
define("UDALAN_3", "Configuración actualizada para");
define("UDALAN_4", "Nombre");
define("UDALAN_5", "Contraseña");
define("UDALAN_6", "Re-escriba contraseña");
define("UDALAN_7", "Cambiar contraseña");
define("UDALAN_8", "Actualizar contraseña de");

?>