<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_ugflag.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Configuración de mantenimiento actualizada");
define("UGFLAN_2", "Activado aviso de mantenimiento");
define("UGFLAN_3", "Actualizar configuración de mantenimiento");
define("UGFLAN_4", "Configuración de Mantenimiento");
define("UGFLAN_5", "Texto a mostrar cuando el sitio esté en mantenimiento");
define("UGFLAN_6", "Deje en blanco para mostrar el mensaje por defecto");
?>