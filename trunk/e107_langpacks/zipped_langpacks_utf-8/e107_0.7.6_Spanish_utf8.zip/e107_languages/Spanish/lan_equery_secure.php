<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_equery_secure.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Esta siendo redirigido a una función de Administración, posiblemente hay modificaciones de la base de datos");
define("EQSEC_LAN2", "Por favor, confirme esta acción:");
define("EQSEC_LAN3", "Sin referir");
define("EQSEC_LAN4", "Acción desde:");
define("EQSEC_LAN5", "Acción para:");
define("EQSEC_LAN6", "Confirmar acción");
define("EQSEC_LAN7", "O cancelar");
?>