Polskie tłumaczenie systemu CMS e107 v0.7.16

Wersja tłumaczenia: v0.7.16
Wersja kodowa: UTF-8

Data: 13 września 2009

Tłumaczenie: e107 Polish Team - http://e107pl.org
Serwis e107 Polska: http://e107pl.org

1. Wprowadzenie
2. Instalacja
3. Aktualizacja
4. Pomoc



1. Wprowadzenie

	Wszystkie pliki zawarte w archiwum stanowią zestaw polskich plików językowych przeznaczonych dla systemu CMS e107 v0.7.16). W archiwum zawarte są jedynie pliki językowe i nie ingerują on w strukturę systemu e107 w sposób bezpośredni.

2. Instalacja

	Po wypakowaniu, zawartość archiwum należy wysłać za pomocą klienta FTP na serwer hostujący stronę WWW. W wypadku prośby o nadpisanie należy ją potwierdzić dla wszystkich plików.

3. Aktualizacja

- Z e107 v0.7.x do e107 v0.7.16+

  Należy postępować identycznie jak przy instalacji, czyli najpierw rozpakować archiwum, a następnie wysłać na serwer i zatwierdzić wszystkie zmiany.

4. Pomoc

  Jeśli szukasz pomocy oraz dodatkowych komponentów dla systemu e107, odwiedź strony wymienione poniżej.

Strony polskojęzyczne:

http://e107pl.org - strona e107 Polska - newsy, pliki, forum, dokumentacja e107 itp.
http://demo.e107pl.org - polskie demo systemu CMS dla ostatniej stabilnej wersji


Strony międzynarodowe:

http://e107.org - oficjalna strona projektu [EN]
http://e107.org/forum.php - oficjalne forum [EN]
http://wiki.e107.org - e107 Wiki - czyli wikipedia dla e107 :) [EN,GR,FR]
http://plugins.e107.org - e107 Plugins - serwis ze wtyczkami dla e107 [EN]
http://themes.e107.org - e107 Themes - serwis z motywami graficznymi dla e107 [EN]
http://e107designs.org - motywy dla e107 [EN]
http://e107coders.org - serwis koderów, wtyczki, dodatki... [EN]

