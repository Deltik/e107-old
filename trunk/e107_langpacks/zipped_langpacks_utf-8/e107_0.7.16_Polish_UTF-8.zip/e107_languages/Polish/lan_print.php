<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2009/07/12 12:59:28 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_print.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_print.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Wersja do druku"); }

define("LAN_PRINT_86", "Kategoria:");
define("LAN_PRINT_87", "przez ");
define("LAN_PRINT_94", "Dodane przez");
define("LAN_PRINT_135", "Wiadomość");
define("LAN_PRINT_303", "Źródło: ");
define("LAN_PRINT_304", "Tytuł: ");
define("LAN_PRINT_305", "Podtytuł: ");
define("LAN_PRINT_306", "Źródło: ");
define("LAN_PRINT_307", "Drukuj stronę");

define("LAN_PRINT_1", "Wersja do druku");

?>