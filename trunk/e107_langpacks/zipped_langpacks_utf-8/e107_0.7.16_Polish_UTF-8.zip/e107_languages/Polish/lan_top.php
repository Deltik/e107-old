<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.2 $
|     $Date: 2009/07/12 12:59:28 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_top.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_top.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("TOP_LAN_0", "Lista Top: Najbardziej aktywni na forum");
define("TOP_LAN_1", "Nick");
define("TOP_LAN_2", "Postów");
define("TOP_LAN_3", "Lista Top: Najczęściej komentują");
define("TOP_LAN_4", "Komentarzy");
define("TOP_LAN_5", "Lista Top: Najbardziej aktywni w chatbox'ie");
define("TOP_LAN_6", "Ranga na stronie");

//v.616
define("LAN_1", "Wątek");
define("LAN_2", "Autor");
define("LAN_3", "Odsłon");
define("LAN_4", "Posty");
define("LAN_5", "Ostatni post");
define("LAN_6", "Wątki");
define("LAN_7", "Najbardziej aktywne wątki");
define("LAN_8", "Lista Top: Najwięcej napisali");

?>