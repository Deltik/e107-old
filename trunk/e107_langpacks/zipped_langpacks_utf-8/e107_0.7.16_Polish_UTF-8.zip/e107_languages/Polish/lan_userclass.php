<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.3 $
|     $Date: 2009/07/12 12:59:28 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_userclass.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_userclass.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("UC_LAN_0", "Wszyscy (publiczne)");
define("UC_LAN_1", "Goście");
define("UC_LAN_2", "Nikt (nieaktywne)");
define("UC_LAN_3", "Zarejestrowani");
define("UC_LAN_4", "Tylko do odczytu");
define("UC_LAN_5", "Administratorzy");
define("UC_LAN_6", "Główni administratorzy");

?>