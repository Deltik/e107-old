/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.1 $
|     $Date: 2009/09/13 10:10:23 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/themes/advanced/langs/pl_dlg.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/themes/advanced/langs/en_dlg.js rev. 1.1
+-----------------------------------------------------------------------------+
*/

tinyMCE.addI18n('pl.advanced_dlg',{
about_title:"O TinyMCE",
about_general:"O TinyMCE",
about_help:"Pomoc",
about_license:"Licencja",
about_plugins:"Wtyczki",
about_plugin:"Wtyczka",
about_author:"Autor",
about_version:"Wersja",
about_loaded:"Za\u0142adowane wtyczki",
anchor_title:"Wstaw/Edytuj zakotwiczenie",
anchor_name:"Nazwa zakotwiczenia",
code_title:"Edytor \u017Ar\u00F3d\u0142a HTML",
code_wordwrap:"Zawijanie s\u0142\u00F3w",
colorpicker_title:"Wybierz kolor",
colorpicker_picker_tab:"Wybieranie",
colorpicker_picker_title:"Wybieranie kolor\u00F3w",
colorpicker_palette_tab:"Paleta",
colorpicker_palette_title:"Paleta kolor\u00F3w",
colorpicker_named_tab:"Nazwane",
colorpicker_named_title:"Nazwane kolory",
colorpicker_color:"Kolor:",
colorpicker_name:"Nazwa:",
charmap_title:"Wybierz niestandardowy znak",
image_title:"Wstaw/Edytuj obraz",
image_src:"URL obrazka",
image_alt:"Opis obrazka",
image_list:"Lista obrazk\u00F3w",
image_border:"Ramka",
image_dimensions:"Rozmiary",
image_vspace:"Pionowy odst\u0119p",
image_hspace:"Poziomy odst\u0119p",
image_align:"Wyr\u00F3wnanie",
image_align_baseline:"Linia bazowa",
image_align_top:"G\u00F3ra",
image_align_middle:"\u015Arodek",
image_align_bottom:"Dolny",
image_align_texttop:"G\u00F3rny tekst",
image_align_textbottom:"Dolny tekst",
image_align_left:"Lewy",
image_align_right:"Prawy",
link_title:"Wstaw/edytuj link",
link_url:"Link URL",
link_target:"Cel",
link_target_same:"Otw\u00F3rz link w tym samym oknie",
link_target_blank:"Otw\u00F3rz link w nowym oknie",
link_titlefield:"Tytu\u0142",
link_is_email:"URL kt\u00F3ry otworzy\u0142e\u015B wydaje si\u0119 by\u0107 adresem mailowym, czy chcesz doda\u0107 odpowiedni prefix mailto: ?",
link_is_external:"URL kt\u00F3ry otworzy\u0142e\u015B wydaje si\u0119 by\u0107 zewn\u0119trznym linkiem, czy chcesz doda\u0107 wymagany prefix http:// ?",
link_list:"Lista link\u00F3w"
});