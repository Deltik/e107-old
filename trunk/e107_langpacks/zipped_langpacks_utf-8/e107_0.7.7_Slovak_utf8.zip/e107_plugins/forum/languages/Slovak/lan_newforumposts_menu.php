<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Slovak/lan_newforumposts_menu.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
	
define("NFP_1", "Všetky posledné príspevky sú zaslané mimo vašej triedy užívateľov, zobrazenie nie je možné.");
define("NFP_2", "Žiadne príspevky");
define("NFP_3", "Konfigurácia menu nového príspevku fóra");
define("NFP_4", "Nadpis");
define("NFP_5", "Počet zobrazených príspevkov");
define("NFP_6", "Počet zobrazených znakov");
define("NFP_7", "Nahrádzací reťazec (postfix) pre dlhé príspevky");
define("NFP_8", "Zobraziť tému vlákna v menu");
define("NFP_9", "Aktualizovať nastavenia menu");
define("NFP_10", "Konfigurácia menu nového príspevku fóra");
define("NFP_11", "Odoslané");
	
?>
