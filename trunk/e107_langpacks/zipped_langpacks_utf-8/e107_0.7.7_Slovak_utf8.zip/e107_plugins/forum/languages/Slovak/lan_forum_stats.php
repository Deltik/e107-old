<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Slovak/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Štatistiky fóra");

define("FSLAN_1", "Hlavné štatistiky");
define("FSLAN_2", "Otvorenie fóra");
define("FSLAN_3", "Čas od otvorenia fóra");
define("FSLAN_4", "Počet príspevkov");
define("FSLAN_5", "Počet vlákien");
define("FSLAN_6", "Počet odpovedí");
define("FSLAN_7", "Počet zobrazení vlákien");
define("FSLAN_8", "Veľkosť databázy (len tabuľky fóra)");
define("FSLAN_9", "Dĺžka riadkov tabuľky fóra");
define("FSLAN_10", "Najviac aktívne fóra");
define("FSLAN_11", "Poradie");
define("FSLAN_12", "Vlákno");
define("FSLAN_13", "Odpovedí");
define("FSLAN_14", "Založenie");
define("FSLAN_15", "Dátum");
define("FSLAN_16", "Najviac prehliadané vlákna");
define("FSLAN_17", "Zobrazení");
define("FSLAN_18", "Naj prispievači");
define("FSLAN_19", "Meno");
define("FSLAN_20", "Príspevkov");
define("FSLAN_21", "Top zakladači vlákien");
define("FSLAN_22", "Top odpovedači");
define("FSLAN_23", "Štatistiky fóra");
define("FSLAN_24", "Priemerný počet príspevkov na deň");

?>
