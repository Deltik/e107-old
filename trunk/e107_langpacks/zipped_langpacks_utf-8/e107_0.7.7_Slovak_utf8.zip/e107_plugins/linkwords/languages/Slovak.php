<?php
	
define("LWLAN_1", "Field(s) left blank.");
define("LWLAN_2", "Link word saved.");
define("LWLAN_3", "Link word updated.");
define("LWLAN_4", "No link words defined yet.");
define("LWLAN_5", "Word");
define("LWLAN_6", "Link");
define("LWLAN_7", "Active?");
define("LWLAN_8", "Options");
define("LWLAN_9", "yes");
define("LWLAN_10", "no");
define("LWLAN_11", "Existing Linkwords");
define("LWLAN_12", "Yes");
define("LWLAN_13", "No");
define("LWLAN_14", "Submit LinkWord");
define("LWLAN_15", "Update LinkWord");
define("LWLAN_16", "Edit");
define("LWLAN_17", "Delete");
define("LWLAN_18", "Are you sure you want to delete this linkword?");
define("LWLAN_19", "Linkword deleted.");
define("LWLAN_20", "Unable to find that linkword entry.");
define("LWLAN_21","Word to autolink");
define("LWLAN_22","Activate?");

define("LWLANINS_1", "Linkwords");
define("LWLANINS_2", "This plugin will link specified words with a defined link");
define("LWLANINS_3", "Configure LinkWords");
define("LWLANINS_4", "To configure please click on the link in the plugins section of the admin front page");

?>