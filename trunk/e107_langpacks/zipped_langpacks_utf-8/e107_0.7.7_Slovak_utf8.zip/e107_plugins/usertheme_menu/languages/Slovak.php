<?php
	
define("LAN_350", "Nastav tému");
define("LAN_351", "Vyber tému");
	
?>