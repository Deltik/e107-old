<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsletter/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/

define("NLLAN_MENU_CAPTION", "Noviny");

define("NLLAN_01", "Noviny");
define("NLLAN_02", "Poskytuje lahký a rýchly spôsob na konfigurovanie a odoslanie novín");
define("NLLAN_03", "Konfiguruj noviny");
define("NLLAN_04", "The newsletter plugin has been successfuly installed. To configure, return to your main admin page and click on 'Newsletter' in the plugin section.");
define("NLLAN_05", "Zatial nie sú zadefinované žiadne noviny");

define("NLLAN_06", "Meno");
define("NLLAN_07", "Abonent");
define("NLLAN_08", "Možnosti");
define("NLLAN_09", "Ste si istý, že chcete zmazat túto novinu?");
define("NLLAN_10", "Existujúce noviny");

define("NLLAN_11", "Zatial neexistuje žiadna vydanie novín");
define("NLLAN_12", "Vydanie");
define("NLLAN_13", "[ Parent ID ] Predmet/Titul");
define("NLLAN_14", "Mailované?");
define("NLLAN_15", "Možnosti");
define("NLLAN_16", "áno");
define("NLLAN_17", "Neodoslané - klikni k odoslaniu");
define("NLLAN_18", "Si si istý, že chceš odoslat toto vydanie abonentom?");
define("NLLAN_19", "Si si istý, že chceš zmazat toto vydanie novín?");
define("NLLAN_20", "Existujúce vydania");
define("NLLAN_21", "Titul");
define("NLLAN_22", "Popis");
define("NLLAN_23", "Hlavicka");
define("NLLAN_24", "Päticka");
define("NLLAN_25", "Aktualizuj noviny");
define("NLLAN_26", "Vytvor noviny");
define("NLLAN_27", "Noviny sú aktualizované v databáze.");
define("NLLAN_28", "Noviny sú definované a uložené v databáze.");
define("NLLAN_29", "Zatial nie sú definované žiadne noviny.");
define("NLLAN_30", "Noviny");
define("NLLAN_31", "Predmet / Titul");
define("NLLAN_32", "Císlo vydania");
define("NLLAN_33", "Text");
define("NLLAN_34", "Aktualizuj Mailing");
define("NLLAN_35", "Vytvor Mailing");
define("NLLAN_36", "Aktualizuj vydanie novín");
define("NLLAN_37", "Vytvor vydanie novín");
define("NLLAN_38", "Noviny sú aktualizované v databáze.");
define("NLLAN_39", "Vydanie novín je aktualizované v databáze - pre odoslanie, klikni na tlacidlo 'Odošli vydanie' v menu Možnosti.");
define("NLLAN_40", "Odoslanie ukoncené - Vydanie odoslané komu: ");

define("NLLAN_41", " abonent(i).");
define("NLLAN_42", "Noviny zmazané.");
define("NLLAN_43", "Vydanie novín zmazané.");

define("NLLAN_44", "Úvodná strana novín");
define("NLLAN_45", "Vytvor noviny");
define("NLLAN_46", "Vytvor mailing");
define("NLLAN_47", "Možnosti novín");

define("NLLAN_48", "ste prihlásený odberateľ týchto novín - ak sa chcete odhlásiť, stlačte prosím tlačidlo dole.");
define("NLLAN_49", "Ste si istý, že sa chcete odhlásiť z odberu týchto novín?");
define("NLLAN_50", "Klikni tlačidlo k prihláseniu sa ( vaša adresa na odober novín je ");
define("NLLAN_51", "Odhlás sa");
define("NLLAN_52", "Prihlás sa");
define("NLLAN_53", "Ste si istý, že sa chcete prihlásiť k odberu týchto novín?");

define("NLLAN_54", "Odosielanie");




?>