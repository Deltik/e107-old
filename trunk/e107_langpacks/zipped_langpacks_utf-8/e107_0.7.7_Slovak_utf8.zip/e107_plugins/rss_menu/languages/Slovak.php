<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/rss_menu/languages/Slovak.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro, whitewolfsix $
+----------------------------------------------------------------------------+
*/

define("RSS_LAN05","Počet položiek (0=neaktívne)");

define("RSS_MENU_L1", " je možné odoberať pomocou RSS kanála.");
define("RSS_MENU_L2", "RSS kanál");
define("RSS_MENU_L3", "Novinky zo stránok");
define("RSS_MENU_L4", "Komentáre zo stránok");
define("RSS_MENU_L5", "Vlákna fóra");
define("RSS_MENU_L6", "Príspevky z fóra");
define("RSS_MENU_L7", "Naše príspevky chatboxu");
define("RSS_MENU_L8", "Naše reporty chýb");
define("RSS_MENU_L9", "Naše downloady");

define("RSS_NEWS", "Novinky");
define("RSS_COM", "Komentáre");
define("RSS_ART", "Články");
define("RSS_REV", "Hodnotenia");
define("RSS_FT", "Vlákna fóra");
define("RSS_FP", "Príspevky fóra");
define("RSS_FSP", "Určité príspevky fóra");
define("RSS_BUG", "Sledovač chýb");
define("RSS_FOR", "Fórum");
define("RSS_DL", "Downloady");

define("RSS_PLUGIN_LAN_1", "RSS");

define("RSS_PLUGIN_LAN_6", "Linky dodávok");
define("RSS_PLUGIN_LAN_7", "RSS dodávka noviniek");
define("RSS_PLUGIN_LAN_8", "RSS dodávka downloadov");
define("RSS_PLUGIN_LAN_9", "RSS dodávka komentárov");
define("RSS_PLUGIN_LAN_10", "RSS dodávka kategórie noviniek:");
define("RSS_PLUGIN_LAN_11", "RSS dodávka kategórie downloadov:");

define("RSS_PLUGIN_LAN_14", "Komentáre");

define("RSS_LAN_ADMINMENU_1", "Možnosti RSS");
define("RSS_LAN_ADMINMENU_2", "Zoznam");
define("RSS_LAN_ADMINMENU_4", "Importovať");

define("RSS_LAN_ERROR_1", "Toto nie je platná rss dodávka<br /><br /><a href='".e_SELF."'><< vráťte sa do zoznamu rss dodávokt</a>");
define("RSS_LAN_ERROR_2", "Váš e107_config.php súbor alebo vaše jazykové súbory obsahujú medzery alebo ï»¿﻿ znaky pred &lt;? znakmi. Musíte to odstrániť s textovým editorom bez utf8, ak si želáte mať platnú RSS dodávku.");
define("RSS_LAN_ERROR_3", "Nie sú prítomné žiadne rss dodávky<br />použite, prosím, funkciu importovania k importovaniu dostupných rss dodávok alebo vytvorte rss dodávku ručne.");
define("RSS_LAN_ERROR_4", "Nie sú dostupné žiadne rss dodávky");
define("RSS_LAN_ERROR_5", "Táto rss položka neexistuje");
define("RSS_LAN_ERROR_6", "Nie sú žiadne rss dodávky k importovaniu");
define("RSS_LAN_ERROR_7", "Niektoré požadované polia chýbajú.");

define("RSS_LAN_ADMIN_1", "Existujúce RSS dodávky");
define("RSS_LAN_ADMIN_2", "Id");
define("RSS_LAN_ADMIN_3", "Cesta");
define("RSS_LAN_ADMIN_4", "Názov");
define("RSS_LAN_ADMIN_5", "Url");
define("RSS_LAN_ADMIN_6", "Text");
define("RSS_LAN_ADMIN_7", "Obmedzenie");
define("RSS_LAN_ADMIN_8", "Viditeľnosť");
define("RSS_LAN_ADMIN_9", "Typ");
define("RSS_LAN_ADMIN_10", "rss dodávka vytvára položku");
define("RSS_LAN_ADMIN_11", "rss dodávka importuje dodávky");
define("RSS_LAN_ADMIN_12", "Id témy");

define("RSS_LAN_ADMIN_13", "Začleniť položky ďalších-noviniek do novej dodávky?");
define("RSS_LAN_ADMIN_14", "Aktivovať");
define("RSS_LAN_ADMIN_15", "Zaškrtnúť linky na ich označenie pre importovanie ...");
define("RSS_LAN_ADMIN_16", "importovať?");
define("RSS_LAN_ADMIN_17", "importovať zaškrtnuté linky");
define("RSS_LAN_ADMIN_18", "rss dodávka(y) sú importované.");

define("RSS_LAN_ADMIN_21", "aktívne a viditeľné v zozname rss dodávky");
define("RSS_LAN_ADMIN_22", "aktívne a neviditeľné v zozname rss dodávky");
define("RSS_LAN_ADMIN_23", "neaktívne");

define("RSS_LAN_ADMIN_26", "všetko označiť");
define("RSS_LAN_ADMIN_27", "všetko odznačiť");

define("RSS_LAN_ADMIN_31", "obmedzenie rss položiek je aktualizované");

define("RSS_LAN_0", "RSS");
define("RSS_LAN_2", "@nospam.com");
define("RSS_LAN_3", "noauthor@nospam.com");
?>
