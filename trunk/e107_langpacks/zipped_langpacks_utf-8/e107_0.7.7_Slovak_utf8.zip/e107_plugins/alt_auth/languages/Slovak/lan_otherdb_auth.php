<?php
define("OTHERDB_LAN_1", "Druh databázy:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Meno užívateľa:");
define("OTHERDB_LAN_4", "Heslo:");
define("OTHERDB_LAN_5", "Databáza");
define("OTHERDB_LAN_6", "Tabuľka");
define("OTHERDB_LAN_7", "Pole užívateľa:");
define("OTHERDB_LAN_8", "Pole hesla:");
define("OTHERDB_LAN_9", "Metóda hesla:");
define("OTHERDB_LAN_10", "Nastav overenie inej db");
define("OTHERDB_LAN_11", "** Ak používate e107 databázu, nasledujúce polia nie sú požadované");

?>
