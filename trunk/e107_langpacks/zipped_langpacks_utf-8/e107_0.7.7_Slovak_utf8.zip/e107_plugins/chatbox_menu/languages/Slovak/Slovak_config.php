<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Slovak/Slovak_config.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro $
|     Encoding:
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Nastavenia chatboxu aktualizované.");
define("CHBLAN_2", "Moderovať.");
define("CHBLAN_3", "Žiadne príspevky chatboxu.");
define("CHBLAN_4", "Člen");
define("CHBLAN_5", "Hosť");
define("CHBLAN_6", "odblokovať");
define("CHBLAN_7", "blokovať");
define("CHBLAN_8", "zmazať");
define("CHBLAN_9", "Moderovať chatbox");
define("CHBLAN_10", "Moderovať príspevky");
define("CHBLAN_11", "Zobrazených príspevkov");
define("CHBLAN_12", "počet zobrazených príspevkov v chatboxe");
define("CHBLAN_13", "Nahrádzať odkazy");
define("CHBLAN_14", "ak je označené, zaslané odkazy sú nahrádzané režazcom zvoleným dole");
define("CHBLAN_15", "Nahrádzací reťazec (ak je voľba aktívna)");
define("CHBLAN_16", "odkazy sú nahrádzané týmto reťazcom");
define("CHBLAN_17", "Obmedzovač znakov");
define("CHBLAN_18", "slová dlhšie ako nastavený počet sú zabalované");
define("CHBLAN_19", "Aktualizovať nastavenia chatboxu");
define("CHBLAN_20", "Nastavenia chatboxu");
define("CHBLAN_21", "Údržba");
define("CHBLAN_22", "Maže správy staršie ako je nastavená časová perióda");
define("CHBLAN_23", "Mazať správy staršie ako ");

define("CHBLAN_24", "Jeden deň");
define("CHBLAN_25", "Jeden týždeň");
define("CHBLAN_26", "Jeden mesiac");
define("CHBLAN_27", "- Zmazať všetky správy -");
define("CHBLAN_28", "Chatbox uprataný.");

define("CHBLAN_29", "Zobraziť chatbox v skrollovacom menu");
define("CHBLAN_30", "Výška vrstvy");
define("CHBLAN_31", "Ukázať smajlíkov");
define("CHBLAN_32", "Moderovať užívateľské triedy");

define("CHBLAN_33", "Súčty užívateľa sú prepočítané");
define("CHBLAN_34", "Prepočítať počty príspevkov užívateľa");
define("CHBLAN_35", "Prepočítať");

define("CHBLAN_36", "Možnosťi zobrazenia chatboxu");
define("CHBLAN_37", "Normálny chatbox");
define("CHBLAN_38", "Použiť javascript kód na dynamickú aktualizáciu príspevkov (AJAX)");

?>
