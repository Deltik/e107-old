<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/Slovak.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', 'Nastavenia menu hodín uložené');
define('CLOCK_MENU_L2', 'Nadpis');
define('CLOCK_MENU_L3', 'Aktualizovať nastavenia menu');
define('CLOCK_MENU_L4', 'Konfigurácia menu hodín');
define('CLOCK_MENU_L5', 'Pondelok,');
define('CLOCK_MENU_L6', 'Utorok,');
define('CLOCK_MENU_L7', 'Streda,');
define('CLOCK_MENU_L8', 'Štvrtok,');
define('CLOCK_MENU_L9', 'Piatok,');
define('CLOCK_MENU_L10', 'Sobota,');
define('CLOCK_MENU_L11', 'Nedeľa,');
define('CLOCK_MENU_L12', 'Január');
define('CLOCK_MENU_L13', 'Február');
define('CLOCK_MENU_L14', 'Marec');
define('CLOCK_MENU_L15', 'Apríl');
define('CLOCK_MENU_L16', 'Máj');
define('CLOCK_MENU_L17', 'Jún');
define('CLOCK_MENU_L18', 'Júl');
define('CLOCK_MENU_L19', 'August');
define('CLOCK_MENU_L20', 'September');
define('CLOCK_MENU_L21', 'Október');
define('CLOCK_MENU_L22', 'November');
define('CLOCK_MENU_L23', 'December');
define('CLOCK_MENU_L24', '');
?>
