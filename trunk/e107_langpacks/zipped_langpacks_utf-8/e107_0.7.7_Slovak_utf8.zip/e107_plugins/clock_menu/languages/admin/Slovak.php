<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/admin/Slovak.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
	
define("CLOCK_AD_L1", "Nastavenia menu hodín uložneé");
define("CLOCK_AD_L2", "Nadpis menu");
define("CLOCK_AD_L3", "Aktualizovať nastavenia");
define("CLOCK_AD_L4", "Konfigurácia menu hodín");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Ak je označené, čas sa bude zobrazovať v US formáte (0-12 AM/PM formát). Odznačte ak chcete používať fotmát hodín 0-24");
define("CLOCK_AD_L7", "Predpona času");
define("CLOCK_AD_L8", "Ak váš jazyk vyžaduje pred dátumom isté ktátke slovo (Napríklad 'le' vo francúžtine alebo 'den' v nemčine...), použite túto voľbu. Ak voľba nie je potrebné, ponechajte polia prázdne.");
define("CLOCK_AD_L9", "Predpona 1");
define("CLOCK_AD_L10", "Predpona 2");
define("CLOCK_AD_L11", "Predpona 3");
define("CLOCK_AD_L12", "Predpona 4 a viac");
define("CLOCK_AD_L13", "Ak váš jazyk vyžaduje pred číslo času vložiť istú predložku, vyplňte tieto polia práve touto predložkou (Napríklad v angličtine: 'st' pre 1, 'nd' pre 2, 'rd' pre 3 and 'th' pre 4 a ďalej). Ak táto voľba nie je potrebná, ponehajte polia prázdne.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>
