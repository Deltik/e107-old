<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/human_condition/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/03/21 11:13:49 $
|     $Author: stevedunstan $
|     $Translation: whitewolfsix $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' od <a href='http://e107.org' rel='external'>jalista</a>, založené na téme Wordpressu, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Komentáre sú vypnuté pre túto položku");
define("LAN_THEME_3", "Komentár(e): ");
define("LAN_THEME_4", "Čítať zvyšok ...");
define("LAN_THEME_5", "Spätné sledovanie: ");
define("LAN_THEME_6", "Komentár od");


?>
