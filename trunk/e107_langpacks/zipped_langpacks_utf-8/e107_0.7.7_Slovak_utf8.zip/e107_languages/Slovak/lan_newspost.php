<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_newspost.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Novinka zmazaná.");
define("NWSLAN_2", "Potvrďte zmazanie tejto novinky.");
define("NWSLAN_3", "Žiadne existujúce novinky.");
define("NWSLAN_4", "Existujúce novninky");
define("NWSLAN_5", "Otvoriť HTML editor");
define("NWSLAN_6", "Kategória");
define("NWSLAN_7", "Editovať");
define("NWSLAN_8", "Zmazať");
define("NWSLAN_9", "potvrdiť");
define("NWSLAN_10", "Žiadne kategórie.");
define("NWSLAN_11", "Pridať/editovať kategórie");
define("NWSLAN_12", "Titulok");
define("NWSLAN_13", "Novinka");
define("NWSLAN_14", "Rozšírený text");
define("NWSLAN_15", "Komentáre");
define("NWSLAN_16", "Zpanuté");
define("NWSLAN_17", "Vypnuté");
define("NWSLAN_18", "Povolí zasielanie komentárov pre túto novinku");
define("NWSLAN_19", "Aktivácia");
define("NWSLAN_20", "Nechajte prázdne polia pre nepoužitie auto-aktivácie");
define("NWSLAN_21", "Aktivovať medzi");
define("NWSLAN_22", "Viditeľnosť");
define("NWSLAN_23", "Označte triedu užívateľov, ktorá má právo vidieť túto novinku");
define("NWSLAN_24", "Ukázať znova");
define("NWSLAN_25", "Aktualizovať novinku");
define("NWSLAN_26", "Novinka uložená");
define("NWSLAN_27", "Ukázať");
define("NWSLAN_28", "Novinka(príbeh)");
define("NWSLAN_29", "Novinka");

define("NWSLAN_30", "Ukázať len titulok");

?>
