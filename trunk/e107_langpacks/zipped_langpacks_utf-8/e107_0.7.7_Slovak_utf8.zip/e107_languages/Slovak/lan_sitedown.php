<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Stránky sú dočasne uzavreté");
define("LAN_SITEDOWN_00", "je dočasne uzavretá");
define("LAN_SITEDOWN_01", "Stránky sú dočasne uzavreté z dôvodu údržby. Tento stav nepotrvá dlho - prosím, skúste sa o chvíľu vrátiť.");
?>
