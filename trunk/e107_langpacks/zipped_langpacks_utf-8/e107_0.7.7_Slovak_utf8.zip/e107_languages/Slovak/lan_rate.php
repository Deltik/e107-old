<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Hodnotenie");

define("RATELAN_0", "hlas");
define("RATELAN_1", "hlasov");
define("RATELAN_2", "ako ohodnotíte tento článok?");
define("RATELAN_3", "ďakujeme za váš hlas");
define("RATELAN_4", "nehodnotené");
define("RATELAN_5", "hodnoť");


?>
