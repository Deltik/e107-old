<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_links.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Odkazy");

define("LAN_61", "Kategórie odkazov");
define("LAN_62", "kategórie");
define("LAN_63", "kategória");
define("LAN_64", "v tejto kategórií");
define("LAN_65", "odkaz");
define("LAN_66", "odkazy");
define("LAN_67", "Ukázať všetky odkazy");
define("LAN_68", "editovať");
define("LAN_69", "zmazať");
define("LAN_86", "Kategória:");
define("LAN_88", "Referal:");
define("LAN_89", "Admin: ");
define("LAN_90", "pridať nový odkaz do kategórie");
define("LAN_91", "pridať novú kategóriu");

define("LAN_92", "Uložiť odkaz");
define("LAN_93", "Po uložení vášho odkazu máte možnosť zviditeľniť ho v hlavnom menu, prejdite prosím, do administrátora odkazov.");
define("LAN_94", "Meno odkazu:");
define("LAN_95", "URL odkazu:");
define("LAN_96", "Popis odkazu:");
define("LAN_97", "URL na tlačidlo odkazu:");
define("LAN_98", "Uložiť odkaz");

define("LAN_99", "Ďakujeme vám");
define("LAN_100", "Váš odkaz bol zaznamenaný a posunutý administrátorovi na schválenie");
define("LAN_101", "Prosím, kliknite sem pre zaslanie odkazu");

define("LAN_102", "Toto");
define("LAN_103", "je");
define("LAN_104", "sú");
define("LAN_105", "spolu");
define("LAN_106", "Podtrhnuté polia sú povinné.");

define("LAN_Links_1", "Odkazov spolu");
define("LAN_Links_2", "Spolu aktivovaných odkazov");
define("LAN_LINKS_3", "Anonym");
?>
