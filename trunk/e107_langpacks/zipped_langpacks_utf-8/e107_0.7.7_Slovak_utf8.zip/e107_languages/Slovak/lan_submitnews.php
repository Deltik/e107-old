<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Zaslať novinku");
define("LAN_7", "Užívateľské meno: ");
define("LAN_62", "Predmet: ");
define("LAN_112", "Emailová adresa: ");
define("LAN_133", "Ďakujeme vám");
define("LAN_134", "Vaša novinka bola zaznamenaná a posunutá administrátorovi na schválenie.");
define("LAN_135", "Novinka: ");
define("LAN_136", "Zaslať novinku");
define("NWSLAN_6", "Kategória");
define("NWSLAN_10", "Žiadne kategórie noviniek");
define("NWSLAN_11", "Nemáte prístup do tejto oblasti.");
define("NWSLAN_12", "Prístup zamietnutý.");

define("SUBNEWSLAN_1", "Musíte zadať titulok.\\n");
define("SUBNEWSLAN_2", "Musíte zadať text novinky.\\n");
define("SUBNEWSLAN_3", "Vaša príloha musí byž buď jpg, gif alebo png súbor");
define("SUBNEWSLAN_4", "Súbor je príliš vešký");
define("SUBNEWSLAN_5", "Súbor obrázku");
define("SUBNEWSLAN_6", "(jpg, gif alebo png)");

?>
