<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Užívateľ registrovaný");

define("NT_LAN_UV_1", "Registrácia užívateľa potvrdená");
define("NT_LAN_UV_2", "Užívateľovo identifikačné číslo");
define("NT_LAN_UV_3", "Užívateľovo prihlasovacie meno: ");
define("NT_LAN_UV_4", "Užívateľova IP: ");

define("NT_LAN_LI_1", "Užívateľ prihlásený");

define("NT_LAN_LO_1", "Užívateľ odhlásený");
define("NT_LAN_LO_2", " odhlásený zo stránky");

define("NT_LAN_FL_1", "Zákaz pre zahltenie");
define("NT_LAN_FL_2", "IP adresa zakázaná kvôli zahlteniu");

define("NT_LAN_SN_1", "Novinka zaslaná");

define("NT_LAN_NU_1", "Aktualizované");

define("NT_LAN_ND_1", "Novinka zmazaná");
define("NT_LAN_ND_2", "Zmazaná novinka s ID");

?>
