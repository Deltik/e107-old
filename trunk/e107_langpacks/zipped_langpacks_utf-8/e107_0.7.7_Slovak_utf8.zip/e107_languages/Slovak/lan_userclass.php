<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Každý (verejná)");
define("UC_LAN_1", "Hostia");
define("UC_LAN_2", "Nikto (neaktívna)");
define("UC_LAN_3", "Členovia");
define("UC_LAN_4", "Len na čítanie");
define("UC_LAN_5", "Administrátori");
define("UC_LAN_6", "Hlavný administrátor");
?>
