<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:49 $
|     $Author: whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'sk');
define("CORE_LC", 'sk');
define("CORE_LC2", 'sk');
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","Error : chýba téma.\\n\\nZmente používanú tému v administrátorovi alebo uploadujte chýbajúce súbory nastavenej témy.");

//v.616
define("CORE_LAN2"," \\1 napísal:");// "\\1" represents the username.
define("CORE_LAN3","súborové prílohy vypnuté");

//v0.7+
define("CORE_LAN4", "Zmažte súbor install.php z vášho servera, prosím");
define("CORE_LAN5", "ak to nespravíte, vystavíte svoje stránky možným útokom");

// v0.7.6
define("CORE_LAN6", "Ochrana proti zahlteniu bola na týchto stránkach aktivovaná a budete upozornený na možné zablokovanie ak sa pokúsite dostať na požadované stránky.");
define("CORE_LAN7", "Jadro sa pokúša obnoviť prednastavenia z automatickej zálohy.");
define("CORE_LAN8", "Core Prefs Error");
define("CORE_LAN9", "Jadro nemôže byť obnovené z automatickej zálohy. Vykonanie je pozastavené.");
define("CORE_LAN10", "Bolo zistené poškodené cookie - odhlásený.");


define("LAN_WARNING", "Pozor!");
define("LAN_ERROR", "Chyba");
define("LAN_ANONYMOUS", "Anonymný");
?>
