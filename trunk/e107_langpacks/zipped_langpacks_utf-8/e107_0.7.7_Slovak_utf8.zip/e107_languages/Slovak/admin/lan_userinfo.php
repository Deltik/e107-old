<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_userinfo.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Nie je možné nájsť IP adresu - informácie nie sú prístupné.");
// define("USFLAN_2", "Error");
define("USFLAN_3", "Správa poslaná z IP adresy");
define("USFLAN_4", "Host");
define("USFLAN_5", "Kliknite sem pre zaslanie IP adresy do administrátora zákazov");
define("USFLAN_6", "ID užívateľa");
define("USFLAN_7", "Informácie o užívateľovi");

?>
