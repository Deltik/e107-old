<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_db.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Záloha nastavení jadra uložená do databázy.");
define("DBLAN_2", "Kliknite na tlačítko pre zálohu vašej databázy");
define("DBLAN_3", "Zálohovať SQL databázu");
define("DBLAN_4", "Kliknite na tlačítko pre overenie vašej databázy");
define("DBLAN_5", "Skontrolovať správnosť databázy");
define("DBLAN_6", "Kliknite na tlačítko pre optimalizáciu vašej databázy");
define("DBLAN_7", "Optimalizovať SQL databázu");
define("DBLAN_8", "Kliknite na tlačítko pre zálohovanie nastavení jadra portálu");
define("DBLAN_9", "Zálohovať jadro");
define("DBLAN_10", "Nástroje databázy");
define("DBLAN_11", "mySQL databáza");
define("DBLAN_12", "optimalizovaná");
define("DBLAN_13", "Späť");
define("DBLAN_14", "OK");
define("DBLAN_15", "Kliknite na tlačítko pre skontrolovanie prístupných aktualizácií databázy");
define("DBLAN_16", "Skontrolovať aktualizácie");
define("DBLAN_17", "Meno volieb");
define("DBLAN_18", "Hodnota volieb");
define("DBLAN_19", "Kliknite na tlačidlo pre otvorenie editora volieb (len pre skúsených užívateľov!)");
define("DBLAN_20", "Editor volieb");
define("DBLAN_21", "Zmažte skontrolované");
define("DBLAN_22", "Plugin: Zobraz a skenuj");
define("DBLAN_23", "Skenovanie ukončené");
define("DBLAN_24", "Meno");
define("DBLAN_25", "Zložka");
define("DBLAN_26", "Zahrnuté doplnky");
define("DBLAN_27", "Inštalované");
define("DBLAN_28", "Kliknite na tlačidlo pre skenovanie plugin zložiek kvôli zmenám");
define("DBLAN_29", "Skenujte plugin zložky");


?>
