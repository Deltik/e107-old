<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_mailout.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "Uložiť zmeny");
define("PRFLAN_63", "Poslať testovací email");
define("PRFLAN_64", "Kliknutím na tlačítko pošlete email na adresu hlavného administrátora");
define("PRFLAN_65", "Kliknite pre poslanie emailu na");
define("PRFLAN_66", "Testovací mail z");
define("PRFLAN_67", "Toto je testovací email, zdá sa, že vaše nastavenie emailu je vporiadku!\n\nPozdrav\nz vášho e107 web portálu.");
define("PRFLAN_68", "Testovací email nebol odoslaný. Zdá sa, že váš server alebo samotný portál nieje správne nakonfigurovaný pre odosielanie emailov, prosím, skúste použiť SMTP alebo kontaktujte administrátora aby skontroloval nastavenie emailu pre váš účet.");
define("PRFLAN_69", "Testovací email bol úspešne odoslaný, skontrolujte, prosím, vašu emailovú schránku.");
define("PRFLAN_70", "Zapnúť SMTP");
define("PRFLAN_71", "Ozančte ak chcete zasielať emaily pomocou SMTP");
define("PRFLAN_72", "SMTP Server");
define("PRFLAN_73", "SMTP užívateľské meno");
define("PRFLAN_74", "SMTP heslo");
define("PRFLAN_75", "Email nebol odoslaný. Prosím, skontrolujte veše nastavenia SMTP alebo vypnite SMTP a skúste to znovu.");

define("MAILAN_01","Od");
define("MAILAN_02","Z emailu");
define("MAILAN_03","Pre");
define("MAILAN_04","Cc");
define("MAILAN_05","Bcc");
define("MAILAN_06","Predmet");
define("MAILAN_07","Prílohy");
define("MAILAN_08","Poslať email");
define("MAILAN_09","Použiť štýl témy");
define("MAILAN_10","Podpis užívateľa");
define("MAILAN_11","Vložiť premenné");
define("MAILAN_12","Všetci užívatelia");
define("MAILAN_13","Všetci neoverení užívatelia ");
define("MAILAN_14","Pre odosielanie väčšieho množstva emailov odporúčame nastaviť SMTP v možnostiach nižšie");
define("MAILAN_15","Odosielanie emailov");

define("MAILAN_16","Meno užívateľa");
define("MAILAN_17","prihlasovací link");
define("MAILAN_18","užívateľovo id");
define("MAILAN_19","Emailova adresa na admina nie je dostupná. Skontrolujte si, prosím, svoje nastavenia a skúste znova.");
define("MAILAN_20","Trasa odosielaného mailu");
define("MAILAN_21","Položky hromadného mailu");
define("MAILAN_22","Momentálne nie sú uložené žiadne položky");
define("MAILAN_23","Trieda užívateľa: ");
define("MAILAN_24", "email(y) sú pripravené na odoslanie");

define("MAILAN_25", "Pauza");
define("MAILAN_26", "Prerušte odosielanie hromadných mailov každých");
define("MAILAN_27", "emaily");
define("MAILAN_28", "Dĺžka pauzy");
define("MAILAN_29", "sekundy");
define("MAILAN_30", "Viac než 30 sekúnd môže spôsobiť výpadok prehliadača");
define("MAILAN_31", "Spracovávanie vyskočeného emailu");
define("MAILAN_32", "Emailova adresa");
define("MAILAN_33", "Prichádzajúci mail");
define("MAILAN_34", "Názov konta");
define("MAILAN_35", "Heslo");
define("MAILAN_36", "Zmažte po kontrole vyskakujúce maily");

define("MAILAN_37", "Spracované");
define("MAILAN_38", "Zrušte");
define("MAILAN_39", "Emailovanie");
define("MAILAN_40", "Musíte premenovať <b>e107.htaccess</b> na <b>.htaccess</b> v");
define("MAILAN_41", "pred odoslaním mailu z tejto stránky.");
define("MAILAN_42", "Upozornenie");
define("MAILAN_43", "Meno užívateľa");
define("MAILAN_44", "Prihlásenie užívateľa");
define("MAILAN_45", "Užívateľov email");
define("MAILAN_46", "Porovnanie užívateľa");
define("MAILAN_47", "obsahuje");
define("MAILAN_48", "rovná sa");
define("MAILAN_49", "Id");
define("MAILAN_50", "Autor");
define("MAILAN_51", "Predmet");
define("MAILAN_52", "Posledná zmena");
define("MAILAN_53", "Admini");
define("MAILAN_54", "Ja");
define("MAILAN_55", "Trieda užívateľa");
define("MAILAN_56", "Pošlite mail");
define("MAILAN_57", "Udržať SMTP spojenie nažive");
define("MAILAN_58", "Vyskytol sa problem s prílohou:");
define("MAILAN_59", "Pokrok mailovania");
define("MAILAN_60", "Odosielanie...");
define("MAILAN_61", "Nezostávajú žiadne maily na odoslanie.");
define("MAILAN_62", "Odoslané emaily:");
define("MAILAN_63", "Emaily, ktorých odoslanie zlyhalo:");
define("MAILAN_64", "Súčet uplynulého času:");
define("MAILAN_65", "sekundy");
define("MAILAN_66", "Úspešne prerušené");
define("MAILAN_67", "Použite 'POP pred SMTP' overovaním"); 

?>
