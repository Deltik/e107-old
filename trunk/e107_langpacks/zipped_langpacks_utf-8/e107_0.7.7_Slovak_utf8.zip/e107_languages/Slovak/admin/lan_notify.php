<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("NT_LAN_1", "Oznamovanie");
define("NT_LAN_2", "Posielať oznamovacie emali pri");
define("NT_LAN_3", "Nie");
define("NT_LAN_4", "Hlavný administrátor");
define("NT_LAN_5", "Trieda");
define("NT_LAN_6", "Email");

define("NU_LAN_1", "Užívateľské udalosti");
define("NU_LAN_2", "Registrácia užívateľa");
define("NU_LAN_3", "Overenie užívateľa");
define("NU_LAN_4", "Prihlásenie užívateľa");
define("NU_LAN_5", "Odhlásenie užívateľa");

define("NS_LAN_1", "Bezpečnostné udalosti");
define("NS_LAN_2", "Zákaz IP útočiacej stránky");

define("NN_LAN_1", "Udalosti noviniek");
define("NN_LAN_2", "Novinka zaslaná užívateľom");
define("NN_LAN_3", "Novinka uložená administrátorom");
define("NN_LAN_4", "Novinka editovaná administrátorom");
define("NN_LAN_5", "Novinka zmazaná administrátorom");

define("NF_LAN_1", "Udalosti súboru");
define("NF_LAN_2", "Súbor uploadovaný užívateľom");

?>
