<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_filemanager.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "Uploadované");
define("FMLAN_2", "do");
define("FMLAN_3", "adresára");
define("FMLAN_4", "Uploadované súbory musia dodržiavať direktívi max_file_size v php.ini.");
// define("FMLAN_5", "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form.");
// define("FMLAN_6", "The uploaded file was only partially uploaded.");
// define("FMLAN_7", "No file was uploaded.");
// define("FMLAN_8", "Uploaded file size 0 bytes");
// define("FMLAN_9", "The file did not upload. Filename");
// define("FMLAN_10", "Error");
// define("FMLAN_11", "Probably incorrect permissions on upload directory.");
define("FMLAN_12", "súbor");
define("FMLAN_13", "súbory");
define("FMLAN_14", "adresár");
define("FMLAN_15", "adresáry");
define("FMLAN_16", "Root adresár");
define("FMLAN_17", "Meno");
define("FMLAN_18", "Veľkosť");
define("FMLAN_19", "Posledná modifikácia");

define("FMLAN_21", "Uploadovať súbor do tohto adresára");
define("FMLAN_22", "Uploadovať");

define("FMLAN_26", "Zmazanie");
define("FMLAN_27", "úspešné");
define("FMLAN_28", "Nemožnosť zmazania");
define("FMLAN_29", "Cesta");
define("FMLAN_30", "O úroveň vyššie");
define("FMLAN_31", "adresár");

define("FMLAN_32", "Zvoliť adresár");
define("FMLAN_33", "Zvoliť");
define("FMLAN_34", "Voľba adresára");
define("FMLAN_35", "Adresár súborov");

define("FMLAN_36", "Adresár vlastných menu");
define("FMLAN_37", "Adresár vlastných stránok");

define("FMLAN_38", "Úspešne presunuté do");
define("FMLAN_39", "Nemožnosť presunutia do");
define("FMLAN_40", "Adresár obrázkov noviniek");
define("FMLAN_41", "Presunúť do adresára downloadov.");
define("FMLAN_42", "Presunúť do adresára obrázkov downloadov.");
define("FMLAN_43", "Zmazať zvolené súbory");
define("FMLAN_44", "Prosím, potvrďte presunutie vybraných súborov do adresára downloadov.");
define("FMLAN_45", "Prosím, potvrďte presunutie vybraných súborov do adresára obrázkov downloadov.");
define("FMLAN_46", "Prosím, potvrďte zmazanie vybraných súborov.");
define("FMLAN_47", "Uploady užívateľov");

define("FMLAN_48", "Vybraté presuňte do");
define("FMLAN_49", "Potvrďte, prosím, presun vybratých súborov.");
define("FMLAN_50", "Presun");

?>
