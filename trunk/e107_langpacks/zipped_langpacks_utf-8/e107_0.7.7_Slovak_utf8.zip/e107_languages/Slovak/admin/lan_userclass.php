<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Zaslať overovací email");
define("UCSLAN_2", "Aktualizovať privilégia");
define("UCSLAN_3", "Vážený");
define("UCSLAN_4", "Vaše privilégia boli aktualizované na");
define("UCSLAN_5", "Máte teraz prístup do týchto lokácií");
define("UCSLAN_6", "Nastaviť triedu pre užívateľa");
define("UCSLAN_7", "Nastavenie triedy");
define("UCSLAN_8", "Overiť užívateľa");
define("UCSLAN_9", "Trieda aktualizovaná.");
define("UCSLAN_10", "Pozdravy,");

?>
