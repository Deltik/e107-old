<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_footer.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Stránka");
define("FOOTLAN_2", "Hlavný administrátor");
define("FOOTLAN_3", "Verzia");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Téma");
define("FOOTLAN_6", "od");
define("FOOTLAN_7", "Informácie");
define("FOOTLAN_8", "Dátum inštalácie");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP verzia");
define("FOOTLAN_12", "mySQL verzia");
define("FOOTLAN_13", "Informácie o portály");
define("FOOTLAN_14", "Ukázať dokumenty");
define("FOOTLAN_15", "Dokumentácia");
define("FOOTLAN_16", "Databáza");
define("FOOTLAN_17", "Kódovanie");

?>
