<?php
$text = " This page displays all your servers PHP configuration settings. ";
$ns -> tablerender("PHP Info Help", $text);
?>