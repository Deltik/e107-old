<?php
$text = "From here you can allow / disallow the ability for users to post images on the site, set resize method and view uploaded avatars.";
$ns -> tablerender("Images Help", $text);
?>