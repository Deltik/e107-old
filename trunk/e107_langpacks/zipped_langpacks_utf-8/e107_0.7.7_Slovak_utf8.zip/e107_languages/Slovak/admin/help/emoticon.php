<?php

$text = "You can create emote packs that will install seamlessly into e107. Go to <a href='".e_FILE."emote_create/emotecreate.php'>emote create</a> and follow the instructions.";

$ns -> tablerender("Emoticon Help", $text);
?>