<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_e107_update.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Akcia");
define("LAN_UPDATE_3", "Nie je potrebné");

define("LAN_UPDATE_5", "Dostupná aktualizácia");
define("LAN_UPDATE_7", "Vykonané");
define("LAN_UPDATE_8", "Aktualizácia z");
define("LAN_UPDATE_9", "na");
define("LAN_UPDATE_10", "Dostupné aktualizácie");
define("LAN_UPDATE_11", ".617 na .7 aktualizácia pokračovala");
define("LAN_UPDATE_12", "Jedna z vašich tabuliek obsahuje zdvojené položky.");

?>
