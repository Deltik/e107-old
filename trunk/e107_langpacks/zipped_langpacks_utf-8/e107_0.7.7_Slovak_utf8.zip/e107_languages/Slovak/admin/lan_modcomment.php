<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_modcomment.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderovaný.");
define("MDCLAN_2", "Žiadne komentáre pre tento predmet");
define("MDCLAN_3", "Člen");
define("MDCLAN_4", "Hosť");
define("MDCLAN_5", "odblokovať");
define("MDCLAN_6", "blokovať");

define("MDCLAN_8", "Moderované komentáre");
define("MDCLAN_9", "Pozor! Zmazanie zdroja spôsobí zmazanie všetkých odpovedí!");
define("MDCLAN_10", "možnosti");
define("MDCLAN_11", "komentár");
define("MDCLAN_12", "komentáre");
define("MDCLAN_13", "blokované");
define("MDCLAN_14", "zamknuté komentáre");
define("MDCLAN_15", "otvorené");
define("MDCLAN_16", "zamknuté");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>
