<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "nastavenie údržby aktualizované");
define("UGFLAN_2", "Aktivovať stav údržby");
define("UGFLAN_3", "Aktualizovať nastavenie údržby");
define("UGFLAN_4", "Nastavenie údržby");

define("UGFLAN_5", "Zobrazený text");
define("UGFLAN_6", "Nechajte prázdne pre zobrazenie prednastaveného textu.");

?>
