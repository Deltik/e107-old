<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_cache.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Stav systémov cache");
define("CACLAN_2", "Nastaviť stav systémov cache");
define("CACLAN_3", "Cache systém");
define("CACLAN_4", "Stav cache nastavený");
define("CACLAN_5", "Vyprázdniť cache");
define("CACLAN_6", "Cache vyprázdnená");

define("CACLAN_7", "Vypnúť cache");
// define("CACLAN_8", "Cache data saved to MySQL");
define("CACLAN_9", "Dáta v cache uložené do súboru");
define("CACLAN_10", "Cache adresár nieje zapisovateľný. Prosím, nastavte práva tohto adresára na CHMOD 777");
?>
