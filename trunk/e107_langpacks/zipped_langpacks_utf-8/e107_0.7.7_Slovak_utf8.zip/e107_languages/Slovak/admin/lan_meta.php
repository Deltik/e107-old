<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_meta.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tagy aktualizované");
define("METLAN_2", "Vložené meta-tagy");
define("METLAN_3", "Uložiť nové nastavenie meta-tagov");
define("METLAN_4", "Aktualizované");
define("METLAN_5", "sem vložte váš popis");
define("METLAN_6", "sem, vložte, zoznam, vašich, kľúčových slov");
define("METLAN_7", "sem vložte vaše informácie o autorských právach");
define("METLAN_8", "Meta Tagy");

define("METLAN_9", "Popis");
define("METLAN_10", "Kľúčové slová");
define("METLAN_11", "Autorské práva");
define("METLAN_12", "Použije názov novinky a jej sumár ako meta-popis stránke noviniek.");
define("METLAN_13", "Autor");

?>
