<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_userclass2.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Vymazať všetkých užívateľov z tejto triedy.");
define("UCSLAN_2", "Užívatelia triedy aktualizovaný.");
define("UCSLAN_3", "Trieda zmazaná.");
define("UCSLAN_4", "Prosím, potvrďte zmazanie tejto témy.");
define("UCSLAN_5", "Trieda aktualizovaná.");
define("UCSLAN_6", "Trieda uložená.");
define("UCSLAN_7", "Žiadne triedy užívateľov.");
define("UCSLAN_8", "Existujúce triedy užívateľov");

// define("UCSLAN_9", "Edit");
// define("UCSLAN_10", "Delete");
define("UCSLAN_11", "potvrďte");
define("UCSLAN_12", "Názov triedy");
define("UCSLAN_13", "Popis triedy");
define("UCSLAN_14", "Aktualizovať triedu užívateľov");
define("UCSLAN_15", "Vytvoriť novú triedu");
define("UCSLAN_16", "Pridať užívateľa do triedy");
define("UCSLAN_17", "Odstrániť");
define("UCSLAN_18", "Vyprázdniť triedu");
define("UCSLAN_19", "Pridať užívateľa do triedy");
define("UCSLAN_20", ".");
define("UCSLAN_21", "Nastavenia užívateľských tried");

define("UCSLAN_22", "Užívatelia - kliknite pre presun ...");
define("UCSLAN_23", "Užívatelia v triede ...");

define("UCSLAN_24", "Kto môže spravovať triedu -");


?>
