<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: whitewolfsix
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Prihlásenie admina");
define("LAN_ADMINLOG_1", "Dátum");
define("LAN_ADMINLOG_2", "Názov");
define("LAN_ADMINLOG_3", "Popis");
define("LAN_ADMINLOG_4", "Užívateľksá IP");
define("LAN_ADMINLOG_5", "Užívateľksá ID");
define("LAN_ADMINLOG_6", "Informatívna ikona");
define("LAN_ADMINLOG_7", "Informatívna správa");
define("LAN_ADMINLOG_8", "Ikona oznamu");
define("LAN_ADMINLOG_9", "Informačná správa");
define("LAN_ADMINLOG_10", "Ikona varovania");
define("LAN_ADMINLOG_11", "Varujúca správa");
define("LAN_ADMINLOG_12", "Ikona kritickej chyby");
define("LAN_ADMINLOG_13", "Správa kritickej chyby");

?>