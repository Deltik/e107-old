<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_cpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro, whitewolfsix $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Nadpis");
define("CUSLAN_2", "Typ");
define("CUSLAN_3", "Nastavenia");
define("CUSLAN_4", "Zmazať túto stránku?");
define("CUSLAN_5", "Existujúce stránky");
define("CUSLAN_7", "Názov menu");
define("CUSLAN_8", "Nadpis / Titulok");
define("CUSLAN_9", "Text");
define("CUSLAN_10", "Povoliť hodnotenie stránky");
define("CUSLAN_11", "Úvodná stránka");
define("CUSLAN_12", "Vytvoriť stránku");
define("CUSLAN_13", "Povoliť komentáre");
define("CUSLAN_14", "Stránka chránená heslom");
define("CUSLAN_15", "vložte heslo pre chránené stránky");
define("CUSLAN_16", "Vytvoriť odkaz v hlavnom menu");
define("CUSLAN_17", "vložte názov odkazu");
define("CUSLAN_18", "Stránka / odkaz viditeľný pre");
define("CUSLAN_19", "Aktualizovať stránku");
define("CUSLAN_20", "Vytvoriť stránku");
define("CUSLAN_21", "Aktualizovať menu");
define("CUSLAN_22", "Vytvoriť menu");
define("CUSLAN_23", "Editovať stránku");
define("CUSLAN_24", "Vytvoriť novú stránku");
define("CUSLAN_25", "Editovať menu");
define("CUSLAN_26", "Vytvoriť nové menu");
define("CUSLAN_27", "Stránka uložená.");
define("CUSLAN_28", "Stránka zmazaná");
define("CUSLAN_29", "Zobraziť zoznam stránok ak nieje vybraná žiadna stránka");
define("CUSLAN_30", "Expiračná doba pre cookie(v sekundách)");
define("CUSLAN_31", "Vytvoriť menu");
define("CUSLAN_32", "Konvertovať staré stránky/menu");
define("CUSLAN_33", "Nastavenia stránky");
define("CUSLAN_34", "Počiatočná konverzia");
define("CUSLAN_35", "Aktualizácia vlastnej stránky dokončená - aktualizované");
define("CUSLAN_36", "Pre nastavenia vlastných konfigurácií pre každé menu sa vráťte, prosím, na úvodnp stránku vlastných stránok/menu a pokračujte v editácií.");
define("CUSLAN_37", "Vlastná stránka aktualizovaná");
define("CUSLAN_38", "áno");
define("CUSLAN_39", "nie");
define("CUSLAN_40", "Uložiť nastavenia");

define("CUSLAN_41", "Zobraziť informácie o autorovi a dátume");
define("CUSLAN_42", "Zatiaľ neboli definované žiadne stránky");

?>
