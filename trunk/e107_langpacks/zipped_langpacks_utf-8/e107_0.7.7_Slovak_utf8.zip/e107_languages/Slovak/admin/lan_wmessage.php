<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_wmessage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: manro $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Message for Guests");
// define("WMGLAN_2", "Message for Members");
// define("WMGLAN_3", "Message for Administrators");
// define("WMGLAN_4", "Submit");
// define("WMGLAN_5", "Set Welcome Message");
// define("WMGLAN_6", "Activate?");
// define("WMGLAN_7", "Welcome message settings updated.");

define("WMLAN_00","Uvítacie správy");
define("WMLAN_01","Vytvoriť novú správu");
define("WMLAN_02","Správa");
define("WMLAN_03","Viditeľnosť");
define("WMLAN_04","Text správy");

define("WMLAN_05","Uzavretá");
define("WMLAN_06","Označte, ak chcete aby bola správa renderovaná v samostatnom boxe");
define("WMLAN_07","Povoliť štandardný systém použitia kódu {WMESSAGE}:");
// define("WMLAN_08","Preferences");

define("WMLAN_09","Žiadne uvítacie správy");
define("WMLAN_10","Popis správy");    

?>
