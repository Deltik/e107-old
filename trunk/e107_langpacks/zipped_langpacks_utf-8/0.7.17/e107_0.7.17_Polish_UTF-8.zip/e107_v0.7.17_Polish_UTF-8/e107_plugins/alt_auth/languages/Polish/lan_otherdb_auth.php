<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     Plik modyfikowany dla tłumaczenia [adv_pl]
|     $Revision: 1.1 $
|     $Date: 2006/10/19 16:41:26 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/alt_auth/languages/Polish/lan_otherdb_auth.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/alt_auth/languages/English/lan_otherdb_auth.php rev. 1.2
+-----------------------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Typ bazy danych:");
define("OTHERDB_LAN_2", "Serwer:");
define("OTHERDB_LAN_3", "Użytkownik:");
define("OTHERDB_LAN_4", "Hasło:");
define("OTHERDB_LAN_5", "Baza danych");
define("OTHERDB_LAN_6", "Tabela");
define("OTHERDB_LAN_7", "Pole użytkownika:");
define("OTHERDB_LAN_8", "Pole hasła:");
define("OTHERDB_LAN_9", "Rodzaj hasła:");
define("OTHERDB_LAN_10", "Konfiguracja otherdb auth");
define("OTHERDB_LAN_11", "** Te pola nie są wymagane jeśli używasz bazy danych e107");

?>
