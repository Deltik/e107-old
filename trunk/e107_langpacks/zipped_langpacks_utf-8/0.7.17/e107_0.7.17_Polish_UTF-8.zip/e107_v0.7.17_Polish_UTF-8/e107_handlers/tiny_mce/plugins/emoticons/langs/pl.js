/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2009/09/13 10:10:23 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/emoticons/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/emoticons/langs/en.php rev. 1.3
+-----------------------------------------------------------------------------+
*/

tinyMCE.addI18n('pl.emoticons',{
	desc : 'Emotikony'
});