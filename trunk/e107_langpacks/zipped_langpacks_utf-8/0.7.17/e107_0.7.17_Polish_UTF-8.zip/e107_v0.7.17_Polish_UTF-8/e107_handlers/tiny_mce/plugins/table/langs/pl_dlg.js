/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.1 $
|     $Date: 2009/09/13 09:47:39 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/table/langs/pl_dlg.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/table/langs/en_dlg.js rev. 1.1
+-----------------------------------------------------------------------------+
*/


tinyMCE.addI18n('pl.table_dlg',{
general_tab:"G\u0142\u00F3wna",
advanced_tab:"Zaawansowana",
general_props:"G\u0142\u00F3wne w\u0142a\u015Bciwo\u015Bci",
advanced_props:"Zaawansowane w\u0142a\u015Bciwo\u015Bci",
rowtype:"Wiersz w cz\u0119\u015Bci tabeli",
title:"Wklej/Zmie\u0144 tabel\u0119",
width:"Szeroko\u015B\u0107",
height:"Wysoko\u015B\u0107",
cols:"Kolumny",
rows:"Wiersze",
cellspacing:"Odst\u0119py mi\u0119dzy kom\u00F3rkami",
cellpadding:"Margines wewn\u0105trz kom\u00F3rek",
border:"Ramka",
align:"Wyr\u00F3wnanie",
align_default:"Domy\u015Blnie",
align_left:"Lewy",
align_right:"Prawy",
align_middle:"\u015Arodek",
row_title:"W\u0142a\u015Bciwo\u015Bci wiersza",
cell_title:"W\u0142a\u015Bciwo\u015Bci kom\u00F3rki",
cell_type:"Typ kom\u00F3rki",
valign:"Pionowe wyr\u00F3wnanie",
align_top:"G\u00F3ra",
align_bottom:"D\u00F3\u0142",
bordercolor:"Kolor ramki",
bgcolor:"Kolor t\u0142a",
merge_cells_title:"Po\u0142\u0105cz kom\u00F3rki",
id:"Id",
style:"Styl",
langdir:"Kierunek czytania tekstu",
langcode:"Oznaczenie kodowe j\u0119zyka",
mime:"Docelowy typ MIME",
ltr:"Kierunek z lewej do prawej",
rtl:"Kierunek z prawej do lewej",
bgimage:"Obrazek t\u0142a",
summary:"Podsumowanie",
td:"Data",
th:"Nag\u0142owek",
cell_cell:"Zmie\u0144 aktualn\u0105 kom\u00F3rk\u0119",
cell_row:"Zmie\u0144 wszytkie kom\u00F3rki w wierszu",
cell_all:"Zmie\u0144 wszytkie kom\u00F3rki w tabeli",
row_row:"Zmie\u0144 aktualny wiersz",
row_odd:"Zmie\u0144 nieparzyste wiersze",
row_even:"Zmie\u0144 parzyste wiersze",
row_all:"Zmie\u0144 wszystkie wiersze",
thead:"Nag\u0142\u00F3wek tabeli",
tbody:"Cia\u0142o tabeli",
tfoot:"Stopka tabeli",
scope:"Zakres",
rowgroup:"Grupa wierszy",
colgroup:"Grupa kolumn",
col_limit:"Przekroczy\u0142e\u015B maksymaln\u0105 liczb\u0119 kolumn kt\u00F3ra wynosi {$cols}.",
row_limit:"Przekroczy\u0142e\u015B maksymaln\u0105 liczb\u0119 wierszy kt\u00F3ra wynosi {$rows}.",
cell_limit:"Przekroczy\u0142e\u015B maksymaln\u0105 liczb\u0119 kom\u00F3rek kt\u00F3ra wynosi {$cells}.",
missing_scope:"Jeste\u015B pewny \u017Ce chcesz kontynuowa\u0107 bez definiowania zasi\u0119gu dla kom\u00F3rki tabeli. Bez niej, mo\u017Ce by\u0107 trudne dla niekt\u00F3rych u\u017Cytkownik\u00F3w zrozuminie zawarto\u015Bci albo danych wy\u015Bwietlanych poza tabel\u0105.",
caption:"Nag\u0142\u00F3wek tabeli",
frame:"Ramka",
frame_none:"brak",
frame_groups:"grupy",
frame_rows:"wiersze",
frame_cols:"kolumny",
frame_all:"wszystkie",
rules:"Prowadnice",
rules_void:"void",
rules_above:"nad",
rules_below:"pod",
rules_hsides:"hsides",
rules_lhs:"lhs",
rules_rhs:"rhs",
rules_vsides:"vsides",
rules_box:"box",
rules_border:"border"
});