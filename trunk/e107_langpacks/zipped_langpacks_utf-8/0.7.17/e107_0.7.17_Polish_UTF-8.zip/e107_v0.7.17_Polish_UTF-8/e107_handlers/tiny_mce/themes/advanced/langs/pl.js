/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2009/09/13 10:10:23 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/themes/advanced/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/themes/advanced/langs/en.js rev. 1.9
+-----------------------------------------------------------------------------+
*/

tinyMCE.addI18n('pl.advanced',{
style_select:"Styl",
font_size:"Rozmiar czcionki",
fontdefault:"Rodzaj czcionki",
block:"Format",
paragraph:"Paragraf",
div:"Div",
address:"Adres",
pre:"Czcionka o sta\u0142ej szeroko\u015Bci",
h1:"Nag\u0142\u00F3wek 1",
h2:"Nag\u0142\u00F3wek 2",
h3:"Nag\u0142\u00F3wek 3",
h4:"Nag\u0142\u00F3wek 4",
h5:"Nag\u0142\u00F3wek 5",
h6:"Nag\u0142\u00F3wek 6",
blockquote:"Wydzielony blok",
code:"Kod",
samp:"Pr\u00F3bka kodu",
dt:"Definicja terminu ",
dd:"Opis terminu",
bold_desc:"Pogrubienie (Ctrl+B)",
italic_desc:"Kursywa (Ctrl+I)",
underline_desc:"Podkre\u015Blenie (Ctrl+U)",
striketrough_desc:"Przekre\u015Blenia",
justifyleft_desc:"Wyr\u00F3wnaj do lewej",
justifycenter_desc:"Wycentruj",
justifyright_desc:"Wyr\u00F3wnaj do prawej",
justifyfull_desc:"R\u00F3wnanie do prawej i lewej",
bullist_desc:"Lista nienumerowana",
numlist_desc:"Lista numerowana",
outdent_desc:"Cofnij wci\u0119cie",
indent_desc:"Wci\u0119cie",
undo_desc:"Cofnij (Ctrl+Z)",
redo_desc:"Pon\u00F3w (Ctrl+Y)",
link_desc:"Wstaw/edytuj link",
unlink_desc:"Usu\u0144 link",
image_desc:"Wstaw/edytuj obraz",
cleanup_desc:"Wyczy\u015B\u0107 nieuporz\u0105dkowany kod",
code_desc:"Edytuj \u017Ar\u00F3d\u0142o HTML",
sub_desc:"Indeks dolny",
sup_desc:"Indeks g\u00F3rny",
hr_desc:"Wstaw poziom\u0105 lini\u0119",
removeformat_desc:"Usu\u0144 formatowanie",
custom1_desc:"Tw\u00F3j niestandardowy opis tutaj",
forecolor_desc:"Wybierz kolor tekstu",
backcolor_desc:"Wybierz kolor t\u0142a",
charmap_desc:"Wstaw niestandardowy znak",
visualaid_desc:"Prze\u0142\u0105cz widoczno\u015B\u0107 wska\u017Anik\u00F3w i niewidocznych element\u00F3w",
anchor_desc:"Wstaw/edytuj kotwic\u0119",
cut_desc:"Wytnij",
copy_desc:"Kopiuj",
paste_desc:"Wklej",
image_props_desc:"W\u0142a\u015Bciwo\u015Bci obrazka",
newdocument_desc:"Nowy dokument",
help_desc:"Pomoc",
blockquote_desc:"Blok cytatu",
clipboard_msg:"Akcje Kopiuj/Wytnij/Wklej nie s\u0105 dost\u0119pne w Mozilli i Firefox.\nCzy chcesz wi\u0119cej informacji o tym problemie?",
path:"\u015Acie\u017Cka",
newdocument:"Czy jeste\u015B pewnien, ze chcesz wyczy\u015Bci\u0107 ca\u0142\u0105 zawarto\u015B\u0107?",
toolbar_focus:"Przeskocz do przycisk\u00F3w narz\u0119dzi - Alt+Q, Przeskocz do edytora - Alt-Z, Przeskocz do elementu \u015Bcie\u017Cki - Alt-X",
more_colors:"Wi\u0119cej kolor\u00F3w"
});
