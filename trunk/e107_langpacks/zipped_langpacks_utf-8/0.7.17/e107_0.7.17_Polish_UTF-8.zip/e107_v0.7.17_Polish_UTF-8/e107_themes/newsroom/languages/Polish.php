<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2007/02/10 15:53:40 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_themes/newsroom/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_themes/newsroom/languages/English.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("LAN_THEME_1", "Komentarze");
define("LAN_THEME_2", "Komentarze wyłączone");
define("LAN_THEME_3", "CZYTAJ WIĘCEJ");
define("LAN_THEME_4", "Data dodania");
?>
