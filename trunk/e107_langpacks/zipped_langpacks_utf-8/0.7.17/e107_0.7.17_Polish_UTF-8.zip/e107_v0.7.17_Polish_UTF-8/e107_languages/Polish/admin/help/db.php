<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/db.php,v $
|     $Revision: 1.4 $
|     $Date: 2009/09/13 08:15:05 $
|     $Author: marcelis_pl $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "These collection of tools allow you to manage your database.";
$ns -> tablerender("Database Tools", $text);
?>
