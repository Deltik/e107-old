<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.6 $
|     $Date: 2009/09/13 08:17:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_submitnews.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_submitnews.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Dodaj newsa");
define("LAN_7", "Imię i nazwisko: ");
define("LAN_62", "Tytuł: ");
define("LAN_112", "Adres e-mail: ");
define("LAN_133", "Dziękujemy");
define("LAN_134", "Twoja wiadomość została przedłożona do kontroli przez jednego z administratorów witryny.");
define("LAN_135", "Wiadomość: ");
define("LAN_136", "Dodaj newsa");
define("NWSLAN_6", "Kategoria");
define("NWSLAN_10", "Brak kategorii aktualności");
define("NWSLAN_11", "Nie masz dostępu do tego obszaru.");
define("NWSLAN_12", "Odmowa dostępu.");

define("SUBNEWSLAN_1", "Musisz podać tytuł.\\n");
define("SUBNEWSLAN_2", "Musisz podać jakiś tekst w wiadomości.\\n");
define("SUBNEWSLAN_3", "Załączniki muszą być w formacie jpg, gif lub png");
define("SUBNEWSLAN_4", "Plik jest za duży");
define("SUBNEWSLAN_5", "Plik grafiki");
define("SUBNEWSLAN_6", "(jpg, gif lub png)");
define('SUBNEWSLAN_7', 'Musisz podać swoje imię i nazwisko oraz adres e-mail');
define('SUBNEWSLAN_8', 'Błąd przesyłu grafiki');
?>