<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.3 $
|     $Date: 2009/07/12 12:59:28 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_footer.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_footer.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("FOOTLAN_1", "Strona");
define("FOOTLAN_2", "Główny administrator");
define("FOOTLAN_3", "Wersja");
define("FOOTLAN_4", "kompilacja");
define("FOOTLAN_5", "Motyw panelu admina");
define("FOOTLAN_6", "wykonany przez");
define("FOOTLAN_7", "Informacje");
define("FOOTLAN_8", "Data instalacji");
define("FOOTLAN_9", "Serwer");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "Wersja PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Informacje o stronie");
define("FOOTLAN_14", "Pokaż dokumentację");
define("FOOTLAN_15", "Dokumentacja");
define("FOOTLAN_16", "Baza danych");
define("FOOTLAN_17", "Strona kodowa");
define("FOOTLAN_18", "Motyw graficzny strony");

?>