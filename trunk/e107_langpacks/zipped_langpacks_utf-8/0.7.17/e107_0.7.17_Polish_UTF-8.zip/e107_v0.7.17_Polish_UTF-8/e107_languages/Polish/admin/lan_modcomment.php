<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.2 $
|     $Date: 2009/07/12 12:59:29 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_modcomment.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_modcomment.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("MDCLAN_1", "Komentarze zmoderowano.");
define("MDCLAN_2", "Brak komentarzy dla tej pozycji");
define("MDCLAN_3", "Użytkownik");
define("MDCLAN_4", "Gość");
define("MDCLAN_5", "Odblokuj");
define("MDCLAN_6", "Zablokuj");

define("MDCLAN_8", "Moderacja komentarzy");
define("MDCLAN_9", "Uwaga! Usunięcie komentarza spowoduje również skasowanie wszystkich tyczących się niego odpowiedzi!");

define("MDCLAN_10", "Opcje");
define("MDCLAN_11", "komentarz");
define("MDCLAN_12", "komentarze");
define("MDCLAN_13", "zablokowany");
define("MDCLAN_14", "Zablokuj pisanie komentarzy");
define("MDCLAN_15", "Nie");
define("MDCLAN_16", "Tak");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>