<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/tree_menu/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Konfigurera trädmeny");
define("TREE_L2", "Uppdatera inställningar för trädmeny");
define("TREE_L3", "Trädenykonfiguration sparad.");
define("TREE_L4", "På");
define("TREE_L5", "Av");

?>
