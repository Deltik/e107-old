<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Swedish/lan_forum_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Välj forum");
define("FOR_SCH_LAN_3", "Alla forum");
define("FOR_SCH_LAN_4", "Hela inlägget");
define("FOR_SCH_LAN_5", "Som del av en tråd");

?>
