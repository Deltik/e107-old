<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Swedish/lan_forum_conf.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/13 16:20:21 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "Röstning raderad.");
define("FORLAN_6", "Tråd raderad");
define("FORLAN_7", "svar raderade");
define("FORLAN_8", "Radering avbruten.");
define("FORLAN_9", "Tråd flyttad.");
define("FORLAN_10", "Flyttning avbruten.");
define("FORLAN_11", "Tillbaka till forum");
define("FORLAN_12", "Forumkonfiguration");
define("FORLAN_13", "Är du absolut säker på att du vill radera denna röstningen?<br />Väl raderad kan den <b><u>inte</u></b> återfås.");
define("FORLAN_14", "Avbryt");
define("FORLAN_15", "Bekräfta radering av inlägg");
define("FORLAN_16", "Bekräfta radering av röstning");
define("FORLAN_17", "inlagd av");
define("FORLAN_18", "Är du absolut säker på att du vill radera detta forum");
define("FORLAN_19", "tråd och dess relaterade inlägg?");
define("FORLAN_20", "röstningen kommer också att raderas");
define("FORLAN_21", "Väl raderade kan");
define("FORLAN_22", "inlägg?<br />Väl raderat kan det");
define("FORLAN_23", "inte</u></b> återfås");
define("FORLAN_24", "Flytta tråd till forum");
define("FORLAN_25", "Flytta tråd");
define("FORLAN_26", "Svar raderat");

define("FORLAN_27", "flyttat");

?>