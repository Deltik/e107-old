<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/calendar_menu/languages/Swedish_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("CM_SCH_LAN_1", "Kalender");

?>