<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/counter_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 12:05:43 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("COUNTER_L1", "Adminbesök räknas inte.");
define("COUNTER_L2", "Denna sida idag");
define("COUNTER_L3", "Totalt");
define("COUNTER_L4", "För alltid på denna sida...");
define("COUNTER_L5", "unika");
define("COUNTER_L6", "Sajt...");
define("COUNTER_L7", "Räknare");
define("COUNTER_L8", "Adminmeddelande: <b>Statistikloggning är inte aktiverad.</b><br />För att aktivera måste du installera statistikloggningspluginen från din <a href='".e_ADMIN."plugin.php'>plugin hanterare</a>, och sedan aktivera den från <a href='".e_PLUGIN."log/admin_config.php'>konfigurationssidan</a>.");

?>
