<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/rss_menu/languages/Swedish.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/10/17 10:58:03 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " kan distribueras genom att använda dessa rss flöden.");
define("BACKEND_MENU_L2", "RSS flöden");

define("BACKEND_MENU_L3", "Våra nyheter");
define("BACKEND_MENU_L4", "Våra kommentarer");
define("BACKEND_MENU_L5", "Våra forumtrådar");
define("BACKEND_MENU_L6", "Våra foruminlägg");

define("BACKEND_MENU_L7", "Våra chattruteinlägg");
define("BACKEND_MENU_L8", "Våra buggspårningsrapporter");
define("BACKEND_MENU_L9", "Våra nerladdningar");

define("RSS_LAN01", "Aktivera separata flöden för varje nyhetskategori?");
define("RSS_LAN02", "Aktivera separata flöden för varje nerladdningskategori?");

define("RSS_NEWS","Nyheter");
define("RSS_COM","Kommentarer");
define("RSS_ART","Artiklar");
define("RSS_REV", "Recensioner");
define("RSS_FT","Forumtrådar");
define("RSS_FP","Foruminlägg");
define("RSS_FSP","Forum specifikt inlägg");
define("RSS_BUG","Buggspårare");
define("RSS_FOR","Forum");
define("RSS_DL","Nerladdningar");

?>
