<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/17 10:58:03 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("ONLINE_L1", "Gäster: ");
define("ONLINE_L2", "Medlemmar: ");
define("ONLINE_L3", "På denna sida: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Medlemmar");
define("ONLINE_L6", "senaste");
define("TRACKING_MESSAGE", "Online användarspårning är för närvarande inaktiverad, aktivera den <a href='".e_ADMIN."users.php?options'>här</a></span><br />");

?>
