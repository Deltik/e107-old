<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/trackback/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("TRACKBACK_L1", "Konfigurera bakåtspårning");
define("TRACKBACK_L2", "Denna plugin låter dig använda bakåtspårning i dina nyheter.");
define("TRACKBACK_L3", "Bakåtspårning är nu installerad och aktiverad.");
define("TRACKBACK_L4", "Bakåtspårningsinställningar sparade.");
define("TRACKBACK_L5", "På");
define("TRACKBACK_L6", "Av");
define("TRACKBACK_L7", "Aktivera bakåtspårning");
define("TRACKBACK_L8", "Bakåtspårning URL text");
define("TRACKBACK_L9", "Spara inställningar");
define("TRACKBACK_L10", "Bakåtspårning inställningar");
define("TRACKBACK_L11", "Bakåtspårningsadress för denna post:");

define("TRACKBACK_L12", "Ingen bakåtspårning för denna post");
define("TRACKBACK_L13", "Moderera bakåtspårningar");
define("TRACKBACK_L14", "Radera");
define("TRACKBACK_L15", "Bakåtspårningar raderade.");

?>
