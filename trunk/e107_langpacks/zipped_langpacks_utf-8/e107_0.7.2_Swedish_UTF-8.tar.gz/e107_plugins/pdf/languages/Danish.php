<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Danish Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/pdf/languages/Danish.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/01/17 15:03:47 $
|     $Author: e107dk $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF oprettelse support");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Denne plugin er nu klar til brug.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF egenskaber");
define("PDF_LAN_3", "anvendt");
define("PDF_LAN_4", "slået fra");
define("PDF_LAN_5", "side margen venstre");
define("PDF_LAN_6", "side margen højre");
define("PDF_LAN_7", "side margen top");
define("PDF_LAN_8", "font familie");
define("PDF_LAN_9", "font størrelse standard");
define("PDF_LAN_10", "font størrelse sitenavn");
define("PDF_LAN_11", "font størrelse side url");
define("PDF_LAN_12", "font størrelse side nummer");
define("PDF_LAN_13", "vis logo på pdf?");
define("PDF_LAN_14", "vis sitenavn på pdf?");
define("PDF_LAN_15", "vis forfatter side url på pdf?");
define("PDF_LAN_16", "vis side numre på pdf?");
define("PDF_LAN_17", "opdater");
define("PDF_LAN_18", "PDF egenskaber opdateret med succes");
define("PDF_LAN_19", "Side");
define("PDF_LAN_20", "fejl  raportering");

?>