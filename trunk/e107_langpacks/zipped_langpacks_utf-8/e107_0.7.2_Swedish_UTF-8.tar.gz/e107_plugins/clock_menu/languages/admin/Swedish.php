<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/admin/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/28 13:13:29 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Klockmeny konfiguration sparad");
define("CLOCK_AD_L2", "Rubrik");
define("CLOCK_AD_L3", "Uppdatera menyinställninar");
define("CLOCK_AD_L4", "Klockmenykonfiguration");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Om markerad kommer tid att visas i amerikanskt format (0-12 AM/PM format). Avmarkerad så visas 'militärt/Europeiskt' format 0-24.");
define("CLOCK_AD_L7", "Datumprefix");
define("CLOCK_AD_L8", "Om ditt språk kräver ett kort ord framför datumet (T.ex 'le' för franska eller 'den' för svenska...), så använd detta fältet. Om inte, lämna tomt.");
define("CLOCK_AD_L9", "Suffix 1");
define("CLOCK_AD_L10", "Suffix 2");
define("CLOCK_AD_L11", "Suffix 3");
define("CLOCK_AD_L12", "Suffix 4 och mer");
define("CLOCK_AD_L13", "Om ditt språk behöver ett suffix direkt efter datumets siffror, fyll då i dessa fält med bara suffixen. (T.ex: 'sta' för 1, 'a' för 2, 'e' för 3 och 'de' för 4 och så vidare). Om inte, lämna tomma fält.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");

?>
