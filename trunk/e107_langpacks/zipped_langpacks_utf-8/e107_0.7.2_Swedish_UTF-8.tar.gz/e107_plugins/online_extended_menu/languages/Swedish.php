<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_extended_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/08 06:34:30 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Gäster: ");
define("ONLINE_EL2", "Medlemmar: ");
define("ONLINE_EL3", "På denna sida: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Medlemmar");
define("ONLINE_EL6", "Nyaste medlemmen");
define("ONLINE_EL7", "läser");

define("ONLINE_EL8", "flest online någonsin: ");
define("ONLINE_EL9", "den");

define("TRACKING_MESSAGE", "Online användarspårning är inte aktiverad. Aktivera den <a href='".e_ADMIN."users.php?options'>här</a></span><br />");

?>
