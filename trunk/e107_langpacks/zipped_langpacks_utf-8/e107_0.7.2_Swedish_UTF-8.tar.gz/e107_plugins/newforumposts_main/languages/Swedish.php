<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newforumposts_main/languages/Swedish.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Tråd");
define("NFPM_LAN_2", "Författare");
define("NFPM_LAN_3", "Visningar");
define("NFPM_LAN_4", "Svar");
define("NFPM_LAN_5", "Senaste inlägg");
define("NFPM_LAN_6", "Trådar");
define("NFPM_LAN_7", "av");

define("NFPM_L1", "Denna plugin visar en lista på nya foruminlägg på din förstasida");
define("NFPM_L2", "Senaste foruminlägg");
define("NFPM_L3", "För att konfigurera, klicka på länken i pluginssektionen på admins förstasida");
define("NFPM_L4", "Aktivera i vilken area?");
define("NFPM_L5", "Inaktiv");
define("NFPM_L6", "Sidans början");
define("NFPM_L7", "Sidans slut");
define("NFPM_L8", "Rubrik");
define("NFPM_L9", "Antal nya inlägg att visa?");
define("NFPM_L10", "Visa i ett rullande lager?");
define("NFPM_L11", "Lagrets höjd");
define("NFPM_L12", "Konfiguration för nya foruminlägg");
define("NFPM_L13", "Uppdatera inställningar för nya foruminlägg");
define("NFPM_L14", "Inställningara uppdaterade.");
define("NFPM_L15", "Markera för att visa senaste foruminlägg.<br />Standard är senaste ämnen.");
define('NFPM_L16', '[användare raderad]');

?>