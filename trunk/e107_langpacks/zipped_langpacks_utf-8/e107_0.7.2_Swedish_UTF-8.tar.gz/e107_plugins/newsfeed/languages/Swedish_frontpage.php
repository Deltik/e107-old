<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsfeed/languages/Swedish_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "Nyhetsflöden");
define("NWSF_FP_2", "Huvudsida");

?>
