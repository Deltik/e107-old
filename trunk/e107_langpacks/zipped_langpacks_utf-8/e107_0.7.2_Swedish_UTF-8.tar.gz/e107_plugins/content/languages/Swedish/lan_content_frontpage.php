<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Swedish/lan_content_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/16 15:45:55 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("CONT_FP_1", "Inneh�llskategori");
define("CONT_FP_2", "Huvudsida");

?>
