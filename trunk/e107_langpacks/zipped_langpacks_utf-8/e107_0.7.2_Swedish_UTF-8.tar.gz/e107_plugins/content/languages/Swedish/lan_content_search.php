<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Swedish/lan_content_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/16 15:45:55 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Innehåll");
define("CONT_SCH_LAN_2", "Alla innehållskategorier");
define("CONT_SCH_LAN_3", "Postat som svar till");

?>
