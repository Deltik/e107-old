<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:52 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "Fält lämnat tomt.");
define("LWLAN_2", "Länkord sparat.");
define("LWLAN_3", "Länkord uppdaterat.");
define("LWLAN_4", "Inga länkord definierade ännu.");
define("LWLAN_5", "Ord");
define("LWLAN_6", "Länk");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Alternativ");
define("LWLAN_9", "ja");
define("LWLAN_10", "nej");
define("LWLAN_11", "Befintliga länkord");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nej");
define("LWLAN_14", "Skicka in länkord");
define("LWLAN_15", "Uppdatera öänkord");
define("LWLAN_16", "Redigera");
define("LWLAN_17", "Radera");
define("LWLAN_18", "Är du säker på att du vill radera detta länkord?");
define("LWLAN_19", "Länkord raderat.");
define("LWLAN_20", "Kan inte hitta den länkordsposten.");
define("LWLAN_21","Ord att autolänka");
define("LWLAN_22","Aktivera?");

define("LWLANINS_1", "Länkord");
define("LWLANINS_2", "Denna plugin kommer att länka specificerade ord till en definierad länk");
define("LWLANINS_3", "Konfigurera länkord");
define("LWLANINS_4", "För att konfigurera, klicka på länken i pluginsektionen på admins förstasida");

?>
