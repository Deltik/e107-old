<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Swedish/Swedish_config.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Chattruteinställningar uppdaterade.");
define("CHBLAN_2", "Modererat.");
define("CHBLAN_3", "Inga chattruteinlägg ännu.");
define("CHBLAN_4", "Medlem");
define("CHBLAN_5", "Gäst");
define("CHBLAN_6", "häv blockering");
define("CHBLAN_7", "blockera");
define("CHBLAN_8", "radera");
define("CHBLAN_9", "Moderera chattruta");
define("CHBLAN_10", "Moderera inlägg");
define("CHBLAN_11", "Chattruteinlägg att visa");
define("CHBLAN_12", "mängd inlägg visade i chattrutan");
define("CHBLAN_13", "Byt ut länkar");
define("CHBLAN_14", "om markerad kommer länkar att bytas ut mot texten i rutan nedan");
define("CHBLAN_15", "Utbytessträng om aktiverad");
define("CHBLAN_16", "kommer länkar att bytas ut mot denna text");
define("CHBLAN_17", "Orbrytningslängd");
define("CHBLAN_18", "ord längre än det antal tecken du anger här kommer att brytas");
define("CHBLAN_19", "Uppdatera chattruteinställningar");
define("CHBLAN_20", "Chattruteinställningar");
define("CHBLAN_21", "Rensa");
define("CHBLAN_22", "Radera inlägg äldre än en viss tid");
define("CHBLAN_23", "Radera inlägg äldre än ");

define("CHBLAN_24", "En dag");
define("CHBLAN_25", "En vecka");
define("CHBLAN_26", "En månad");
define("CHBLAN_27", "- Radera alla inlägg -");
define("CHBLAN_28", "Chattrutan rensad.");

define("CHBLAN_29", "Visa chattrutan inuti ett rullande lager");
define("CHBLAN_30", "Lagrets höjd");
define("CHBLAN_31", "Visa smajlys");
define("CHBLAN_32", "Moderator användarklass");

define("CHBLAN_33", "Användare omräknade");
define("CHBLAN_34", "Räkna om användarpostningar");
define("CHBLAN_35", "Räkna om");
define("CHBLAN_36", "Visningsalternativ för chattruta");
define("CHBLAN_37", "Normal chattruta");
define("CHBLAN_38", "Använd javascriptkod för att uppdatera innehållet dynamiskt (AJAX)");

?>