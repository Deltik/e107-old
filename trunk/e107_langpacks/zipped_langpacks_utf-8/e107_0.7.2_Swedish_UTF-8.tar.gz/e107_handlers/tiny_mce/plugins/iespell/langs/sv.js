/*
+ ----------------------------------------------------------------------------+
|     Swedish (SE) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/iespell/langs/sv.js,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
iespell_desc : 'Kör rättstavningskontroll',
iespell_download : "ieSpell verkar inte vara installerad. Klicka OK för att ladda hem."
});
