<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/jayya/languages/Swedish.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/26 11:12:24 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Kommentarer är avaktiverade för detta objekt");
define("LAN_THEME_2", "Läs/Posta kommentar: ");
define("LAN_THEME_3", "Läs resten...");
define("LAN_THEME_4", "Bakåtlänkar: ");
define("LAN_THEME_5", "Postad av");
define("LAN_THEME_6", "den");

?>
