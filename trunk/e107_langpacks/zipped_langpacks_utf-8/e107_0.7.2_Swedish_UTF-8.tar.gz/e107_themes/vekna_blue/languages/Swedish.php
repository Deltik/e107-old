<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/vekna_blue/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'vekna blue' av <a href='http://e107.org' rel='external'>jalist</a>, baserat på, och med tillstånd från Arach's sajt, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Läs/Posta kommentar: ");
define("LAN_THEME_3", "Kommentarer är avaktiverade för detta objekt");
define("LAN_THEME_4", "Läs resten ...");
define("LAN_THEME_5", "Bakåtlänkar: ");

?>
