<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/khatru/languages/Swedish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/17 11:39:41 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'khatru' av <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Kommentarer är avstängda för detta objekt");
define("LAN_THEME_3", "Kommentar: ");
define("LAN_THEME_4", "Läs resten ...");
define("LAN_THEME_5", "Bakåtlänkar: ");

?>
