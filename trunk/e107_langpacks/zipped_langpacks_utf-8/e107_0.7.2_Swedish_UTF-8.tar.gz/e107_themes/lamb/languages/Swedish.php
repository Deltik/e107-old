<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/lamb/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'lamb' av <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Kommentarer är avaktiverade för detta objekt");
define("LAN_THEME_3", "kommentar: ");
define("LAN_THEME_4", "Läs resten ...");
define("LAN_THEME_5", "Bakåtlänkar: ");


?>
