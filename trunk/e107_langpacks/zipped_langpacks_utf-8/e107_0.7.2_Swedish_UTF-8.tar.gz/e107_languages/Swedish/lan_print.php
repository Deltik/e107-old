<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Utskriftsvänlig");

define("LAN_86", "Kategori:");
define("LAN_87", "av ");
define("LAN_94", "Postad av");
define("LAN_135", "Nyhet: ");
define("LAN_303", "Denna nyhet är från ");
define("LAN_304", "Rubrik: ");
define("LAN_305", "Underrubrik: ");
define("LAN_306", "Detta är från: ");
define("LAN_307", "Skriv ut sidan");

?>
