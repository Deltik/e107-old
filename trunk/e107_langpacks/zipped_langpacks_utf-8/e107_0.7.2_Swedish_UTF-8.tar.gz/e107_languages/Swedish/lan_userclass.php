<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Alla (publik)");
define("UC_LAN_1", "Gäster");
define("UC_LAN_2", "Ingen (inaktiv)");
define("UC_LAN_3", "Medlemmar");
define("UC_LAN_4", "Skrivskyddad");
define("UC_LAN_5", "Admin");

?>
