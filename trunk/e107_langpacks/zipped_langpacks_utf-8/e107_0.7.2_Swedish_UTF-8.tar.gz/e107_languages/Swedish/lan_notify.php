<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/26 11:12:22 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Användarregistrering");

define("NT_LAN_UV_1", "Användarregistrering verifierad");
define("NT_LAN_UV_2", "Användares sessionssträng");

define("NT_LAN_LI_1", "Användare loggade in");

define("NT_LAN_LO_1", "Användare loggade ut");
define("NT_LAN_LO_2", " utloggad från sajten");

define("NT_LAN_FL_1", "Flödningsspärrad");
define("NT_LAN_FL_2", "IP-adress spärrad p.g.a. flödning");

define("NT_LAN_SN_1", "Nyhetsämne postat");

define("NT_LAN_NU_1", "Uppdaterad");

define("NT_LAN_ND_1", "Nyhetsämne raderat");
define("NT_LAN_ND_2", "Raderat nyhetsämnes ID");

?>
