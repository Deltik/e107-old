<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_fla.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Misslyckade inloggningsförsök");
define("FLALAN_2", "Inga misslyckade inloggningar har loggats");
define("FLALAN_3", "Försök raderade");
define("FLALAN_4", "Användare försökte logga in med felaktigt användarnamn/lösenord");
define("FLALAN_5", "Spärrade IP(s)");
define("FLALAN_6", "Datum");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP adress/Värd");
define("FLALAN_9", "Alternativ");
define("FLALAN_10", "Radera/Spärra markerade poster");
define("FLALAN_11", "markera alla radera-rutorna");
define("FLALAN_12", "avmarkera alla radera-rutorna");
define("FLALAN_13", "markera alla spärra-rutorna");
define("FLALAN_14", "avmarkera alla spärra-rutorna");
define("FLALAN_15", "Följande IP adress(er) har blivit auto-spärrade - användare har gjort fler än tio felaktiga inloggningar");
define("FLALAN_16", "Radera denna autospärrlista");
define("FLALAN_17", "Autospärrlista raderad");

?>
