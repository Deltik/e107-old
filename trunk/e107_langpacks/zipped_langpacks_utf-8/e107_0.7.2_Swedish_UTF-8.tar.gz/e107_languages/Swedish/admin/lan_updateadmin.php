<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Fel - skicka igen");
define("UDALAN_2", "Inställningar uppdaterade");
define("UDALAN_3", "Inställningar uppdaterade för");
define("UDALAN_4", "Namn");
define("UDALAN_5", "Lösenord");
define("UDALAN_6", "Ange lösenord igen");
define("UDALAN_7", "Ändra lösenord");
define("UDALAN_8", "Lösenord uppdatering för");

?>
