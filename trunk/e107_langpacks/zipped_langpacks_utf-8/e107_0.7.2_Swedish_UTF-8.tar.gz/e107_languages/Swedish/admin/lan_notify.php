<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_1", "Notifiera");
define("NT_LAN_2", "Ta emot e-postnotifiering om");
define("NT_LAN_3", "Av");
define("NT_LAN_4", "Huvudadmin");
define("NT_LAN_5", "Klass");
define("NT_LAN_6", "E-post");

define("NU_LAN_1", "Användarhändelse");
define("NU_LAN_2", "Användarregistrering");
define("NU_LAN_3", "Användarkonto verifierat");
define("NU_LAN_4", "Användarinloggning");
define("NU_LAN_5", "Användarutloggning");

define("NS_LAN_1", "Säkerhetshändelse");
define("NS_LAN_2", "IP spärrat för flödning av sajten");

define("NN_LAN_1", "Nyhetshändelse");
define("NN_LAN_2", "Nyhetspost insänd av användare");
define("NN_LAN_3", "Nyhet postad av admin");
define("NN_LAN_4", "Nyhet redigerad av admin");
define("NN_LAN_5", "Nyhet raderad av admin");

?>
