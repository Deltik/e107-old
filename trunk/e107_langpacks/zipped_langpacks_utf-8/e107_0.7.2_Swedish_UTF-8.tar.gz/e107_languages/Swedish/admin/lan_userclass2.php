<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_userclass2.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/09/18 11:07:48 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Tog bort alla användare från klass.");
define("UCSLAN_2", "Klassanvändare uppdaterade.");
define("UCSLAN_3", "Klass raderad.");
define("UCSLAN_4", "Markera för att bekräfta radering av denna användarklass");
define("UCSLAN_5", "Klass uppdaterad.");
define("UCSLAN_6", "Klass sparad till databasen.");
define("UCSLAN_7", "Inga användarklasser ännu.");
define("UCSLAN_8", "Befintliga klasser");

// define("UCSLAN_9", "Redigera");
// define("UCSLAN_10", "Radera");
define("UCSLAN_11", "markera för att bekräfta");
define("UCSLAN_12", "Klassnamn");
define("UCSLAN_13", "Klassbeskrivning");
define("UCSLAN_14", "Uppdatera användarklass");
define("UCSLAN_15", "Skapa ny klass");
define("UCSLAN_16", "Lägg till användare till klass");
define("UCSLAN_17", "Ta bort");
define("UCSLAN_18", "Rensa klass");
define("UCSLAN_19", "Lägg till användare till");
define("UCSLAN_20", "klass");
define("UCSLAN_21", "Användarklass inställningar");

define("UCSLAN_22", "Användare - klicka för att flytta...");
define("UCSLAN_23", "Användare i denna klass...");

define("UCSLAN_24", "Vem kan hantera klass");

?>
