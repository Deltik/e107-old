<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_filemanager.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "Uppladdad");
define("FMLAN_2", "till");
define("FMLAN_3", "katalog");
define("FMLAN_4", "Den uppladdade filen överskrider upload_max_filesize direktivet i php.ini.");
// define("FMLAN_5", "Den uppladdade filen överskrider MAX_FILE_SIZE direktivet som specifiecerades i html-formuläret.");
// define("FMLAN_6", "Filen blev bara delvis uppladdad.");
// define("FMLAN_7", "Ingen fil laddades upp.");
// define("FMLAN_8", "Uppladdad filstorlek 0 bytes");
// define("FMLAN_9", "Filen laddades inte upp. Filnamn");
// define("FMLAN_10", "Fel");
// define("FMLAN_11", "Antagligen felaktiga rättigheter till uppladdningskatalogen.");
define("FMLAN_12", "fil");
define("FMLAN_13", "filer");
define("FMLAN_14", "katalog");
define("FMLAN_15", "kataloger");
define("FMLAN_16", "Root katalog");
define("FMLAN_17", "Namn");
define("FMLAN_18", "Storlek");
define("FMLAN_19", "Senast ändrad");

define("FMLAN_21", "Ladda upp fil till denna katalog");
define("FMLAN_22", "Ladda upp");

define("FMLAN_26", "Raderad");
define("FMLAN_27", "korrekt");
define("FMLAN_28", "Kan inte radera");
define("FMLAN_29", "Sökväg");
define("FMLAN_30", "Upp nivå");
define("FMLAN_31", "folder");

define("FMLAN_32", "Välj katalog");
define("FMLAN_33", "Välj");
define("FMLAN_34", "Katalogval");
define("FMLAN_35", "Filer katalog");

define("FMLAN_36", "Katalog egna menyer");
define("FMLAN_37", "Katalog egna sidor");

define("FMLAN_38", "Flyttade filen till");
define("FMLAN_39", "Kunde inte flytta filen till");
define("FMLAN_40", "Katalog, nyhetsbilder");


define("FMLAN_43", "Radera valda filer");


define("FMLAN_46", "Bekräfta att du vill RADERA de valda filerna.");
define("FMLAN_47", "Användares uppladdningar");

define("FMLAN_48", "Flytta valda till");
define("FMLAN_49", "Bekräfta att du vill flytta de valda filerna.");
define("FMLAN_50", "Flytta");

?>
