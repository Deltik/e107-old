<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_banlist.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Spärr borttagen.");
define("BANLAN_2", "Inga spärrar.");
define("BANLAN_3", "Befintliga spärrar");
define("BANLAN_4", "Ta bort spärr");
define("BANLAN_5", "Ange IP, e-postadress, eller värd");
define("BANLAN_7", "Anledning");
define("BANLAN_8", "Spärra användare");
define("BANLAN_9", "Spärra användare från sajten");
define("BANLAN_10", "IP / E-post / Orsak");
define("BANLAN_11", "Auto-spärra: Fler än 10 misslyckade inloggningsförsök");

?>
