<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_db_verify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Kan inte läsa SQL-datafilen<br /><br />Försäkra dig om att filen <b>core_sql.php</b> finns i <b>/admin/sql</b> katalogen.");
define("DBLAN_2", "Verifierar allt");

define("DBLAN_4", "Tabell");
define("DBLAN_5", "Fält");
define("DBLAN_6", "Status");
define("DBLAN_7", "Noteringar");
define("DBLAN_8", "Stämmer ej");
define("DBLAN_9", "Nuvarande");
define("DBLAN_10", "skall vara");
define("DBLAN_11", "Fält saknas");
define("DBLAN_12", "Extra fält!");
define("DBLAN_13", "Tabell saknas!");
define("DBLAN_14", "Välj tabell(er) att validera");
define("DBLAN_15", "Starta verifiering");
define("DBLAN_16", "SQL verifiering");
define("DBLAN_17", "Tillbaka");
define("DBLAN_18", "tabeller");
define("DBLAN_19", "Försök att rätta");
define("DBLAN_20", "Försöker att rätta tabeller");
define("DBLAN_21", "Rätta valda objekt");

?>
