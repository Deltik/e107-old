<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_cache.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Cachesystem status");
define("CACLAN_2", "Sätt cachestatus");
define("CACLAN_3", "Cachesystem");
define("CACLAN_4", "Cachestatus satt");
define("CACLAN_5", "Töm cache");
define("CACLAN_6", "Cache tömd");

define("CACLAN_7", "Cache inaktiverad");
// define("CACLAN_8", "Cachedata sparad till MySQL");
define("CACLAN_9", "Cachedata sparad till diskfil");
define("CACLAN_10", "Cachebiblioteket skrivskyddat. Verifiera att katalogen är satt till CHMOD 0777");

?>
