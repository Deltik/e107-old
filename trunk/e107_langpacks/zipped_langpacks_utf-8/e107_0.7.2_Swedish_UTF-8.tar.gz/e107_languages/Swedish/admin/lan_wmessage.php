<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_wmessage.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Meddelande för gäster");
// define("WMGLAN_2", "Meddelande för medlemmar");
// define("WMGLAN_3", "Meddelande för administratörer");
// define("WMGLAN_4", "Skicka");
// define("WMGLAN_5", "Sätt hälsningsmeddelande");
// define("WMGLAN_6", "Aktivera?");
// define("WMGLAN_7", "Inställning för välkomsthälsning uppdaterad.");

define("WMLAN_00","Hälsningsmeddelande");
define("WMLAN_01","Skapa nytt meddelande");
define("WMLAN_02","Meddelande");
define("WMLAN_03","Synbarhet");
define("WMLAN_04","Meddelandetext");

define("WMLAN_05","Kapsla in");
define("WMLAN_06","Om markerad kommer meddelandet att visas inuti en ruta");
define("WMLAN_07","Förbigå systemstandard att använda {WMESSAGE} kortkod:");
// define("WMLAN_08","Preferenser");

define("WMLAN_09","Inget hälsningsmeddelande satt ännu");

?>
