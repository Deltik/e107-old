<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_credits.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Tack till");
define("CRELAN_2", "Nedan är en lista på tredjeparts mjukvara / resurser använda i e107. e107's utvecklingsteam vill personligen tacka utvecklarna av följande för att de tillåter oss att återdistribuera deras kod med e107, och för att de släpper sin mjukvara under GPL licensen.");
// define("CRELAN_3", "Resurs");
// define("CRELAN_4", "Beskrivning");
// define("CRELAN_5", "Webbsajt");
// define("CRELAN_6", "Tillåtelse");
define("CRELAN_7", "version");

?>
