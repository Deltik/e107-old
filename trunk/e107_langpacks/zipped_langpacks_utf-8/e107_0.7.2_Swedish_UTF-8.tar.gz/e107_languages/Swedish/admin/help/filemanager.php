<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/filemanager.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan hantera filerna i din /files katalog från denna sidan. Om du får felmeddelande om filrättigheter när du laddar upp, sätt då katalogen du försöker ladda upp till till CHMOD 777.";
$ns -> tablerender("Hjälp Filhanteraren", $text);

?>
