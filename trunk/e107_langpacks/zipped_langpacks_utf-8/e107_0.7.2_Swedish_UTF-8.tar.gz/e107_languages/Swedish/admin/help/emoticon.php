<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/emoticon.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Med smajlys aktiverade kommer standard smajly-text att ersättas med motsvarande smajly-ikon i allt innehåll på din sajt.";

$ns -> tablerender("Smajlyhjälp", $text);

?>
