<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/ugflag.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Om du uppgraderar e107 eller bara behöver ta din sajt offline för en tid, klicka bara i underhållsrutan så kommer dina besökare att omdirigeras till en sida som förklarar att sajen är nere för underhåll. När du är klar, avmarkera rutan och sajten återgår till det vanliga.";

$ns -> tablerender("Underhåll", $text);

?>
