<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/link_category.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan separera dina länkar i olika kategorier, detta gör navigeringen i huvudlänkarna mycket enklare och förbättrar layouten.<br /><br />En länk placerad i huvudkategorin kommer att visas i din huvudnavigeringsmeny.";
$ns -> tablerender("Hjälp länkkategorier", $text);

?>
