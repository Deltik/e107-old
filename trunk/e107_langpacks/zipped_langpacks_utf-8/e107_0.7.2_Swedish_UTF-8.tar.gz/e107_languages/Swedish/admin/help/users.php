<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/users.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Denna sida låter dig moderera dina registrerade användare. Du kan uppdatera deras inställningar, ge dem adminstatus, sätta deras klass med mera.";
$ns -> tablerender("Användarhjälp", $text);
unset($text);

?>
