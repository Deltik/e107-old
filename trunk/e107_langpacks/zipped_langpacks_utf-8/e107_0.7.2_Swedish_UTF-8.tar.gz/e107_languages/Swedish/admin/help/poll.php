<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/poll.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du skapar röstningar/undersökningar från denna sida, bara skriv in rubriken och de olika alternativen, förhandsgranska det och om det ser bra ut, markera rutan för att aktivera den.<br /><br />
För att visa röstningen, gå till din menysida och se till att poll_menu är aktiverad.";

$ns -> tablerender("Röstningar", $text);

?>
