<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/users_extended.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Utökade användarfält låter dig lägga till ytterligare datafält av olika typer som användarna kan fylla i i sin profil.";
$ns -> tablerender("Hjälp för utökade användarfält", $text);

?>
