<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/wmessage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "På denna sidan kan du sätta ett meddelande som alltid visas högst upp på din förstasida när det är atkiverat.
 Du kan ha olika meddelanden för gäster, registrerade/inloggade medlemmar och administratörer.";
$ns -> tablerender("WMeddelande hjälp", $text);

?>
