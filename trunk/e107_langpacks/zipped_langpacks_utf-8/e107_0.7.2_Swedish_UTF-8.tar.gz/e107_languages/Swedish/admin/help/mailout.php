<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/mailout.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Använd denna sida för att konfigurera dina e-postinställningar för sajtens utskicksfunktioner. Utskicksformuläret ger dig också möjlighet att skicka ut ett brev till dina användare.";
$ns -> tablerender("E-posthjälp", $text);

?>
