<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/upload.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Härifrån kan du tillåta/förbjuda att användare laddar upp filer, och du kan hantera de filer som har laddats upp.";
$ns -> tablerender("Publika uppladdningar hjälp", $text);

?>
