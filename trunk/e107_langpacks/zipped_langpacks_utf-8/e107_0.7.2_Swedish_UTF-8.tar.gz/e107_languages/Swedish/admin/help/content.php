<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/content.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan lägga till en vanlig sida till din sajt med denna funktion. En länk till den nya sidan kommer att skapa i sajtens huvudnavigeringsruta. Till exempel om du skapa en ny sida med länknamnet 'Test' kommer en länk benämnd 'Test' att dyka upp  i din länkruta efter att du postat din nya sida.<br />
Om du vill att din sida skall ha en rubrik, ange den i rutan för sidhuvud.";
$ns -> tablerender("Innehållshjälp", $text);

?>
