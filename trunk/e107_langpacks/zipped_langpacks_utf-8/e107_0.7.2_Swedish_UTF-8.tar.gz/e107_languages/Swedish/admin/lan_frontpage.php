<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_frontpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "Förstasidans inställningar uppdaterade.");
define("FRTLAN_2", "Sätt förstasida för");
define("FRTLAN_6", "Länkar");
// define("FRTLAN_7", "Innehållssida");
define("FRTLAN_12", "Uppdatera förstasidans inställningar");
define("FRTLAN_13", "Förstasidans inställningar");
define("FRTLAN_15", "Annat (ange URL):");
define("FRTLAN_16", "Fel: ingen huvudinnehållsvärd vald");
define("FRTLAN_17", "Fel: ingen innehållsunderkategori vald");
define("FRTLAN_18", "Fel: ingen innehållpost vald");
define("FRTLAN_19", "huvudinnehållsvärd");
define("FRTLAN_20", "innehållskategori");
define("FRTLAN_21", "innehållspost");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Alla användare");
define("FRTLAN_27", "Gäster");
define("FRTLAN_28", "Medlemmar");
define("FRTLAN_29", "Administratörer");
define("FRTLAN_31", "Alla användare");
define("FRTLAN_32", "Användarklass");
define("FRTLAN_33", "Nuvarande inställningar");
define("FRTLAN_34", "Sida");

?>
