<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_ugflag.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "underhållsinställningar sparade");
define("UGFLAN_2", "Aktivera underhållsflaggan");
define("UGFLAN_3", "Uppdatera underhållsinställningar");
define("UGFLAN_4", "Underhållsinställningar");

define("UGFLAN_5", "Text att visa när sajten är nere");
define("UGFLAN_6", "Lämna tomt för att visa standardmeddelande");

?>
