<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_cpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/26 11:12:22 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Rubrik");
define("CUSLAN_2", "Typ");
define("CUSLAN_3", "Alternativ");
define("CUSLAN_4", "Radera denna sida?");
define("CUSLAN_5", "Befintliga sidor");
define("CUSLAN_7", "Menynamn");
define("CUSLAN_8", "Rubrik / Rubrikrad");
define("CUSLAN_9", "Text");
define("CUSLAN_10", "Tillåt betygssättning av sidan");
define("CUSLAN_11", "Förstasida");
define("CUSLAN_12", "Skapa sida");
define("CUSLAN_13", "Tillåt kommentarer");
define("CUSLAN_14", "Lösenordsskydda sida");
define("CUSLAN_15", "ange lösenord för skydd av sidan");
define("CUSLAN_16", "Skapa länk i huvudmenyn");
define("CUSLAN_17", "ange länknamn att skapa");
define("CUSLAN_18", "Sida / länk synlig för");
define("CUSLAN_19", "Uppdatera sida");
define("CUSLAN_20", "Skapa sida");
define("CUSLAN_21", "Uppdatera meny");
define("CUSLAN_22", "Skapa meny");
define("CUSLAN_23", "Redigera sida");
define("CUSLAN_24", "Skapa ny sida");
define("CUSLAN_25", "Redigera meny");
define("CUSLAN_26", "Skapa ny meny");
define("CUSLAN_27", "Sidan sparad till databasen.");
define("CUSLAN_28", "Sidan raderad");
define("CUSLAN_29", "Lista sidor om ingen sida valts");
define("CUSLAN_30", "Kakans varaktighet (i sekunder)");
define("CUSLAN_31", "Skapa meny");
define("CUSLAN_32", "Konvertera gamla sidor/menyer");
define("CUSLAN_33", "Alternativ för sida");
define("CUSLAN_34", "Startar konvertering");
define("CUSLAN_35", "Avslutade uppdatering av innehållssid - uppdaterad");
define("CUSLAN_36", "För att sätta preferenser för varje sida, återgå till förstasidan och redigera sidorna.");
define("CUSLAN_37", "Uppdatering av egna sidor");
define("CUSLAN_38", "till");
define("CUSLAN_39", "från");
define("CUSLAN_40", "Spara alternativ");

define("CUSLAN_41", "Visa information om författare och datum");
define("CUSLAN_42", "Inga sidor definierade ännu");

?>
