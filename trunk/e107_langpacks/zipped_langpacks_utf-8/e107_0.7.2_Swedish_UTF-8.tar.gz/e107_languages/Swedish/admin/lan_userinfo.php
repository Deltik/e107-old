<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_userinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Kunde inte hitta postarens IP-adress - ingen information tillgänglig.");
// define("USFLAN_2", "Fel");
define("USFLAN_3", "Meddelanden postade från IP-adress");
define("USFLAN_4", "Värd");
define("USFLAN_5", "Klicka här för att överföra IP-adressen till admins spärrsida");
define("USFLAN_6", "AnvändarID");
define("USFLAN_7", "Användarinformation");

?>
