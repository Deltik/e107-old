<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_header.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Admin navigering");
define("LAN_head_2", "Din server tillåter inte HTTP filuppladdningar, så dina användare kommer inte att kunna ladda upp figurer/filer etc. För att rätta till detta, sätt file_uploads till On i din php.ini och starta om din server. Om du inte har tillgång till php.ini kontakta din webbvärd.");
define("LAN_head_3", "Din server körs med en 'baskatalog' restriktion aktiverad. Detta förbjuder användandet av filer utanför din hemmakatalog och kan med det påverka vissa skript som t.ex. filhanteraren.");

define("LAN_head_4", "Admin area");

define("LAN_head_5", "språk visat i adminarean: ");
define("LAN_head_6", "Plugin info");

?>
