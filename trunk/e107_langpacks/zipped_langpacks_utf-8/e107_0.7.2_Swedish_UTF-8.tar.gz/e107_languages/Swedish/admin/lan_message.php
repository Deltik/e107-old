<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_message.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Mottagna meddelanden");
define("MESSLAN_2", "Radera meddelande");
define("MESSLAN_3", "Meddelande raderat.");
define("MESSLAN_4", "Radera alla meddelanden");
define("MESSLAN_5", "Bekräfta");
define("MESSLAN_6", "Alla meddelanden raderade.");
define("MESSLAN_7", "Inga meddelanden.");
define("MESSLAN_8", "Meddelande typ");
define("MESSLAN_9", "Rapporterat den");

define("MESSLAN_10", "Skickat av");
define("MESSLAN_11", "öppnas i nytt fönster");
define("MESSLAN_12", "Meddelande");
define("MESSLAN_13", "Länk");

?>
