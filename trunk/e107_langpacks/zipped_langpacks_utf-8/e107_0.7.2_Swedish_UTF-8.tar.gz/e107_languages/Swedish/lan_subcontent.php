<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_subcontent.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "Tack, din artikel har sparats och kommer att granskas av en sajtadministratör snarast.");
define("ARLAN_1", "Fält lämnade tomma.");
define("ARLAN_2", "Tack, din recension har sparats och kommer att granskas av en sajtadministratör snarast..");
define("ARLAN_15", "Skicka in artikel");
define("ARLAN_17", "Rubrik");
define("ARLAN_18", "Underrubrik");
define("ARLAN_19", "Summering");
define("ARLAN_20", "Artikel");
define("ARLAN_21", "Tillåt kommentarer?");
define("ARLAN_22", "På");
define("ARLAN_23", "Av");
define("ARLAN_24", "Lägg till e-post/utskrift ikoner?");
define("ARLAN_25", "Ja");
define("ARLAN_26", "Nej");
define("ARLAN_27", "Skicka in artikel");
define("ARLAN_28", "Förhandsgranska");
define("ARLAN_55", "Synlig för");
define("ARLAN_73", "Öppna HTML-redigerare");
define("ARLAN_74", "Kategori");
define("ARLAN_75", "Ingen");
define("ARLAN_82", "Författardetaljer");
define("ARLAN_84", "författarens namn");
define("ARLAN_85", "författarens e-postadress");
define("ARLAN_86", "Recension");
define("ARLAN_87", "Betyg");
define("ARLAN_88", "Välj betyg");
define("ARLAN_89", "Skicka in recension");

define("ARLAN_90", "Fält lämnade tomma, klicka på din webbläsares bakåt-knapp och se till att alla fält är ifyllda.");
define("ARLAN_91", "Granska igen");
define("ARLAN_92", "Ange ditt namn/e-postadress");


define("ARLAN_93", "artikel");
define("ARLAN_94", "recension");
define("ARLAN_95", "Insändning av artiklar från användare är avstängd just nu");
define("ARLAN_96", "Insändning av recensioner från användare är avstängd just nu");
define("ARLAN_97", "Du har inte tillräckliga behörigheter att skicka in artiklar");
define("ARLAN_98", "Du har inte tillräckliga behörigheter att skicka in recensioner");


define("ARLAN_99", "Vad vill du sända in?");
define("ARLAN_100", "Nyhet");
define("ARLAN_101", " Händelse");
define("ARLAN_102", "Artikel");
define("ARLAN_103", "Recension");
define("ARLAN_104", "Länk");
define("ARLAN_105", "Fil");
define("ARLAN_106", "Skicka in");

?>
