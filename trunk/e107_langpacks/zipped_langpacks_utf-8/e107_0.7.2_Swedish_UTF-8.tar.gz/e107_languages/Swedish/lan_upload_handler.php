<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Filtypen");
define("LANUPLOAD_2", "är inte tillåten och har raderats.");
define("LANUPLOAD_3", "Uppladdningen lyckades");
define("LANUPLOAD_4", "Antingen finns inte mottagande folder, eller så är den inte skrivbar.");
define("LANUPLOAD_5", "Den uppladdade filen överskrider upload_max_filesize direktivet i php.ini.");
define("LANUPLOAD_6", "Den uppladdade filen överskrider MAX_FILE_SIZE direktivet som specficerats i html-formuläret.");
define("LANUPLOAD_7", "Filen blev bara delvis uppladdad.");
define("LANUPLOAD_8", "Ingen fil laddades upp.");
define("LANUPLOAD_9", "Uppladdad filstorlek 0 bytes");
define("LANUPLOAD_10", "Uppladdning misslyckades [Dubblerat filnamn] - En fil med samma namn finns redan.");
define("LANUPLOAD_11", "Filen laddades inte upp. Filnamn: ");
define("LANUPLOAD_12", "Fel");

?>
