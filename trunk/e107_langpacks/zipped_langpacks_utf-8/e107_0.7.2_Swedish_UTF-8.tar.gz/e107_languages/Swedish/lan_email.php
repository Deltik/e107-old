<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_email.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/28 13:47:33 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "E-post");

define("LAN_5", "E-posta artikel till en vän");
define("LAN_6", "E-posta nyhet till en vän");
define("LAN_7", "Login Namn: ");
define("LAN_8", "Kommentar");
define("LAN_9", "Tyvärr - kunde inte skicka e-post");
define("LAN_10", "Brev sänt till");
define("LAN_11", "Brev skickat");
define("LAN_12", "Fel");
define("LAN_106", "Det ser inte ut som en giltig e-postadress");
define("LAN_185", "Skicka artikel");
define("LAN_186", "Skicka nyhet");
define("LAN_187", "E-postadress att skicka till");
define("LAN_188", "Jag tänkte att du kunde vara intresserad av denna nyhet från");
define("LAN_189", "Jag tänkte att du kunde vara intresserad av denna artikel från");

define("LAN_email_1", "Från:");
define("LAN_email_2", "Avsändarens IP-adress:");
define("LAN_email_3", "E-postat ämne från ");
define("LAN_email_4", "Skicka e-post");
define("LAN_email_5", "E-posta ämne till en vän");
define("LAN_email_6", "Jag tänkte att du kunde vara intresserad av detta ämne från");

?>
