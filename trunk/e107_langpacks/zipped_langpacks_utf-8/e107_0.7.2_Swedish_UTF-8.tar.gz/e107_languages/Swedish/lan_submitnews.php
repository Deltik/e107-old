<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_submitnews.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Skicka in nyhet");
define("LAN_7", "Inloggningsnamn: ");
define("LAN_62", "Ämne: ");
define("LAN_112", "E-postadress: ");
define("LAN_133", "Tack");
define("LAN_134", "Din insändare har skickats in och kommer att granskas av en sajtadministratör snarast.");
define("LAN_135", "Nyhet: ");
define("LAN_136", "Skicka in nyhet");
define("NWSLAN_6", "Kategori");
define("NWSLAN_10", "Inga nyhetskategorier");
define("NWSLAN_11", "Du har inte tillgång till denna area.");
define("NWSLAN_12", "Tillgång nekad.");

define("SUBNEWSLAN_1", "Du måste ange en rubrik.\\n");
define("SUBNEWSLAN_2", "Du måste inkludera en text i en nyhet.\\n");
define("SUBNEWSLAN_3", "Din bilaga måste vara antingen en jpg, gif eller png fil");
define("SUBNEWSLAN_4", "Filen för stor");
define("SUBNEWSLAN_5", "Bildfil");
define("SUBNEWSLAN_6", "(jpg, gif eller png)");

?>
