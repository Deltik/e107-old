<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Endast medlemmar");

define("LAN_MEMBERS_0", "begränsad area");
define("LAN_MEMBERS_1", "Detta är en begränsad area");
define("LAN_MEMBERS_2", "För tillgång till den, <a href='login.php'>logga in</a>");
define("LAN_MEMBERS_3", "eller <a href='".e_SIGNUP."'>registrera</a> dig som medlem");
define("LAN_MEMBERS_4", "Klicka här för återgång till förstasidan");

?>