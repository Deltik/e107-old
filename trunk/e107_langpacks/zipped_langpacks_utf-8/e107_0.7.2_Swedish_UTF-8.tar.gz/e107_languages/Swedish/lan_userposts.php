<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_userposts.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Användarinlägg");

define("UP_LAN_0", "Alla foruminlägg från ");
define("UP_LAN_1", "Alla kommentarer från ");
define("UP_LAN_2", "Tråd");
define("UP_LAN_3", "Visningar");
define("UP_LAN_4", "Svar");
define("UP_LAN_5", "Senaste inlägg");
define("UP_LAN_6", "Trådar");
define("UP_LAN_7", "Inga kommentarer");
define("UP_LAN_8", "Inga inlägg");
define("UP_LAN_9", " den ");
define("UP_LAN_10", "Ang");
define("UP_LAN_11", "Postat den");
define("UP_LAN_12", "Sök");
define("UP_LAN_13", "Kommentarer");
define("UP_LAN_14", "Foruminlägg");
define("UP_LAN_15", "Ang");
define("UP_LAN_16", "IP-adress");

?>
