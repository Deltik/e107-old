<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 12:05:43 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "röst");
define("RATELAN_1", "röster");
define("RATELAN_2", "Hur vill du betygssätta detta objekt?");
define("RATELAN_3", "Tack för din röst");
define("RATELAN_4", "Ej betygssatt");
define("RATELAN_5", "Betyg");

?>
