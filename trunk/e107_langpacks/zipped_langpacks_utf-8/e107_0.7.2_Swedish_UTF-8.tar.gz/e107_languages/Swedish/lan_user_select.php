<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_user_select.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("US_LAN_1", "Välj användare");
define("US_LAN_2", "Välj användarklass");
define("US_LAN_3", "Alla användare");
define("US_LAN_4", "Sök användarnamn");
define("US_LAN_5", "Användare hittades");
define("US_LAN_6", "Söks");

?>