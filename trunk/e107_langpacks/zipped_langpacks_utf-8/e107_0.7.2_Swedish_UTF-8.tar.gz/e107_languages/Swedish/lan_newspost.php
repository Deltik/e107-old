<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Nyhet raderad.");
define("NWSLAN_2", "Markera rutan för att bekräfta borttagning av denna nyhet.");
define("NWSLAN_3", "Inga nyheter ännu.");
define("NWSLAN_4", "Befintliga nyheter");
define("NWSLAN_5", "Öppna HTML-redigerare");
define("NWSLAN_6", "Kategori");
define("NWSLAN_7", "Redigera");
define("NWSLAN_8", "Radera");
define("NWSLAN_9", "markera för att bekräfta");
define("NWSLAN_10", "Inga kategorier satta ännu.");
define("NWSLAN_11", "Lägg till/Redigera kategorier");
define("NWSLAN_12", "Rubrik");
define("NWSLAN_13", "Text");
define("NWSLAN_14", "Utökad");
define("NWSLAN_15", "Kommentarer");
define("NWSLAN_16", "Aktiv");
define("NWSLAN_17", "Inaktiv");
define("NWSLAN_18", "Tillåt kommentarer att postas till denna nyhet");
define("NWSLAN_19", "Aktivering");
define("NWSLAN_20", "Lämna tomt för att inte använda auto-aktivering");
define("NWSLAN_21", "Aktiv mellan");
define("NWSLAN_22", "Synbarhet");
define("NWSLAN_23", "Markering gör nyheten synlig enbart för användare i den klassen");
define("NWSLAN_24", "Förhandsgranska igen");
define("NWSLAN_25", "Uppdatera nyhet i databasen");
define("NWSLAN_26", "Posta nyhet till databasen");
define("NWSLAN_27", "Förhandsgranska");
define("NWSLAN_28", "Ny nyhet");
define("NWSLAN_29", "Nyhetspost");

define("NWSLAN_30", "Visa enbart rubrik");

?>
