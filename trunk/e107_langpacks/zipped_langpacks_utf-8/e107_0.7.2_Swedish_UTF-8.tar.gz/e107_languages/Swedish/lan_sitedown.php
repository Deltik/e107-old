<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_sitedown.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sajten tillfälligt stängd");
define("LAN_00", "är tillfälligt stängd");
define("LAN_01", "Vi har tillfälligt stängt sajten för nödvändigt underhåll. Det bör inte ta så lång tid, kika tillbaka lite senare. Vi ber om ursäkt för ditt besvär.");

?>
