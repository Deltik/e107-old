<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
	
define("ONLINE_EL1", "Гостей: ");
define("ONLINE_EL2", "Пользователей: ");
define("ONLINE_EL3", "На этой странице: ");
define("ONLINE_EL4", "В сети");
define("ONLINE_EL5", "Пользователей");
define("ONLINE_EL6", "Новичок");
define("ONLINE_EL7", "смотрит");

define("ONLINE_EL8", "рекорд он-лайн: ");
define("ONLINE_EL9", "в");

define("ONLINE_TRACKING_MESSAGE", "Отслеживание пользователей он-лайн в настоящий момент отключено, пожалуйста, включите его [link=".e_ADMIN."users.php?options]здесь[/link][br]");
?>
