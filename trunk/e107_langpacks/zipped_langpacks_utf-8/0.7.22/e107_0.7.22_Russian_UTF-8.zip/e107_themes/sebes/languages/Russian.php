<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 237 $
|     $Date: 2009-09-20 16:18:50 +0600 (Вс, 20 сен 2009) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define('LAN_THEME_1', "'sebes' от <a href='http://e107.org' rel='external'>jalist</a>");
define('LAN_THEME_2', 'Читать/Добавить комментарии: ');
define('LAN_THEME_3', 'Комментарии выключены');
define('LAN_THEME_4', 'Читать далее ...');
define('LAN_THEME_5', 'Трекбеки: ');
define('LAN_THEME_6', ' | ');

?>
