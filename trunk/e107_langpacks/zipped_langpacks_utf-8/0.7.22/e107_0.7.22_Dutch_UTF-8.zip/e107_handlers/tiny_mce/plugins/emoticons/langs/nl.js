// $Id$
tinyMCE.addI18n('nl.emoticons',{
	desc : 'Emoticon invoegen'
});
