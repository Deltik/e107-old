<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('PAGE_NAME', 'Gebruiker berichten');

define('UP_LAN_0',  'Alle forumberichten van ');
define('UP_LAN_1',  'Alle reacties van ');
define('UP_LAN_2',  'Discussie');
define('UP_LAN_3',  'Bekeken');
define('UP_LAN_4',  'reacties');
define('UP_LAN_5',  'Laatste');
define('UP_LAN_6',  'Discussies');
define('UP_LAN_7',  'Geen reacties');
define('UP_LAN_8',  'Geen berichten');
define('UP_LAN_9',  'op ');
define('UP_LAN_10', 'Betr.');
define('UP_LAN_11', 'Geplaatst op: ');
define('UP_LAN_12', 'Zoeken');
define('UP_LAN_13', 'Reacties');
define('UP_LAN_14', 'Forumberichten');
define('UP_LAN_15', 'Betr.');
define('UP_LAN_16', 'IP adres');

?>