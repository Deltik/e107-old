<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('US_LAN_1', 'Selecteer gebruiker');
define('US_LAN_2', 'Selecteer gebruikersklasse');
define('US_LAN_3', 'Alle gebruikers');
define('US_LAN_4', 'Zoek gebruikersnaam');
define('US_LAN_5', 'Gebruiker(s) gevonden');
define('US_LAN_6', 'Zoek');

?>