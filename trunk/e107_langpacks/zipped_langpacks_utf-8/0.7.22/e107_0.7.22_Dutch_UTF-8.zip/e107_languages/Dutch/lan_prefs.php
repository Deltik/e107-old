<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_PREF_1', 'e107 powered website');
define('LAN_PREF_2', 'e107 website systeem');
define('LAN_PREF_3', 'Alle merknamen zijn auteursrechtelijk beschermd door hun respectievelijke eigenaars, alle andere content is eigendom van deze e107 powered website.<br />e107 is © e107.org en is gepubliceerd onder de <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU GPL licentie</a>.');
define('LAN_PREF_4', 'gecensureerd');
define('LAN_PREF_5', 'Forums');

?>