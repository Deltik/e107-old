<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LANMAILH_1', 'Gecreëerd door het e107 website systeem');
define('LANMAILH_2', 'Dit is een multi-part bericht in MIME formaat.');
define('LANMAILH_3', ' is niet juist geformatteerd');
define('LANMAILH_4', 'Door server geweigerd adres');
define('LANMAILH_5', 'Geen reactie van server');
define('LANMAILH_6', 'Kan e-mail server niet vinden.');
define('LANMAILH_7', ' lijkt geldig.');

?>