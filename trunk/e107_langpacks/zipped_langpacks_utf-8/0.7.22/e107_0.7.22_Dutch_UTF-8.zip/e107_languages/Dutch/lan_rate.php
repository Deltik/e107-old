<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('RATELAN_0', 'Stem');
define('RATELAN_1', 'Stemmen');
define('RATELAN_2', 'Hoe beoordeel je dit onderwerp?');
define('RATELAN_3', 'Bedankt voor je stem');
define('RATELAN_4', 'Niet beoordeeld');
define('RATELAN_5', 'Waardering');

?>