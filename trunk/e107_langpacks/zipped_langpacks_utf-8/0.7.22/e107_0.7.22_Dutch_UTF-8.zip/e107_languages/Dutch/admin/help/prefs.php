<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

if (!defined('e107_INIT')) { exit(); }

$text = "De Voorkeuren functie laat je alle belangrijke instellingen van je site vastleggen. Dat varieert van bijvoorbeeld van de naam van je site tot de beveiligingsfuncties en het ongewenste woorden filter.";
$ns -> tablerender("Voorkeurenhulp", $text);

?>