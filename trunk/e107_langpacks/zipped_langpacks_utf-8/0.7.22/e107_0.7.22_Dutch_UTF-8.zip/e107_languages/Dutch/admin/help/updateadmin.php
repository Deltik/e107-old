<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

if (!defined('e107_INIT')) { exit(); }

$text = "Wijzig hier je naam, e-mailadres en wachtwoord.";
$ns -> tablerender("Bijwerken instellingen Hulp", $text);

?>