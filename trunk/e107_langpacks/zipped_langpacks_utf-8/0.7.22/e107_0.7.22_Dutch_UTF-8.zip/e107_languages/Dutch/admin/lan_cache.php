<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('CACLAN_1',  'Activeer cache systeem');
define('CACLAN_2',  'Instellen cache');
define('CACLAN_3',  'Cache Systeem');
define('CACLAN_4',  'Cache functie ingesteld');
define('CACLAN_5',  'Cache leegmaken');
define('CACLAN_6',  'Cache leeg gemaakt');

define('CACLAN_7',  'Cache gedeactiveerd');
// define('CACLAN_8',  'Cache data saved to MySQL');
define('CACLAN_9',  'Cache gegevens bewaard in bestand');
define('CACLAN_10', 'De cache map is niet beschrijfbaar, zorg ervoor dat de map de juiste schrijfrechten heeft (CHMOD is systeem afhankelijk, hou het zo laag mogelijk.) Voor meer informatie en de mogelijkheden wat betreft CHMOD verwijzen wij je naar je hostings provider.'); //@FIXIT,IS THIS CORRECT

?>