<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

if (!defined('e107_INIT')) { exit(); }

$text = "Kruis het vakje aan om text emoticons te vervangen door plaatjes.<br /><br />
Voer de wijzigingen in en klik op Bijwerken om de instellingen te bewaren. Gebruik het invoerformulier onderaan dit scherm om nieuwe emoticons toe te voegen.";

$ns -> tablerender("Emoticon Hulp", $text);

?>