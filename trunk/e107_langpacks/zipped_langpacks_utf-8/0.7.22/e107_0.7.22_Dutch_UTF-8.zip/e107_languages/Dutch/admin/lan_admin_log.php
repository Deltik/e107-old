<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_ADMINLOG_0',  'Beheerlog');
define('LAN_ADMINLOG_1',  'Datum');
define('LAN_ADMINLOG_2',  'Titel');
define('LAN_ADMINLOG_3',  'Omschrijving');
define('LAN_ADMINLOG_4',  'Gebruikers IP');
define('LAN_ADMINLOG_5',  'Gebruikers ID');
define('LAN_ADMINLOG_6',  'Informatie icon');
define('LAN_ADMINLOG_7',  'Informatie melding');
define('LAN_ADMINLOG_8',  'Meldings icon');
define('LAN_ADMINLOG_9',  'Meldings Bericht');
define('LAN_ADMINLOG_10', 'Waarschuwings icon');
define('LAN_ADMINLOG_11', 'Waarschuwings melding');
define('LAN_ADMINLOG_12', 'Fatale fout icon');
define('LAN_ADMINLOG_13', 'Fatale fout boodschap');

?>