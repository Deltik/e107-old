<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

if (!defined('e107_INIT')) { exit(); }

$text = "Gebruik deze pagina om de algemene e-mailinstellingen voor je site regelen. Je kunt met het formulier ook direct een mailing naar al je leden te verzorgen.";
$ns -> tablerender("Mail help", $text);

?>