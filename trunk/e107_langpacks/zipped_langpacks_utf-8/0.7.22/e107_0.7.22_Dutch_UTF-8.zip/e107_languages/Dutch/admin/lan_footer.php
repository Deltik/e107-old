<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('FOOTLAN_1',  'Site');
define('FOOTLAN_2',  'Hoofdbeheerder');
define('FOOTLAN_3',  'Versie');
define('FOOTLAN_4',  'build');
define('FOOTLAN_5',  'Beheer thema');
define('FOOTLAN_6',  'door');
define('FOOTLAN_7',  'Info');
define('FOOTLAN_8',  'Installatiedatum');
define('FOOTLAN_9',  'Server');
define('FOOTLAN_10', 'systeem');
define('FOOTLAN_11', 'PHP Versie');
define('FOOTLAN_12', 'MySQL');
define('FOOTLAN_13', 'Site info');
define('FOOTLAN_14', 'Toon docs');
define('FOOTLAN_15', 'Documentatie');
define('FOOTLAN_16', 'Database');
define('FOOTLAN_17', 'Charset');
define('FOOTLAN_18', 'Site thema');

?>