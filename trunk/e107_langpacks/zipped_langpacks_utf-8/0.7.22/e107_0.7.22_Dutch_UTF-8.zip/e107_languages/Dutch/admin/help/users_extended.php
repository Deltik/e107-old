<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

if (!defined('e107_INIT')) { exit(); }

$text = " Uitgebreide gebruikervelden maken het mogelijk om aanvullende soorten gegevens op te geven die de leden in hun gebruikersprofielen kunnen vastleggen.";
$ns -> tablerender(" Uitgebreide gebruikersvelden hulp", $text);

?>