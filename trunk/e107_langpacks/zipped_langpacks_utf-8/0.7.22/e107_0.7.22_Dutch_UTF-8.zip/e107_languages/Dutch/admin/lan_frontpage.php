<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('FRTLAN_1',  'Instellingen Hoofdpagina gewijzigd.');
define('FRTLAN_2',  'Toon');
define('FRTLAN_6',  'Links');
// define('FRTLAN_7', 'Content Page');
define('FRTLAN_12', 'Wijzig instellingen hoofdpagina');
define('FRTLAN_13', 'Instellingen Hoofdpagina');
define('FRTLAN_15', 'Overig (invoeren url):');
define('FRTLAN_16', 'fout: geen content hoofdpagina geselecteerd');
define('FRTLAN_17', 'fout: geen content subcategorie geselecteerd');
define('FRTLAN_18', 'fout: geen content onderwerp item geselecteerd');
define('FRTLAN_19', 'content hoofdpagina');
define('FRTLAN_20', 'content categorie');
define('FRTLAN_21', 'content onderwerp');
// define('FRTLAN_22', '');
// define('FRTLAN_23', '');
// define('FRTLAN_24', '');
// define('FRTLAN_25', '');

define('FRTLAN_26', 'alle gebruikers');
define('FRTLAN_27', 'Gasten');
define('FRTLAN_28', 'Leden');
define('FRTLAN_29', 'Beheerders');
define('FRTLAN_31', 'Alle gebruikers');
define('FRTLAN_32', 'Gebruikersklasse');
define('FRTLAN_33', 'Huidige instellingen');
define('FRTLAN_34', 'Pagina');

?>