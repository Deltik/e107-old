<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('UCSLAN_1',  'Alle leden verwijderd uit de klasse.');
define('UCSLAN_2',  'Leden in de klasse bijgewerkt.');
define('UCSLAN_3',  'Klasse verwijderd.');
define('UCSLAN_4',  'aankruisen om het verwijderen van de gebruikersklasse te bevestigen');
define('UCSLAN_5',  'Klasse bijgewerkt.');
define('UCSLAN_6',  'Klasse opgeslagen in de database.');
define('UCSLAN_7',  'Nog geen gebruikersklasse.');
define('UCSLAN_8',  'Aanwezige klassen');

// define('UCSLAN_9',  'Edit');
// define('UCSLAN_10', 'Delete');
define('UCSLAN_11', 'aankruisen om te bevestigen');
define('UCSLAN_12', 'Naam klasse');
define('UCSLAN_13', 'Beschrijving klasse');
define('UCSLAN_14', 'Bijwerken gebruikersklasse');
define('UCSLAN_15', 'Opvoeren nieuwe gebruikersklasse');
define('UCSLAN_16', 'Wijs leden toe aan de gebruikersklasse');
define('UCSLAN_17', 'Verwijderen');
define('UCSLAN_18', 'Klasse opschonen');
define('UCSLAN_19', 'Wijs leden toe aan');
define('UCSLAN_20', 'klasse');
define('UCSLAN_21', 'Gebruikersklasse instellingen');

define('UCSLAN_22', 'Leden - klik om te verplaatsen ...');
define('UCSLAN_23', 'Leden in deze klasse ...');

define('UCSLAN_24', 'Wie kan de gebruikersklasse beheren');

?>