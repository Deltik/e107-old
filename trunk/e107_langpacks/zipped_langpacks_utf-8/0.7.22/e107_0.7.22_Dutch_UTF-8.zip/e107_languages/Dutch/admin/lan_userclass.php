<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('UCSLAN_1',  'Stuur e-mail melding aan');
define('UCSLAN_2',  'Autorisaties bijgewerkt');
define('UCSLAN_3',  'Beste');
define('UCSLAN_4',  'je autorisaties zijn bijgewerkt op');
define('UCSLAN_5',  'Je hebt nu toegang tot de volgende functie(s)');
define('UCSLAN_6',  'Instellen klasse voor lid');
define('UCSLAN_7',  'Instellen klassen');
define('UCSLAN_8',  'Melden aan lid');
define('UCSLAN_9',  'Gebruikersklasse bijgewerkt');
define('UCSLAN_10', 'Groeten,');
define('UCSLAN_12', 'Alleen leden autorisaties');

?>