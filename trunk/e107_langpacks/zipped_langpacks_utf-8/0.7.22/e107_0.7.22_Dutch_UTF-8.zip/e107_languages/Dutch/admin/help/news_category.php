<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

if (!defined('e107_INIT')) { exit(); }

$text = "Je kunt nieuwsberichten in verschillende categorieën onderverdelen en kunt bezoekers berichten per categorie laten zien. <br /><br />Upload je nieuwspictogrammen naar ofwel ".e_THEME."-jouwthema-/images/ of themes/shared/newsicons/.";
$ns -> tablerender("Nieuws categorie Hulp", $text);

?>