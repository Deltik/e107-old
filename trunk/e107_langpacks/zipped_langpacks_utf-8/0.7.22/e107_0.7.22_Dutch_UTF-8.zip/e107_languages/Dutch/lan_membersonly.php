<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('PAGE_NAME', 'Alleen voor leden'); 

define('LAN_MEMBERS_0', 'afgeschermd gedeelte');
define('LAN_MEMBERS_1', 'Dit is een');
define('LAN_MEMBERS_2', 'Om toegang te krijgen <a href="'.e_LOGIN.'">log hier in</a>');
define('LAN_MEMBERS_3', 'of <a href="'.e_SIGNUP.'">meld je aan</a> als lid');
define('LAN_MEMBERS_4', 'Klik hier om naar de startpagina terug te keren');

?>