<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('PAGE_NAME',       'Site is tijdelijk gesloten');

define('LAN_SITEDOWN_00', 'is tijdelijk gesloten');
define('LAN_SITEDOWN_01', 'We hebben deze site tijdelijk gesloten om het nodige onderhoud uit te kunnen voeren.<br /><br />Dit zal niet lang duren, dus kom binnenkort terug.<br /><br />Onze excuses voor het ongemak!');

?>