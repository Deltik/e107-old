<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('UC_LAN_0', 'Iedereen (openbaar)');
define('UC_LAN_1', 'Alleen voor gasten');
define('UC_LAN_2', 'Niemand (inactief)');
define('UC_LAN_3', 'Alleen voor leden');
define('UC_LAN_4', 'Alleen voor lezen');
define('UC_LAN_5', 'Alleen voor beheer');
define('UC_LAN_6', 'Hoofdbeheerder');

?>