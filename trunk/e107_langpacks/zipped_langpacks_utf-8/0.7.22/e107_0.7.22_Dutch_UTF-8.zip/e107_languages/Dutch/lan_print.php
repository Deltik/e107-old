<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

if (!defined('PAGE_NAME')) {define('PAGE_NAME', 'Printervriendelijk');}

define('LAN_PRINT_86',  'Categorie:');
define('LAN_PRINT_87',  'door ');
define('LAN_PRINT_94',  'Geplaatst door');
define('LAN_PRINT_135', 'Nieuwsbericht: ');
define('LAN_PRINT_303', 'Dit nieuwsbericht is van ');
define('LAN_PRINT_304', 'Titel: ');
define('LAN_PRINT_305', 'Onderkop: ');
define('LAN_PRINT_306', 'Dit artikel is van:');
define('LAN_PRINT_307', 'Druk deze pagina af');
define('LAN_PRINT_1',   'printervriendelijk');

?>