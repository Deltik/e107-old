<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_UMENU_THEME_1', 'Instellen theme');
define('LAN_UMENU_THEME_2', 'Selecteer theme');
define('LAN_UMENU_THEME_3', 'Gebruikers');
define('LAN_UMENU_THEME_4', 'Selecteer de themes waar gebruikers uit kunnen kiezen');
define('LAN_UMENU_THEME_5', 'Bijwerken');
define('LAN_UMENU_THEME_6', 'Beschikbare themes voor gebruikers');
define('LAN_UMENU_THEME_7', 'De gebruikersklasse welke themes kunnen selecteren.');

?>