<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('TREE_L1', 'Configureren Tree Menu');
define('TREE_L2', 'Bijwerken Tree Menu instellingen');
define('TREE_L3', 'Tree Menu configuratie opgeslagen.');
define('TREE_L4', 'Aan');
define('TREE_L5', 'Uit');
define('TREE_L6', 'CSS klasse te gebruiken voor niet te openen links');
define('TREE_L7', 'CSS klasse te gebruiken voor te openen links');
define('TREE_L8', 'CSS klasse te gebruiken voor geopende links');
define('TREE_L9', 'Gebruik spatiëringsklasse tussen hoofdlinks');

?>