<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('CLOCK_MENU_L1',  'Klok menu configuratie opgeslagen');
define('CLOCK_MENU_L2',  'Titelbalk');
define('CLOCK_MENU_L3',  'Bijwerken Menu Instellingen');
define('CLOCK_MENU_L4',  'Klok Menu Config');
define('CLOCK_MENU_L5',  'Maandag,');
define('CLOCK_MENU_L6',  'Dinsdag,');
define('CLOCK_MENU_L7',  'Woensdag,');
define('CLOCK_MENU_L8',  'Donderdag,');
define('CLOCK_MENU_L9',  'Vrijdag,');
define('CLOCK_MENU_L10', 'Zaterdag,');
define('CLOCK_MENU_L11', 'Zondag,');
define('CLOCK_MENU_L12', 'Januari');
define('CLOCK_MENU_L13', 'Februari');
define('CLOCK_MENU_L14', 'Maart');
define('CLOCK_MENU_L15', 'April');
define('CLOCK_MENU_L16', 'Mei');
define('CLOCK_MENU_L17', 'Juni');
define('CLOCK_MENU_L18', 'Juli');
define('CLOCK_MENU_L19', 'Augustus');
define('CLOCK_MENU_L20', 'September');
define('CLOCK_MENU_L21', 'Oktober');
define('CLOCK_MENU_L22', 'November');
define('CLOCK_MENU_L23', 'December');
define('CLOCK_MENU_L24', '');

?>