<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('CONT_SCH_LAN_1', 'Content');
define('CONT_SCH_LAN_2', 'Alle contentcategorieën');
define('CONT_SCH_LAN_3', 'Geplaatst als reactie op onderwerp');
define('CONT_SCH_LAN_4', 'in');

?>