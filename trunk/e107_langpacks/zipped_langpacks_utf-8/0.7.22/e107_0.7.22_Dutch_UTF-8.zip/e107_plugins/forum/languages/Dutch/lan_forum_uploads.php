<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('PAGE_NAME', 'Forum Uploads');

define('FRMUP_1',   'Geuploade bestanden in forum');
define('FRMUP_2',   'Bestand verwijderd');
define('FRMUP_3',   'Fout: bestand niet te verwijderen');
define('FRMUP_4',   'Bestandsverwijdering');
define('FRMUP_5',   'Bestandsnaam');
define('FRMUP_6',   'Resultaat');
define('FRMUP_7',   'Gevonden in discussie');
define('FRMUP_8',   'NIET GEVONDEN');
define('FRMUP_9',   'Geen geuploade bestanden gevonden');
define('FRMUP_10',  'Verwijderen');
	
?>