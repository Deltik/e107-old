<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('FOR_SCH_LAN_1', 'Forum');
define('FOR_SCH_LAN_2', 'Selecteer forum');
define('FOR_SCH_LAN_3', 'Alle forums');
define('FOR_SCH_LAN_4', 'Hele bericht');
define('FOR_SCH_LAN_5', 'Als deel van discussie');

?>