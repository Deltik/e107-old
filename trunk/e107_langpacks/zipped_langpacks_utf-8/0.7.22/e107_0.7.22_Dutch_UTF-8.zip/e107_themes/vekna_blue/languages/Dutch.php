<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_THEME_1', '“vekna blue” door <a href="http://e107.org" rel="external">jalist</a>, gebaseerd op en met toestemming van Arach’s site, <a href="http://e107.vekna.com" rel="external">http://e107.vekna.com</a>');
define('LAN_THEME_2', 'Lees/plaats reactie: ');
define('LAN_THEME_3', 'Reacties bij dit onderwerp niet mogelijk');
define('LAN_THEME_4', 'Lees verder ...');
define('LAN_THEME_5', 'Trackbacks: ');

?>