<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_THEME_1', 'Reageren bij dit onderwerp niet mogelijk');
define('LAN_THEME_2', 'Lees/plaats reactie: ');
define('LAN_THEME_3', 'Lees verder ...');
define('LAN_THEME_4', 'Trackbacks: ');
define('LAN_THEME_5', 'Geplaatst door');
define('LAN_THEME_6', 'op');
define('LAN_THEME_7', 'Zoeken ...');

?>