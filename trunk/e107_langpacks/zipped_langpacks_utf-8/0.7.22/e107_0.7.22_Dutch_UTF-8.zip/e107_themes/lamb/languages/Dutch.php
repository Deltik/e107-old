<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_THEME_1', '“lamb” door <a href="http://e107.org" rel="external">jalist</a>');
define('LAN_THEME_2', 'Reacties bij dit onderwerp niet mogelijk');
define('LAN_THEME_3', 'reactie: ');
define('LAN_THEME_4', 'Lees verder ...');
define('LAN_THEME_5', 'Trackbacks: ');
define('LAN_THEME_6', 'op');

?>