<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_THEME_1', 'Reacties');
define('LAN_THEME_2', 'Reageren uit');
define('LAN_THEME_3', 'Volledig bericht');
define('LAN_THEME_4', 'Geplaatst op');

?>