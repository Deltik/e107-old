<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL$
 * $Revision$
 * $Date$
 * $Author$
 */

define('LAN_THEME_1', 'Reactie(s) ');
define('LAN_THEME_2', 'Reageren op dit onderwerp niet mogelijk');
define('LAN_THEME_3', 'reactie(s) ');
define('LAN_THEME_4', 'Lees verder ...');
define('LAN_THEME_5', 'Trackbacks: ');
define('LAN_THEME_6', 'Reactie door');
define('LAN_THEME_7', 'Nieuws');

?>