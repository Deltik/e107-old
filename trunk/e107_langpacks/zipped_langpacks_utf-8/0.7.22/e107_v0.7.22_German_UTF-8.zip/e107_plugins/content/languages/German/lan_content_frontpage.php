<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/content/languages/German/lan_content_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:05 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("CONT_FP_1", "Inhalt Kategorie");
define("CONT_FP_2", "Hauptseite");

?>
