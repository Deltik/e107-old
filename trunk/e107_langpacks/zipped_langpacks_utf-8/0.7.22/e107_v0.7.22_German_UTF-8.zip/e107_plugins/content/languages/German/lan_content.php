<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/content/languages/German/lan_content.php,v $
|     $Revision: 1.2 $
|     $Date: 2010/01/30 13:47:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
|     $ UTF-8 encoded $
|     $updated by: webmaster@e107cms.de (http://www.e107cms.de) $
+----------------------------------------------------------------------------+
*/


define("CONTENT_EMAILPRINT_LAN_1", "Dieser Inhaltseintrag ist von");
define("POPUP_LAN_1", "bitte hier klicken um das Bild zu vergrössern");

define("CONTENT_NOTIFY_LAN_1", "Inhalt Ereignisse");
define("CONTENT_NOTIFY_LAN_2", "Inhaltseintrag übermittlet durch Benutzer");
define("CONTENT_NOTIFY_LAN_3", "Inhalt übermittelt");

define("CONTENT_TYPE_LAN_0", "Kategorien");
define("CONTENT_TYPE_LAN_1", "Autoren");
define("CONTENT_TYPE_LAN_2", "Archive");
define("CONTENT_TYPE_LAN_3", "Best bewertet");
define("CONTENT_TYPE_LAN_4", "Top Score");
define("CONTENT_TYPE_LAN_5", "Letzte");

define("CONTENT_ICON_LAN_0", "Bearbeiten");
define("CONTENT_ICON_LAN_1", "Löschen");
define("CONTENT_ICON_LAN_2", "Optionen");
define("CONTENT_ICON_LAN_3", "Benutzer Details");
define("CONTENT_ICON_LAN_4", "Download Anhang");
define("CONTENT_ICON_LAN_5", "Neu");
define("CONTENT_ICON_LAN_6", "Inhalt übermitteln");
define("CONTENT_ICON_LAN_7", "Autor Liste");
define("CONTENT_ICON_LAN_8", "Warnung");
define("CONTENT_ICON_LAN_9", "Ok");
define("CONTENT_ICON_LAN_10", "Fehler");
define("CONTENT_ICON_LAN_11", "Einträge nach Kategorien ordnen");
define("CONTENT_ICON_LAN_12", "Einträge nach Hauptkategorien ordnen");
define("CONTENT_ICON_LAN_13", "Persönlicher Admin");
define("CONTENT_ICON_LAN_14", "Persönlicher Inhaltsmanager");
define("CONTENT_ICON_LAN_15", "Ansehen");


define("CONTENT_ADMIN_DATE_LAN_0", "Januar");
define("CONTENT_ADMIN_DATE_LAN_1", "Februar");
define("CONTENT_ADMIN_DATE_LAN_2", "März");
define("CONTENT_ADMIN_DATE_LAN_3", "April");
define("CONTENT_ADMIN_DATE_LAN_4", "Mai");
define("CONTENT_ADMIN_DATE_LAN_5", "Juni");
define("CONTENT_ADMIN_DATE_LAN_6", "Juli");
define("CONTENT_ADMIN_DATE_LAN_7", "August");
define("CONTENT_ADMIN_DATE_LAN_8", "September");
define("CONTENT_ADMIN_DATE_LAN_9", "Oktober");
define("CONTENT_ADMIN_DATE_LAN_10", "November");
define("CONTENT_ADMIN_DATE_LAN_11", "Dezember");
define("CONTENT_ADMIN_DATE_LAN_12", "Tag");
define("CONTENT_ADMIN_DATE_LAN_13", "Monat");
define("CONTENT_ADMIN_DATE_LAN_14", "Jahr");
define("CONTENT_ADMIN_DATE_LAN_15", "Setzen Sie ein eigenes Startdatum");
define("CONTENT_ADMIN_DATE_LAN_16", "Setzen Sie ein Enddatum");
define("CONTENT_ADMIN_DATE_LAN_17", "Sie können für diesen Eintrag ein Startdatum festsetzen. Bitte frei lassen für jetziges Datum");
define("CONTENT_ADMIN_DATE_LAN_18", "Sie können für diesen Eintrag ein Enddatum festsetzen. Bitte frei lassen für endlos");

define("CONTENT_PAGETITLE_LAN_0", "Inhalt");
define("CONTENT_PAGETITLE_LAN_1", "Haupt");
define("CONTENT_PAGETITLE_LAN_2", "Letzte");
define("CONTENT_PAGETITLE_LAN_3", "Kategorie");
define("CONTENT_PAGETITLE_LAN_4", "Meist bewertet");
define("CONTENT_PAGETITLE_LAN_5", "Autor");
define("CONTENT_PAGETITLE_LAN_6", "Archiv");
define("CONTENT_PAGETITLE_LAN_7", "Übermitteln");
define("CONTENT_PAGETITLE_LAN_8", "Inhaltseintrag übermitteln");
define("CONTENT_PAGETITLE_LAN_9", "Persönlicher Inhaltmanager");
define("CONTENT_PAGETITLE_LAN_10", "Eintrage ansehen");
define("CONTENT_PAGETITLE_LAN_11", "Einträge bearbeiten");
define("CONTENT_PAGETITLE_LAN_12", "Eintrag erstellen");
define("CONTENT_PAGETITLE_LAN_13", "Kategorien");
define("CONTENT_PAGETITLE_LAN_14", "Autorliste");
define("CONTENT_PAGETITLE_LAN_15", "Top Score");

define("CONTENT_SEARCH_LAN_0", "Keine Inhaltseinträge für diese Schlüsselwörter gefunden.");


define("CONTENT_ORDER_LAN_0", "Sortiert nach ...");
define("CONTENT_ORDER_LAN_1", "Überschrift (Absteigend)");
define("CONTENT_ORDER_LAN_2", "Überschrift (Aufsteigend)");
define("CONTENT_ORDER_LAN_3", "Datum (Absteigend)");
define("CONTENT_ORDER_LAN_4", "Datum (Aufsteigend)");
define("CONTENT_ORDER_LAN_5", "Refer (Absteigend)");
define("CONTENT_ORDER_LAN_6", "refer (Aufsteigend)");
define("CONTENT_ORDER_LAN_7", "Hauptkategorie (Absteigend)");
define("CONTENT_ORDER_LAN_8", "Hauptkategorie (Aufsteigend)");
define("CONTENT_ORDER_LAN_9", "Ordnung (Absteigend)");
define("CONTENT_ORDER_LAN_10", "Ordnung (Aufsteigend)");
define("CONTENT_ORDER_LAN_11", "Autor (Absteigend)");
define("CONTENT_ORDER_LAN_12", "Autor (Aufsteigend)");

define("CONTENT_LAN_0", "Inhalt");
define("CONTENT_LAN_1", "Letzte Einträge Liste");
define("CONTENT_LAN_2", "Kategorien Liste");
define("CONTENT_LAN_3", "Kategorie");
define("CONTENT_LAN_4", "Autor Liste");
define("CONTENT_LAN_5", "Autor");
define("CONTENT_LAN_6", "Alle Kategorien");
define("CONTENT_LAN_7", "Alle Autoren");
define("CONTENT_LAN_8", "Best bewertete Einträge");
define("CONTENT_LAN_9", "in");

define("CONTENT_LAN_10", "am");
define("CONTENT_LAN_11", "von");
define("CONTENT_LAN_12", "Top score Einräge");
define("CONTENT_LAN_13", "Auflisten");
define("CONTENT_LAN_14", "-- Kategorien --");
define("CONTENT_LAN_15", "keine Autoren bis jetzt");
define("CONTENT_LAN_16", "[weiterlesen]");
define("CONTENT_LAN_17", "");
define("CONTENT_LAN_18", "Suche nach Schlüsselwörtern");
define("CONTENT_LAN_19", "Suche");

define("CONTENT_LAN_20", "Einhaltssuche Ergebnisse");
define("CONTENT_LAN_21", "Keine Inhaltstypen bis jetzt.");
define("CONTENT_LAN_22", "Inhaltstypen");
define("CONTENT_LAN_23", "Inhaltsliste letzte Einträge");
define("CONTENT_LAN_24", "breadcrumb");
define("CONTENT_LAN_25", "Inhaltskategorien");
define("CONTENT_LAN_26", "Hauptkategorie");
define("CONTENT_LAN_27", "Unterkategorie");
define("CONTENT_LAN_28", "Haupt-Unterkategorie");
define("CONTENT_LAN_29", "unbekannt");
define("CONTENT_LAN_30", "Inhaltseintrag");
define("CONTENT_LAN_31", "Inhaltseinträge");
define("CONTENT_LAN_32", "Inhaltsliste Autoren");
define("CONTENT_LAN_33", "Gehe zur Seite");
define("CONTENT_LAN_34", "Inhalt");
define("CONTENT_LAN_35", "Kommentare");
define("CONTENT_LAN_36", "Kommentare moderieren");
define("CONTENT_LAN_37", "Keine Inhalteinträge bewertet bis jetzt");
define("CONTENT_LAN_38", "Bestbewertete Inhalteinträge");
define("CONTENT_LAN_39", "Autor Liste");

define("CONTENT_LAN_40", "Autor Benutzer Details");
define("CONTENT_LAN_41", "Download angehängt");
define("CONTENT_LAN_42", "Datei");
define("CONTENT_LAN_43", "Dateien");
define("CONTENT_LAN_44", "Hits:");
define("CONTENT_LAN_45", "Autor bezogener Score:");
define("CONTENT_LAN_46", "Artikel Index");
define("CONTENT_LAN_47", "Autor");
define("CONTENT_LAN_48", "Inhalt Einträge");
define("CONTENT_LAN_49", "Letzter Inhaltseintrag");

define("CONTENT_LAN_50", "Datum");
define("CONTENT_LAN_51", "Typen Liste");
define("CONTENT_LAN_52", "keine gültigen Autoren gefunden");
define("CONTENT_LAN_53", "Eintrag");
define("CONTENT_LAN_54", "Einträge");
define("CONTENT_LAN_55", "Letzter Eintrag von");
define("CONTENT_LAN_56", "Zeige Übersicht");
define("CONTENT_LAN_57", "Kommentare:");
define("CONTENT_LAN_58", "Home");
define("CONTENT_LAN_59", "Inhalt");
define("CONTENT_LAN_60", "Letzte");
define("CONTENT_LAN_61", "Zeige letzte Einträge");
define("CONTENT_LAN_62", "Zeige alle Kategorien");
define("CONTENT_LAN_63", "Zeige alle Autoren");
define("CONTENT_LAN_64", "Zeige bestbewertete Einträge");
define("CONTENT_LAN_65", "Inhalt übermitteln");
define("CONTENT_LAN_66", "Klicke hier um Inhalt zu übermitteln, Sie können die Kategorie auf der Übermittlungsseite wählen.");
define("CONTENT_LAN_67", "Persönlicher Inhaltsmanager");
define("CONTENT_LAN_68", "Klicken Sie hier um Ihren persönlichen Inhalt zu managen.");
define("CONTENT_LAN_69", "Email an");
define("CONTENT_LAN_70", "Drucke das");
define("CONTENT_LAN_71", "Inhaltseintrag");
define("CONTENT_LAN_72", "Kategorieeintrag");
define("CONTENT_LAN_73", "Keine Inhaltseinträge bis jetzt");
define("CONTENT_LAN_74", "");
define("CONTENT_LAN_75", "Inhaltseintrag übermitteln");
define("CONTENT_LAN_76", "pdf-Datei erstellen");
define("CONTENT_LAN_77", "Inhalts Suche");
define("CONTENT_LAN_78", "Seite ohne Überschrift");
define("CONTENT_LAN_79", "Seite");
define("CONTENT_LAN_80", "Letzte Einträge : ");
define("CONTENT_LAN_81", "Kategorien");
define("CONTENT_LAN_82", "Keine Einträge bis jetzt in");
define("CONTENT_LAN_83", "Eintrags Archiv");
define("CONTENT_LAN_84", "Inhalts Archiv");
define("CONTENT_LAN_85", "Autorliste");
define("CONTENT_LAN_86", "Top Score Einträge ansehen");
define("CONTENT_LAN_87", "Top Score Inhalt");
define("CONTENT_LAN_88", "Keine Inhaltseinträge haben bis jetzt einen Score");
define("CONTENT_LAN_89", "Seite auswählen");
define("CONTENT_LAN_90", "Vorherige Seite");
define("CONTENT_LAN_91", "Nächste Seite");
define("CONTENT_LAN_92", " - diese");

define('CONTENT_LAN_ALL', 'alle');

define("CONTENT_MENU_LAN_0", "Inhalts-Menü :");
define("CONTENT_MENU_LAN_1", "Keine Inhaltseintäge bis jetzt");
define("CONTENT_MENU_LAN_2", "Letzte Einträge");
define("CONTENT_MENU_LAN_3", "Kategorien");
define("CONTENT_MENU_LAN_4", "Inhalts Links");
define("CONTENT_MENU_LAN_5", "keine Einträge in");
define("CONTENT_MENU_LAN_6", "");
define("CONTENT_MENU_LAN_7", "");
define("CONTENT_MENU_LAN_8", "");
define("CONTENT_MENU_LAN_9", "");
define("CONTENT_MENU_LAN_10", "");
define("CONTENT_MENU_LAN_11", "");
define("CONTENT_MENU_LAN_12", "");
define("CONTENT_MENU_LAN_13", "");
define("CONTENT_MENU_LAN_14", "");
define("CONTENT_MENU_LAN_15", "");
define("CONTENT_MENU_LAN_16", "");
define("CONTENT_MENU_LAN_17", "");
define("CONTENT_MENU_LAN_18", "");
define("CONTENT_MENU_LAN_19", "");
define("CONTENT_MENU_LAN_20", "");




?>
