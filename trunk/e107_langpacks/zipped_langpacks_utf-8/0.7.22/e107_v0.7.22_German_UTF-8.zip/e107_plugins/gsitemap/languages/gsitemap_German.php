<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/gsitemap/languages/gsitemap_German.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:05 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "Sitemap");
define("GSLAN_1", "Seiten Link");
define("GSLAN_2", "Importieren?");
define("GSLAN_3", "Typ");
define("GSLAN_4", "Name");
define("GSLAN_5", "Url");
define("GSLAN_6", "Bitte Links für Import markieren ...");
define("GSLAN_7", "Import Links");
define("GSLAN_8", "Import mit:");
define("GSLAN_9", "Priorität");
define("GSLAN_10", "Frequenz");
define("GSLAN_11", "immer");
define("GSLAN_12", "stündlich");
define("GSLAN_13", "täglich");
define("GSLAN_14", "wöchentlich");
define("GSLAN_15", "monatlich");
define("GSLAN_16", "jährlich");
define("GSLAN_17", "nie");
define("GSLAN_18", "Markierte Links importieren");
define("GSLAN_19", "Google Sitemap");
define("GSLAN_20", "Auflistung");
define("GSLAN_21", "Anleitung");
define("GSLAN_22", "Neuen Eintrag erstellen");
define("GSLAN_23", "Importieren");
define("GSLAN_24", "Google Sitemap Einträge");
define("GSLAN_25", "Name");
define("GSLAN_26", "URL");
define("GSLAN_27", "Letzter Modus");
define("GSLAN_28", "Freq.");
define("GSLAN_29", "Google Sitemap Konfiguartion");
define("GSLAN_30", "Anzeigesortierung");
define("GSLAN_31", "Sichtbar für");
define("GSLAN_32", "Wie kann Google Sitemaps genutzt werden");
define("GSLAN_33", "GSiteMap Anleitung");
define("GSLAN_34", "Estellen Sie bitte zuerst die Links die Sie in Ihrer Sitemap aufgelistet haben wollen. Sie können die meisten Links automatisch importieren indem Sie den 'Import' Button rechts klicken");
define("GSLAN_35", "Fall Sie sich entschieden haben, Links zu importieren, klicken Sie bitte 'Import' und markieren Sie danach die gewünschten Links, die Sier importieren möchten");
define("GSLAN_36", "Sie können auch individuelle Links erstellen in dem Sie auf  'Erstelle neue Links' klicken");
define("GSLAN_37", "Wenn Sie dann Einträge getätigt haben, gehen Sie bitte auf <a href='https://www.google.com/webmasters/sitemaps/stats'>https://www.google.com/webmasters/sitemaps/stats</a> und geben Sie dort folgende URL ein -> <b>".SITEURL."gsitemap.php</b> - falls die URL nicht richtig ist, vergewissern Sie sich, dass Sie die Seitenurl in  admin -> Voreinstellungen korrekt eingegeben haben.");
define("GSLAN_38", "Für mehr Informationen über das Google Sitemap Protokoll, besuchen Sie bitte <a href='http://www.google.com/webmasters/sitemaps/docs/en/protocol.html'>http://www.google.com/webmasters/sitemaps/docs/en/protocol.html</a>.");
define("GSLAN_39", "Keine Links in der Sitemap - Seitenlinks importieren?");
define("GSLAN_40", "Google Sitemap Einträge");

?>
