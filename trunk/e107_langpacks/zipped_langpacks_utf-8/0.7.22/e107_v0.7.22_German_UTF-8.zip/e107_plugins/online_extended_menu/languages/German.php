<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/online_extended_menu/languages/German.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:06 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Gäste: ");
define("ONLINE_EL2", "Mitglieder: ");
define("ONLINE_EL3", "auf dieser Seite: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Mitglieder");
define("ONLINE_EL6", "Neuestes Mitglied");
define("ONLINE_EL7", "auf Seite");

define("ONLINE_EL8", "Online Rekord: ");
define("ONLINE_EL9", "am");

define("ONLINE_TRACKING_MESSAGE", "Online User Tracking ist momentan deaktiviert, bitte aktivieren Sie es [link=".e_ADMIN."users.php?options]hier[/link][br]");
?>
