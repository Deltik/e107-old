<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/search_menu/languages/German.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:07 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
define("LAN_180", "Suche");

?>
