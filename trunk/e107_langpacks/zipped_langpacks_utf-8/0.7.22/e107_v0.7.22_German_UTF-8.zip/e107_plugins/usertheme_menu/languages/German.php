<?php

define('LAN_UMENU_THEME_1', 'Theme setzen');
define('LAN_UMENU_THEME_2', 'Theme wählen');
define('LAN_UMENU_THEME_3', 'Benutzer:');
define('LAN_UMENU_THEME_4', 'Aktivieren Sie die Themes, welche Benutzer auswählen können');
define('LAN_UMENU_THEME_5', 'Update');
define('LAN_UMENU_THEME_6', 'Für Benutzer verfügbare Themes');
define('LAN_UMENU_THEME_7', 'Klasse, welche Themes auswählen kann');

?>
