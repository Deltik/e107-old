<?php
define("OTHERDB_LAN_1", "Datenbank Typ:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Benutzername:");
define("OTHERDB_LAN_4", "Passwort:");
define("OTHERDB_LAN_5", "Datenbank");
define("OTHERDB_LAN_6", "Tabelle");
define("OTHERDB_LAN_7", "Benutzername Feld:");
define("OTHERDB_LAN_8", "Passwort Feld:");
define("OTHERDB_LAN_9", "Passwort Methode:");
define("OTHERDB_LAN_10", "otherdb auth konfigurieren");
define("OTHERDB_LAN_11", "** Nachfolgende Felder werden nicht benötigt, falls Sie eine e107 Datenbank benutzen.");

?>
