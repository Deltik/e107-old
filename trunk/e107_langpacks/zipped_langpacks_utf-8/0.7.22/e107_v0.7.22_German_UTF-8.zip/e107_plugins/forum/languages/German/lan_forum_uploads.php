<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/forum/languages/German/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:05 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','Hochgeladene Dateien im Forum');
define('FRMUP_2','Datei gelöscht');
define('FRMUP_3','Fehler: Datei kann nicht gelöscht werden');
define('FRMUP_4','Datei Löschung');
define('FRMUP_5','Dateiname');
define('FRMUP_6','Ergebnis');
define('FRMUP_7','Im Thread gefunden');
define('FRMUP_8','NICHT GEFUNDEN');
define('FRMUP_9','Keine hochgeladenen Datein gefunden');
define('FRMUP_10','Löschen');
	
?>
