<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/forum/languages/German/lan_newforumposts_menu.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:05 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Alle letzten Forumeinträge sind ausserhalb Ihrer Gesetzten Benutzerklasse, deswegen besteht keine Möglichkeit sie anzuzeigen.");
define("NFP_2", "Keine Einträge");
define("NFP_3", "New Forum Posts Menü Konfiguration gespeichert");
define("NFP_4", "Überschrift");
define("NFP_5", "Anzahl der Einträge die angezeigt werden sollen?");
define("NFP_6", "Anzahl der Zeichen die angezeigt werden?");
define("NFP_7", "Postfix für zu lange Einträge?");
define("NFP_8", "Zeige die orginalen Topics im Menü?");
define("NFP_9", "Menüeinstellungen aktualisieren");
define("NFP_10", "New Forum Posts Menü Konfiguration");
define("NFP_11", "Geschrieben von");
define("NFP_12", "maximale Alter des angezeigten Eintrags");
define("NFP_13", "Bitte 0 für wenig frequentierte Seiten verwenden; wenn Sie einen Wert in Tagen setzen, wird sich die Zeit für Datenbankanfragen auf frequentierten Seiten reduzieren");


?>