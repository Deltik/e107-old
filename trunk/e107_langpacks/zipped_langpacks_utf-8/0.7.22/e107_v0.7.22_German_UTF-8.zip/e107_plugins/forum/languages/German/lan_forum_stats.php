<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/forum/languages/German/lan_forum_stats.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:05 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Forum Statistik");

define("FSLAN_1", "Generell");
define("FSLAN_2", "Forum eröffnet");
define("FSLAN_3", "Geöffnet seit");
define("FSLAN_4", "Einträge insgesamt");
define("FSLAN_5", "Forum Topics");
define("FSLAN_6", "Forum Antworten");
define("FSLAN_7", "Forum Thread Ansichten");
define("FSLAN_8", "Datenbankgrösse (nur Forumtabellen)");
define("FSLAN_9", "Durchschnittliche Zeilenlänge in den Forumtabellen");
define("FSLAN_10", "Aktivste Topics");
define("FSLAN_11", "Rang");
define("FSLAN_12", "Topic");
define("FSLAN_13", "Antworten");
define("FSLAN_14", "Gestartet von");
define("FSLAN_15", "Datum");
define("FSLAN_16", "Meist gesehene Topics");
define("FSLAN_17", "Ansichten");
define("FSLAN_18", "Top Posters");
define("FSLAN_19", "Name");
define("FSLAN_20", "Einträge");
define("FSLAN_21", "Top Topic Starter");
define("FSLAN_22", "Top Antworter");
define("FSLAN_23", "Forum Statistiken");
define("FSLAN_24", "Durchschnittliche Einträge pro Tag");

?>
