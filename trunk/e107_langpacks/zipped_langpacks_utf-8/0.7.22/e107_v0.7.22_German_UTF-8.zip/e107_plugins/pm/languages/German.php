<?php
/*
+---------------------------------------------------------------+
|        e107 website system German Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/pm/languages/German.php,v $
|        $Revision: 1.2 $
|        $Date: 2010/01/30 13:47:03 $
|        $Author: lars78 $
|        $ UTF-8 encoded $
|        $updated by: webmaster@e107cms.de (http://www.e107cms.de) $
+---------------------------------------------------------------+
*/

define("LAN_PM", "Private Nachrichten");
define("LAN_PM_1", "Private Nachricht senden");
define("LAN_PM_2", "an");
define("LAN_PM_3", "Voransicht");
define("LAN_PM_4", "Benutzerklasse");
define("LAN_PM_5", "Betreff");
define("LAN_PM_6", "Nachricht");
define("LAN_PM_7", "Smilies");
define("LAN_PM_8", "Anhänge");
define("LAN_PM_9", "Lesebestätigung");
define("LAN_PM_10", "Möchten Sie eine E-mail bekommen, wenn diese Private Nachricht gelesen wurde?");
define("LAN_PM_11", "Neuen Upload hinzufügen");
define("LAN_PM_12", "Sie haben keine Berechtigung dieses Private Nachrichtensystem zu nutzen");
define("LAN_PM_13", "Ihr Postausgang ist momentan zu {PERCENT}% voll, - Sie können keine weiteren Privaten Nachrichten verschicken. Bitte löschen Sie ältere, nichtmehr benötigte Einträge");
define("LAN_PM_14", "Fehler: Womöglich doppelter Eintrag. - Ihre Private Nachricht wurde nicht versendet");
define("LAN_PM_15", "Sie haben keine Berechtigung der Auswahl, an Benutzerklassen zu senden");
define("LAN_PM_16", "Sie müssen folgender Benutzerklasse angehören");
define("LAN_PM_17", "Benutzer wurde nicht gefunden");
define("LAN_PM_18", "Sie haben keine Berechtigung Private Nachrichten zu senden an: ");
define("LAN_PM_19", "Ihr Postasgang ist voll. Sie haben deshalb keine Möglichkeit momentan neue Private Nachrichten zu verschicken.");
define("LAN_PM_21", "Durch Hinzufügen dieser Privaten Nachricht, übersteigt Ihr Postausgang die maximale Größe, - Private Nachricht wurde nicht versendet");
define("LAN_PM_22", "Dateiupload fehlgeschlagen");
define("LAN_PM_23", "Sie haben keine Berechtigung Anhänge zu versenden");
define("LAN_PM_24", "Private Nachrichten löschen");
define("LAN_PM_25", "Posteingang");
define("LAN_PM_26", "Postausgang");
define("LAN_PM_27", "Ungelesen");
define("LAN_PM_28", "N/A");
define("LAN_PM_29", "Nachricht verschickt");
define("LAN_PM_30", "Nachricht gelesen");
define("LAN_PM_31", "Von");
define("LAN_PM_32", "Erhalten");
define("LAN_PM_33", "Verschicken");
define("LAN_PM_34", "Keine Nachrichten");
define("LAN_PM_35", "Neue Private Nachricht verschicken");
define("LAN_PM_36", "Insgesamt");
define("LAN_PM_37", "Ungelesen");
define("LAN_PM_38", "Private Nachricht verschickt an Benutzerklasse");
define("LAN_PM_39", "Fehler beom Versenden der Privaten Nachricht an");
define("LAN_PM_40", "Private Nachricht verschickt an Benutzer");
define("LAN_PM_41", "Fehler beim Hinzufügen der Privaten Nachricht zu Ihrem Postausgang");
define("LAN_PM_42", "Private Nachricht wurde im Posteingang gelöscht");
define("LAN_PM_43", "Private Nachricht wurde im Postausgang gelöscht");
define("LAN_PM_44", "Blockierung aufgehoben: {UNAME} darf Ihnen nun Private Nachrichten schicken");
define("LAN_PM_45", "Fehler: Blockierung wurde nicht aufgehoben, unbekannter Fehler");
define("LAN_PM_46", "Blockierung nicht gesetzt für {UNAME}");
define("LAN_PM_47", "Blockierung hinzugefügt: {UNAME} darf Ihnen keine Privaten Nachrichten mehr schicken");
define("LAN_PM_48", "Fehler: Blockierung nicht hinzugefügt, unbekannter Fehler");
define("LAN_PM_49", "Fehler: Blockierung bsteht schon für {UNAME}");
define("LAN_PM_50", "Benutzer blockieren");
define("LAN_PM_51", "Blockierung für Benutzer aufheben");
define("LAN_PM_52", "Löschen");
define("LAN_PM_53", "Ausgewählte löschen");
define("LAN_PM_54", "Orginaltext");
define("LAN_PM_55", "Antwort verschicken");
define("LAN_PM_56", "Sie haben keine Berechtigung auf diese Private Nachricht zu antworten");
define("LAN_PM_57", "Nachricht wurde nicht gefunden");
define("LAN_PM_58", "Re: ");
define("LAN_PM_59", "Gehe zur Seite: ");
define("LAN_PM_60", "Sie haben keine Erlaubnis diese Nachricht zu sehen");
define("LAN_PM_61", "Kein Betreff");
define("LAN_PM_62", "Datei: [{FILENAME}] hat Dateigrößenlimit überschritten - konnte nicht angehängt werden");
define("LAN_PM_63", "Klasse:");
define("LAN_PM_64", "Fehler: Sie haben keine Berechtigung Nachrichten des Hauptseitenadministrator zu blockieren");
define("LAN_PM_65", "Fehler: Sie haben nichts eingetragen was gesendet werden soll");
define('LAN_PM_66', 'Geblockte Sender');
define('LAN_PM_67', 'Keine Benutzer geblockt');
define('LAN_PM_68', 'Benutzer Name');
define('LAN_PM_69', 'Geblockt am');
define('LAN_PM_70', 'Blockierung von Benutzer aufheben');
define('LAN_PM_71', '--GUT-- Anhang/Anhänge gelöscht. --FEHLGESCHLAGEN-- Fehler');
define('LAN_PM_72', 'Benutzer gelöscht');

define("LAN_PM_100", "Neue Private Nachricht von ");
define("LAN_PM_101", "Sie haben eine neue Private Nachricht erhalten von ");
define("LAN_PM_102", "Nachricht gesendet von: ");
define("LAN_PM_103", "Betreff der Nachricht: ");
define("LAN_PM_104", "Anzahl der Anhänge: ");
define("LAN_PM_105", "Sie können hier die Private Nachricht lesen: ");
define("LAN_PM_106", "Private Nachricht gelesen von ");
define("LAN_PM_107", "Die Private Nachricht, die Sie {UNAME} gesendet habern wurde gelesen am ");
define("LAN_PM_108", "Nachricht gesendet am: ");
define("LAN_PM_109", "Neue Nachricht(en)");
define("LAN_PM_110", "ok");
define("LAN_PM_111", "Lese");


?>