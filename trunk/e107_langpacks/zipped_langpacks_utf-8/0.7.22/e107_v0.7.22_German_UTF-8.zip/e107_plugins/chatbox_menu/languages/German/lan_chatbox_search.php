<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/chatbox_menu/languages/German/lan_chatbox_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:04 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");

?>
