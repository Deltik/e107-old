<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_plugins/banner_menu/languages/German.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:04 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Werbung");
define("BANNER_MENU_L2", "Banner Menü Konfiguration gespeichert");

define("BANNER_MENU_L3", "Überschrift");
define("BANNER_MENU_L4", "Kampagne");
define("BANNER_MENU_L5", "Banner Menü Konfiguration");
define("BANNER_MENU_L6", "Wählen Sie die Kampagnen, die im Menü angezeigt werden sollen");
define("BANNER_MENU_L7", "Bestehende Kampagnen");
define("BANNER_MENU_L8", "Gewählte Kampagnen");
define("BANNER_MENU_L9", "Auswahl aufheben");
define("BANNER_MENU_L10", "Wie sollen die gewählten Kampagnen angezeigt werden ?");
define("BANNER_MENU_L11", "Wählen Sie die Anzeigeoption ...");
define("BANNER_MENU_L12", "Eine Kampagne in einem Menü");
define("BANNER_MENU_L13", "Alle Kampagnen in einem Menü");
define("BANNER_MENU_L14", "Alle Kampagnen in separaten Menüs");
define("BANNER_MENU_L15", "Wieviele Banner sollen angezeigt werden ?");
define("BANNER_MENU_L16", "Diese Einstellungen gelten nur in Verbindung mit Option 2 und 3.<br />Falls weniger Banner vorhanden sind, wird die maximale Anzahl gesetzt.");
define("BANNER_MENU_L17", "Anzahl setzen ...");
define("BANNER_MENU_L18", "Menüeinstellungen aktualisieren");

?>
