<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Benutzer Registrierung");

define("NT_LAN_UV_1", "Benutzer Registrierung verifiziert");
define("NT_LAN_UV_2", "Benutzer Session String");
define("NT_LAN_UV_3", "Benutzer Login Name: ");
define("NT_LAN_UV_4", "Benutzer IP: ");

define("NT_LAN_LI_1", "Benutzer eingelogged");

define("NT_LAN_LO_1", "Benutzer ausgelogged");
define("NT_LAN_LO_2", " aus der Seite ausgelogged");

define("NT_LAN_FL_1", "Flood Bannung");
define("NT_LAN_FL_2", "Ip Adresse wurde wegen flooding gebannt - Es gab zu viele Anfragen mit einer und der selben IP Adresse in der in den Voreinstellungen gesetzten Konfiguration - ");

define("NT_LAN_SN_1", "Newseintrag übermittelt");

define("NT_LAN_NU_1", "Aktualisiert");

define("NT_LAN_ND_1", "Newseintrag gelöscht");
define("NT_LAN_ND_2", "Newseintrags Id gelöscht");

?>
