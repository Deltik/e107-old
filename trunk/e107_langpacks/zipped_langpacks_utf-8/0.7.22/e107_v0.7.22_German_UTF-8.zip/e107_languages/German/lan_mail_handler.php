<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_mail_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Produziert vom e107 Website System");
define("LANMAILH_2", "Dies ist eine Multi-Part Message im MIME Format.");
define("LANMAILH_3", " ist nicht korrekt formatiert");
define("LANMAILH_4", "Der server hat die Adresse abgelehnt");
define("LANMAILH_5", "Server antwortet nicht");
define("LANMAILH_6", "E-mail Server kann nicht gefunden werden.");
define("LANMAILH_7", " scheint gültig zu sein.");



?>
