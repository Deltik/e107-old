<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_footer.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Seitenname");
define("FOOTLAN_2", "Haupt Administrator");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "Erstellt");
define("FOOTLAN_5", "Admin-Theme");
define("FOOTLAN_6", "von");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installations Datum");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "PHP Version");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Seiten Info");
define("FOOTLAN_14", "Zeige Dokumentationen");
define("FOOTLAN_15", "Dokumentationen");
define("FOOTLAN_16", "Datenbank");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "Seiten-Theme");

?>
