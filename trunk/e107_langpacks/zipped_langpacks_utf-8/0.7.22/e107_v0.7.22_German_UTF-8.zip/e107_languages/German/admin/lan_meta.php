<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_meta.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta Tags in Datenbank aktualisiert");
define("METLAN_2", "Meta Tags eingeben");
define("METLAN_3", "Eingabe neuer Meta Tag Einstellungen");
define("METLAN_4", "Aktualisiert");
define("METLAN_5", "Beschreibung hier eingeben");
define("METLAN_6", "tippen, sie, eine, Liste, ihrer, Keywords, hier");
define("METLAN_7", "schreiben Sie hier die Copyrighthinweise");
define("METLAN_8", "Meta Tags");
define("METLAN_9", "Beschreibung");
define("METLAN_10", "Schlüsselwörter");
define("METLAN_11", "Copyright");
define("METLAN_12", "Benutze 'News Titel' und 'News Zusammenfassung' als Metabeschreibung von Newsseiten.");
define("METLAN_13", "Autor");

?>
