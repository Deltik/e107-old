<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_cpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Titel");
define("CUSLAN_2", "Typ");
define("CUSLAN_3", "Optionen");
define("CUSLAN_4", "Diese Seite löschen?");
define("CUSLAN_5", "Bestehende Seiten");
define("CUSLAN_7", "Menü Name");
define("CUSLAN_8", "Titel / Überschrift");
define("CUSLAN_9", "Text");
define("CUSLAN_10", "Bewertung erlauben?");
define("CUSLAN_11", "Erste Seite");
define("CUSLAN_12", "Seite erstellen");
define("CUSLAN_13", "Kommentare erlauben");
define("CUSLAN_14", "Passwort geschützte Seite");
define("CUSLAN_15", "Passwort eingeben um Seite zu schützen");
define("CUSLAN_16", "Link im Hauptmenü erstellen");
define("CUSLAN_17", "Linkname eingeben um zu erstellen");
define("CUSLAN_18", "Seite / Link sichtbar für");
define("CUSLAN_19", "Seite aktualisieren");
define("CUSLAN_20", "Seite erstellen");
define("CUSLAN_21", "Menü aktualisieren");
define("CUSLAN_22", "Menü erstellen");
define("CUSLAN_23", "Seite bearbeiten");
define("CUSLAN_24", "Neue Seite erstellen");
define("CUSLAN_25", "Menü bearbeiten");
define("CUSLAN_26", "Neues Menü erstellen");
define("CUSLAN_27", "Seite in Datenbank gespeichert.");
define("CUSLAN_28", "Seite gelöscht");
define("CUSLAN_29", "Seite auflisten, falls keine Seite geählt wurde");
define("CUSLAN_30", "Dauer der Cookiewirksamkeit (in seconds)");
define("CUSLAN_31", "Menü erstellen");
define("CUSLAN_32", "Alte Seiten/Menüs konvertieren");
define("CUSLAN_33", "Seite Optionen");
define("CUSLAN_34", "Konvertierung Beginn");
define("CUSLAN_35", "Eigene Seiten Aktualisierung abgeschlossen - aktualisiert");
define("CUSLAN_36", "Um Voreinstellungen für die Seiten zu setzen, gehen Sie zur ersten Seite zurück und bearbeiten Sie die gewünschte Seite.");
define("CUSLAN_37", "Eigen Seiten Aktualisierung");
define("CUSLAN_38", "an");
define("CUSLAN_39", "aus");
define("CUSLAN_40", "Optionen speichern");
define("CUSLAN_41", "Autor, - und Datumsinformationen anzeigen");
define("CUSLAN_42", "Keine Seiten definiert");
define("CUSLAN_43", "Menü ohne Titel");
define("CUSLAN_44", "Seite ohne Titel");


?>