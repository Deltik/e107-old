<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_ugflag.php,v $
|     $Revision: 1.2 $
|     $Date: 2010/01/30 13:47:02 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
|     $updated by: webmaster@e107cms.de (http://www.e107cms.de) $
+----------------------------------------------------------------------------+
*/
define('UGFLAN_1', 'Wartungseinstellungen aktualisiert');
define('UGFLAN_2', 'Aktiviere Wartungsstatus');
define('UGFLAN_3', 'Wartungseinstellungen aktualisieren');
define('UGFLAN_4', 'Wartungseinstellungen');

define('UGFLAN_5', 'Text der angezeigt werden soll, wenn die Seite im Wartungsmodus ist.');
define('UGFLAN_6', 'Frei lassen, um vorgegebenen Text zu verwenden.');

define('UGFLAN_8', 'Zugriff nur für Admins');
define('UGFLAN_9', 'Zugriff nur für Haupt Admins');

?>
