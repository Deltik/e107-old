<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Schicke E-Mail Benachrichtigung an");
define("UCSLAN_2", "Privilegien aktualisiert");
define("UCSLAN_3", "Hallo ");
define("UCSLAN_4", "Ihre Privilegien wurden aktualisiert");
define("UCSLAN_5", "Sie haben nun Zugriff auf die folgenden Bereiche");
define("UCSLAN_6", "Klasse für Benutzer festlegen");
define("UCSLAN_7", "Klassen festlegen");
define("UCSLAN_8", "Benutzer benachrichtigen");
define("UCSLAN_9", "Klassen aktualisiert.");
define("UCSLAN_10", "Glückwunsch");
define("UCSLAN_12", "Nur für Mitglieder");


?>