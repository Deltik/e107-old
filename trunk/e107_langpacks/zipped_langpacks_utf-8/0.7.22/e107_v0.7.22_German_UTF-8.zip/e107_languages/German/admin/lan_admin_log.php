<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "Datum");
define("LAN_ADMINLOG_2", "Titel");
define("LAN_ADMINLOG_3", "Beschreibung");
define("LAN_ADMINLOG_4", "User IP");
define("LAN_ADMINLOG_5", "User ID");
define("LAN_ADMINLOG_6", "Information Icon");
define("LAN_ADMINLOG_7", "Information Nachricht");
define("LAN_ADMINLOG_8", "Bemerkung Icon");
define("LAN_ADMINLOG_9", "Bemerkung Nchricht");
define("LAN_ADMINLOG_10", "Warnung Icon");
define("LAN_ADMINLOG_11", "Warnung Nchricht");
define("LAN_ADMINLOG_12", "Fatal Icon");
define("LAN_ADMINLOG_13", "Fatal Fehlermeldung");

?>
