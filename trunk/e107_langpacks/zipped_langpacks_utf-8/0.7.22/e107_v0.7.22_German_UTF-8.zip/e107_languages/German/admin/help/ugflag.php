<?php
$text = "Wenn Sie e107 aufrüsten (Upgrade) oder Ihre Seite für Wartungsarbeiten offline ist, dann gehen Sie auf das Menü Wartung und aktivieren Sie die Checkbox 'aktiviere Wartungsstatus'. Danach erhalten Ihre Besucher für den zeitraum der Wartun eine Meldung, dass die Seite offline ist. Anschlie&szlig;end deaktivieren Sie bitte die Checkbox.";

$ns -> tablerender("Wartung", $text);
?>
