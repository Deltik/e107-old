<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Fehler - bitte erneut übertragen");
define("UDALAN_2", "Einstellungen aktualisiert");
define("UDALAN_3", "Einstellungen aktualisiert für");
define("UDALAN_4", "Name");
define("UDALAN_5", "Passwort");
define("UDALAN_6", "Passwort wiederholen");
define("UDALAN_7", "Passwort ändern");
define("UDALAN_8", "Passwort Aktualisierung für");

?>
