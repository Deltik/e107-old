<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_banlist.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/11/29 09:00:48 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
|     $updated by: webmaster@e107cms.de (http://www.e107cms.de) $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Verbannung aufgehoben.");
define("BANLAN_2", "Keine Verbannungen.");
define("BANLAN_3", "Existierende Verbannungen");
define("BANLAN_4", "Verbannung aufheben");
define("BANLAN_5", "Geben Sie entweder IP, E-Mail Adresse oder Host ein");
define("BANLAN_7", "Grund");
define("BANLAN_8", "Adresse verbannen");
define("BANLAN_9", "Benutzer von Seite verbannen, per e-mail, IP, oder Host-Adresse");
define("BANLAN_10", "IP / Email / Grund");
define("BANLAN_11", "Auto-Verbannung: Mehr als 10 fehlerhafte Loginversuche");
define("BANLAN_12", "Bitte beachten: Reverse DNS ist moment abgeschaltet, es muss angestellt werden um Verbannung  des Host zu ermöglichen. Verbannung über IP und E-mail wird weiterhin funktionieren.");
define("BANLAN_13", "Anmerkung: Um einen Benutzer per Benutzername zu löschen, gehen Sie bitte zur Benutzer Adminseite: ");
define("BANLAN_78", "Zu viele Zugriffe (--ZUGRIFFE-- Anforderungen in einer bestimmten Zeit)");

?>