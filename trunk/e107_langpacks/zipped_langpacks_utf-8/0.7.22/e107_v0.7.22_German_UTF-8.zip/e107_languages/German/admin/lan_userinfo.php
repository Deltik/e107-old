<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_userinfo.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Die IP Adresser des Absenders kann nicht gefunden werden - keine Information vorhanden.");
//define("USFLAN_2", "Fehler");
define("USFLAN_3", "Nachricht geschickt von IP Adresse");
define("USFLAN_4", "Host");
define("USFLAN_5", "Klicken Sie hier um diese IP Adresse auf die Verbannungs Seite zu legen");
define("USFLAN_6", "BenutzerID");
define("USFLAN_7", "Benutzer Information");

?>
