<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_emoticon.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/02/14 20:49:20 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $updated by: webmaster@langenbach-service.com (http://www.langenbach-service.com)$
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Smilie Aktivierung");
define("EMOLAN_2", "Name");
define("EMOLAN_3", "Smilies");
define("EMOLAN_4", "Smilies aktivieren?");
define("EMOLAN_5", "Bild");
define("EMOLAN_6", "Smilie Code");
define("EMOLAN_7", "Mehrfache Eingaben mit Leerstellen trennen");
define("EMOLAN_8", "Status");
define("EMOLAN_9", "Optionen");
define("EMOLAN_10", "Aktiv");
define("EMOLAN_11", "Paket aktivieren");
define("EMOLAN_12", "Dieses Paket bearbeiten / konfigurieren");
define("EMOLAN_13", "Installierte Pakete");
define("EMOLAN_14", "Konfiguration speichern");
define("EMOLAN_15", "Bearbeite / konfiguriere Smilies");
define("EMOLAN_16", "Smilie Konfiguration gespeichert");
define("EMOLAN_17", "Sie verwenden im Moment ein Smiliepaket, welches Leerzeichen beinhaltet, die nicht erlaubt sind !");
define("EMOLAN_18", "Korrigieren Sie bitte unten aufgeführte Liste, so dass keine Leerstellen mehr vorhanden sind:");
define("EMOLAN_19", "Name");
define("EMOLAN_20", "Ort");
define("EMOLAN_21", "Fehler");
define("EMOLAN_22", "Neues Smilie-Paket gefunden:");
define("EMOLAN_23", "Neues Smilie-xml-Paket gefunden:");
define("EMOLAN_24", "Neues Smilie-php gefunden:");
define("EMOLAN_25", "Neue PHP-Smilies installieren: ");
define("EMOLAN_26", "Paket nochmals scannen");
define("EMOLAN_27", "Es ist ein Fehler aufgetreten: ");
define("EMOLAN_28", "XML generieren");
define("EMOLAN_29", "XML Datei erstellt: ");
define("EMOLAN_30", "Fehler beim Schreiben der XML Datei");


?>