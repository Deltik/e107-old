<?php
$caption = "Cache-Modus";
$text = "Wenn Sie Cache aktiviert haben, beschleunigen Sie den Seitenaufbau enorm. Außerdem wir die SQL Datenbankabfrage auf eine Minimum reduziert.<br />
<br /><b>WICHITIG!!! Während Sie Ihr eigenes Theme bauen, sollten Sie unbedingt den Chache Modus ausschalten. Sonst werden Ihre vorgenommenen Änderungen gar nicht oder nur rudimentär angezeigt.</b> <br />
TIPP: Sie sollten den Cache gegebenenfalls auch leeren, um Änderungen sichtbar zu machen";
$ns -> tablerender($caption, $text);
?>
