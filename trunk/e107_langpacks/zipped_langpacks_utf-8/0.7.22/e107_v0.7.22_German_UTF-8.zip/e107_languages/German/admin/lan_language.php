<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_language.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "konnte nicht erstellt werden.(besteht bereits)");
define("LANG_LAN_01", "wurde gelöscht(falls bestehend) und neu erstellt.");
define("LANG_LAN_02", "konnte nicht gelöscht werden");
define("LANG_LAN_03", "Tabellen");
define("LANG_LAN_05", "Nicht installiert");
define("LANG_LAN_06", "Tabellen erstellen");
define("LANG_LAN_07", "Markiere bestehende Tabellen?");
define("LANG_LAN_08", "Ersetze bestehende Tabellen (Daten werden verloren gehen).");
define("LANG_LAN_10", "Löschen bestätigen");
define("LANG_LAN_11", "Nichtmarkierte Tabellen von oben löschen (falls diese bestehen).");
define("LANG_LAN_12", "Multi-Language Tabellen freischalten");
define("LANG_LAN_13", "Multi-Language Voreinstellungen");
define("LANG_LAN_14", "Gesetzte Sprache der Seite");
define("LANG_LAN_15", "Bitte hier markieren um Daten der gesetzten Sprache zu kopieren.(nützlich für Links, News-Kategorien etc.) ");
define("LANG_LAN_16", "Multi-language Datenbankbenutzung");
define("LANG_LAN_17", "Gesetzte Sprache - keine zusätzlichen Tabellen erfoderlich.");
define("LANG_LAN_18", "geparkte Subdomains benutzen um Sprache zu setzen:");
define("LANG_LAN_19", "z.B. de.mydomain.com um die Sprache aud Deutsch zu stellen.");
define("LANG_LAN_20", "Bitte eine Domain pro Zeile eingeben. Z.B.
meinedomain.de etc. oder frei lassen um es abzuschalten");
define("LANG_LAN_21", "Sprach Tools");


?>