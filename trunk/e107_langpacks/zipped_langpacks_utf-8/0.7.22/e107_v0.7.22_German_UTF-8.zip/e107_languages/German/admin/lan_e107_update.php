<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_e107_update.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Aktion");
define("LAN_UPDATE_3", "Nicht notwendig");

define("LAN_UPDATE_5", "Aktualisierung vorhanden");
define("LAN_UPDATE_6", "Alle aktualisieren");
define("LAN_UPDATE_7", "Ausgeführt");
define("LAN_UPDATE_8", "Aktualisierung von");
define("LAN_UPDATE_9", "bis");
define("LAN_UPDATE_10", "Vorhandene Aktualisierungen");
define("LAN_UPDATE_11", ".617 zu .7 Update fortgeführt");
define("LAN_UPDATE_12", "Eine Ihrer Tabellen beinhaltet doppelte Eintr&auml;ge.");

?>
