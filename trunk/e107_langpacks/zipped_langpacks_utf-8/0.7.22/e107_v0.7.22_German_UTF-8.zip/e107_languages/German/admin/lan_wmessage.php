<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/admin/lan_wmessage.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
//define("WMGLAN_1", "Nachricht für Gäste");
//define("WMGLAN_2", "Nachricht für Mitglieder");
//define("WMGLAN_3", "Nachricht für Administratoren");
//define("WMGLAN_4", "Abschicken");
//define("WMGLAN_5", "Begrü&#223;ungstext einstellen");
//define("WMGLAN_6", "Aktivieren?");
//define("WMGLAN_7", "Einstellungen Willkommensnachricht aktualisiert.");

define("WMLAN_00","Willkommens Nachricht");
define("WMLAN_01","Neue Nachricht erstellen");
define("WMLAN_02","Nachricht");
define("WMLAN_03","Sichtbarkeit");
define("WMLAN_04","Nachricht Text");

define("WMLAN_05","Einbetten");
define("WMLAN_06","Falls markiert, wird der Text innerhalb der Box gerendert");
define("WMLAN_07","Standard System Einstellungen überschreiben um {WMESSAGE} shortcode zu nutzen:");
//define("WMLAN_08","Voreinstellungen");

define("WMLAN_09","Keine Willkommensnachricht bis jetzt eingerichtet");
define("WMLAN_10","Nachricht Überschrift");

?>
