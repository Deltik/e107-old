<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Top Forum Poster");
define("TOP_LAN_1", "Benutzer Name");
define("TOP_LAN_2", "Einträge");
define("TOP_LAN_3", "Top Kommentare Poster");
define("TOP_LAN_4", "Kommentare");
define("TOP_LAN_5", "Top Chatbox Poster");
define("TOP_LAN_6", "Seitenbewertung");

//v.616
define("LAN_1", "Thread");
define("LAN_2", "Poster");
define("LAN_3", "Ansichten");
define("LAN_4", "Antworten");
define("LAN_5", "Letzter Eintrag");
define("LAN_6", "Threads");
define("LAN_7", "Meist aktiven Threads");
define("LAN_8", "Top Poster");


?>
