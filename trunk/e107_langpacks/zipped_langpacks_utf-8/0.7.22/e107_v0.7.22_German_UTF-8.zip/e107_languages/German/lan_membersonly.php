<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_membersonly.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Nur für Mitglieder"); 

define("LAN_MEMBERS_0", "nur für Mitglieder zugänglicher Bereich");
define("LAN_MEMBERS_1", "Dies ist ein für Mitglieder beschränkter Bereich");
define("LAN_MEMBERS_2","um Zugriff zu erlangen <a href='".e_LOGIN."'>loggen Sie sich bitte ein</a>");
define("LAN_MEMBERS_3","oder <a href='".e_SIGNUP."'>register</a> Sie sich als Mitglied");
define("LAN_MEMBERS_4","Klicken sie hier um zur ersten Seite zurückzukehren");

?>
