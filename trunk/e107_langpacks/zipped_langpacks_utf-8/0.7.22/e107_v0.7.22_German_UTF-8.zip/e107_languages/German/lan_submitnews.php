<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_submitnews.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/11/29 06:09:23 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
|     $updated by: webmaster@e107cms.de (http://www.e107cms.de) $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "News übermitteln");
define("LAN_7", "Benutzer Name: ");
define("LAN_62", "Betreff: ");
define("LAN_112", "E-Mail Adresse: ");
define("LAN_133", "Danke");
define("LAN_134", "Ihre News wurden gesendet und werden von einem Administrator baldmöglichst geprüft &amp; aktiviert werden.");
define("LAN_135", "News: ");
define("LAN_136", "News übermitteln");
define("NWSLAN_6", "Kategorie");
define("NWSLAN_10", "Keine News Kategorien");
define("NWSLAN_11", "Sie haben keinen Zutritt zu diesem Bereich.");
define("NWSLAN_12", "Zugang verweigert.");

define("SUBNEWSLAN_1", "Sie müssen einen Titel angeben.\\n");
define("SUBNEWSLAN_2", "Sie müssen Text eingeben.\\n");
define("SUBNEWSLAN_3", "Ihr Anhang muss entweder eine jpg, gif oder png Datei sein");
define("SUBNEWSLAN_4", "Datei ist zu gross");
define("SUBNEWSLAN_5", "Bild Datei");
define("SUBNEWSLAN_6", "(jpg, gif oder png)");
define("SUBNEWSLAN_7", "Sie müssen Ihren Namen und Ihre Email Adresse angeben");
define("SUBNEWSLAN_8", "Fehler beim Hochladen des Bildes");

?>
