<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_prefs.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 Powered Website");
define("LAN_PREF_2", "e107 Webseiten System");
define("LAN_PREF_3", "Diese Seite benutzt <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, veröffentlicht unter den Bedingungen von <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL Lizenz.");
define("LAN_PREF_4", "zensiert");
define("LAN_PREF_5", "Foren");

?>
