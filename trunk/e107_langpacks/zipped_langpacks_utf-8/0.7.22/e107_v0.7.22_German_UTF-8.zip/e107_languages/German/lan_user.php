<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2010/06/07 21:17:49 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Mitglieder");

define("LAN_20", "Fehler");
define("LAN_112", "E-Mail Adresse: ");
// define("LAN_115", "ICQ Nummer: ");
// define("LAN_116", "AIM Adresse: ");
// define("LAN_117", "MSN Messenger: ");
// define("LAN_118", "Geburtstag: ");
// define("LAN_119", "Ort: ");
// define("LAN_120", "Signatur: ");
define("LAN_137", "Es gibt keine Information für diesen Benutzer - nicht registriert.");
define("LAN_138", "Registrierte Benutzer: ");
define("LAN_139", "Reihenfolge: ");
define("LAN_140", "Registrierte Benutzer");

define("LAN_141", "Bis jetzt keine registrierten Benutzer.");
define("LAN_142", "Mitglied");
define("LAN_143", "[wird nicht gezeigt]");
// define("LAN_144", "Webseiten URL: ");
define("LAN_145", "Registriert: ");
define("LAN_146", "Besuche auf dieser Seite seit der Registrierung: ");
define("LAN_147", "Chatbox Einträge: ");
define("LAN_148", "Kommentare: ");
define("LAN_149", "Foren Einträge: ");
define("LAN_308", "Wirklicher Name: ");
define("LAN_400", "Das ist kein gültiger Benutzer.");
define("LAN_401", "Keine Information");
define("LAN_402", "Mitglieder Profil");
define("LAN_403", "Seiten Statistik");
define("LAN_404", "Letzter Besuch");
define("LAN_405", "Tage vergangen");
define("LAN_406", "Beurteilung");
define("LAN_407", "keines");
define("LAN_408", "Kein Foto");
define("LAN_409", "Punkte");
define("LAN_410", "Erweiterte Informationen");
define("LAN_411", "Klicken Sie hier um Ihre Informationen upzudaten");
define("LAN_412", "Klicken Sie hier um die Informationen diese Mitglieds upzudaten");
define("LAN_413", "Foto löschen");
define("LAN_414", "vorheriges Mitglied");
define("LAN_415", "nächstes Mitglied");
define("LAN_416", "Sie müssen eingelogged sein um Zugang zu dieser Seite zu haben");
define("LAN_417", "Hauptseiten Administrator");
define("LAN_418", "Seiten Administrator");

define("LAN_419", "Zeige");
define("LAN_420", "absteigend");
define("LAN_421", "aufsteigend");
define("LAN_422", "abschicken");
define("LAN_423", "Hier klicken um Benutzerkommentare zu lesen");
define("LAN_424", "Hier klicken um Forumeinträge zu lesen");


define("LAN_425", "Private Nachricht senden");
define("LAN_426", "her");
define("USERLAN_1", "Peer Bewertung");
define("USERLAN_2", "Sie haben keine Berechtigung diese Seite anzusehen.");

?>
