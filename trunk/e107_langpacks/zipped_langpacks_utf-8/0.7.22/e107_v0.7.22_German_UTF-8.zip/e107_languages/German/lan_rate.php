<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Bewertung");

define("RATELAN_0", "Abstimmung");
define("RATELAN_1", "Abstimmungen");
define("RATELAN_2", "Wie würden Sie diesen Eintrag bewerten?");
define("RATELAN_3", "Danke für Ihre Abstimmung");
define("RATELAN_4", "Nicht bewertet");
define("RATELAN_5", "Bewerte");


?>
