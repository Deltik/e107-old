<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_print.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Druckerfreundlich"); }

define("LAN_PRINT_86", "Kategorie:");
define("LAN_PRINT_87", "von ");
define("LAN_PRINT_94", "Eintrag von");
define("LAN_PRINT_135", "News: ");
define("LAN_PRINT_303", "Diese News sind von ");
define("LAN_PRINT_304", "Artikel Titel: ");
define("LAN_PRINT_305", "Untertitel: ");
define("LAN_PRINT_306", "Dieser Artikel ist von ");
define("LAN_PRINT_307", "Diese Seite drucken");

define("LAN_PRINT_1", "Druckerfreundlich");

?>
