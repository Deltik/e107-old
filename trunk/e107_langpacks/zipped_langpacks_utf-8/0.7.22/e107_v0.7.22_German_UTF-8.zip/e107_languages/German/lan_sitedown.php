<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_sitedown.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/02/25 13:16:43 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $updated by: webmaster@e107cms.de [Jedi] (http://www.e107cms.de)$
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vorübergehend geschlossen ");
define("LAN_SITEDOWN_00", "ist vorübergehend geschlossen");
define("LAN_SITEDOWN_01", "Diese Seite wurde vorübergehend geschlossen, um wichtige Wartungsarbeiten durchzuführen. Das sollte nicht lange dauern. Bitte kommen Sie bald wieder. Wir bitten um Entschuldigung für diesen Umstand.");
?>