<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2009/02/02 21:37:03 $
|     $Author: lars78 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Jederman (öffentlich)");
define("UC_LAN_1", "Nur für Gäste");
define("UC_LAN_2", "Keiner (inactiv)");
define("UC_LAN_3", "Nur für Mitglieder");
define("UC_LAN_4", "Nur lesen");
define("UC_LAN_5", "Nur für Admin");
define("UC_LAN_6", "Hauptseiten-Admin");
?>
