<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107german/e107_0.7/e107_langpacks/e107_languages/German/lan_contact.php,v $
|     $Revision: 1.4 $
|     $Date: 2009/11/29 13:50:37 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define('PAGE_NAME',     'Impressum & Kontakt');

define("LANCONTACT_01", "Impressum & Kontakt");
define("LANCONTACT_02", "Kontaktformular");
define("LANCONTACT_03", "Benutzername:");
define("LANCONTACT_04", "E-Mail Adresse:");
define("LANCONTACT_05", "Betreff:");
define("LANCONTACT_06", "Nachricht:");
define("LANCONTACT_07", "Eine Kopie dieser Nachricht an Ihre E-Mail Adresse senden ");
define("LANCONTACT_08", "Senden");
define("LANCONTACT_09", "Ihre Nachricht wurde versand.");
define("LANCONTACT_10", "Es gab ein Problem beim Versenden Ihrer Nachricht.");
define("LANCONTACT_11", "Ihre E-Mail Adresse scheint nicht gültig zu sein.\\nBitte überprüfen Sie diese und versuchen es erneut.");
define("LANCONTACT_12", "Ihre Nachricht ist zu kurz.");
define("LANCONTACT_13", "Bitte fügen Sie einen Betreff ein."); 

define("LANCONTACT_14", "Nachricht senden an:");
define("LANCONTACT_15", "Falscher Code eingegeben");
define("LANCONTACT_16", "Code eingeben");





?>