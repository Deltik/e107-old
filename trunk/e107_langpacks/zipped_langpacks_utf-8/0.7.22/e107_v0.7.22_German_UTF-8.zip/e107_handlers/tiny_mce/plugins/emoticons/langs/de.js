// UK lang variables

tinyMCE.addI18n('de.emoticons',{
	desc : 'Smiley einf\u00FCgen'
});