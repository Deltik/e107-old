// UK lang variables
tinyMCE.addI18n('de.ibrowser',{
	desc : 'Bild Browser'
});	