<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("MESSLAN_1", "Fogadott �zenet");
define("MESSLAN_2", "�zenet t�rl�se");
define("MESSLAN_3", "�zenet t�r�lve.");
define("MESSLAN_4", "�sszes �zenet t�rl�se");
define("MESSLAN_5", "Meger�s�t�s");
define("MESSLAN_6", "�sszes �zenet t�r�lve.");
define("MESSLAN_7", "Nincs �zenet.");
define("MESSLAN_8", "�zenet t�pusa");
define("MESSLAN_9", "K�ld�s ideje");

define("MESSLAN_10", "K�ld�");
define("MESSLAN_11", "megnyit�s �j ablakban");
define("MESSLAN_12", "�zenet");
define("MESSLAN_13", "Link");
?>
