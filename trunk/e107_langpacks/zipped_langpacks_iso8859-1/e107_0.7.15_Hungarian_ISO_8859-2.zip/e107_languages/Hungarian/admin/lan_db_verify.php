<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("DBLAN_1", "SQL adatfile beolvas�sa sikertelen<br /><br />Ellen�rizd, hogy a <b>core_sql.php</b> f�jl megtal�lhat� az <b>/admin/sql</b> k�nyvt�rban");
define("DBLAN_2", "�sszes ellen�rz�se");

define("DBLAN_4", "T�bla");
define("DBLAN_5", "Mez�");
define("DBLAN_6", "�llapot");
define("DBLAN_7", "Megjegyz�sek");
define("DBLAN_8", "Ellentmond�s");
define("DBLAN_9", "Jelenleg");
define("DBLAN_10", "k�ne legyen");
define("DBLAN_11", "Hi�nyz� mez�");
define("DBLAN_12", "Extra mez�!");
define("DBLAN_13", "Hi�nyz� t�bla!");
define("DBLAN_14", "V�laszd ki az ellen�rizend� t�bl�(ka)t");
define("DBLAN_15", "Ellen�rz�s kezdete");
define("DBLAN_16", "Adatb�zis ellen�rz�s");
define("DBLAN_17", "Vissza");
define("DBLAN_18", "t�bl�k");
define("DBLAN_19", "Jav�t�s megk�s�rl�se");
define("DBLAN_20", "Jav�t�si k�s�rletek eredm�nyei");
define("DBLAN_21", "Kijel�ltek jav�t�sa");
define("DBLAN_22", " nem olvashat�");
?>
