<?php
$caption = "Men�k s�g�";
if(IsSet($_POST['reset'])){
	if(!check_class("FAKE","",TRUE)){
		$text = "<b>M�velet nem enged�lyezett</b><br /><br />";
	} else {
		for($mc=1;$mc<=5;$mc++){
			$sql -> db_Select("menus","*", "menu_location='$mc' ORDER BY menu_order");
			$count = 1;
			$sql2 = new db;
			while(list($menu_id, $menu_name, $menu_location, $menu_order) = $sql-> db_Fetch()){
				$sql2 -> db_Update("menus", "menu_order='$count' WHERE menu_id='$menu_id' ");
				$count++;
			}
			$text = "<b>Menus reset in database</b><br /><br />";
		}
	}
}else{
	unset($text);
}

$text .= "Be�ll�thatod, hogy mely men�k, hol, s milyen sorrendben jelenjenek meg. A nyilak seg�ts�g�vel mozgasd a men�ket a megfelel� poz�ci�ba. A k�z�pen list�zott men�k inakt�vak. Bekapcsolhatod �ket, ha megadod, hogy hol jelenjenek meg.<br />Ha �gy t�nik, hogy a men�kkel valami nincs rendben, nyomd meg a Friss�t�s gombot.

<br />
<form method='post' action='".$_SERVER['PHP_SELF']."'>
<input class='button' type='submit' name='reset' value='Friss�t�s' />
</form><br />
<div class='indent'><span style='color:red'>*</span> jelzi, ha a men� l�that�s�g�t, el�rhet�s�g�t m�dos�tottad.</div>";

$ns -> tablerender($caption, $text);
?>
