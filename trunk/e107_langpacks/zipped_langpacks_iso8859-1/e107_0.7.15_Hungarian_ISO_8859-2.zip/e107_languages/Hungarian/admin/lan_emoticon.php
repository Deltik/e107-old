<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.7 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("EMOLAN_1", "Emotikonok bekapcsol�sa");
define("EMOLAN_2", "N�v");
define("EMOLAN_3", "Emotikon");
define("EMOLAN_4", "Emotikonok bekapcsol�sa?");

define("EMOLAN_5", "Emotikon k�p");
define("EMOLAN_6", "Emotikon k�d");
define("EMOLAN_7", "�sszetett be�r�shoz haszn�lj sz�k�zt");

define("EMOLAN_8", "�llapot");
define("EMOLAN_9", "Be�ll�t�sok");
define("EMOLAN_10", "Akt�v");
define("EMOLAN_11", "Aktiv�l�s");

define("EMOLAN_12", "M�dos�t / be�ll�t");
define("EMOLAN_13", "Telep�tett csomagok");

define("EMOLAN_14", "Be�ll�t�sok ment�se");
define("EMOLAN_15", "Emotikon m�dos�t�sa / be�ll�t�sa");
define("EMOLAN_16", "Emotikon be�ll�t�sok elmentve");
define("EMOLAN_17", "Ha az emotikon csomag sz�k�zt tartalmaz, akkor az nem lesz enged�lyezve !");
define("EMOLAN_18", "nevezd �t az al�bbi list�ban l�v�ket, hogy ne tartalmazzanak sz�k�zt:");
define("EMOLAN_19", "N�v");
define("EMOLAN_20", "Hely");
define("EMOLAN_21", "Hiba");
//define("EMOLAN_2", "Name");
define("EMOLAN_22", "�j emotikon csoport:");
define("EMOLAN_23", "�j emotikon xml csoport:");
define("EMOLAN_24", "�j emotikon php:");
define("EMOLAN_25", "�j emotikon php telep�t�se: ");
define("EMOLAN_26", "Csomag �jra-ellen�rz�se");
define("EMOLAN_27", "Hiba t�rt�nt a csomag feldolgoz�s�ban: ");
define("EMOLAN_28", "XML l�trehoz�sa");
define("EMOLAN_29", "XML file l�trehozva: ");
define("EMOLAN_30", "Hiba az XML file �r�sakor: ");


?>
