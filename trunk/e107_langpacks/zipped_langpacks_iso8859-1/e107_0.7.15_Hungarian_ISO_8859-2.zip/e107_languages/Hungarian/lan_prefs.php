<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_PREF_1", "e107 alap� weboldal");

define("LAN_PREF_2", "e107 port�l rendszer");

define("LAN_PREF_3", "Ez az oldal <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107 port�l</a> rendszert haszn�l, �s a <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL licensz alatt lett kiadva</a>.");

define("LAN_PREF_4", "cenz�r�zva");

define("LAN_PREF_5", "F�rumok");

?>