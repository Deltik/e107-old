<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Az oldal �tmenetileg z�rva");
define("LAN_SITEDOWN_00", "�tmenetileg z�rva");
define("LAN_SITEDOWN_01", "Karbantart�s miatt az oldalt �tmenetileg lez�rtuk. Nem tart sok�ig - l�togass vissza hamarosan, eln�z�st k�r�nk a kellemetlens�g�rt.");
?>
