<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Keres�s");

define("LAN_140", "Regisztr�lt tagok");
define("LAN_180", "Keres�s");
define("LAN_192", "�sszes kateg�ria");
define("LAN_193", "Esem�nynapt�r");
define("LAN_194", "�sszes kateg�ria");
define("LAN_195", "Keres�s");
define("LAN_196", "tal�lat");

define("LAN_197", "Let�lt�sek");
define("LAN_198", "Nincs tal�lat");
define("LAN_199", "Keresend�:");

define("LAN_416", "Be kell jelentkezned az oldal el�r�s�hez.");
define("LAN_417", "A keresett kifejez�snek legal�bb 3 karakter hossz�nak kell lennie");

define("LAN_418", "Egy�b oldalak");

define("LAN_SEARCH_1", "�sszes kijel�l�se");
define("LAN_SEARCH_2", "�sszes t�rl�se");
define("LAN_SEARCH_3", "bek�ldve ");
define("LAN_SEARCH_4", "Tal�lat a h�r c�m�ben");
define("LAN_SEARCH_5", "Tal�lat a h�r sz�veg�ben");
define("LAN_SEARCH_6", "Tal�lat a h�r b�v�tett sz�veg�ben");
define("LAN_SEARCH_7", "�rta ");
define("LAN_SEARCH_8", " - ");
define("LAN_SEARCH_9", "Nincs c�m");
define("LAN_SEARCH_10", "Ugr�s oldalra:");
define("LAN_SEARCH_11", "Eredm�nyek");
define("LAN_SEARCH_12", ", �sszesen: ");
define("LAN_SEARCH_13", " itt: ");
define("LAN_SEARCH_14", "Kateg�ria:");
define("LAN_SEARCH_15", "Szerz�:");
define("LAN_SEARCH_17", "A keres�s korl�tozott: egy keres�s enged�lyezett ");
define("LAN_SEARCH_18", " m�sodpercenk�nt.");
define("LAN_SEARCH_19", "Keres�s helye:");
define("LAN_SEARCH_20", "Azonos�t�s sz�ks�ges");
define("LAN_SEARCH_21", "Nincs jogosults�god az oldal el�r�s�hez.");



define("LAN_SEARCH_22", "�sszes ter�let");
define("LAN_SEARCH_23", "Sz�k�tett keres�si forma");
define("LAN_SEARCH_24", "Sz�ks�ges szavak");
define("LAN_SEARCH_25", "Nem sz�ks�ges szavak");
define("LAN_SEARCH_26", "Pontos kifejez�s");
define("LAN_SEARCH_27", "Szavak, melyek ezzel kezd�dnek");
define("LAN_SEARCH_28", "Minden, ami nem ig�nyel r�szletes keres�st");
define("LAN_SEARCH_29", "Alap");
define("LAN_SEARCH_30", "R�szletes");
define("LAN_SEARCH_31", "Nincs r�szletes keres�s");
define("LAN_SEARCH_32", "A k�vetkez� szavak kiz�r�sra ker�lnek a keres�sb�l");
define("LAN_SEARCH_33", "A k�vetkez� sz� kiz�r�sra ker�l a keres�sb�l");
define("LAN_SEARCH_34", "�jabb, mint");
define("LAN_SEARCH_35", "R�gebbi, mint");
define("LAN_SEARCH_36", "B�rmikor");
define("LAN_SEARCH_37", "Egy nap");
define("LAN_SEARCH_38", "K�t nap");
define("LAN_SEARCH_39", "H�rom nap");
define("LAN_SEARCH_40", "Egy h�t");
define("LAN_SEARCH_41", "K�t h�t");
define("LAN_SEARCH_42", "H�rom h�t");
define("LAN_SEARCH_43", "Egy h�nap");
define("LAN_SEARCH_44", "K�t h�nap");
define("LAN_SEARCH_45", "H�rom h�nap");
define("LAN_SEARCH_46", "F�l�v");
define("LAN_SEARCH_47", "Egy �v");
define("LAN_SEARCH_48", "K�t �v");
define("LAN_SEARCH_49", "H�rom �v");

define("LAN_SEARCH_50", "Bek�ld�s ideje");
define("LAN_SEARCH_51", "�sszes kateg�ria");
define("LAN_SEARCH_52", "Tal�lat");
define("LAN_SEARCH_53", "Teljes r�sz");
define("LAN_SEARCH_54", "Csak a c�m");
define("LAN_SEARCH_55", "Keres�s a h�r kateg�ri�ban");
define("LAN_SEARCH_56", "�sszes h�r kateg�ria");
define("LAN_SEARCH_57", "Melyhez hozz�sz�ltak");
define("LAN_SEARCH_58", "Minden ter�let");
define("LAN_SEARCH_59", "�sszes hozz�sz�l�s");
define("LAN_SEARCH_60", "Melyhez hozz�sz�ltak");
define("LAN_SEARCH_61", "Bek�ld� szerint");
define("LAN_SEARCH_62", "Regisztr�ci� d�tuma szerint");
define("LAN_SEARCH_63", "Kares�s a kateg�ri�ban");
define("LAN_SEARCH_64", "�sszes let�lt�s kateg�ria");
define("LAN_SEARCH_65", "Let�lt�sek");
define("LAN_SEARCH_66", "Hozz�ad�s d�tuma");
define("LAN_SEARCH_67", "Minden let�lt�s adat");
define("LAN_SEARCH_68", "D�tum");
define("LAN_SEARCH_69", "Fontoss�g");

define("LAN_SEARCH_70", "Hozz�sz�l�s a let�lt�shez");
define("LAN_SEARCH_71", "V�lasz a h�rekhez");
define("LAN_SEARCH_72", "Al��r�s");
define("LAN_SEARCH_73", "Nincs al��r�s.");
define("LAN_SEARCH_74", "Regisztr�lt");

define("LAN_SEARCH_75", "Keres�s t�pusa");
define("LAN_SEARCH_76", "�zenet az oldalon");
define("LAN_SEARCH_77", "�zenet a profil oldalon");

// Following formerly LAN_nnn - renamed to avoid clashes
define("LAN_SEARCH_98", "H�rek");
define("LAN_SEARCH_99", "Hozz�sz�l�sok");
//define("LAN_SEARCH_200", "Kateg�ri�k:");						// Redundant LAN?
define("LAN_SEARCH_201", "Hat�rozd meg �jra a keres�s felt�tel�t");

?>
