<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.3 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("ONLINE_EL1", "vend�g: ");
define("ONLINE_EL2", "tag: ");
define("ONLINE_EL3", "Ezen az oldalon: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Tagok");
define("ONLINE_EL6", "Leg�jabb tag");
define("ONLINE_EL7", "olvassa");

define("ONLINE_EL8", "legt�bb ");
define("ONLINE_EL9", "-");

define("ONLINE_TRACKING_MESSAGE", "Online felhaszn�l�k k�vet�se jelenleg kikapcsolva, ezt enged�lyezheted [link=".e_ADMIN."users.php?options]itt[/link][br]");

?>
