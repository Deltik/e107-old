<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CONT_SCH_LAN_1", "Tartalom");
define("CONT_SCH_LAN_2", "�sszes Tartalom Kateg�ria");
define("CONT_SCH_LAN_3", "�zenetek az adott r�szben");
define("CONT_SCH_LAN_4", "-");
?>
