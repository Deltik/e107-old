<?php
# --------------------------------------------------------------------------
# e107 Hungarian language file - $Version: 1.14 $ - $Author: e107hungary.org team $ - $Date: 2008 $
# --------------------------------------------------------------------------

define("ADSTAT_ON", "Be");
define("ADSTAT_OFF", "Ki");
define("ADSTAT_L1", "A plugin minden l�togat�st napl�zni fog, �s r�szletes statisztik�kat ad az �sszegy�jt�tt inform�ci�k alapj�n.");
define("ADSTAT_L2", "A statisztika napl�z� telep�tve. Az aktiv�l�shoz l�pj a be�ll�t�sokhoz �s kattints az Aktiv�l�s-ra.<br /><b>Az e107_plugins/log/logs mappa jogosults�ga 777 legyen! (chmod 777)</b>");
define("ADSTAT_L3", "Statisztika napl�z�s");
define("ADSTAT_L4", "Statisztika napl�z�s aktiv�l�sa");
define("ADSTAT_L5", "Statisztika t�pusok");
define("ADSTAT_L6", "B�ng�sz�k");
define("ADSTAT_L7", "Oper�ci�s rendszerek");
define("ADSTAT_L8", "Felbont�s / sz�nm�lys�g");
define("ADSTAT_L9", "L�togat� orsz�g / domain");
define("ADSTAT_L10", "Utal�sok");
define("ADSTAT_L11", "Keres�szavak");
define("ADSTAT_L12", "Statisztik�k t�rl�se");
define("ADSTAT_L13", "Minden statisztika t�rl�dni fog!");
define("ADSTAT_L14", "Oldal sz�ml�l�k");
define("ADSTAT_L15", "Statisztika be�ll�t�sok friss�t�se");
define("ADSTAT_L16", "Statisztika be�ll�t�sok");
define("ADSTAT_L17", "Statisztika be�ll�t�sok friss�tve");
define("ADSTAT_L18", "A statisztika oldalt el�rhetik ...");
define("ADSTAT_L19", "El�z� l�togat�k");
define("ADSTAT_L20", "Admin l�togat�sok sz�ml�l�sa");
define("ADSTAT_L21", "A statisztika oldalon megjelen�tett t�telek maxim�lis sz�ma");
define("ADSTAT_L22", "Friss�t�s futtat�sa");
define("ADSTAT_L23", "El�z� verzi� statisztikai log-ot tal�lt, friss�tsd �ket.");
define("ADSTAT_L24", "L�pj a friss�t�s oldalra");
define("ADSTAT_L25", "Kiv�lasztott statisztika null�z�sa");
define("ADSTAT_L26", "Megl�v� oldal t�rl�se");
define("ADSTAT_L27", "Ha a statisztika t�ves oldalt tartalmaz, itt t�r�lheted azt.");
define("ADSTAT_L28", "Oldal megnyit�sa");
define("ADSTAT_L29", "Oldal neve");
define("ADSTAT_L30", "Jel�ld be a t�rl�shez");
define("ADSTAT_L31", "Kiv�lasztott oldal t�rl�se");
define("ADSTAT_L32", "Oldal rendez�se");
define("ADSTAT_L33", "Statisztika Loggol�sa - Be�ll�t�s");
define("ADSTAT_L34", "Oldal statisztika");


define('ADSTAT_L38', "Az e107_plugins/log/logs mapp�nak �rhat�nak kell lennie");	// Constant compatible with 0.8


?>
