// DA_DK lang variables

tinyMCE.addToLang('',{
iespell_desc : 'K&oslash;r stave kontrol';
iespell_download : "ieSpell ikke fundet. Klik OK for at g&aring; til download siden.";
});