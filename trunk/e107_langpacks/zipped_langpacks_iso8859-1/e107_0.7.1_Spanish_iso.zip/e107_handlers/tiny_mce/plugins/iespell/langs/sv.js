/*
+ ----------------------------------------------------------------------------+
|     Swedish (SE) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/iespell/langs/sv.js,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/17 14:44:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
iespell_desc : 'K&ouml;r stavningskontroll',
iespell_download : "ieSpell hittades inte. Klicka OK f&ouml;r att g&aring; till nerladdningssidan."
});

