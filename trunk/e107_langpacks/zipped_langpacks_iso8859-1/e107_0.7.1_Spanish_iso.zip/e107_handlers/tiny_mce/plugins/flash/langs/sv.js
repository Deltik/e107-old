/*
+ ----------------------------------------------------------------------------+
|     Swedish (SE) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/flash/langs/sv.js,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/17 14:44:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('flash',{
title : 'Infoga / redigera Flash film',
desc : 'Infoga / redigera Flash film',
file : 'Flash-fil (.swf)',
size : 'Storlek',
list : 'Flash filer',
props : 'Flash attribut',
general : 'Generelllt'
});
