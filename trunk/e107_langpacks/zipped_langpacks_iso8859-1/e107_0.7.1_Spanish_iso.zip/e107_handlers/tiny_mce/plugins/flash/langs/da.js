// DA_DK lang variables

tinyMCE.addToLang('flash',{
title : 'Ins&aelig;t/rediger Flash Film',
desc : 'Ins&aelig;t/rediger Flash Film',
file : 'Flash-Fil (.swf)',
size : 'St&oslash;rrelse',
list : 'Flash filer',
props : 'Flash egenskaber',
general : 'Generelt'
});