/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/emoticons/langs/es.js,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

tinyMCELang['lang_insert_emotions_title'] = 'Inserta emoticono';
tinyMCELang['lang_emotions_desc'] = 'Emoticonos';

