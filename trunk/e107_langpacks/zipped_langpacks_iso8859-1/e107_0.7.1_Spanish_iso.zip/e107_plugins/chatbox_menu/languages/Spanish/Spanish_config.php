<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/chatbox_menu/languages/Spanish/Spanish_config.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/06 12:45:13 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Par�metros de chatbox actualizados.");
define("CHBLAN_2", "Moderado.");
define("CHBLAN_3", "Sin mensajes de chatbox.");
define("CHBLAN_4", "Miembro");
define("CHBLAN_5", "Invitado");
define("CHBLAN_6", "Desbloquear");
define("CHBLAN_7", "Bloquear");
define("CHBLAN_8", "Eliminar");
define("CHBLAN_9", "Moderar chatbox");
define("CHBLAN_10", "Moderar mensajes");
define("CHBLAN_11", "Mensajes de chatbox a mostrar");
define("CHBLAN_12", "cantidad de mensajes mostrados en chatbox");
define("CHBLAN_13", "Reemplazar enlaces");
define("CHBLAN_14", "Si activa, los enlaces de los mensajes ser�n cambiados por lo que ponga en el texto");
define("CHBLAN_15", "Reemplazar cadena si est� activado");
define("CHBLAN_16", "Los enlaces ser�n reemplazados por esta cadena");
define("CHBLAN_17", "Contador de palabras ocultas");
define("CHBLAN_18", "Palabras mas largas del numero definido ser�n ocultadas");
define("CHBLAN_19", "Actualizar par�metros del chatbox");
define("CHBLAN_20", "Par�metros chatbox");
define("CHBLAN_21", "Purga");
define("CHBLAN_22", "Borrar mensajes m�s viejos de cierta fecha");
define("CHBLAN_23", "Borra mensajes m�s antiguos de ");
define("CHBLAN_24", "Un d�a");
define("CHBLAN_25", "Una semana");
define("CHBLAN_26", "Un mes");
define("CHBLAN_27", "- borrar todos los mensajes -");
define("CHBLAN_28", "Chatbox purga.");
define("CHBLAN_29", "Mostrar chatbox dentro de un scroll");
define("CHBLAN_30", "Alto del scroll");
define("CHBLAN_31", "Mostrar emoticonos");
define("CHBLAN_32", "Clase de usuario del moderador");
define("CHBLAN_33", "Contador de usuarios recalculado"); 
define("CHBLAN_34", "Recalcular envios de usuario"); 
define("CHBLAN_35", "Recalcular");
define("CHBLAN_36", "Mostrar opciones Chaybox");
define("CHBLAN_37", "Chatbox Normal");
define("CHBLAN_38", "Use c�digo javascript para actualizar los env�os din�micamente (AJAX)");
?>