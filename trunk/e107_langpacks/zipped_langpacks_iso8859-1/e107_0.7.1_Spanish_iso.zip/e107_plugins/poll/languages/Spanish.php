<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/poll/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("POLL_ADLAN01", "Encuesta");
define("POLL_ADLAN02", "El plugin encuesta permite definir encuestas en forma de men� o en env�os de foro.");
define("POLL_ADLAN03", "Configure las encuestas");
define("POLL_ADLAN04", "El plugin encuestas se instal� correctamente. Para a�adir encuestas, click en el icono de encuestas en el menu del Administrador->secci�n plugins, y recuerde de activar el bloque men� en la secci�n men�s.");

define("POLLAN_MENU_CAPTION", "Poll");
define("POLL_1", "Votos: ");
define("POLL_2", "Comentarios");
define("POLL_3", "Encuestas antiguas");
define("POLL_4", "Votar");
define("POLL_5", "Encuesta");
define("POLL_6", "Sin Votos");
define("POLL_7", "1 voto");
define("POLL_8", " Votos");
define("POLL_9", "Moderador");
define("POLL_10", "Borrar solo encuesta");
define("POLL_11", "Encuesta actualizada.");
define("POLL_12", "Enviada por: ");
define("POLLAN_13", "Despu�s de votar");
define("POLLAN_14", "Pulsando en el enlace de resultados - Los comentarios deben estar activos para usar esta opci�n");
define("POLLAN_15", "Permitir votar en esta encuesta");
define("POLLAN_16", "M�todo de almacenamiento del voto");
define("POLLAN_17", "Cookie");
define("POLLAN_18", "Direcci�n IP");
define("POLLAN_19", "UserID (solo miembros pueden votar)");
define("POLLAN_20", "�Permitir comentarios en esta encuesta?");
define("POLLAN_21", "Previsualizar de nuevo");
define("POLLAN_22", "Actualizar encuesta");
define("POLLAN_23", "Crear encuesta");
define("POLLAN_24", "Previsualizar");
define("POLLAN_25", "Limpiar formulario");
define("POLLAN_26", "Votos");
define("POLLAN_27", "Comentarios");
define("POLLAN_28", "Encuestas antiguas");
define("POLLAN_29", "Enviado por");
define("POLLAN_30", "Enviar");
define("POLLAN_31", "Votos");
define("POLLAN_32", "Click aqu� para ver resultados");
define("POLLAN_33", "No hay encuestas antiguas.");
define("POLLAN_34", "T�tulo");
define("POLLAN_35", "Enviado por");
define("POLLAN_36", "Activa");
define("POLLAN_37", "Activa desde");
define("POLLAN_38", "Hasta");
define("POLLAN_39", "�Gracias por su voto!");
define("POLLAN_40", "Click aqu� para ver los resultados");
define("POLLAN_41", "Esta encuesta est� restringida solo a los miembros");
define("POLLAN_42", "Esta encuesta est� restringida solo a los Admins");
define("POLLAN_43", "No tiene permisos para votar en esta encuenta");
define("POLLAN_44", "�Eliminar esta encuesta?");
define("POLLAN_45", "Encuesta actualizada con �xito");


?>