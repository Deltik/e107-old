<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/comment_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CM_L1", "No hay comentarios a�n.");
define("CM_L2", "");
define("CM_L3", "T�tulo");
define("CM_L4", "�N�mero de comentarios a mostrar?");
define("CM_L5", "�N�mero de caracteres a mostrar?");
define("CM_L6", "�Cortar comentarios demasiado largos?");
define("CM_L7", "�Mostrar t�tulo original?");
define("CM_L8", "Configuraci�n");
define("CM_L9", "Actualizar configuraci�n");
define("CM_L10", "Configuraci�n guardada");
?>