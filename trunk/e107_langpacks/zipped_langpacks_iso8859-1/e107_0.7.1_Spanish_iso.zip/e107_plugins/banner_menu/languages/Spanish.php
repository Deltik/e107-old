<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/banner_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Publicidad");
define("BANNER_MENU_L2", "Configuraci�n del men� anuncio guardada");
//v.617
define("BANNER_MENU_L3", "T�tulo");
define("BANNER_MENU_L4", "Campa�a");
define("BANNER_MENU_L5", "Configuraci�n del men� del Anuncio");
define("BANNER_MENU_L6", "Seleccionar campa�as para mostrar en el men�");
define("BANNER_MENU_L7", "Campa�as disponibles");
define("BANNER_MENU_L8", "Campa�as seleccionadas");
define("BANNER_MENU_L9", "Eliminar selecci�n");
define("BANNER_MENU_L10", "�Como deben ser mostradas las campa�as seleccionadas?");
define("BANNER_MENU_L11", "Escoja tipo de renderizado ...");
define("BANNER_MENU_L12", "Una campa�a en un solo men�");
define("BANNER_MENU_L13", "Todas las campa�as en un solo men�");
define("BANNER_MENU_L14", "Todas las campa�as en men�s separados");
define("BANNER_MENU_L15", "�Cuantos anuncios deben mostrarse?");
define("BANNER_MENU_L16", "Este par�metro solo debe ser usado con las opciones 2 y 3.<br />Si hay menos anuncios se usar� la mayor cantidad disponible.");
define("BANNER_MENU_L17", "Ponga cantidad ...");
define("BANNER_MENU_L18", "Actualizar par�metros de men�");

?>