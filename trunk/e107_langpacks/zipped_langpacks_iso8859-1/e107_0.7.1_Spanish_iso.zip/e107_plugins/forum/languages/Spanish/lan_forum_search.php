<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/forum/languages/Spanish/lan_forum_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Foro");
define("FOR_SCH_LAN_2", "Seleccionar foro");
define("FOR_SCH_LAN_3", "Todos los foros");
define("FOR_SCH_LAN_4", "Todo el mensaje");
define("FOR_SCH_LAN_5", "Como parte de un tema");
?>