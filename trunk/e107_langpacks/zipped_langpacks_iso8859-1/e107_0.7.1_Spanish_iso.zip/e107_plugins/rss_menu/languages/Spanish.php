<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/rss_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " pueden ser sindicalizadas usando RSS.");
define("BACKEND_MENU_L2", "RSS Feeds");
define("BACKEND_MENU_L3", "Nuestras noticias");
define("BACKEND_MENU_L4", "Nuestros comentarios");
define("BACKEND_MENU_L5", "Nuestros temas de foros");
define("BACKEND_MENU_L6", "Nuestros env�os al foro");
define("BACKEND_MENU_L7", "Nuestros mensajes de chat");
define("BACKEND_MENU_L8", "Nuestros informes de bugs");
define("BACKEND_MENU_L9", "Nuestras descargas");

define("RSS_LAN01", "�Activar Feeds separados para cada categor�a de noticias?");
define("RSS_LAN02", "�Activar Feeds separados para cada categor�a de descargas?");

define("RSS_NEWS","Noticias"); 
define("RSS_COM","Comentarios"); 
define("RSS_ART","Art�culos"); 
define("RSS_REV", "An�alisis"); 
define("RSS_FT","Temas del foro"); 
define("RSS_FP","Env�os del foro"); 
define("RSS_FSP","Env�o fijo del foro"); 
define("RSS_BUG","Bugtracker"); 
define("RSS_FOR","Foro"); 
define("RSS_DL","Descargas"); 

?>