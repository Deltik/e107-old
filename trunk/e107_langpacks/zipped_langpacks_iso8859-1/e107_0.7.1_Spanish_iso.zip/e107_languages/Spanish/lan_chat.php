<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_chat.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Chatbox");
define("LAN_11", "Chatbox (Todos)");
define("LAN_12", "Env�os al Chat");
define("LAN_13", "el");
define("LAN_14", "Error!");
define("LAN_15", "Lo sentimos, no tiene permisos para ver esta p�gina.");
define("LAN_16", "[ este mensaje ha sido bloqueado por el administrador ]");
?>