<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/links.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Introduzca todos los enlaces de su sitio aqu�.
Los enlaces se mostrar�n en el men� principal de navegaci�n.
Para los dem�s enlaces utilice la p�gina de enlaces del plugin
<br />
";
$ns -> tablerender("Ayuda Enlaces", $text);
?>