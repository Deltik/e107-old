<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_mailout.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "Guardar cambios");

define("PRFLAN_63", "Enviar correo de prueba");
define("PRFLAN_64", "Pulsando el bot�n enviar� un correo de prueba al administrador principal");
define("PRFLAN_65", "Click para enviar correo a");
define("PRFLAN_66", "Correo de prueba de");
define("PRFLAN_67", "�Este es un correo de prueba, parece que su configuraci�n de correo funciona bien!\n\nSaludos\ndesde e107.");
define("PRFLAN_68", "El correo no pudo enviarse. Parece que tu servidor no esta correctamente configurado y no puede enviar correos, pruebe otra vez usando SMTP, o contacte a su Host para comprobar la configuraci�n del envio de correo.");
define("PRFLAN_69", "El correo se envi� correctamente, compruebe su bandeja de entrada.");
define("PRFLAN_70", "M�todo de env�os");
define("PRFLAN_71", "Si no est� seguro, d�jelo en php");
define("PRFLAN_72", "SMTP Servidor");
define("PRFLAN_73", "SMTP Usuario");
define("PRFLAN_74", "SMTP Contrase�a");
define("PRFLAN_75", "El correo no se pudo enviar. Compruebe su configuraci�n SMTP, o desactive SMTP y pruebe de nuevo.");

define("MAILAN_01","De (Nombre)");
define("MAILAN_02","De (email)");
define("MAILAN_03","A");
define("MAILAN_04","Cc");
define("MAILAN_05","Bcc");
define("MAILAN_06","Asunto");
define("MAILAN_07","Adjunto");
define("MAILAN_08","Enviar email");
define("MAILAN_09","Usar estilo del tema");
define("MAILAN_10","Usuario suscrito");
define("MAILAN_11","Insertar variables");
define("MAILAN_12","Todos los miembros");
define("MAILAN_13","Todos los miembros sin verificar ");
define("MAILAN_14","Es recomendable que active SMTP para enviar un gran n�mero de correos. Aj�stelo en las preferencias de debajo");
define("MAILAN_15","Salidas correo");
define("MAILAN_16","Usuario");
define("MAILAN_17","Enlace de registro");
define("MAILAN_18","ID Usuario");
define("MAILAN_19","No hay una direcci�n email para el admin del sitio. Compruebe su perfil y pruebe de nuevo.");
define("MAILAN_20","Ruta Sendmail");
define("MAILAN_21","Entradas de mail masivo"); 
define("MAILAN_22","Actualmente no hay entradas guardadas");
define("MAILAN_23","Clase de usuario: ");
define("MAILAN_24", "Email(s) listo(s) para ser enviado(s)");
?>