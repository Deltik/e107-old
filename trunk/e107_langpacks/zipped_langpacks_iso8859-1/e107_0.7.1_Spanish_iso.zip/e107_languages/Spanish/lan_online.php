<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_online.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
//v.616
define("ONLINE_EL1", "Visitas: ");
define("ONLINE_EL2", "Miembros: ");
define("ONLINE_EL3", "En esta p�gina: ");
define("ONLINE_EL4", "En linea");
define("ONLINE_EL5", "Miembros");
define("ONLINE_EL6", "Nuevo miembro");
define("ONLINE_EL7", "viendo");
define("ONLINE_EL8", "M�ximo en linea: ");
define("ONLINE_EL9", "el");
define("ONLINE_EL10", "Nombre");
define("ONLINE_EL11", "Viendo p�gina");
define("ONLINE_EL12", "Respondiendo a");
define("ONLINE_EL13", "Foro");
define("ONLINE_EL14", "Tema");
define("ONLINE_EL15", "P�gina");
define("CLASSRESTRICTED", "P�gina restringida");
define("ARTICLEPAGE", "Art�culo/Revisi�n");
define("CHAT", "Chat");
define("COMMENT", "Comentarios");
define("DOWNLOAD", "Descargas");
define("EMAIL", "email.php");
define("FORUM", "Foro Principal");
define("LINKS", "Enlaces");
define("NEWS", "Noticias");
define("OLDPOLLS", "Encuestas antiguas");
define("POLLCOMMENT", "Encuesta");
define("PRINTPAGE", "Imprimir");
define("LOGIN", "Entrando en");
define("SEARCH", "Buscando");
define("STATS", "Estad�sticas");
define("SUBMITNEWS", "Enviar Noticia");
define("UPLOAD", "Transferencias");
define("USERPAGE", "Perfiles de usuario");
define("USERSETTINGS", "Configuraciones de usuario");
define("ONLINE", "Usuarios en linea");
define("LISTNEW", "Lista de novedades");
define("USERPOSTS", "Mensajes de usuario");
define("SUBCONTENT", "Enviar Art�culo/Revisi�n");
define("TOP", "Top Usuarios/Temas m�s activos");
define("ADMINAREA", "�rea de Admin.");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Lista de eventos");
define("CALENDAR", "Calendario de eventos");
define("FAQ", "Faq");
define("PM", "Mensajer�a privada");
define("SURVEY", "Survey");
define("ARTICLE", "Art�culo");
define("CONTENT", "P�gina de contenido");
define("REVIEW", "Revisi�n");

?>