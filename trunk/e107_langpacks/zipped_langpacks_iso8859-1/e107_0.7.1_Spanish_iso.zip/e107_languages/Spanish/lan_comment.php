<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_comment.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Comentarios");
define("LAN_0", "[bloqueado por el administrador]");
define("LAN_1", "Desbloquear");
define("LAN_2", "Bloquear");
define("LAN_3", "Borrar");
define("LAN_4", "Informaci�n");
define("LAN_5", "Comentarios ...");
define("LAN_6", "Debe iniciar la sesi�n en este sitio como usuario registrado para poder dejar sus comentarios - Si no es un usuario registrado pulse  <a href='".e_BASE."signup.php'>aqu�</a> para realizar el registro");
define("LAN_7", "Administrador del sitio");
define("LAN_8", "Comentario");
define("LAN_9", "Enviar comentario");
define("LAN_10", "Administrador");
define("LAN_11", "<b>Error!</b> No ha sido posible incluir su comentario en nuestra base de datos - por favor vuelva a escribir su comentario evitando utilizar car�cteres no est�ndar.");

define("LAN_16", "Usuario: ");

define("LAN_99", "Comentarios");
define("LAN_100", "Noticias");
define("LAN_101", "Encuesta");
define("LAN_102", "Respondido a: ");
define("LAN_103", "Art�culo");
define("LAN_104", "Revisi�n");
define("LAN_105", "Contenido");

define("LAN_145", "Registrado: ");

define("LAN_194", "Invitado");
define("LAN_195", "Miembro");

define("LAN_310", "No se pudo aceptar el env�o, ese nombre de usuario est� registrado - si es su nombre de usuario por favor inicie sesi�n para identificarse.");

define("LAN_312", "Env�o duplicado - no se pudo aceptar.");
define("LAN_313", "Localizaci�n");
define("LAN_314", "Moderar comentarios");
define("LAN_315", "Trackbacks");
define("LAN_316", "Sin trackbacks para este nuevo env�o.");
define("LAN_317", "Moderar trackbacks");
define("LAN_318", "Editar comentario");
define("LAN_319", "Editado");
define("LAN_320", "Actualizar comentario");

define("COMLAN_1", "Aqu�");
define("COMLAN_2", "para registrarse");
define("COMLAN_3", "�Error!");
define("COMLAN_4", "Tema");
define("COMLAN_5", "Re:");
define("COMLAN_6", "Responderle");
define("COMLAN_7", 'Valoraci�n');
define("COMLAN_8", 'Comentarios bloqueados');

?>