<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Email");
define("LAN_5", "Enviar art�culo a un amigo");
define("LAN_6", "Enviar noticia a un amigo");
define("LAN_7", "Nombre : ");
define("LAN_8", "Comentario");
define("LAN_9", "Lo sentimos - no se pudo enviar el email");
define("LAN_10", "Email enviado a");
define("LAN_11", "Email enviado");
define("LAN_12", "Error");

define("LAN_106", "Esta no parece una direcci�n de email v�lida");

define("LAN_185", "Enviar art�culo");
define("LAN_186", "Enviar noticia");
define("LAN_187", "Email del destinatario");
define("LAN_188", "Espero que le guste esta noticia de");
define("LAN_189", "Espero que le guste este art�culo de");

define("LAN_email_1", "Desde:");
define("LAN_email_2", "Direcci�n IP del remitente:");
define("LAN_email_3", "Noticia desde ");
define("LAN_email_4", "Enviar email");
define("LAN_email_5", "Email a un amigo");
define("LAN_email_6", "Creo que estar�a interesado de este email de ");
?>