<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'SP');
define("CORE_LC", 'es');
define("CORE_LC2", 'es');
define("CHARSET", "iso-8859-1");
define("CORE_LAN1","Error : tema no encontrado.\\n\\nCambie el tema usado en preferencias (administraci�n) o copie los archivos del tema seleccionado al servidor.");
define("CORE_LAN2"," \\1 escribi�:");// "\\1" representa el nombre de usuario.
define("CORE_LAN3","archivo adjunto desactivado");
?>