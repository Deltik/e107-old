<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "e107 Credits");

define("CRELAN_1", "Credit-ek");
define("CRELAN_2", "A lenti lista az e107-ben haszn�lt third-party (k�ls�) scripteket tartalmazza. Az e107 fejleszt�csapata szeretne szem�lyes k�sz�netet mondani e scriptek �r�inak a k�dok e107-tel t�rt�n� haszn�lat�nak, terjeszt�s�nek enged�lyez�s��rt, �s script-jeik GPL licensz-el t�rt�n� terjeszt�s��rt.");
define("CRELAN_3", "all rights reserved");
define("CRELAN_4", "Show e107 Dev Team");
define("CRELAN_5", "K�ls� scriptek bemutat�sa");
define("CRELAN_6", "e107 v0.7 l�trehozta neked ...");
define("CRELAN_7", "verzi�");
define("CRELAN_8", "enged�lyez�s");
define("CRELAN_9", "Licensz");

// third party scripts

define("CRELAN_10", "MagpieRSS egy XML-b�zis� (expat) RSS elemz�st biztos�t PHP-ban.");
define("CRELAN_11", "PclZip k�nyvt�r biztos�tja a zip arch�vumok t�m�r�t�si �s kicsomagol�si funkci�j�t (WinZip, PKZIP).");
define("CRELAN_12", "PclTar lehet�s�get biztos�t a file-k vagy k�nyvt�rak arch�v�l�s�ra t�m�r�t�ssel vagy t�m�r�t�s n�lk�l. A PclTar-val k�sz�lt arch�vumok olvashat�ak a legt�bb gzip/tar alkalmaz�ssal �s a Windows WinZip programmal.");
define("CRELAN_13", "TinyMCE egy alap, f�ggetlen, webb�zis� Javascript HTML WYSIWYG szerkeszt�, mely az Open Source under LGPL by Moxiecode Systems AB ellen�rz�se alatt �ll. K�pes �tkonvert�lni a HTML sz�vegmez�ket vagy m�s HTML elemeket a szerkeszt� k�r�s�nek megfelel�en.");
define("CRELAN_14", "Az e107-ben alkalmazott ikonok");
define("CRELAN_15", "Minden tulajdons�ggal felruh�zott email k�ld� csoport a PHP sz�m�ra");
define("CRELAN_16", "A Jayya theme-ben alkalmazott men�rendszer");
define("CRELAN_17", "Felugr� seg�dnapt�r");
define("CRELAN_18", "PDF t�mogat�s");
define("CRELAN_19", "UTF-8 PDF t�mogat�s");

// end third party scripts

// dev team

define("CRELAN_20", ""); // asperon
define("CRELAN_21", "Mindig egy s�rg�s..err..s�rg�s!"); // CaMer0n
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\""); // jalist
define("CRELAN_23", ""); // lisa
define("CRELAN_24", ""); // McFly
define("CRELAN_25", ""); // que
define("CRELAN_26", ""); // streaky
define("CRELAN_27", "\"Tud? Nincs tea?? 0_0\""); // SweetAs
define("CRELAN_28", ""); // MrPete

// end dev team
?>
