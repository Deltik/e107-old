<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("MDCLAN_1", "Moder�lva");
define("MDCLAN_2", "Nincsen hozz�sz�l�s");
define("MDCLAN_3", "Tag");
define("MDCLAN_4", "Vend�g");
define("MDCLAN_5", "Enged�lyez�s");
define("MDCLAN_6", "Tilt�s");

define("MDCLAN_8", "Hozz�sz�l�sok moder�l�sa");
define("MDCLAN_9", "Figyelem! Sz�l� hozz�sz�l�s t�rl�se eset�n az �sszes v�lasz is t�rl�dik!");

define("MDCLAN_10", "be�ll�t�sok");
define("MDCLAN_11", "hozz�sz�l�s");
define("MDCLAN_12", "hozz�sz�l�s");
define("MDCLAN_13", "kikapcsolva");
define("MDCLAN_14", "hozz�sz�l�sok kikapcsol�sa");
define("MDCLAN_15", "enged�lyez�s");
define("MDCLAN_16", "lez�rva");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");
?>