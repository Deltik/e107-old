<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.11 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FC_LAN_1", "File Ellen�r");
define("FC_LAN_2", "Vizsg�lat be�ll�t�sok");
define("FC_LAN_3", "Mutat");
define("FC_LAN_4", "�sszes File");
define("FC_LAN_5", "Mag (Core) File-k");
define("FC_LAN_6", "Mag (Core) File-k (Integrit�s hib�s)");
define("FC_LAN_7", "Nem mag (Core) File-k");
define("FC_LAN_8", "A Mag (Core) File-k integrit�s�nak ellen�rz�se");
define("FC_LAN_9", "Be");
define("FC_LAN_10", "Ki");
define("FC_LAN_11", "Vizsg�lat Most");
define("FC_LAN_12", "Nincs");
define("FC_LAN_13", "Hi�nyz� Core File-k");
define("FC_LAN_14", "Eredm�ny megjelen�t�se");
define("FC_LAN_15", "K�nyvt�r strukt�ra");
define("FC_LAN_16", "Lista");
define("FC_LAN_17", "Felt�tel �sszevet�se");
define("FC_LAN_18", "Pontos kifejez�s");
define("FC_LAN_19", "�gak sz�m�nak mutat�sa");
define("FC_LAN_20", "Tal�lt �gak mutat�sa");
define("FC_LAN_21", "R�gi Core (Mag) File-k");

define("FR_LAN_1", "Vizsg�lat...");
define("FR_LAN_2", "Eredm�ny");
define("FR_LAN_3", "�ttekint�s");
define("FR_LAN_4", "Mag (Core) file-k");
define("FR_LAN_5", "Nem Mag (Core) file-k");
define("FR_LAN_6", "�sszes file");
define("FR_LAN_7", "Integrit�s ellen�rz�s");
define("FR_LAN_8", "Mag (Core) file-k ellen�rizve");
define("FR_LAN_9", "Mag (Core) file-k hib�sak");
define("FR_LAN_10", "Elk�pzelhet�, hogy a file-k hib�sak");
define("FR_LAN_11", "A file s�r�lt");
define("FR_LAN_12", "Ez betudhat� a hib�s zip file-nek, hiba j�hetett l�tre a kicsomagol�s
folyam�n vagy az FTP felt�lt�s sor�n. Pr�b�ld meg �jra felt�lteni a hib�s file-t a szerverre
�s futtasd �jra a File Ellen�rt, hogy megn�zd megsz�nt-e a hiba.");
define("FR_LAN_13", "A file m�r r�gi");
define("FR_LAN_14", "Ha a file egy r�gebbi e107 verzi�b�l val� �s szerepel a file-k k�z�tt, akkor
a frissebb e107 fut�sakor hib�t jelezhet az integrit�s ellen�rz�sekor. Term�szetesen, t�ltsd fel a file �jabb verzi�j�t.");
define("FR_LAN_15", "A file m�dos�tva lett");
define("FR_LAN_16", "Ha m�dos�tottad ezt a file-t b�rhol, akkor az integrit�s ellen�rz�s nem lesz sikeres. Ha
sz�nd�kosan m�dos�tottad ezt a file-t, nem kell idegeskedned �s ne vedd figyelembe ezt az integrit�s ellen�rz�si hib�t. Azonban, ha
a file-t valaki m�s m�dos�totta az enged�lyed n�lk�l, akkor t�lts fel �jra a helyes file verzi�t
ehhez a file-hez.");
define("FR_LAN_17", "Ha CVS felhaszn�l� vagy");
define("FR_LAN_18", "Ha futtatod az ellen�rz�st �s CVS verzi�t haszn�lsz a stabil hivatalos e107 kiad�s
helyett, akkor tapasztalhatod, hogy sok file integrit�s ellen�rz�se hib�s lehet, ami abb�l ad�dik, hogy az utols� CVS ment�s �ta m�r
m�dos�totta a fejleszt� csapat az adott file-t.");
define("FR_LAN_19", "file-k hib�sak");
define("FR_LAN_20", "�sszes file ellen�rizve");
define("FR_LAN_21", "nincs");
define("FR_LAN_22", "Hi�nyz� core file-k");
define("FR_LAN_23", "Nincs tal�lat.");
define("FR_LAN_24", "R�gi core (Mag) file-k");
define("FR_LAN_25", "Integrit�s nem kisz�m�that�");

define("FR_LAN_26", "Figyelmeztet�s! Ismert biztons�gi r�s felismerve!");
define("FR_LAN_27", "Ezek a file-k, melyek ismertek, vissza�l�sre adhatnak lehet�s�get �s azonnal t�r�lni kell.");
define("FR_LAN_28", "Ismert vesz�lyes file-k");

?>
