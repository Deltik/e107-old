<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FOOTLAN_1", "Weboldal");
define("FOOTLAN_2", "F� admin");
define("FOOTLAN_3", "Verzi�");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Theme");
define("FOOTLAN_6", "-");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Telep�t�s d�tuma");
define("FOOTLAN_9", "Szerver");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "PHP verzi�");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Weboldal Info");
define("FOOTLAN_14", "Dokument�ci� megtekint�se");
define("FOOTLAN_15", "Dokument�ci�");
define("FOOTLAN_16", "Adatb�zis");
define("FOOTLAN_17", "Karakterk�szlet");

?>
