<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.23 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("SEALAN_1", "Keres�s be�ll�t�sa");
define("SEALAN_2", "A keres�s eredm�ny�ben megjelen�tend� karakterek sz�ma:");
define("SEALAN_3", "Keres�s rendez�si m�dja:");
define("SEALAN_6", "Hozz�sz�l�sok");
define("SEALAN_7", "Regisztr�lt tagok");
define("SEALAN_10", "Relevance �rt�k megjelen�t�se:");
define("SEALAN_11", "Felhaszn�l� kiv�laszthatja a keresend� ter�leteket:");
define("SEALAN_12", "Keres�sek k�z�tti id� korl�toz�sa (max 5 perc):");
define("SEALAN_13", "Keres�s enged�lyez�se csak");
define("SEALAN_14", "m�sodpercenk�nt");
define("SEALAN_15", "A Keres�s oldal e felhaszn�l�csoportnak �rhet� el");
define("SEALAN_16", "Be");
define("SEALAN_17", "Ki");
define("SEALAN_18", "Kereshet� hozz�sz�l�s ter�letek (ha a keres�s a hozz�sz�l�sokban aktiv�lt)");
define("SEALAN_19", "A felhaszn�l�k egyid�ben t�bb, mint egy ter�letben kereshetnek:");
define("SEALAN_20", "�ltal�nos be�ll�t�sok");
define("SEALAN_21", "Kereshet� ter�letek");
define("SEALAN_22", "Alap�rtelmezett");
define("SEALAN_23", "Alternat�v:");
define("SEALAN_24", "T�pus");
define("SEALAN_25", "Csoport");
define("SEALAN_26", "Pre-Title Sz�veg");
define("SEALAN_30", "Kulcsszavak kiemel�se a hivatkozott oldalon:");
define("SEALAN_31", "PHP limit");
define("SEALAN_32", "eredm�ny (hagyd �resen, ha nincs limit)");
define("SEALAN_33", "Could not switch to MySql sort method as this requires at least version 4.0.1 of MySql.");
define("SEALAN_34", "Jelenlegi verzi�d");
define("SEALAN_35", "Keresend� ter�let kiv�laszt�si m�dszere:");
define("SEALAN_36", "Leg�rd�l� doboz");
define("SEALAN_37", "Bejel�l� doboz");
define("SEALAN_38", "R�di� gomb");
define("SEALAN_39", "Egy�ni oldalak");

define("LAN_98", "H�rek");
define("LAN_197", "Let�lt�sek");
define("LAN_418", "Egy�ni oldalak");

define("SEALAN_40", "Keres�s be�ll�t�sSearch Options");
define("SEALAN_41", "F�oldal");
define("SEALAN_42", "Be�ll�t�sok");

define("SEALAN_43", "Be�ll�t�sok m�dos�t�sa");
define("SEALAN_44", "El�rhet�s�g");
define("SEALAN_45", "Megjelen� eredm�ny mennyis�g / oldal");
define("SEALAN_46", "Karakterek sz�ma a keres�si eredm�nyben");

define("SEALAN_47", "Eredm�ny, csak teljes szavak:");
define("SEALAN_48", "Ezen be�ll�t�s alkalmaz�sa csak akkor lehets�ges, ha a keres�s rendez�s m�dszere PHP. Ha oldalad k�p�r�s-szer� nyelvet tartalmaz, pl.: K�nai �s Jap�n, akkor ezt ki kell kapcsolnod.");
define("SEALAN_49", "Ha oldalad k�p�r�s-szer� nyelvet tartalmaz, pl.: K�nai �s Jap�n, akkor a PHP rendez�si m�dszert kell alkalmaznod.");

?>
