<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UCSLAN_1", "�sszes felhaszn�l� t�r�lve a csoportb�l");
define("UCSLAN_2", "Csoport friss�tve.");
define("UCSLAN_3", "Csoport t�r�lve");
define("UCSLAN_4", "Csoport t�rl�s�nek meger�s�t�s�hez pip�ld ki a dobozt");
define("UCSLAN_5", "Csoport friss�tve.");
define("UCSLAN_6", "Csoport elmentve");
define("UCSLAN_7", "Nincsenek csoportok");
define("UCSLAN_8", "Megl�v� csoportok");

//define("UCSLAN_9", "M�dos�t�s");
//define("UCSLAN_10", "T�rl�s");
define("UCSLAN_11", "Meger�s�t�s");
define("UCSLAN_12", "Csoport n�v");
define("UCSLAN_13", "Csoport le�r�s");
define("UCSLAN_14", "Csoport friss�t�se");
define("UCSLAN_15", "�j csoport l�trehoz�sa");
define("UCSLAN_16", "Felhaszn�l� besorol�sa a csoportba");
define("UCSLAN_17", "Elt�vol�t�s");
define("UCSLAN_18", "Csoport �r�t�se");
define("UCSLAN_19", "Felhaszn�l�(k) besorol�sa a(z)");
define("UCSLAN_20", "csoportba");
define("UCSLAN_21", "Csoport be�ll�t�sok");

define("UCSLAN_22", "Felhaszn�l�k - klikk a mozgat�shoz");
define("UCSLAN_23", "Felhaszn�l�k a csoportban");

define("UCSLAN_24", "Kik m�dos�thatj�k a csoportot");

?>