<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FRTLAN_1", "Kezd�lap be�ll�t�sai friss�tve");
define("FRTLAN_2", "Megjelen�tend�");
define("FRTLAN_6", "Linkek");
//define("FRTLAN_7", "Tartalom oldal");
define("FRTLAN_12", "Be�ll�t�sok ment�se");
define("FRTLAN_13", "Kezd�lap be�ll�t�sai");
define("FRTLAN_15", "Egy�b (�rd be az url-t):");
define("FRTLAN_16", "hiba: nincs tartalom f�kateg�ria kiv�lasztva");
define("FRTLAN_17", "hiba: nincs tartalom alkateg�ria kiv�lasztva");
define("FRTLAN_18", "hiba: nincs tartalom kiv�lasztva");
define("FRTLAN_19", "tartalom f�kateg�ria");
define("FRTLAN_20", "tartalom alkateg�ria");
define("FRTLAN_21", "tartalom");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Mindenki");
define("FRTLAN_27", "Vend�gek");
define("FRTLAN_28", "Tagok");
define("FRTLAN_29", "Adminok");
define("FRTLAN_31", "Mindenki (publikus)");
define("FRTLAN_32", "Felhaszn�l�i csoport");
define("FRTLAN_33", "�rv�nyes be�ll�t�sok");
define("FRTLAN_34", "Oldal");
?>