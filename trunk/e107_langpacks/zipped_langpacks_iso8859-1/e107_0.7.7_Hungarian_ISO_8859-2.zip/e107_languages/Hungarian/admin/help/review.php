<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/review.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:45 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Le�r�sok s�g�";
$text = "A le�r�sok egy egyszer� r�sze a cikkeknek, de saj�t men�r�szben jelenik meg.<br />
 A t�bboldalas le�r�st a [newpage] k�ddal lehet elv�lasztani, P�ld�ul <br /><code>Test1 [newpage] Test2</code><br /> k�ddal k�toldalas le�r�st hozhatsz l�tre, ahol a 'Test1' az els� oldal �s a 'Test2' a m�sodik oldal.";
$ns -> tablerender("Le�r�sok s�g�", $text);
?>
