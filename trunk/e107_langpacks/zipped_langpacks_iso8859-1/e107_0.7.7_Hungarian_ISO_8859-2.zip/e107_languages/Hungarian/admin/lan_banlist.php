<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("BANLAN_1", "Kitilt�s kikapcsolva.");
define("BANLAN_2", "Nincs kitilt�s.");
define("BANLAN_3", "�rv�nyben l�v� kitilt�sok");
define("BANLAN_4", "Kitilt�s t�rl�se");
define("BANLAN_5", "Add meg az IP c�met, az e-mail c�met vagy a host-ot");
define("BANLAN_7", "Indokl�s");
define("BANLAN_8", "Felhaszn�l� kitilt�sa");
define("BANLAN_9", "Felhaszn�l�k kitilt�sa");
define("BANLAN_10", "IP / E-mail c�m / Indok");
define("BANLAN_11", "Automatikus-Kitilt�s: T�bb, mint 10 hib�s bejelentkez�si kis�rlet");
define("BANLAN_12", "Megjegyz�s: A DNS megv�ltoztat�sa jelenleg letiltva, a host alapj�n t�rt�n� kitilt�shoz enged�lyezni kell. Az IP �s email alapj�n t�rt�n� kitilt�s m�g norm�lisan m�k�dik.");
?>
