<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Rekl�mcs�kok");

define("BANNERLAN_16", "Felhaszn�l�n�v: ");
define("BANNERLAN_17", "Jelsz�: ");
define("BANNERLAN_18", "Folytat�s");
define("BANNERLAN_19", "A folytat�shoz add meg az �gyf�l felhaszn�l�nev�t �s jelszav�t");
define("BANNERLAN_20", "Sajnos ezen adatok nem tal�lhat�ak meg az adatb�zisban. Keresd meg az oldal �zemeltet�j�t a r�szletekkel.");
define("BANNERLAN_21", "Rekl�m statisztik�k");
define("BANNERLAN_22", "�gyf�l");
define("BANNERLAN_23", "ID");
define("BANNERLAN_24", "Kattint�sok");
define("BANNERLAN_25", "Kattint�s %");
define("BANNERLAN_26", "Megjelen�t�sek");
define("BANNERLAN_27", "Megrendelt megjelen�t�s");
define("BANNERLAN_28", "H�tral�v� megjelen�t�s");
define("BANNERLAN_29", "Nincs rekl�mcs�k");
define("BANNERLAN_30", "Korl�tlan");
define("BANNERLAN_31", "Nem alkalmazhat�");
define("BANNERLAN_32", "Igen");
define("BANNERLAN_33", "Nem");
define("BANNERLAN_34", "Befejez�s");
define("BANNERLAN_35", "Kattint�sok IP c�mei");
define("BANNERLAN_36", "Akt�v:");
define("BANNERLAN_37", "Kezd�si id�pont:");
define("BANNERLAN_38", "Hiba");

?>
