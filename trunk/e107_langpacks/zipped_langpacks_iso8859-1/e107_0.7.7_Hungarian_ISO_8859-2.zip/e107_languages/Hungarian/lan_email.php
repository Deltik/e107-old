<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

if (!defined("PAGE_NAME")) {define("PAGE_NAME", "E-mail");}

define("LAN_EMAIL_1", "Felad�:");
define("LAN_EMAIL_2", "K�ld� IP c�me:");
define("LAN_EMAIL_3", "�j �zenet... ");
define("LAN_EMAIL_4", "Email k�ld�se");
define("LAN_EMAIL_5", "Email k�ld�se");
define("LAN_EMAIL_6", "�gy gondoltam �rdekelni fog...");
define("LAN_EMAIL_7", "email valakinek");
define("LAN_EMAIL_8", "�zenet");
define("LAN_EMAIL_9", "Hiba: e-mail k�ld�se sikertelen");
define("LAN_EMAIL_10", "Lev�l c�mzettje");
define("LAN_EMAIL_11", "E-mail elk�ldve");
define("LAN_EMAIL_12", "Hiba");
define("LAN_EMAIL_13", "Cikk k�ld�se");
define("LAN_EMAIL_14", "H�r k�ld�se");
define("LAN_EMAIL_15", "Felhaszn�l�n�v: ");
define("LAN_EMAIL_106", "�rv�nytelen email c�m");
define("LAN_EMAIL_185", "Cikk k�ld�se");
define("LAN_EMAIL_186", "H�r k�ld�se");
define("LAN_EMAIL_187", "C�mzett e-mail c�me");
define("LAN_EMAIL_188", "�gy gondoltam �rdekelni fog ez a h�r...");
define("LAN_EMAIL_189", "�gy gondoltam �rdekelni fog ez a cikk...");
define("LAN_EMAIL_190", "�rd be a l�that� k�dot");


?>
