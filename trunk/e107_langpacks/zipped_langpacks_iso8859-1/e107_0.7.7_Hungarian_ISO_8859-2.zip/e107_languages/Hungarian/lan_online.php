<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

//v.616
define("ONLINE_EL1", "Vend�gek: ");
define("ONLINE_EL2", "Tagok: ");
define("ONLINE_EL3", "Ezen az oldalon: ");
define("ONLINE_EL4", "Jelenleg");
define("ONLINE_EL5", "Tagok");
define("ONLINE_EL6", "�j tagok");
define("ONLINE_EL7", "mutat�sa");
define("ONLINE_EL8", "ebb�l jelenleg ");
define("ONLINE_EL9", "-");
define("ONLINE_EL10", "Felhaszn�l�n�v");
define("ONLINE_EL11", "A lap mutat�sa");
define("ONLINE_EL12", "V�lasz");
define("ONLINE_EL13", "F�rum");
define("ONLINE_EL14", "T�ma");
define("ONLINE_EL15", "Lap");
define("CLASSRESTRICTED", "Ezt az oldalt csak regisztr�lt felhaszn�l�k l�togathatj�k!");
define("ARTICLEPAGE", "Cikk / Le�r�s");
define("CHAT", "Chat");
define("COMMENT", "Hozz�sz�l�sok");
define("DOWNLOAD", "Let�lt�sek");
define("EMAIL", "K�ld�s e-mailben");
define("FORUM", "F�rum f�oldal");
define("LINKS", "Linkek");
define("NEWS", "H�rek");
define("OLDPOLLS", "R�gebbi szavaz�sok");
define("POLLCOMMENT", "Szavaz�s");
define("PRINTPAGE", "Nyomtat�s");
define("LOGIN", "Bejelentkez�s");
define("SEARCH", "Keres�s");
define("STATS", "Weblap statisztika");
define("SUBMITNEWS", "H�rek");
define("UPLOAD", "Felt�lt�sek");
define("USERPAGE", "Profil");
define("USERSETTINGS", "Be�ll�t�sok");
define("ONLINE", "Jelenlegi felhaszn�l�k");
define("LISTNEW", "Lista az �jdons�gokr�l");
define("USERPOSTS", "�zenetek");
define("SUBCONTENT", "Cikk/Le�r�s javaslatok");
define("TOP", "Top �zenetek/Legakt�vabb t�m�k");
define("ADMINAREA", "Adminter�let");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Esem�nyek");
define("CALENDAR", "Esem�nynapt�r");
define("FAQ", "GYIK");
define("PM", "Priv�t �zenetek");
define("SURVEY", "Szavaz�s");
define("ARTICLE", "Cikk");
define("CONTENT", "Tartalom oldal");
define("REVIEW", "Le�r�s");

?>
