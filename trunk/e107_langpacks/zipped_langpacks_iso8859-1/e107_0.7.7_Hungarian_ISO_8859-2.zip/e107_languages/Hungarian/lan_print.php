<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Nyomtat�bar�t v�ltozat");}

define("LAN_PRINT_86", "Kateg�ria:");
define("LAN_PRINT_87", "�rta: ");
define("LAN_PRINT_94", "K�ldte:");
define("LAN_PRINT_135", "H�r: ");
define("LAN_PRINT_303", "Ezen h�r sz�rmaz�si helye: ");
define("LAN_PRINT_304", "C�m: ");
define("LAN_PRINT_305", "Alc�m: ");
define("LAN_PRINT_306", "A cikk sz�rmaz�si helye: ");
define("LAN_PRINT_307", "Oldal nyomtat�sa");

define("LAN_PRINT_1", "Nyomtat�bar�t v�ltozat");

?>
