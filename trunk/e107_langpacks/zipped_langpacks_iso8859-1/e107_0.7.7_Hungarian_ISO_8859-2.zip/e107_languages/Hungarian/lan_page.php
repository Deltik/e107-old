<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/28 23:02:59 $
|     $Author: whoisrich $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Oldal list�z�s kikapcsolva");
define("LAN_PAGE_2", "Nincsennek oldalak");
define("LAN_PAGE_3", "A k�rt oldal nem l�tezik");
define("LAN_PAGE_4", "Oldal �rt�kel�se");
define("LAN_PAGE_5", "�rt�kel�sedet k�sz�nj�k");
define("LAN_PAGE_6", "Nincs jogosults�god az oldal megtekint�s�hez");
define("LAN_PAGE_7", "�rv�nytelen jelsz�");
define("LAN_PAGE_8", "Jelsz�val v�dett oldal");
define("LAN_PAGE_9", "Jelsz�");
define("LAN_PAGE_10", "Mehet");
define("LAN_PAGE_11", "Oldal Lista");
define("LAN_PAGE_12", "�rv�nytelen oldal");

?>
