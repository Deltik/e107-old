<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.7 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "H�rek");


define("LAN_NEWS_1", "H�rek csak meghat�rozott tagoknak");
define("LAN_NEWS_2", "Nincs jogosults�god a h�r elolvas�s�ra");
// define("LAN_NEWS_3", "T�r�ld az install.php-t a szerverr�l");
// define("LAN_NEWS_4", "mivel jelent�s biztons�gi rizik�t jelent az oldalra n�zve");
define("LAN_NEWS_5", "<b>Hiba!</b> A h�r friss�t�se az adatb�zisban nem siker�lt!</b>");
define("LAN_NEWS_6", "A h�r felv�ve az adatb�zisba.");
define("LAN_NEWS_7", "<b>Hiba!</b> A h�r felv�tele az adatb�zisba nem siker�lt!</b>");
define("LAN_NEWS_8", "A h�r felv�ve az adatb�zisba minden nyelvhez. ID: ");
define("LAN_NEWS_9", "Csak c�m be�ll�tva - <b>csak a h�r c�me fog megjelenni</b><br />");
define("LAN_NEWS_10", "A h�r <b>inakt�v</b> (nem fog megjelenni a f�oldalon). ");
define("LAN_NEWS_11", "A h�r <b>akt�v</b> (meg fog jelenni a f�oldalon). ");
define("LAN_NEWS_12", "Hozz�sz�l�sok <b>enged�lyezve</b>. ");
define("LAN_NEWS_13", "Hozz�sz�l�sok <b>tiltva</b>. ");
define("LAN_NEWS_14", "<br />Akt�v id�szak: ");
define("LAN_NEWS_15", "T�rzs hossz: ");
define("LAN_NEWS_16", "b. B�v�tett hossz: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Most");
define("LAN_NEWS_20", "A h�r friss�tve az adatb�zisban a k�vetkez� nyelvhez: ");
define("LAN_NEWS_21", "A h�r friss�tve az adatb�zisban.");
// define("LAN_NEWS_22", "Ugr�s: ");
define("LAN_NEWS_23", "H�rkateg�ri�k");
define("LAN_NEWS_24", "H�r l�trehoz�sa pdf form�tumban");

define("LAN_NEWS_82", "H�rek - Kateg�ria");
define("LAN_NEWS_83", "Nincsenek h�rek - n�zz vissza k�s�bb.");
define("LAN_NEWS_84", "H�rek");
define("LAN_NEWS_99", "Hozz�sz�l�sok");
define("LAN_NEWS_100", "-");
define("LAN_NEWS_307", "H�rek sz�ma a kateg�ri�ban: ");
define("LAN_NEWS_462", "Nincs �j h�r a meghat�rozott h�napban");

?>
