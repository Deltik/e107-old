<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("EQSEC_LAN1", "Egy admin funkci�hoz leszel �tir�ny�tva, m�dosulhat az adatb�zis");
define("EQSEC_LAN2", "Er�s�tsd meg a m�veletet:");
define("EQSEC_LAN3", "Nincs utal�");
define("EQSEC_LAN4", "Honnan:");
define("EQSEC_LAN5", "Hova:");
define("EQSEC_LAN6", "Meger�s�t�s");
define("EQSEC_LAN7", "vagy kil�p�s");
?>