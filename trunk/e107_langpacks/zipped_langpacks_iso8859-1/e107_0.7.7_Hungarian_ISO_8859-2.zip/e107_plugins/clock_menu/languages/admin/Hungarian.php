<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CLOCK_AD_L1","Be�ll�t�s elmentve");
define("CLOCK_AD_L2","C�msor");
define("CLOCK_AD_L3","Be�ll�t�s friss�t�se");
define("CLOCK_AD_L4","Be�ll�t�s");
define("CLOCK_AD_L5","AM/PM");
define("CLOCK_AD_L6","Ha bejel�lt, az id� US form�tumban (12 �r�s, AM/PM) lesz kijelezve. Ha nincs bejel�lve, az id� 'katonai' form�tumban (24 �r�s) lesz kijelezve.");
define("CLOCK_AD_L7","D�tum el�tag");
define("CLOCK_AD_L8","Ha a nyelvedben a d�tum el� egy r�vid sz� kell (p�ld�ul 'le' a franci�ban, vagy 'den' a n�metben...), haszn�ld ezt a mez�t. Ha nem kell, hagyd �resen.");
define("CLOCK_AD_L9","Ut�tag 1");
define("CLOCK_AD_L10","Ut�tag 2");
define("CLOCK_AD_L11","Ut�tag 3");
define("CLOCK_AD_L12","Ut�tag 4 �s t�bb");
define("CLOCK_AD_L13","Ha a nyelvedben a d�tum sz�mai ut�n egy ut�tag kell, t�ltsd ki ezeket a mez�ket csak az ut�tagokkal. (P�lda: 'st' az 1 ut�n, 'nd' a 2 ut�n, 'rd' a 3 ut�n �s 'th' a 4 �s t�bb ut�n az english nyelvben). Ha nem kell, hagyd �resen.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>
