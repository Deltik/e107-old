<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("e_PAGETITLE", "F�rum statisztik�k");

define("FSLAN_1", "�ltal�nos");
define("FSLAN_2", "F�rum megnyitva");
define("FSLAN_3", "M�k�d�si id�");
define("FSLAN_4", "�sszes �zenet");
define("FSLAN_5", "F�rum t�ma");
define("FSLAN_6", "F�rum v�lasz");
define("FSLAN_7", "F�rum t�ma megtekint�s");
define("FSLAN_8", "Adatb�zis m�ret (csak f�rum t�bl�k)");
define("FSLAN_9", "�tlagos sorhossz�s�g a f�rum t�bl�ban");
define("FSLAN_10", "Legakt�vabb t�m�k");
define("FSLAN_11", "Rang");
define("FSLAN_12", "T�ma");
define("FSLAN_13", "V�lasz");
define("FSLAN_14", "Ind�totta");
define("FSLAN_15", "D�tum");
define("FSLAN_16", "Legolvasottabb t�m�k");
define("FSLAN_17", "Olvas�s");
define("FSLAN_18", "Legt�bbet �r�k");
define("FSLAN_19", "N�v");
define("FSLAN_20", "�zenet");
define("FSLAN_21", "Legt�bb t�m�t nyit�k");
define("FSLAN_22", "Legt�bb v�laszt �r�k");
define("FSLAN_23", "F�rum statisztik�k");
define("FSLAN_24", "Napi �zenet �tlag");

?>
