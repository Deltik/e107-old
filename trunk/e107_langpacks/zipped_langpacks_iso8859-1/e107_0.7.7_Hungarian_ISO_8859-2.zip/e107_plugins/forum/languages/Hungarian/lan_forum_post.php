<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.9 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "F�rum");

define("LAN_01", "F�rumok");
define("LAN_02", "V�lasz: ");
define("LAN_03", "�j T�ma");
define("LAN_1", "Norm�l");
define("LAN_2", "Kiemelt");
define("LAN_3", "Bejelent�s");
define("LAN_4", "Szavaz�s k�ld�se");
define("LAN_5", "Szavaz�s k�rd�se:");
define("LAN_6", "�jabb v�lasz hozz�ad�sa");
define("LAN_7", "V�laszt�si lehet�s�gek:");
define("LAN_8", "Mindenki szavazhat");
define("LAN_9", "Csak tagok szavazhatnak");
define("LAN_10", "Bejelentkez�s");
define("LAN_11", "Adatok megjegyz�se");
define("LAN_16", "Felhaszn�l�n�v: ");
define("LAN_17", "Jelsz�: ");
define("LAN_20", "Hiba");
define("LAN_27", "K�telez�en megadand� mez�(ke)t hagyt�l �resen");
define("LAN_28", "Nem adt�l meg semmit ..");
define("LAN_29", "M�dos�tva");
define("LAN_45", "Ebben a f�rumban csak regisztr�lt tagok k�ldhetnek �zenetet. Kattints ");
define("LAN_60", "�j t�ma");
define("LAN_61", "Neved: ");
define("LAN_62", "T�ma: ");
define("LAN_63", "�zenet: ");
define("LAN_64", "�j t�ma k�ld�se");
define("LAN_73", "V�lasz: ");
define("LAN_74", "V�lasz a t�m�ra");
define("LAN_77", "T�ma friss�t�se");
define("LAN_78", "V�lasz friss�t�se");
define("LAN_94", "�rta:");
define("LAN_95", "Jogosulatlan");
define("LAN_96", "Nincs enged�lyed a hozz�sz�l�s szerkeszt�s�re.");
define("LAN_100", "T�ma t�rgya");
define("LAN_101", "Legutols�:");
define("LAN_102", " v�lasz");
define("LAN_103", "Eg�sz t�ma �ttekint�se. (�j ablakban.)");
define("LAN_133", "K�sz�nj�k");
define("LAN_174", "Regisztr�ci�");
define("LAN_175", "Bejelentkez�s");
define("LAN_212", "Elfelejtett jelsz�?");
define("LAN_310", "Hozz�sz�l�s nem elfogadhat�, mivel egy regisztr�lt tag nev�t haszn�ltad. Ha esetleg nem jelentkezt�l be, de a n�v a saj�tod, akkor jelentkezz be.");
define("LAN_311", "Anonymous");
define("LAN_322", "Elk�ldve: ");
define("LAN_323", "El�n�zet");
define("LAN_324", "�zenet sikeresen elk�ldve.");
define("LAN_325", "�zeneted megtekint�se");
define("LAN_326", "Vissza a f�rumba");
define("LAN_327", "El�zetes");
define("LAN_380", "Ha e-mailben akarsz �rtes�lni a v�laszokr�l, akkor jel�ld be ");
define("LAN_381", "V�lasz: ");
define("LAN_382", "Hozz�sz�l�s: ");
define("LAN_383", "Az eg�sz t�ma megtekint�s�hez kattints a linkre ...");
define("LAN_384", "F�rum v�lasz: ");
define("LAN_385", "�rta: ");
define("LAN_386", "Ha nem akarsz szavaz�st a t�m�dhoz, akkor hagy �resen a mez�ket ");
define("LAN_387", "Mehet");
define("LAN_388", "Vissza az elej�re");
define("LAN_389", "Dupla hozz�sz�l�s, �tir�ny�t�s ...");
define("LAN_390", "F�jl / k�p csatol�sa");
define("LAN_391", "Opci�");
define("LAN_392", "Csatoland� f�jl");
define("LAN_393", "<b>Figyelem</b><br />Megengedett f�jlt�pusok:");
define("LAN_394", "Minden m�s t�pus� felt�lt�tt f�jl azonnal t�r�lve lesz.");
define("LAN_395", "Maxim�lis f�jlm�ret");
define("LAN_396", "byte");
define("LAN_397", "Lez�rt t�ma");
define("LAN_398", "Ez a f�rum csak olvashat�");
define("LAN_399", "Nincs jogosults�god �rni ebbe a f�rumba.");
define("LAN_400", "t�ma t�pusa");
define("LAN_401", "Ugr�s");

define("LAN_402", "szavaz�s");
define("LAN_403", "hirdetm�ny");
define("LAN_404", "kiemelt");
define("LAN_405", "F�rumok");
define("LAN_406", "V�lasz:");

//v.616
define("LAN_407", "Visszair�ny�t�s");
define("LAN_408", "Ha a b�ng�sz�d nem t�mogatja a meta tag-eket, kattints");
define("LAN_409", "IDE");
define("LAN_410", "a visszair�ny�t�shoz.");
define("LAN_411", "ide");
define("LAN_412", "a regisztr�ci�hoz.");

define("LAN_413", "Szavazatod r�gz�tve.");
define("LAN_414", "Szavazatod megtekint�se");
define("LAN_415", "V�laszod r�gz�tve.");

define("LAN_416", "File csatol�sa");
define("LAN_417", "Tov�bbi mell�kletek hozz�ad�sa");

define("POLL_506", "T�bb v�laszt�si lehet�s�g enged�lyez�se?");
define("POLL_507", "igen");
define("POLL_508", "nem");

define("LAN_FORUM_1", "Felt�lt�s nem lehets�ges: az ".e_FILE."public k�nyvt�r nem �rhat�");
define("LAN_FORUM_2", "Dupla �zenet");
?>
