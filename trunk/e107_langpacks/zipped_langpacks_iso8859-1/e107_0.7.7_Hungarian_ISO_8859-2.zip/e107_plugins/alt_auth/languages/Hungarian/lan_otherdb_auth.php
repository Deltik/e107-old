<?php
define("OTHERDB_LAN_1", "Adatb�zis t�pus:");
define("OTHERDB_LAN_2", "Szerver:");
define("OTHERDB_LAN_3", "Felhaszn�l�n�v:");
define("OTHERDB_LAN_4", "Jelsz�:");
define("OTHERDB_LAN_5", "Adatb�zis");
define("OTHERDB_LAN_6", "T�bla");
define("OTHERDB_LAN_7", "Felhaszn�l�n�v mez�:");
define("OTHERDB_LAN_8", "Jelsz� mez�:");
define("OTHERDB_LAN_9", "Jelsz� m�dszer:");
define("OTHERDB_LAN_10", "Otherdb auth be�ll�t�sa");
define("OTHERDB_LAN_11", "** A k�vetkez� mez�k nem sz�ks�gesek, ha e107 adatb�zist haszn�lsz");

?>
