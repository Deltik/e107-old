<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.1 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LWLAN_1", "�res mez�(k).");
define("LWLAN_2", "Link sz� elmentve.");
define("LWLAN_3", "Link sz� friss�tve.");
define("LWLAN_4", "Nincs link sz� defini�lva.");
define("LWLAN_5", "Sz�");
define("LWLAN_6", "Link");
define("LWLAN_7", "Akt�v?");
define("LWLAN_8", "Opci�k");
define("LWLAN_9", "igen");
define("LWLAN_10", "nem");
define("LWLAN_11", "Jelenlegi linkszavak");
define("LWLAN_12", "Igen");
define("LWLAN_13", "Nem");
define("LWLAN_14", "Link sz� ment�se");
define("LWLAN_15", "Link sz� friss�t�se");
define("LWLAN_16", "M�dos�t�s");
define("LWLAN_17", "T�rl�s");
define("LWLAN_18", "Biztosan t�r�lni akarod ezt a link sz�t?");
define("LWLAN_19", "Link sz� t�r�lve.");
define("LWLAN_20", "Ez a link sz� nem tal�lhat�.");
define("LWLAN_21","Sz� az automatikus linkhez");
define("LWLAN_22","Aktiv�l�s?");

define("LWLANINS_1", "Link szavak");
define("LWLANINS_2", "A plugin linket rendel a megadott sz�hoz");
define("LWLANINS_3", "Link szavak be�ll�t�sa");
define("LWLANINS_4", "A be�ll�t�shoz kattints a linkre a plugin manager-ben.");

?>
