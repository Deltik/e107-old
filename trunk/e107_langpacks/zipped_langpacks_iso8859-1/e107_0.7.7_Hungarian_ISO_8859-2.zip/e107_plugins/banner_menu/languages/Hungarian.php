<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.3 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("BANNER_MENU_L1", "Rekl�mok");
define("BANNER_MENU_L2", "Rekl�m men� be�ll�t�sai elmentve");

//v.617
define("BANNER_MENU_L3", "C�m/fejl�c");
define("BANNER_MENU_L4", "Kamp�ny");
define("BANNER_MENU_L5", "Rekl�m Men� be�ll�t�sai");
define("BANNER_MENU_L6", "a men�ben megjelen�tend� kamp�nyok kiv�laszt�sa");
define("BANNER_MENU_L7", "jelenlegi kamp�nyok");
define("BANNER_MENU_L8", "kiv�lasztott kamp�nyok");
define("BANNER_MENU_L9", "kiv�laszt�s t�rl�se");
define("BANNER_MENU_L10", "hogyan jelenjenek meg a kiv�lasztott kamp�nyok?");
define("BANNER_MENU_L11", "megjelen�t�s t�pusa ...");
define("BANNER_MENU_L12", "egy kamp�ny egy egyszer� men�ben");
define("BANNER_MENU_L13", "az �sszes kiv�lasztott kamp�ny egy egyszer� men�ben");
define("BANNER_MENU_L14", "az �sszes kiv�lasztott kamp�ny k�l�n men�kben");
define("BANNER_MENU_L15", "h�ny banner legyen l�that�?");
define("BANNER_MENU_L16", "ez a be�ll�t�s csak 2 vagy 3 opci�kkal lesz haszn�lhat�<br />ha kevesebb banner van, a maxim�lis lehets�ges mennyis�g lesz haszn�lva.");
define("BANNER_MENU_L17", "mennyis�g be�ll�t�sa ...");
define("BANNER_MENU_L18", "Men� be�ll�t�sok friss�t�se");
?>
