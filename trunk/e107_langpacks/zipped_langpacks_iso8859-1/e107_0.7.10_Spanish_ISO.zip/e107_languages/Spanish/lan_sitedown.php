<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_sitedown.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/17 10:47:08 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sitio cerrado temporalmente");
define("LAN_SITEDOWN_00", "<b>- Temporalmente cerrado -</b><br /><br />Hemos cerrado temporalmente nuestro portal para realizar un mantenimiento del mismo e implementar nuevas utilidades. Este proceso durar� pocas horas - Le rogamos nos disculpe por los inconvenientes que este proceso le pueda causar..");
define("LAN_SITEDOWN_01", "Este sitio est� cerrado temporalmente por mantenimiento. El sitio estar� disponible lo antes posible, por favor disculpe las molestias.");
?>