<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_upload_handler.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/08/06 21:48:50 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "El tipo de archivo");
define("LANUPLOAD_2", "no est� permitido y ha sido borrado.");
define("LANUPLOAD_3", "Transferencia completada");
define("LANUPLOAD_4", "La carpeta de destino no existe o no tiene permisos de escritura.(chmod 777)");
define("LANUPLOAD_5", "La transferencia excede el tama�o m�ximo permitido definido en php.ini.");
define("LANUPLOAD_6", "La transferencia excede el tama�o m�ximo permitido definido por el administrador.");
define("LANUPLOAD_7", "La transferencia se ha completado parcialmente.");
define("LANUPLOAD_8", "No se realiz� la transferencia.");
define("LANUPLOAD_9", "El tama�o de la transferencia es de 0 bytes");
define("LANUPLOAD_10", "Fall� la transferencia [Archivo duplicado] - existe un archivo con el mismo nombre.");
define("LANUPLOAD_11", "El archivo no pudo ser transferido. Archivo: ");
define("LANUPLOAD_12", "Error");
define("LANUPLOAD_13", "Falta la carpeta temporal"); 
define("LANUPLOAD_14", "Fallo en la escritura de archivo"); 
define("LANUPLOAD_15", "Transferencia no permitida"); 
define("LANUPLOAD_16", "Error desconocido"); 
define("LANUPLOAD_17", "Nombre inv�lido para el archivo transferido"); 
define("LANUPLOAD_18", "El archivo trasnferido excede los l�mites permitidos."); 
define("LANUPLOAD_19", "Demasiados archivos trasnferidos - eliminados los excesos."); 
?>