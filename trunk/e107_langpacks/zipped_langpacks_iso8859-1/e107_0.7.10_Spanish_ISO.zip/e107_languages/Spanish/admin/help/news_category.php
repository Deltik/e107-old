<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/news_category.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Puede separar sus �tems nuevos en diferentes categor�as,
y permitir a los visitantes desplegar los nuevos �tems en esas categor�as. <br /><br />
Suba los �conos de sus noticias a ".e_THEME."-tutema-/images/ o images/newsicons/.";
$ns -> tablerender("Ayuda Categor�a de noticias", $text);
?>