<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_banlist.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/08/10 19:04:02 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Expulsi�n eliminada.");
define("BANLAN_2", "No hay expulsados.");
define("BANLAN_3", "Expulsados existentes");
define("BANLAN_4", "Eliminar expulsi�n");
define("BANLAN_5", "Expulsar por IP, email o host");

define("BANLAN_7", "Raz�n");
define("BANLAN_8", "Expulsar Usuario");
define("BANLAN_9", "Expulsar usuarios del sitio");
define("BANLAN_10", "IP / Email / Raz�n");
define("BANLAN_11", "Auto-expulsi�n: M�s de 10 intentos de conexi�n fallidos");
define("BANLAN_12", "Nota: DNS reversa est� actualmente desactivada, debe activarse para permitir expulsar un dominio. La expulsi�n por IP y correo seguir� funcionando correctamente.");
define("BANLAN_13","Nota: Para expulsar a un usuario por su nombre, vaya a la p�gina de administraci�n de usuarios");
?>