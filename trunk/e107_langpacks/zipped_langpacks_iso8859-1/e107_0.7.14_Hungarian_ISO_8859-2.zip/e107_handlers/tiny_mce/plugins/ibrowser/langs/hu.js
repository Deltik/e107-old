// UK lang variables

tinyMCELang['lang_ibrowser_title'] = 'K�p beilleszt�se / m�dos�t�sa';
tinyMCELang['lang_ibrowser_desc'] = 'K�p beilleszt�se / m�dos�t�sa';
tinyMCELang['lang_ibrowser_library'] = 'K�nyvt�r';
tinyMCELang['lang_ibrowser_preview'] = 'El�n�zet';
tinyMCELang['lang_ibrowser_img_sel'] = 'K�p kiv�laszt�s';
tinyMCELang['lang_ibrowser_img_info'] = 'K�p inform�ci�';
tinyMCELang['lang_ibrowser_img_upload'] = 'K�p felt�lt�se';
tinyMCELang['lang_ibrowser_images'] = 'K�p';
tinyMCELang['lang_ibrowser_src'] = 'Forr�s';
tinyMCELang['lang_ibrowser_alt'] = 'Le�r�s';
tinyMCELang['lang_ibrowser_size'] = 'M�ret';
tinyMCELang['lang_ibrowser_align'] = 'Sz�veg k�rbefuttat�sa';
tinyMCELang['lang_ibrowser_height'] = 'Magass�g';
tinyMCELang['lang_ibrowser_width'] = 'Sz�less�g';
tinyMCELang['lang_ibrowser_reset'] = '�jram�retez�s';
tinyMCELang['lang_ibrowser_border'] = 'Szeg�ly';
tinyMCELang['lang_ibrowser_hspace'] = 'HSpace';
tinyMCELang['lang_ibrowser_vspace'] = 'VSpace';
tinyMCELang['lang_ibrowser_select'] = 'Ment�s';
tinyMCELang['lang_ibrowser_delete'] = 'T�rl�s';
tinyMCELang['lang_ibrowser_cancel'] = 'Kil�p�s';
tinyMCELang['lang_ibrowser_uploadtxt'] = 'File';
tinyMCELang['lang_ibrowser_uploadbt'] = 'Felt�lt�s';
// error messages
tinyMCELang['lang_ibrowser_error'] = 'Hiba';
tinyMCELang['lang_ibrowser_errornoimg'] = 'V�lassz egy k�pet';
tinyMCELang['lang_ibrowser_errornodir'] = 'A k�nyvt�r fizikailag nem l�tezik';
tinyMCELang['lang_ibrowser_errorupload'] = 'Hiba a file felt�lt�s sor�n.\nPr�b�lkozz �jra';
tinyMCELang['lang_ibrowser_errortype'] = '�rv�nytelen k�p file t�pus';
tinyMCELang['lang_ibrowser_errordelete'] = 'T�rl�s sikertelen';
tinyMCELang['lang_ibrowser_confirmdelete'] = 'Katt az OK-ra a k�p t�rl�s�hez!';
tinyMCELang['lang_ibrowser_error_width_nan'] = 'Sz�less�g nem egy sz�m!';
tinyMCELang['lang_ibrowser_error_height_nan'] = 'Magass�g nem egy sz�m!';
tinyMCELang['lang_ibrowser_error_border_nan'] = 'Szeg�ly nem egy sz�m!';
tinyMCELang['lang_ibrowser_error_hspace_nan'] = 'V�zszintes sz�net nem egy sz�m!';
tinyMCELang['lang_ibrowser_error_vspace_nan'] = 'F�gg�leges sz�net nem egy sz�m!';
