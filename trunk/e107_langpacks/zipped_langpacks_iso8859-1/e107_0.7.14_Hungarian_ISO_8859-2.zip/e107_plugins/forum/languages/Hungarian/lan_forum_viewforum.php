<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.8 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "F�rum");

define("LAN_01", "F�rumok");
define("LAN_02", "Vissza az elej�re");
define("LAN_03", "Mehet");
define("LAN_53", "T�ma");
define("LAN_54", "Nyitotta");
define("LAN_55", "V�laszok");
define("LAN_56", "Megtekintve");
define("LAN_57", "Utols� hozz�sz�l�s");
define("LAN_58", "Ebben a  f�rumban m�g nincsenek t�m�k.");
define("LAN_59", "Ebben a f�rumban a hozz�sz�l�shoz regisztr�lnod kell. Regisztr�lj, vagy l�pj be.");
define("LAN_79", "Van �j �zenet");
define("LAN_80", " Nincs �j �zenet");
define("LAN_81", "Z�rt t�ma");
define("LAN_180", "Keres�s");
define("LAN_199", "Olvasatlan �zenetek");
define("LAN_202", "Kiemelt");
define("LAN_203", "Kiemelt/Z�rt");
define("LAN_204", "<b>Nyithatsz</b> �j t�m�kat");
define("LAN_205", "<b>Nem</b> nyithatsz �j t�m�kat");
define("LAN_206", "<b>K�ldhetsz</b> v�laszokat");
define("LAN_207", "<b>Nem</b> k�ldhetsz v�laszokat");
define("LAN_208", "<b>M�dos�thatod</b> a hozz�sz�l�saidat");
define("LAN_209", "<b>Nem</b> m�dos�thatod a hozz�sz�l�saidat");
define("LAN_316", "Ugr�s: ");
define("LAN_317", "Nincs");
define("LAN_321", "Moder�torok: ");
define("LAN_395", "[n�pszer�]");
define("LAN_396", "Hirdetm�ny");

define("LAN_397", "Ez a f�rum csak olvashat�");

define("LAN_398", "T�ma kiemel�s�nek megsz�ntet�se");
define("LAN_399", "T�ma lez�r�sa");
define("LAN_400", "T�ma felnyit�sa");
define("LAN_401", "T�ma kiemel�se");
define("LAN_402", "T�ma �thelyez�se");
define("LAN_403", "Tov�bbi oldalak");
define("LAN_404", "Moder�torok");

define("LAN_405", "f�rumolvas�");
define("LAN_406", "f�rumolvas�");
define("LAN_407", "tag");
define("LAN_408", "vend�g");
define("LAN_409", "tag");
define("LAN_410", "vend�g");

//v.616
define("LAN_411", "Fontos t�m�k");
define("LAN_412", "F�rumt�m�k");
define("LAN_431", "F�rum �tad�sa: rss 0.92");
define("LAN_432", "F�rum �tad�sa: rss 2.0");
define("LAN_433", "F�rum �tad�sa: RDF");

define("LAN_434", "Biztosan t�r�lni akarod e t�m�t �s minden v�lasz�t?");
define("LAN_435", "T�ma t�rl�se");

//v.617
define("FORLAN_CLOSE", "T�ma lez�rva.");
define("FORLAN_OPEN", "T�ma felnyitva.");
define("FORLAN_STICK", "A t�ma kiemelt lett.");
define("FORLAN_UNSTICK", "A t�ma kiemel�se megsz�nt.");
define("FORLAN_6", "T�ma t�r�lve");
define("FORLAN_7", "v�lasz t�r�lve");
define("FORLAN_8", "ide");
define("FORLAN_9", "a regisztr�ci�hoz, vagy l�pj be.");

define("FORLAN_10", "�j t�ma nyit�sa");
define("FORLAN_11", "�j �zenet");
define("FORLAN_12", "Nincs �j �zenet");
define("FORLAN_13", "�j �zenet - N�pszer� t�ma");
define("FORLAN_14", "Nincs �j �zenet - N�pszer� t�ma");
define("FORLAN_15", "Kiemelt t�ma");
define("FORLAN_16", "Lez�rt kiemelt t�ma");
define("FORLAN_17", "Hirdetm�ny t�ma");
define("FORLAN_18", "Lez�rt t�ma");
define('FORLAN_19', '[felhaszn�l� t�r�lve]');
define('FORLAN_20', 'Al-F�rum');
define('FORLAN_21', 'T�m�k');
define('FORLAN_22', 'Utols� hozz�sz�l�s');
?>