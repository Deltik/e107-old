<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.6 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CHATBOX_L1", "Ez a felhaszn�l�n�v m�r foglalt - ha a tied, akkor jelentkezz be.");
define("CHATBOX_L2", "Chatbox");
define("CHATBOX_L3", "�zenetek �r�s�hoz regisztr�lt tagnak kell lenned - jelentkezz be, vagy <a href='".e_BASE."signup.php'>regisztr�lj</a>");
define("CHATBOX_L4", "Mehet");
define("CHATBOX_L5", "T�rl�s");
define("CHATBOX_L6", "[Admin blokkolta]");
define("CHATBOX_L7", "Megnyit");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Tilt�s");
define("CHATBOX_L10", "T�rl�s");
define("CHATBOX_L11", "M�g nincs �zenet.");
define("CHATBOX_L12", "�sszes �zenet megtekint�se");
define("CHATBOX_L13", "Chatbox moder�l�sa");
define("CHATBOX_L14", "Emotikonok");
define("CHATBOX_L15", "Az �zenet t�l hossz�, vagy �res");
define("CHATBOX_L16", "Anonymous");
define("CHATBOX_L17", "Dupla �zenet");
define("CHATBOX_L18", "Chatbox �zenet moder�lva");
define("CHATBOX_L19", "�jabb �zenetet csak ".FLOODTIMEOUT." m�sodperc ut�n k�ldhetsz");

define("CHATBOX_L20", "Chatbox (�sszes �zenet)");
define("CHATBOX_L21", "Chat �zenetek");
define("CHATBOX_L22", "-");
define("CHATBOX_L23", "Hiba!");
define("CHATBOX_L24", "Nincs jogosults�god az oldal megtekint�s�hez.");
define("CHATBOX_L25", "[ ezt az �zenetet az admin blokkolta ]");

// Notify
define("NT_LAN_CB_1", "Chatbox Esem�nyek");
define("NT_LAN_CB_2", "�zenet elk�ldve");
define("NT_LAN_CB_3", "Elk�ldte");
define("NT_LAN_CB_4", "IP C�m");
define("NT_LAN_CB_5", "�zenet");
define("NT_LAN_CB_6", "Chatbox �zenet elk�ldve");

?>
