<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("TRACKBACK_L1", "Trackback be�ll�t�sa");
define("TRACKBACK_L2", "Ez a plugin enged�lyezi a trackback haszn�lat�t a h�r �zenetekben.");
define("TRACKBACK_L3", "Trackback telep�tve �s enged�lyezve.");
define("TRACKBACK_L4", "Trackback be�ll�t�sok elmentve.");
define("TRACKBACK_L5", "Be");
define("TRACKBACK_L6", "Ki");
define("TRACKBACK_L7", "Trackback aktiv�l�sa");
define("TRACKBACK_L8", "Trackback URL sz�veg");
define("TRACKBACK_L9", "Be�ll�t�sok ment�se");
define("TRACKBACK_L10", "Trackback be�ll�t�sok");
define("TRACKBACK_L11", "Trackback c�m e h�rhez:");

define("TRACKBACK_L12", "Nincsenek trackback-ek");
define("TRACKBACK_L13", "Trackback-ek moder�l�sa");
define("TRACKBACK_L14", "T�rl�s");
define("TRACKBACK_L15", "Trackback-ek t�r�lve.");
?>
