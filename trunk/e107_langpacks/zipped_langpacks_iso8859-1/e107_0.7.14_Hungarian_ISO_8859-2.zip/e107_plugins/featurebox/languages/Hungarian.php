<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.1 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FBLAN_01", "Saj�t doboz");
define("FBLAN_02", "Ez a plugin lehet�s�get ad, hogy megjelen�ts egy dobozt a h�reid felett k�l�nb�z� tulajdons�gokkal / b�rmit, amit akarsz. Az �zenetet megjelen�theted v�letlenszer�en vagy dinamikusan elhalv�nyulva.");
define("FBLAN_03", "Saj�t doboz be�ll�t�sa");
define("FBLAN_04", "Saj�t doboz plugin telep�tve. A be�ll�t�shoz �s az �zenetek felvitel�hez l�pj vissza az admin kezd�lapra, �s kattints a Feature box ikonra a plugin r�szben.");
define("FBLAN_05", "Nincsenek be�ll�tott �zenetek");
define("FBLAN_06", "Jelenlegi �zenetek");
define("FBLAN_07", "C�msor");
define("FBLAN_08", "�zenet sz�vege");
define("FBLAN_09", "�zenet l�that�s�ga");
define("FBLAN_10", "Saj�t doboz �zenet l�trehoz�sa");
define("FBLAN_11", "Saj�t doboz �zenet friss�t�se");
define("FBLAN_12", "M�d");
define("FBLAN_13", "V�letlenszer�en forgatja az �zeneteket");
define("FBLAN_14", "Csak ezt az �zenetet mutatja");
define("FBLAN_15", "Az �zenet t�rolva az adatb�zisban.");
define("FBLAN_16", "Az �zenet friss�tve az adatb�zisban.");
define("FBLAN_17", "�resen maradt mez�(k)");
define("FBLAN_18", "Saj�t doboz �zenet t�r�lve");
define("FBLAN_19", "Opci�k");
define("FBLAN_20", "M�dos�t�s");
define("FBLAN_21", "T�rl�s");
define("FBLAN_22", "Megjelen�t�s t�pusa");
define("FBLAN_23", "Theme box-ban");
define("FBLAN_24", "Sima");
define("FBLAN_25", "Sablon");
define("FBLAN_26", "minden �zenethez m�s sablont haszn�lhatsz, a sablonokat t�ltsd fel az e107_plugins/featurebox/templates/ mapp�ba");

?>
