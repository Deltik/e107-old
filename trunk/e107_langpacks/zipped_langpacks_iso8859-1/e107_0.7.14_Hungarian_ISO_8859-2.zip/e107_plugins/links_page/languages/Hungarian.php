<?php
# --------------------------------------------------------------------------
# e107 Hungarian language file - $Version: 1.30 $ - $Author: e107hungary.org team $ - $Date: 2008 $
# --------------------------------------------------------------------------


define("LCLAN_PLUGIN_LAN_1", "Linkek oldal");
define("LCLAN_PLUGIN_LAN_2", "K�ls� linkek megjelen�t�si oldala");
define("LCLAN_PLUGIN_LAN_3", "Be�ll�t�sok");
define("LCLAN_PLUGIN_LAN_4", "Linkek");
define("LCLAN_PLUGIN_LAN_5", "Linkek oldal sikeresen telep�tve, be�ll�t�s a 'Linkek oldal' fel�leten az admin r�szben.");
define("LCLAN_PLUGIN_LAN_6", "Linkek oldal sikeresen friss�tve, jelenlegi verzi�");

define("LCLAN_OPT_MENU_1", "�ltal�nos be�ll�t�sok");
define("LCLAN_OPT_MENU_2", "Szem�lyes link kezel�");
define("LCLAN_OPT_MENU_3", "Kateg�ria oldal");
define("LCLAN_OPT_MENU_4", "Linkek megjelen�t�se");
define("LCLAN_OPT_MENU_5", "Hivatkoz�s oldal");
define("LCLAN_OPT_MENU_6", "�rt�kel�s oldal");
define("LCLAN_OPT_MENU_7", "Men�");

define("LCLAN_PAGETITLE_1", "Linkek");
define("LCLAN_PAGETITLE_2", "�sszes kateg�ria");
define("LCLAN_PAGETITLE_3", "�sszes link");
define("LCLAN_PAGETITLE_4", "Kateg�ria");
define("LCLAN_PAGETITLE_5", "Legjobb �rt�kel�s");
define("LCLAN_PAGETITLE_6", "Legt�bb hivatkoz�s");
define("LCLAN_PAGETITLE_7", "Szem�lyes link kezel�");
define("LCLAN_PAGETITLE_8", "Link hozz�sz�l�sok");
define("LCLAN_PAGETITLE_9", "Link bek�ld�se");
define("LCLAN_PAGETITLE_10", "");


define("LCLAN_OPT_1", "�ltal�nos be�ll�t�sok");
define("LCLAN_OPT_2", "Link oldal be�ll�t�sok");
define("LCLAN_OPT_3", "enged�lyez�s");
define("LCLAN_OPT_4", "tilt�s");
define("LCLAN_OPT_5", "px");
define("LCLAN_OPT_6", "");
define("LCLAN_OPT_7", "Kateg�ri�k elv�laszt�sa egy�ni oldalakba");
define("LCLAN_OPT_8", "Link bek�ld�s enged�lyez�se");
define("LCLAN_OPT_9", "Ki k�ldhet be linket");
define("LCLAN_OPT_10", "�sszetett link oldal megjelen�t�se");
define("LCLAN_OPT_11", "Linkek sz�ma / oldal");
define("LCLAN_OPT_12", "Kateg�ria oldal");
define("LCLAN_OPT_13", "Mely r�szt jelen�tsen meg");
define("LCLAN_OPT_14", "Ikon");
define("LCLAN_OPT_15", "Le�r�s");
define("LCLAN_OPT_16", "Mennyis�g");
define("LCLAN_OPT_17", "Hivatkoz�s");
define("LCLAN_OPT_18", "url");
define("LCLAN_OPT_19", "Teljes kateg�ria info vonal");
define("LCLAN_OPT_20", "link a legt�bb hivatkoz�shoz");
define("LCLAN_OPT_21", "link a legjobb �rt�kel�shez");
define("LCLAN_OPT_22", "Alap�rtelmezett ikon megjelen�t�se, ha nincs kiv�lasztva");
define("LCLAN_OPT_23", "Alap�rtelmezett elrendez�si m�dszer");
define("LCLAN_OPT_24", "Alap�rtelmezett soorend m�dszer");
define("LCLAN_OPT_25", "Alap�rtelmezett �tm�retez�si �rt�k");
define("LCLAN_OPT_26", "linkek oldal");
define("LCLAN_OPT_27", "Linkek �rt�kel�s�nek enged�lyez�se");
define("LCLAN_OPT_28", "Alap�rtelmezett ikon megjelen�t�se, ha nincs kiv�lasztva");
define("LCLAN_OPT_29", "Elrendez�s �s sorrend men� megjelen�t�se");
define("LCLAN_OPT_30", "n�vekv�");
define("LCLAN_OPT_31", "cs�kken�");
define("LCLAN_OPT_32", "Link megnyit�s m�dszer fel�l�r�s�nak haszn�lata");
define("LCLAN_OPT_33", "Alap�rtelmezett �tm�retez�si �rt�k");
define("LCLAN_OPT_34", "n�v");
define("LCLAN_OPT_35", "url");
define("LCLAN_OPT_36", "sorrend");
define("LCLAN_OPT_37", "Hivatkoz�s");
define("LCLAN_OPT_38", "");
define("LCLAN_OPT_39", "");
define("LCLAN_OPT_40", "n�v");
define("LCLAN_OPT_41", "id");
define("LCLAN_OPT_42", "Egy�ni link be�ll�t�sok haszn�lata");
define("LCLAN_OPT_43", "Megnyit�s azonos ablakban");
define("LCLAN_OPT_44", "Megnyit�s �j ablakban");
define("LCLAN_OPT_45", "Megnyit�s 600x400 -as ablakban");
define("LCLAN_OPT_46", "Linkek karbantart�sa");
define("LCLAN_OPT_47", "Ezek a felhaszn�l�k hozz�adhatnak/m�dos�thatj�k a saj�t szem�lyes linkeket");
define("LCLAN_OPT_48", "K�zvetlen bek�ld�s enged�lyez�se");
define("LCLAN_OPT_49", "Ha enged�lyezed, akkor k�zvetlen�l az oldalra ker�lnek, egy�b esetben az oldal adminisztr�tor j�v�hagy�sa sz�ks�ges");
define("LCLAN_OPT_50", "K�zvetlen t�rl�s enged�lyez�se");
define("LCLAN_OPT_51", "Ha enged�lyezed a linkek karbantart�s�t, akkor mindenki t�r�lheti a saj�t linkj�t");
define("LCLAN_OPT_52", "Szem�lyes link karbantart�");
define("LCLAN_OPT_53", "D�tum");
define("LCLAN_OPT_54", "Szem�lyes karbantart�s enged�lyez�se");
define("LCLAN_OPT_55", "Hozz�sz�l�s enged�lyez�se az �sszes linkhez");
define("LCLAN_OPT_56", "minim�lis hivatkoz�s �rt�k");
define("LCLAN_OPT_57", "Csak a meghat�rozott �rt�kn�l nagyobb sz�m� linkek jelennek meg (0 vagy empty = �sszes)");
define("LCLAN_OPT_58", "link a bek�ld�shez");
define("LCLAN_OPT_59", "link a szem�lyes karbantart�shoz<br />(csak ha enged�lyezett)");
define("LCLAN_OPT_60", "link a link f�oldalra");
define("LCLAN_OPT_61", "link az �sszes kateg�ri�hoz");
define("LCLAN_OPT_62", "Navig�ci�s linkek megjelen�t�se");
define("LCLAN_OPT_63", "Minimum �rt�kel�si �rt�k");
define("LCLAN_OPT_64", "Csak a meghat�rozott �rt�kn�l nagyobb sz�m� linkek jelennek meg (0 vagy empty = �sszes)");
define("LCLAN_OPT_65", "�res kateg�ri�k megjelen�t�se");
define("LCLAN_OPT_66", "link minden kateg�ri�hoz");
define("LCLAN_OPT_67", "link az �sszes kateg�ri�hoz");
define("LCLAN_OPT_68", "�sszes link megtekint�se");

define("LCLAN_OPT_69", "Link navig�tor megjelen�t�si st�lusa");
define("LCLAN_OPT_70", "Link kateg�ri�k megjelen�t�se");
define("LCLAN_OPT_71", "Kateg�ria linkek megjelen�t�si st�lusa");
define("LCLAN_OPT_72", "�j linkek megjelen�t�se");
define("LCLAN_OPT_73", "D�tum kijelz�se");
define("LCLAN_OPT_74", "H�ny leg�jabb linket jelen�tsen meg");
define("LCLAN_OPT_75", "hyperlink");
define("LCLAN_OPT_76", "kiv�laszt�doboz");
define("LCLAN_OPT_77", "Kateg�ria");
define("LCLAN_OPT_78", "Le�r�s");
define("LCLAN_OPT_79", "C�m navig�ci�");
define("LCLAN_OPT_80", "Kateg�ria c�mek");
define("LCLAN_OPT_81", "Leg�jabb lista c�me");
define("LCLAN_OPT_82", "Navig�ci�");
define("LCLAN_OPT_83", "Kateg�ri�k");
define("LCLAN_OPT_84", "Leg�jabb lista");
define("LCLAN_OPT_85", "C�m men�");
define("LCLAN_OPT_86", "Link men�");
define("LCLAN_OPT_87", "Linkek sz�m�nak megjelen�t�se");

define("LCLAN_ADMIN_1", "Friss�t�s");
define("LCLAN_ADMIN_2", "Link adatb�zisba elmentve.");
define("LCLAN_ADMIN_3", "Link adatb�zisban friss�tve.");
define("LCLAN_ADMIN_4", "Link kateg�ria elmentve.");
define("LCLAN_ADMIN_5", "Link kateg�ria friss�tve.");
define("LCLAN_ADMIN_6", "Be�ll�t�sok elmentve.");
define("LCLAN_ADMIN_7", "Link ikon sikeresen felt�ltve !");
define("LCLAN_ADMIN_8", "Link ikon felt�lt�se sikertelen !");
define("LCLAN_ADMIN_9", "Sorrend friss�tve.");
define("LCLAN_ADMIN_10", "Link");
define("LCLAN_ADMIN_11", "t�r�lve");
define("LCLAN_ADMIN_12", "Link kateg�ria");
define("LCLAN_ADMIN_13", "Bek�ld�tt link t�r�lve.");
define("LCLAN_ADMIN_14", "Linkek");
define("LCLAN_ADMIN_15", "Ebben a kateg�ri�ban m�g vannak linkek, el�sz�r t�r�ld �ket");

define("LCLAN_SL_1", "Bek�ld�tt linkek");
define("LCLAN_SL_2", "Nincs bek�ld�tt link");
define("LCLAN_SL_3", "Link");
define("LCLAN_SL_4", "Bek�ldte");
define("LCLAN_SL_5", "Be�ll�t�sok");
define("LCLAN_SL_6", "K�ld�s");
define("LCLAN_SL_7", "T�rl�s");
define("LCLAN_SL_8", "Biztosan t�r�lni akarod ezt a bek�ld�tt linket?");
define("LCLAN_SL_9", "A link bek�ld�s�t k�vet�en az Adminisztr�tor ellen�rzi azt, amennyiben alkalmasnak tal�lja, k�zz�teszi a linkek oldalon.");
define("LCLAN_SL_10", "Kateg�ria:");
define("LCLAN_SL_11", "n�v");
define("LCLAN_SL_12", "url");
define("LCLAN_SL_13", "Le�r�s");
define("LCLAN_SL_14", "URL a link gombhoz:");
define("LCLAN_SL_15", "Al�h�zott mez�k kit�lt�se k�telez�.");
define("LCLAN_SL_16", "Bek�ld�s");
define("LCLAN_SL_17", "");
define("LCLAN_SL_18", "");

define("LCLAN_CAT_1", "K�p");
define("LCLAN_CAT_2", "Kateg�ria");
define("LCLAN_CAT_3", "Be�ll�t�sok");
define("LCLAN_CAT_4", "Mozgat�s");
define("LCLAN_CAT_5", "Sorrend");
define("LCLAN_CAT_6", "M�dos�t");
define("LCLAN_CAT_7", "Van");
define("LCLAN_CAT_8", "Biztosan t�r�lni akarod ezt a kateg�ri�t?");
define("LCLAN_CAT_9", "Linkek megtekint�se");
define("LCLAN_CAT_10", "�j sorrend");
define("LCLAN_CAT_11", "Nincsennek link kateg�ri�k");
define("LCLAN_CAT_12", "Megl�v� link kateg�ri�k");
define("LCLAN_CAT_13", "N�v:");
define("LCLAN_CAT_14", "Le�r�s:");
define("LCLAN_CAT_15", "�j ikon felt�lt�se:");
define("LCLAN_CAT_16", "Auto-Thumbnail m�ret:");
define("LCLAN_CAT_17", "Ez a lehet�s�g letiltva, mint f�ljfelt�lt�s nem enged�lyezett a szerveren");
define("LCLAN_CAT_18", "A");
define("LCLAN_CAT_19", "mappa nem �rhat�, a felt�lt�s el�tt �ll�tsd a jogosults�got CHMOD 777-re");
define("LCLAN_CAT_20", "px");
define("LCLAN_CAT_21", "Felt�lt�s");
define("LCLAN_CAT_22", "V�lassz egy ikont:");
define("LCLAN_CAT_23", "K�pek megtekint�se");
define("LCLAN_CAT_24", "El�rhet�s�g:");
define("LCLAN_CAT_25", "Jel�ld be a d�tumb�lyeg friss�t�s�hez");
define("LCLAN_CAT_26", "Link kateg�ria friss�t�se");
define("LCLAN_CAT_27", "Formula t�rl�se");
define("LCLAN_CAT_28", "Link kateg�ria l�trehoz�sa");
define("LCLAN_CAT_29", "Link Kateg�ria");

define("LCLAN_ITEM_1", "Bek�ldte");
define("LCLAN_ITEM_2", "Kateg�ria:");
define("LCLAN_ITEM_3", "m�g nincsennek kateg�ri�k");
define("LCLAN_ITEM_4", "N�v:");
define("LCLAN_ITEM_5", "Url:");
define("LCLAN_ITEM_6", "Le�r�s:");
define("LCLAN_ITEM_7", "Ikon felt�lt�se:");
define("LCLAN_ITEM_8", "Auto-Thumbnail m�ret:");
define("LCLAN_ITEM_9", "Ez a lehet�s�g letiltva, mint f�ljfelt�lt�s nem enged�lyezett a szerveren");
define("LCLAN_ITEM_10", "A (az)");
define("LCLAN_ITEM_11", "mappa nem �rhat�, a felt�lt�s el�tt �ll�tsd a jogosults�got CHMOD 777-re");
define("LCLAN_ITEM_12", "px");
define("LCLAN_ITEM_13", "Felt�lt�s");
define("LCLAN_ITEM_14", "V�lassz egy ikont:");
define("LCLAN_ITEM_15", "K�pek megtekint�se");
define("LCLAN_ITEM_16", "Megnyit�s m�dszere:");
define("LCLAN_ITEM_17", "Megnyit�s azonos ablakban");
define("LCLAN_ITEM_18", "Megnyit�s �j ablakban");
define("LCLAN_ITEM_19", "Megnyit�s 600x400 ablakban");
define("LCLAN_ITEM_20", "Megtekint�s:");
define("LCLAN_ITEM_21", "Jel�ld be a jelenlegi d�tumra t�rt�n� friss�t�shez");
define("LCLAN_ITEM_22", "Link friss�t�sa");
define("LCLAN_ITEM_23", "Link l�trehoz�sa");
define("LCLAN_ITEM_24", "Linkek");
define("LCLAN_ITEM_25", "K�p");
define("LCLAN_ITEM_26", "Link Neve");
define("LCLAN_ITEM_27", "Be�ll�t�sok");
define("LCLAN_ITEM_28", "�thelyez�s");
define("LCLAN_ITEM_29", "Sorrend");
define("LCLAN_ITEM_30", "�j sorrend");
define("LCLAN_ITEM_31", "M�dos�t�s");
define("LCLAN_ITEM_32", "T�rl�s");
define("LCLAN_ITEM_33", "Biztosan t�r�lni akarod ezt a linket?");
define("LCLAN_ITEM_34", "nincs ikon");
define("LCLAN_ITEM_35", "Szem�lyes linkek karbantart�sa");
define("LCLAN_ITEM_36", "Mehet");
define("LCLAN_ITEM_37", "�sszes link megtekint�se");
define("LCLAN_ITEM_38", "�sszes link");
define("LCLAN_ITEM_39", "�rt�kel�s");

define("LCLAN_ADMINMENU_1", "Link Be�ll�t�sok");
define("LCLAN_ADMINMENU_2", "Link Kateg�ri�k Karbantart�sa");
define("LCLAN_ADMINMENU_3", "Link Kateg�ria l�trehoz�sa");
define("LCLAN_ADMINMENU_4", "Linkek karbantart�sa");
define("LCLAN_ADMINMENU_5", "Link l�trehoz�sa");
define("LCLAN_ADMINMENU_6", "Be�ll�t�sok");
define("LCLAN_ADMINMENU_7", "Bek�ld�tt linkek");
define("LCLAN_ADMINMENU_8", "Kateg�ri�k");

define("NT_LAN_LP_1", "Link oldal esem�nyek");
define("NT_LAN_LP_2", "Linket bek�ldte");
define("NT_LAN_LP_3", "Link bek�ldve");

define("LNK_SCH_LAN_2", "�sszes link kateg�ria");
define("LNK_SCH_LAN_3", "�sszes link r�szletez�s");

define("LAN_LINKS_MANAGER_0", "Ikon");
define("LAN_LINKS_MANAGER_1", "Link");
define("LAN_LINKS_MANAGER_2", "Be�ll�t�sok");
define("LAN_LINKS_MANAGER_3", "�j link l�trehoz�sa");
define("LAN_LINKS_MANAGER_4", "Jelenleg nincsennek linkek");
define("LAN_LINKS_MANAGER_5", "Kateg�ria");
define("LAN_LINKS_MANAGER_6", "");
define("LAN_LINKS_MANAGER_7", "");
define("LAN_LINKS_MANAGER_8", "");
define("LAN_LINKS_MANAGER_9", "");

define("LAN_LINKS_1", "�sszes link");
define("LAN_LINKS_2", "�sszes akt�v link");
define("LAN_LINKS_3", "Anonymous");
define("LAN_LINKS_4", "Fejr�sz");
define("LAN_LINKS_5", "url");
define("LAN_LINKS_6", "Sorrend");
define("LAN_LINKS_7", "Hivatkoz�s");
define("LAN_LINKS_8", "N�vekv�");
define("LAN_LINKS_9", "Cs�kken�");
define("LAN_LINKS_10", "Top Linkek : Hivatkoz�s");
define("LAN_LINKS_11", "Top Linkek : �rt�kel�s");
define("LAN_LINKS_12", "Linkek megtekint�se hivatkoz�s szerint");
define("LAN_LINKS_13", "Linkek megtekint�se �rt�kel�s szerint");
define("LAN_LINKS_14", "Linkek f�oldal");
define("LAN_LINKS_15", "Rendez�s");
define("LAN_LINKS_16", "ebben a kateg�ri�ban");
define("LAN_LINKS_17", "Link");
define("LAN_LINKS_18", "Linkek");
define("LAN_LINKS_19", "Kateg�ri�k");
define("LAN_LINKS_20", "Kateg�ria");
define("LAN_LINKS_21", "Ott");
define("LAN_LINKS_22", "van");
define("LAN_LINKS_23", "van");
define("LAN_LINKS_24", "�sszesen");
define("LAN_LINKS_25", "�sszes Link Mutat�sa");
define("LAN_LINKS_26", "Hivatkoz�s:");
define("LAN_LINKS_27", "Link bek�ld�se");
define("LAN_LINKS_28", "K�sz�nj�k!");
define("LAN_LINKS_29", "A bek�ld�tt linkedet az oldal adminisztr�tora ellen�rizni fogja.");
define("LAN_LINKS_30", "Link Kateg�ri�k");
define("LAN_LINKS_31", "Link bek�ld�se");
define("LAN_LINKS_32", "Kateg�ria:");
define("LAN_LINKS_33", "M�g nincs �rt�kelve.");
define("LAN_LINKS_34", "Jelenleg nincsennek linkek");
define("LAN_LINKS_35", "szem�lyes linkek karbantart�sa");
define("LAN_LINKS_36", "Link hozz�sz�l�sok");
define("LAN_LINKS_37", "Hozz�sz�l�s:");
define("LAN_LINKS_38", "D�tum");
define("LAN_LINKS_39", "Linkek");
define("LAN_LINKS_40", "Kateg�ria");
define("LAN_LINKS_41", "m�g nincsennek kateg�ri�k");
define("LAN_LINKS_42", "m�g nincsennek hivatkozott linkek");
define("LAN_LINKS_43", "�sszes kateg�ria megtekint�se");
define("LAN_LINKS_44", "id");
define("LAN_LINKS_45", "Link Kateg�ria");
define("LAN_LINKS_46", "Link Alkateg�ria");
define("LAN_LINKS_47", "link navig�tor...");
define("LAN_LINKS_48", "-- Kateg�ria megtekint�se --");
define("LAN_LINKS_49", "");
define("LAN_LINKS_50", "Jelenleg nem rendelkezel link bek�ld�s jogosults�ggal");

define('LAN_LINKS_SCH_1','V�lasz a linkhez');

define("LAN_ADMIN_HELP_0", "Linkoldal - S�g�");

define("LAN_ADMIN_HELP_1", "<i>A kateg�ri�k karbantart�s�hoz jelenleg minden kateg�ria megjelenik az oldalon.</i><br /><br /><b>R�szletes lista</b><br />L�thatsz egy kateg�ria list�t ikonnal, le�r�ssal, be�ll�t�si lehet�s�gekkel �s sorrendi be�ll�t�ssal.<br /><br /><b>Ikonok �rtelmez�se</b><br />
".LINK_ICON_LINK." : Link a kateg�ri�hoz<br /><br />
".LINK_ICON_EDIT." : Kateg�ria m�dos�t�sa<br /><br />
".LINK_ICON_DELETE." : Kateg�ria t�rl�se<br /><br />
".LINK_ICON_ORDER_UP." : A felfel� mutat� ny�l seg�ts�g�vel a kateg�ri�t el�re mozgathatod a sorrendben.<br /><br />
".LINK_ICON_ORDER_DOWN." : A lefel� mutat� ny�l seg�ts�g�vel a kateg�ri�t h�tra mozgathatod a sorrendben.<br />
<br />
<b>Sorrend</b><br />Itt manu�lisan megv�ltoztathatod az �sszes kateg�ria sorrendj�t. Meg kell v�ltoztatnod a kiv�laszt�dobozban l�v� �rt�ket az �ltalad k�v�ntra, majd meg kell nyomnod az �j sorrend gombot az elment�shez.<br />");

define("LAN_ADMIN_HELP_2", "<i>A link kateg�ri�k l�trehoz�sa oldalon hozz�adhatod az �j link kateg�ri�kat</i><br /><br />Felt�lthetsz �j ikont, a felt�lt�s ut�n hozz�rendelheted az adott kateg�ri�hoz.");
define("LAN_ADMIN_HELP_3", "<i>A linkek karbantart�sa oldalon el�sz�r megjelenik az �sszes kateg�ria.</i><br /><br />".LINK_ICON_LINK." : link a kateg�ri�hoz<br /><br />".LINK_ICON_EDIT." : katt az ikonra a kateg�ri�ban l�v� �sszes link megjelen�t�s�hez<br />");
define("LAN_ADMIN_HELP_4", "<i>A link l�trehoz�sa oldalon hozz�adhatsz �j linket</i><br /><br />Felt�lthetsz egy �j ikont, majd hozz�rendelheted a linkhez.<br /><br />A megnyit�s m�dszere lehet�s�get biztos�t, hogy meghat�rozd, hogyan ny�ljon meg a link, ha a felhaszn�l� r�kattint.");
define("LAN_ADMIN_HELP_5", "<i>A bek�ld�tt linkek oldalon megjelenik az �sszes, felhaszn�l�k �ltal bek�ld�tt link</i><br /><br /><b>R�szletes lista</b><br />L�thatod a link url-j�t, a felhaszn�l� nev�t, aki bek�ldte a linket �s a be�ll�t�si lehet�s�geket.<br /><br /><b>Ikonok jelent�se</b><br />
".LINK_ICON_EDIT." : Bek�ld�tt link �thelyez�se a l�trehoz�si formul�ba<br /><br />
".LINK_ICON_DELETE." : Bek�ld�tt link t�rl�se<br />
");
define("LAN_ADMIN_HELP_6", "<i>A be�ll�t�sok oldalon megv�ltoztathatod a linkek oldal plugin viselked�s�t</i><br /><br />
�ltal�nos be�ll�t�sok<br />
Ezeket a be�ll�t�sokat haszn�lja a teljes linkek oldal.<br /><br />
Szem�lyes link kezel�<br />
A szem�lyes link kezel� jogosults�gokat ad a felhaszn�l�knak, hogy karbantarts�k saj�t saj�t bek�ld�tt linkj�ket.<br /><br />
Kateg�ria oldal<br />
Itt megv�ltoztathatod a kateg�ria oldal be�ll�t�sait.<br /><br />
Linkek megjelen�t�se oldal<br />
Ezeket a be�ll�t�sokat alkalmazza a linkek oldal.<br /><br />
Hivatkoz�s oldal<br />
Ezeket a be�ll�t�sokat alkalmazza a Top hivatkoz�s link oldal.<br /><br />
�rt�kel�s oldal<br />
Ezeket a be�ll�t�sokat alkalmazza a Top �rt�kel�s link oldal.<br />
");

define("LAN_ADMIN_HELP_7", "<i>A link kateg�ria m�dos�t�sa oldalon m�dos�thatod a l�tez� link kateg�ri�kat</i><br /><br />Felt�lthetsz �j ikont, majd hozz�rendelheted a kateg�ri�hoz.<br />Fel�l�rhatod a d�tumot a jel�l�doboz bejel�l�s�vel.");

define("LAN_ADMIN_HELP_8", "<i>Ezen az oldalon megjelenik az adott kateg�ri�ban l�v� �sszes link.</i><br /><br /><b>R�szletes lista</b><br />L�thatod a linkek list�j�t, k�peiket, nev�ket, be�ll�t�sukat �s sorrendi elhelyezked�s�ket.<br /><br /><b>Ikonok jelent�se</b><br />
".LINK_ICON_LINK." : Link a F�oldalra<br /><br />
".LINK_ICON_EDIT." : Link m�dos�t�sa<br /><br />
".LINK_ICON_DELETE." : Link t�rl�se<br /><br />
".LINK_ICON_ORDER_UP." : A fel gombbal mozgathatod a linket el�re a sorrendben.<br /><br />
".LINK_ICON_ORDER_DOWN." : A le gombbal mozgathatod a linket h�tra a sorban.<br />
<br />
<b>Sorrend</b><br />Itt manu�lisan kiv�laszthatod a linkek sorrendj�t. V�ltoztasd meg a kiv�laszt�dobozban l�v� �rt�ket az �ltalad k�v�nt �rt�kre �s nyomd meg az �j sorrend gombot a sorrend elment�s�hez.<br />");

define("LAN_ADMIN_HELP_9", "<i>A m�dos�t�s oldalon szerkesztheted a megl�v� linkeket</i><br /><br />Felt�lthetsz �j ikont, majd hozz�rendelheted a linkhez.<br /><br />A megnyit�s m�dszer�n�l be�ll�thatod, hogy ny�ljon meg a link, ha a felhaszn�l� r�kattint.");
define("LAN_ADMIN_HELP_10", "<i>A bek�ld�tt linkek oldalon hozz�adhatod a bek�ld�tt linket a megl�v�kh�z</i><br /><br />Egy kis bek�ld�tt sz�veg van a le�r�s mez�h�z.<br /><br />Felt�lthetsz egy �j ikont, majd hozz�adhatod a linkhez.<br /><br />A megnyit�s m�szer�n�l be�ll�thatod, hogyan ny�ljon meg a link, ha a felhaszn�l� r�kattint.");
?>
