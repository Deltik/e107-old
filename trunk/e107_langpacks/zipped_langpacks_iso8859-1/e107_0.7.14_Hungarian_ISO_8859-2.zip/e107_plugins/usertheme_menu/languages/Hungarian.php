<?php
# --------------------------------------------------------------------------
# e107 Hungarian language file - $Version: 1.00 $ - $Author: e107hungary.org team $ - $Date: 2008 $
# --------------------------------------------------------------------------

define('LAN_UMENU_THEME_1', 'Theme kiv�laszt�s');
define('LAN_UMENU_THEME_2', 'Theme kiv�laszt�sa');
define('LAN_UMENU_THEME_3', 'felhaszn�l�k:');
define('LAN_UMENU_THEME_4', 'Azon theme-k enged�lyez�se, melyeket a felhaszn�l�k kiv�laszthatnak');
define('LAN_UMENU_THEME_5', 'Friss�t�s');
define('LAN_UMENU_THEME_6', 'A felhaszn�l�k rendelkez�s�re �ll� theme-k');
define('LAN_UMENU_THEME_7', 'Csoport, amely theme-ket tud v�lasztani');

?>