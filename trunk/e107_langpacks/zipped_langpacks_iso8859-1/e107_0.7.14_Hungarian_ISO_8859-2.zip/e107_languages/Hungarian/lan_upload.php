<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Felt�lt�s");

define('LAN_UL_001','�rv�nytelen email c�m');
define('LAN_UL_002', 'Nincs jogosults�god file felt�lt�sre erre a szerverre.');	// LAN_403

define('LAN_UL_020', 'Hiba');
define('LAN_UL_021', 'Felt�lt�s sikertelen');

define("LAN_61", "Neved: ");
define("LAN_112", "E-mail c�med: ");
define("LAN_144", "Weboldal URL c�me: ");
define("LAN_402", "A felt�lt�shez regisztr�lnod kell.");
define("LAN_404", "K�sz�nj�k. A felt�lt�tt f�jlt az adminisztr�tor ellen�rizni fogja, ha megfelel a k�vetelm�nyeknek, akkor kirakja az oldalra.");
// define("LAN_405", "A f�jl meghaladta a maxim�lis m�retet, ez�rt t�rl�sre ker�lt.");
define("LAN_406", "Figyelem");
define("LAN_407", "B�rmely m�s t�pus� f�jl azonnali t�rl�sre ker�l.");
define("LAN_408", "Az al�h�zott");
define("LAN_409", "F�jl neve");
define("LAN_410", "Verzi�");
define("LAN_411", "F�jl");
define("LAN_412", "K�perny�k�p");
define("LAN_413", "Le�r�s");
define("LAN_414", "Dem�");
define("LAN_415", "Add meg az oldal URL c�m�t, ahol a dem� el�rhet�");
define("LAN_416", "Felt�lt�s");
define("LAN_417", "F�jl felt�lt�se");
define("LAN_418", "Maxim�lis f�jlm�ret: ");
define("DOWLAN_11", "Kateg�ria");
define("LAN_419", "Enged�lyezett f�jlt�pusok:");
define("LAN_420", "mez�k kit�lt�se k�telez�");
?>
