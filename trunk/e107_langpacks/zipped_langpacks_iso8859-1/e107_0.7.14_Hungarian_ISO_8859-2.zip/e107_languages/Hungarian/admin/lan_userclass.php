<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Hungarian/admin/lan_userclass.php,v $
|     $Revision: 1.3 $
|     $Date: 2008/04/04 21:03:58 $
|     $Author: e107hungary.org team $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "�rtes�t�s k�ld�se");
define("UCSLAN_2", "Jogosults�gok friss�t�se");
define("UCSLAN_3", "Kedves");
define("UCSLAN_4", "Jogosults�gaid friss�tve a k�vetkez� oldalon:");
define("UCSLAN_5", "Mostant�l el�rheted a k�vetkez� r�szleg(ek)et:");
define("UCSLAN_6", "Csoport be�ll�t�sa felhaszn�l�ra");
define("UCSLAN_7", "Csoport be�ll�t�sa");
define("UCSLAN_8", "Felhaszn�l� �rtes�t�se");
define("UCSLAN_9", "Csoportok friss�tve");
define("UCSLAN_10", "�dv�zlettel");
define('UCSLAN_12', 'Csak tags�g joggal');
?>