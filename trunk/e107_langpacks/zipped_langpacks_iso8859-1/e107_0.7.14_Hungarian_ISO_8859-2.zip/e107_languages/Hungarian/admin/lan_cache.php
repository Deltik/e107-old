<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CACLAN_1", "Cache rendszer �llapot");
define("CACLAN_2", "Cache bekapcsol�sa");
define("CACLAN_3", "Cache rendszer");
define("CACLAN_4", "Cache bekapcsolva");
define("CACLAN_5", "Cache �r�t�se");
define("CACLAN_6", "Cache ki�r�tve");

define("CACLAN_7", "Cache kikapcsol�sa");
// define("CACLAN_8", "Cache adat ment�se a MySQL adatb�zisba");
define("CACLAN_9", "Cache tartalm�nak ment�se f�jlba");
define("CACLAN_10", "A cache k�nyvt�r nem �rhat�. Ellen�rizd, hogy a szerver megfelel� jogosults�gokkal rendelkezik az e107_files/cache mapp�n. Ha nem, adj CHMOD 0777-et a mapp�ra");
?>