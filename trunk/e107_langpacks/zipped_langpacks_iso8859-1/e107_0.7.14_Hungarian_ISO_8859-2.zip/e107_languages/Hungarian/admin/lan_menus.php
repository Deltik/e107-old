<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("MENLAN_1", "Mindenki �ltal l�that�");
define("MENLAN_2", "Csak a tagok �ltal l�that�");
define("MENLAN_3", "Csak az adminok �ltal l�that�");
define("MENLAN_4", "Csak a(z)");
//define("MENLAN_5", "csoportban l�v� felhaszn�l�k sz�m�ra l�that�");
define("MENLAN_6", "Mehet");
define("MENLAN_7", "Csoport be�ll�t�sa");
define("MENLAN_8", "Csoport friss�tve");
define("MENLAN_9", "�j saj�t men� telep�tve");
define("MENLAN_10", "�j men� telep�tve");
define("MENLAN_11", "Men� elt�vol�tva");
define("MENLAN_12", "Men� aktiv�l�sa - v�laszd ki hol legyen");
define("MENLAN_13", "Aktiv�l�s: Ter�let");
define("MENLAN_14", "Ter�let");
define("MENLAN_15", "Kikapcsol�s");
define("MENLAN_16", "Be�ll�t�sok");
define("MENLAN_17", "Fel");
define("MENLAN_18", "Le");
define("MENLAN_19", "Mozgat: Ter�let");
define("MENLAN_20", "El�rhet�s�g");

//define("MENLAN_21", "Csak a Vend�gek sz�m�ra l�that�");
define("MENLAN_22", "Kikapcsolt men�k");

define("MENLAN_23", "Mozgat�s alulra");
define("MENLAN_24", "Mozgat�s fel�lre");
define("MENLAN_25", "Funkci� ...");

define("MENLAN_26", "Ez a men� csak a k�vetkez� oldalakon lesz <strong>l�that�</strong>");
define("MENLAN_27", "Ez a men� csak a k�vetkez� oldalakon lesz <strong>rejtett</strong>");
define("MENLAN_28", "Minden sorba egy oldalt adj meg, a sz�ks�ges el�r�si �ttal");

define("MENLAN_29", "Elrendez�s kiv�laszt�sa");
define("MENLAN_30", "Az egy�ni elrendez�s men�ter�leteinek �s azok poz�ci�inak megtekint�s�hez v�lassz egy egy�ni elrendez�st:");
define("MENLAN_31", "Alap�rtelmezett elrendez�s");
define("MENLAN_32", "Newsheader elrendez�s");
define("MENLAN_33", "Egy�ni elrendez�s");
define("MENLAN_34", "Be�gyazott");
define("MENLAN_35", "Men�k be�ll�t�sa");
define("MENLAN_36", "V�laszd ki az aktiv�land� men�(ke)t,");
define("MENLAN_37", "majd v�laszd ki, hol legyenek akt�vak.");
define("MENLAN_38", "Tartsd lenyomva a CTRL -t t�bb men� kiv�laszt�s�hoz.");
?>