<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/newspost.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:45 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "�j h�r - S�g�";
$text = "<b>�ltal�nos</b><br />
A t�rzs a f�oldalon fog megjelenni, m�g a b�v�tett a 'Tov�bb' linkre kattintva lesz olvashat�.
<br />
<br />
<b>Csak a c�m mutat�sa</b>
<br />
Ennek enged�lyez�sekor a f�oldalon csak a h�r c�me jelenik meg,egy kattinthat� linkkel a teljes sz�veghez.
<br /><br />
<b>Aktiv�l�s</b>
<br />
Ha megadsz egy kezd�si �s/vagy befejez�si d�tumot, akkor a cikk csak a k�t id�pont k�zt jelenik meg.
";
$ns -> tablerender($caption, $text);
?>
