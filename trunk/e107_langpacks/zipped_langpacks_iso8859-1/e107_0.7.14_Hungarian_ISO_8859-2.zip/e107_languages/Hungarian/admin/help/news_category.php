<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/news_category.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Elk�l�n�theted a h�reket k�l�nb�z� kateg�ri�kba, enged�lyezheted a l�togat�knak csak azon a kateg�ri�nak a h�reinek megjelen�t�s�t. <br /><br />T�ltsd fel a h�r ikonokat vagy a ".e_THEME."-yourtheme-/images/ vagy a themes/shared/newsicons/ mapp�ba.";
$ns -> tablerender("H�r Kateg�ria - S�g�", $text);
?>
