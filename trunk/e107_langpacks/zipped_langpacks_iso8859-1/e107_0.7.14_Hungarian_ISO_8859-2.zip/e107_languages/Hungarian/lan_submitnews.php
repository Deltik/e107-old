<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "H�r bek�ld�se");
define("LAN_7", "Felhaszn�l�n�v: ");
define("LAN_62", "C�m: ");
define("LAN_112", "Email c�m: ");
define("LAN_133", "K�sz�nj�k!");
define("LAN_134", "A bek�ld�tt h�rt r�gz�tett�k. Amint tudjuk ellen�rizz�k.");
define("LAN_135", "H�r: ");
define("LAN_136", "H�r bek�ld�se");
define("NWSLAN_6", "Kateg�ria");
define("NWSLAN_10", "Nincs h�rkateg�ria!");
define("NWSLAN_11", "Nincs jogosults�god h�r bek�ld�s�hez");
define("NWSLAN_12", "Hozz�f�r�s megtagadva");

define("SUBNEWSLAN_1", "Meg kell adnod egy c�met.\\n");
define("SUBNEWSLAN_2", "Meg kell adnod n�mi sz�veget.\\n");
define("SUBNEWSLAN_3", "Csatolt k�p enged�lyezett form�tumai: jpg, gif �s png");
define("SUBNEWSLAN_4", "T�l nagy file");
define("SUBNEWSLAN_5", "K�pf�jl");
define("SUBNEWSLAN_6", "(jpg, gif vagy png)");

?>
