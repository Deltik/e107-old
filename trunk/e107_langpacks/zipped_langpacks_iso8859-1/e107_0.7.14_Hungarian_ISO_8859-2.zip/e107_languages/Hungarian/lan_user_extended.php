<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UE_LAN_1", "Sz�vegmez�");
define("UE_LAN_2", "R�di�gombok");
define("UE_LAN_3", "Leny�l� men�");
define("UE_LAN_4", "Adatb�zis t�bla mez�");
define("UE_LAN_5", "Sz�vegmez�");
define("UE_LAN_6", "Eg�sz");
define("UE_LAN_7", "D�tum");
define("UE_LAN_8", "Nyelv");

define("UE_LAN_9", "N�v");
define("UE_LAN_10", "T�pus");
define("UE_LAN_11", "Haszn�lat");

define("UE_LAN_HIDE", "Elrejt�s");

define("UE_LAN_LOCATION", "Lak�hely");
define("UE_LAN_LOCATION_DESC", "Felhaszn�l� lak�helye");
define("UE_LAN_AIM", "AIM c�m");
define("UE_LAN_AIM_DESC", "AIM c�m");
define("UE_LAN_ICQ", "ICQ sz�m");
define("UE_LAN_ICQ_DESC", "ICQ sz�m");
define("UE_LAN_YAHOO", "Yahoo! c�m");
define("UE_LAN_YAHOO_DESC", "Yahoo! c�m");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN c�m");
define("UE_LAN_HOMEPAGE", "Weboldal");
define("UE_LAN_HOMEPAGE_DESC", "Felhaszn�l� weboldala (url)");
define("UE_LAN_BIRTHDAY", "Sz�let�snap");
define("UE_LAN_BIRTHDAY_DESC", "Sz�let�snap");
define("UE_LAN_LANGUAGE", "Nyelv");
define("UE_LAN_LANGUAGE_DESC", "Felhaszn�l� Nyelv");
define("UE_LAN_COUNTRY", "Orsz�g");
define("UE_LAN_COUNTRY_DESC", "Felhaszn�l� Orsz�g (includes db table)");

define("LAN_UE_FAIL_HOMEPAGE", "�rv�nytelen bejegyz�s a weboldal be�ll�t�sokhoz");
?>
