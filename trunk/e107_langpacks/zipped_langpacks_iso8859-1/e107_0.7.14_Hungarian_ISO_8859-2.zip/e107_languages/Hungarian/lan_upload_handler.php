<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LANUPLOAD_1", "A f�jlt�pus");
define("LANUPLOAD_2", "nem enged�lyezett, t�r�lve lett.");
define("LANUPLOAD_3", "Sikeresen felt�ltve");
define("LANUPLOAD_4", "A c�lk�nyvt�r nem l�tezik, vagy nem �rhat�.");
define("LANUPLOAD_5", "A file t�ll�pte a php.ini -ben meghat�rozott maxim�lis m�retet.");
define("LANUPLOAD_6", "A file t�ll�pte a HTML formul�ban meghat�rozott maxim�lis m�retet.");
define("LANUPLOAD_7", "A file csak r�szben lett felt�ltve.");
define("LANUPLOAD_8", "Nem lett semmi felt�ltve.");
define("LANUPLOAD_9", "Felt�lt�tt filem�ret: 0 byte");
define("LANUPLOAD_10", "A felt�lt�s nem siker�lt [Duplik�lt f�jln�v] - M�r van ilyen nev� f�jl.");
define("LANUPLOAD_11", "A f�jl nem lett felt�ltve. F�jln�v: ");
define("LANUPLOAD_12", "Hiba");
define("LANUPLOAD_13", "Hi�nyzik az ideiglenes mappa");
define("LANUPLOAD_14", "File �r�s hib�s");
define("LANUPLOAD_15", "Felt�lt�s nem enged�lyezett");
define("LANUPLOAD_16", "Ismeretlen hiba");
define("LANUPLOAD_17", "Felt�lt�tt file �rv�nytelen file n�v");
define("LANUPLOAD_18", "A felt�lt�tt file t�ll�pte a megengedett hat�r�rt�ket.");
define("LANUPLOAD_19", "T�l sok a felt�lt�tt file - t�bblet t�r�lve.");
?>
