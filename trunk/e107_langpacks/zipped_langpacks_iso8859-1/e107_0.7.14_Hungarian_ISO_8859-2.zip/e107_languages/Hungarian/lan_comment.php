<?php
# --------------------------------------------------------------------------
# e107 Hungarian language file - $Version: 1.14 $ - $Author: e107hungary.org team $ - $Date: 2008 $
# --------------------------------------------------------------------------


define("COMLAN_0", "[admin blokkolta]");
define("COMLAN_1", "Enged�lyez�s");
define("COMLAN_2", "Letilt�s");
define("COMLAN_3", "T�rl�s");
define("COMLAN_4", "Info");
define("COMLAN_5", "Hozz�sz�l�sok ...");
define("COMLAN_6", "Hozz�sz�l�s k�ld�s�hez be kell jelentkezned. Jelentkezz be, vagy kattints");
define("COMLAN_7", "F� adminisztr�tor");
define("COMLAN_8", "Hozz�sz�l�sok");
define("COMLAN_9", "Hozz�sz�l�s k�ld�se");
define("COMLAN_10", "Adminisztr�tor");
define("COMLAN_11", "A hozz�sz�l�s r�gz�t�se az adatb�zisban sikertelen. �rd be �jra a sz�veget, nem szabv�nyos, speci�lis karakter n�lk�l.");
define("COMLAN_16", "Felhaszn�l�n�v: ");
define("COMLAN_99", "Hozz�sz�l�s");
define("COMLAN_100", "H�rek");
define("COMLAN_101", "Szavaz�s");
define("COMLAN_102", "V�lasz: ");
define("COMLAN_103", "Cikk");
define("COMLAN_104", "Le�r�s");
define("COMLAN_105", "Tartalom");
define("COMLAN_106", "Let�lt�s");
define("COMLAN_145", "Regisztr�lt: ");
define("COMLAN_194", "Vend�g");
define("COMLAN_195", "Regisztr�lt tag");
define("COMLAN_310", "Ez a felhaszn�l�n�v m�r regisztr�lva van. Ha a tied, akkor jelentkezz be.");
define("COMLAN_312", "Dupl�z�s - nem elfogadhat�.");
define("COMLAN_313", "Lakhely");
define("COMLAN_314", "hozz�sz�l�sok moder�l�sa");
define("COMLAN_315", "Trackback");
define("COMLAN_316", "Nincs trackbacks a h�rhez.");
define("COMLAN_317", "Trackback moder�l�sa");
define("COMLAN_318", "Hozz�sz�l�s m�dos�t�sa");
define("COMLAN_319", "m�dos�tva");
define("COMLAN_320", "Hozz�sz�l�s friss�t�se");
define("COMLAN_321", "ide");
define("COMLAN_322", "a regisztr�ci�hoz");
define("COMLAN_323", "Hiba!");
define("COMLAN_324", 'T�rgy');
define("COMLAN_325", 'V�lasz:');
define("COMLAN_326", 'V�lasz erre');
define("COMLAN_327", '�rt�kel�s');
define("COMLAN_328", 'Hozz�sz�l�s kikapcsolva');
define("COMLAN_329", 'Jogosulatlan');
define("COMLAN_330", 'IP:');

define("COMLAN_TYPE_1", "H�rek");
define("COMLAN_TYPE_2", "Let�lt�s");
define("COMLAN_TYPE_3", "GYIK");
define("COMLAN_TYPE_4", "Szavaz�s");
define("COMLAN_TYPE_5", "Dokument�ci�");
define("COMLAN_TYPE_6", "Hibajelenz�s");
define("COMLAN_TYPE_7", "�tletek");
define("COMLAN_TYPE_8", "Felhaszn�l� Profil");
define("COMLAN_TYPE_PAGE", "Tartalom");		// Reall custom page, but use a 'non-technical' description

?>
