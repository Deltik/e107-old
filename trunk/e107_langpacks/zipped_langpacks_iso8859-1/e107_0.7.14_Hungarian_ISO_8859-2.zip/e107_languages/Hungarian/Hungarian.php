<?php
# ------------------------------------------------------------------------------------------------------------------
# e107 hungarian language file - $Revision: 1.13 $ - $author: e107hungary.org team $ - $Date: 2008/10/19 11:33:43 $
# ------------------------------------------------------------------------------------------------------------------

setlocale(LC_ALL, 'hu_HU.ISO8859-2', 'hu_HU@euro', 'hu_HU', 'hu', 'Hungarian');
define("CORE_LC", 'hu');
define("CORE_LC2", 'HU.iso-8859-2');
// define("TEXTDIRECTION","rtl");
define("CHARSET", "iso-8859-2");  // for a true multi-language site. :)
define("CORE_LAN1","Hiba : A t�ma hi�nyzik.\\n\\nCser�ld le a be�ll�t�sokn�l a haszn�lt t�m�t (admin ter�let) vagy t�lts fel az aktu�lis t�ma file-it a szerverre.");

//v.616
define("CORE_LAN2", " \\1 �rta:");// "\\1" represents the username.
define("CORE_LAN3", "f�jl csatol�sa nem enged�lyezett");

//v0.7+
define("CORE_LAN4", "T�r�ld az install.php file-t a szerveredr�l");
define("CORE_LAN5", "ha nem hajtod v�gre, akkor az oldalad potenci�lis biztons�gi kock�zatnak van kit�ve");

// v0.7.6
define("CORE_LAN6", "A flood v�delem ezen az oldalon aktiv�lva van �s figyelmeztet t�ged, ha folytatod az oldal folyamatos lek�rdez�s�t, akkor ki leszel tiltva.");
define("CORE_LAN7", "A mag (Core) megkis�rli a helyre�ll�t�st az aut�matikus biztons�gi ment�sb�l.");
define("CORE_LAN8", "Mag (Core) be�ll�t�sok Hiba");
define("CORE_LAN9", "A mag (Core) nem tudja a vissza�ll�t�st v�grehajtani az aut�matikus ment�sb�l. V�grehajt�s megszak�tva.");
define("CORE_LAN10", "Hib�s cookie �szlel�se - Kijelentkezett.");

// Footer
define("CORE_LAN11", "Oldal l�trehoz�si id�: ");
define("CORE_LAN12", " m�sodperc, ");
define("CORE_LAN13", " lek�rdez�si id�. ");
define("CORE_LAN14", "");			// Used in 0.8
define("CORE_LAN15", "Adatb�zis lek�rdez�s: ");
define("CORE_LAN16", "Mem�ria haszn�lat: ");

// img.bb
define('CORE_LAN17', '[ K�p letiltva ]');
define('CORE_LAN18', 'K�p: ');

define("CORE_LAN_B", "b");
define("CORE_LAN_KB", "kb");
define("CORE_LAN_MB", "Mb");
define("CORE_LAN_GB", "Gb");
define("CORE_LAN_TB", "Tb");


define("LAN_WARNING", "Figyelmeztet�s!");
define("LAN_ERROR", "Hiba");
define("LAN_ANONYMOUS", "Anonymous");
define("LAN_EMAIL_SUBS", "-Email-");

?>
