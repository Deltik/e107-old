<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/leaf/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/12/01 21:56:48 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Comentario(s) ");
define("LAN_THEME_2", "Comentarios desactivados para este art�culo");
define("LAN_THEME_3", "Comentario(s) ");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Comentario de");
define("LAN_THEME_7", "Noticias");
?>