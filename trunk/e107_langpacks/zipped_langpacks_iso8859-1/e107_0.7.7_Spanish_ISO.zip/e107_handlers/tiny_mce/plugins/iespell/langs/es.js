/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/iespell/langs/es.js,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
iespell_desc : 'Ejecutar corrector ortogr�fico',
iespell_download : "ieSpell no detectado. Haga click en OK para ir a la p�gina de descarga."
});

