<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_frontpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Actualizados los ajustes de la p�gina.");
define("FRTLAN_2", "Mostrar");

define("FRTLAN_6", "Enlaces");
//define("FRTLAN_7", "P�gina de contenidos");

define("FRTLAN_12", "Actualizar par�metros de la p�gina");
define("FRTLAN_13", "Par�metros de la p�gina");

define("FRTLAN_15", "Otro (escribe url):");
define("FRTLAN_16", "Error: no hay contenido principal seleccionado");
define("FRTLAN_17", "Error: no hay subcategor�a de contenido seleccionado");
define("FRTLAN_18", "Error: no hay ning�n contenido seleccionado");
define("FRTLAN_19", "Contenido principal");
define("FRTLAN_20", "Categor�a de contenido");
define("FRTLAN_21", "Contenido");
//define("FRTLAN_22", "");
//define("FRTLAN_23", "");
//define("FRTLAN_24", "");
//define("FRTLAN_25", "");
define("FRTLAN_26", "Todos los usuarios");
define("FRTLAN_27", "Invitados");
define("FRTLAN_28", "Miembros");
define("FRTLAN_29", "Administradores");
define("FRTLAN_31", "Todos los usuarios");
define("FRTLAN_32", "Clase de usuario");
define("FRTLAN_33", "Par�metros actuales");
define("FRTLAN_34", "P�gina");
?>