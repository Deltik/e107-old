<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/prefs.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Sus preferencias le permiten especificar los ajustes importantes de su sitio, desde el nombre del sitio, protecci�n flood y filtros.";
$ns -> tablerender("Ayuda preferencias", $text);
?>