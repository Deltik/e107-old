<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/poll.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Puede configurar encuestas desde esta p�gina,
solo escriba en el t�tulo y opciones de la encuesta,
previsualice y si est� conforme marque la casilla para activar.<br /><br />
Para ver la votaci�n, vaya a su p�gina de men�s y verifique que el men� de encuestas est� activado.";

$ns -> tablerender("Encuestas", $text);
?>