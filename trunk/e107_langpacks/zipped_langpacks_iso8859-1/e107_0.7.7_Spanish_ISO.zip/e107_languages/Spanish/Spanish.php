<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/Spanish.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/11/10 19:17:11 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'SP');
define("CORE_LC", 'es');
define("CORE_LC2", 'es');
define("CHARSET", "iso-8859-1");
define("CORE_LAN1","Error : tema no encontrado.\\n\\nCambie el tema usado en preferencias (administraci�n) o copie los archivos del tema seleccionado al servidor.");
define("CORE_LAN2"," \\1 escribi�:");// "\\1" representa el nombre de usuario.
define("CORE_LAN3","archivo adjunto desactivado");

//v0.7+
define("CORE_LAN4", "Por favor, elimine install.php de su servidor");
define("CORE_LAN5", "Si no lo hace, pone en riesgo potencial su sitio web");
// v0.7.6 
define("CORE_LAN6", "La protecci�n por flood ha sido activada en este sitio y se le avisa que contin�a requeriendo p�ginas podr� ser baneado."); 
define("CORE_LAN7", "El n�cleo est� intentando recuperar ajustes del backup autom�tico."); 
define("CORE_LAN8", "Ajustes del n�cleo en error"); 
define("CORE_LAN9", "El n�cleo no puede recuperar del backup autom�tico. Ejecuci�n fallida."); 
define("CORE_LAN10", "Detectada cookie corrupta - desconectando."); 

define("LAN_WARNING", "�Atenci�n!"); 

define("LAN_ERROR", "Error");
define("LAN_ANONYMOUS", "An�nimo");
?>