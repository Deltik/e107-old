<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_userclass.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/07/01 20:56:55 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Todos (p�blico)");
define("UC_LAN_1", "Invitados");
define("UC_LAN_2", "Nadie (inactivo)");
define("UC_LAN_3", "Miembros");
define("UC_LAN_4", "Solo Lectura");
define("UC_LAN_5", "Administrador");
define("UC_LAN_6", "Admin Principal");
?>