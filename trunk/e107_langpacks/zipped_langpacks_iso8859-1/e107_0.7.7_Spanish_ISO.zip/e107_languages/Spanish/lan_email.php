<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_email.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/10/29 12:57:43 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }

define("LAN_EMAIL_1", "Desde:");
define("LAN_EMAIL_2", "Direcci�n IP del remitente:");
define("LAN_EMAIL_3", "Noticia desde ");
define("LAN_EMAIL_4", "Enviar email");
define("LAN_EMAIL_5", "Email a un amigo");
define("LAN_EMAIL_6", "Creo que estar�a interesado de este email de ");
define("LAN_EMAIL_7", "Enviar mail a alguien");
define("LAN_EMAIL_8", "Comentario"); 
define("LAN_EMAIL_9", "Lo sentimos - imposible enviar el correo"); 
define("LAN_EMAIL_10", "Correo enviado a"); 
define("LAN_EMAIL_11", "Correo enviado"); 
define("LAN_EMAIL_12", "Error"); 
define("LAN_EMAIL_13", "Enviar art�culo por correo a un amigo"); 
define("LAN_EMAIL_14", "Enviar noticia por correo a un amigo"); 
define("LAN_EMAIL_15", "Nombre conexi�n: "); 

define("LAN_EMAIL_106", "Esta no parece una direcci�n de email v�lida");

define("LAN_EMAIL_185", "Enviar art�culo");
define("LAN_EMAIL_186", "Enviar noticia");
define("LAN_EMAIL_187", "Email del destinatario");
define("LAN_EMAIL_188", "Espero que le guste esta noticia de");
define("LAN_EMAIL_189", "Espero que le guste este art�culo de");
define("LAN_EMAIL_190", "Entre c�digo visible");
?>