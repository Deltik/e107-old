<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/forum/languages/Spanish/lan_forum_conf.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/14 21:30:55 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FORLAN_1", "Tema cerrado.");
define("FORLAN_2", "Tema reabierto.");
define("FORLAN_3", "Tema pegado (fijo).");
define("FORLAN_4", "Tema sin atacar.");
define("FORLAN_5", "Votaci�n borrada.");
define("FORLAN_6", "Tema borrado");
define("FORLAN_7", "Respuestas borradas");
define("FORLAN_8", "Borrar cancelado.");
define("FORLAN_9", "Tema movido.");
define("FORLAN_10", "Movimiento cancelado.");
define("FORLAN_11", "Volver a foros");
define("FORLAN_12", "Configuraci�n del foro");
define("FORLAN_13", "�Est� seguro que quiere borrar esta votaci�n?<br />Una vez borrada <b><u>no podr�</u></b> recupararla.");
define("FORLAN_14", "Cancelar");
define("FORLAN_15", "Confirmar que quiere borrar mensajes del foro");
define("FORLAN_16", "Confirmar que quiere borrar la votaci�n");
define("FORLAN_17", "Expuesto por");
define("FORLAN_18", "�Est� seguro que quiere borrar este foro");
define("FORLAN_19", "tema y sus correspondientes mensajes?");
define("FORLAN_20", "La votaci�n tambi�n ser� borrada");
define("FORLAN_21", "Una vez borrados");
define("FORLAN_22", "�exponer?<br />Una vez borrado");
define("FORLAN_23", "no puede</u></b> ser recuperado");
define("FORLAN_24", "Mover tema a foro");
define("FORLAN_25", "Mover tema");
define("FORLAN_26", "Respuesta borrada");
define("FORLAN_27", "Movido");
define("FORLAN_28", "No renombre el t�tulo del tema"); 
define("FORLAN_29", "A�adir"); 
define("FORLAN_30", "al t�tulo"); 
define("FORLAN_31", "Renombrar a:"); 
define("FORLAN_32", "Opciones al renombrar tema:"); 
?>