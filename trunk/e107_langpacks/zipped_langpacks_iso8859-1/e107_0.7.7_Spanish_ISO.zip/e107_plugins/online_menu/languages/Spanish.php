<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/online_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Invitados: ");
define("ONLINE_L2", "Miembros: ");
define("ONLINE_L3", "En esta p�gina: ");
define("ONLINE_L4", "En linea");
define("ONLINE_L5", "Miembros");
define("ONLINE_L6", "�ltimo");

define("TRACKING_MESSAGE", "Tracking de usuario online est� actualmente desactivado, por favor act�velo <a href='".e_ADMIN."users.php?options'>aqu�</a></span><br />");

?>