<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/calendar_menu/languages/Spanish_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/16 21:34:01 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CM_SCH_LAN_1", "Calendario");
?>