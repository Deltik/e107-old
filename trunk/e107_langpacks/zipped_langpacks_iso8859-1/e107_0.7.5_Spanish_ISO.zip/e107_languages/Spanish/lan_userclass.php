<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Todos (p�blico)");
define("UC_LAN_1", "Invitados");
define("UC_LAN_2", "Nadie (inactivo)");
define("UC_LAN_3", "Miembros");
define("UC_LAN_4", "Solo Lectura");
define("UC_LAN_5", "Administrador");
?>