<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/03/23 22:06:16 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Listado de p�gina desactivado");
define("LAN_PAGE_2", "No hay p�ginas");
define("LAN_PAGE_3", "La p�gina solicitada no existe");
define("LAN_PAGE_4", "Valorar esta p�gina");
define("LAN_PAGE_5", "Gracias por valorar esta p�gina");
define("LAN_PAGE_6", "No tiene permisos para ver esta p�gina");
define("LAN_PAGE_7", "Contrase�a incorrecta");
define("LAN_PAGE_8", "P�gina con contrase�a protegida");
define("LAN_PAGE_9", "Contrase�a");
define("LAN_PAGE_10", "Enviar");
define("LAN_PAGE_11", "Lista de p�gina");
?>