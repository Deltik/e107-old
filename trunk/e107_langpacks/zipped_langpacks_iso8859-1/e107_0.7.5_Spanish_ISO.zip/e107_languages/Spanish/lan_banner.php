<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Anuncio");
define("LAN_16", "Usuario: ");
define("LAN_17", "Contrase�a: ");
define("LAN_18", "Continuar");
define("LAN_19", "Por favor identif�quese con su nombre de usuario y contrase�a para continuar");
define("LAN_20", "Lo sentimos, No se pueden encontrar esos detalles en nuestra base de datos. Por favor p�ngase en contacto con el administrador del sitio.");
define("LAN_21", "Estad�sticas de la publicidad");
define("LAN_22", "Cliente");
define("LAN_23", "ID anuncio");
define("LAN_24", "Visitas");
define("LAN_25", "% Visitas");
define("LAN_26", "Impresiones");
define("LAN_27", "Impresiones Contratadas");
define("LAN_28", "Impresiones realizadas");
define("LAN_29", "Sin anuncios");
define("LAN_30", "Ilimitado");
define("LAN_31", "No aplicable");
define("LAN_32", "Si");
define("LAN_33", "No");
define("LAN_34", "Finaliza");
define("LAN_35", "Pulsado desde las direcciones IP");
define("LAN_36", "Activo:");
define("LAN_37", "Comienzo:");
define("LAN_38", "Error");
?>






