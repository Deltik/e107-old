<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_print.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/20 19:46:44 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vista para Impresi�n");

define("LAN_86", "Categor�a:");
define("LAN_87", "por ");

define("LAN_94", "Enviada por");

define("LAN_135", "Noticias: ");

define("LAN_303", "Esta noticia proviene de ");
define("LAN_304", "T�tulo del art�culo: ");
define("LAN_305", "Encabezado: ");
define("LAN_306", "Este art�culo es de ");
define("LAN_307", "Imprimir esta p�gina");

define("LAN_PRINT_1", "modo impresi�n");
?>