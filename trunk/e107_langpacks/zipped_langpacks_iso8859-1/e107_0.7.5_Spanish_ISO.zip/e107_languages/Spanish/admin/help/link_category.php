<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/link_category.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Puede separar sus enlaces en diferentes categor�as,
esto hace la navegaci�n por la p�gina de enlaces mucho m�s f�cil y mejora la exposici�n.<br /><br />
Cualquier enlace introducido bajo la categor�a Principal ser� mostrado en su men� de navegaci�n.";
$ns -> tablerender("Ayuda Categor�a enlace", $text);
?>