<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta-tags actualizados en la base de datos");
define("METLAN_2", "A�adir Meta-tags adicionales");
define("METLAN_3", "Nueva configuraci�n de Meta-tags");
define("METLAN_4", "Actualizado");
define("METLAN_5", "Escriba aqu� su descripci�n");
define("METLAN_6", "Escriba, una, lista, de, sus, palabras, clave, aqu�");
define("METLAN_7", "Escriba la informaci�n de Copyright aqu�");
define("METLAN_8", "Meta-Tags");
define("METLAN_9", "Descripci�n");
define("METLAN_10", "Palabras Clave");
define("METLAN_11", "Copyright");
?>