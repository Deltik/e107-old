<?php
/**
* PHPMailer language file.
* Danish Version
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'Du skal levere mindst en ' . 'modtager email adresse.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer er ikke underst&oslash;ttet.';
$PHPMAILER_LANG["execute"] = 'Kunne ikke eksekvere: ';
$PHPMAILER_LANG["instantiate"] = 'Kunne ikke igangs&aelig;tte mail funktion.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Fejl: Kunne ikke godkende.';
$PHPMAILER_LANG["from_failed"] = 'Den flg. Fra adressen fejlede: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Fejl: De flg. ' . 'modtagere fejlede: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Fejl: Data ikke accepteret.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Fejl: Kunne ikke forbinde til SMTP v&aelig;rt.';
$PHPMAILER_LANG["file_access"] = 'Kunne ikke tilg&aring; filen: ';
$PHPMAILER_LANG["file_open"] = 'Fil Fejl: Kunne ikke &aring;bne fil: ';
$PHPMAILER_LANG["encoding"] = 'Ukendt kodning: ';
?>