<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/chatbox_menu/languages/Spanish/Spanish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Chatbox");
define("CHATBOX_L1", "No se pudo aceptar su mensaje con ese nombre de usuario porque ya est� registrado - si es su nombre de usuario por favor inicie sesi�n ant�s de continuar.");
define("CHATBOX_L2", "Chatbox");
define("CHATBOX_L3", "Debe iniciar sesi�n antes de enviar mensajes en este sistio - si usted no es usuario registrado ,por favor pulse <a href='".e_BASE."signup.php'>aqu�</a> para registrarse");
define("CHATBOX_L4", "Enviar");
define("CHATBOX_L5", "Resetear");
define("CHATBOX_L6", "[Bloqueado por admin]");
define("CHATBOX_L7", "Desbloquear");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Bloquear");
define("CHATBOX_L10", "Borrar");
define("CHATBOX_L11", "No hay mensajes a�n.");
define("CHATBOX_L12", "Ver todos los mensajes");
define("CHATBOX_L13", "Moderar chatbox");
define("CHATBOX_L14", "Mostrar emoticones");
define("CHATBOX_L15", "Mensaje demasiado largo, o enviaste un mensaje vacio");
define("CHATBOX_L16", "An�nimo");
define("CHATBOX_L17", "Mensaje duplicado");
define("CHATBOX_L18", "Mensajes de ChatBox moderados");
define("CHATBOX_L19", "Solo puedes enviar un mensaje cada ".FLOODTIMEOUT." segundos");
define("CHATBOX_L20", "Chatbox (todos los env�os)");
define("CHATBOX_L21", "Env�os Chat");
define("CHATBOX_L22", "on");
define("CHATBOX_L23", "�Error!");
define("CHATBOX_L24", "No tiene autorizaci�n suficiente para ver esta p�gina.");
define("CHATBOX_L25", "[ este env�o ha sido bloqueado por el Admin ]");

define("NT_LAN_CB_1", "Eventos Chatbox");
define("NT_LAN_CB_2", "Mensaje enviado");
define("NT_LAN_CB_3", "Enviado por");
define("NT_LAN_CB_4", "Direcci�n IP");
define("NT_LAN_CB_5", "Mensaje");
define("NT_LAN_CB_6", "Mensaje Chatbox enviado");
?>