<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/10/29 16:03:38 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_submitnews.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_submitnews.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Dodaj newsa");

define("LAN_7", "Login: ");
define("LAN_62", "Temat: ");
define("LAN_112", "Adres email: ");
define("LAN_133", "Dzi�kujemy");
define("LAN_134", "Tw�j news zosta� wys�any i zostanie sprawdzony przez jednego z administrator�w w najbli�szym czasie.");
define("LAN_135", "Wiadomo��: ");
define("LAN_136", "Dodaj newsa");
define("NWSLAN_6", "Kategoria");
define("NWSLAN_10", "Brak kategorii aktualno�ci");
define("NWSLAN_11", "Nie posiadasz uprawnie� dost�pu do tej strefy.");
define("NWSLAN_12", "Dost�p zabroniony.");

define("SUBNEWSLAN_1", "Musisz do��czy� jaki� tytu�.\\n");
define("SUBNEWSLAN_2", "Musisz do��czy� jaki� tekst do tej wiadomo�ci.\\n");
define("SUBNEWSLAN_3", "Twoje pliki za��cznik�w musz� mie� nast�puj�ce rozszerzenia jpg, gif lub png");
define("SUBNEWSLAN_4", "Plik jest za du�y");
define("SUBNEWSLAN_5", "Obrazek");
define("SUBNEWSLAN_6", "(jpg, gif lub png)");

?>
