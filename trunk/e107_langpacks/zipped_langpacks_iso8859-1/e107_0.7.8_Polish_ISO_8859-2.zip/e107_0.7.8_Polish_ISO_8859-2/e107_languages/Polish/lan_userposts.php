<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:05 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_userposts.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_userposts.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Posty u�ytkownika");

define("UP_LAN_0", "Wszystkie posty na forum dla ");
define("UP_LAN_1", "Wszystkie komentarze dla ");
define("UP_LAN_2", "Temat");
define("UP_LAN_3", "Podgl�d");
define("UP_LAN_4", "Posty");
define("UP_LAN_5", "Ostatni post");
define("UP_LAN_6", "Tematy");
define("UP_LAN_7", "Brak komentarzy");
define("UP_LAN_8", "Brak post�w");
define("UP_LAN_9", " dnia ");
define("UP_LAN_10", "Odp");
define("UP_LAN_11", "Dodane dnia");
define("UP_LAN_12", "Szukaj");
define("UP_LAN_13", "Komentarze");
define("UP_LAN_14", "Posty na forum");
define("UP_LAN_15", "Odp");
define("UP_LAN_16", "Adres IP");

?>
