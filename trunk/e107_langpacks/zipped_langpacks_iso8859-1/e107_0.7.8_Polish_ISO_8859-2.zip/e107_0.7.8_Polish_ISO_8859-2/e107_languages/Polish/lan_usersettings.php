<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2007/02/10 15:53:40 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_usersettings.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_usersettings.php rev. 1.11
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Ustawienia u�ytkownika");

define("LAN_7", "Wy�wietlana nazwa: ");
define("LAN_8", "ta nazwa b�dzie wy�wietlana na stronie");
define("LAN_9", "Login: ");
define("LAN_10", "ta nazwa b�dzie u�ywana do logowania w serwisie");
define("LAN_11", "ta nazwa b�dzie u�ywana do logowania w serwisie - nie b�dziesz m�g� jej zmieni�. Je�li potrzebujesz zmiany tej nazwy w zwi�zku z bezpiecze�stwem swojego konta, prosz� skontaktowa� si� z administratorem strony.");

define("LAN_20", "B��d");
define("LAN_105", "Podane has�a r�ni� si�. Prosz� wprowadzi� je ponownie");
define("LAN_106", "Podany adres email jest b��dny. Wprowad� go ponownie.");
define("LAN_112", "Adres email: ");
define("LAN_113", "Ukry� adres email?: ");
define("LAN_114", "Ta opcja pozwala ukry� adresu email na wy�wietlanych stronach");
define("LAN_115", "Numer ICQ: ");
define("LAN_116", "Adres AIM: ");
define("LAN_117", "MSN Messenger: ");
define("LAN_118", "Urodziny: ");
define("LAN_119", "Miejscowo��: ");
define("LAN_120", "Sygnatura: ");
define("LAN_121", "Awatar: ");
define("LAN_122", "Strefa czasowa:");
define("LAN_144", "Strona domowa URL: ");
define("LAN_150", "Ustawienia zosta�y zaktualizowane i zapisane w bazie danych.");
define("LAN_151", "OK");
define("LAN_152", "Nowe has�o: ");
define("LAN_153", "Powt�rz has�o: ");
define("LAN_154", "Zapisz ustawienia");
define("LAN_155", "Ustawienia u�ytkownika");
define("LAN_185", "Has�o nie zosta�o wpisane ");
define("LAN_308", "Prawdziwe imi�: ");
define("LAN_401", "Pozostaw puste je�li nie chcesz zmienia� has�a");
define("LAN_402", "�cie�ka dost�pu lub wybierz awatara");
define("LAN_403", "Wybierz awatara");
define("LAN_404", "Uwaga: Ka�dy obraz nades�any do serwisu, kt�ry zostanie uznany przez administratora za nieodpowiedni, b�dzie natychmiast kasowany.");

define("LAN_410", "Ustawienia dla");
define("LAN_411", "Uaktualnij swoje ustawienia");
define("LAN_412", "Zmie� has�o");
define("LAN_413", "Wybierz awatara");
define("LAN_414", "Wy�lij w�asne zdj�cie");
define("LAN_415", "Wy�lij w�asnego awatara");

define("LAN_416", "Tak");
define("LAN_417", "Nie");

define("LAN_418", "Informacje rejestracyjne");
define("LAN_419", "Informacje personalne/kontaktowe");
define("LAN_420", "Awatar");
define("LAN_421", "Wybierz dost�pnego awatara");
define("LAN_422", "Pobieraj awatara z adresu");
define("LAN_423", "Prosz� wpisa� pe�ny adres do obrazka");
define("LAN_424", "Kliknij w przycisk, aby zobaczy� awatary dost�pne na tej stronie");
define("LAN_425", "Zdj�cie");
define("LAN_426", "To b�dzie wy�wietlane w twoim profilu");
define("LAN_427", "Wy�lij ...");
define("LAN_428", "Wiadomo��");
define("LAN_429", "Link");
define("LAN_430", "Plik do pobrania");
define("LAN_431", "Artyku�");
define("LAN_432", "Recenzj�");

define("LAN_433", "Adres URL do Twojego pliku XUP");
define("LAN_434", "co to jest?");
define("LAN_435", "Plik XML User Protocol");

define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "znak�w.");
define("LAN_SIGNUP_4", "Twoje has�o musi by� d�u�sze ni� ");
define("LAN_SIGNUP_5", " znak�w.");
define("LAN_SIGNUP_6", "Twoje ");
define("LAN_SIGNUP_7", " jest wymagane");

define("LAN_USET_1", "Tw�j awatar jest za szeroki");
define("LAN_USET_2", "Maksymaln� dopuszczon� szeroko�ci� jest");
define("LAN_USET_3", "Tw�j awatar jest za wysoki");
define("LAN_USET_4", "Maksymaln� dopuszczon� wysoko�ci� jest");

// v.616
define("LAN_CUSTOMTITLE", "Dodatkowy opis");
define("LAN_ICQNUMBER", "Numer ICQ musi sk�ada� si� tylko cyfry");

//v.617
define("LAN_408", "U�ytkownik o podanym adresie email ju� istnieje. ");
define("MAX_AVWIDTH", "Maksymalnym rozmiarem awatara (sxw) jest ");
define("MAX_AVHEIGHT", " x ");
define("GIF_RESIZE", "Prosz� zmieni� rozmiar obrazka gif lub przekonwertowa� go do innego formatu");
define("RESIZE_NOT_SUPPORTED", "Zmiana rozmiar�w na tym serwerze nie jest wspomagana. Prosz� zmieni� rozmiar obrazka inn� metod�. Plik zosta� usuni�ty.");

// v0.7
define("LAN_USET_5", "Subskrypcja");
define("LAN_USET_6", "Zapisz si� do naszej listy-mailingowej i/oraz sekcji na tej stronie.");
define("LAN_USET_7", "Dodatkowe informacje");
define("LAN_USET_8", "Sygnatura oraz Strefa czasowa");
define("LAN_USET_9", "Pewne wymagane pola (oznaczone znakiem *) zosta�y utracone.");
define("LAN_USET_10","Aby przej�� dalej, prosz� uaktualni� swoje ustawienia.");
define("LAN_USET_11", "Podany login nie mo�e zosta� zaakceptowany, prosz� wybra� inn� nazw� u�ytkownika");
define("LAN_USET_12", "Wy�wietlana nazwa jest za kr�tka. Prosz� wybra� inn�.");
define("LAN_USET_13", "Wykryto niedozwolone znaki w loginie. Prosz� wybra� inny.");

?>
