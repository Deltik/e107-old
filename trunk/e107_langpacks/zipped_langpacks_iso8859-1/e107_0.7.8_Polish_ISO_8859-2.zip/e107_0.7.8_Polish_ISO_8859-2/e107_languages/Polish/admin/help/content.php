<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/content.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/content.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "U�ywaj�c tej strony mo�esz tworzy� strony dla w�asnego serwisu. Link do nowej strony zostanie utworzony w menu g��wnym. Na przyk�ad, je�li utworzysz now� stron� z nazw� linku 'Test', link Test zostanie wy�wietlony w menu po wys�anie nowej strony.<br />
Je�li chcesz, aby Twoja strona mia�a nag��wek, wpisz jego nazw� w pole <i>Nag��wek strony</i>.";
$ns -> tablerender("Kontent", $text);

?>
