<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/forum.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/forum.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$caption = "Forum";
$text = "<b>Og�lne</b><br />
U�ywaj tej strony do tworzenia lub edytowania swoich for�w.<br />
<br />
<b>Dzia�y i fora</b><br />
Dzia� jest nag��wkiem, pod kt�rym s� wy�wietlane inne fora, co czyni uk�ad strony prostszym i sprawia, �e nawigacja na forach jest znacznie �atwiejsza dla odwiedzaj�cych.
<br /><br />
<b>Dost�pno��</b>
<br />
Tutaj mo�esz ustawi� swoje fora tak, aby by�y dost�pne tylko dla okre�lonych odwiedzaj�cych. Gdy ustawisz 'grup�' odwiedzaj�cych mo�esz j� zaznaczy�, aby zezwoli� tylko tym u�ytkownikom na dost�p do forum. Post�puj�c w spos�b analogiczny mo�esz nada� dost�p dla dzia��w jak i pojedynczych for�w.
<br /><br />
<b>Moderatorzy</b>
<br />
Zaznacz nazwy z listy administrator�w, aby nada� im status moderatora tego forum. Administrator, aby zosta� tutaj wy�wietlonym, musi mie� nadane uprawnienia moderatora forum.
<br /><br />
<b>Ranga</b>
<br />
Tutaj mo�esz ustawi� rangi dla u�ytkownik�w. Je�li pola obrazk�w s� wype�nione, zostan� u�yte odpowiednie grafiki. Aby u�y� nazwy rangi wpisz j� i upewnij si�, �e odpowiednie pole obrazka rangi jest puste.<br />Pr�g stanowi ilo�� punkt�w, kt�re u�ytkownik musi zdoby� przed zmian� jego poziomu.";
$ns -> tablerender($caption, $text);
unset($text);

?>
