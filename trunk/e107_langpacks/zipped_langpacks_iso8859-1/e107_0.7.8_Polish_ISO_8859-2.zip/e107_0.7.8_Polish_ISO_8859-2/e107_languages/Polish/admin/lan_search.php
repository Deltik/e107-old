<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/11/01 00:05:09 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_search.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_search.php rev. 1.25
+-----------------------------------------------------------------------------+
*/
 
define("SEALAN_1", "Konfiguracja wyszukiwania");
define("SEALAN_2", "Ilo�� znak�w wy�wietlanych w kr�tkim wyniku wyszukiwania:");
define("SEALAN_3", "Metoda sortowania wynik�w:");
define("SEALAN_6", "Komentarze");
define("SEALAN_7", "Zarejestrowani<br />u�ytkownicy");
define("SEALAN_10", "Pokazuj ocen� trafno�ci:"); // Display relevance value
define("SEALAN_11", "Pozw�l u�ytkownikom na wyb�r stref przeszukiwania:");
define("SEALAN_12", "Ogranicz czas dost�pu pomi�dzy wyszukiwaniami (max 5 min):");
define("SEALAN_13", "Ogranicz do jednego wyszukiwania co ka�de");
define("SEALAN_14", "sekund");
define("SEALAN_15", "Strona wyszukiwania dost�pna dla grupy u�ytkownik�w");
define("SEALAN_16", "W��cz");
define("SEALAN_17", "Wy��cz");
define("SEALAN_18", "Przeszukiwanie strefy komentarzy (tylko w�wczas gdy wyszukiwanie komentarzy zosta�o aktywowane)");
define("SEALAN_19", "Zezw�l u�ytkownikowi na wi�cej ni� jeden proces <br />wyszukiwania w tym samym czasie:");
define("SEALAN_20", "G��wne ustawienia");
define("SEALAN_21", "Przeszukiwane strefy");
define("SEALAN_22", "Domy�lny");
define("SEALAN_23", "Alternatywny:");
define("SEALAN_24", "Typ");
define("SEALAN_25", "Grupa u�ytkownik�w");
define("SEALAN_26", "Podtytu�");
define("SEALAN_30", "Pod�wietl s�owa kluczowe w wynikach wyszukiwania:"); // Highlight keywords on referred too page
define("SEALAN_31", "PHP - limituj do");
define("SEALAN_32", "wynik�w (pozostaw puste, aby nie u�ywa� limit�w)");
define("SEALAN_33", "Nie mog� prze��czy� na metod� sortowania MySql wymaga to przynajmniej wersji 4.0.1 MySql."); // Could not switch to MySql sort method as this requires at least version 4.0.1 of MySql
define("SEALAN_34", "Twoja wersja jest poprawna");
define("SEALAN_35", "Spos�b wyboru stref przeszukiwania:");
define("SEALAN_36", "Rozwijalna lista");
define("SEALAN_37", "Zaznaczenie");
define("SEALAN_38", "Przyciski");
define("SEALAN_39", "Inne strony");

define("LAN_98", "Aktualno�ci");
define("LAN_197", "Pliki do pobrania");
define("LAN_418", "Inne strony");

define("SEALAN_40", "Opcje wyszukiwania");
define("SEALAN_41", "Strona g��wna");
define("SEALAN_42", "Ustawienia");

define("SEALAN_43", "Edycja ustawie� wyszukiwania dla");
define("SEALAN_44", "Dozwolona grupa u�ytkownik�w do wyszukiwania w tej strefie");
define("SEALAN_45", "Ilo�� wynik�w wy�wietlanych na stronie");
define("SEALAN_46", "Ilo�� znak�w w streszczonym wyniku wyszukiwania");

define("SEALAN_47", "Tylko pe�ne s�owa:");
define("SEALAN_48", "Tego ustawienie u�ywaj tylko, kiedy metod� sortowania wyszukiwa� jest PHP. Je�li Twoja strona zawiera j�zyki ideograficzne takie jak chi�ski i japo�ski, musisz t� opcj� wy��czy�.");
define("SEALAN_49", "Je�li Twoja strona zawiera j�zyki ideograficzne takie jak chi�ski i japo�ski, musisz u�ywa� metody sortowania PHP.");

?>
