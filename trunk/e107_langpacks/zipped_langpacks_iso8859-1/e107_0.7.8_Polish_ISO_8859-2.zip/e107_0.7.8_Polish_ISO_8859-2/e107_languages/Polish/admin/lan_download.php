<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.8 $
|     $Date: 2007/02/19 17:12:40 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_download.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_download.php rev. 1.19
+-----------------------------------------------------------------------------+
*/
 
define("DOWLAN_1", "Plik zosta� dodany do bazy danych.");
define("DOWLAN_2", "Plik zosta� zaktualizowany w bazie danych.");
define("DOWLAN_3", "Plik zosta� usuni�ty.");
define("DOWLAN_4", "Prosz� zaznaczy� pole, aby usun�� plik");
define("DOWLAN_5", "Nie ma jeszcze zdefiniowanych kategorii plik�w do pobrania. Dop�ki nie zdefiniujesz jakiej� kategorii nie b�dziesz m�g� dodawa� plik�w do tego dzia�u.");
define("DOWLAN_6", "Nie ma jeszcze plik�w do pobrania");
define("DOWLAN_7", "Aktualne pliki do pobrania");

define("DOWLAN_11", "Kategoria");
define("DOWLAN_12", "Nazwa");
define("DOWLAN_13", "Plik");
define("DOWLAN_14", "Wpisz adres, je�li plik do pobrania pochodzi z zewn�trznego serwera");
define("DOWLAN_15", "Autor");
define("DOWLAN_16", "Email autora");
define("DOWLAN_17", "Strona autora");
define("DOWLAN_18", "Opis");
define("DOWLAN_19", "Obraz");
define("DOWLAN_20", "Miniatura obrazu");
define("DOWLAN_21", "Status");

define("DOWLAN_24", "Aktualizuj plik");
define("DOWLAN_25", "Wy�lij plik");

define("DOWLAN_27", "Plik");
define("DOWLAN_28", "Uwaga");
define("DOWLAN_29", "Aktualne pliki do pobrania");
define("DOWLAN_30", "Dodaj nowy plik");
define("DOWLAN_31", "Kategorie");
define("DOWLAN_32", "Opcje downloadu");
define("DOWLAN_33", "Czy na pewno chcesz usun�� wskazany plik?");
define("DOWLAN_34", "Czy na pewno chcesz usun�� wskazan� kategori� downloadu?");

define("DOWLAN_36", "- usuni�to."); 
define("DOWLAN_37", "Dzia�");
define("DOWLAN_38", "Nie ma jeszcze �adnych kategorii");
define("DOWLAN_39", "Kategorie plik�w do pobrania");
define("DOWLAN_40", "Brak - dzia� g��wny");
define("DOWLAN_41", "Ikona");
define("DOWLAN_42", "Wy�wietl obrazki");
define("DOWLAN_43", "Widoczno��");
define("DOWLAN_44", "Wybierz grup� u�ytkownik�w, dla kt�rej ta kategoria b�dzie tylko widoczna");
define("DOWLAN_45", "Utw�rz kategori�");
define("DOWLAN_46", "Aktualizuj kategori�");
define("DOWLAN_47", "Kategoria zosta�a utworzona");
define("DOWLAN_48", "Kategoria zosta�a zaktualizowana");
define("DOWLAN_49", "Kategori� plik�w o numerze ID");

define("DOWLAN_51", "Szukaj/Od�wie� pliki");
define("DOWLAN_52", "Pliki");
define("DOWLAN_53", "Podkategoria");
define("DOWLAN_54", "Opcje downloadu");
define("DOWLAN_55", "Ilo�� wy�wietlanych plik�w na stronie");
define("DOWLAN_56", "Sortuj wed�ug ");


define("DOWLAN_59", "Nazwa pliku");
// define("DOWLAN_60", "Autor");

define("DOWLAN_62", "Rosn�co");
define("DOWLAN_63", "Malej�co");
define("DOWLAN_64", "Aktualizuj opcje");
define("DOWLAN_65", "Opcje zosta�y zaktualizowane");
define("DOWLAN_66", "Wpisz rozmiar pliku");
define("DOWLAN_67", "ID");
define("DOWLAN_68", "Brak pliku!");
define("DOWLAN_69", "Pobieranie plik�w obs�ugiwane przez PHP"); // Downloads handled by PHP
define("DOWLAN_70", "Zaznaczenie tego spowoduje, �e wszystkie ��dane pliki b�d� pobierane przez funkcje PHP.");  //Checking this will send all download requests through PHP.
define("DOWLAN_100", "Aktywuj umow� pobierania plik�w");
define("DOWLAN_101", "Tre�� umowy");
define("DOWLAN_102", "Zezwoli� na komentarze?");
define("DOWLAN_103", "Usu� z uploadu");
define("DOWLAN_104", "zosta� usuni�ty z dzia�u publiczny upload");
define("DOWLAN_105", "Wr�� do dzia�u publiczny upload");
define("DOWLAN_106", "Mo�e by� pobierany przez");
define("DOWLAN_107", "Limit mo�liwych pobra�");
define("DOWLAN_108", "Limit pobieranych danych");
define("DOWLAN_109", "na ka�de");
define("DOWLAN_110", "dni");
define("DOWLAN_111", "kb");
define("DOWLAN_112", "Limity");
define("DOWLAN_113", "Grupa u�ytkownik�w");
define("DOWLAN_114", "Dodaj nowy limit");
define("DOWLAN_115", "Aktualizuj limity");
define("DOWLAN_116", "Limit dla wskazanej grupy ju� istnieje");
define("DOWLAN_117", "Limit zosta� dodany");
define("DOWLAN_118", "Limit nie zosta� dodany - nieznany b��d");
define("DOWLAN_119", "Limit zosta� usuni�ty");
define("DOWLAN_120", "Limit nie zosta� usuni�ty - nieznany b��d");
define("DOWLAN_121", "Limit zosta� zaktualizowany");
define("DOWLAN_122", "Nieaktywny");
define("DOWLAN_123", "Aktywny - Plik podlega limitom pobierania");
define("DOWLAN_124", "Aktywny - Plik NIE podlega limitom pobierania");
define("DOWLAN_125", "Aktywuj limity pobierania");
define("DOWLAN_126", "Status aktywacji zosta� zaktualizowany");
define("DOWLAN_127", "Rozmiar pliku wpisz tylko w�wczas, gdy plik jest pobierany z zewn�trznego serwera");
define("DOWLAN_128", "Mirrory");
define("DOWLAN_129", "pozostaw puste je�li nie chcesz u�ywa� mirror�w");
define("DOWLAN_130", "Dodaj jeszcze jeden mirror");
define("DOWLAN_131", "Wybierz plik lokalny");
define("DOWLAN_132", "Wpisz adres u�ywanego mirrora, a nast�pnie adres pliku do pobrania");

define("DOWLAN_133", "Mirror zosta� zaktualizowany w bazie danych");
define("DOWLAN_134", "Mirror zosta� zapisany w bazie danych");
define("DOWLAN_135", "Mirror zosta� usuni�ty");
define("DOWLAN_136", "obraz");
define("DOWLAN_137", "Czy na pewno usun�� wskazany mirror?");
define("DOWLAN_138", "Aktualne mirrory");
define("DOWLAN_139", "Adres");
define("DOWLAN_140", "Za�aduj obrazki do lokalnego folderu e107_files/downloadimages, aby wy�wietli� je tutaj, lub wpisz pe�ny adres do pliku umieszczonego na zewn�trznym serwerze");
define("DOWLAN_141", "Lokalizacja");
define("DOWLAN_142", "Aktualizuj mirror");
define("DOWLAN_143", "Dodaj mirror");
define("DOWLAN_144", "Nie ustawiono jeszcze zadnych mirror�w.");

define("DOWLAN_145", "Plik widoczny dla");
define("DOWLAN_146", "Tre�� wiadomo�ci wy�wietlanej w wypadku odmowy pobierania lub adres URL");

define("DOWLAN_147", "Ikona dla pustej kategorii");
define("DOWLAN_148", "Zaznacz, aby zaktualizowa� dat� dodania do aktualnego czasu");  // Check to update datestamp to current time
define("DOWLAN_149", "Albo kliknij tutaj, aby u�y� pliku umieszczonego na zewn�trznym serwerze");
define("DOWLAN_150", "Wiadomo�� email do administratora, gdy zg�oszono uszkodzony plik"); // Email admin when broken download reported
define("DOWLAN_151", "Zg�aszanie uszkodzonych plik�w do pobrania dost�pne dla");

define("DOWLAN_152", "Nie mog� przenie�� pliku");
define("DOWLAN_153", "Przenie� plik do folderu downloads");

define("DOWLAN_154", "Je�li u�ywasz mirror�w, wybierz spos�b w jaki maj� by� wy�wietlone");
define("DOWLAN_155", "Metoda wy�wietlania mirror�w:");
define("DOWLAN_156", "Poka� list� mirror�w, umo�liwia u�ytkownikowi wyb�r mirrora");
define("DOWLAN_157", "U�ywaj losowego mirrora - brak mo�liwo�ci wyboru przez u�ytkownika");

?>
