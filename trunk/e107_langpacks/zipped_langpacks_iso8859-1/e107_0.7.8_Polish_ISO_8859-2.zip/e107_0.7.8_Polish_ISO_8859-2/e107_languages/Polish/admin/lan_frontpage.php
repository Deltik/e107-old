<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_frontpage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_frontpage.php rev. 1.8
+-----------------------------------------------------------------------------+
*/
 
define("FRTLAN_1", "Ustawienia strony g��wnej zosta�y zaktualizowane.");
define("FRTLAN_2", "Ustawienia strony g��wnej dla");
define("FRTLAN_6", "Linki");
// define("FRTLAN_7", "W�asna strona");
define("FRTLAN_12", "Aktualizuj ustawienia strony g��wnej");
define("FRTLAN_13", "Ustawienia strony g��wnej");
define("FRTLAN_15", "Inna (wpisz adres):");
define("FRTLAN_16", "B��d: nie wybrano dzia�u g��wnego publikacji");
define("FRTLAN_17", "B��d: nie wybrano podkategorii publikacji");
define("FRTLAN_18", "B��d: nie wybrano publikacji");
define("FRTLAN_19", "Dzia� g��wny publikacji");
define("FRTLAN_20", "Kategoria publikacji");
define("FRTLAN_21", "Publikacja");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Wszyscy u�ytkownicy");
define("FRTLAN_27", "Go�cie");
define("FRTLAN_28", "Zarejestrowani u�ytkownicy");
define("FRTLAN_29", "Administratorzy");
define("FRTLAN_31", "Wszystkich u�ytkownik�w");
define("FRTLAN_32", "Grupy u�ytkownik�w");
define("FRTLAN_33", "Aktualne ustawienia");
define("FRTLAN_34", "Strona");

?>
