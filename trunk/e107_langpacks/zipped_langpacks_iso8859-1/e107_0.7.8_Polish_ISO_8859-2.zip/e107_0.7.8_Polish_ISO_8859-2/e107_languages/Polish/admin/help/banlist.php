<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2007/02/18 19:42:45 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/banlist.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/banlist.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$caption = "Blokowanie u�ytkownik�w";
$text = "Na tej stronie mo�esz blokowa� u�ytkownik�w odwiedzaj�cych Twoja stron�.<br />
Prosz� wpisywa� pe�ny adres IP lub u�ywa� znaku zast�pczego (*) do zablokowania wskazanej puli adres�w IP. Mo�esz r�wnie� wpisa� adres email w celu zablokowania u�ytkownik�w zarejestrowanych na Twojej stronie.<br /><br />
<b>Blokowanie przez adres IP:</b><br />
Wpisanie adresu 123.123.123.123 zablokuje u�ytkownik�w odwiedzaj�cych Twoj� stron� ze wskazanego adresu IP.<br />
Wpisanie adresu 123.123.123.* zablokuje u�ytkownik�w odwiedzaj�cych Twoj� stron� ze wskazanej puli adres�w IP.<br /><br />
<b>Blokowanie przez adres email:</b><br />
Wpisanie adresu email foo@bar.com zablokuje ka�dego zarejestrowanego u�ytkownika u�ywaj�cego tego adresu na Twojej stronie.<br />
Wpisanie adresu email *@bar.com zablokuje ka�dego zarejestrowanego u�ytkownika u�ywaj�cego adresu email pochodz�cego ze wskazanej domeny.<br /><br />
<b>Blokowanie przez nazw� u�ytkownika</b><br />
Jest to wykonalne z podstrony 'U�ytkownicy' w 'Panelu admina'.";
$ns -> tablerender($caption, $text);

?>
