<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/article.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/article.php rev. 1.
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie mo�esz tworzy� jedno oraz wielostronicowe artyku�y.<br />
Aby utworzy� artyku� wielostronicowy, oddziel ka�d� stron� tekstem [newpage], np. <br /><code>Strona testowa 1 [newpage] Strona testowa 2</code><br /> utworzy artyku� dwustronicowy z tekstem 'Strona testowa 1' na pierwszej stronie oraz 'Strona testowa 2' na stronie drugiej.
<br /><br />
Je�li Tw�j artyku� zawiera znaczniki HTML, kt�re chcesz wy�wietli� na stronie, otocz wybrany kod znacznikami [html] [/html]. Na przyk�ad, je�li w swoim artykule wpiszesz tekst '&lt;table>&lt;tr>&lt;td>Cze�� &lt;/td>&lt;/tr>&lt;/table>', zostanie wy�wietlona tabela zawieraj�ca s�owo 'Cze��'. Je�li natomiast wpiszesz '[html]&lt;table>&lt;tr>&lt;td>Cze�� &lt;/td>&lt;/tr>&lt;/table>[/html]', zostanie wy�wietlony kod, kt�ry wpisa�e�, a nie tabela, kt�r� kod ten generuje.";
$ns -> tablerender("Artyku�y", $text);

?>
