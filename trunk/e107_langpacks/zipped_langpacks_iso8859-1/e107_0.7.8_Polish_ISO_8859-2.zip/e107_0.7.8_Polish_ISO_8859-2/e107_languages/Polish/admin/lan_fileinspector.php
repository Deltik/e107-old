<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 22:38:19 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_fileinspector.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_fileinspector.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("FC_LAN_1", "Inspektor plik�w");
define("FC_LAN_2", "Opcje skanowania");
define("FC_LAN_3", "Poka�");
define("FC_LAN_4", "Wszystkie");
define("FC_LAN_5", "pliki j�dra");
define("FC_LAN_6", "Tylko niesp�jne pliki");
define("FC_LAN_7", "nieznane pliki j�dra");
define("FC_LAN_8", "Sprawd� sp�jno�� plik�w j�dra");
define("FC_LAN_9", "W��czone");
define("FC_LAN_10", "Wy��czone");
define("FC_LAN_11", "Skanuj");
define("FC_LAN_12", "Nic nie pokazuj");
define("FC_LAN_13", "brakuj�ce pliki j�dra");
define("FC_LAN_14", "Wy�wietlaj wyniki jako");
define("FC_LAN_15", "Drzewo katalog�w");
define("FC_LAN_16", "Lista");
define("FC_LAN_17", "Dopasowany ci�g"); // String Matching
define("FC_LAN_18", "Regularne wyra�enia"); //Regular expression
define("FC_LAN_19", "Poka� numer linii"); // Show line numbers
define("FC_LAN_20", "Poka� powi�zane linie"); // Show matched lines
define("FC_LAN_21", "stare pliki j�dra");

define("FR_LAN_1", "Skanowanie");
define("FR_LAN_2", "Wynik skanowania");
define("FR_LAN_3", "Statystyki");
define("FR_LAN_4", "Plik�w j�dra");
define("FR_LAN_5", "Nieznane pliki j�dra");
define("FR_LAN_6", "Wszystkich plik�w");
define("FR_LAN_7", "Sprawdzanie integralno�ci");
define("FR_LAN_8", "Poprawnych plik�w j�dra");
define("FR_LAN_9", "B��dnych plik�w j�dra");
define("FR_LAN_10", "Prawdopodobne przyczyny b��d�w w plikach");
define("FR_LAN_11", "Plik jest uszkodzony");
define("FR_LAN_12", "Mo�e by� wiele przyczyn powoduj�cych niepoprawne dzia�anie plik�w zaczynaj�c od uszkodzonych archiw�w .zip, b��d�w podczas rozpakowywania, lub uszkodzenia plik�w podczas wysy�ania na serwer poprzez FTP. Spr�buj za�adowa� plik na sw�j serwer i uruchom jeszcze raz skanowanie, aby zobaczy� czy problem zosta� rozwi�zany.");
define("FR_LAN_13", "Plik jest nieaktualny");
define("FR_LAN_14", "Je�li plik pochodzi ze starszej wersji e107 ni� obecna, mo�e powodowa� niepoprawne dzia�anie skanera integralno�ci plik�w. Upewnij si�, �e masz za�adowan� najnowsz� wersj� pliku.");
define("FR_LAN_15", "Plik zosta� zmodyfikowany");
define("FR_LAN_16", "Posiadasz zmodyfikowany plik, w takim razie nie przejdzie on poprawnie sprawdzania integralno��. Je�li sam ingerowa�e� w ten plik nie musisz si� niczego obawia� i mo�esz zignorowa� wskazane b��dy sp�jno�ci plik�w. Je�li jednak plik zosta� zmodyfikowany przez osob� nie posiadaj�c� do tego uprawnie�, powiniene� przywr�ci� poprawn� wersj� pliku z archiwum .zip e107.");
define("FR_LAN_17", "Je�li jeste� u�ytkownikiem wersji CVS");
define("FR_LAN_18", "Je�li prowadzisz testy sprawdzaj�ce na wersji CVS e107 zamias6t na stabilnej wersji e107, zauwa�, �e pliki nie przechodz� poprawnie testu sp�jno�ci, poniewa� zosta�y zmodyfikowane po ostatnio utworzonym obrazie (image) kontrolnym j�dra.");
define("FR_LAN_19", "niepoprawnych plik�w");
define("FR_LAN_20", "Wszystkie pliki s� poprawne");
define("FR_LAN_21", "Brak");
define("FR_LAN_22", "Brakuj�ce pliki j�dra");
define("FR_LAN_23", "Nie znaleziono �adnych wynik�w.");
define("FR_LAN_24", "Stare pliki j�dra");
define("FR_LAN_25", "Sp�jno�� niesprawdzona");

define("FR_LAN_26", "Uwaga! Wykryto zagro�enie bezpiecze�stwa!");
define("FR_LAN_27", "Na Twoim serwerze znajduj� si� pliki rozpoznane jako exploity w celu zachowania bezpiecze�stwa usu� je niezw�ocznie.");
define("FR_LAN_28", "Rozpoznane niebezpieczne pliki");

?>
