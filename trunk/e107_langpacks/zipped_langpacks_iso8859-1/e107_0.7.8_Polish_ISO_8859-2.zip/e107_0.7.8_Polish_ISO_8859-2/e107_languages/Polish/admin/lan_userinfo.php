<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 22:38:19 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_userinfo.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_userinfo.php rev. 1.
+-----------------------------------------------------------------------------+
*/
 
define("USFLAN_1", "Nie mog� znale�� adresu IP nadawcy - brak dost�pnych informacji.");
// define("USFLAN_2", "B��d");
define("USFLAN_3", "Wiadomo�ci zosta�y nades�ane z adresu IP");
define("USFLAN_4", "Nazwa hosta");
define("USFLAN_5", "Kliknij tutaj, aby przetransferowa� adres IP do listy blokowanych");
define("USFLAN_6", "ID u�ytkownika");
define("USFLAN_7", "Informacje o u�ytkowniku");

?>
