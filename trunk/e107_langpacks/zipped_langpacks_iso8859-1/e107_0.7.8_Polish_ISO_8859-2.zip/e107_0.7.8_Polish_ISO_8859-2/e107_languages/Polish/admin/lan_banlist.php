<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2007/02/18 19:42:45 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_banlist.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/admin/lan_banlist.php rev. 1.8
+-----------------------------------------------------------------------------+
*/
 
define("BANLAN_1", "Blokada zosta�a usuni�ta.");
define("BANLAN_2", "Obecnie nie ma �adnych blokad.");
define("BANLAN_3", "Aktualnie zablokowani");
define("BANLAN_4", "Usu� blokad�");
define("BANLAN_5", "Wpisz IP, adres email lub nazw� hosta");
define("BANLAN_7", "Pow�d");
define("BANLAN_8", "Zablokuj adres");
define("BANLAN_9", "Zablokuj u�ytkownik�w strony po adres email, IP lub hosta");
define("BANLAN_10", "IP / email / pow�d");
define("BANLAN_11", "Auto-blokowanie: Wi�cej ni� 10 b��dnych pr�b logowania");
define("BANLAN_12", "Uwaga: rDNS (Reverse DNS - odwrotny DNS) jest obecnie niedost�pny. rDNS musi by� dost�pny, aby umo�liwi� blokowanie poprzez nazw� hosta. Blokowanie ze wzgl�du na adres IP oraz email wci�� funkcjonuj� normalnie.");
define("BANLAN_13", "Uwaga: Aby zablokowa� u�ytkownika po jego nazwie, przejd� do podstrony 'U�ytkownicy' w 'Panelu admina': ");

?>
