<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2007/02/19 16:58:12 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_comment.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_comment.php rev. 1.10
+-----------------------------------------------------------------------------+
*/

define("COMLAN_0", "[zablokowany przez admina]");
define("COMLAN_1", "Odblokuj");
define("COMLAN_2", "Zablokuj");
define("COMLAN_3", "Usu�");
define("COMLAN_4", "Informacje");
define("COMLAN_5", "Komentarze...");
define("COMLAN_6", "Aby wystawia� komentarze na tej stronie, musisz by� zalogowany. Zaloguj si� lub kliknij ");
define("COMLAN_7", "Strona g��wna administratora");
define("COMLAN_8", "Komentarz");
define("COMLAN_9", "Wy�lij komentarz");
define("COMLAN_10", "Administrator");
define("COMLAN_11", "Nie uda�o si� zamie�ci� komentarza w bazie danych - Aby spr�bowa� ponownie, usu� z komentarza wszystkie nietypowe znaki.");
define("COMLAN_16", "U�ytkownik: ");
define("COMLAN_99", "Komentarze");
define("COMLAN_100", "Aktualno�ci");
define("COMLAN_101", "Ankieta");
define("COMLAN_102", "Odpowiadanie na temat: ");
define("COMLAN_103", "Artyku�y");
define("COMLAN_104", "Recenzja");
define("COMLAN_105", "Publikacje");
define("COMLAN_145", "Zarejestrowany: ");
define("COMLAN_194", "Go��");
define("COMLAN_195", "Zarejestrowany u�ytkownik");
define("COMLAN_310", "Nie mog� zaakceptowa� wpisu, poniewa� podana nazwa u�ytkownika jest ju� zarejestrowana - Je�li podana login nale�y do Ciebie, prosz� si� zalogowa�, a nast�pnie ponownie wystawi� komentarz.");
define("COMLAN_312", "Wykryto duplikat wypowiedzi - Dodanie komentarza zako�czy�o si� niepowodzeniem.");
define("COMLAN_313", "Miejscowo��");
define("COMLAN_314", "Moderuj komentarze");
define("COMLAN_315", "Warto przeczyta�");
define("COMLAN_316", "Brak powi�za� dla tej wiadomo�ci.");
define("COMLAN_317", "Moderuj powi�zania");
define("COMLAN_318", "Edycja komentarza");
define("COMLAN_319", "edytowany");
define("COMLAN_320", "Zaktualizuj");
/*
define("COMLAN_1", "tutaj");
define("COMLAN_2", ", aby si� zarejestrowa�.");
define("COMLAN_3", "B��d!");
define("COMLAN_4", 'Temat');
define("COMLAN_5", 'Odp:');
define("COMLAN_6", 'Odpowiedz');
define("COMLAN_7", 'Ocena');
define("COMLAN_8", 'Komentarze zosta�y wy��czone');
*/
define("COMLAN_321", "tutaj");
define("COMLAN_322", ", aby si� zarejestrowa�.");
define("COMLAN_323", "B��d!");
define("COMLAN_324", 'Temat:');
define("COMLAN_325", 'Odp:');
define("COMLAN_326", 'Odpowiedz');
define("COMLAN_327", 'Ocena');
define("COMLAN_328", 'Komentarze zosta�y wy��czone');
define("COMLAN_329", 'Brak autoryzacji'); //Unauthorized
define("COMLAN_330", 'IP:');

define("COMLAN_TYPE_1", "News");
define("COMLAN_TYPE_2", "Download");
define("COMLAN_TYPE_3", "FAQ");
define("COMLAN_TYPE_4", "Ankieta");
define("COMLAN_TYPE_5", "Dokumentacja");
define("COMLAN_TYPE_6", "Bugtracker");
define("COMLAN_TYPE_7", "Pomys�y");
define("COMLAN_TYPE_8", "Profil u�ytkownika");

?>
