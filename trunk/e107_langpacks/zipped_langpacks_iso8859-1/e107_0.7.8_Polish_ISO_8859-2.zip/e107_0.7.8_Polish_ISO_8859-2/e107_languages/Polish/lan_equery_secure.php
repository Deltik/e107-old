<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:05:17 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_equery_secure.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_equery_secure.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("EQSEC_LAN1", "Zosta�e� przekierowany do funkcji administratora, by� mo�e baza danych zosta�a uszkodzona.");
define("EQSEC_LAN2", "Prosz� potwierdzi� wybran� czynno��:");
define("EQSEC_LAN3", "Bez odsy�acza");
define("EQSEC_LAN4", "Akcja od:");
define("EQSEC_LAN5", "Akcja do:");
define("EQSEC_LAN6", "Potwierd� wyb�r");
define("EQSEC_LAN7", "Lub anuluj");

?>
