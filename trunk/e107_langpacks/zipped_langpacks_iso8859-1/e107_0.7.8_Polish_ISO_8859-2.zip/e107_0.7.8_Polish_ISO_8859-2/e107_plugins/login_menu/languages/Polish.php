<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.8 $
|     $Date: 2006/11/19 17:04:56 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/login_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/login_menu/languages/English.php rev. 1.8
+-----------------------------------------------------------------------------+
*/
 
define("LOGIN_MENU_L1", "Login: ");
define("LOGIN_MENU_L2", "Has�o: ");
define("LOGIN_MENU_L3", "Rejestracja");
define("LOGIN_MENU_L4", "Zmiana has�a");
define("LOGIN_MENU_L5", "Witaj");
define("LOGIN_MENU_L6", "Zapami�taj mnie");
define("LOGIN_MENU_L7", "Unikalne ID u�ytkownika nie zosta�o rozpoznane (prawdopodobnie uszkodzony jest plik <o>cookie</i>).<br />Prosz� <a href=\"".e_BASE."index.php?logout\">klikn�� tutaj</a>, aby usun�� wadliwy plik <i>cookie</i>.");
define("LOGIN_MENU_L8", "Wyloguj");
define("LOGIN_MENU_L9", "B��d logowania");
define("LOGIN_MENU_L10", "Strona jest w trybie konserwacji - to oznacza, �e osoby odwiedzaj�ce Twoj� stron� zostan� przekierowane do strony sitedown.php. Aby przywr�ci� normalne funkcjonowanie witryny przejd� do panelu administratora i zmie� odpowiednie opcje w dziale <i>Konserwacja</i>.");
define("LOGIN_MENU_L11", "Panel admina");
define("LOGIN_MENU_L12", "Ustawienia");
define("LOGIN_MENU_L13", "Profil");
define("LOGIN_MENU_L14", "wiadomo��");
define("LOGIN_MENU_L15", "wiadomo�ci");
define("LOGIN_MENU_L16", "post na czacie");
define("LOGIN_MENU_L17", "post�w na czacie");
define("LOGIN_MENU_L18", "komentarz");
define("LOGIN_MENU_L19", "komentarzy");
define("LOGIN_MENU_L20", "post na forum");
define("LOGIN_MENU_L21", "post�w na forum");
define("LOGIN_MENU_L22", "nowy u�ytkownik");
define("LOGIN_MENU_L23", "nowych u�ytkownik�w");
define("LOGIN_MENU_L24", "Kliknij tutaj, aby zobaczy� list� nowych pozycji");
define("LOGIN_MENU_L25", "Od Twojej ostatniej wizyty na stronie pojawi�o si�");
define("LOGIN_MENU_L26", "0");
define("LOGIN_MENU_L27", "i");
define("LOGIN_MENU_L28", "Zaloguj");

define("LOGIN_MENU_L29", "nowy artyku�");
define("LOGIN_MENU_L30", "nowe artyku�y");

// New config options
define('LOGIN_MENU_L31', 'Poka� nowe aktualno�ci');
define('LOGIN_MENU_L32', 'Poka� nowe artyku�y');
define('LOGIN_MENU_L33', 'Poka� nowe posty na czacie');
define('LOGIN_MENU_L34', 'Poka� nowe komentarze');
define('LOGIN_MENU_L35', 'Poka� nowe posty na forum');
define('LOGIN_MENU_L36', 'Poka� nowo zarejestrowanych u�ytkownik�w');

define('LOGIN_MENU_L39', 'Opu�� panel');

define("LOGIN_MENU_L40", "Pon�w aktywacj�");
define("LOGIN_MENU_L41", "Ustawienia - Login Menu");

?>
