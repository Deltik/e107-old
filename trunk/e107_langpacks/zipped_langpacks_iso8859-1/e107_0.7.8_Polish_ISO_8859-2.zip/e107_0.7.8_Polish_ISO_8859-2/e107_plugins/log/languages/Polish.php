<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/06/28 17:05:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/log/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/log/languages/English.php rev. 1.7
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Statystyki");

define("ADSTAT_L1", "Plugin statystyk b�dzie zapisywa� wszystkie odwiedziny strony, a nast�pnie na podstawie zgromadzonych danych utworzy szczeg�owe statystyki.");
define("ADSTAT_L2", "Plugin statystyk zosta� pomy�lnie zainstalowany. Aby przetworzy� aktualne statystyki do nowszej wersji, prosz� <a href='".e_PLUGIN."log/update_routine.php'>klikn�� tutaj w celu uruchomienia podprogramu</a>.");
define("ADSTAT_L3", "Statystyki");
define("ADSTAT_L4", "Nie masz uprawnie� do przegl�danie tej strony.");
define("ADSTAT_L5", "Funkcje na tej stronie zosta�y wy��czone."); // The features on this page have been disabled
define("ADSTAT_L6", "Statystyki strony");
define("ADSTAT_L7", "Statystyki wskazanego typu nie zosta�y jeszcze utworzone.");
define("ADSTAT_L8", "Dzisiejsze statystyki");
define("ADSTAT_L9", "Og�lne statystyki");
define("ADSTAT_L10", "Dzienne statystyki");
define("ADSTAT_L11", "Miesi�czne statystyki");
define("ADSTAT_L12", "Przegl�darki");
define("ADSTAT_L13", "Systemy operacyjne");
define("ADSTAT_L14", "Domeny");
define("ADSTAT_L15", "Rozdzielczo�� ekranu oraz g��bia kolor�w");
define("ADSTAT_L16", "Strony odsy�aj�ce");
define("ADSTAT_L17", "S�owa kluczowe");
define("ADSTAT_L18", "Ostatni go�cie");
define("ADSTAT_L19", "Strona");
define("ADSTAT_L20", "Dzisiejszych odwiedzin");
define("ADSTAT_L21", "Wszystkich");
define("ADSTAT_L22", "Unikalnych");
define("ADSTAT_L23", "Wszystkich wizyt");
define("ADSTAT_L24", "Wszystkich unikalnych wizyt");
define("ADSTAT_L25", "Nie ma jeszcze statystyk wskazanego typu.");
define("ADSTAT_L26", "Przegl�darka");
define("ADSTAT_L27", "System operacyjny");
define("ADSTAT_L28", "Kraje i domeny");
define("ADSTAT_L29", "Rozdzielczo�� ekranu");
define("ADSTAT_L30", "Strona odsy�aj�ca");
define("ADSTAT_L31", "Wyszukiwarki - s�owa kluczowe");
define("ADSTAT_L32", "Odes�any z");
define("ADSTAT_L33", "Odwiedziny w ci�gu ostatnich");
define("ADSTAT_L34", "Odwiedziny");
define("ADSTAT_L35", "Unikalnych odwiedzin w ci�gu ostatnich");
define("ADSTAT_L36", "dni na stronach");
define("ADSTAT_L37", "Odwiedziny w miesi�cu");
define("ADSTAT_L38", "Unikalnych odzwiedzin w miesi�cu");
define("ADSTAT_L39", "Usu� wskazane wpisy");
define("ADSTAT_L40", "dni");
define("ADSTAT_L41", "B��d");

?>
