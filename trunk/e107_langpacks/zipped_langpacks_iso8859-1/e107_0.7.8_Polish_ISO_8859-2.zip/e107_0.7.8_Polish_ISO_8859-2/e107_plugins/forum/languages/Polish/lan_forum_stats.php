<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:37:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum_stats.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_newforumposts_menu.php rev rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("e_PAGETITLE", "Statystyki forum");

define("FSLAN_1", "Og�lne");
define("FSLAN_2", "Forum otwarto");
define("FSLAN_3", "Dzia�a od");
define("FSLAN_4", "Wszystkich wypowiedzi");
define("FSLAN_5", "Temat�w na forum");
define("FSLAN_6", "Post�w na forum");
define("FSLAN_7", "Wy�wietle� temat�w");
define("FSLAN_8", "Rozmiar bazy danych (tylko tabela forum)");
define("FSLAN_9", "�rednia rozmiar wiersza w tabeli forum");
define("FSLAN_10", "Lista Top : Najbardziej aktywne tematy");
define("FSLAN_11", "Pozycja");
define("FSLAN_12", "Temat");
define("FSLAN_13", "Posty");
define("FSLAN_14", "Autor");
define("FSLAN_15", "Data");
define("FSLAN_16", "Lista Top : Najch�tniej czytane tematy");
define("FSLAN_17", "Ods�on");
define("FSLAN_18", "Lista Top : Najbardziej aktywni u�ytkownicy");
define("FSLAN_19", "Imi�");
define("FSLAN_20", "Posty");
define("FSLAN_21", "Lista Top : Najwi�cej za�o�yli temat�w");
define("FSLAN_22", "Lista Top : Najwi�cej zamie�cili odpowiedzi");
define("FSLAN_23", "Statystyki forum");
define("FSLAN_24", "�rednia ilo�� post�w na dzie�");

?>
