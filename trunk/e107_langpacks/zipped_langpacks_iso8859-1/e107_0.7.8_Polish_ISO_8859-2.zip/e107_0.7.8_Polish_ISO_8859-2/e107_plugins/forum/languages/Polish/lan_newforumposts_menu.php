<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:37:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_newforumposts_menu.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_newforumposts_menu.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("NFP_1", "Wszystkie ostatnie posty s� niedost�pne dla Twojej grupy u�ytkownik�w, nie mog� ich wy�wietli�.");
define("NFP_2", "Obecnie nie ma �adnych nowych post�w");
define("NFP_3", "Konfiguracja menu zosta�a zapisana");
define("NFP_4", "Nag��wek");
define("NFP_5", "Ilo�� wy�wietlanych post�w?");
define("NFP_6", "Ilo�� wy�wietlanych znak�w?");
define("NFP_7", "Przyrostek dla zbyt d�ugich wypowiedzi?");
define("NFP_8", "Pokazywa� oryginalne tematy w menu?");
define("NFP_9", "Aktualizuj ustawienia menu");
define("NFP_10", "Konfiguracja menu Nowych Post�w na Forum");
define("NFP_11", "Autor");

?>
