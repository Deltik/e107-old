<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2006/11/01 20:21:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/pm/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/pm/languages/English.php rev. 1.13, Mon Oct 30 14:01:47 2006 UTC
+-----------------------------------------------------------------------------+
*/
 
define('LAN_PM', "Wiadomo�� prywatna");
define('LAN_PM_1', "Wy�lij wiadomo�� prywatn�");
define('LAN_PM_2', "Do");
define('LAN_PM_3', "Podgl�d");
define('LAN_PM_4', "Grupa u�ytkownik�w");
define('LAN_PM_5', "Temat");
define('LAN_PM_6', "Wiadomo��");
define('LAN_PM_7', "Emoty");
define('LAN_PM_8', "Za��cznik");
define('LAN_PM_9', "Potwierdzenie odbioru"); //Read receipt
define('LAN_PM_10', "Wy�lij do mnie emaila potwierdzaj�cego przeczytanie tej wiadomo�ci");
define('LAN_PM_11', "dodaj nowy plik");
define('LAN_PM_12', "Nie masz uprawnie� do u�ywania systemu Wiadomo�ci Prywatnych");
define('LAN_PM_13', "Twoja skrzynka odbiorcza jest zape�niona w {PERCENT}% - nie mo�esz wysy�a� wiadomo�ci prywatnych dop�ki czego� nie usuniesz");
define('LAN_PM_14', "B��D: Prawdopodobnie taka wiadomo�� ju� istniej, wiadomo�� nie zosta�a wys�ana");
define('LAN_PM_15', "Nie posiadasz uprawnie� do wysy�ania wiadomo�ci do wskazanej grupy u�ytkownik�w");
define('LAN_PM_16', "Musisz by� u�ytkownikiem grupy");
define('LAN_PM_17', "Podany u�ytkownik nie zosta� odnaleziony");
define('LAN_PM_18', "Nie masz uprawnie� do wys�ania wiadomo�ci do: ");
define('LAN_PM_19', "Twoja skrzynka odbiorcza jest pe�na, nie posiadasz uprawnie� do wysy�ania wiadomo�ci prywatnych");
define('LAN_PM_21', "Dodanie tej wiadomo�ci prywatnej spowoduje przekroczenie maksymalnego rozmiaru Twojej skrzynki nadawczej, wiadomo�� nie zosta�a wys�ana"); // Adding this PM will exceed your maximum outbox size
define('LAN_PM_22', "B��d �adowania pliku");
define('LAN_PM_23', "Nie posiadasz uprawnie� do wysy�ania za��cznik�w");
define('LAN_PM_24', "Usu� wiadomo��");
define('LAN_PM_25', "Skrzynka odbiorcza");
define('LAN_PM_26', "Skrzynka nadawcza");
define('LAN_PM_27', "Nieczytane");
define('LAN_PM_28', "N/A");
define('LAN_PM_29', "Wiadomo�� wys�ana");
define('LAN_PM_30', "Wiadomo�� przeczytana");
define('LAN_PM_31', "Od");
define('LAN_PM_32', "Otrzymana");
define('LAN_PM_33', "Wys�ana");
define('LAN_PM_34', "Brak wiadomo�ci");
define('LAN_PM_35', "Wy�lij now� wiadomo��");
define('LAN_PM_36', "wszystkich");
define('LAN_PM_37', "nieczytanych");
define('LAN_PM_38', "Wiadomo�� zosta�a wys�ana do u�ytkownik�w grupy");
define('LAN_PM_39', "B��d wysy�ania wiadomo�ci do");
define('LAN_PM_40', "Wiadomo�� zosta�a wys�ana do u�ytkownika");
define('LAN_PM_41', "B��d zapisu wiadomo�ci do skrzynki nadawczej");

define('LAN_PM_42', "Wiadomo�� zosta�a usuni�ta ze skrzynki odbiorczej");
define('LAN_PM_43', "Wiadomo�� zosta�a usuni�ta ze skrzynki nadawczej");
define('LAN_PM_44', "Blokada usuni�ta: {UNAME} mo�e teraz wysy�a� do Ciebie wiadomo�ci prywatne");
define('LAN_PM_45', "B��D: Blokada nie zosta�a usuni�ta, wyst�pi� nieokre�lony b��d");
define('LAN_PM_46', "Nie ma aktualnie ogranicze� dla {UNAME}"); // Block not in place for
define('LAN_PM_47', "Blokada dodana: {UNAME} utraci�(a) uprawnienia do wysy�ania wiadomo�ci na Twojej konto");
define('LAN_PM_48', "B��D: Blokada nie dodana, nieokre�lony b��d");
define('LAN_PM_49', "B��D: Blokada dla {UNAME} ju� istnieje"); // Block already in place for
define('LAN_PM_50', "Zablokuj u�ytkownika");
define('LAN_PM_51', "Odblokuj u�ytkownika");
define('LAN_PM_52', "Usu�");
define('LAN_PM_53', "Usu� zaznaczone");
define('LAN_PM_54', "Cytuj orygina�");
define('LAN_PM_55', "Odpowiedz");
define('LAN_PM_56', "Nie masz uprawnie� do odpowiedzenia na t� wiadomo��");
define('LAN_PM_57', "Wiadomo�� nieodnaleziona");
define('LAN_PM_58', "Odp: ");
define('LAN_PM_59', "Id� do strony: ");
define('LAN_PM_60', "Nie masz uprawnie� do wy�wietlenia tej wiadomo�ci");
define('LAN_PM_61', "Bez tematu");
define('LAN_PM_62', "Plik: [{FILENAME}] przekracza limit wielko�ci - nie do��czono");
define('LAN_PM_63', "Grupa:");

define("LAN_PM_100", "Nowa wiadomo�� prywatna od ");
define("LAN_PM_101", "Otrzyma�e� now� wiadomo�� prywatn� od ");
define("LAN_PM_102", "Nadawc� wiadomo�ci jest: ");
define("LAN_PM_103", "Temat: ");
define("LAN_PM_104", "Ilo�� za��cznik�w: ");
define("LAN_PM_105", "Mo�esz zobaczy� t� wiadomo�� w: ");
define("LAN_PM_106", "Wiadomo�� zosta�a przeczytana przez ");
define("LAN_PM_107", "Wiadomo�� prywatna, kt�r� wys�a�e� do {UNAME}, zosta�a przeczytana dnia ");
define("LAN_PM_108", "Wiadomo�� wys�ana dnia: ");
define("LAN_PM_109", "Nowa wiadomo��");
define("LAN_PM_110", "OK");
define("LAN_PM_111", "Czytaj");

?>
