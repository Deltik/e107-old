<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/14 00:33:38 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_themes/jayya/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_themes/jayya/languages/English.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("LAN_THEME_1", "Komentarze zosta�y wy��czone");
define("LAN_THEME_2", "Komentarze: ");
define("LAN_THEME_3", "Czytaj reszt�...");
define("LAN_THEME_4", "Powi�zania: ");
define("LAN_THEME_5", "Autor: ");
define("LAN_THEME_6", "dnia: ");

?>
