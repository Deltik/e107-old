<?php
/**
* PHPMailer language file.
* Hungarian Version
*/

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Legal�bb egy c�met meg kell adnod ' . 'c�mzettek email c�me.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer nem t�mogatott.';
$PHPMAILER_LANG["execute"] = 'Nem v�grehajthat�: ';
$PHPMAILER_LANG["instantiate"] = 'Nem rendelkezik s�rg�ss�gi mail funkci�val.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Hiba: Nincs hiteles�t�s.';
$PHPMAILER_LANG["from_failed"] = 'A k�vetkez� c�mt�l hiba: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Hiba: A k�vetkez� ' . 'c�mzettek hib�sak: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Hiba: Adat nincs elfogadva.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Hiba: Nem lehet csatlakozni az SMTP kiszolg�l�hoz.';
$PHPMAILER_LANG["file_access"] = 'Nincs hozz�f�r�s file: ';
$PHPMAILER_LANG["file_open"] = 'File Hiba: Nem lehet megnyitni a file-t: ';
$PHPMAILER_LANG["encoding"] = 'Ismeretlen k�dol�s: ';
?>