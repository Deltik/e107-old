<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_SITELINKS_183", "F�men�");
define("LAN_SITELINKS_502", "Admin ter�let");

?>
