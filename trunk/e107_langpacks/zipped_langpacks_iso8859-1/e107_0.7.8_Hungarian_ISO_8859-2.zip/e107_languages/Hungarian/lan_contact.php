<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Kapcsolat r�szletei");
define("LANCONTACT_02", "Kapcsolat");
define("LANCONTACT_03", "�rd be a neved:");
define("LANCONTACT_04", "E-mail c�m:");
define("LANCONTACT_05", "�zenet t�rgya:");
define("LANCONTACT_06", "�rd be az �zenetet:");
define("LANCONTACT_07", "Email �zenet m�solat�nak elk�ld�se a saj�t c�mre ");
define("LANCONTACT_08", "K�ld�s");
define("LANCONTACT_09", "�zeneted elk�ldve.");
define("LANCONTACT_10", "Probl�ma mer�lt fel az �zenet elk�ld�se folyam�n.");
define("LANCONTACT_11", "Az email c�med �rv�nytelen.\\nEllen�rizd, majd pr�b�ld �jra.");
define("LANCONTACT_12", "Az �zeneted nagyon r�vid.");
define("LANCONTACT_13", "Add meg az �zenet t�rgy�t.");


define("LANCONTACT_14", "�zenet k�ld�se a k�vetkez�nek:");
define("LANCONTACT_15", "�rv�nytelen k�dot �rt�l be");
define("LANCONTACT_16", "K�d be�r�sa");




?>
