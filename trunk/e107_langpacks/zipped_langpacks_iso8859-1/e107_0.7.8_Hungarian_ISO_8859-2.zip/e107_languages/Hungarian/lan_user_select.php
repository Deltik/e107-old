<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("US_LAN_1", "Felhaszn�l� kiv�laszt�sa");
define("US_LAN_2", "Felhaszn�l� csoport kiv�laszt�sa");
define("US_LAN_3", "�sszes felhaszn�l�");
define("US_LAN_4", "Felhaszn�l�n�v keres�se");
define("US_LAN_5", "Felhaszn�l�t tal�lt");
define("US_LAN_6", "Keres�s");
?>