<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LANDT_01", "�v");
define("LANDT_02", "h�nap");
define("LANDT_03", "h�t");
define("LANDT_04", "nap");
define("LANDT_05", "�ra");
define("LANDT_06", "perc");
define("LANDT_07", "m�sodperc");
define("LANDT_01s", "�v");
define("LANDT_02s", "h�nap");
define("LANDT_03s", "h�t");
define("LANDT_04s", "nap");
define("LANDT_05s", "�ra");
define("LANDT_06s", "perc");
define("LANDT_07s", "m�sodperc");

define("LANDT_08", "perc");
define("LANDT_08s", "perc");
define("LANDT_09", "mp");
define("LANDT_09s", "mp");
define("LANDT_AGO", "ezel�tt");

?>
