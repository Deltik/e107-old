<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

setlocale(LC_ALL, 'hu_HU.ISO8859-2', 'hu_HU@euro', 'hu_HU', 'hu', 'Hungarian');
define("CORE_LC", 'hu');
define("CORE_LC2", 'HU.iso-8859-2');
// define("TEXTDIRECTION","rtl");
define("CHARSET", "iso-8859-2");  // for a true multi-language site. :)
define("CORE_LAN1","Hiba : A t�ma hi�nyzik.\\n\\nCser�ld le a be�ll�t�sokn�l a haszn�lt t�m�t (admin ter�let) vagy t�lts fel az aktu�lis t�ma file-it a szerverre.");

//v.616
define("CORE_LAN2", " \\1 �rta:");// "\\1" represents the username.
define("CORE_LAN3", "f�jl csatol�sa nem enged�lyezett");

//v0.7+
define("CORE_LAN4", "T�r�ld az install.php file-t a szerveredr�l");
define("CORE_LAN5", "ha nem hajtod v�gre, akkor az oldalad potenci�lis biztons�gi kock�zatnak van kit�ve");

// v0.7.6
define("CORE_LAN6", "A flood v�delem ezen az oldalon aktiv�lva van �s figyelmeztet t�ged, ha folytatod az oldal folyamatos lek�rdez�s�t, akkor ki leszel tiltva.");
define("CORE_LAN7", "A mag (Core) megkis�rli a helyre�ll�t�st az aut�matikus biztons�gi ment�sb�l.");
define("CORE_LAN8", "Mag (Core) be�ll�t�sok Hiba");
define("CORE_LAN9", "A mag (Core) nem tudja a vissza�ll�t�st v�grehajtani az aut�matikus ment�sb�l. V�grehajt�s megszak�tva.");
define("CORE_LAN10", "Korrupt cookie �szlel�se - Kijelentkezett.");


define("LAN_WARNING", "Figyelmeztet�s!");
define("LAN_ERROR", "Hiba");
define("LAN_ANONYMOUS", "Anonymous");
?>
