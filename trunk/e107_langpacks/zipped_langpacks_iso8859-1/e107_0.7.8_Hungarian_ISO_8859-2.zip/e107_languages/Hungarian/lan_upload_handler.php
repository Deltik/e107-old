<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LANUPLOAD_1", "A f�jlt�pus");
define("LANUPLOAD_2", "nem enged�lyezett, t�r�lve lett.");
define("LANUPLOAD_3", "Sikeresen felt�ltve");
define("LANUPLOAD_4", "A c�lk�nyvt�r nem l�tezik, vagy nem �rhat�.");
define("LANUPLOAD_5", "A file t�ll�pte a php.ini -ben meghat�rozott maxim�lis m�retet.");
define("LANUPLOAD_6", "A file t�ll�pte a HTML formul�ban meghat�rozott maxim�lis m�retet.");
define("LANUPLOAD_7", "A file csak r�szben lett felt�ltve.");
define("LANUPLOAD_8", "Nem lett semmi felt�ltve.");
define("LANUPLOAD_9", "Felt�lt�tt filem�ret: 0 byte");
define("LANUPLOAD_10", "A felt�lt�s nem siker�lt [Duplik�lt f�jln�v] - M�r van ilyen nev� f�jl.");
define("LANUPLOAD_11", "A f�jl nem lett felt�ltve. F�jln�v: ");
define("LANUPLOAD_12", "Hiba");

?>