<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("USFLAN_1", "IP c�m meghat�rozatlan - nem �ll rendelkez�sre inform�ci�");
//define("USFLAN_2", "Hiba");
define("USFLAN_3", "Ezen IP c�mr�l k�ld�tt �zenetek");
define("USFLAN_4", "Kiszolg�l�");
define("USFLAN_5", "IP c�m blokkol�sa");
define("USFLAN_6", "Felhaszn�l� ID");
define("USFLAN_7", "Felhaszn�l� inform�ci�");

?>