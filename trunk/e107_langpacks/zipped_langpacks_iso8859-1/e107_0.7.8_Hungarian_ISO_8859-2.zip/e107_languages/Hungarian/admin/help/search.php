<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/search.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/08/27 02:24:45 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ha a MySQL szerver verzi�ja t�mogatja, akkor be�ll�thatod 
a MySQL rendez�si m�dszer�t, amely gyorsabb, mint a PHP rendez�si m�dszere. N�zd meg a be�ll�t�sokat.<br /><br />
Ha az oldalad k�p�r�sos nyelvet haszn�l, �gy mint K�nai vagy Jap�n, akkor mindenk�ppen 
PHP rendez�si m�dszert kell haszn�lni �s ki kell kapcsolnod az eg�sz szavak keres�s�t.";
$ns -> tablerender("Keres�s - S�g�", $text);
?>
