<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_head_1", "Admin Navig�ci�");
define("LAN_head_2", "A szervered nem engedi a HTTP alap� filefelt�lt�st, enn�lfogva felhaszn�l�id nem tudnak avatart/f�jlokat felt�lteni. Ezen �llapot megsz�ntet�s�hez enged�lyezd a file_uploads opci�t a php.ini -ben �s ind�tsd �jra a szervert. Ha nincs jogosults�god a php.ini el�r�s�hez, l�pj kapcsolatba a szerver adminisztr�tor�val.");
define("LAN_head_3", "A szerver basedir korl�toz�ssal fut. Emiatt nem tudsz el�rni semmilyen f�jlt a saj�t k�nyvt�rodon k�v�l. Ez bezavarhat n�h�ny olyan szkriptnek, mint a f�jlkezel�.");

define("LAN_head_4", "Admin ter�let");

define("LAN_head_5", "az adminter�let nyelve: ");
define("LAN_head_6", "Plugin info");

?>