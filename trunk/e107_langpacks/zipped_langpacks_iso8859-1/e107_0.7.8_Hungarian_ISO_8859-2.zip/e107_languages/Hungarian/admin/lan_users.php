<?php
# ---------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# ---------------------------------------------------------------------------

define("USRLAN_1", "Be�ll�t�sok elmentve");
define("USRLAN_3", "adminisztr�tor - a jogosults�gok be�ll�t�s�hoz menj az");
define("USRLAN_4", "adminisztr�torok oldalra");
define("USRLAN_5", "A f� admin jogosults�gai nem vonhat�ak vissza");
define("USRLAN_6", "admin jogai megvonva");
define("USRLAN_7", "A f� admin nem tilthat� ki");
define("USRLAN_8", "felhaszn�l� kitiltva");
define("USRLAN_9", "Kitilt�s megsz�ntetve");
define("USRLAN_10", "Felhaszn�l� t�r�lve");
define("USRLAN_11", "T�rl�s visszavonva");
define("USRLAN_12", "Nem t�r�lheted a f� admint");
define("USRLAN_13", "Biztosan t�r�lni akarod ezt a tagot?");
//define("USRLAN_14", "Nem vissza�ll�that�!");
//define("USRLAN_15", "M�gse");
define("USRLAN_16", "T�rl�s meger�s�t�se");
define("USRLAN_17", "Tag t�rl�s�nek meger�s�t�se");
//define("USRLAN_18", "felhaszn�l� aktiv�lva");
//define("USRLAN_19", "Keres�s");
//define("USRLAN_20", "Rendez�s:");
//define("USRLAN_21", "ID");
//define("USRLAN_22", "Felhaszn�l�i n�v");
//define("USRLAN_23", "L�togat�sok sz�ma");
//define("USRLAN_24", "Admin st�tusz");
//define("USRLAN_25", "St�tusz");
//define("USRLAN_26", "Cs�kken�");
//define("USRLAN_27", "N�vekv�");
//define("USRLAN_28", "Rendez�s");

define("USRLAN_30", "Kitilt�s");
//define("USRLAN_31", "Kitilt�s -kikapcsolva-");
define("USRLAN_32", "Aktiv�l�s");
define("USRLAN_33", "Kitilt�s megsz�ntet�se");
define("USRLAN_34", "Admin rang megvon�sa");
define("USRLAN_35", "Admin rang kioszt�sa");
define("USRLAN_36", "Csoport be�ll�t�sa");

//define("USRLAN_37", "Tagok");
//define("USRLAN_38", "A keres�s eredm�nye");
//define("USRLAN_39", "tal�lat");
//define("USRLAN_40", "Nincs semmi megadva");

define("USRLAN_44", "Tagok t�lthetnek fel avatart?");

define("USRLAN_47", "Maxi�lis avatar sz�less�g (pixel)");
define("USRLAN_48", "Aalap�rtelmezett: 120");
define("USRLAN_49", "Maxim�lis avatar magass�g (pixel)");
define("USRLAN_50", "Alap�rtelmezett: 100");
define("USRLAN_51", "Mehet");
define("USRLAN_52", "Tagok be�ll�t�sa");
define("USRLAN_53", "Fot� felt�lt�se enged�lyezve a tagoknak?");
define("USRLAN_54", "�sszes aktiv�latlan felhaszn�l� t�rl�se");
define("USRLAN_55", "Karbantart�s");
define("USRLAN_56", "T�r�lve");
define("USRLAN_57", "Aktiv�latlan tagok t�rl�se ...");
define("USRLAN_58", "A f�jlok felt�lt�se tiltva a php.ini-ben");
define("USRLAN_59", "Tag gyors felv�tele");
define("USRLAN_60", "Tag felv�tele");
define("USRLAN_61", "Felhaszn�l�n�v");
define("USRLAN_62", "Jelsz�");
define("USRLAN_63", "Jelsz� �jra");
define("USRLAN_64", "E-mail c�m");
define("USRLAN_65", "A felhaszn�l�n�v nem fogadhat� el �rv�nyesnek, v�lassz m�sikat");
define("USRLAN_66", "A felhaszn�l�n�v m�r l�tezik az adatb�zisban, v�lassz m�sikat");
define("USRLAN_67", "A k�t jelsz� nem egyezik");
define("USRLAN_68", "K�telez� mez�(ke)t hagyt�l �resen");
define("USRLAN_69", "Ez nem t�nik val�s e-mail c�mnek");
define("USRLAN_70", "Tag sikeresen felv�ve");
define("USRLAN_71", "Tagok f�oldala");
define("USRLAN_72", "Tag gyors felv�tele");
define("USRLAN_73", "Tagok karbantart�sa");
//define("USRLAN_75", "M�veletek");
define("USRLAN_76", "Be�ll�t�sok");
define("USRLAN_77", "Tagok");
define("USRLAN_78", "Felhaszn�l�n�v");
define("USRLAN_79", "�llapot");
define("USRLAN_80", "Info");

//define("USRLAN_82", "Biztosan t�r�lni akarod ezt a tagot?");
define("USRLAN_84", "Van");
define("USRLAN_85", "tag, aki m�g nem er�s�tette meg a regisztr�ci�j�t - kattints a lenti gombra a t�rl�shez");
define("USRLAN_86", "Tag ellen�rizve");
define("USRLAN_87", "Tag be�ll�t�sok friss�tve");
define("USRLAN_88", "Csoportok friss�tve");

define("USRLAN_90", "Keres�s/friss�t�s");
define("USRLAN_91", "Csoport");
define("USRLAN_92", "Nem megengedett karakterek a felhaszn�l�n�vben");

define("USRLAN_93", "Meger�s�t�s n�lk�li felhaszn�l�k t�rl�se");
define("USRLAN_94", "Regisztr�ci� t�rl�se, ha adott id�tartam alatt nincs meger�s�tve - Hagyd �resen, ha nem akarod haszn�lni ezt a lehet�s�get");
define("USRLAN_95", "perc");


define("USRLAN_112", "E-mail �jrak�ld�se");
define("USRLAN_113", "Regisztr�ci�s adatok:");
define("USRLAN_114", "Kedves ");
define("USRLAN_115", "K�sz�nj�k a regisztr�ci�t.");
define("USRLAN_116", "Er�s�tsd meg, hogy �jra akarod k�ldetni az aktiv�l�shoz sz�ks�ges e-mailt a k�vetkez�:");
define("USRLAN_117", "Kattints az al�bbi gombra a k�vetkez� e-mail c�m tesztel�s�re:");
define("USRLAN_118", "Teszt e-mail k�ld�se");

define("USRLAN_120", "Csoportok be�ll�t�sa");
define("USRLAN_121", "E-mail k�ld�se");
define("USRLAN_122", "�dv�z�l a(z) ");
define("USRLAN_123", "Regisztr�ci�d sikeres volt.");
define("USRLAN_124", "A regisztr�ci�d jelenleg inakt�v, az aktiv�l�s�hoz kattints az al�bbi linkre ...");
define("USRLAN_125", "Felad�:");

define("USRLAN_126", "A tagok �rt�kelhetik egym�st");
define("USRLAN_127", "Hozz�sz�l�sok enged�lyez�se a tag profilj�ban");

define("USRLAN_128", "Bejelentkez� n�v");

define("USRLAN_130", "Online felhaszn�l�k k�vet�s�nek enged�lyez�se");
define("USRLAN_131", "Enged�lyezned kell ezt az opci�t az online felhaszn�l�k k�vet�s�nek haszn�lat�hoz, �gymint online.php, f�rum online info �s egy�b online men�k");
define("USRLAN_132", "Enged�lyez�s");

define("USRLAN_133", "Felhaszn�l� utas�t�sa a be�ll�t�sainak friss�t�s�re");
define("USRLAN_134", "Ennek az opci�nak az enged�lyez�se eset�n automatikusan �tir�ny�tja a felhaszn�l�t a be�ll�t�sok oldalra, ha k�telez� mez�t hagyott �resen.");

define("USRLAN_135", "No IP address found in user's info, IP not banned");
define("USRLAN_136", "Multiple users found with IP address of {IP}, IP not banned.");
define("USRLAN_137", "Users IP address of {IP} banned.");

define("LAN_MAINADMIN","F� Admin");
define("LAN_ADMIN","Admin");
define("LAN_NOTVERIFIED","Nincs Ellen�rizve");
define("LAN_BANNED","Kitiltva");

define("DUSRLAN_1", "ID");
define("DUSRLAN_2", "Megjelen� n�v");
define("DUSRLAN_3", "Felhaszn�l�n�v");
define("DUSRLAN_4", "Rang");
define("DUSRLAN_5", "Jelsz�");
define("DUSRLAN_6", "Szekci�");
define("DUSRLAN_7", "Email");
define("DUSRLAN_8", "Weboldal");
define("DUSRLAN_9", "ICQ");
define("DUSRLAN_10", "AIM");
define("DUSRLAN_11", "MSN");
define("DUSRLAN_12", "Lakhely");
define("DUSRLAN_13", "Sz�let�snap");
define("DUSRLAN_14", "Al��r�s");
define("DUSRLAN_15", "K�p");
define("DUSRLAN_16", "Id�z�na");
define("DUSRLAN_17", "Email c�m elrejt�se");
define("DUSRLAN_18", "Csatlakoz�s d�tuma");
define("DUSRLAN_19", "Utols� l�togat�s");
define("DUSRLAN_20", "L�togat�sok");
define("DUSRLAN_21", "Utols� �zenet");
define("DUSRLAN_22", "Chatbox �zenet");
define("DUSRLAN_23", "Hozz�sz�l�s");
define("DUSRLAN_24", "F�rum�zenetek");
define("DUSRLAN_25", "IP");
define("DUSRLAN_26", "Kitilt�s");
define("DUSRLAN_27", "Be�ll�t�sok");
define("DUSRLAN_28", "�j");
define("DUSRLAN_29", "Megtekint�s");
define("DUSRLAN_30", "L�togat�s");
define("DUSRLAN_31", "Admin");
define("DUSRLAN_32", "Val�di n�v");
define("DUSRLAN_33", "Felhaszn�l�i csoport");
define("DUSRLAN_34", "Jogosults�gok");
define("DUSRLAN_35", "K�p");
define("DUSRLAN_36", "Jelsz� megv�ltoztat�sa");
define("DUSRLAN_37", "XUP");

define("USRLAN_138", "Nem ellen�rz�tt felhaszn�l�k");
define("USRLAN_139", "Hozz�f�r�sed aktiv�lva.\n\nL�togass el a(z) {SITEURL} oldalra �s l�pj be az �ltalad megadott felhaszn�l�i adatokkal.");

define("USRLAN_140", "Email �jrak�ldve a k�vetkez�nek");
define("USRLAN_141", "E-mail �jrak�ld�se sikertelen a k�vetkez�nek");
define("USRLAN_142", "a k�vetkez� aktiv�l� linkkel");

define("LAN_BOUNCED","Visszadobott");
define("USRLAN_143", "Visszadobott mail ellen�rz�se");
define("USRLAN_144", "Meger�s�t� Email �jrak�ld�se mindenkinek");
define("USRLAN_145", "Visszautas�tott felhaszn�l�k");
define("USRLAN_146", "Tag inform�ci�k enged�lyez�se");
?>
