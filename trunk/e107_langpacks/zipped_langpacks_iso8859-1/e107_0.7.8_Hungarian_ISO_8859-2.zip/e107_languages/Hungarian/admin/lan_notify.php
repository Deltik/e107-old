<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NT_LAN_1", "�rtes�t�s");
define("NT_LAN_2", "Email �rtes�t�s bekapcsol�sa");
define("NT_LAN_3", "Ki");
define("NT_LAN_4", "F� Admin");
define("NT_LAN_5", "Csoport");
define("NT_LAN_6", "Email");

define("NU_LAN_1", "Esem�ny");
define("NU_LAN_2", "Al��r�s");
define("NU_LAN_3", "Felhaszn�l�i hozz�f�r�s meger�s�t�se");
define("NU_LAN_4", "Bejelentkez�s");
define("NU_LAN_5", "Kijelentkez�s");

define("NS_LAN_1", "Biztons�gi Esem�ny");
define("NS_LAN_2", "Kitiltott IP");

define("NN_LAN_1", "H�r esem�nyek");
define("NN_LAN_2", "H�rt bek�ldte");
define("NN_LAN_3", "H�rt bek�ldte Admin");
define("NN_LAN_4", "H�rt szerkesztette Admin");
define("NN_LAN_5", "H�rt t�r�lte Admin");

define("NF_LAN_1", "File Esem�nyek");
define("NF_LAN_2", "Felhaszn�l� �ltal felt�lt�tt file");

?>
