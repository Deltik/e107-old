<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PRFLAN_52", "M�dos�t�sok ment�se");
define("PRFLAN_63", "Teszt e-mail k�ld�se");
define("PRFLAN_64", "A gombra kattintva egy teszt e-mail lesz elk�ldve a f� admin e-mail c�m�re");
define("PRFLAN_65", "E-mail k�ld�se:");
define("PRFLAN_66", "Teszt e-mail inn�t:");
define("PRFLAN_67", "Ez egy teszt e-mail, azt jelzi, hogy az e-mail be�ll�t�said j�k!\n\n�dv�zlettel\naz e107 website system.");
define("PRFLAN_68", "Az e-mail elk�ld�se nem siker�lt. Lehet, hogy a szerver e-mail k�ld�si be�ll�t�sai hib�sak, pr�b�ld �jra SMTP haszn�lat�val, vagy egyeztesd a szolg�ltat�ddal a sendmail / e-mail szerver be�ll�t�sokat.");
define("PRFLAN_69", "Az e-mail sikeresen elk�ldve, ellen�rizd a postafi�kod.");
define("PRFLAN_70", "Lev�lk�ld�s m�dszere");
define("PRFLAN_71", "Ha bizonytalan vagy, hagyd php-n.");
define("PRFLAN_72", "SMTP szerver");
define("PRFLAN_73", "SMTP felhaszn�l�n�v");
define("PRFLAN_74", "SMTP jelsz�");
define("PRFLAN_75", "Az e-mail elk�ld�se nem siker�lt. N�zd �t az SMTP be�ll�t�sokat, vagy tiltsd le az SMTP-t �s pr�b�ld meg �jra.");

define("MAILAN_01","Felad� neve");
define("MAILAN_02","Felad� e-mail c�me");
define("MAILAN_03","C�mzett");
define("MAILAN_04","M�solat (Cc)");
define("MAILAN_05","Titkos m�solat (Bcc)");
define("MAILAN_06","T�rgy");
define("MAILAN_07","Mell�klet");
define("MAILAN_08","E-mail k�ld�se");
define("MAILAN_09","Theme st�lus haszn�lata");
define("MAILAN_10","Felhaszn�l� a csoportban");
define("MAILAN_11","V�ltoz�k besz�r�sa");
define("MAILAN_12","Minden tag");
define("MAILAN_13","Minden nem ellen�rz�tt tag");
define("MAILAN_14","Aj�nlott az SMTP enged�lyez�se a be�ll�t�sokn�l sok e-mail k�ld�se eset�n.");
define("MAILAN_15","Kimen� E-mail");

define("MAILAN_16","Felhaszn�l�n�v");
define("MAILAN_17","link");
define("MAILAN_18","Felhaszn�l�i id");
define("MAILAN_19","Nem tal�lhat� oldal-admin email c�m. Ellen�rizd a be�ll�t�saidat �s pr�b�ld �jra.");
define("MAILAN_20","�zenetk�ld�s-�tvonal");
define("MAILAN_21","Csoportos-Mail bejegyz�s");
define("MAILAN_22","A bejegyz�s ment�se sikertelen");
define("MAILAN_23","felhaszn�l� csoport: ");
define("MAILAN_24", "email(ek) k�ld�sre k�szen");

define("MAILAN_25", "Sz�net");
define("MAILAN_26", "Sz�net csoportos lev�lk�ld�s eset�n, minden");
define("MAILAN_27", "email ut�n");
define("MAILAN_28", "Sz�net hossza");
define("MAILAN_29", "m�sodperc");
define("MAILAN_30", "T�bb, mint 30 m�sodperces sz�net a b�ng�sz� id�kifut�s�t eredm�nyezheti");
define("MAILAN_31", "Visszadobott Email");
define("MAILAN_32", "Email c�m");
define("MAILAN_33", "Bej�v� Lev�l");
define("MAILAN_34", "Felhaszn�l�n�v");
define("MAILAN_35", "Jelsz�");
define("MAILAN_36", "Visszadobott Mail ellen�z�s ut�ni t�rl�se");

define("MAILAN_37", "Folyamatban");
define("MAILAN_38", "Kil�p");
define("MAILAN_39", "Email k�ld�s");
define("MAILAN_40", "�t kell nevezned az <b>e107.htaccess</b> file-t <b>.htaccess</b> file-re, itt");
define("MAILAN_41", "miel�tt levelet k�ldesz err�l az oldalr�l.");
define("MAILAN_42", "Figyelmeztet�s");
define("MAILAN_43", "Felhaszn�l�n�v");
define("MAILAN_44", "Bejelentkez�s");
define("MAILAN_45", "Felhaszn�l� Email");
define("MAILAN_46", "Felhaszn�l�-Egyez�s");
define("MAILAN_47", "tartalmaz");
define("MAILAN_48", "azonos");
define("MAILAN_49", "Id");
define("MAILAN_50", "Szerz�");
define("MAILAN_51", "T�rgy");
define("MAILAN_52", "Utols� m�dos�t�s");
define("MAILAN_53", "Adminisztr�torok");
define("MAILAN_54", "�nmaga");
define("MAILAN_55", "Felhaszn�l� csoport");
define("MAILAN_56", "Lev�l k�ld�se");
define("MAILAN_57", "Keep SMTP session alive");
define("MAILAN_58", "Probl�ma l�pett fel a mell�klet csatol�s�n�l:");
define("MAILAN_59", "Lev�lk�ld�s folyamata");
define("MAILAN_60", "K�ld�s...");
define("MAILAN_61", "Nincs t�bb elk�ldend� lev�l.");
define("MAILAN_62", "Email-ek elk�ldve:");
define("MAILAN_63", "Hib�s Email-ek:");
define("MAILAN_64", "�sszes eltelt id�:");
define("MAILAN_65", "m�sodperc");
define("MAILAN_66", "Kil�p�s sikeres");
define("MAILAN_67", "Haszn�ld a 'POP before SMTP' lehet�s�get a hiteles�t�shez"); 


?>
