<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LANMAILH_1", "K�sz�tette az e107 webport�l rendszer");
define("LANMAILH_2", "Ez egy t�bbr�szes �zenet, MIME form�tummal.");
define("LANMAILH_3", " helytelen form�tum�.");
define("LANMAILH_4", "A szerver a c�met visszautas�totta!");
define("LANMAILH_5", "A szerver nem v�laszolt");
define("LANMAILH_6", "Nincs ilyen e-mail szerver.");
define("LANMAILH_7", " �gy t�nik rendben van.");

?>
