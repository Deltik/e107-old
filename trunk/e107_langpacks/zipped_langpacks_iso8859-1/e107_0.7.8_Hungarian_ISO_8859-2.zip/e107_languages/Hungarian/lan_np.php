<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NP_1", "El�z� oldal");
define("NP_2", "K�vetkez� oldal");
define("NP_3", "Oldal:");

?>
