<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.6 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------
define("PAGE_NAME", "Statisztika");

define("ADSTAT_L1", "A plugin minden l�togat�st napl�zni fog, �s r�szletes statisztik�kat ad az �sszegy�jt�tt inform�ci�k alapj�n.");
define("ADSTAT_L2", "A statisztika napl�z� telep�tve. A megl�v� statisztik�k konvert�l�s�hoz az �j rendszerbe, <a href='".e_PLUGIN."log/update_routine.php'>futtasd a friss�t� rutint</a>.");
define("ADSTAT_L3", "Statisztika napl�z�s");
define("ADSTAT_L4", "Nincs jogos�lts�god az oldal megtekint�s�hez.");
define("ADSTAT_L5", "A tulajdons�gok ezen az oldalon let�ltva.");
define("ADSTAT_L6", "Oldal statisztik�k");
define("ADSTAT_L7", "Statistics for this type is not being gathered.");
define("ADSTAT_L8", "Ma");
define("ADSTAT_L9", "�sszes");
define("ADSTAT_L10", "Napi");
define("ADSTAT_L11", "Havi");
define("ADSTAT_L12", "B�ng�sz�");
define("ADSTAT_L13", "Oper�ci�s rendszer");
define("ADSTAT_L14", "N�vv�gz�d�s");
define("ADSTAT_L15", "K�perny� m�ret / Sz�nm�lys�g");
define("ADSTAT_L16", "Hivatkoz�s");
define("ADSTAT_L17", "Keres�si felt�tel");
define("ADSTAT_L18", "Leg�jabb l�togat�k");
define("ADSTAT_L19", "Oldal");
define("ADSTAT_L20", "Mai l�togat�sok");
define("ADSTAT_L21", "�sszes");
define("ADSTAT_L22", "Egyedi");
define("ADSTAT_L23", "�sszes l�togat�s");
define("ADSTAT_L24", "�sszes egyedi l�togat�s");
define("ADSTAT_L25", "Jelenleg nincs statisztika.");
define("ADSTAT_L26", "B�ng�sz�");
define("ADSTAT_L27", "Oper�ci�s rendszer");
define("ADSTAT_L28", "Orsz�g / Tartom�ny");
define("ADSTAT_L29", "K�perny�m�ret");
define("ADSTAT_L30", "Oldal hivatkoz�s");
define("ADSTAT_L31", "Keres�si felt�telek");
define("ADSTAT_L32", "Hivatkoz�s");
define("ADSTAT_L33", "L�togat�s az utols�");
define("ADSTAT_L34", "L�togat�sok");
define("ADSTAT_L35", "Egyedi l�togat�s az utols�");
define("ADSTAT_L36", "napban / oldal");
define("ADSTAT_L37", "Havi l�togat�sok");
define("ADSTAT_L38", "Havi egyedi l�togat�sok");
define("ADSTAT_L39", "Bejegyz�s t�rl�se");
define("ADSTAT_L40", "napban");
define("ADSTAT_L41", "Hiba");
?>
