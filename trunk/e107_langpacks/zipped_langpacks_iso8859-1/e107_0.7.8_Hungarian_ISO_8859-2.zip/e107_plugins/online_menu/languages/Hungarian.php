<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.4 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("ONLINE_L1", "Vend�gek: ");
define("ONLINE_L2", "Tagok: ");
define("ONLINE_L3", "Ezen a lapon: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Tagok");
define("ONLINE_L6", "leg�jabb");
define("TRACKING_MESSAGE", "Online felhaszn�l� nyomk�vet�se letiltva, az enged�lyez�shez katt <a href='".e_ADMIN."users.php?options'>IDE</a></span><br />");
?>