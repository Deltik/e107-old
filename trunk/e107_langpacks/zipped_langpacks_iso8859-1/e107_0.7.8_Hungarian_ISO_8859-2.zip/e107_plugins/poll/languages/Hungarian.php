<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.8 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("POLL_ADLAN01", "Szavaz�s");
define("POLL_ADLAN02", "Szavaz�st hozhatsz l�tre �n�ll�an, vagy a f�rumban.");
define("POLL_ADLAN03", "Szavaz�sok be�ll�t�sa");
define("POLL_ADLAN04", "A szavaz�s plugin telep�tve. Szavaz�s l�trehoz�s�hoz kattints a Szavaz�s ikonra az admin ter�leten, �s aktiv�ld a men�t a Men�k r�szben.");

define("POLLAN_MENU_CAPTION", "Szavaz�s");

define("POLLAN_1", "Jelenlegi szavaz�sok");
define("POLLAN_2", "Szavaz�sok k�sz�t�se / m�dos�t�sa");
define("POLLAN_3", "Szavaz�s k�rd�se");
define("POLLAN_4", "Opci�k");
define("POLLAN_5", "M�dos�t�s");
define("POLLAN_6", "T�rl�s");
define("POLLAN_7", "Nincsenek szavaz�sok.");
define("POLLAN_8", "�j opci� hozz�ad�sa");
define("POLLAN_9", "T�bb v�lasz enged�lyez�se?");
define("POLLAN_10", "igen");
define("POLLAN_11", "nem");
define("POLLAN_12", "Eredm�nyek mutat�sa");
define("POLLAN_13", "szavaz�s ut�n");
define("POLLAN_14", "az eredm�nyek linkre kattintva");
define("POLLAN_15", "Szavazat enged�lyez�se");
define("POLLAN_16", "Szavazat t�rol�s�nak m�dja");
define("POLLAN_17", "cookie");
define("POLLAN_18", "IP c�m");
define("POLLAN_19", "UserID (csak tagok szavazhatnak)");
define("POLLAN_20", "Hozz�sz�l�sok enged�lyez�se?");
define("POLLAN_21", "Ism�telt el�n�zet");
define("POLLAN_22", "Szavaz�s friss�t�se");
define("POLLAN_23", "Szavaz�s k�sz�t�se");
define("POLLAN_24", "El�n�zet");
define("POLLAN_25", "T�rl�s");
define("POLLAN_26", "szavazat");
define("POLLAN_27", "hozz�sz�l�s");
define("POLLAN_28", "Kor�bbi szavaz�sok");
define("POLLAN_29", "ki�rta");
define("POLLAN_30", "Mehet");
define("POLLAN_31", "szavazat");
define("POLLAN_32", "Eredm�nyek megtekint�se");
define("POLLAN_33", "Nincsenek kor�bbi szavaz�sok.");
define("POLLAN_34", "C�m");
define("POLLAN_35", "Ki�rta");
define("POLLAN_36", "Akt�v");
define("POLLAN_37", "akt�v:");
define("POLLAN_38", "-");
define("POLLAN_39", "K�sz�nj�k a szavazatot!");
define("POLLAN_40", "Eredm�nyek megtekint�se");
define("POLLAN_41", "A szavaz�s korl�tozva csak tagoknak");
define("POLLAN_42", "A szavaz�s korl�tozva csak adminisztr�toroknak");
define("POLLAN_43", "Nincs jogosults�god a szavaz�sra");
define("POLLAN_44", "Szavaz�s t�rl�se?");
define("POLLAN_45", "Szavaz�s sikeresen friss�tve");
define("POLLAN_46", "Mez�(k) maradtak �resen");

?>
