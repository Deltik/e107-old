<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/gsitemap/languages/gsitemap_English.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/15 17:43:12 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "Oldalt�rk�p");
define("GSLAN_1", "Oldal Link");
define("GSLAN_2", "Import�lod?");
define("GSLAN_3", "T�pus");
define("GSLAN_4", "N�v");
define("GSLAN_5", "Url");
define("GSLAN_6", "Jel�ld be az import�land� linkeket ...");
define("GSLAN_7", "Linkek import�l�sa");
define("GSLAN_8", "Import�l�s be�ll�t�sai:");
define("GSLAN_9", "Priorit�s");
define("GSLAN_10", "Gyakoris�g");
define("GSLAN_11", "mindig");
define("GSLAN_12", "�r�nk�nt");
define("GSLAN_13", "naponta");
define("GSLAN_14", "hetente");
define("GSLAN_15", "havonta");
define("GSLAN_16", "�vente");
define("GSLAN_17", "soha");
define("GSLAN_18", "Bejel�lt linkek import�l�sa");
define("GSLAN_19", "Google Oldalt�rk�p");
define("GSLAN_20", "List�z�s");
define("GSLAN_21", "El��r�sok");
define("GSLAN_22", "�j bejegyz�s l�trehoz�sa");
define("GSLAN_23", "Import�l�s");
define("GSLAN_24", "Google Oldalt�rk�p bejegyz�sek");
define("GSLAN_25", "N�v");
define("GSLAN_26", "URL");
define("GSLAN_27", "Utols� m�dos�t�s");
define("GSLAN_28", "Gyakoris�g");
define("GSLAN_29", "Google Oldalt�rk�p be�ll�t�s");
define("GSLAN_30", "Megjelen�si sorrend");
define("GSLAN_31", "Megtekint�s");
define("GSLAN_32", "Hogyan haszn�ld a Google Oldalt�rk�pet");
define("GSLAN_33", "GSiteMap El��r�sok");
define("GSLAN_34", "El�sz�r, hozz l�tre egy linket, melyet meg szeretn�l jelen�teni az oldalt�rk�pen. A legt�bb linket import�lnod kell az 'Import�l�s' gomb megnyom�s�nak seg�ts�g�vel");
define("GSLAN_35", "Ha kiv�lasztottad a megfelel� linkeket, akkor nyomd meg az 'Import�l�s' gombot, majd ellen�rizd a m�velet helyess�g�t");
define("GSLAN_36", "Egy�ni linket is l�trehozhatsz manu�lisan az '�j bejegyz�s l�trehoz�sa' gomb megnyom�s�val");
define("GSLAN_37", "Ha m�r rendelkezel n�h�ny bejegyz�ssel, akkor l�pj a <a href='https://www.google.com/webmasters/sitemaps/stats'>https://www.google.com/webmasters/sitemaps/stats</a> oldalra �s add meg a k�vetkez� URL-t -> <b>".SITEURL."gsitemap.php</b> - ha ez az url nem jelenik meg megfelel�en, akkor jav�tani kell az oldalad url-j�t az admin -> be�ll�t�sok fel�leten");
define("GSLAN_38", "Tov�bbi inform�ci�khoz l�pj a <a href='http://www.google.com/webmasters/sitemaps/docs/en/protocol.html'>http://www.google.com/webmasters/sitemaps/docs/en/protocol.html</a> oldalra.");
define("GSLAN_39", "Nincsennek linkek - import�lod az oldal linkeket?");
define("GSLAN_40", "Google Oldalt�rk�p bejegyz�sek");

?>