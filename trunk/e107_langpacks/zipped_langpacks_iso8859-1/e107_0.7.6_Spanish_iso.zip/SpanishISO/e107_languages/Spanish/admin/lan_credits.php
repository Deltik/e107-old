<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_credits.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Cr�ditos");
define("CRELAN_2", "Debajo est� una lista de recursos y software de terceras personas para e107. Agradecemos su colaboraci�n as� como el permitir usar su software bajo licencia GPL");
//define("CRELAN_3", "Origen");
//define("CRELAN_4", "Descripci�n");
//define("CRELAN_5", "Web");
//define("CRELAN_6", "Permiso");
define("CRELAN_7", "Versi�n");
?>