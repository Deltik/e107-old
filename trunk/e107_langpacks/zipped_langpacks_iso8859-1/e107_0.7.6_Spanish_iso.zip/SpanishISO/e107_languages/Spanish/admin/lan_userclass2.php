<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Borrados todos los usuarios de esta clase.");
define("UCSLAN_2", "Usuarios de esta clase actualizados.");
define("UCSLAN_3", "Clase borrada.");
define("UCSLAN_4", "Por favor marca la casilla de confirmaci�n para borrar el usuario de esta clase");
define("UCSLAN_5", "Clase actualizada.");
define("UCSLAN_6", "Clase guardada en base de datos.");
define("UCSLAN_7", "No hay clases de usuarios a�n.");
define("UCSLAN_8", "Clases existentes");
//define("UCSLAN_9", "Editar");
//define("UCSLAN_10", "Borrar");
define("UCSLAN_11", "Marcar para confirmar");
define("UCSLAN_12", "Nombre de la Clase");
define("UCSLAN_13", "Descripci�n de la clase");
define("UCSLAN_14", "Actualizar clase de usuario");
define("UCSLAN_15", "Crear nueva clase");
define("UCSLAN_16", "Asignar usuarios a esta clase");
define("UCSLAN_17", "Eliminar");
define("UCSLAN_18", "Limpiar Clase");
define("UCSLAN_19", "Asignar usuarios a");
define("UCSLAN_20", "Clases");
define("UCSLAN_21", "Configuraciones para clase de usuario");
define("UCSLAN_22", "Usuarios - pulse para mover ...");
define("UCSLAN_23", "Usuarios en esta clase ...");
define("UCSLAN_24", "�Qui�n puede gestionar las clases?");

?>