<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_e107_update.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/22 22:56:48 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Acci�n");
define("LAN_UPDATE_3", "No necesaria");

define("LAN_UPDATE_5", "Actualizaci�n disponible");
define("LAN_UPDATE_6", "Ejecutado");
define("LAN_UPDATE_8", "Actualizar de");
define("LAN_UPDATE_9", "a");
define("LAN_UPDATE_10", "Actualizaciones disponibles");
define("LAN_UPDATE_11", "Actualizaci�n de .617 a .7");

?>