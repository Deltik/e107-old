<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_footer.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Sitio");
define("FOOTLAN_2", "Administrador");
define("FOOTLAN_3", "Versi�n");
define("FOOTLAN_4", "Revisi�n");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "Por");
define("FOOTLAN_7", "Info.");
define("FOOTLAN_8", "Fecha instalaci�n");
define("FOOTLAN_9", "Servidor");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "Versi�n PHP");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Info. Sitio");
define("FOOTLAN_14", "Ver Documentos");
define("FOOTLAN_15", "Documentaci�n");
define("FOOTLAN_16", "Base de datos");
define("FOOTLAN_17", "Juego de car�cteres");

?>