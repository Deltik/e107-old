<?php

$NEWFORUMPOSTSTYLE_HEADER = "
<!-- newforumposts -->\n<ul>\n";

$NEWFORUMPOSTSTYLE_MAIN = "<li><span class='smalltext'>{THREAD} ".LAN_7." {POSTER} [ ".LAN_3.": {VIEWS}, ".LAN_4.": {REPLIES}, ".LAN_5.": {LASTPOST} ]\n</span>\n</li>\n";

$NEWFORUMPOSTSTYLE_FOOTER = "</ul>\n<br /><br />\n<span class='smalltext'>".LAN_6.": <b>{TOTAL_TOPICS}</b> | ".LAN_4.": <b>{TOTAL_REPLIES}</b> | ".LAN_3.": <b>{TOTAL_VIEWS}</b></span>";


?>