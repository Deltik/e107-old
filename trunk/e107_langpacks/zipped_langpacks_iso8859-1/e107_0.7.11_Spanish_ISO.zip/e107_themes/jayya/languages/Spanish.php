<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/jayya/languages/Spanish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "Comentarios desactivados ");
define("LAN_THEME_2", "Leer/enviar comentario: ");
define("LAN_THEME_3", "Leer el resto...");
define("LAN_THEME_4", "Trackbacks: ");
define("LAN_THEME_5", "Enviado por");
define("LAN_THEME_6", "el");

?>