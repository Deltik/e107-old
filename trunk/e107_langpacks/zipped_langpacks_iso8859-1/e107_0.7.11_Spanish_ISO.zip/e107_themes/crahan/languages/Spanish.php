<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/crahan/languages/Spanish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'CraHan' por <a href='http://e107.org' rel='external'>jalist</a>, basado en el theme de CraHan y su p�gina <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Comentarios desactivados ");
define("LAN_THEME_3", "Comentario(s) ");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Comentario de");


?>