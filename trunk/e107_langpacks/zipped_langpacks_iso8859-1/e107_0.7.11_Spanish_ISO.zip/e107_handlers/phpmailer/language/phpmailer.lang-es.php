<?php
/**
* PHPMailer language file.
* Spanish Version
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'Necesita proveer al menos ' . ' una direcci�n de buz�n.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer no est� soportado.';
$PHPMAILER_LANG["execute"] = 'No se puede ejecutar: ';
$PHPMAILER_LANG["instantiate"] = 'No se puede instanciar la funci�n mail.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Error: No es posible autentificar.';
$PHPMAILER_LANG["from_failed"] = 'La siguiente direcci�n DE fall�: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Error: Los siguientes ' . 'buzones fallaron: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Error: Datos no aceptados.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Error: No se puede conectar al servidor SMTP.';
$PHPMAILER_LANG["file_access"] = 'No se puede acceder al archivo: ';
$PHPMAILER_LANG["file_open"] = 'Error de archivo: No se puede abrir: ';
$PHPMAILER_LANG["encoding"] = 'Codificaci�n desconocida: ';
?>