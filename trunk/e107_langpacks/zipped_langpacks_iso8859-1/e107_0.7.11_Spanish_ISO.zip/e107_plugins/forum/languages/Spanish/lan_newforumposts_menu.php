<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/forum/languages/Spanish/lan_newforumposts_menu.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/07/14 06:02:13 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Todos los �ltimos env�os estan fuera de su clase de usuario. Imposible mostrar.");
define("NFP_2", "Sin env�os todav�a");
define("NFP_3", "Configuraci�n de nuevos env�os del foro guardada");
define("NFP_4", "T�tulo");
define("NFP_5", "�N�mero de mensajes a mostrar?");
define("NFP_6", "�N�mero de car�cteres a mostrar?");
define("NFP_7", "�Fijar env�os muy largos?");
define("NFP_8", "�Mostrar temas originales en el men�?");
define("NFP_9", "Actualizar par�metros del men�");
define("NFP_10", "Configuraci�n del men� de nuevos env�os del foro");
define("NFP_11", "Enviado por");
define("NFP_12", "Antiguedad de los env�os mostrados"); 
define("NFP_13", "Use cero para un sitio tranquilo; fijando un valor en d�as reducir� el tiempo de la dase de datos en un sitio ocupado"); 
?>