<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/alt_auth/languages/Spanish/lan_ldap_auth.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/11/11 11:02:27 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LDAPLAN_1", "Direcci�n del servidor");
define("LDAPLAN_2", "Base DN o Dominio<br />If LDAP - Escriba BaseDN<br />If AD - Escriba Dominio");
define("LDAPLAN_3", "LDAP mostrar usuarios<br />Contenido de texto del usuario que ser� capaz de buscar en el directorio.");
define("LDAPLAN_4", "LDAP mostrar contrase�a<br />Contrase�a para el usuario LDAP.");
define("LDAPLAN_5", "Versi�n LDAP");
define("LDAPLAN_6", "Configurar LDAP aut.");
define("LDAPLAN_7", "Filtro de b�squeda de sDirectory:"); 
define("LDAPLAN_8", "Se utilizar� para asegurar que el usuario esta en el �rbol correcto, <br />pe '(objectclass=inetOrgPerson)'"); 
define("LDAPLAN_9", "El filtro actual de b�squeda ser�:");
define("LDAPLAN_10", "Ajustes actualizados"); 
define("LDAPLAN_11", "ATENCION:  �Parece que el modulo ldap no est� disponible, fijando el m�todo de autentificaci�n a LDAP no podr�a funcionar!"); 
define("LDAPLAN_12", "Tipo de servidor"); 
define("LDAPLAN_13", "Actualizar ajustes");
?>
