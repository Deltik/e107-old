<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/online_menu/languages/Spanish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/10 21:09:15 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Invitados: ");
define("ONLINE_L2", "Miembros: ");
define("ONLINE_L3", "En esta p�gina: ");
define("ONLINE_L4", "En linea");
define("ONLINE_L5", "Miembros");
define("ONLINE_L6", "�ltimo");

define("TRACKING_MESSAGE", "El tracking de usuario online est� actualmente desactivado, por favor act�velo [link=".e_ADMIN."users.php?options]aqu�[/link][br]");
?>