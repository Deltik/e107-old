<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_parser_functions.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/22 18:18:50 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Invitado");
define("LAN_WROTE", "escribi�"); // as in John wrote.."  ";
?>