<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_emoticon.php,v $
|     $Revision: 1.5 $
|     $Date: 2007/07/14 06:02:13 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Activaci�n de Emoticono.");
define("EMOLAN_2", "Nombre");
define("EMOLAN_3", "Emoticonos");
define("EMOLAN_4", "�Activar emoticonos?");
define("EMOLAN_5", "Imagen");
define("EMOLAN_6", "C�digo emoticono");
define("EMOLAN_7", "Separar m�ltiples entradas con espacios");
define("EMOLAN_8", "Estado");
define("EMOLAN_9", "Opciones");
define("EMOLAN_10", "Activo");
define("EMOLAN_11", "Activar pack");
define("EMOLAN_12", "Editar / configurar este pack");
define("EMOLAN_13", "Packs instalados");
define("EMOLAN_14", "Guardar configuraci�n");
define("EMOLAN_15", "Editar / configurar Emoticonos");
define("EMOLAN_16", "Configuraci�n de emoticono guardada");
define("EMOLAN_17", "� Tiene un pack de emoticonos que contiene espacios en el nombre, lo cual no est� permitido !"); 
define("EMOLAN_18", "por favor, renombre las instancias listadas debajo para que no contengan espacios:"); 
define("EMOLAN_19", "Nombre"); 
define("EMOLAN_20", "Lugar"); 
define("EMOLAN_21", "Error"); 
define("EMOLAN_22", "Encontrado nuevo pack:"); 
define("EMOLAN_23", "Encontrado nuevo pack xml:"); 
define("EMOLAN_24", "Encontrado nuevo pack php:");
define("EMOLAN_25", "Instalando nuevos emoticonos PHP: "); 
define("EMOLAN_26", "Re-escanear pack"); 
define("EMOLAN_27", "Error ocurrido procesando el pack: "); 
define("EMOLAN_28", "Generar XML"); 
define("EMOLAN_29", "Archivo XML generado: ");
define("EMOLAN_30", "Error escribiendo el archivo XML: ");
?>