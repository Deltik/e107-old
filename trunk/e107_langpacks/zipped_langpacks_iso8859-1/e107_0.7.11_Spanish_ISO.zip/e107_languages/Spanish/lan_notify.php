<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_notify.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/09/18 19:53:16 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Conexi�n de usuario");

define("NT_LAN_UV_1", "Verificaci�n de la conexi�n de usuario");
define("NT_LAN_UV_2", "Usuario ID: "); 
define("NT_LAN_UV_3", "suario nombre conexi�n: "); 
define("NT_LAN_UV_4", "Usuario IP: "); 

define("NT_LAN_LI_1", "Usuario conectado");

define("NT_LAN_LO_1", "Usuario desconectado");
define("NT_LAN_LO_2", " desconectado del sitio");

define("NT_LAN_FL_1", "Expulsi�n flood");
define("NT_LAN_FL_2", "Expulsiones IP por flooding");

define("NT_LAN_SN_1", "Elementos de noticias enviados");

define("NT_LAN_NU_1", "Actualizado");

define("NT_LAN_ND_1", "Elementos de noticias eliminados");
define("NT_LAN_ND_2", "Elementos de noticias eliminados por ID");

define("NF_LAN_1", "Eventos de archivo"); 
define("NF_LAN_2", "Archivo transferido por el usuario");
?>