<?php

define("LAN_PLUGIN_DOWNLOAD_NAME",  "Downloads");
define("LAN_PLUGIN_DOWNLOAD_DIZ",  "This plugin is a fully featured File-download system");



?>