CREATE TABLE alt_auth (
  auth_type varchar(20) NOT NULL default '',
  auth_parmname varchar(30) NOT NULL default '',
  auth_parmval varchar(120) NOT NULL default ''
) ENGINE=MyISAM;