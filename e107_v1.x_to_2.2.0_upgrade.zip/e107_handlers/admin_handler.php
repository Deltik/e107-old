<?php
/**
 * e107 website system
 *
 * Copyright (C) 2008-2009 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * Administration UI handlers, admin helper functions
 * @DEPRECATED FILE
*/

if (!defined('e107_INIT')) { exit; }

// DEBUG INFO ONLY - do NOT translate. 
e107::getMessage()->addDebug("admin_handler.php is deprecated. You can simply remove it from your script and continue to use its functions which can now be found inside core_functions.php");

