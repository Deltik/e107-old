<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/07 00:15:58 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Page listing is turned off");
define("LAN_PAGE_2", "There are no pages");
define("LAN_PAGE_3", "Requested page does not exist");
define("LAN_PAGE_4", "Rate this page");
define("LAN_PAGE_5", "Thank you for rating this page");
define("LAN_PAGE_6", "You do not have permission to view this page");
define("LAN_PAGE_7", "Incorrect password");
define("LAN_PAGE_8", "Password Protected Page");
define("LAN_PAGE_9", "Password");
define("LAN_PAGE_10", "Submit");
define("LAN_PAGE_11", "Page List");
define("LAN_PAGE_12", "Invalid page");
define("LAN_PAGE_13", "Page");

?>