<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/leaf/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/03/03 19:59:56 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Comment(s) ");
define("LAN_THEME_2", "Comments are turned off for this item");
define("LAN_THEME_3", "comment(s) ");
define("LAN_THEME_4", "Read the rest ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Comment by");
define("LAN_THEME_7", "News");



?>