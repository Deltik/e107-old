/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.2 2005/12/24 00:09:57 e107coders Exp $ 
 */  

tinyMCE.addToLang('',{
insert_flash : 'Vlo�it/editovat Flash Movie',
insert_flash_file : 'Flash soubor (.swf)',
insert_flash_size : 'Velikost',
insert_flash_list : 'Seznam',
flash_props : 'Vlastnosti Flash'
});
