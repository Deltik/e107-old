<?php
define("UC_LAN_0", "Everyone (public)");
define("UC_LAN_1", "Guest Only");
define("UC_LAN_2", "No One (inactive)");
define("UC_LAN_3", "Members Only");
define("UC_LAN_4", "Read Only");
define("UC_LAN_5", "Admin Only");
?>