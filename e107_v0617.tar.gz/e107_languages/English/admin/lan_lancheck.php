<?php

define("LAN_CHECK_1", "Select Language to verify");
define("LAN_CHECK_2", "Begin Verify");
define("LAN_CHECK_3", "Verification of");
define("LAN_CHECK_4", "File missing!");
define("LAN_CHECK_5", "Phrase missing!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "phrase");

?>