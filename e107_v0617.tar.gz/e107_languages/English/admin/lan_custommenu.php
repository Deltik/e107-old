<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107/e107_languages/English/admin/lan_custommenu.php,v $
|     $Revision: 1.4 $
|     $Date: 2004/09/06 09:55:17 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Fields left blank.");
define("CUSLAN_2", "Unable to create custom menu - please ensure your ");
define("CUSLAN_3", "custom directory is CHMODDed to 777.");
define("CUSLAN_4", "Custom menu/page updated.");
define("CUSLAN_5", "Custom menu successfully created. To activate go to your menus screen.");
define("CUSLAN_6", "Unable to open menu/page");
define("CUSLAN_7", "for reading");
define("CUSLAN_8", "Existing Menus");
define("CUSLAN_9", "Edit");
define("CUSLAN_10", "None");
define("CUSLAN_11", "Menu/Page Filename");
define("CUSLAN_12", "Menu/Page Caption Title");
define("CUSLAN_13", "Menu/Page Text");
define("CUSLAN_14", "Preview Again");
define("CUSLAN_15", "Preview");
define("CUSLAN_16", "Update Custom Menu/Page");
define("CUSLAN_17", "Create Custom Menu/Page");
define("CUSLAN_18", "Custom Menus/Pages");
// New for .617
define("CUSLAN_19", "Existing Pages");
define("CUSLAN_20", "Unable to create custom page - please ensure your ");
define("CUSLAN_21", "custompages directory is CHMODDed to 777.");
define("CUSLAN_22", "Menu");
define("CUSLAN_23", "Page");
define("CUSLAN_24", "Custom Page successfully created. The URL will be:");
define("CUSLAN_25", "Create a link in the main menu ?");
define("CUSLAN_26", "Link displayed for everybody and opened in the same window !");
define("CUSLAN_27", "You already have a link in your main menu for this page or with the same name...");
define("CUSLAN_28", "Link to this page now created !!! Go to your links section to update link properties.");

define("CUSLAN_29", "e107_plugins/custompages/");
define("CUSLAN_30", "If required edit link properties here ");

?>