<?php

define("DBLAN_1", "Core settings backed up in database.");
define("DBLAN_2", "Click button to save a backup of your e107 database");
define("DBLAN_3", "Backup SQL database");
define("DBLAN_4", "Click button to check validity of e107 database");
define("DBLAN_5", "Check database validity");
define("DBLAN_6", "Click button to optimize your e107 database");
define("DBLAN_7", "Optimize SQL database");
define("DBLAN_8", "Click button to backup your core settings");
define("DBLAN_9", "Backup core");
define("DBLAN_10", "Database Utilities");
define("DBLAN_11", "mySQL database");
define("DBLAN_12", "optimized");
define("DBLAN_13", "Back");
define("DBLAN_14", "Done");
define("DBLAN_15", "Click button to check for any available db updates");
define("DBLAN_16", "Check for Updates");

?>