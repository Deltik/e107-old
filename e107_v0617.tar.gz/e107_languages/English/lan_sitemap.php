<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107/e107_languages/English/lan_sitemap.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/09/09 09:31:42 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sitemap");

define("LANSM_1", "Sitemap of");
define("LANSM_2", "Home");
define("LANSM_3", "(Index Page)");
define("LANSM_4", "Content");
define("LANSM_5", "News");
define("LANSM_6", "(News categories)");
define("LANSM_7", "Click here to show/hide the full sitemap");
define("LANSM_8", "Links");
define("LANSM_9", "(links categories)");
define("LANSM_10", "Forums");
define("LANSM_11", "(Forums list)");
define("LANSM_12", "Downloads");
define("LANSM_13", "(Downloads categories)");
define("LANSM_14", "Articles");
define("LANSM_15", "(Articles categories)");
define("LANSM_16", "Reviews");
define("LANSM_17", "(Reviews categories)");
define("LANSM_18", "Frontpage");
define("LANSM_19", "Members");
define("LANSM_20", "Stats");
define("LANSM_21", "User Settings");
define("LANSM_22", "Profile");
define("LANSM_23", "Categories:");
define("LANSM_24", "Main features");
define("LANSM_25", "Plugins");
define("LANSM_26", "Chatbox messages");
define("LANSM_27", "Headines");
define("LANSM_28", "Old Polls");
define("LANSM_29", "Content");
define("LANSM_30", "(List of content pages)");
define("LANSM_31", "or click on");
define("LANSM_32", "List of registred users");
define("LANSM_33", "(Statistics of this site)");
define("LANSM_34", "(Info about a member)");
define("LANSM_35", "(Setup info member)");
define("LANSM_36", "(Other content pages)");
define("LANSM_37", "Subcategories:");
define("LANSM_38", "Pages");
define("LANSM_39", "(threads/replies");
define("LANSM_40", "Uncategorized");
define("LANSM_41", "to expand/hide a subcategory");
define("LANSM_42", "Chat");
define("LANSM_43", "(All messages posted in the chatbox menu)");
define("LANSM_44", "Other pages");
define("LANSM_45", "Signup");
define("LANSM_46", "Password forgot?");
define("LANSM_47", "Search");
define("LANSM_48", "Submit news");
define("LANSM_49", "Submit content");
define("LANSM_50", "Top posters");
define("LANSM_51", "Submit links");
define("LANSM_52", "User Posts");
define("LANSM_53", "(Check comments from a specific users on the site)");

?>