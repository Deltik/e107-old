<?php
// -----------------------
// blogcal menu style vars
// -----------------------
$bc_menu_wrapper = ;
$menu_header = ;
$menu_body = ;
$menu_footer = ;


// --------------------------
// calendar object style vars
// --------------------------
$cal_header_cell = ;
$cal_blank_cell
$cal_cell = ;
$cal_linked_cell = ;
$cal_hl_cell = ;
$cal_hl_linked_cell = ;


// --------------------------
// archive section style vars
// --------------------------
$arch_wrapper = ;
$arch_header = ;
$arch_cell = ;
$arch_cell_header = ;
$arch_cell_body = ;

?>