<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/admin/lan_userclass.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 13:56:14 -0500 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Sending notification email to");
define("UCSLAN_2", "Updated Privileges");
define("UCSLAN_3", "Dear");
define("UCSLAN_4", "Your privileges have been updated at");
define("UCSLAN_5", "You now have access to the following area(s)");
define("UCSLAN_6", "Set class for user");
define("UCSLAN_7", "Set Classes");
define("UCSLAN_8", "Notify User");
define("UCSLAN_9", "Classes Updated.");
define("UCSLAN_10", "Regards,");
define('UCSLAN_12', 'Member privileges only');

?>