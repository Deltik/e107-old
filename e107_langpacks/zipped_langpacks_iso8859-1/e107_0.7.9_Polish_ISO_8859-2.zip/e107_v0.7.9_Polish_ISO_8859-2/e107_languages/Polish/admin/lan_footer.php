<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2007/02/10 15:53:40 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_footer.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_footer.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("FOOTLAN_1", "Strona");
define("FOOTLAN_2", "G��wny administrator");
define("FOOTLAN_3", "Wersja");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Temat panelu admina");
define("FOOTLAN_6", "wykonany przez");
define("FOOTLAN_7", "Informacje");
define("FOOTLAN_8", "Data instalacji");
define("FOOTLAN_9", "Serwer");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "Wersja PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Informacje o stronie");
define("FOOTLAN_14", "Poka� dokumentacj�");
define("FOOTLAN_15", "Dokumentacja");
define("FOOTLAN_16", "Baza danych");
define("FOOTLAN_17", "Strona kodowa");
define("FOOTLAN_18", "Temat strony");

?>
