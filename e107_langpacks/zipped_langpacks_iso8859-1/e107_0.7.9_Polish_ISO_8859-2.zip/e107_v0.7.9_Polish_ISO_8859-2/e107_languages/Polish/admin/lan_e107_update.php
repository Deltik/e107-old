<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/07/10 15:00:22 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_e107_update.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_e107_update.ph rev. 1.7
+-----------------------------------------------------------------------------+
*/
 
define("LAN_UPDATE_2", "Zadanie");
define("LAN_UPDATE_3", "Nie wymagane");

define("LAN_UPDATE_5", "Aktualizuj dost�pne");
define("LAN_UPDATE_7", "Wykonano");
define("LAN_UPDATE_8", "Aktualizuj z wersji");
define("LAN_UPDATE_9", "do");
define("LAN_UPDATE_10", "Dost�pne aktualizacje");
define("LAN_UPDATE_11", "Pozosta�e aktualizacje z wersji .617 do .7");
define("LAN_UPDATE_12", "Jedna z tabel zawiera podw�jne wpisy.");

?>
