<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_message.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_message.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("MESSLAN_1", "Otrzymane wiadomo�ci");
define("MESSLAN_2", "Usu� wiadomo��");
define("MESSLAN_3", "Wiadomo�� zosta�a usuni�ta.");
define("MESSLAN_4", "Skasuj wszystkie wiadomo�ci");
define("MESSLAN_5", "Potwierd�");
define("MESSLAN_6", "Wszystkie wiadomo�ci zosta�y usuni�te.");
define("MESSLAN_7", "Brak wiadomo�ci.");
define("MESSLAN_8", "Rodzaj wiadomo�ci");
define("MESSLAN_9", "Wys�ana dnia");

define("MESSLAN_10", "Nades�ana przez");
define("MESSLAN_11", "otwarte w nowym oknie");
define("MESSLAN_12", "Wiadomo��");
define("MESSLAN_13", "Link");

?>
