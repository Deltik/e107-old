<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/10/25 12:22:25 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/filemanager.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/filemanager.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Z poziomu tej strony mo�esz zarz�dza� plikami w swoich katalogach plik�w. Je�li otrzymasz komunikat b��du o uprawnieniach podczas usi�owania przesy�ania plik�w do okre�lonego katalogu, ustaw CHMOD wskazanego folderu na warto�� 777.";
$ns -> tablerender("Mened�er plik�w", $text);

?>
