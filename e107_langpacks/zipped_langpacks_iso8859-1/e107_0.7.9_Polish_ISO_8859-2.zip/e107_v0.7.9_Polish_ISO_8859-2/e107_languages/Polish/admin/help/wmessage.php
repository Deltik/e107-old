<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/wmessage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/wmessage.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie mo�esz ustawi� wiadomo��, kt�ra b�dzie wy�wietlana w g�rnej cz�ci Twojej strony g��wnej przez ca�y czas jej aktywacji. Mo�esz ustawi� r�ne wiadomo�ci dla go�ci, zalogowanych u�ytkownik�w oraz administrator�w.";
$ns -> tablerender("Wiadomo�� powitalna", $text);

?>
