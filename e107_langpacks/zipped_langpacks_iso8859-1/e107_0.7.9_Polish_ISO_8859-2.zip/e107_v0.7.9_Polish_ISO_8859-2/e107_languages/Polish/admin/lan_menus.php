<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_menus.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_menus.php rev. 1.10
+-----------------------------------------------------------------------------+
*/
 
define("MENLAN_1", "Wszystkich");
define("MENLAN_2", "Zarejestrowanych u�ytkownik�w");
define("MENLAN_3", "Administrator�w");
define("MENLAN_4", "Widoczne dla:");
// define("MENLAN_5", "grupa");
define("MENLAN_6", "Zapisz opcje widoczno�ci");
define("MENLAN_7", "Konfiguracja opcji widoczno�ci dla");
define("MENLAN_8", "Opcje widoczno�ci zosta�y zaktualizowane");
define("MENLAN_9", "Menu u�ytkownika zosta�o zainstalowane");
define("MENLAN_10", "Zainstalowano nowe menu");
define("MENLAN_11", "Menu zosta�o usuni�te");
define("MENLAN_12", "Aktywacja: wybierz obszar");
define("MENLAN_13", "Aktywuj w obszarze");
define("MENLAN_14", "Obszar");
define("MENLAN_15", "Dezaktywuj");
define("MENLAN_16", "Konfiguruj");
define("MENLAN_17", "Przesu� w g�r�");
define("MENLAN_18", "Przesu� w d�");
define("MENLAN_19", "Przesu� do obszaru");
define("MENLAN_20", "Widoczno��");

// define("MENLAN_21", "Widoczne tylko dla go�ci");
define("MENLAN_22", "Nieaktywne menu");

define("MENLAN_23", "Przenie� na koniec");
define("MENLAN_24", "Przenie� na pocz�tek");
define("MENLAN_25", "Funkcje...");

define("MENLAN_26", "Menu b�dzie <strong>POKAZYWANE</strong> tylko na nast�puj�cych stronach");
define("MENLAN_27", "Menu b�dzie <strong>UKRYTE</strong> tylko na nast�puj�cych stronach");
define("MENLAN_28", "Wpisuj po jednej stronie w linii, wpisy adres�w powinny by� dostatecznie rozr�nialne i poprawne.");

define("MENLAN_29", "Wybierz wygl�d");
define("MENLAN_30", "Aby zobaczy� obszary menu oraz ich lokalizacje dla w�asnego wygl�du, wybierz jeden z dost�pnych wygl�d�w:");
define("MENLAN_31", "Domy�lny styl wygl�du");
define("MENLAN_32", "Wygl�d stylu nag��wka");
define("MENLAN_33", "W�asny wygl�d stylu");
define("MENLAN_34", "Osadzony");
define("MENLAN_35", "Konfiguracja menu");
define("MENLAN_36", "Wybierz menu do aktywacji");
define("MENLAN_37", "a nast�pnie wska� gdzie ma by� aktywowane.");
define("MENLAN_38", "Przytrzymaj wci�ni�ty klawisz CTRL, aby wybra� wi�cej menu.");

?>
