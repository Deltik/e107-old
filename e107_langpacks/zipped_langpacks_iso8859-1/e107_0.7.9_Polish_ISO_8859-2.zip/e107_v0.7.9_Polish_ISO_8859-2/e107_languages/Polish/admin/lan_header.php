<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 22:38:19 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_header.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_header.php rev. 1.
+-----------------------------------------------------------------------------+
*/
 
define("LAN_head_1", "Nawigacja administracji");
define("LAN_head_2", "Tw�j serwer nie zezwala na nadsy�anie plik�w za po�rednictwem HTTP, tak wi�c nie b�dzie mo�liwe nadsy�anie awatar�w, plik�w itp, przez u�ytkownik�w Twojego serwisu. Aby to naprawi� ustaw w pliku php.ini warto�� dla <i>file_uploads</i> na <i>On</i> i ponownie uruchom serwer. Je�li nie masz dost�pu do pliku php.ini, skontaktuj si� ze swoim administratorem serwera.");
define("LAN_head_3", "Tw�j serwer jest uruchomiony z ograniczeniem <i>basedir</i> (katalogu g��wnego). W rezultacie niemo�liwe jest u�ywanie jakichkolwiek innych plik�w spoza g��wnego katalogu strony oraz skrypt�w takich jak np. <i>filemanager</i>.");

define("LAN_head_4", "Panel administratora");

define("LAN_head_5", "J�zyk panelu administracyjnego: ");
define("LAN_head_6", "Informacje o pluginach");

?>
