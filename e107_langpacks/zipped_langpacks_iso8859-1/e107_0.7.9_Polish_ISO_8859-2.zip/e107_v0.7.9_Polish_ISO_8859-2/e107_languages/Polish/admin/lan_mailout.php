<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/08/13 01:29:47 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_mailout.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_mailout.php rev. 1.14
+-----------------------------------------------------------------------------+
*/
 
define("PRFLAN_52", "Zapisz zmiany");
define("PRFLAN_63", "Wy�lij testowego emaila");
define("PRFLAN_64", "Klikni�cie na przycisk spowoduje wys�anie emaila na adres g��wnego administratora strony."); // Clicking button will send test email to main admin email address
define("PRFLAN_65", "Kliknij, aby wys�a� email do");
define("PRFLAN_66", "Testowa wiadomo�� email ze strony");
define("PRFLAN_67", "To jest testowa wiadomo�� email. Otrzymanie jej �wiadczy o tym, �e ustawienia email s� poprawnie skonfigurowane!\n\nPozdrowienia\ne107 website system.");
define("PRFLAN_68", "Email nie zosta� wys�any. Prawdopodobnie serwer hostingowy nie jest poprawnie skonfigurowany do wysy�ania wiadomo�ci email. Prosz� spr�bowa� ponownie u�ywaj�c funkcji SMTP. Mo�esz r�wnie� skontaktowa� si� z administratorem hosta i poinformowa� go o zaistnia�ym problemie. By� mo�e b�dzie potrzebne sprawdzenie konfiguracji serwera pod wzgl�dem ustawie� us�ug email oraz sendmail.");
define("PRFLAN_69", "Wiadomo�� email zosta�a wys�ana pomy�lnie, prosz� sprawdzi� swoj� skrzynk� odbiorcz�.");
define("PRFLAN_70", "Metoda wysy�ania emaili");
define("PRFLAN_71", "Je�li nie wiesz, pozostaw jako php");
define("PRFLAN_72", "Serwer SMTP");
define("PRFLAN_73", "U�ytk. SMTP");
define("PRFLAN_74", "Has�o SMTP");
define("PRFLAN_75", "Email nie zosta� wys�any. Prosz� wykona� przegl�d ustawie� SMTP lub odblokowa� protok� SMTP i sprawdzi� ponownie.");

define("MAILAN_01","Od");
define("MAILAN_02","Adres email");
define("MAILAN_03","Do");
define("MAILAN_04","Kopia do");
define("MAILAN_05","Ukryta kopia do");
define("MAILAN_06","Temat");
define("MAILAN_07","Za��cznik");
define("MAILAN_08","Wy�lij emaila");
define("MAILAN_09","U�yj stylu tematu");
define("MAILAN_10","Subskrynenci");
define("MAILAN_11","Wstaw zmienne");
define("MAILAN_12","Wszyscy zarejestrowani u�ytkownicy");
define("MAILAN_13","Wszyscy nieautoryzowani u�ytkownicy");
define("MAILAN_14","Do wysy�ania du�ej liczby wiadomo�ci email wskazane jest u�ywanie funkcji SMTP - mo�esz to ustawi� w poni�szych preferencjach.");
define("MAILAN_15","Wysy�anie wiadomo�ci email");

define("MAILAN_16","u�ytkownik");
define("MAILAN_17","link do rejestracji");
define("MAILAN_18","id u�ytkownika");
define("MAILAN_19","Brak adresu email administratora strony. Prosz� sprawdzi� ustawienia i spr�bowa� ponownie.");
define("MAILAN_20","�ce�ka dost�pu do <i>sendmail</i>");
define("MAILAN_21","Zapisane wiadomo�ci email");
define("MAILAN_22","Aktualnie nie ma zapisanych pozycji"); // There are currently no saved entries
define("MAILAN_23","grupa u�ytkownik�w: ");
define("MAILAN_24", "email(e) s� gotowe do wys�ania");

define("MAILAN_25", "Pauza");
define("MAILAN_26", "Zatrzymaj zbiorcze wysy�anie poczty co ka�de");
define("MAILAN_27", "emaile");
define("MAILAN_28", "Czas trwania pauzy");
define("MAILAN_29", "sekund(y)");
define("MAILAN_30", "Wi�cej ni� 30 sekund mo�e spowodowa� przekroczenie czasu oczekiwania przegl�darki");
define("MAILAN_31", "Przetwarzanie emaila zwrotnego");
define("MAILAN_32", "Adres email");
define("MAILAN_33", "Skrzynka odbiorcza");
define("MAILAN_34", "Nazwa konta");
define("MAILAN_35", "Has�o");
define("MAILAN_36", "Usu� maile zwrotne po sprawdzeniu");

define("MAILAN_37", "Dalej");
define("MAILAN_38", "Anuluj");
define("MAILAN_39", "Korespondencja elektroniczna");
define("MAILAN_40", "Musisz zmieni� nazw� pliku <b>e107.htaccess</b> na <b>.htaccess</b> w katalogu");
define("MAILAN_41", "przed wysy�aniem poczty z tej strony.");
define("MAILAN_42", "Ostrze�enie");
define("MAILAN_43", "Nazwa u�ytkownika");
define("MAILAN_44", "Login u�ytkownika");
define("MAILAN_45", "Email u�ytkownika");
define("MAILAN_46", "Dobierz u�ytkownik�w wed�ug regu�y<br />");
define("MAILAN_47", "zawiera");
define("MAILAN_48", "r�wna si�");
define("MAILAN_49", "Id");
define("MAILAN_50", "Autor");
define("MAILAN_51", "Temat");
define("MAILAN_52", "Ostatnia modyfikacja");
define("MAILAN_53", "Administratorzy");
define("MAILAN_54", "Do siebie");
define("MAILAN_55", "Grupa u�ytkownik�w");
define("MAILAN_56", "Wy�lij poczt�");
define("MAILAN_57", "Utrzymaj sesj� SMTP w dzia�aniu");
define("MAILAN_58", "Wyst�pi� problem z za��cznikiem:");
define("MAILAN_59", "Post�p wysy�ania poczty");
define("MAILAN_60", "Wysy�anie...");
define("MAILAN_61", "Nie ma oczekuj�cych emaili do wys�ania."); // There are no remaining emails to be sent
define("MAILAN_62", "Emaile wys�ane:");
define("MAILAN_63", "Emaile niewys�ane:");
define("MAILAN_64", "Ca�kowity czas wysy�ania:"); // Total time elapsed
define("MAILAN_65", "sekundy");
define("MAILAN_66", "Anulowanie zosta�o zako�czone pomy�lnie");
define("MAILAN_67", "U�ywaj 'POP przed uwierzytelnianiem SMTP'");

?>
