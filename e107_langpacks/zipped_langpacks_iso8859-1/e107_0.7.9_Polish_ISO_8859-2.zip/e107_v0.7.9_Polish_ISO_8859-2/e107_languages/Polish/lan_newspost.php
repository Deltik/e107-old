<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_newspost.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_newspost.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("NWSLAN_1", "Tre�� wiadomo�ci zosta�a usuni�ta.");
define("NWSLAN_2", "Prosz� zaznaczy� pole, aby usun�� wybran� wiadomo��.");
define("NWSLAN_3", "Nie ma jeszcze �adnych wiadomo�ci.");
define("NWSLAN_4", "Obecne aktualno�ci");
define("NWSLAN_5", "Otw�rz edytor HTML");
define("NWSLAN_6", "Kategoria");
define("NWSLAN_7", "Edytuj");
define("NWSLAN_8", "Usu�");
define("NWSLAN_9", "Zaznacz, aby potwierdzi�");
define("NWSLAN_10", "Nie ma jeszcze �adnych kategorii.");
define("NWSLAN_11", "Dodaj/Edytuj kategori�");
define("NWSLAN_12", "Tytu�");
define("NWSLAN_13", "Tre��");
define("NWSLAN_14", "Rozwini�cie");
define("NWSLAN_15", "Komentarze");
define("NWSLAN_16", "Dozwolone");
define("NWSLAN_17", "Niedozwolone");
define("NWSLAN_18", "Pozw�l dodawa� komentarze do tej wiadomo�ci");
define("NWSLAN_19", "Aktywacja");
define("NWSLAN_20", "Pozostaw puste, aby uniemo�liwi� auto-aktywacj�");
define("NWSLAN_21", "Aktywuj pomi�dzy");
define("NWSLAN_22", "Widoczno��");
define("NWSLAN_23", "Zaznaczenie spowoduje, �e wiadomo�� b�dzie widoczna tylko dla u�ytkownik�w ze wskazanej grupy");
define("NWSLAN_24", "Ponowny podgl�d");
define("NWSLAN_25", "Uaktualnij wiadomo�� w bazie danych");
define("NWSLAN_26", "Dodaj wiadomo�� do bazy danych");
define("NWSLAN_27", "Podgl�d");
define("NWSLAN_28", "Nowa tre��");
define("NWSLAN_29", "Wy�lij wiadomo��");

define("NWSLAN_30", "Pokazuj tylko tytu�");

?>
