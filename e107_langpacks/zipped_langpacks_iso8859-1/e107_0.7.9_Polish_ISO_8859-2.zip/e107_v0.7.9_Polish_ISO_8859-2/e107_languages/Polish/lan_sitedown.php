<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/11/01 00:05:28 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_sitedown.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_sitedown.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Strona tymczasowo wy��czona");

define("LAN_SITEDOWN_00", "- serwis jest chwilowo wy��czony");
define("LAN_SITEDOWN_01", "Wy��czyli�my chwilowo serwis z powodu niezb�dnej konserwacji oraz przeprowadzanych bardzo istotnych aktualizacji.<br />Nie powinno to potrwa� zbyt d�ugo - prosimy zajrze� do nas za jaki� czas.<br /><br />Przepraszamy za wszelkie niedogodno�ci.");

?>
