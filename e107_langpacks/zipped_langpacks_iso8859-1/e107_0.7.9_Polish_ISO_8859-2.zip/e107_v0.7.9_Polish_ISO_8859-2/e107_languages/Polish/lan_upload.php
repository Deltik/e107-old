<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_upload.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_upload.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Wysy�anie pliku");

define("LAN_20", "B��d");
define("LAN_61", "Imi�: ");
define("LAN_112", "Adres email: ");
define("LAN_144", "Strona domowa: ");
define("LAN_402", "Musisz by� zarejestrowanym u�ytkownikiem, aby wys�a� pliki na ten serwer.");
define("LAN_403", "Nie masz odpowiednich uprawnie�, aby wysy�a� pliki na ten serwer.");
define("LAN_404", "Dzi�kujemy, wys�any plik b�dzie sprawdzony przez administratora i po uzyskaniu pozytywnej oceny zostanie umieszczony w odpowiednim dziale.");
define("LAN_405", "Plik przekracza zdefiniowany limit wielko�ci - plik zosta� usuni�ty.");
define("LAN_406", "Uwaga");
define("LAN_407", "Wszystkie inne typy wysy�anych plik�w zostan� natychmiast skasowane.");
define("LAN_408", "Podkre�lone");
define("LAN_409", "Nazwa pliku");
define("LAN_410", "Wersja");
define("LAN_411", "Plik");
define("LAN_412", "Zrzut ekranu");
define("LAN_413", "Opis");
define("LAN_414", "Demo");
define("LAN_415", "Wpisz adres strony, na kt�rej znajduje si� dzia�aj�ce demo");
define("LAN_416", "Dodaj i wy�lij plik");
define("LAN_417", "Wy�lij plik");
define("LAN_418", "Maksymalny rozmiar pliku: ");
define("DOWLAN_11", "Kategoria");
define("LAN_419", "Dozwolone typy plik�w");
define("LAN_420", "pola s� wymagane");

?>
