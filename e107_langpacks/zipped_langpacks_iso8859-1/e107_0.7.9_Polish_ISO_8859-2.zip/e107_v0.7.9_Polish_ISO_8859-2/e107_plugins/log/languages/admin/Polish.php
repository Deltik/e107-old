<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2007/10/08 19:03:31 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/log/languages/admin/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/log/languages/admin/English.php rev. 1.13
+-----------------------------------------------------------------------------+
*/
 
define("ADSTAT_ON", "W��czone");
define("ADSTAT_OFF", "Wy��czone");
define("ADSTAT_L1", "Ten plugin b�dzie zapisywa� wszystkie wizyty na Twojej stronie, a nast�pnie wykona szczeg�owe zestawienie bazuj�ce na zebranych informacjach.");
define("ADSTAT_L2", "Plugin statystyk zosta� pomy�lnie zainstalowany. Aby aktywowa�, prosz� przej�� do strony konfiguracyjnej plugina i wybra� odpowiednia opcj�.<br /><b>Musisz ustawi� uprawnienia katalogu e107_plugins/log/logs na warto�� 777 (chmod 777)</b>");
define("ADSTAT_L3", "Statystyki");
define("ADSTAT_L4", "Aktywacja statystyk");
define("ADSTAT_L5", "Rodzaje statystyk");
define("ADSTAT_L6", "Przegl�darki");
define("ADSTAT_L7", "Systemy operacyjne");
define("ADSTAT_L8", "Rozdzielczo�� oraz g��bia kolor�w");
define("ADSTAT_L9", "Kraje oraz domeny");
define("ADSTAT_L10", "Strony odsy�aj�ce");
define("ADSTAT_L11", "S�owa kluczowe");
define("ADSTAT_L12", "Resetuj statystyki");
define("ADSTAT_L13", "ta opcja wyma�e statystyki - ostro�nie!");
define("ADSTAT_L14", "Ilo�� stron");
define("ADSTAT_L15", "Aktualizuj ustawienia");
define("ADSTAT_L16", "Ustawienia statystyk");
define("ADSTAT_L17", "Ustawienia statystyk zosta�y zaktualizowane");
define("ADSTAT_L18", "Zezw�l na dost�p do g��wnej strony statystyk dla...");
define("ADSTAT_L19", "Ostatni go�cie");
define("ADSTAT_L20", "Zliczanie wizyt administrator�w");
define("ADSTAT_L21", "Maksymalna ilo�� rekord�w wy�wietlana na stronie statystyk");
define("ADSTAT_L22", "Uruchom podprogram aktualizuj�cy");
define("ADSTAT_L23", "Zosta�y wykryte statystyki z poprzedniej wersji systemu e107, zaktualizuj je tutaj");
define("ADSTAT_L24", "Przejd� do skryptu aktualizuj�cego");
define("ADSTAT_L25", "Wybrane statystyki zosta�y zresetowane");
define("ADSTAT_L26", "Usu� wpisy stron");
define("ADSTAT_L27", "Je�li statystyki zawieraj� niepoprawne strony, mo�esz usun�� je z poziomu tej strony");
define("ADSTAT_L28", "Otw�rz stron�");
define("ADSTAT_L29", "Nazwa strony");
define("ADSTAT_L30", "Zaznacz, aby usun��");
define("ADSTAT_L31", "Usu� wybrane strony");
define("ADSTAT_L32", "Porz�dkowanie stron");
define("ADSTAT_L33", "Konfiguracja statystyk");
define("ADSTAT_L34", "Statystyki strony");

?>