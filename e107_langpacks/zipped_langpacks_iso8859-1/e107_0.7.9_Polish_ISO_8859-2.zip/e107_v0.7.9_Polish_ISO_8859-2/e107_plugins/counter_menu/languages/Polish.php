<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.6 $
|     $Date: 2006/10/29 16:04:09 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/counter_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/counter_menu/languages/English.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("COUNTER_L1", "Wizyty administrator�w nie s� zliczane.<br />");
define("COUNTER_L2", "Dzisiejsze odwiedziny tej strony...");
define("COUNTER_L3", "og�em");
define("COUNTER_L4", "Dotychczasowe odwiedziny tej strony...");
define("COUNTER_L5", "unikalnych");
define("COUNTER_L6", "Wszystkich odwiedzin serwisu...");
define("COUNTER_L7", "Licznik");
define("COUNTER_L8", "Wiadomo�� administracyjna: <b>Rejestracja statystyk jest wy��czona.</b><br />Aby j� aktywowa�, zainstaluj plugin <i>Statystyki</i> u�ywaj�c <a href='".e_ADMIN."plugin.php'>mened�era plugin�w</a>, a nast�pnie aktywuj odpowiedni� opcj� na stronie <a href='".e_PLUGIN."log/admin_config.php'>ustawie� plugina</a>.");

?>
