<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:37:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/featurebox/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/featurebox/languages/English.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
  
define("FBLAN_01", "Wiadomo�ci specjalne");
define("FBLAN_02", "Plugin Wiadomo�ci specjalne (Feature Box) umo�liwia wy�wietlanie, ponad pozycjami aktualno�ci, komunikat�w, kt�re uznasz za wa�ne, lub czegokolwiek innego co b�dziesz chcia� umie�ci� w tym miejscu. Wiadomo�ci mog� zmienia� si� losowo, albo zanikac dynamicznie.");
define("FBLAN_03", "Konfiguracja wiadomo�ci specjalnych");
define("FBLAN_04", "Plugin Wiadomo�ci specjalne (Feature Box) zosta� pomy�lnie zainstalowany. Aby doda� wiadomo�� oraz skonfigurowa� plugin, powr�� do Panelu admina i w sekcji plugin�w kliknij w ikon� Wiadomo�ci specjalne.");
define("FBLAN_05", "Nie utworzono jeszcze �adnych wiadomo�ci specjalnych");
define("FBLAN_06", "Aktualne wiadomo�ci specjalne");
define("FBLAN_07", "Nag��wek");
define("FBLAN_08", "Tre�� wiadomo�ci");
define("FBLAN_09", "Wiadomo�� widoczna dla:");
define("FBLAN_10", "Utw�rz wiadomo��");
define("FBLAN_11", "Zaktualizuj wiadomo��");
define("FBLAN_12", "Styl");
define("FBLAN_13", "Losowo zmieniane wiadomo�ci");
define("FBLAN_14", "Pokazuj tylko t� wiadomo��");
define("FBLAN_15", "Wiadomo�� zosta�a dodana do bazy danych.");
define("FBLAN_16", "Wiadomo�� zosta�a zaktualizowana w bazie danych.");
define("FBLAN_17", "Wymagane pola pozosta�y puste");
define("FBLAN_18", "Wiadomo�� zosta�a usuni�ta");
define("FBLAN_19", "Opcje");
define("FBLAN_20", "Edytuj");
define("FBLAN_21", "Usu�");
define("FBLAN_22", "Spos�b wy�wietlania");
define("FBLAN_23", "Zgodnie ze stylem u�ywanego tematu");
define("FBLAN_24", "Prosty");
define("FBLAN_25", "Szablon");
define("FBLAN_26", "Mo�esz u�ywa� r�nych szablon�w dla poszczeg�lnych wiadomo�ci. W�asne szablony dodaj do katalogu ".e_PLUGIN."featurebox/templates/");

?>
