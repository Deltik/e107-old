<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.6 $
|     $Date: 2007/02/10 15:53:40 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/links_page/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/links_page/languages/English.php rev. 1.29
+-----------------------------------------------------------------------------+
*/
 
// if(!defined("PAGE_NAME")){define("PAGE_NAME", "Links");}  <--
// Lisa, could you please move this out of the language file ?



define("LCLAN_PLUGIN_LAN_1", "Strona link�w");
define("LCLAN_PLUGIN_LAN_2", "Plugin Strona link�w s�u�y do katalogowania i wy�wietlania link�w prowadz�cych do zewn�trznych serwis�w.");
define("LCLAN_PLUGIN_LAN_3", "Konfiguracja strony link�w");
define("LCLAN_PLUGIN_LAN_4", "linki");
define("LCLAN_PLUGIN_LAN_5", "Strona link�w zosta�a pomy�lnie zainstalowana, prosz� skonfigurowa� t� stron� z poziomu panelu administratora przy u�yciu linku w sekcji plugin�w.");
define("LCLAN_PLUGIN_LAN_6", "Strona link�w zosta�a pomy�lnie zaktualizowana do nowszej wersji, aktualnie u�ywasz wersji");

define("LCLAN_OPT_MENU_1", "Opcje og�lne");
define("LCLAN_OPT_MENU_2", "Osobisty mened�er link�w");
define("LCLAN_OPT_MENU_3", "Strona kategorii");
define("LCLAN_OPT_MENU_4", "Wy�wietlanie link�w");
define("LCLAN_OPT_MENU_5", "Strona ods�on");
define("LCLAN_OPT_MENU_6", "Strona ocen");
define("LCLAN_OPT_MENU_7", "Menu");

define("LCLAN_PAGETITLE_1", "Linki");
define("LCLAN_PAGETITLE_2", "Wszystkie kategorie");
define("LCLAN_PAGETITLE_3", "Wszystkie linki");
define("LCLAN_PAGETITLE_4", "Kategoria");
define("LCLAN_PAGETITLE_5", "Lista Top Link�w : Najlepiej ocenione");
define("LCLAN_PAGETITLE_6", "Lista Top Link�w : Najwi�cej ods�on");
define("LCLAN_PAGETITLE_7", "Osobisty mened�er link�w");
define("LCLAN_PAGETITLE_8", "Komentarze link�w");
define("LCLAN_PAGETITLE_9", "Wy�lij link");
define("LCLAN_PAGETITLE_10", "");


define("LCLAN_OPT_1", "Opcje og�lne");
define("LCLAN_OPT_2", "Strona opcji link�w");
define("LCLAN_OPT_3", "W��czone");
define("LCLAN_OPT_4", "Wy��czone");
define("LCLAN_OPT_5", "pikseli");
define("LCLAN_OPT_6", "");
define("LCLAN_OPT_7", "Podzia� kategorii na oddzielne strony");
define("LCLAN_OPT_8", "Zezw�l na nadsy�anie link�w");
define("LCLAN_OPT_9", "Kto mo�e nadsy�a� linki?");
define("LCLAN_OPT_10", "U�ywaj wielu stron do wy�wietlania link�w");
define("LCLAN_OPT_11", "Ilo�� link�w na stronie");
define("LCLAN_OPT_12", "Strona kategorii");
define("LCLAN_OPT_13", "Wy�wietlane sekcje");
define("LCLAN_OPT_14", "Ikona");
define("LCLAN_OPT_15", "Opis");
define("LCLAN_OPT_16", "Ilo��");
define("LCLAN_OPT_17", "Ods�ony");
define("LCLAN_OPT_18", "Adres URL");
define("LCLAN_OPT_19", "Linia informacyjna o wszystkich kategoriach");
define("LCLAN_OPT_20", "Link do listy top ods�on");
define("LCLAN_OPT_21", "Link do listy top ocen");
define("LCLAN_OPT_22", "Poka� domy�ln� ikon�, je�li brak jest bie��cej");
define("LCLAN_OPT_23", "Domy�lna metoda sortowania");
define("LCLAN_OPT_24", "Domy�lna metoda kolejkowania");
define("LCLAN_OPT_25", "Domy�lna warto�� rozmiaru");
define("LCLAN_OPT_26", "Strona link�w");
define("LCLAN_OPT_27", "Zezw�l u�ytkownikom na ocenianie link�w");
define("LCLAN_OPT_28", "Pokazuj domy�ln� ikon�, je�li brak bie��cej");
define("LCLAN_OPT_29", "Wy�wietl menu sortowania i ustawienia kolejno�ci");
define("LCLAN_OPT_30", "rosn�co");
define("LCLAN_OPT_31", "malej�co");
define("LCLAN_OPT_32", "Uniewa�nij u�ywane metody otwierania link�w");
define("LCLAN_OPT_33", "Domy�lna warto�� rozmiaru");
define("LCLAN_OPT_34", "Nazwa");
define("LCLAN_OPT_35", "Adres URL");
define("LCLAN_OPT_36", "Kolejno��");
define("LCLAN_OPT_37", "Ods�ony");
define("LCLAN_OPT_38", "");
define("LCLAN_OPT_39", "");
define("LCLAN_OPT_40", "Nazwa");
define("LCLAN_OPT_41", "Id");
define("LCLAN_OPT_42", "U�yj indywidualnych ustawie� linka");
define("LCLAN_OPT_43", "Otw�rz w tym samym oknie");
define("LCLAN_OPT_44", "Otw�rz w nowym oknie");
define("LCLAN_OPT_45", "Otw�rz w mini-oknie 600x400");
define("LCLAN_OPT_46", "Kto mo�e zarz�dza� linkami?");
define("LCLAN_OPT_47", "Wskazani u�ytkownicy b�d� mogli dodawa� nowe oraz edytowa� ju� dodane przez siebie wcze�niej linki.");
define("LCLAN_OPT_48", "Zezw�l na proste dodawanie");
define("LCLAN_OPT_49", "Je�li w��czone, nades�ane linki b�d� dodawane bezpo�rednio, w innym przypadku administratorzy strony b�d� musieli najpierw je zaakceptowa�.");
define("LCLAN_OPT_50", "Zezw�l na proste usuwanie");
define("LCLAN_OPT_51", "Je�li w��czone, to osoby zrz�dzaj�ce linkami b�d� mogli usuwa� linki dodane przez siebie.");
define("LCLAN_OPT_52", "Osobisty mened�er link�w");
define("LCLAN_OPT_53", "Data");
define("LCLAN_OPT_54", "Zezw�l na zarz�dzanie osobistymi linkami");
define("LCLAN_OPT_55", "Zezw�l na komentowanie wszystkich link�w");
define("LCLAN_OPT_56", "Minimalna warto�� ods�on");
define("LCLAN_OPT_57", "Tylko linki z warto�ci� ods�on wi�ksz� ni� zadeklarowana b�d� wy�wietlane (0 lub puste pole = wszystkie)");
define("LCLAN_OPT_58", "Link do wys�ania linka");
define("LCLAN_OPT_59", "Link do osobistego mened�era");
define("LCLAN_OPT_60", "Link do strony g��wnej link�w");
define("LCLAN_OPT_61", "Link do wszystkich kategorii");
define("LCLAN_OPT_62", "Wy�wietl nast�puj�ce linki nawigacyjne");
define("LCLAN_OPT_63", "Minimalna warto�� oceny");
define("LCLAN_OPT_64", "Tylko linki z ocen� wi�ksz� ni� zdefiniowanej warto�ci b�d� wy�wietlane (0 lub puste pole = wszystkie)");
define("LCLAN_OPT_65", "Pokazuj puste kategorie");
define("LCLAN_OPT_66", "Link do ka�dej kategorii");
define("LCLAN_OPT_67", "Link do wszystkich link�w");
define("LCLAN_OPT_68", "Wy�wietl wszystkie linki");

define("LCLAN_OPT_69", "Metoda wy�wietlania link�w nawigacyjnych");
define("LCLAN_OPT_70", "Wy�wietlanie kategorii link�w");
define("LCLAN_OPT_71", "Metoda wy�wietlania kategorii link�w");
define("LCLAN_OPT_72", "Wy�wietlanie ostatnio dodanych link�w");
define("LCLAN_OPT_73", "Pokazywane dane");
define("LCLAN_OPT_74", "Ile wy�wietla� ostatnio dodanych link�w?");
define("LCLAN_OPT_75", "hiper��cza");
define("LCLAN_OPT_76", "pole wyboru");
define("LCLAN_OPT_77", "kategoria");
define("LCLAN_OPT_78", "opis");
define("LCLAN_OPT_79", "Nag��wek nawigatora");
define("LCLAN_OPT_80", "Nag��wek kategorii");
define("LCLAN_OPT_81", "Nag��wek ostatnio dodanych link�w");
define("LCLAN_OPT_82", "Nawigator");
define("LCLAN_OPT_83", "Kategorie");
define("LCLAN_OPT_84", "Najnowsze linki");
define("LCLAN_OPT_85", "Nag��wek menu");
define("LCLAN_OPT_86", "Katalog link�w");
define("LCLAN_OPT_87", "Pokazuj ilo�� link�w");

define("LCLAN_ADMIN_1", "Aktualizuj"); // deprecated
define("LCLAN_ADMIN_2", "Link zosta� zapisany w bazie danych.");
define("LCLAN_ADMIN_3", "Link zosta� zaktualizowany w bazie danych.");
define("LCLAN_ADMIN_4", "Kategoria link�w zosta�a zapisana");
define("LCLAN_ADMIN_5", "Kategoria link�w zosta�a zaktualizowana");
define("LCLAN_ADMIN_6", "Opcje zosta�y zapisane");
define("LCLAN_ADMIN_7", "Ikona zosta�a pomy�lnie za�adowana!");
define("LCLAN_ADMIN_8", "Ikona nie zosta�a za�adowana!");
define("LCLAN_ADMIN_9", "Kolejno�� zosta�a zaktualizowana");
define("LCLAN_ADMIN_10", "Link");
define("LCLAN_ADMIN_11", "Usu�"); // deprecated
define("LCLAN_ADMIN_12", "Kategoria link�w");
define("LCLAN_ADMIN_13", "Nades�any link zosta� usuni�ty");
define("LCLAN_ADMIN_14", "Linki");
define("LCLAN_ADMIN_15", "Ta kategoria wci�� zawiera linki, prosz� najpierw je usun�� lub przenie�� do innej kategorii.");

define("LCLAN_SL_1", "Nades�ane linki");
define("LCLAN_SL_2", "Brak nades�anych link�w");
define("LCLAN_SL_3", "Link");
define("LCLAN_SL_4", "Nades�any przez");
define("LCLAN_SL_5", "Opcje");
define("LCLAN_SL_6", "Dodaj");
define("LCLAN_SL_7", "Usu�");
define("LCLAN_SL_8", "Czy na pewno chcesz usun�� nades�any link?");
define("LCLAN_SL_9", "Po wys�aniu, link zostanie sprawdzony przez administratora strony i, je�li oka�e si� odpowiedni, zostanie dodany do katalogu link�w.");
define("LCLAN_SL_10", "Kategoria:");
define("LCLAN_SL_11", "Nazwa");
define("LCLAN_SL_12", "Adres URL");
define("LCLAN_SL_13", "Opis");
define("LCLAN_SL_14", "Adres URL do przycisku linka:");
define("LCLAN_SL_15", "Podkre�lone pola s� wymagane.");
define("LCLAN_SL_16", "Wy�lij link");
define("LCLAN_SL_17", "");
define("LCLAN_SL_18", "");

define("LCLAN_CAT_1", "Obrazek");
define("LCLAN_CAT_2", "Kategoria");
define("LCLAN_CAT_3", "Opcje");
define("LCLAN_CAT_4", "Przesu�");
define("LCLAN_CAT_5", "Kolejno��");
define("LCLAN_CAT_6", "Edytuj");
define("LCLAN_CAT_7", "S�");
define("LCLAN_CAT_8", "Czy na pewno chcesz usun�� wskazan� kategori�?");
define("LCLAN_CAT_9", "Wy�wietl linki");
define("LCLAN_CAT_10", "Prze�aduj");
define("LCLAN_CAT_11", "Brak kategorii link�w");
define("LCLAN_CAT_12", "Aktualne kategorie link�w");
define("LCLAN_CAT_13", "Nazwa:");
define("LCLAN_CAT_14", "Opis:");
define("LCLAN_CAT_15", "Za�aduj now� ikon�:");
define("LCLAN_CAT_16", "Rozmiar auto-miniaturki:");
define("LCLAN_CAT_17", "Ta opcja jest nieaktywna ze wzgl�du na to, �e przesy�anie plik�w na Twoim serwerze jest wy��czone.");
define("LCLAN_CAT_18", "Katalog");
define("LCLAN_CAT_19", "nie jest zapisywalny, zanim za�adujesz ustaw warto�� katalogu na CHMOD 777.");
define("LCLAN_CAT_20", "pikseli");
define("LCLAN_CAT_21", "Za�aduj");
define("LCLAN_CAT_22", "Wybierz ikon�:");
define("LCLAN_CAT_23", "Wy�wietl obrazki");
define("LCLAN_CAT_24", "Widoczne dla:");
define("LCLAN_CAT_25", "Zaznacz, aby zaktualizowa� dat� dodania do aktualnego czasu.");
define("LCLAN_CAT_26", "Aktualizuj kategori� link�w");
define("LCLAN_CAT_27", "Wyczy�� wszystko");
define("LCLAN_CAT_28", "Utw�rz kategori� link�w");
define("LCLAN_CAT_29", "Kategoria link�w");

define("LCLAN_ITEM_1", "Nades�ane przez");
define("LCLAN_ITEM_2", "Kategoria:");
define("LCLAN_ITEM_3", "Nie ma jeszcze �adnych kategorii");
define("LCLAN_ITEM_4", "Nazwa:");
define("LCLAN_ITEM_5", "Adres URL:");
define("LCLAN_ITEM_6", "Opis:");
define("LCLAN_ITEM_7", "Za�aduj ikon�:");
define("LCLAN_ITEM_8", "Rozmiar auto-miniaturki:");
define("LCLAN_ITEM_9", "Ta opcja jest nieaktywna ze wzgl�du na to, �e przesy�anie plik�w na Twoim serwerze jest wy��czone.");
define("LCLAN_ITEM_10", "Katalog");
define("LCLAN_ITEM_11", "nie jest zapisywalny, zanim za�adujesz ustaw warto�� katalogu na CHMOD 777.");
define("LCLAN_ITEM_12", "pikseli");
define("LCLAN_ITEM_13", "Za�aduj");
define("LCLAN_ITEM_14", "Wybierz ikon�:");
define("LCLAN_ITEM_15", "Wy�wietl obrazki");
define("LCLAN_ITEM_16", "Metoda otwierania:");
define("LCLAN_ITEM_17", "Otw�rz w tym samym oknie");
define("LCLAN_ITEM_18", "Otw�rz w nowym oknie");
define("LCLAN_ITEM_19", "Otw�rz w mini-oknie 600x400");
define("LCLAN_ITEM_20", "Widoczne dla:");
define("LCLAN_ITEM_21", "Zaznacz, aby zaktualizowa� dat� dodania do aktualnego czasu.");
define("LCLAN_ITEM_22", "Aktualizuj link");
define("LCLAN_ITEM_23", "Utw�rz link");
define("LCLAN_ITEM_24", "Linki");
define("LCLAN_ITEM_25", "Obrazek");
define("LCLAN_ITEM_26", "Nazwa linka");
define("LCLAN_ITEM_27", "Opcje");
define("LCLAN_ITEM_28", "Przesu�");
define("LCLAN_ITEM_29", "Kolejno��");
define("LCLAN_ITEM_30", "Prze�aduj");
define("LCLAN_ITEM_31", "Edytuj");
define("LCLAN_ITEM_32", "Usu�");
define("LCLAN_ITEM_33", "Czy na pewno chcesz usun�� wskazany link?");
define("LCLAN_ITEM_34", "brak ikony");
define("LCLAN_ITEM_35", "Osobisty mened�er link�w");
define("LCLAN_ITEM_36", "id�");
define("LCLAN_ITEM_37", "Wy�wietl wszystkie linki");
define("LCLAN_ITEM_38", "Wszystkie linki");
define("LCLAN_ITEM_39", "Ocena");

define("LCLAN_ADMINMENU_1", "Opcje link�w");
define("LCLAN_ADMINMENU_2", "Zarz�dzanie kategoriami");
define("LCLAN_ADMINMENU_3", "Utw�rz kategori� link�w");
define("LCLAN_ADMINMENU_4", "Zarz�dzanie linkami");
define("LCLAN_ADMINMENU_5", "Utw�rz link");
define("LCLAN_ADMINMENU_6", "Opcje");
define("LCLAN_ADMINMENU_7", "Nades�ane linki");
define("LCLAN_ADMINMENU_8", "Kategorie");

define("NT_LAN_LP_1", "Wydarzenia na stronie link�w");
define("NT_LAN_LP_2", "Linki nades�ane przez u�ytkownik�w");
define("NT_LAN_LP_3", "Nades�ane linki");

define("LNK_SCH_LAN_2", "Wszystkie kategorie link�w");
define("LNK_SCH_LAN_3", "Wszystkie szczeg�y link�w");

define("LAN_LINKS_MANAGER_0", "Ikona");
define("LAN_LINKS_MANAGER_1", "Link");
define("LAN_LINKS_MANAGER_2", "Opcje");
define("LAN_LINKS_MANAGER_3", "Utw�rz nowy link");
define("LAN_LINKS_MANAGER_4", "Nie zaprezentowa�e� jeszcze na stronie �adnych link�w.");
define("LAN_LINKS_MANAGER_5", "Kategoria");
define("LAN_LINKS_MANAGER_6", "");
define("LAN_LINKS_MANAGER_7", "");
define("LAN_LINKS_MANAGER_8", "");
define("LAN_LINKS_MANAGER_9", "");

define("LAN_LINKS_1", "Wszystkich link�w");
define("LAN_LINKS_2", "Wszystkich aktywnych link�w");
define("LAN_LINKS_3", "Anonim");
define("LAN_LINKS_4", "Nag��wka");
define("LAN_LINKS_5", "Adresu URL");
define("LAN_LINKS_6", "Kolejno��");
define("LAN_LINKS_7", "Ods�on");
define("LAN_LINKS_8", "rosn�co");
define("LAN_LINKS_9", "malej�co");
define("LAN_LINKS_10", "Lista Top Link�w : Najcz�ciej odwiedzane");
define("LAN_LINKS_11", "Lista Top Link�w : Najlepiej ocenione");
define("LAN_LINKS_12", "Wy�wietl linki wed�ug ilo�ci ods�on");
define("LAN_LINKS_13", "Wy�wietl linki wed�ug oceny");
define("LAN_LINKS_14", "Wy�wietl stron� g��wn� link�w");
define("LAN_LINKS_15", "Sortuj wed�ug");
define("LAN_LINKS_16", "w kategorii");
define("LAN_LINKS_17", "link");
define("LAN_LINKS_18", "link�w");
define("LAN_LINKS_19", "kategorie");
define("LAN_LINKS_20", "kategoria");
define("LAN_LINKS_21", "Aktualnie");
define("LAN_LINKS_22", "jest");
define("LAN_LINKS_23", "s�");
define("LAN_LINKS_24", "wszystkich w");
define("LAN_LINKS_25", "Poka� wszystkie linki");
define("LAN_LINKS_26", "Ods�on");
define("LAN_LINKS_27", "Wy�lij link");
define("LAN_LINKS_28", "Dzi�kujemy");
define("LAN_LINKS_29", "Tw�j link zosta� zapisany i wkr�tce zostanie sprawdzony przez administratora strony.");
define("LAN_LINKS_30", "Kategorie link�w");
define("LAN_LINKS_31", "Wy�lij link");
define("LAN_LINKS_32", "Kategoria:");
define("LAN_LINKS_33", "�aden link nie zosta� jeszcze oceniony.");
define("LAN_LINKS_34", "Aktualnie nie ma �adnych link�w.");
define("LAN_LINKS_35", "Osobisty mened�er link�w");
define("LAN_LINKS_36", "Komentarze");
define("LAN_LINKS_37", "Komentarze");
define("LAN_LINKS_38", "Daty");
define("LAN_LINKS_39", "Linki");
define("LAN_LINKS_40", "Kategoria");
define("LAN_LINKS_41", "Nie ma jeszcze �adnych kategorii");
define("LAN_LINKS_42", "�aden link nie zosta� jeszcze odwiedzony");
define("LAN_LINKS_43", "Wy�wietl wszystkie kategorie");
define("LAN_LINKS_44", "Id");
define("LAN_LINKS_45", "Kategoria link�w");
define("LAN_LINKS_46", "Podkategoria link�w");
define("LAN_LINKS_47", "Linki nawigacyjne...");
define("LAN_LINKS_48", "-- zobacz kategorie --");
define("LAN_LINKS_49", "");
define("LAN_LINKS_50", "Obecnie nie masz uprawnie� do dodawania link�w");

define("LAN_ADMIN_HELP_0", "Strona link�w");

define("LAN_ADMIN_HELP_1", "<i>Strona zarz�dzania kategoriami link�w wy�wietla wszystkie dost�pne kategorie.</i><br /><br /><b>Szczeg�owa wykaz</b><br />Widzisz list� wszystkich kategorii wraz z ich obrazkiem, nazwami oraz opisem, opcje, a tak�e opcje sortowania.<br /><br /><b>Obja�nienie ikon</b><br />
".LINK_ICON_LINK." : link do kategorii<br /><br />
".LINK_ICON_EDIT." : edycja kategorii<br /><br />
".LINK_ICON_DELETE." : usuni�cie kategorii<br /><br />
".LINK_ICON_ORDER_UP." : przycisk ze strza�k� do g�ry pozwoli Ci przesun�� dan� kategori� o jedn� pozycje w g�r�.<br /><br />
".LINK_ICON_ORDER_DOWN." : przycisk ze strza�ka w d� pozwoli Ci przesun�� dan� kategori� o jedn� pozycje w d�.<br />
<br />
<b>Kolejno��</b><br />Z poziomu tej strony mo�esz r�cznie ustawi� kolejno�� wszystkich kategorii. Aby tego dokona�, zmie� warto�� w polach wyboru na kolejno�� jak� chcesz i naci�nij przycisk <i>Prze�aduj</i> znajduj�cy si� poni�ej wszystkich p�l wyboru w celu zapisania nowej kolejno�ci kategorii.<br />");

define("LAN_ADMIN_HELP_2", "<i>Strona tworzenia kategorii link�w umo�liwia dodanie nowej kategorii do ju� istniej�cych.</i><br /><br />Mo�esz r�wnie� za�adowa� now� ikon�, a potem przydzieli� j� do danej kategorii.");
define("LAN_ADMIN_HELP_3", "<i>Strona zarz�dzania linkami dla lepszej przejrzysto�ci wy�wietla w pierwszej kolejno�ci wszystkie kategorie.</i><br /><br />".LINK_ICON_LINK." : link do danej kategorii<br /><br />".LINK_ICON_EDIT." : kliknij na ikonie w celu wy�wietlenia wszystkich link�w dla danej kategorii<br />");
define("LAN_ADMIN_HELP_4", "<i>Strona do tworzenia link�w umo�liwia dodanie nowego linka.</i><br /><br />Mo�esz r�wnie� za�adowa� now� ikon�, a potem przydzieli� j� do danego linka.<br /><br />Metoda otwierania umo�liwia zdefiniowanie sposobu otwarcia danego odsy�acza, gdy kliknie na nim jaki� u�ytkownik.");
define("LAN_ADMIN_HELP_5", "<i>Strona nades�anych link�w ukazuje wszystkie linki, kt�re zosta�y nades�ane przez u�ytkownik�w.</i><br /><br /><b>Szczeg�owy wykaz</b><br />Na stronie widzisz adres URL, nazw� u�ytkownika, kt�ry przys�a� link, oraz opcje.<br /><br /><b>Obja�nienie ikon</b><br />
".LINK_ICON_EDIT." : przesy�a nades�any link do formularza tworzenia link�w<br /><br />
".LINK_ICON_DELETE." : usuni�cie nades�anego linka<br />
");
define("LAN_ADMIN_HELP_6", "<i>Strona opcji umo�liwia zmian� sposobu dzia�ania plugina.</i><br /><br />
Opcje og�lne<br />
Te opcje s� u�ywane przewa�nie na wszystkich stronach link�w<br /><br />
Osobisty mened�er link�w<br />
Mened�erowie osobistych link�w s� uprzywilejowanymi u�ytkownikami, kt�rzy mog� zarz�dza� linkami dodanym przez siebie.<br /><br />
Strona kategorii<br />
Tutaj mo�esz zmieni� opcje dla strony kategorii.<br /><br />
Strona link�w<br />
Opcje z tego dzia�u s� u�ywane na stronach link�w.<br /><br />
Strona ods�on<br />
Opcje z tego dzia�u s� u�ywane na li�cie top najch�tniej odwiedzanych stron.<br /><br />
Strona ocen<br />
Opcje z tego dzia�u s� u�ywane na li�cie top najlepiej ocenionych stron.<br />
");

define("LAN_ADMIN_HELP_7", "<i>Strona edycji kategorii link�w umo�liwia edytowanie istniej�cych kategorii link�w.</i><br /><br />Mo�esz za�adowa� now� ikon�, a potem przydzieli� j� do danej kategorii.<br />Mo�esz r�wnie� zaktualizowa� czas dodania link�w poprzez zaznaczenie odpowiedniego pola.");

define("LAN_ADMIN_HELP_8", "<i>Na tej stronie s� wy�wietlane wszystkie aktualne linki z wybranej kategorii.</i><br /><br /><b>Szczeg�owy wykaz</b><br />Na stronie widzisz list� link�w wraz z ich obrazkami, nazw�, opcjami, oraz sposobami sortowania.<br /><br /><b>Obja�nienie ikon</b><br />
".LINK_ICON_LINK." : link do danej strony<br /><br />
".LINK_ICON_EDIT." : edycja linka<br /><br />
".LINK_ICON_DELETE." : usuni�cie linka<br /><br />
".LINK_ICON_ORDER_UP." : przycisk ze strza�k� do g�ry pozwoli Ci przesun�� dany link o jedn� pozycj� w g�r�.<br /><br />
".LINK_ICON_ORDER_DOWN." : przycisk ze strza�k� w d� pozwoli Ci przesun�� dany link o jedn� pozycj� w d�.<br />
<br />
<b>Kolejno��</b><br />Z poziomu tej strony mo�esz r�wnie� r�cznie ustawi� kolejno�� wszystkich link�w. Aby tego dokona�, zmie� warto�� w polach wyboru na kolejno�� jak� chcesz i naci�nij przycisk <i>Prze�aduj</i> znajduj�cy si� poni�ej wszystkich p�l wyboru w celu zapisania nowej kolejno�ci link�w.<br />");

define("LAN_ADMIN_HELP_9", "<i>Strona edycji link�w umo�liwia edycj� ju� istniej�cych link�w</i><br /><br />Mo�esz r�wnie� za�adowa� now� ikon�, a potem przydzieli� j� do danego linka.<br /><br />Metoda otwierania umo�liwia zdefiniowanie sposobu otwarcia danego odsy�acza, gdy kliknie na nim jaki� u�ytkownik.");
define("LAN_ADMIN_HELP_10", "<i>Strona nades�anych link�w umo�liwia dodanie nades�anego linka b�d� link�w do katalogu link�w.</i><br /><br />Informacja dotycz�ca nades�ania zostanie dodana do opisu linka.<br /><br />Mo�esz r�wnie� za�adowa� now� ikon�, a potem przydzieli� j� do danego linka.<br /><br />Metoda otwierania umo�liwia zdefiniowanie sposobu otwarcia danego odsy�acza, gdy kliknie na nim jaki� u�ytkownik.");

?>
