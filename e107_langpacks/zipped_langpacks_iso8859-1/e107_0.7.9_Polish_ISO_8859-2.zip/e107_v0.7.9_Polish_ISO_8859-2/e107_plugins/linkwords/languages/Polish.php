<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2007/10/08 19:03:18 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/linkwords/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/linkwords/languages/English.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("LWLAN_1", "Wymagane pola pozosta�y puste.");
define("LWLAN_2", "Link wyrazowy zosta� zapisany.");
define("LWLAN_3", "Link wyrazowy zosta� zaktualizowany.");
define("LWLAN_4", "Nie zdefiniowano jeszcze �adnych link�w wyrazowych.");
define("LWLAN_5", "Wyrazy");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktywny?");
define("LWLAN_8", "Opcje");
define("LWLAN_9", "Tak");
define("LWLAN_10", "Nie");
define("LWLAN_11", "Aktualne linki wyrazowe");
define("LWLAN_12", "Tak");
define("LWLAN_13", "Nie");
define("LWLAN_14", "Wy�lij link wyrazowy");
define("LWLAN_15", "Zaktualizuj link wyrazowy");
define("LWLAN_16", "Edytuj");
define("LWLAN_17", "Usu�");
define("LWLAN_18", "Czy na pewno usun�� wskazany link wyrazowy?");
define("LWLAN_19", "Link wyrazowy zosta� usuni�ty.");
define("LWLAN_20", "Nie mog� odnale�� wpisu linku wyrazowego.");
define("LWLAN_21", "Wyraz do automatycznego zlinkowania (lub lista wyraz�w oddzielonych przecinkami");
define("LWLAN_22", "Aktywowa�?");
define("LWLAN_23", "Zarz�dzanie linkami");
define("LWLAN_24", "Zarz�dzanie wyrazami");
define("LWLAN_25", "Opcje");
define("LWLAN_26", "Obszary, w kt�rych b�d� aktywne linki wyrazowe");
define("LWLAN_27", "To jest 'kontekst' wy�wietlanego tekstu");
define("LWLAN_28", "Strony, na kt�rych linki wyrazowe b�d� wy��czone");
define("LWLAN_29", "Identyczny format, jak przy ustawieniu widoczno�ci menu. Jedna pozycja w linii. Wymie� cz�ciowe lub kompletne adresy URL. Zako�cz je '!' dla precyzyjnego okre�lenia ko�ca linku.");
define("LWLAN_30", "Zapisz opcje");
define("LWLAN_31", "Dodaj/edytuj link wyrazowy");
define("LWLAN_32", "Opcje link�w wyrazowych");
define("LWLAN_33", 'Obszar tytu�u');
define("LWLAN_34", 'Streszczenie pozycj');
define("LWLAN_35", 'Tre�� pozycji');
define("LWLAN_36", 'Opis (linki etc)');
define("LWLAN_37", 'Dopuszczone obszary'); //Legacy areas
define("LWLAN_38", 'Klikalne linki');
define("LWLAN_39", 'Nieprzetworzony tekst'); //Unprocessed text
define("LWLAN_40", 'Tytu�y u�ytkownik�w (np. na forum)');
define("LWLAN_41", 'Tre�� u�ytkownik�w (np. na forum)');


define("LWLANINS_1", "Linki wyrazowe");
define("LWLANINS_2", "Plugin Linki wyrazowe ��czy �ci�le wyszczeg�lnione wyrazy ze zdefiniowanymi wcze�niej dla nich linkami.");
define("LWLANINS_3", "Konfiguracja link�w wyrazowych");
define("LWLANINS_4", "Aby skonfigurowa� ten plugin, prosz� klikn�� na link w sekcji plugin�w na g��wnej stronie administracyjnej.");

?>