<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_userclass2.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_userclass2.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("UCSLAN_1", "Usuni�to wszystkich u�ytkownik�w z grupy.");
define("UCSLAN_2", "Grupa u�ytkownik�w zosta�a zaktualizowana.");
define("UCSLAN_3", "Grupa zosta�a usuni�ta.");
define("UCSLAN_4", "Prosz� zaznaczy� pole w celu potwierdzenia usuni�cia wskazanej grupy u�ytkownik�w");
define("UCSLAN_5", "Grupa zosta�a zaktualizowana.");
define("UCSLAN_6", "Grupa zosta�a zapisana do bazy danych.");
define("UCSLAN_7", "Nie ma jeszcze grup u�ytkownik�w.");
define("UCSLAN_8", "Aktualne grupy");

// define("UCSLAN_9", "Edytuj");
// define("UCSLAN_10", "Usu�");
define("UCSLAN_11", "Zaznacz, aby potwierdzi� usuni�cie");
define("UCSLAN_12", "Nazwa grupy");
define("UCSLAN_13", "Opis grupy");
define("UCSLAN_14", "Aktualizuj grup� u�ytkownik�w");
define("UCSLAN_15", "Utw�rz now� grup�");
define("UCSLAN_16", "Przypisywanie u�ytkownik�w do grupy");
define("UCSLAN_17", "Usu�");
define("UCSLAN_18", "Wyczy�� grup�");
define("UCSLAN_19", "Przypisz u�ytkownik�w do grupy - ");
define("UCSLAN_20", ""); // class - zmiana szyku dotyczy: 
define("UCSLAN_21", "Ustawienia grup u�ytkownik�w");

define("UCSLAN_22", "U�ytkownicy - kliknij, aby przenie��...");
define("UCSLAN_23", "U�ytkownicy w tej grupie...");

define("UCSLAN_24", "Kto mo�e zarz�dza� grup�");

?>
