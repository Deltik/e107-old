<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.8 $
|     $Date: 2008/09/29 08:07:01 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_users_extended.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_users_extended.php rev. 1.22
+-----------------------------------------------------------------------------+
*/
 
define("EXTLAN_1", "Nazwa");
define("EXTLAN_2", "Podgl�d");
define("EXTLAN_3", "Warto��");
define("EXTLAN_4", "Wyma<br />gane");
define("EXTLAN_5", "Mog� stosowa�");
define("EXTLAN_6", "Wgl�d dost�pny dla");
define("EXTLAN_7", "Edycja dost�pna dla");
define("EXTLAN_8", "Akcja");
define("EXTLAN_9", "Dodatkowe pola user�w");

define("EXTLAN_10", "Nazwa pola");
define("EXTLAN_11", "Ta nazwa pola zostanie przypisana tabeli, musi wi�c si� r�ni� od pozosta�ych i nie mo�e by� u�ywane w g��wnej tabeli u�ytkownik�w."); // This is the name of the field as stored in the table, it must be unique from any other, and must not be used in the main user table
define("EXTLAN_12", "Wy�wietlana nazwa pola");
define("EXTLAN_13", "Ta nazwa pola b�dzie wy�wietlana na stronie");
define("EXTLAN_14", "Typ pola");
define("EXTLAN_15", "Zawarto�� pola");
define("EXTLAN_16", "Domy�lna warto��");
define("EXTLAN_17", "Wpisz wszystkie mo�liwe warto�ci w liniach <br /> Zobacz pomoc dla tabel BD.");
define("EXTLAN_18", "Wymagane");
define("EXTLAN_19", "U�ytkownicy b�d� zmuszeni do wpisania warto�ci w tym polu podczas aktualizacji swoich ustawie�.");
define("EXTLAN_20", "Okre�la, kt�rzy u�ytkownicy b�d� mieli dost�p do tego pola.");
define("EXTLAN_21", "Okre�la, kto zobaczy to pole w ustawieniach u�ytkownika.");
define("EXTLAN_22", "Okre�la, kto b�dzie m�g� zobaczy� t� warto�� na stronie u�ytkownik�w. <br />UWAGA: Ustawienie tego na 'Tylko do odczytu' spowoduje, �e b�dzie to tylko widoczne dla administrator�w oraz zarejestrowanych u�ytkownik�w.");
define("EXTLAN_23", "Dodaj dodatkowe pole");
define("EXTLAN_24", "Aktualizuj dodatkowe pole");
define("EXTLAN_25", "Przenie� na d�");
define("EXTLAN_26", "Przenie� do g�ry");
define("EXTLAN_27", "Potwierd� usuni�cie");
define("EXTLAN_28", "Aktualnie nie ma zdefiniowanych p�l");
define("EXTLAN_29", "Dodatkowe pola u�ytkownika zosta�o zapisane.");
define("EXTLAN_30", "Dodatkowe pole zosta�o usuni�te");
// define("EXTLAN_31", "Dodatkowe pole menu");
// define("EXTLAN_32", "Dodatkowa strona");
define("EXTLAN_33", "Anuluj edycj�");
define("EXTLAN_34", "Dodatkowe pola");
define("EXTLAN_35", "Kategorie");
define("EXTLAN_36", "Brak przypisanych kategorii");
define("EXTLAN_37", "Brak zdefiniowanych kategorii");
define("EXTLAN_38", "Nazwa kategorii");
define("EXTLAN_39", "Dodaj kategori�");
define("EXTLAN_40", "Kategoria zosta�a utworzona");
define("EXTLAN_41", "Kategoria zosta�a usuni�ta");
define("EXTLAN_42", "Aktualizuj kategori�");
define("EXTLAN_43", "Kategoria zosta�a zaktualizowana");
define("EXTLAN_44", "Kategoria");
define("EXTLAN_45", "Dodaj nowe pole");
define("EXTLAN_46", "Pomoc");
define("EXTLAN_47", "Dodaj nowy parametr");
define("EXTLAN_48", "Dodaj now� warto��");
define("EXTLAN_49", "Zezw�l u�ytkownikowi na ukrycie");
define("EXTLAN_50", "Ustawienie na tak, pozwoli u�ytkownikowi ukry� t� warto�� przed innymi u�ytkownikami (nie dotyczy administracji)");
define("EXTLAN_51", "Tu mo�esz wpisywa� wa�ne parametry zgodne ze standardem w3c<br />np. <b><i>class='tbox' size='40' maxlength='80'</i></b>");
define("EXTLAN_52", "Walidacja kodu wyra�e� regularnych");
define("EXTLAN_53", "Wprowad� kod wyra�e� regularnych, kt�ry b�dzie potrzebny do wykonania por�wnania poprawno�ci zapisu <br />**ograniczniki wyra�e� regularnych s� wymagane**");  // Enter the regex code that will need to be matched to make it a valid entry <br />**regex delimiters are required**");
define("EXTLAN_54", "Komunikat niepowodzenia wyra�e� regularnych");
define("EXTLAN_55", "Wpisz komunikat b��du, kt�ry b�dzie pokazywany, je�li walidacja wyra�e� regularnych zawiedzie.");
define("EXTLAN_56", "Wcze�niej zdefiniowane pola");
define("EXTLAN_57", "Aktywowane");
define("EXTLAN_58", "Nie aktywowane");
define("EXTLAN_59", "Aktywuj");
define("EXTLAN_60", "Dezaktywuj");
define("EXTLAN_61", "Brak");

define("EXTLAN_62", "Tabela");
define("EXTLAN_63", "Id pola");
define("EXTLAN_64", "Wy�wietl warto��");

define("EXTLAN_65", "Nie - Nie b�dzie wy�wietlana na stronie rejestracyjnej");
define("EXTLAN_66", "Tak - B�dzie wy�wietlana na stronie rejestracyjnej");
define("EXTLAN_67", "Nie - Wy�wietl na stronie rejestracyjnej");

define("EXTLAN_68", "Pole:");
define("EXTLAN_69", "zosta�o aktywowane");
define("EXTLAN_70", "B��D!! Pole:");
define("EXTLAN_71", "nie zosta�o aktywowane!");
define("EXTLAN_72", "zosta�o deaktywowane");
define("EXTLAN_73", "nie zosta�o deaktywowane!");
define("EXTLAN_74", "jest zarezerwowan� nazw� pola i nie mo�e by� urzyta.");
define("EXTLAN_75", "B��d dodawania pola do bazy danych.");
define("EXTLAN_76", "Niedozwolone znaki w nazwie pola - tylko znaki A-Z, a-z, 0-9, '_' s� dozwolone.");
define("EXTLAN_77", "Kategoria nie zosta�a usuni�ta - najpierw musisz usun�� elementy kategorii: ");
define('EXTLAN_78', 'Nie mog� znale�� pliku --FILE-- potrzebnego do utworzenia tabeli danych');

//textbox
define("EXTLAN_HELP_1", "<b><i>Parametry:</i></b><br />size - rozmiar pola<br />maxlength - maksymalna d�ugo�� pola<br /><br />class - klasa stylu css<br />style - string stylu css<br /><br />regex - walidacja kodu wyra�e� regularnych<br />regexfail - komunikat nieudanej walidacji"); // style - css style string
//radio buttons
define("EXTLAN_HELP_2", "Wprowad� tekst dla opcji w pole 'Warto��' - jedno pole na opcj�. Dodaj nowe pola je�li tego potrzebujesz.");
//dropdown
define("EXTLAN_HELP_3", "Wprowad� tekst dla opcji w pole 'Warto��' - jedno pole na opcj�. Dodaj nowe pola je�li tego potrzebujesz.");
//db field
define("EXTLAN_HELP_4", "<b><i>Warto�ci:</i></b><br />Tu powinny by� ZAWSZE trzy ustalone warto�ci:<br /><ol><li>tabela BD</li><li>pole zawieraj�ce znacznik id</li><li>pole zawieraj�ce warto��</li></ol><br />");
//textarea
define("EXTLAN_HELP_5", "Definiuje obszar dla pola tekstowego (Ustaw warto�� rozmiaru 'size' w polu 'Zawarto�� pola' je�li tego wymagasz).");
//integer
define("EXTLAN_HELP_6", "Umo�liwia u�ytkownikom wpisywanie warto�ci liczbowych.");
//date
define("EXTLAN_HELP_7", "Umo�liwia podanie daty przez u�ytkownika.");
// Language
define("EXTLAN_HELP_8", "Umo�liwia u�ytkownikowi wyb�w jednego z zainstalowanych j�zyk�w.");

?>
