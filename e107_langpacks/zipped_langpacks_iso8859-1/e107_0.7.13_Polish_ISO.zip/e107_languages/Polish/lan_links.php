<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/07/08 21:19:22 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_links.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_links.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Linki");

define("LAN_61", "Kategorie link�w");
define("LAN_62", "kategorii");
define("LAN_63", "kategoria");
define("LAN_64", "w tej kategorii");
define("LAN_65", "link");
define("LAN_66", "linki");
define("LAN_67", "Poka� wszystkie linki");
define("LAN_68", "Edytuj");
define("LAN_69", "Usu�");
define("LAN_86", "Kategoria:");
define("LAN_88", "Odwiedzin:");
define("LAN_89", "Administrator: ");
define("LAN_90", "Dodaj nowy link w tej kategorii");
define("LAN_91", "Dodaj now� kategori�");

define("LAN_92", "Wy�lij link");
define("LAN_93", "Po wys�aniu Tw�j link zostanie sprawdzony przez administratora i je�li b�dzie odpowiedni zostanie dodany do dzia�u link�w.");
define("LAN_94", "Nazwa:");
define("LAN_95", "Adres URL:");
define("LAN_96", "Opis:");
define("LAN_97", "Adres URL do buttona linku:");
define("LAN_98", "Wy�lij");

define("LAN_99", "Dzi�kujemy");
define("LAN_100", "Tw�j link zosta� zapisany i b�dzie sprawdzony przez administratora strony.");
define("LAN_101", "Prosz� klikn�� tutaj, aby wys�a� link");

define("LAN_102", "Tam");
define("LAN_103", "jest");
define("LAN_104", "s�");
define("LAN_105", "suma w");
define("LAN_106", "Podkre�lone pola s� wymagane.");

define("LAN_Links_1", "Wszystkich link�w");
define("LAN_Links_2", "Wszystkich aktywnych link�w");
define("LAN_LINKS_3", "Anonim");

?>
