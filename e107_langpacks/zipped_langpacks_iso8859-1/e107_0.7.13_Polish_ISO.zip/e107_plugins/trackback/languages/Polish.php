<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/25 19:18:04 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/trackback/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/trackback/languages/English.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("TRACKBACK_L1", "Konfiguracja powi�za�");
define("TRACKBACK_L2", "Wtyczka pozwoli Ci na u�ywanie powi�za� pomi�dzy Twoimi aktualno�ciami."); // This plugin enables you to use trackback in your news posts.
define("TRACKBACK_L3", "Trackback jest zainstalowany i gotowy do u�ytku.");
define("TRACKBACK_L4", "Ustawienia powi�za� zosta�y zapisane.");
define("TRACKBACK_L5", "W��czone");
define("TRACKBACK_L6", "Wy��czone");
define("TRACKBACK_L7", "Aktywuj powi�zania");
define("TRACKBACK_L8", "Tre�� adresu URL powi�zania");
define("TRACKBACK_L9", "Zapisz ustawienia");
define("TRACKBACK_L10", "Ustawienia powi�za�");
define("TRACKBACK_L11", "Powi�zania dla tej pozycji:");

define("TRACKBACK_L12", "Nie ma jeszcze powi�za� dla tej pozycji");
define("TRACKBACK_L13", "Moderuj powi�zania");
define("TRACKBACK_L14", "Usu�");
define("TRACKBACK_L15", "Powi�zania zosta�y usuni�te.");

?>
