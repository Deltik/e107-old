<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.6 $
|     $Date: 2008/09/29 08:07:01 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/newsletter/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/newsletter/languages/English.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("NLLAN_MENU_CAPTION", "Newsletter");

define("NLLAN_01", "Newsletter");
define("NLLAN_02", "Pozwala w prosty i szybki spos�b tworzy� i wysy�a� e-biuletyny, newslettery itp.");
define("NLLAN_03", "Konfiguruj Newsletter");
define("NLLAN_04", "Plugin Newsletter zosta� pomy�lnie zainstalowany. Aby go skonfigurowa� powr�� do 'Panelu Administratora' i kliknij w sekcji plugin�w na 'Newsletter'");
define("NLLAN_05", "Nie ma jeszcze nesletter�w");
define("NLLAN_06", "Nazwa");
define("NLLAN_07", "Prenumerator�w");
define("NLLAN_08", "Opcje");
define("NLLAN_09", "Czy na pewno usun�� ten newsletter?");
define("NLLAN_10", "Aktualne newslettery");

define("NLLAN_11", "Nie ma jeszcze wyda� newslettera");
define("NLLAN_12", "Wydanie");
define("NLLAN_13", "[ Nadrz�dne ID ] Temat/Tytu�");
define("NLLAN_14", "Rozes�ane?");
define("NLLAN_15", "Opcje");
define("NLLAN_16", "Tak");
define("NLLAN_17", "Nie rozes�ane - aby wys�a� kliknij");
define("NLLAN_18", "Czy na pewno chcesz wys�a� to wydanie newslettera do subskrybent�w?");
define("NLLAN_19", "Czy na pewno chcesz usun�� to wydanie newslettera?");
define("NLLAN_20", "Aktualne wydania");
define("NLLAN_21", "Tytu�");
define("NLLAN_22", "Opis");
define("NLLAN_23", "Nag��wek");
define("NLLAN_24", "Stopka");
define("NLLAN_25", "Zaktualizuj newsletter");
define("NLLAN_26", "Utw�rz newsletter");
define("NLLAN_27", "Newsletter zosta� zaktualizowany w bazie danych.");
define("NLLAN_28", "Newsletter zosta� zdefiniowany i zapisany w bazie danych.");
define("NLLAN_29", "Nie zdefiniowano jeszcze newsletter�w.");
define("NLLAN_30", "Newsletter");
define("NLLAN_31", "Temat / Tytu�");
define("NLLAN_32", "Numer wydania");
define("NLLAN_33", "Tre��");
define("NLLAN_34", "Aktualizuj");
define("NLLAN_35", "Utw�rz wydanie");
define("NLLAN_36", "Aktualizacja wydania newslettera");
define("NLLAN_37", "Utw�rz wydanie newslettera");
define("NLLAN_38", "Newsletter zosta� zaktualizowany w bazie danych.");
define("NLLAN_39", "Wydanie newslettera zosta�o zapisane w bazie danych - aby je rozes�a�, kliknij w odpowiedni przycisk w tabeli 'Aktualne wydania'.");
define("NLLAN_40", "Rozsy�anie zako�czone - wydanie wys�ane do ");

define("NLLAN_41", " prenumerator�w.");
define("NLLAN_42", "Newsletter zosta� usuni�ty.");
define("NLLAN_43", "Wydanie newslettera zosta�o usuni�te."); // Newsletter issue deleted

define("NLLAN_44", "Newsletter - strona g��wna");
define("NLLAN_45", "Utw�rz newsletter");
define("NLLAN_46", "Utw�rz wydania newslettera");
define("NLLAN_47", "Opcje newslettera");

define("NLLAN_48", "jeste� prenumeratorem tego newslettera - je�li chcesz si� wypisa� prosz� klikn�� w poni�szy przycisk");  // you are subscribed to this newsletter - if you wish to un-subscribe please click the button below.1
define("NLLAN_49", "Czy na pewno chcesz si� wypisa� ze wskazanego newslettera?");
define("NLLAN_50", "Aby si� zapisa� kliknij w poni�szy przycisk (adres na kt�ry b�dzie wysy�any newsletter to");
define("NLLAN_51", "Wypisz mnie");
define("NLLAN_52", "Zapisz mnie");
define("NLLAN_53", "Czy na pewno chcesz si� zapisa� do tego newslettera?");

define("NLLAN_54", "Wys�ano"); // sprawdzi� czy na pewno tak :) 

define("NLLAN_55", "ID");
define("NLLAN_56", "Numer ID newslettera niedost�pny"); // WYMAGA WERYFIKACJI Newsletter ID not available 
define("NLLAN_57", "Powr�� na poprzedni� stron�");
define("NLLAN_58", "B��d");
define("NLLAN_59", "Nazwa");
define("NLLAN_60", "E-mail");
define("NLLAN_61", "Zadanie");
define("NLLAN_62", "U�ytkownik jest zbanowany! (lub nie w pe�ni zarejestrowany)");
define("NLLAN_63", "Wszystkich subskrybent�w");
define("NLLAN_64", "Powr�� do strony g��wnej newslettera");
define("NLLAN_65", "Przegl�d numer�w ID subskrybent�w newslettera"); // WYMAGA WERYFIKACJI Subscribers overview newsletter ID

?>
