<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2007/02/18 20:20:20 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/gsitemap/languages/gsitemap_Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/gsitemap/languages/gsitemap_English.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("GSLAN_Name", "Mapa strony");
define("GSLAN_1", "Linki strony");
define("GSLAN_2", "Import");
define("GSLAN_3", "Rodzaj");
define("GSLAN_4", "Nazwa");
define("GSLAN_5", "Adres URL");
define("GSLAN_6", "Odznacz linki, aby wyznaczy� je do importu...");
define("GSLAN_7", "Importowanie link�w");
define("GSLAN_8", "Preferencje importu:");
define("GSLAN_9", "Priorytet");
define("GSLAN_10", "Cz�stotliwo��");
define("GSLAN_11", "ca�y czas");
define("GSLAN_12", "cogodzinna");
define("GSLAN_13", "codzienna");
define("GSLAN_14", "cotygodniowa");
define("GSLAN_15", "comiesi�czna");
define("GSLAN_16", "coroczna");
define("GSLAN_17", "nigdy");
define("GSLAN_18", "Importuj zaznaczone linki");
define("GSLAN_19", "Google Sitemap");
define("GSLAN_20", "Lista");
define("GSLAN_21", "Wprowadzenie");
define("GSLAN_22", "Dodaj nowy wpis");
define("GSLAN_23", "Import");
define("GSLAN_24", "Wpisy Google Sitemap");
define("GSLAN_25", "Nazwa");
define("GSLAN_26", "Adres URL");
define("GSLAN_27", "Ostatnia modyfikacja");
define("GSLAN_28", "Cz�s.");
define("GSLAN_29", "Konfiguracja Google Sitemap");
define("GSLAN_30", "Kolejno�� wy�wietlania");
define("GSLAN_31", "Widoczne dla");
define("GSLAN_32", "Jak u�ywa� Google Sitemap");
define("GSLAN_33", "GSiteMap Wprowadzenie");
define("GSLAN_34", "Najpierw utw�rz linki, kt�re b�dziesz chcia� doda� do swojej mapy strony. Mo�esz importowa� cz�� link�w poprzez klikni�cie na przycisk 'Import' znajduj�cy si� po prawej stronie.");
define("GSLAN_35", "Je�li wolisz importowa� linki, kliknij w 'Import' i zaznacz linki, kt�re chcesz zaimportowa�.");
define("GSLAN_36", "Mo�esz r�wnie� wprowadzi� poszczeg�lne linki r�cznie poprzez klikni�cie na przycisk 'Dodaj nowy wpis'.");
define("GSLAN_37", "Gdy ju� b�dziesz mia� jakie� wpisy, przejd� do <a href='https://www.google.com/webmasters/sitemaps/stats'>https://www.google.com/webmasters/sitemaps/stats</a> i wprowad� nast�puj�cy adres URL -> <b>".SITEURL."gsitemap.php</b> - je�li ten adres URL nie wygl�da poprawnie, prosz� si� upewni�, �e na stronie Panel admina -> Preferencje adres serwisu jest poprawnie wprowadzony.");
define("GSLAN_38", "Aby uzyska� wi�cej informacji na temat protoko�u Google Sitemap, przejd� do <a href='http://www.google.com/webmasters/sitemaps/docs/en/protocol.html'>http://www.google.com/webmasters/sitemaps/docs/en/protocol.html</a>.");
define("GSLAN_39", "Obecnie nie ma link�w w mapie strony - importowa� linki?");
define("GSLAN_40", "Wpisy Google Sitemap");

?>
