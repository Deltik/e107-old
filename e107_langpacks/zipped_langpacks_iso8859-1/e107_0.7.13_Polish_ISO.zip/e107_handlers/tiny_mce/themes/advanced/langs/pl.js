/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2007/02/19 16:57:59 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/themes/advanced/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/themes/advanced/langs/en.php rev. 1.8
+-----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
theme_style_select : 'Styl',
theme_code_desc : 'Edytuj �r�d�o html',
theme_code_title : 'Edytor �r�d�a html',
theme_code_wordwrap : 'Zawijanie wierszy',
theme_sub_desc : 'Nadpisywanie',
theme_sup_desc : 'Podpisywanie',
theme_hr_desc : 'Wstaw poziom� lini�',
theme_removeformat_desc : 'Usu� formatowanie',
theme_custom1_desc : 'Wstaw w�asny opis',
insert_image_border : 'Ramka',
insert_image_dimensions : 'Wymiary',
insert_image_vspace : 'Pionowy odst�p',
insert_image_hspace : 'Poziomy odst�p',
insert_image_align : 'Otaczanie',
insert_image_align_default : 'Domy�lne',
insert_image_align_baseline : 'Do linii bazowej',
insert_image_align_top : 'G�rne',
insert_image_align_middle : '�rodkowe',
insert_image_align_bottom : 'Dolne',
insert_image_align_texttop : 'Tekst powy�ej',
insert_image_align_absmiddle : 'Absolutny �rodek',
insert_image_align_absbottom : 'Absolutny d�',
insert_image_align_left : 'Lewe',
insert_image_align_right : 'Prawe',
theme_font_size : '-- Rozmiar czcionki --',
theme_fontdefault : '-- Rodzina czcionki --',
theme_block : '-- Format --',
theme_paragraph : 'Paragraf',
theme_div : 'Div',
theme_address : 'Adres',
theme_pre : 'Preformatowanie',
theme_h1 : 'Nag��wek 1',
theme_h2 : 'Nag��wek 2',
theme_h3 : 'Nag��wek 3',
theme_h4 : 'Nag��wek 4',
theme_h5 : 'Nag��wek 5',
theme_h6 : 'Nag��wek 6',
theme_blockquote : 'Cytat',
theme_code : 'Kod',
theme_samp : 'Przyk�adowy kod',
theme_dt : 'Termin definicji ',
theme_dd : 'Opis definicji',
theme_colorpicker_title : 'Wybierz kolor',
theme_colorpicker_apply : 'Wybierz',
theme_forecolor_desc : 'Wybierz kolor tekstu',
theme_backcolor_desc : 'Wybierz kolor t�a',
theme_charmap_title : 'Wybierz znak',
theme_charmap_desc : 'Wstaw znak',
theme_visualaid_desc : 'Prze��cz linie prowadz�ce/niewidoczne elementy',
insert_anchor_title : 'Kotwica',
insert_anchor_name : 'Nazwa kotwicy',
theme_anchor_desc : 'Wstaw/Edytuj kotwic�',
theme_insert_link_titlefield : 'Tytu�',
theme_clipboard_msg : 'Kopiuj/Edytuj/Wklej nie jest dost�pne w przegl�darkach Mozilla i Firefox.\nPotrzebujesz wi�cej informacji na ten temat?',
theme_path : '�cie�ka',
cut_desc : 'Wytnij',
copy_desc : 'Kopiuj',
paste_desc : 'Wklej',
link_list : 'Lista link�w',
image_list : 'Lista obrazk�w',
browse : 'Przegl�daj',
image_props_desc : 'W�a�ciwo�ci obrazka',
newdocument_desc : 'Nowy dokument',
class_name : 'Klasa',
newdocument : 'Czy jeste� pewien, �e chcesz wyczy�ci� zawarto�� tego dokumentu?',
about_title : 'O TinyMCE...',
about : 'O ...',
license : 'Licencja',
plugins : 'Pluginy',
plugin : 'Plugin',
author : 'Autor',
version : 'Wersja',
loaded_plugins : 'Za�adowane pluginy',
help : 'Pomoc',
not_set : '-- Nie wybrano --',
close : 'Zamknij',
toolbar_focus : 'Skocz do przycisk�w narz�dzi - Alt+Q, Skocz do edytora - Alt-Z, Skocz do �cie�ki elementu - Alt-X',
invalid_data : 'B��d: Wprowadzono niepoprawne warto�ci - oznaczone s� na czerwono.'
});
