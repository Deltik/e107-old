<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_email.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/28 13:47:33 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "E-post");

define("LAN_5", "E-posta artikel till en v&auml;n");
define("LAN_6", "E-posta nyhet till en v&auml;n");
define("LAN_7", "Login Namn: ");
define("LAN_8", "Kommentar");
define("LAN_9", "Tyv&auml;rr - kunde inte skicka e-post");
define("LAN_10", "Brev s&auml;nt till");
define("LAN_11", "Brev skickat");
define("LAN_12", "Fel");
define("LAN_106", "Det ser inte ut som en giltig e-postadress");
define("LAN_185", "Skicka artikel");
define("LAN_186", "Skicka nyhet");
define("LAN_187", "E-postadress att skicka till");
define("LAN_188", "Jag t&auml;nkte att du kunde vara intresserad av denna nyhet fr&aring;n");
define("LAN_189", "Jag t&auml;nkte att du kunde vara intresserad av denna artikel fr&aring;n");

define("LAN_email_1", "Fr&aring;n:");
define("LAN_email_2", "Avs&auml;ndarens IP-adress:");
define("LAN_email_3", "E-postat &auml;mne fr&aring;n ");
define("LAN_email_4", "Skicka e-post");
define("LAN_email_5", "E-posta &auml;mne till en v&auml;n");
define("LAN_email_6", "Jag t&auml;nkte att du kunde vara intresserad av detta &auml;mne fr&aring;n");

?>
