<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_upload_handler.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Filtypen");
define("LANUPLOAD_2", "&auml;r inte till&aring;ten och har raderats.");
define("LANUPLOAD_3", "Uppladdningen lyckades");
define("LANUPLOAD_4", "Antingen finns inte mottagande folder, eller s&aring; &auml;r den inte skrivbar.");
define("LANUPLOAD_5", "Den uppladdade filen &ouml;verskrider upload_max_filesize direktivet i php.ini.");
define("LANUPLOAD_6", "Den uppladdade filen &ouml;verskrider MAX_FILE_SIZE direktivet som specficerats i html-formul&auml;ret.");
define("LANUPLOAD_7", "Filen blev bara delvis uppladdad.");
define("LANUPLOAD_8", "Ingen fil laddades upp.");
define("LANUPLOAD_9", "Uppladdad filstorlek 0 bytes");
define("LANUPLOAD_10", "Uppladdning misslyckades [Dubblerat filnamn] - En fil med samma namn finns redan.");
define("LANUPLOAD_11", "Filen laddades inte upp. Filnamn: ");
define("LANUPLOAD_12", "Fel");

?>
