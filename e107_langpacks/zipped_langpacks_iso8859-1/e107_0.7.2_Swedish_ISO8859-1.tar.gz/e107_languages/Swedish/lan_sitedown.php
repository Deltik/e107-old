<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_sitedown.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sajten tillf&auml;lligt st&auml;ngd");
define("LAN_00", "&auml;r tillf&auml;lligt st&auml;ngd");
define("LAN_01", "Vi har tillf&auml;lligt st&auml;ngt sajten f&ouml;r n&ouml;dv&auml;ndigt underh&aring;ll. Det b&ouml;r inte ta s&aring; l&aring;ng tid, kika tillbaka lite senare. Vi ber om urs&auml;kt f&ouml;r ditt besv&auml;r.");

?>
