<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_sitedown.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sajten tillf&auml;lligt st&auml;ngd");
define("LAN_00", "&auml;r tillf&auml;lligt st&auml;ngd");
define("LAN_01", "Vi har tillf&auml;lligt st&auml;ngt sajten f&ouml;r n&ouml;dv&auml;ndigt underh&aring;ll. Det b&ouml;r inte ta s&aring; l&aring;ng tid, kika tillbaka lite senare. Vi ber om urs&auml;kt f&ouml;r ditt besv&auml;r.");

?>
