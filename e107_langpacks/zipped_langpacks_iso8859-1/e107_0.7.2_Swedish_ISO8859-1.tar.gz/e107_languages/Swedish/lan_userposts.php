<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_userposts.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Anv&auml;ndarinl&auml;gg");

define("UP_LAN_0", "Alla foruminl&auml;gg fr&aring;n ");
define("UP_LAN_1", "Alla kommentarer fr&aring;n ");
define("UP_LAN_2", "Tr&aring;d");
define("UP_LAN_3", "Visningar");
define("UP_LAN_4", "Svar");
define("UP_LAN_5", "Senaste inl&auml;gg");
define("UP_LAN_6", "Tr&aring;dar");
define("UP_LAN_7", "Inga kommentarer");
define("UP_LAN_8", "Inga inl&auml;gg");
define("UP_LAN_9", " den ");
define("UP_LAN_10", "Ang");
define("UP_LAN_11", "Postat den");
define("UP_LAN_12", "S&ouml;k");
define("UP_LAN_13", "Kommentarer");
define("UP_LAN_14", "Foruminl&auml;gg");
define("UP_LAN_15", "Ang");
define("UP_LAN_16", "IP-adress");

?>
