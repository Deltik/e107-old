<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_user_extended.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Textruta");
define("UE_LAN_2", "Radioknappar");
define("UE_LAN_3", "Rullgardinsmeny");
define("UE_LAN_4", "DB-tabellf&auml;lt");
define("UE_LAN_5", "Textarea");
define("UE_LAN_6", "Heltal");
define("UE_LAN_7", "Datum");
define("UE_LAN_8", "Spr&aring;k");

define("UE_LAN_9", "Namn");
define("UE_LAN_10", "Typ");
define("UE_LAN_11", "Anv&auml;nd");

define("UE_LAN_HIDE", "D&ouml;lj fr&aring;n anv&auml;ndare");

define("UE_LAN_LOCATION", "Plats");
define("UE_LAN_LOCATION_DESC", "Anv&auml;ndarens ort");
define("UE_LAN_AIM", "AIM adress");
define("UE_LAN_AIM_DESC", "AIM adress");
define("UE_LAN_ICQ", "ICQ nummer");
define("UE_LAN_ICQ_DESC", "ICQ nummer");
define("UE_LAN_YAHOO", "Yahoo! adress");
define("UE_LAN_YAHOO_DESC", "Yahoo! adress");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN adress");
define("UE_LAN_HOMEPAGE", "Hemsida");
define("UE_LAN_HOMEPAGE_DESC", "URL till anv&auml;ndarens hemsida");
define("UE_LAN_BIRTHDAY", "F&ouml;delsedag");
define("UE_LAN_BIRTHDAY_DESC", "F&ouml;delsedag");

?>
