<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Endast medlemmar");

define("LAN_MEMBERS_0", "begr&auml;nsad area");
define("LAN_MEMBERS_1", "Detta &auml;r en begr&auml;nsad area");
define("LAN_MEMBERS_2", "F&ouml;r tillg&aring;ng till den, &lt;a href='login.php'&gt;logga in&lt;/a&gt;");
define("LAN_MEMBERS_3", "eller &lt;a href='".e_SIGNUP."'&gt;registrera&lt;/a&gt; dig som medlem");
define("LAN_MEMBERS_4", "Klicka h&auml;r f&ouml;r &aring;terg&aring;ng till f&ouml;rstasidan");

?>