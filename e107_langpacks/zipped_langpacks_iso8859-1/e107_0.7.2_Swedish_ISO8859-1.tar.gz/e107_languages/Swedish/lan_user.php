<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_user.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Medlemmar");

define("LAN_20", "Fel");
define("LAN_112", "E-postadress");
define("LAN_115", "ICQ-nummer");
define("LAN_116", "AIM adress");
define("LAN_117", "MSN Messenger");
define("LAN_118", "F&ouml;delsedag");
define("LAN_119", "Plats");
define("LAN_120", "Signatur");
define("LAN_137", "Det finns ingen information p&aring; den anv&auml;ndaren eftersom den inte &auml;r registrerad p&aring;");
define("LAN_138", "Registrerade medlemmar: ");
define("LAN_139", "Ordning: ");
define("LAN_140", "Registrerade medlemmar");
define("LAN_141", "Inga registrerade medlemmar &auml;nnu.");
define("LAN_142", "Medlem");
define("LAN_143", "[dold p&aring; beg&auml;ran]");
define("LAN_144", "Webbsajt URL");
define("LAN_145", "Medlem sedan");
define("LAN_146", "Bes&ouml;k h&auml;r sedan registrering");
define("LAN_147", "Chattruta inl&auml;gg");
define("LAN_148", "Antal kommentarer");
define("LAN_149", "Foruminl&auml;gg");
define("LAN_308", "Riktigt namn");
define("LAN_400", "Det &auml;r ingen giltig anv&auml;ndare.");
define("LAN_401", "ingen information");
define("LAN_402", "Medlemsprofil");
define("LAN_403", "Sajtstatistik");
define("LAN_404", "Senaste bes&ouml;k");
define("LAN_405", "dagar sedan");
define("LAN_406", "Niv&aring;");
define("LAN_407", "ingen");
define("LAN_408", "inget foto");
define("LAN_409", "po&auml;ng");
define("LAN_410", "Diverse");
define("LAN_411", "Klicka h&auml;r f&ouml;r att uppdatera din information");
define("LAN_412", "Klicka h&auml;r f&ouml;r att redigera denna anv&auml;ndares information");
define("LAN_413", "radera foto");
define("LAN_414", "f&ouml;reg&aring;ende medlem");
define("LAN_415", "n&auml;sta medlem");
define("LAN_416", "Du m&aring;ste vara inloggad f&ouml;r att anv&auml;nda denna sidan");
define("LAN_417", "Sajtens huvudadministrat&ouml;r");
define("LAN_418", "Sajtadministrat&ouml;r");
define("LAN_419", "Visa");
define("LAN_420", "Fall.");
define("LAN_421", "Stig.");
define("LAN_422", "K&ouml;r");
define("LAN_423", "Klicka h&auml;r f&ouml;r att se anv&auml;ndarkommentarer");
define("LAN_424", "Klicka h&auml;r f&ouml;r att se foruminl&auml;gg");
define("LAN_425", "S&auml;nd privat meddelande");
define("LAN_426", "sedan");

define("USERLAN_1", "Peer niv&aring;");

?>
