<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("US_LAN_1", "V&auml;lj anv&auml;ndare");
define("US_LAN_2", "V&auml;lj anv&auml;ndarklass");
define("US_LAN_3", "Alla anv&auml;ndare");
define("US_LAN_4", "S&ouml;k anv&auml;ndarnamn");
define("US_LAN_5", "Anv&auml;ndare hittades");
define("US_LAN_6", "S&ouml;ks");

?>