<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_newspost.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Nyhet raderad.");
define("NWSLAN_2", "Markera rutan f&ouml;r att bekr&auml;fta borttagning av denna nyhet.");
define("NWSLAN_3", "Inga nyheter &auml;nnu.");
define("NWSLAN_4", "Befintliga nyheter");
define("NWSLAN_5", "&Ouml;ppna HTML-redigerare");
define("NWSLAN_6", "Kategori");
define("NWSLAN_7", "Redigera");
define("NWSLAN_8", "Radera");
define("NWSLAN_9", "markera f&ouml;r att bekr&auml;fta");
define("NWSLAN_10", "Inga kategorier satta &auml;nnu.");
define("NWSLAN_11", "L&auml;gg till/Redigera kategorier");
define("NWSLAN_12", "Rubrik");
define("NWSLAN_13", "Text");
define("NWSLAN_14", "Ut&ouml;kad");
define("NWSLAN_15", "Kommentarer");
define("NWSLAN_16", "Aktiv");
define("NWSLAN_17", "Inaktiv");
define("NWSLAN_18", "Till&aring;t kommentarer att postas till denna nyhet");
define("NWSLAN_19", "Aktivering");
define("NWSLAN_20", "L&auml;mna tomt f&ouml;r att inte anv&auml;nda auto-aktivering");
define("NWSLAN_21", "Aktiv mellan");
define("NWSLAN_22", "Synbarhet");
define("NWSLAN_23", "Markering g&ouml;r nyheten synlig enbart f&ouml;r anv&auml;ndare i den klassen");
define("NWSLAN_24", "F&ouml;rhandsgranska igen");
define("NWSLAN_25", "Uppdatera nyhet i databasen");
define("NWSLAN_26", "Posta nyhet till databasen");
define("NWSLAN_27", "F&ouml;rhandsgranska");
define("NWSLAN_28", "Ny nyhet");
define("NWSLAN_29", "Nyhetspost");

define("NWSLAN_30", "Visa enbart rubrik");

?>
