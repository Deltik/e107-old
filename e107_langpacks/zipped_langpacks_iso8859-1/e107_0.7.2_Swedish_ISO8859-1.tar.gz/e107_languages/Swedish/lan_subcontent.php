<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_subcontent.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "Tack, din artikel har sparats och kommer att granskas av en sajtadministrat&ouml;r snarast.");
define("ARLAN_1", "F&auml;lt l&auml;mnade tomma.");
define("ARLAN_2", "Tack, din recension har sparats och kommer att granskas av en sajtadministrat&ouml;r snarast..");
define("ARLAN_15", "Skicka in artikel");
define("ARLAN_17", "Rubrik");
define("ARLAN_18", "Underrubrik");
define("ARLAN_19", "Summering");
define("ARLAN_20", "Artikel");
define("ARLAN_21", "Till&aring;t kommentarer?");
define("ARLAN_22", "P&aring;");
define("ARLAN_23", "Av");
define("ARLAN_24", "L&auml;gg till e-post/utskrift ikoner?");
define("ARLAN_25", "Ja");
define("ARLAN_26", "Nej");
define("ARLAN_27", "Skicka in artikel");
define("ARLAN_28", "F&ouml;rhandsgranska");
define("ARLAN_55", "Synlig f&ouml;r");
define("ARLAN_73", "&Ouml;ppna HTML-redigerare");
define("ARLAN_74", "Kategori");
define("ARLAN_75", "Ingen");
define("ARLAN_82", "F&ouml;rfattardetaljer");
define("ARLAN_84", "f&ouml;rfattarens namn");
define("ARLAN_85", "f&ouml;rfattarens e-postadress");
define("ARLAN_86", "Recension");
define("ARLAN_87", "Betyg");
define("ARLAN_88", "V&auml;lj betyg");
define("ARLAN_89", "Skicka in recension");

define("ARLAN_90", "F&auml;lt l&auml;mnade tomma, klicka p&aring; din webbl&auml;sares bak&aring;t-knapp och se till att alla f&auml;lt &auml;r ifyllda.");
define("ARLAN_91", "Granska igen");
define("ARLAN_92", "Ange ditt namn/e-postadress");


define("ARLAN_93", "artikel");
define("ARLAN_94", "recension");
define("ARLAN_95", "Ins&auml;ndning av artiklar fr&aring;n anv&auml;ndare &auml;r avst&auml;ngd just nu");
define("ARLAN_96", "Ins&auml;ndning av recensioner fr&aring;n anv&auml;ndare &auml;r avst&auml;ngd just nu");
define("ARLAN_97", "Du har inte tillr&auml;ckliga beh&ouml;righeter att skicka in artiklar");
define("ARLAN_98", "Du har inte tillr&auml;ckliga beh&ouml;righeter att skicka in recensioner");


define("ARLAN_99", "Vad vill du s&auml;nda in?");
define("ARLAN_100", "Nyhet");
define("ARLAN_101", " H&auml;ndelse");
define("ARLAN_102", "Artikel");
define("ARLAN_103", "Recension");
define("ARLAN_104", "L&auml;nk");
define("ARLAN_105", "Fil");
define("ARLAN_106", "Skicka in");

?>
