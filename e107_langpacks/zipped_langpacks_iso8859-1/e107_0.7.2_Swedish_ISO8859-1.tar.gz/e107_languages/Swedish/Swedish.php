<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'sv_SE', 'swedish', 'sve_sv');
define("CORE_LC", 'sv');
define("CORE_LC2", 'se');
define("CHARSET", "iso8859-1");  // F&ouml;r en &auml;kta flerspr&aring;kig sajt. :)
define("CORE_LAN1","Fel: Tema saknas.\\n\\nByt det anv&auml;nda temat i dina preferenser (admin area) eller ladda upp filerna f&ouml;r det aktuella temat till din server.");

//v.616
define("CORE_LAN2","Skrev \\1:");// "\\1" representerar anv&auml;ndarnamnet.
define("CORE_LAN3","filbilaga avaktiverad");

?>
