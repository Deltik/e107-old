<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/26 11:12:22 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Anv&auml;ndarregistrering");

define("NT_LAN_UV_1", "Anv&auml;ndarregistrering verifierad");
define("NT_LAN_UV_2", "Anv&auml;ndares sessionsstr&auml;ng");

define("NT_LAN_LI_1", "Anv&auml;ndare loggade in");

define("NT_LAN_LO_1", "Anv&auml;ndare loggade ut");
define("NT_LAN_LO_2", " utloggad fr&aring;n sajten");

define("NT_LAN_FL_1", "Fl&ouml;dningssp&auml;rrad");
define("NT_LAN_FL_2", "IP-adress sp&auml;rrad p.g.a. fl&ouml;dning");

define("NT_LAN_SN_1", "Nyhets&auml;mne postat");

define("NT_LAN_NU_1", "Uppdaterad");

define("NT_LAN_ND_1", "Nyhets&auml;mne raderat");
define("NT_LAN_ND_2", "Raderat nyhets&auml;mnes ID");

?>
