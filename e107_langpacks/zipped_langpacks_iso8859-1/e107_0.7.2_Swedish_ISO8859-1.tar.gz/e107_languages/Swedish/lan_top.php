<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_top.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Toppostare i forum");
define("TOP_LAN_1", "Anv&auml;ndarnamn");
define("TOP_LAN_2", "Inl&auml;gg");
define("TOP_LAN_3", "Toppostare, kommentarer");
define("TOP_LAN_4", "Kommentarer");
define("TOP_LAN_5", "Toppostare, chattruta");
define("TOP_LAN_6", "Sajtbetyg");

//v.616
define("LAN_1", "Tr&aring;d");
define("LAN_2", "Postare");
define("LAN_3", "Visningar");
define("LAN_4", "Svar");
define("LAN_5", "Senaste post");
define("LAN_6", "Tr&aring;dar");
define("LAN_7", "Mest aktiva tr&aring;dar");
define("LAN_8", "Toppostare");

?>
