<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_upload.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Ladda upp");

define("LAN_20", "Fel");
define("LAN_61", "Ditt namn: ");
define("LAN_112", "E-postadress: ");
define("LAN_144", "Webbsajt URL: ");
define("LAN_402", "Du m&aring;ste vara registrerad medlem f&ouml;r att ladda upp filer till denna server.");
define("LAN_403", "Du har inte r&auml;ttigheter att ladda upp filer till denna server.");
define("LAN_404", "Tack. Din uppladdning kommer att granskas av en sajtadministrat&ouml;r och postas till sajten om den anses l&auml;mplig.");
define("LAN_405", "Filen &ouml;verskrider maximalt till&aring;ten storlek - raderad.");
define("LAN_406", "Observera");
define("LAN_407", "Alla andra filtyper som laddas upp kommer att raderas omedelbart.");
define("LAN_408", "Understruken");
define("LAN_409", "Filnamn");
define("LAN_410", "Version");
define("LAN_411", "Fil");
define("LAN_412", "Sk&auml;rmbild");
define("LAN_413", "Beskrivning");
define("LAN_414", "Fungerande demo");
define("LAN_415", "ange URL till en sajt d&auml;r en demo visas");
define("LAN_416", "Bekr&auml;fta och ladda upp");
define("LAN_417", "Ladda upp fil");
define("LAN_418", "Maximal filstorlek: ");
define("DOWLAN_11", "Kategori");
define("LAN_419", "Till&aring;tna filtyper");
define("LAN_420", "f&auml;lt &auml;r n&ouml;dv&auml;ndiga");

?>
