<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_submitnews.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Skicka in nyhet");
define("LAN_7", "Inloggningsnamn: ");
define("LAN_62", "&Auml;mne: ");
define("LAN_112", "E-postadress: ");
define("LAN_133", "Tack");
define("LAN_134", "Din ins&auml;ndare har skickats in och kommer att granskas av en sajtadministrat&ouml;r snarast.");
define("LAN_135", "Nyhet: ");
define("LAN_136", "Skicka in nyhet");
define("NWSLAN_6", "Kategori");
define("NWSLAN_10", "Inga nyhetskategorier");
define("NWSLAN_11", "Du har inte tillg&aring;ng till denna area.");
define("NWSLAN_12", "Tillg&aring;ng nekad.");

define("SUBNEWSLAN_1", "Du m&aring;ste ange en rubrik.\\n");
define("SUBNEWSLAN_2", "Du m&aring;ste inkludera en text i en nyhet.\\n");
define("SUBNEWSLAN_3", "Din bilaga m&aring;ste vara antingen en jpg, gif eller png fil");
define("SUBNEWSLAN_4", "Filen f&ouml;r stor");
define("SUBNEWSLAN_5", "Bildfil");
define("SUBNEWSLAN_6", "(jpg, gif eller png)");

?>
