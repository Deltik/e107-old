<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_mail_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Producerad av e107 webbsajtsystem");
define("LANMAILH_2", "Detta &auml;r ett fler-delat meddelande i MIME format.");
define("LANMAILH_3", " &auml;r inte korrekt formaterat");
define("LANMAILH_4", "Servern f&ouml;rkastade adressen");
define("LANMAILH_5", "Ingen respons fr&aring;n servern");
define("LANMAILH_6", "Kan inte hitta e-postservern.");
define("LANMAILH_7", " verkar giltig.");

?>
