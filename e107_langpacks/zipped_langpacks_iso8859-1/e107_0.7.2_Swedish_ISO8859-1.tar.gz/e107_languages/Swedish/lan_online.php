<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_online.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "G&auml;ster: ");
define("ONLINE_EL2", "Medlemmar: ");
define("ONLINE_EL3", "P&aring; denna sida: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Medlemmar");
define("ONLINE_EL6", "Senaste medlem");
define("ONLINE_EL7", "l&auml;ser");
define("ONLINE_EL8", "flest online samtidigt: ");
define("ONLINE_EL9", "den");
define("ONLINE_EL10", "Medlemsnamn");
define("ONLINE_EL11", "L&auml;ser sidan");
define("ONLINE_EL12", "Svarar till");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Tr&aring;d");
define("ONLINE_EL15", "Sida");
define("CLASSRESTRICTED", "Klassbegr&auml;nsad sida");
define("ARTICLEPAGE", "Artikel/Recension");
define("CHAT", "Chat");
define("COMMENT", "Kommentarer");
define("DOWNLOAD", "Filer");
define("EMAIL", "email.php");
define("FORUM", "Forum huvudindex");
define("LINKS", "L&auml;nkar");
define("NEWS", "Nyheter");
define("OLDPOLLS", "Gamla r&ouml;stningar");
define("POLLCOMMENT", "R&ouml;stning");
define("PRINTPAGE", "Skriv ut");
define("LOGIN", "Loggar in");
define("SEARCH", "S&ouml;ker");
define("STATS", "Sajtstatistik");
define("SUBMITNEWS", "Skicka in nyhet");
define("UPLOAD", "Uppladdningar");
define("USERPAGE", "Anv&auml;ndarprofiler");
define("USERSETTINGS", "Anv&auml;ndarinst&auml;llningar");
define("ONLINE", "Anv&auml;ndare online");
define("LISTNEW", "Lista nytt");
define("USERPOSTS", "Anv&auml;ndarpostningar");
define("SUBCONTENT", "Skicka in Artikel/Recension");
define("TOP", "Toppostare/Mest aktiva tr&aring;dar");
define("ADMINAREA", "Admin Area");
define("BUGTRACKER", "Buggsp&aring;rare");
define("EVENT", "H&auml;ndelser");
define("CALENDAR", "Kalender");
define("FAQ", "Faq");
define("PM", "Privata meddelanden");
define("SURVEY", "Unders&ouml;kning");
define("ARTICLE", "Artikel");
define("CONTENT", "Inneh&aring;llssida");
define("REVIEW", "Recension");

?>
