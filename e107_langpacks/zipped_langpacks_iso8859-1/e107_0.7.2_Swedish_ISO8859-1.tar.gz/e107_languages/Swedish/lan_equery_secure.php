<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_equery_secure.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Du blir omdirigerad till en admin funktion, databas&auml;ndringar kan intr&auml;ffa");
define("EQSEC_LAN2", "V&auml;nligen bekr&auml;fta denna &aring;tg&auml;rd:");
define("EQSEC_LAN3", "Ingen h&auml;nvisare");
define("EQSEC_LAN4", "Atg&auml;rd fr&aring;n:");
define("EQSEC_LAN5", "&Aring;tg&auml;rd till:");
define("EQSEC_LAN6", "Bekr&auml;fta &aring;tg&auml;rd");
define("EQSEC_LAN7", "eller avbryt");

?>
