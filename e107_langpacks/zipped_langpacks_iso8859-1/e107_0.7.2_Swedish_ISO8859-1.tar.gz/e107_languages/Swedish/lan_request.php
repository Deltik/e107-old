<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/lan_request.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Nerladdningsfel");
define("LAN_dl_62", "Du har blivit hindrad att ladda ner filen, du har &ouml;verskridit din nerladdningskvot");
define("LAN_dl_63", "Du har inte beh&ouml;righet att ladda ner denna fil.");
define("LAN_dl_64", "Tillbaka");
define("LAN_dl_65", "Fil hittades ej");

?>
