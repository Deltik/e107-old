<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:34 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner");

define("LAN_16", "Anv&auml;ndarnamn: ");
define("LAN_17", "L&ouml;senord: ");
define("LAN_18", "Forts&auml;tt");
define("LAN_19", "Ange ditt klientnamn och l&ouml;senord f&ouml;r att forts&auml;tta");
define("LAN_20", "Tyv&auml;rr, kan inte hitta de detaljerna i databasen. Kontakta sajtadministrat&ouml;ren f&ouml;r mera information.");
define("LAN_21", "Bannerstatistik");
define("LAN_22", "Klient");
define("LAN_23", "Banner ID");
define("LAN_24", "Klickningar");
define("LAN_25", "Klick %");
define("LAN_26", "Visningar");
define("LAN_27", "Ink&ouml;pta visningar");
define("LAN_28", "Kvarvarande visningar");
define("LAN_29", "Inga banners");
define("LAN_30", "Obegr&auml;nsat");
define("LAN_31", "Ej applicerbart");
define("LAN_32", "Ja");
define("LAN_33", "Nej");
define("LAN_34", "Slutar:");
define("LAN_35", "IP adresser, klickningar");
define("LAN_36", "Aktiv:");
define("LAN_37", "Startar:");
define("LAN_38", "Fel");

?>
