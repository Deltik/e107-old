<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_banlist.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Sp&auml;rr borttagen.");
define("BANLAN_2", "Inga sp&auml;rrar.");
define("BANLAN_3", "Befintliga sp&auml;rrar");
define("BANLAN_4", "Ta bort sp&auml;rr");
define("BANLAN_5", "Ange IP, e-postadress, eller v&auml;rd");
define("BANLAN_7", "Anledning");
define("BANLAN_8", "Sp&auml;rra anv&auml;ndare");
define("BANLAN_9", "Sp&auml;rra anv&auml;ndare fr&aring;n sajten");
define("BANLAN_10", "IP / E-post / Orsak");
define("BANLAN_11", "Auto-sp&auml;rra: Fler &auml;n 10 misslyckade inloggningsf&ouml;rs&ouml;k");

?>
