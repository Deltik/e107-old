<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/mailout.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Anv&auml;nd denna sida f&ouml;r att konfigurera dina e-postinst&auml;llningar f&ouml;r sajtens utskicksfunktioner. Utskicksformul&auml;ret ger dig ocks&aring; m&ouml;jlighet att skicka ut ett brev till dina anv&auml;ndare.";
$ns -&gt; tablerender("E-posthj&auml;lp", $text);

?>
