<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/filemanager.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan hantera filerna i din /files katalog fr&aring;n denna sidan. Om du f&aring;r felmeddelande om filr&auml;ttigheter n&auml;r du laddar upp, s&auml;tt d&aring; katalogen du f&ouml;rs&ouml;ker ladda upp till till CHMOD 777.";
$ns -&gt; tablerender("Hj&auml;lp Filhanteraren", $text);

?>
