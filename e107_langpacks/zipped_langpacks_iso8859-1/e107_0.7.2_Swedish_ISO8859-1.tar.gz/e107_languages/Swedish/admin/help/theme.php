<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/theme.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Temahanteraren l&aring;ter dig s&auml;tta teman f&ouml;r din sajts publika avdelning och f&ouml;r adminsektionen.";
$ns -&gt; tablerender("Temahanteraren hj&auml;lp", $text);
?>