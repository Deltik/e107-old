<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/log.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Aktivera sajtstatistik loggning fr&aring;n denna sida. Om du har ont om utrymme p&aring; derverm markera endast dom&auml;n rutan ist&auml;llet f&ouml;r loggning av h&auml;nvisningar, detta kommer endast att logga dom&auml;nen till skillnad fr&aring;n hela URLen, t.ex. 'jalist.com' ist&auml;llet f&ouml;r 'http://jalist.com/links.php' ";
$ns -&gt; tablerender("Loggningshj&auml;lp", $text);

?>
