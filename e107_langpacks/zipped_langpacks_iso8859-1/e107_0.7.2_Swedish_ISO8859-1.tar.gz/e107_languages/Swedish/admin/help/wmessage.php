<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/wmessage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "P&aring; denna sidan kan du s&auml;tta ett meddelande som alltid visas h&ouml;gst upp p&aring; din f&ouml;rstasida n&auml;r det &auml;r atkiverat.
 Du kan ha olika meddelanden f&ouml;r g&auml;ster, registrerade/inloggade medlemmar och administrat&ouml;rer.";
$ns -> tablerender("WMeddelande hj&auml;lp", $text);

?>
