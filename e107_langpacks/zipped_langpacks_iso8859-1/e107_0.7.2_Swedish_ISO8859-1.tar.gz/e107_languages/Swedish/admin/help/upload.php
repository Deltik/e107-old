<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/upload.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "H&auml;rifr&aring;n kan du till&aring;ta/f&ouml;rbjuda att anv&auml;ndare laddar upp filer, och du kan hantera de filer som har laddats upp.";
$ns -&gt; tablerender("Publika uppladdningar hj&auml;lp", $text);

?>
