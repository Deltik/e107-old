<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/custommenu.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Fr&aring;n denna sida can du skapa egna menyer eller egna sidor med ditt eget inneh&aring;ll.<br /><br />Se &auml;ven &lt;a href='http://docs.e107.org?Custom Pages'&gt;http://docs.e107.org?Custom Pages&lt;/a&gt;";
$ns -> tablerender(CUSLAN_18, $text);

?>
