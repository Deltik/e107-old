<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/users.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Denna sida l&aring;ter dig moderera dina registrerade anv&auml;ndare. Du kan uppdatera deras inst&auml;llningar, ge dem adminstatus, s&auml;tta deras klass med mera.";
$ns -&gt; tablerender("Anv&auml;ndarhj&auml;lp", $text);
unset($text);

?>
