<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/users.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Denna sida l&aring;ter dig moderera dina registrerade anv&auml;ndare. Du kan uppdatera deras inst&auml;llningar, ge dem adminstatus, s&auml;tta deras klass med mera.";
$ns -> tablerender("Anv&auml;ndarhj&auml;lp", $text);
unset($text);

?>
