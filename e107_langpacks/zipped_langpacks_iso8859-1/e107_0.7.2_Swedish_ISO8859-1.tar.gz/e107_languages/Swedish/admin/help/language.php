<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/language.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Att s&auml;tta ett nytt spr&aring;k ger dig m&ouml;jligheten att ha detta spr&aring;ket ocks&aring; p&aring; ditt inneh&aring;ll.";
$ns -&gt; tablerender("Spr&aring;khj&auml;lp", $text);

?>
