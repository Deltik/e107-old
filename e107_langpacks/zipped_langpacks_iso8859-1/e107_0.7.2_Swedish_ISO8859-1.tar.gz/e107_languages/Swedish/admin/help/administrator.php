<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/administrator.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Sajtadmin hj&auml;lp";
$text = "Anv&auml;nd denna sida f&ouml;r att l&auml;gga till eller ta bort sajtadministrat&ouml;rer. Administrat&ouml;ren kommer endast att ha tillg&aring;ng till de markerade funktionerna.<br /><br />
F&ouml;r att skapa en ny admin, g&aring; till anv&auml;ndarkonfigureringssidan och uppdatera en befintlig anv&auml;ndare till admin status.";
$ns -> tablerender($caption, $text);

?>
