<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/administrator.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Sajtadmin hj&auml;lp";
$text = "Anv&auml;nd denna sida f&ouml;r att l&auml;gga till eller ta bort sajtadministrat&ouml;rer. Administrat&ouml;ren kommer endast att ha tillg&aring;ng till de markerade funktionerna.&lt;br /&gt;&lt;br /&gt;
F&ouml;r att skapa en ny admin, g&aring; till anv&auml;ndarkonfigureringssidan och uppdatera en befintlig anv&auml;ndare till admin status.";
$ns -&gt; tablerender($caption, $text);

?>
