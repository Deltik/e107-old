<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/emoticon.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Med smajlys aktiverade kommer standard smajly-text att ers&auml;ttas med motsvarande smajly-ikon i allt inneh&aring;ll p&aring; din sajt.";

$ns -> tablerender("Smajlyhj&auml;lp", $text);

?>
