<?php/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/news_category.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan separera dina nyhetsposter i olika kategorier och l&aring;ta bes&ouml;karna att visa nyheter i endast dessa kategorier. &lt;br /&gt;&lt;br /&gt;Ladda upp dina ikonbilder antingen till ".e_THEME."-ditt-tema-/images/ eller themes/shared/newsicons/.";
$ns -&gt; tablerender("Hj&auml;lp nyhetskategorier", $text);

?>
