<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/poll.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du skapar r&ouml;stningar/unders&ouml;kningar fr&aring;n denna sida, bara skriv in rubriken och de olika alternativen, f&ouml;rhandsgranska det och om det ser bra ut, markera rutan f&ouml;r att aktivera den.&lt;br /&gt;&lt;br /&gt;
F&ouml;r att visa r&ouml;stningen, g&aring; till din menysida och se till att poll_menu &auml;r aktiverad.";

$ns -&gt; tablerender("R&ouml;stningar", $text);

?>
