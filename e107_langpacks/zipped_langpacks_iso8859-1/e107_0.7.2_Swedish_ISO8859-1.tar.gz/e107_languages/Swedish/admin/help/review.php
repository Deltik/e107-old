<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/review.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Recensioner &auml;r liknande artiklar, men de listas i egna menyer.&lt;br /&gt;
F&ouml;r en flersidig recension, separera sidorna med texten [newpage], allts&aring; &lt;br /&gt;&lt;code&gt;Test1 [newpage] Test2&lt;/code&gt;&lt;br /&gt; skapar en tv&aring;sidig recension med 'Test1' p&aring; sidan 1 och 'Test2' p&aring; sidan 2.";
$ns -&gt; tablerender("Recensionshj&auml;lp", $text);

?>
