<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/menus2.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Menyhj&auml;lp";
$text .= "Du kan arrangera var och i vilken ordning dina menyer skall visas h&auml;rifr&aring;n. Anv&auml;nd pilarna f&ouml;r att flytta menyerna upp och ner tills du &auml;r n&ouml;jd med placeringarna.&lt;br /&gt;
Menyerna i mitten p&aring; sk&auml;rmen &auml;r avaktiverade, du kan aktivera dem genom att v&auml;lja en plats att visa dem p&aring;.
";

$ns -&gt; tablerender("Menyhj&auml;lp", $text);

?>
