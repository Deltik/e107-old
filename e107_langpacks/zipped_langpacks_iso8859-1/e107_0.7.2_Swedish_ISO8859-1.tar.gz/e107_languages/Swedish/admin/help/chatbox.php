<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/chatbox.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "S&auml;tt dina chattrutepreferenser h&auml;r.<br />Om byt ut l&auml;nk &auml;r markerad kommer alla l&auml;nkar som skrivs att bytas ut mot den text du anger i textrutan. Detta f&ouml;rhindrar att l&aring;nga l&auml;nkar skapar visningsproblem. Textbrytning kommer att automatiskt radbryta text l&auml;ngre &auml;n den l&auml;ngd du anger h&auml;r.";
$ns -> tablerender("Chattruta", $text);

?>
