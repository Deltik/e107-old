<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/image.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "H&auml;rifr&aring;n kan du till&aring;ta/f&ouml;rbjuda anv&auml;ndarnas m&ouml;jligheter att posta bilder p&aring; sajten. Du kan ocks&aring; s&auml;tta skalningsmetod och titta p&aring; uppladdade figurer.";
$ns -> tablerender("Hj&auml;lp f&ouml;r bilder", $text);

?>
