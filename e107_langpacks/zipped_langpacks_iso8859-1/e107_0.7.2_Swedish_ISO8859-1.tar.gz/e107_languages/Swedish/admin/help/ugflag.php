<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/ugflag.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Om du uppgraderar e107 eller bara beh&ouml;ver ta din sajt offline f&ouml;r en tid, klicka bara i underh&aring;llsrutan s&aring; kommer dina bes&ouml;kare att omdirigeras till en sida som f&ouml;rklarar att sajen &auml;r nere f&ouml;r underh&aring;ll. N&auml;r du &auml;r klar, avmarkera rutan och sajten &aring;terg&aring;r till det vanliga.";

$ns -&gt; tablerender("Underh&aring;ll", $text);

?>
