<?php/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/userclass2.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Hj&auml;lp anv&auml;ndande av klasser";
$text = "Du kan skapa och redigera/radera befintliga klasser fr&aring;n denna sidan.<br />Det &auml;r anv&auml;ndbart f&ouml;r att begr&auml;nsa anv&auml;ndare fr&aring;n/till valda delar av din sajt.
 Till exempel kan du skapa en klass kallad TEST, sedan skapa ett forum som endast anv&auml;ndare i klassen TEST har tillg&aring;ng till.";
$ns -> tablerender($caption, $text);

?>
