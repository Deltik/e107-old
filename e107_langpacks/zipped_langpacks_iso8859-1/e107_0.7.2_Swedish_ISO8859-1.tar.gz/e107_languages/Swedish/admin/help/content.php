<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/content.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan l&auml;gga till en vanlig sida till din sajt med denna funktion. En l&auml;nk till den nya sidan kommer att skapa i sajtens huvudnavigeringsruta. Till exempel om du skapa en ny sida med l&auml;nknamnet 'Test' kommer en l&auml;nk ben&auml;mnd 'Test' att dyka upp  i din l&auml;nkruta efter att du postat din nya sida.<br />
Om du vill att din sida skall ha en rubrik, ange den i rutan f&ouml;r sidhuvud.";
$ns -> tablerender("Inneh&aring;llshj&auml;lp", $text);

?>
