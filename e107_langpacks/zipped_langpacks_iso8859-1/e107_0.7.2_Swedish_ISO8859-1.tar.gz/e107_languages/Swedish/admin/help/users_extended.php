<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/users_extended.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ut&ouml;kade anv&auml;ndarf&auml;lt l&aring;ter dig l&auml;gga till ytterligare dataf&auml;lt av olika typer som anv&auml;ndarna kan fylla i i sin profil.";
$ns -&gt; tablerender("Hj&auml;lp f&ouml;r ut&ouml;kade anv&auml;ndarf&auml;lt", $text);

?>
