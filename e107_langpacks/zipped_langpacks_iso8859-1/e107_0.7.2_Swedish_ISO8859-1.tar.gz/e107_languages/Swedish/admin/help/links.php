<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/links.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ange alla dina sajtl&auml;nkar h&auml;r. L&auml;nkar inlagda h&auml;r kommer att visas i din huvudnavigeringsmeny, f&ouml;r andra l&auml;nkar, anv&auml;nd plugin f&ouml;r l&auml;nksidor.
&lt;br /&gt;
";
$ns -&gt; tablerender("L&auml;nkhj&auml;lp", $text);

?>
