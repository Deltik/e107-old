<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/help/prefs.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Dina preferenser l&aring;ter dig specificera alla de viktiga inst&auml;llningarna p&aring; din sajt, allt fr&aring;n sajtens namn och beskrivning till fl&ouml;desskydd och svordomsfilter.";
$ns -> tablerender("Preferenser hj&auml;lp", $text);

?>
