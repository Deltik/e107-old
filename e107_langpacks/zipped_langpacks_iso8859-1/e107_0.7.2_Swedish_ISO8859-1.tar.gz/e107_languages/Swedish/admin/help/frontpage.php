<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/help/frontpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:49:09 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Hj&auml;lp f&ouml;rstasidan";
$text = "Fr&aring;n denna sida v&auml;ljer du vad som skall visas p&aring; f&ouml;rsta sidan p&aring; sajten. Standard &auml;r nyheter.";
$ns -&gt; tablerender($caption, $text);

?>
