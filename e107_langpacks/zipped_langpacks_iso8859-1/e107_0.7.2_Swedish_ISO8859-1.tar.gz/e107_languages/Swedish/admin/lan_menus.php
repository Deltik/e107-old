<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_menus.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Synlig f&ouml;r alla");
define("MENLAN_2", "Synlig endast f&ouml;r medlemmar");
define("MENLAN_3", "Synlig endast f&ouml;r administrat&ouml;rer");
define("MENLAN_4", "Endast synlig f&ouml;r:");
// define("MENLAN_5", "klass");
define("MENLAN_6", "Spara synbarhetsalternativ");
define("MENLAN_7", "Konfigurera synbarhetsalternativ f&ouml;r");
define("MENLAN_8", "Synbarhetsalternativ uppdaterade");
define("MENLAN_9", "Ny egen meny installerad");
define("MENLAN_10", "Ny meny installerad");
define("MENLAN_11", "Meny borttagen");
define("MENLAN_12", "Aktivera: v&auml;lj area");
define("MENLAN_13", "Aktivera i area");
define("MENLAN_14", "Area");
define("MENLAN_15", "Avaktivera");
define("MENLAN_16", "Konfigurera");
define("MENLAN_17", "Flytta upp");
define("MENLAN_18", "Flytta ner");
define("MENLAN_19", "Flytta till area");
define("MENLAN_20", "Synbarhet");

// define("MENLAN_21", "Endast synlig f&ouml;r g&auml;ster");
define("MENLAN_22", "Inaktiva menyer");

define("MENLAN_23", "Flytta till botten");
define("MENLAN_24", "Flytta till topp");
define("MENLAN_25", "Funktion ...");

define("MENLAN_26", "Denna meny kommer bara att &lt;strong&gt;SYNAS&lt;/strong&gt; p&aring; f&ouml;ljande sidor");
define("MENLAN_27", "Denna meny kommer bara att vara &lt;strong&gt;G&Ouml;MD&lt;/strong&gt; p&aring; f&ouml;ljande sidor");
define("MENLAN_28", "Ange en sida per rad, ange tillr&auml;ckligt mycket av URLen f&ouml;r att utm&auml;rka den ordentligt");

define("MENLAN_29", "V&auml;lj layout");
define("MENLAN_30", "F&ouml;r att se menyareorna och deras l&auml;ge f&ouml;r egna layouter, v&auml;lj egen layout h&auml;r:");
define("MENLAN_31", "Standardlayout");
define("MENLAN_32", "Nyhetsrubrik layout");
define("MENLAN_33", "Egen layout");
define("MENLAN_34", "Inb&auml;ddad");
define("MENLAN_35", "Konfigurera menyer");
define("MENLAN_36", "V&auml;lj meny(er) att aktivera");
define("MENLAN_37", "och var de skall aktiveras.");
define("MENLAN_38", "H&aring;ll ner CTRL f&ouml;r att v&auml;lja flera menyer.");

?>
