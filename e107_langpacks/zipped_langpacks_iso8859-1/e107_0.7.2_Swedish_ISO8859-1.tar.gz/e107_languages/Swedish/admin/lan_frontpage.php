<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_frontpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "F&ouml;rstasidans inst&auml;llningar uppdaterade.");
define("FRTLAN_2", "S&auml;tt f&ouml;rstasida f&ouml;r");
define("FRTLAN_6", "L&auml;nkar");
// define("FRTLAN_7", "Inneh&aring;llssida");
define("FRTLAN_12", "Uppdatera f&ouml;rstasidans inst&auml;llningar");
define("FRTLAN_13", "F&ouml;rstasidans inst&auml;llningar");
define("FRTLAN_15", "Annat (ange URL):");
define("FRTLAN_16", "Fel: ingen huvudinneh&aring;llsv&auml;rd vald");
define("FRTLAN_17", "Fel: ingen inneh&aring;llsunderkategori vald");
define("FRTLAN_18", "Fel: ingen inneh&aring;llpost vald");
define("FRTLAN_19", "huvudinneh&aring;llsv&auml;rd");
define("FRTLAN_20", "inneh&aring;llskategori");
define("FRTLAN_21", "inneh&aring;llspost");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Alla anv&auml;ndare");
define("FRTLAN_27", "G&auml;ster");
define("FRTLAN_28", "Medlemmar");
define("FRTLAN_29", "Administrat&ouml;rer");
define("FRTLAN_31", "Alla anv&auml;ndare");
define("FRTLAN_32", "Anv&auml;ndarklass");
define("FRTLAN_33", "Nuvarande inst&auml;llningar");
define("FRTLAN_34", "Sida");

?>
