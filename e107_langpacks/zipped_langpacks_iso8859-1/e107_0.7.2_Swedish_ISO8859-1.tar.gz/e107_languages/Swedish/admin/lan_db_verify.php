<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_db_verify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Kan inte l&auml;sa SQL-datafilen&lt;br /&gt;&lt;br /&gt;F&ouml;rs&auml;kra dig om att filen &lt;b&gt;core_sql.php&lt;/b&gt; finns i &lt;b&gt;/admin/sql&lt;/b&gt; katalogen.");
define("DBLAN_2", "Verifierar allt");

define("DBLAN_4", "Tabell");
define("DBLAN_5", "F&auml;lt");
define("DBLAN_6", "Status");
define("DBLAN_7", "Noteringar");
define("DBLAN_8", "St&auml;mmer ej");
define("DBLAN_9", "Nuvarande");
define("DBLAN_10", "skall vara");
define("DBLAN_11", "F&auml;lt saknas");
define("DBLAN_12", "Extra f&auml;lt!");
define("DBLAN_13", "Tabell saknas!");
define("DBLAN_14", "V&auml;lj tabell(er) att validera");
define("DBLAN_15", "Starta verifiering");
define("DBLAN_16", "SQL verifiering");
define("DBLAN_17", "Tillbaka");
define("DBLAN_18", "tabeller");
define("DBLAN_19", "F&ouml;rs&ouml;k att r&auml;tta");
define("DBLAN_20", "F&ouml;rs&ouml;ker att r&auml;tta tabeller");
define("DBLAN_21", "R&auml;tta valda objekt");

?>
