<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_cpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Rubrik");
define("CUSLAN_2", "Typ");
define("CUSLAN_3", "Alternativ");
define("CUSLAN_4", "Radera denna sida?");
define("CUSLAN_5", "Befintliga sidor");
define("CUSLAN_7", "Menynamn");
define("CUSLAN_8", "Rubrik / Rubrikrad");
define("CUSLAN_9", "Text");
define("CUSLAN_10", "Till&aring;t betygss&auml;ttning av sidan");
define("CUSLAN_11", "F&ouml;rstasida");
define("CUSLAN_12", "Skapa sida");
define("CUSLAN_13", "Till&aring;t kommentarer");
define("CUSLAN_14", "L&ouml;senordsskydda sida");
define("CUSLAN_15", "ange l&ouml;senord f&ouml;r skydd av sidan");
define("CUSLAN_16", "Skapa l&auml;nk i huvudmenyn");
define("CUSLAN_17", "ange l&auml;nknamn att skapa");
define("CUSLAN_18", "Sida / l&auml;nk synlig f&ouml;r");
define("CUSLAN_19", "Uppdatera sida");
define("CUSLAN_20", "Skapa sida");
define("CUSLAN_21", "Uppdatera meny");
define("CUSLAN_22", "Skapa meny");
define("CUSLAN_23", "Redigera sida");
define("CUSLAN_24", "Skapa ny sida");
define("CUSLAN_25", "Redigera meny");
define("CUSLAN_26", "Skapa ny meny");
define("CUSLAN_27", "Sidan sparad till databasen.");
define("CUSLAN_28", "Sidan raderad");
define("CUSLAN_29", "Lista sidor om ingen sida valts");
define("CUSLAN_30", "Kakans varaktighet (i sekunder)");
define("CUSLAN_31", "Skapa meny");
define("CUSLAN_32", "Konvertera gamla sidor/menyer");
define("CUSLAN_33", "Alternativ f&ouml;r sida");
define("CUSLAN_34", "Startar konvertering");
define("CUSLAN_35", "Avslutade uppdatering av inneh&aring;llssid - uppdaterad");
define("CUSLAN_36", "F&ouml;r att s&auml;tta preferenser f&ouml;r varje sida, &aring;terg&aring; till f&ouml;rstasidan och redigera sidorna.");
define("CUSLAN_37", "Uppdatering av egna sidor");
define("CUSLAN_38", "till");
define("CUSLAN_39", "fr&aring;n");
define("CUSLAN_40", "Spara alternativ");

define("CUSLAN_41", "Visa information om f&ouml;rfattare och datum");
define("CUSLAN_42", "Inga sidor definierade &auml;nnu");

?>
