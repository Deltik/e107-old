<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_updateadmin.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Fel - skicka igen");
define("UDALAN_2", "Inst&auml;llningar uppdaterade");
define("UDALAN_3", "Inst&auml;llningar uppdaterade f&ouml;r");
define("UDALAN_4", "Namn");
define("UDALAN_5", "L&ouml;senord");
define("UDALAN_6", "Ange l&ouml;senord igen");
define("UDALAN_7", "&Auml;ndra l&ouml;senord");
define("UDALAN_8", "L&ouml;senord uppdatering f&ouml;r");

?>
