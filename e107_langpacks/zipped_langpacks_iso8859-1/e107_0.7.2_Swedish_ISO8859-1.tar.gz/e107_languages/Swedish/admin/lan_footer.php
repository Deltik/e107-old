<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_footer.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Sajt");
define("FOOTLAN_2", "Huvudadmin");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "av");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installationsdatum");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "v&auml;rd");
define("FOOTLAN_11", "PHP version");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Sajtinfo");
define("FOOTLAN_14", "Visa dok.");
define("FOOTLAN_15", "Dokumentation");
define("FOOTLAN_16", "Databas");
define("FOOTLAN_17", "Teckenupps&auml;ttning");

?>
