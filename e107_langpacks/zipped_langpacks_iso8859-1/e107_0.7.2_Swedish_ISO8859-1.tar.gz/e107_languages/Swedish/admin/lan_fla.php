<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_fla.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Misslyckade inloggningsf&ouml;rs&ouml;k");
define("FLALAN_2", "Inga misslyckade inloggningar har loggats");
define("FLALAN_3", "F&ouml;rs&ouml;k raderade");
define("FLALAN_4", "Anv&auml;ndare f&ouml;rs&ouml;kte logga in med felaktigt anv&auml;ndarnamn/l&ouml;senord");
define("FLALAN_5", "Sp&auml;rrade IP(s)");
define("FLALAN_6", "Datum");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP adress/V&auml;rd");
define("FLALAN_9", "Alternativ");
define("FLALAN_10", "Radera/Sp&auml;rra markerade poster");
define("FLALAN_11", "markera alla radera-rutorna");
define("FLALAN_12", "avmarkera alla radera-rutorna");
define("FLALAN_13", "markera alla sp&auml;rra-rutorna");
define("FLALAN_14", "avmarkera alla sp&auml;rra-rutorna");
define("FLALAN_15", "F&ouml;ljande IP adress(er) har blivit auto-sp&auml;rrade - anv&auml;ndare har gjort fler &auml;n tio felaktiga inloggningar");
define("FLALAN_16", "Radera denna autosp&auml;rrlista");
define("FLALAN_17", "Autosp&auml;rrlista raderad");

?>
