<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_emoticon.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Smajly aktivering");
define("EMOLAN_2", "Namn");
define("EMOLAN_3", "Smajly");
define("EMOLAN_4", "Aktivera smajlys?");

define("EMOLAN_5", "Bild");
define("EMOLAN_6", "Smajly kod");
define("EMOLAN_7", "seperera multipla smajlykoder med mellanslag");

define("EMOLAN_8", "Status");
define("EMOLAN_9", "Alternativ");
define("EMOLAN_10", "Aktiv");
define("EMOLAN_11", "Aktivera paket'");

define("EMOLAN_12", "Redigera/konfigurera detta paket");
define("EMOLAN_13", "Installerade paket");

define("EMOLAN_14", "Spara konfiguration");
define("EMOLAN_15", "Redigera/konfigurera smajlys");
define("EMOLAN_16", "Smajlykonfiguration sparad");
define("EMOLAN_2", "Namn");
define("EMOLAN_2", "Namn");
define("EMOLAN_2", "Namn");
define("EMOLAN_2", "Namn");
define("EMOLAN_2", "Namn");
define("EMOLAN_2", "Namn");

?>
