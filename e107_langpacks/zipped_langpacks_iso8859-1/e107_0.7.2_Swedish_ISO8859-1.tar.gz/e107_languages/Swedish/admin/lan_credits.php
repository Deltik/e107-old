<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_credits.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Tack till");
define("CRELAN_2", "Nedan &auml;r en lista p&aring; tredjeparts mjukvara / resurser anv&auml;nda i e107. e107's utvecklingsteam vill personligen tacka utvecklarna av f&ouml;ljande f&ouml;r att de till&aring;ter oss att &aring;terdistribuera deras kod med e107, och f&ouml;r att de sl&auml;pper sin mjukvara under GPL licensen.");
// define("CRELAN_3", "Resurs");
// define("CRELAN_4", "Beskrivning");
// define("CRELAN_5", "Webbsajt");
// define("CRELAN_6", "Till&aring;telse");
define("CRELAN_7", "version");

?>
