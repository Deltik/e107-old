<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_db.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "K&auml;rninst&auml;llningar kopierade till databasen.");
define("DBLAN_2", "Klicka p&aring; knappen f&ouml;r att spara en kopia av din e107 databas");
define("DBLAN_3", "Kopiera SQL-databasen");
define("DBLAN_4", "Klicka p&aring; knappen f&ouml;r att kontrollera giltigheten av e107 databasen");
define("DBLAN_5", "Kontrollera databasens giltighet ");
define("DBLAN_6", "Klicka p&aring; knappen f&ouml;r att optimera din e107 databas");
define("DBLAN_7", "Optimera SQL-databasen");
define("DBLAN_8", "Klicka p&aring; knappen f&ouml;r att s&auml;kerhetskopiera dina k&auml;rninst&auml;llningar");
define("DBLAN_9", "Kopiera k&auml;rninst&auml;llningar");
define("DBLAN_10", "Databasverktyg");
define("DBLAN_11", "MySQL databas");
define("DBLAN_12", "optimerad");
define("DBLAN_13", "Tillbaka");
define("DBLAN_14", "Klart");
define("DBLAN_15", "Klicka p&aring; knappen f&ouml;r att se om det finns n&aring;gon DB uppdatering");
define("DBLAN_16", "Kontrollera uppdateringar");

?>
