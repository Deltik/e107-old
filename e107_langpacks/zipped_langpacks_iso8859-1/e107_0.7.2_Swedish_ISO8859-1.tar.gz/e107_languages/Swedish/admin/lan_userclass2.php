<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_userclass2.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Tog bort alla anv&auml;ndare fr&aring;n klass.");
define("UCSLAN_2", "Klassanv&auml;ndare uppdaterade.");
define("UCSLAN_3", "Klass raderad.");
define("UCSLAN_4", "Markera f&ouml;r att bekr&auml;fta radering av denna anv&auml;ndarklass");
define("UCSLAN_5", "Klass uppdaterad.");
define("UCSLAN_6", "Klass sparad till databasen.");
define("UCSLAN_7", "Inga anv&auml;ndarklasser &auml;nnu.");
define("UCSLAN_8", "Befintliga klasser");

// define("UCSLAN_9", "Redigera");
// define("UCSLAN_10", "Radera");
define("UCSLAN_11", "markera f&ouml;r att bekr&auml;fta");
define("UCSLAN_12", "Klassnamn");
define("UCSLAN_13", "Klassbeskrivning");
define("UCSLAN_14", "Uppdatera anv&auml;ndarklass");
define("UCSLAN_15", "Skapa ny klass");
define("UCSLAN_16", "L&auml;gg till anv&auml;ndare till klass");
define("UCSLAN_17", "Ta bort");
define("UCSLAN_18", "Rensa klass");
define("UCSLAN_19", "L&auml;gg till anv&auml;ndare till");
define("UCSLAN_20", "klass");
define("UCSLAN_21", "Anv&auml;ndarklass inst&auml;llningar");

define("UCSLAN_22", "Anv&auml;ndare - klicka f&ouml;r att flytta...");
define("UCSLAN_23", "Anv&auml;ndare i denna klass...");

define("UCSLAN_24", "Vem kan hantera klass");

?>
