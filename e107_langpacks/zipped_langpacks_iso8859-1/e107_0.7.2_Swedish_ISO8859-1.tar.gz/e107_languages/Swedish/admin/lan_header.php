<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_header.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Admin navigering");
define("LAN_head_2", "Din server till&aring;ter inte HTTP filuppladdningar, s&aring; dina anv&auml;ndare kommer inte att kunna ladda upp figurer/filer etc. F&ouml;r att r&auml;tta till detta, s&auml;tt file_uploads till On i din php.ini och starta om din server. Om du inte har tillg&aring;ng till php.ini kontakta din webbv&auml;rd.");
define("LAN_head_3", "Din server k&ouml;rs med en 'baskatalog' restriktion aktiverad. Detta f&ouml;rbjuder anv&auml;ndandet av filer utanf&ouml;r din hemmakatalog och kan med det p&aring;verka vissa skript som t.ex. filhanteraren.");

define("LAN_head_4", "Admin area");

define("LAN_head_5", "spr&aring;k visat i adminarean: ");
define("LAN_head_6", "Plugin info");

?>
