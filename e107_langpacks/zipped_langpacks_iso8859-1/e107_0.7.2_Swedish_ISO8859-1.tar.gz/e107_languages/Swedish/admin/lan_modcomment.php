<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/30 16:27:38 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Modererad.");
define("MDCLAN_2", "Inga kommentarer till denna post");
define("MDCLAN_3", "Medlem");
define("MDCLAN_4", "G&auml;st");
define("MDCLAN_5", "avblockera");
define("MDCLAN_6", "blockera");

define("MDCLAN_8", "Moderera kommentarer");
define("MDCLAN_9", "Varning! Radering av v&auml;rdkommentar raderar ocks&aring; alla svar!");

define("MDCLAN_10", "Alternativ");
define("MDCLAN_11", "kommentar");
define("MDCLAN_12", "kommentarer");
define("MDCLAN_13", "blockerad");
define("MDCLAN_14", "l&aring;s kommentarer");
define("MDCLAN_15", "&ouml;ppen");
define("MDCLAN_16", "l&aring;st");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>
