<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_wmessage.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Meddelande f&ouml;r g&auml;ster");
// define("WMGLAN_2", "Meddelande f&ouml;r medlemmar");
// define("WMGLAN_3", "Meddelande f&ouml;r administrat&ouml;rer");
// define("WMGLAN_4", "Skicka");
// define("WMGLAN_5", "S&auml;tt h&auml;lsningsmeddelande");
// define("WMGLAN_6", "Aktivera?");
// define("WMGLAN_7", "Inst&auml;llning f&ouml;r v&auml;lkomsth&auml;lsning uppdaterad.");

define("WMLAN_00","H&auml;lsningsmeddelande");
define("WMLAN_01","Skapa nytt meddelande");
define("WMLAN_02","Meddelande");
define("WMLAN_03","Synbarhet");
define("WMLAN_04","Meddelandetext");

define("WMLAN_05","Kapsla in");
define("WMLAN_06","Om markerad kommer meddelandet att visas inuti en ruta");
define("WMLAN_07","F&ouml;rbig&aring; systemstandard att anv&auml;nda {WMESSAGE} kortkod:");
// define("WMLAN_08","Preferenser");

define("WMLAN_09","Inget h&auml;lsningsmeddelande satt &auml;nnu");

?>
