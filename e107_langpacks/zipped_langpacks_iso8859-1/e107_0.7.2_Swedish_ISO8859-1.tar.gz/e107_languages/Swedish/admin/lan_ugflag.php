<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_ugflag.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "underh&aring;llsinst&auml;llningar sparade");
define("UGFLAN_2", "Aktivera underh&aring;llsflaggan");
define("UGFLAN_3", "Uppdatera underh&aring;llsinst&auml;llningar");
define("UGFLAN_4", "Underh&aring;llsinst&auml;llningar");

define("UGFLAN_5", "Text att visa n&auml;r sajten &auml;r nere");
define("UGFLAN_6", "L&auml;mna tomt f&ouml;r att visa standardmeddelande");

?>
