<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_language.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00","kunde inte skapas. (Finns redan)");
define("LANG_LAN_01","raderades (om befintlig) och skapades.");
define("LANG_LAN_02","kunde inte raderas");
define("LANG_LAN_03","Tabeller");

define("LANG_LAN_05","Ej installerad");
define("LANG_LAN_06", "Skapa tabeller");
define("LANG_LAN_07", "Sl&auml;ppa befintliga tabeller?");
define("LANG_LAN_08", "Ers&auml;tta befintliga tabeller (data f&ouml;rloras).");
define("LANG_LAN_10", "Bekr&auml;fta radering");
define("LANG_LAN_11", "Radera omarkerade tabeller ovan (om de existerar).");
define("LANG_LAN_12", "Aktivera fler-spr&aring;kstabeller");
define("LANG_LAN_13", "Flerspr&aring;kspreferenser");
define("LANG_LAN_14", "Sajtens standardspr&aring;k");
define("LANG_LAN_15", "Markera f&ouml;r att kopiera data fr&aring;n standardspr&aring;ket.(anv&auml;ndbart f&ouml;r l&auml;nkar, nyhetskategorier etc) ");

?>
