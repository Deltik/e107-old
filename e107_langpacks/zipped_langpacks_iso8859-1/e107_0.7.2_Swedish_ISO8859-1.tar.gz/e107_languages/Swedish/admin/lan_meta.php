<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta-taggar uppdaterade i databasen");
define("METLAN_2", "Ange ytterligare meta-taggar");
define("METLAN_3", "Ange nya meta-tagg inst&auml;llningar");
define("METLAN_4", "Uppdaterat");
define("METLAN_5", "skriv in din beskrivning h&auml;r");
define("METLAN_6", "skriv, en, lista, p&aring;, dina, nyckelord, h&auml;r");
define("METLAN_7", "skriv in din copyright info h&auml;r");
define("METLAN_8", "Meta-taggar");

define("METLAN_9", "Beskrivning");
define("METLAN_10", "Nyckelord");
define("METLAN_11", "Copyright");

?>
