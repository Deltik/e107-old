<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_lancheck.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "V&auml;lj spr&aring;k att verifiera");
define("LAN_CHECK_2", "B&ouml;rja verifiering");
define("LAN_CHECK_3", "Verifiering av");
define("LAN_CHECK_4", "Fil saknas!");
define("LAN_CHECK_5", "Fras saknas!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "fras");

define("LAN_CHECK_8", "En fil saknas...");
define("LAN_CHECK_9", " filer saknas...");
define("LAN_CHECK_10", "Kritiskt fel: ");
define("LAN_CHECK_11", "Inga saknade filer!");
define("LAN_CHECK_12", "En fil &auml;r felaktig...");
define("LAN_CHECK_13", " filer &auml;r felaktiga...");
define("LAN_CHECK_14", "Alla befintliga filer &auml;r giltiga!");

?>
