<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Skickar notifieringsbrev till");
define("UCSLAN_2", "Uppdaterade privilegier");
define("UCSLAN_3", "K&auml;ra");
define("UCSLAN_4", "Dina privilegier har uppdaterats p&aring;");
define("UCSLAN_5", "Du har nu tillg&aring;ng till f&ouml;ljande area(or)");
define("UCSLAN_6", "S&auml;tt klass f&ouml;r anv&auml;ndare");
define("UCSLAN_7", "S&auml;tt klasser");
define("UCSLAN_8", "Notifiera anv&auml;dare");
define("UCSLAN_9", "Klasser uppdaterade.");
define("UCSLAN_10", "H&auml;lsningar,");

?>
