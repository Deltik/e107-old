<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Swedish/admin/lan_userinfo.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Kunde inte hitta postarens IP-adress - ingen information tillg&auml;nglig.");
// define("USFLAN_2", "Fel");
define("USFLAN_3", "Meddelanden postade fr&aring;n IP-adress");
define("USFLAN_4", "V&auml;rd");
define("USFLAN_5", "Klicka h&auml;r f&ouml;r att &ouml;verf&ouml;ra IP-adressen till admins sp&auml;rrsida");
define("USFLAN_6", "Anv&auml;ndarID");
define("USFLAN_7", "Anv&auml;ndarinformation");

?>
