<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_1", "Notifiera");
define("NT_LAN_2", "Ta emot e-postnotifiering om");
define("NT_LAN_3", "Av");
define("NT_LAN_4", "Huvudadmin");
define("NT_LAN_5", "Klass");
define("NT_LAN_6", "E-post");

define("NU_LAN_1", "Anv&auml;ndarh&auml;ndelse");
define("NU_LAN_2", "Anv&auml;ndarregistrering");
define("NU_LAN_3", "Anv&auml;ndarkonto verifierat");
define("NU_LAN_4", "Anv&auml;ndarinloggning");
define("NU_LAN_5", "Anv&auml;ndarutloggning");

define("NS_LAN_1", "S&auml;kerhetsh&auml;ndelse");
define("NS_LAN_2", "IP sp&auml;rrat f&ouml;r fl&ouml;dning av sajten");

define("NN_LAN_1", "Nyhetsh&auml;ndelse");
define("NN_LAN_2", "Nyhetspost ins&auml;nd av anv&auml;ndare");
define("NN_LAN_3", "Nyhet postad av admin");
define("NN_LAN_4", "Nyhet redigerad av admin");
define("NN_LAN_5", "Nyhet raderad av admin");

?>
