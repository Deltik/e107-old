<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_e107_update.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/01/24 12:44:19 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "&Aring;tg&auml;rd");
define("LAN_UPDATE_3", "Beh&ouml;vs ej");

define("LAN_UPDATE_5", "Uppdatering tillg&auml;nglig");

define("LAN_UPDATE_7", "Genomf&ouml;rd");
define("LAN_UPDATE_8", "Uppdatera fr&aring;n");
define("LAN_UPDATE_9", "till");
define("LAN_UPDATE_10", "Tillg&auml;ngliga uppdateringar");
define("LAN_UPDATE_11", ".617 to .7 Uppdatering fortsatt");
?>
