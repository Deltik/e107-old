<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_date.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/26 11:12:22 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "&aring;r");
define("LANDT_02", "m&aring;nad");
define("LANDT_03", "vecka");
define("LANDT_04", "dag");
define("LANDT_05", "timma");
define("LANDT_06", "minut");
define("LANDT_07", "sekund");
define("LANDT_01s", "&aring;r");
define("LANDT_02s", "m&aring;nader");
define("LANDT_03s", "veckor");
define("LANDT_04s", "dagar");
define("LANDT_05s", "timmar");
define("LANDT_06s", "minuter");
define("LANDT_07s", "sekunder");

define("LANDT_08", "min");
define("LANDT_08s", "min"); // Pluralis
define("LANDT_09", "sek");
define("LANDT_09s", "sek"); // Pluralis
define("LANDT_AGO", "sedan");

?>
