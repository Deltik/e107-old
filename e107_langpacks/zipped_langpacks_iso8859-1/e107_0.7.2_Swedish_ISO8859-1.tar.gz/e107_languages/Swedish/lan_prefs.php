<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 driven Webbsajt");
define("LAN_PREF_2", "e107 Webbsajtsystem");
define("LAN_PREF_3", "Denna sajt drivs av &lt;a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;&gt;e107&lt;/a&gt;, som distribueras under villkoren i &lt;a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;&gt;GNU&lt;/a&gt; GPL Licensen.");
define("LAN_PREF_4", "censurerad");
define("LAN_PREF_5", "Forum");

?>
