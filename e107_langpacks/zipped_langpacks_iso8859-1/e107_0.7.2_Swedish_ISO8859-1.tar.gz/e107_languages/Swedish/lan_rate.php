<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 12:05:43 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "r&ouml;st");
define("RATELAN_1", "r&ouml;ster");
define("RATELAN_2", "Hur vill du betygss&auml;tta detta objekt?");
define("RATELAN_3", "Tack f&ouml;r din r&ouml;st");
define("RATELAN_4", "Ej betygssatt");
define("RATELAN_5", "Betyg");

?>
