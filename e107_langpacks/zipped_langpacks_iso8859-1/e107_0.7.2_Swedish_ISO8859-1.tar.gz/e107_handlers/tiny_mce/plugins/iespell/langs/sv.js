/*
+ ----------------------------------------------------------------------------+
|     Swedish (SE) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/iespell/langs/sv.js,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
iespell_desc : 'K&ouml;r r&auml;ttstavningskontroll',
iespell_download : "ieSpell verkar inte vara installerad. Klicka OK f&ouml;r att ladda hem."
});
