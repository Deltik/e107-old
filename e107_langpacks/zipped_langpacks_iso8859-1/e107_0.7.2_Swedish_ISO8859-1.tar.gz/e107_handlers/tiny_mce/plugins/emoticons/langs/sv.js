/*
+ ----------------------------------------------------------------------------+
|     Swedish (SE) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/emoticons/langs/sv.js,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/19 09:33:05 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

tinyMCELang['lang_insert_emotions_title'] = 'Infoga smajly';
tinyMCELang['lang_emotions_desc'] = 'Smajlys';
