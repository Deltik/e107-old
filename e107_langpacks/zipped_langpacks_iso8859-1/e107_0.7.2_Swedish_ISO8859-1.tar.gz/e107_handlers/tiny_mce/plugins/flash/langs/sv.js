/*
+ ----------------------------------------------------------------------------+
|     Swedish (SE) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/flash/langs/sv.js,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('flash',{
title : 'Skapa/uppdatera flash-film',
desc : 'Skapa/uppdatera flash-film',
file : 'Flash-film (.swf)',
size : 'Storlek',
list : 'Flash-filer',
props : 'Flash egenskaper',
general : 'Generella inst&auml;llningar'
});
