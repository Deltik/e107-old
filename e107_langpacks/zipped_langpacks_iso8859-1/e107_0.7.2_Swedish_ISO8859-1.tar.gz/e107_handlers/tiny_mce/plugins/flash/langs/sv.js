/*
+ ----------------------------------------------------------------------------+
|     Swedish (SE) language variables
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/flash/langs/sv.js,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('flash',{
title : 'Skapa/uppdatera flash-film',
desc : 'Skapa/uppdatera flash-film',
file : 'Flash-film (.swf)',
size : 'Storlek',
list : 'Flash-filer',
props : 'Flash egenskaper',
general : 'Generella inst&auml;llningar'
});
