<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/e107v4a/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "L&auml;s/Posta kommentar: ");
define("LAN_THEME_2", "Kommentarer &auml;r avaktiverade f&ouml;r detta objekt");
define("LAN_THEME_3", "L&auml;s resten...");
define("LAN_THEME_4", "Postad av");
define("LAN_THEME_5", "den");
define("LAN_THEME_6", "e107.v4 tema av &lt;a href='http://e107.org' rel='external'&gt;jalist&lt;/a&gt;");

?>
