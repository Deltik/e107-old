<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/crahan/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:07 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'CraHan' av &lt;a href='http://e107.org' rel='external'&gt;jalist&lt;/a&gt;, baserat p&aring; tame av CraHan p&aring; hans hemsida &lt;a href='http://n00.be' rel='external'&gt;n00.be&lt;/a&gt;");
define("LAN_THEME_2", "Kommentarer &auml;r avaktiverade f&ouml;r detta objekt");
define("LAN_THEME_3", "kommentar(er): ");
define("LAN_THEME_4", "L&auml;s resten ...");
define("LAN_THEME_5", "Bak&aring;tl&auml;nk: ");
define("LAN_THEME_6", "Kommentar av");


?>
