<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/vekna_blue/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'vekna blue' av &lt;a href='http://e107.org' rel='external'&gt;jalist&lt;/a&gt;, baserat p&aring;, och med tillst&aring;nd fr&aring;n Arach's sajt, &lt;a href='http://e107.vekna.com' rel='external'&gt;http://e107.vekna.com&lt;/a&gt;");
define("LAN_THEME_2", "L&auml;s/Posta kommentar: ");
define("LAN_THEME_3", "Kommentarer &auml;r avaktiverade f&ouml;r detta objekt");
define("LAN_THEME_4", "L&auml;s resten ...");
define("LAN_THEME_5", "Bak&aring;tl&auml;nkar: ");

?>
