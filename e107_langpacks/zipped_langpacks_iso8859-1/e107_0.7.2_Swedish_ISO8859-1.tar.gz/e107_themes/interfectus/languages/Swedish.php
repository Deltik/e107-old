<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/interfectus/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:07 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'interfectus' av &lt;a href='http://e107.org' rel='external'&gt;jalist&lt;/a&gt;");
define("LAN_THEME_2", "L&auml;s/Posta kommentar: ");
define("LAN_THEME_3", "Kommentarer &auml;r avaktiverade f&ouml;r detta objekt");
define("LAN_THEME_4", "L&auml;s resten ...");
define("LAN_THEME_5", "Bak&aring;tl&auml;nkar: ");

?>
