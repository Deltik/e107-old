<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/lamb/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'lamb' av &lt;a href='http://e107.org' rel='external'&gt;jalist&lt;/a&gt;");
define("LAN_THEME_2", "Kommentarer &auml;r avaktiverade f&ouml;r detta objekt");
define("LAN_THEME_3", "kommentar: ");
define("LAN_THEME_4", "L&auml;s resten ...");
define("LAN_THEME_5", "Bak&aring;tl&auml;nkar: ");


?>
