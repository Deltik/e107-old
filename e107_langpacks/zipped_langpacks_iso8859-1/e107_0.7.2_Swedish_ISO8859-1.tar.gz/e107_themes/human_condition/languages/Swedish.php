<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/human_condition/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:07 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' av &lt;a href='http://e107.org' rel='external'&gt;jalist&lt;/a&gt;, baserat p&aring; Wordpress temat, &lt;a href='http://wordpress.org'&gt;http://wordpress.org&lt;/a&gt;.");
define("LAN_THEME_2", "Kommentarer &auml;r avaktiverade f&ouml;r detta objekt");
define("LAN_THEME_3", "kommentar(er): ");
define("LAN_THEME_4", "L&auml;s resten ...");
define("LAN_THEME_5", "Bak&aring;tl&auml;nkar: ");
define("LAN_THEME_6", "Kommentar av");

?>
