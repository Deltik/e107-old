<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/kubrick/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' av &lt;a href='http://e107.org' title='e107.org' rel='external'&gt;jalist&lt;/a&gt; & &lt;a href='http://e107themes.org' title='e107themes.org' rel='external'&gt;Que&lt;/a&gt;, Baserat p&aring; originaltema av Michael Heilemann (&lt;a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'&gt;http://binarybonsai.com/kubrick/&lt;/a&gt;. ).");
define("LAN_THEME_2", "Kommentarer &auml;r avaktiverade f&ouml;r detta objekt");
define("LAN_THEME_3", "kommentar: ");
define("LAN_THEME_4", "L&auml;s resten ...");
define("LAN_THEME_5", "Bak&aring;tl&auml;nkar: ");


?>
