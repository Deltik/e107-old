<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newforumposts_main/languages/Swedish.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Tr&aring;d");
define("NFPM_LAN_2", "F&ouml;rfattare");
define("NFPM_LAN_3", "Visningar");
define("NFPM_LAN_4", "Svar");
define("NFPM_LAN_5", "Senaste inl&auml;gg");
define("NFPM_LAN_6", "Tr&aring;dar");
define("NFPM_LAN_7", "av");

define("NFPM_L1", "Denna plugin visar en lista p&aring; nya foruminl&auml;gg p&aring; din f&ouml;rstasida");
define("NFPM_L2", "Senaste foruminl&auml;gg");
define("NFPM_L3", "F&ouml;r att konfigurera, klicka p&aring; l&auml;nken i pluginssektionen p&aring; admins f&ouml;rstasida");
define("NFPM_L4", "Aktivera i vilken area?");
define("NFPM_L5", "Inaktiv");
define("NFPM_L6", "Sidans b&ouml;rjan");
define("NFPM_L7", "Sidans slut");
define("NFPM_L8", "Rubrik");
define("NFPM_L9", "Antal nya inl&auml;gg att visa?");
define("NFPM_L10", "Visa i ett rullande lager?");
define("NFPM_L11", "Lagrets h&ouml;jd");
define("NFPM_L12", "Konfiguration f&ouml;r nya foruminl&auml;gg");
define("NFPM_L13", "Uppdatera inst&auml;llningar f&ouml;r nya foruminl&auml;gg");
define("NFPM_L14", "Inst&auml;llningara uppdaterade.");
define("NFPM_L15", "Markera f&ouml;r att visa senaste foruminl&auml;gg.&lt;br /&gt;Standard &auml;r senaste &auml;mnen.");
define('NFPM_L16', '[anv&auml;ndare raderad]');

?>