<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/trackback/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:07 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("TRACKBACK_L1", "Konfigurera bak&aring;tsp&aring;rning");
define("TRACKBACK_L2", "Denna plugin l&aring;ter dig anv&auml;nda bak&aring;tsp&aring;rning i dina nyheter.");
define("TRACKBACK_L3", "Bak&aring;tsp&aring;rning &auml;r nu installerad och aktiverad.");
define("TRACKBACK_L4", "Bak&aring;tsp&aring;rningsinst&auml;llningar sparade.");
define("TRACKBACK_L5", "P&aring;");
define("TRACKBACK_L6", "Av");
define("TRACKBACK_L7", "Aktivera bak&aring;tsp&aring;rning");
define("TRACKBACK_L8", "Bak&aring;tsp&aring;rning URL text");
define("TRACKBACK_L9", "Spara inst&auml;llningar");
define("TRACKBACK_L10", "Bak&aring;tsp&aring;rning inst&auml;llningar");
define("TRACKBACK_L11", "Bak&aring;tsp&aring;rningsadress f&ouml;r denna post:");

define("TRACKBACK_L12", "Ingen bak&aring;tsp&aring;rning f&ouml;r denna post");
define("TRACKBACK_L13", "Moderera bak&aring;tsp&aring;rningar");
define("TRACKBACK_L14", "Radera");
define("TRACKBACK_L15", "Bak&aring;tsp&aring;rningar raderade.");

?>
