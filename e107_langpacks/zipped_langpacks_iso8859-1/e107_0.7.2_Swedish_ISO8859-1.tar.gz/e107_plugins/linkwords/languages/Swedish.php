<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/linkwords/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "F&auml;lt l&auml;mnat tomt.");
define("LWLAN_2", "L&auml;nkord sparat.");
define("LWLAN_3", "L&auml;nkord uppdaterat.");
define("LWLAN_4", "Inga l&auml;nkord definierade &auml;nnu.");
define("LWLAN_5", "Ord");
define("LWLAN_6", "L&auml;nk");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Alternativ");
define("LWLAN_9", "ja");
define("LWLAN_10", "nej");
define("LWLAN_11", "Befintliga l&auml;nkord");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nej");
define("LWLAN_14", "Skicka in l&auml;nkord");
define("LWLAN_15", "Uppdatera &ouml;&auml;nkord");
define("LWLAN_16", "Redigera");
define("LWLAN_17", "Radera");
define("LWLAN_18", "&Auml;r du s&auml;ker p&aring; att du vill radera detta l&auml;nkord?");
define("LWLAN_19", "L&auml;nkord raderat.");
define("LWLAN_20", "Kan inte hitta den l&auml;nkordsposten.");
define("LWLAN_21","Ord att autol&auml;nka");
define("LWLAN_22","Aktivera?");

define("LWLANINS_1", "L&auml;nkord");
define("LWLANINS_2", "Denna plugin kommer att l&auml;nka specificerade ord till en definierad l&auml;nk");
define("LWLANINS_3", "Konfigurera l&auml;nkord");
define("LWLANINS_4", "F&ouml;r att konfigurera, klicka p&aring; l&auml;nken i pluginsektionen p&aring; admins f&ouml;rstasida");

?>
