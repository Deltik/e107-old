<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/blogcalendar_menu/languages/Swedish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/13 16:20:20 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("BLOGCAL_L1", "Nyheter f&ouml;r ");
define("BLOGCAL_L2", "Arkiv");

define("BLOGCAL_D1", "M&aring;n");
define("BLOGCAL_D2", "Tis");
define("BLOGCAL_D3", "Ons");
define("BLOGCAL_D4", "Tor");
define("BLOGCAL_D5", "Fre");
define("BLOGCAL_D6", "L&ouml;r");
define("BLOGCAL_D7", "S&ouml;n");

define("BLOGCAL_M1", "Januari");
define("BLOGCAL_M2", "Februari");
define("BLOGCAL_M3", "Mars");
define("BLOGCAL_M4", "April");
define("BLOGCAL_M5", "Maj");
define("BLOGCAL_M6", "Juni");
define("BLOGCAL_M7", "Juli");
define("BLOGCAL_M8", "Augusti");
define("BLOGCAL_M9", "September");
define("BLOGCAL_M10", "Oktober");
define("BLOGCAL_M11", "November");
define("BLOGCAL_M12", "December");

define("BLOGCAL_1", "Nyhets&auml;mnen");

define("BLOGCAL_CONF1", "M&aring;nader/rad");
define("BLOGCAL_CONF2", "Cellpaddning");
define("BLOGCAL_CONF3", "Uppdatera menyinst&auml;llningarna");
define("BLOGCAL_CONF4", "BlogCal menykonfiguration");
define("BLOGCAL_CONF5", "BlogCal menykonfiguration sparad");

define("BLOGCAL_ARCHIV1", "V&auml;lj arkiv");

?>