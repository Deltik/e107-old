<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Swedish/lan_forum_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("FOR_FP_1", "Forum");

?>
