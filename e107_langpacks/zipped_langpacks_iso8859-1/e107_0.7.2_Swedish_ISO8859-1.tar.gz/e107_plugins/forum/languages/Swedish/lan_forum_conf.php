<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Swedish/lan_forum_conf.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/13 16:20:21 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "R&ouml;stning raderad.");
define("FORLAN_6", "Tr&aring;d raderad");
define("FORLAN_7", "svar raderade");
define("FORLAN_8", "Radering avbruten.");
define("FORLAN_9", "Tr&aring;d flyttad.");
define("FORLAN_10", "Flyttning avbruten.");
define("FORLAN_11", "Tillbaka till forum");
define("FORLAN_12", "Forumkonfiguration");
define("FORLAN_13", "&Auml;r du absolut s&auml;ker p&aring; att du vill radera denna r&ouml;stningen?&lt;br /&gt;V&auml;l raderad kan den &lt;b&gt;&lt;u&gt;inte&lt;/u&gt;&lt;/b&gt; &aring;terf&aring;s.");
define("FORLAN_14", "Avbryt");
define("FORLAN_15", "Bekr&auml;fta radering av inl&auml;gg");
define("FORLAN_16", "Bekr&auml;fta radering av r&ouml;stning");
define("FORLAN_17", "inlagd av");
define("FORLAN_18", "&Auml;r du absolut s&auml;ker p&aring; att du vill radera detta forum");
define("FORLAN_19", "tr&aring;d och dess relaterade inl&auml;gg?");
define("FORLAN_20", "r&ouml;stningen kommer ocks&aring; att raderas");
define("FORLAN_21", "V&auml;l raderade kan");
define("FORLAN_22", "inl&auml;gg?&lt;br /&gt;V&auml;l raderat kan det");
define("FORLAN_23", "inte&lt;/u&gt;&lt;/b&gt; &aring;terf&aring;s");
define("FORLAN_24", "Flytta tr&aring;d till forum");
define("FORLAN_25", "Flytta tr&aring;d");
define("FORLAN_26", "Svar raderat");

define("FORLAN_27", "flyttat");

?>