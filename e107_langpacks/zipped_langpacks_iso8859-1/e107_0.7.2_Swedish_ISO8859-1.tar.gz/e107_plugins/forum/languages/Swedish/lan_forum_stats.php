<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Swedish/lan_forum_stats.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/13 16:20:21 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Forumstatistik");

define("FSLAN_1", "Generellt");
define("FSLAN_2", "Forum startades");
define("FSLAN_3", "&Ouml;ppet f&ouml;r");
define("FSLAN_4", "Inl&auml;gg totalt");
define("FSLAN_5", "Forum&auml;mnen");
define("FSLAN_6", "Forumsvar");
define("FSLAN_7", "Forum tr&aring;dvisningar");
define("FSLAN_8", "Databas storlek (Endast forumtabeller)");
define("FSLAN_9", "Genomsnittlig radl&auml;ngd i forumtabell");
define("FSLAN_10", "Mest aktiva &auml;mne");
define("FSLAN_11", "Rang");
define("FSLAN_12", "&Auml;mne");
define("FSLAN_13", "Svar");
define("FSLAN_14", "Startad av");
define("FSLAN_15", "Datum");
define("FSLAN_16", "Mest visade &auml;mne");
define("FSLAN_17", "Visningar");
define("FSLAN_18", "Toppskribenter");
define("FSLAN_19", "Namn");
define("FSLAN_20", "Inl&auml;gg");
define("FSLAN_21", "Flest startade &auml;mnen");
define("FSLAN_22", "Flest svar skrivna");
define("FSLAN_23", "Forumstatistik");
define("FSLAN_24", "Genomsnittligt antal inl&auml;gg per dag");

?>