<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/forum/languages/Swedish/lan_newforumposts_menu.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("NFP_1", "Alla senaste inl&auml;gg &auml;r utanf&ouml;r din anv&auml;ndarklass, kan ej visa dem.");
define("NFP_2", "Inga inl&auml;gg &auml;nnu");
define("NFP_3", "Menykonfiguration f&ouml;r nya foruminl&auml;gg sparad");
define("NFP_4", "Rubrik");
define("NFP_5", "Antal inl&auml;gg att visa?");
define("NFP_6", "Antal tecken att visa?");
define("NFP_7", "Postfix f&ouml;r f&ouml;r l&aring;nga inl&auml;gg?");
define("NFP_8", "Visa ursprungliga &auml;mnen i meny?");
define("NFP_9", "Uppdatera menyinst&auml;llningar");
define("NFP_10", "Menykonfiguration f&ouml;r nya foruminl&auml;gg");
define("NFP_11", "Postad av");

?>