<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/forum/languages/Swedish/lan_forum_uploads.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forumuppladdningar");

define('FRMUP_1','Uppladdade filer i forum');
define('FRMUP_2','Fil raderad');
define('FRMUP_3','Fel: Kan inte radera filen');
define('FRMUP_4','Filradering');
define('FRMUP_5','Filnamn');
define('FRMUP_6','Resultat');
define('FRMUP_7','Funnen i tr&aring;d');
define('FRMUP_8','HITTADES EJ');
define('FRMUP_9','Inga uppladdade filer hittades');
define('FRMUP_10','Radera');

?>