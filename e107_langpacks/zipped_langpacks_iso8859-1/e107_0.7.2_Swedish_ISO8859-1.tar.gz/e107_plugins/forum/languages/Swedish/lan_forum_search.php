<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/forum/languages/Swedish/lan_forum_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "V&auml;lj forum");
define("FOR_SCH_LAN_3", "Alla forum");
define("FOR_SCH_LAN_4", "Hela inl&auml;gget");
define("FOR_SCH_LAN_5", "Som del av en tr&aring;d");

?>
