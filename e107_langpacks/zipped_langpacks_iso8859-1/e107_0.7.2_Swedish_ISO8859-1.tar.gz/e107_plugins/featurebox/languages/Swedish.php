<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/featurebox/languages/Swedish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/13 16:20:21 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("FBLAN_01", "Finessruta");
define("FBLAN_02", "Denna plugin l&aring;ter dig visa en ruta &ouml;ver dina nyheter med finesser/vad-du-vill i. Dessa meddelanden kan antingen bytas ut slumpm&auml;ssigt eller vara dynamiskt tonade.");
define("FBLAN_03", "Konfigurera finessruta");
define("FBLAN_04", "Finessrutans plugin har installerats. F&ouml;r att l&auml;gga till meddelande och konfigurera, g&aring; tillbaka till admins huvudsida och klicka p&aring; ikonen f&ouml;r finessrutan i plugin sektionen.");
define("FBLAN_05", "Inga meddelande definierade f&ouml;r rutan &auml;nnu");
define("FBLAN_06", "Befintliga meddelanden i finessrutan");
define("FBLAN_07", "Titel/Rubrik");
define("FBLAN_08", "Meddelandetext");
define("FBLAN_09", "Meddelandets synbarhet");
define("FBLAN_10", "Skapa meddelande");
define("FBLAN_11", "Uppdatera meddelande");
define("FBLAN_12", "Typ");
define("FBLAN_13", "Slumpvis visning");
define("FBLAN_14", "Visa endast detta meddelande");
define("FBLAN_15", "Meddelande inladt i databasen.");
define("FBLAN_16", "Meddelande uppdaterat i databasen.");
define("FBLAN_17", "F&auml;lt l&auml;mnat tomt");
define("FBLAN_18", "Meddelandet raderat");
define("FBLAN_19", "Alternativ");
define("FBLAN_20", "Redigera");
define("FBLAN_21", "Radera");
define("FBLAN_22", "Visningstyp");
define("FBLAN_23", "I temaruta");
define("FBLAN_24", "Sl&auml;tt");
define("FBLAN_25", "Mall");
define("FBLAN_26", "Du kan anv&auml;nda en egen mall f&ouml;r varje meddelande, l&auml;gg till mallar i e107_plugins/featurebox/templates/ foldern");

?>