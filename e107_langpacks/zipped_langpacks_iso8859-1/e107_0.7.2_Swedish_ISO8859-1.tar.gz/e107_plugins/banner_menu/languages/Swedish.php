<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/banner_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Annons");
define("BANNER_MENU_L2", "Bannermeny konfiguration sparad");

//v.617
define("BANNER_MENU_L3", "Rubrik");
define("BANNER_MENU_L4", "Kampanj");
define("BANNER_MENU_L5", "Bannermeny konfiguration");
define("BANNER_MENU_L6", "v&auml;lj kampanj att visa i meny");
define("BANNER_MENU_L7", "tillg&auml;ngliga kampanjer");
define("BANNER_MENU_L8", "valda kampanjer");
define("BANNER_MENU_L9", "ta bort vald(a)");
define("BANNER_MENU_L10", "hur skall valda kampanjer visas?");
define("BANNER_MENU_L11", "v&auml;lj visningstyp...");
define("BANNER_MENU_L12", "en kampanj i en meny");
define("BANNER_MENU_L13", "alla valda kampanj i en meny");
define("BANNER_MENU_L14", "alla valda kamanjer i separata menyer");
define("BANNER_MENU_L15", "hur m&aring;nga banners skall visas?");
define("BANNER_MENU_L16", "denna inst&auml;llning anv&auml;nds bara med valen 2 and 3.<br />om det finns f&auml;rre banners &auml;n detta maxv&auml;rde kommer alla tillg&auml;ngliga banners att anv&auml;ndas.");
define("BANNER_MENU_L17", "s&auml;tt antal...");
define("BANNER_MENU_L18", "Uppdatera menyinst&auml;llningarna");

?>