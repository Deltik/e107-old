<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_extended_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/08 06:34:30 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "G&auml;ster: ");
define("ONLINE_EL2", "Medlemmar: ");
define("ONLINE_EL3", "P&aring; denna sida: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Medlemmar");
define("ONLINE_EL6", "Nyaste medlemmen");
define("ONLINE_EL7", "l&auml;ser");

define("ONLINE_EL8", "flest online n&aring;gonsin: ");
define("ONLINE_EL9", "den");

define("TRACKING_MESSAGE", "Online anv&auml;ndarsp&aring;rning &auml;r inte aktiverad. Aktivera den &lt;a href='".e_ADMIN."users.php?options'&gt;h&auml;r&lt;/a&gt;&lt;/span&gt;&lt;br /&gt;");

?>
