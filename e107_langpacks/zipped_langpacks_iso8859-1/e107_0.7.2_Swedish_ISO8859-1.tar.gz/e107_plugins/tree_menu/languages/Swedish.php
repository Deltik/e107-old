<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/tree_menu/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Konfigurera tr&auml;dmeny");
define("TREE_L2", "Uppdatera inst&auml;llningar f&ouml;r tr&auml;dmeny");
define("TREE_L3", "Tr&auml;denykonfiguration sparad.");
define("TREE_L4", "P&aring;");
define("TREE_L5", "Av");

?>
