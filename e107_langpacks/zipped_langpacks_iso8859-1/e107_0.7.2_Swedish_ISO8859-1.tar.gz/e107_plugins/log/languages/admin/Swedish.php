<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/log/languages/admin/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/26 11:12:24 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("ADSTAT_ON", "Till");
define("ADSTAT_OFF", "Fr&aring;n");
define("ADSTAT_L1", "Denna plugin kommer att logga alla bes&ouml;k till din sajt och bygga detaljerade statistikbilder baserade p&aring; den insamlade informationen.");
define("ADSTAT_L2", "Statistikloggaren har installerats. F&ouml;r att aktivera, g&aring; till konfigurationsbilden och klicka p&aring; Aktivera.&lt;br /&gt;&lt;b&gt;Du m&aring;ste s&auml;tta filr&auml;ttigheterns till e107_plugins/log/logs katalogen till 777 (chmod 777)&lt;/b&gt;");
define("ADSTAT_L3", "Statistikloggning");
define("ADSTAT_L4", "Aktivera statistikloggning");
define("ADSTAT_L5", "Statistiktyper");
define("ADSTAT_L6", "Webbl&auml;sare");
define("ADSTAT_L7", "Operativsystem");
define("ADSTAT_L8", "Sk&auml;rmuppl&ouml;sningar / f&auml;rgdjup");
define("ADSTAT_L9", "Bes&ouml;k fr&aring;n l&auml;nder/dom&auml;ner");
define("ADSTAT_L10", "H&auml;nvisare");
define("ADSTAT_L11", "S&ouml;kfr&aring;gor");
define("ADSTAT_L12", "Nollst&auml;ll stats");
define("ADSTAT_L13", "detta raderar stats - var f&ouml;rsiktig!");
define("ADSTAT_L14", "Sidr&auml;knare");
define("ADSTAT_L15", "Uppdatera statistikinst&auml;llningar");
define("ADSTAT_L16", "Sajtstatistik inst&auml;llningar");
define("ADSTAT_L17", "Statistikinst&auml;llningar uppdaterade");
define("ADSTAT_L18", "Till&aring;t &aring;tkomst till huvudstatistiksidan f&ouml;r...");
define("ADSTAT_L19", "Senaste bes&ouml;kare");
define("ADSTAT_L20", "R&auml;kna adminbes&ouml;k");
define("ADSTAT_L21", "Maximum poster att visa p&aring; statistiksidan");
define("ADSTAT_L22", "K&ouml;r uppdateringsrutin");
define("ADSTAT_L23", "Loggar fr&aring;n en tidigare version av e107 har hittats, uppdatera dem h&auml;r");
define("ADSTAT_L24", "G&aring; till uppdateringsskriptet");
define("ADSTAT_L25", "Vald statistik nollst&auml;lld");
define("ADSTAT_L26", "Radera sidposter");
define("ADSTAT_L27", "om din statistik har felaktiga sidor kan du ta bort dem h&auml;r");
define("ADSTAT_L28", "&Ouml;ppna sida");


define("ADSTAT_L29", "Sidonamn");
define("ADSTAT_L30", "Markera f&ouml;r att ta bort");
define("ADSTAT_L31", "Ta bort valda sidor");
define("ADSTAT_L32", "St&auml;da sidor");
define("ADSTAT_L10", "H&auml;nvisningar");
define("ADSTAT_L10", "H&auml;nvisningar");

?>
