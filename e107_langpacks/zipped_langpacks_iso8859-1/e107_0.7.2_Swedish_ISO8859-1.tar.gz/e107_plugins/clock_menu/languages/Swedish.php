<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/16 15:45:54 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define('CLOCK_MENU_L1', 'Klockmeny konfiguration sparad');
define('CLOCK_MENU_L2', 'Rubrik');
define('CLOCK_MENU_L3', 'Uppdatera menyinst&auml;llningar');
define('CLOCK_MENU_L4', 'Klockmeny konfiguration');
define('CLOCK_MENU_L5', 'M&aring;ndag,');
define('CLOCK_MENU_L6', 'Tisdag,');
define('CLOCK_MENU_L7', 'Onsdag,');
define('CLOCK_MENU_L8', 'Torsdag,');
define('CLOCK_MENU_L9', 'Fredag,');
define('CLOCK_MENU_L10', 'L&ouml;rdag,');
define('CLOCK_MENU_L11', 'S&ouml;ndag,');
define('CLOCK_MENU_L12', 'Januari');
define('CLOCK_MENU_L13', 'Februari');
define('CLOCK_MENU_L14', 'Mars');
define('CLOCK_MENU_L15', 'April');
define('CLOCK_MENU_L16', 'Maj');
define('CLOCK_MENU_L17', 'Juni');
define('CLOCK_MENU_L18', 'Juli');
define('CLOCK_MENU_L19', 'Augusti');
define('CLOCK_MENU_L20', 'September');
define('CLOCK_MENU_L21', 'Oktober');
define('CLOCK_MENU_L22', 'November');
define('CLOCK_MENU_L23', 'December');
define('CLOCK_MENU_L24', '');

?>
