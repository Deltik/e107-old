<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/clock_menu/languages/admin/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Klockmeny konfiguration sparad");
define("CLOCK_AD_L2", "Rubrik");
define("CLOCK_AD_L3", "Uppdatera menyinst&auml;llninar");
define("CLOCK_AD_L4", "Klockmenykonfiguration");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Om markerad kommer tid att visas i amerikanskt format (0-12 AM/PM format). Avmarkerad s&aring; visas 'milit&auml;rt/Europeiskt' format 0-24.");
define("CLOCK_AD_L7", "Datumprefix");
define("CLOCK_AD_L8", "Om ditt spr&aring;k kr&auml;ver ett kort ord framf&ouml;r datumet (T.ex 'le' f&ouml;r franska eller 'den' f&ouml;r svenska...), s&aring; anv&auml;nd detta f&auml;ltet. Om inte, l&auml;mna tomt.");
define("CLOCK_AD_L9", "Suffix 1");
define("CLOCK_AD_L10", "Suffix 2");
define("CLOCK_AD_L11", "Suffix 3");
define("CLOCK_AD_L12", "Suffix 4 och mer");
define("CLOCK_AD_L13", "Om ditt spr&aring;k beh&ouml;ver ett suffix direkt efter datumets siffror, fyll d&aring; i dessa f&auml;lt med bara suffixen. (T.ex: 'sta' f&ouml;r 1, 'a' f&ouml;r 2, 'e' f&ouml;r 3 och 'de' f&ouml;r 4 och s&aring; vidare). Om inte, l&auml;mna tomma f&auml;lt.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");

?>
