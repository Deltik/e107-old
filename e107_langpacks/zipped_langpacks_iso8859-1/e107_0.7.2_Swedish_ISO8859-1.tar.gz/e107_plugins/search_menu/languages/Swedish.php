<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/search_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:07 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LAN_180", "S&ouml;k");

?>
