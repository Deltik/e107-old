<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/rss_menu/languages/Swedish.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/10/17 10:58:03 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " kan distribueras genom att anv&auml;nda dessa rss fl&ouml;den.");
define("BACKEND_MENU_L2", "RSS fl&ouml;den");

define("BACKEND_MENU_L3", "V&aring;ra nyheter");
define("BACKEND_MENU_L4", "V&aring;ra kommentarer");
define("BACKEND_MENU_L5", "V&aring;ra forumtr&aring;dar");
define("BACKEND_MENU_L6", "V&aring;ra foruminl&auml;gg");

define("BACKEND_MENU_L7", "V&aring;ra chattruteinl&auml;gg");
define("BACKEND_MENU_L8", "V&aring;ra buggsp&aring;rningsrapporter");
define("BACKEND_MENU_L9", "V&aring;ra nerladdningar");

define("RSS_LAN01", "Aktivera separata fl&ouml;den f&ouml;r varje nyhetskategori?");
define("RSS_LAN02", "Aktivera separata fl&ouml;den f&ouml;r varje nerladdningskategori?");

define("RSS_NEWS","Nyheter");
define("RSS_COM","Kommentarer");
define("RSS_ART","Artiklar");
define("RSS_REV", "Recensioner");
define("RSS_FT","Forumtr&aring;dar");
define("RSS_FP","Foruminl&auml;gg");
define("RSS_FSP","Forum specifikt inl&auml;gg");
define("RSS_BUG","Buggsp&aring;rare");
define("RSS_FOR","Forum");
define("RSS_DL","Nerladdningar");

?>
