<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/pdf/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Skapande av PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Denna plugin &auml;r nu redo att anv&auml;ndas.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF preferenser");
define("PDF_LAN_3", "aktiverad");
define("PDF_LAN_4", "avaktiverad");
define("PDF_LAN_5", "Sidomarginal v&auml;nster");
define("PDF_LAN_6", "Sidomarginal h&ouml;ger");
define("PDF_LAN_7", "Sidomarginal topp");
define("PDF_LAN_8", "Fontfamilj");
define("PDF_LAN_9", "Standard fontstorlek");
define("PDF_LAN_10", "Fontstorlek sajtenamn");
define("PDF_LAN_11", "Fontstorlek sidourl");
define("PDF_LAN_12", "Fontstorlek sidnummer");
define("PDF_LAN_13", "Visa logo p&aring; pdf?");
define("PDF_LAN_14", "Visa sajtnamn p&aring; pdf?");
define("PDF_LAN_15", "Visa skapares sidourl p&aring; pdf?");
define("PDF_LAN_16", "Visa sidonummer p&aring; pdf?");
define("PDF_LAN_17", "Uppdatera");
define("PDF_LAN_18", "PDF preferenser sparades");
define("PDF_LAN_19", "Sida");
define("PDF_LAN_20", "Felrapportering");

?>