<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/chatbox_menu/languages/Swedish/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CHATBOX_L1", "Kan inte acceptera inl&auml;gget eftersom anv&auml;ndarnamnet &auml;r registrerat - om det &auml;r ditt namn, logga in f&ouml;r att posta inl&auml;gg.");
define("CHATBOX_L2", "Chattruta");
define("CHATBOX_L3", "Du m&aring;ste vara inloggad f&ouml;r att posta kommentarer p&aring; denna sajt - logga in, eller om du inte &auml;r registrerad klicka &lt;a href='".e_BASE."signup.php'&gt;h&auml;r&lt;/a&gt; f&ouml;r att registrera dig");
define("CHATBOX_L4", "Skicka");
define("CHATBOX_L5", "&Aring;terst&auml;ll");
define("CHATBOX_L6", "[blockerat av admin]");
define("CHATBOX_L7", "H&auml;v blockering");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Blockera");
define("CHATBOX_L10", "Radera");
define("CHATBOX_L11", "Inga meddelanden &auml;nnu.");
define("CHATBOX_L12", "Visa alla poster");
define("CHATBOX_L13", "moderera chattruta");
define("CHATBOX_L14", "Smajlys");
define("CHATBOX_L15", "Inl&auml;gg f&ouml;r l&aring;ngt, eller tomt inl&auml;gg skickat");
define("CHATBOX_L16", "Anonym");
define("CHATBOX_L17", "Dublettinl&auml;gg");
define("CHATBOX_L18", "Chattrutans meddelande modererade");
define("CHATBOX_L19", "Du kan bara skriva ett inl&auml;gg per ".FLOODTIMEOUT." sekunder");

define("CHATBOX_L20", "Chattruta (alla inl&auml;gg)");
define("CHATBOX_L21", "Chattinl&auml;gg");
define("CHATBOX_L22", "den");
define("CHATBOX_L23", "Fel!");
define("CHATBOX_L24", "Du har inte r&auml;ttigheter att se denna sida.");
define("CHATBOX_L25", "[ detta inl&auml;gg har blockerats av admin ]");
// Notify
define("NT_LAN_CB_1", "Chattruteh&auml;ndelser");
define("NT_LAN_CB_2", "Meddelande postat");
define("NT_LAN_CB_3", "Postat av");
define("NT_LAN_CB_4", "IP-adress");
define("NT_LAN_CB_5", "Meddelande");
define("NT_LAN_CB_6", "Chattruteinl&auml;gg postat");

?>
