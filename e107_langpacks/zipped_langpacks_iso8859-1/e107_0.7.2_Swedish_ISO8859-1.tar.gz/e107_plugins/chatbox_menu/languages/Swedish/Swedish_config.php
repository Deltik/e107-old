<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Swedish/Swedish_config.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Chattruteinst&auml;llningar uppdaterade.");
define("CHBLAN_2", "Modererat.");
define("CHBLAN_3", "Inga chattruteinl&auml;gg &auml;nnu.");
define("CHBLAN_4", "Medlem");
define("CHBLAN_5", "G&auml;st");
define("CHBLAN_6", "h&auml;v blockering");
define("CHBLAN_7", "blockera");
define("CHBLAN_8", "radera");
define("CHBLAN_9", "Moderera chattruta");
define("CHBLAN_10", "Moderera inl&auml;gg");
define("CHBLAN_11", "Chattruteinl&auml;gg att visa");
define("CHBLAN_12", "m&auml;ngd inl&auml;gg visade i chattrutan");
define("CHBLAN_13", "Byt ut l&auml;nkar");
define("CHBLAN_14", "om markerad kommer l&auml;nkar att bytas ut mot texten i rutan nedan");
define("CHBLAN_15", "Utbytesstr&auml;ng om aktiverad");
define("CHBLAN_16", "kommer l&auml;nkar att bytas ut mot denna text");
define("CHBLAN_17", "Orbrytningsl&auml;ngd");
define("CHBLAN_18", "ord l&auml;ngre &auml;n det antal tecken du anger h&auml;r kommer att brytas");
define("CHBLAN_19", "Uppdatera chattruteinst&auml;llningar");
define("CHBLAN_20", "Chattruteinst&auml;llningar");
define("CHBLAN_21", "Rensa");
define("CHBLAN_22", "Radera inl&auml;gg &auml;ldre &auml;n en viss tid");
define("CHBLAN_23", "Radera inl&auml;gg &auml;ldre &auml;n ");

define("CHBLAN_24", "En dag");
define("CHBLAN_25", "En vecka");
define("CHBLAN_26", "En m&aring;nad");
define("CHBLAN_27", "- Radera alla inl&auml;gg -");
define("CHBLAN_28", "Chattrutan rensad.");

define("CHBLAN_29", "Visa chattrutan inuti ett rullande lager");
define("CHBLAN_30", "Lagrets h&ouml;jd");
define("CHBLAN_31", "Visa smajlys");
define("CHBLAN_32", "Moderator anv&auml;ndarklass");

define("CHBLAN_33", "Anv&auml;ndare omr&auml;knade");
define("CHBLAN_34", "R&auml;kna om anv&auml;ndarpostningar");
define("CHBLAN_35", "R&auml;kna om");
define("CHBLAN_36", "Visningsalternativ f&ouml;r chattruta");
define("CHBLAN_37", "Normal chattruta");
define("CHBLAN_38", "Anv&auml;nd javascriptkod f&ouml;r att uppdatera inneh&aring;llet dynamiskt (AJAX)");

?>