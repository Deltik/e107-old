<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/compliance_menu/languages/Swedish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/13 16:20:21 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("COMPLIANCE_L1", "W3C &ouml;verensst&auml;mmelse");

?>