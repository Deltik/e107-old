<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/online_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("ONLINE_L1", "G&auml;ster: ");
define("ONLINE_L2", "Medlemmar: ");
define("ONLINE_L3", "P&aring; denna sida: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Medlemmar");
define("ONLINE_L6", "senaste");
define("TRACKING_MESSAGE", "Online anv&auml;ndarsp&aring;rning &auml;r f&ouml;r n&auml;rvarande inaktiverad, aktivera den &lt;a href='".e_ADMIN."users.php?options'&gt;h&auml;r&lt;/a&gt;&lt;/span&gt;<br />");

?>
