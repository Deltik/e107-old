<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/review_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:07 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("LAN_190", "Skicka in recension");
define("LAN_RVW_1", "Uppdatera menyinst&auml;llningar");
define("LAN_RVW_2", "Recensionsmenyns konfiguration sparad");
define("LAN_RVW_3", "Rubrik");
define("LAN_RVW_4", "Antal recensioner att visa");
define("LAN_RVW_5", "Visa recensionskategorier i meny?");
define("LAN_RVW_6", "Titel p&aring; sidan f&ouml;r recensionslista");
define("LAN_RVW_7", "Visa l&auml;nk till att skicka in recension?");
define("LAN_RVW_8", "Recensioners menykonfiguration");

?>
