<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/userlanguage_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/07/12 16:18:11 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("UTHEME_MENU_L1", "S&auml;tt spr&aring;k");
define("UTHEME_MENU_L2", "V&auml;lj spr&aring;k");
define("UTHEME_MENU_L3", "Tabeller");

?>
