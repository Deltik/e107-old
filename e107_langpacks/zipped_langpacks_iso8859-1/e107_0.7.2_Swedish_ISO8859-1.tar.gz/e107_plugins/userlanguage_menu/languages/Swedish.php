<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/userlanguage_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:07 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("UTHEME_MENU_L1", "S&auml;tt spr&aring;k");
define("UTHEME_MENU_L2", "V&auml;lj spr&aring;k");
define("UTHEME_MENU_L3", "Tabeller");

?>
