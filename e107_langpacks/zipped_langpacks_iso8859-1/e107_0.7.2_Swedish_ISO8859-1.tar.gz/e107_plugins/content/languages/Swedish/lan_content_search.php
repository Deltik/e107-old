<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/content/languages/Swedish/lan_content_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Inneh&aring;ll");
define("CONT_SCH_LAN_2", "Alla inneh&aring;llskategorier");
define("CONT_SCH_LAN_3", "Postat som svar till");

?>
