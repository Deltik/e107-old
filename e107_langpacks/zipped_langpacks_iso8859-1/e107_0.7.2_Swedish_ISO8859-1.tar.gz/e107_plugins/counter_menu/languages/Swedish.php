<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/counter_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 09:33:06 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/

define("COUNTER_L1", "Adminbes&ouml;k r&auml;knas inte.");
define("COUNTER_L2", "Denna sida idag");
define("COUNTER_L3", "Totalt");
define("COUNTER_L4", "F&ouml;r alltid p&aring; denna sida...");
define("COUNTER_L5", "unika");
define("COUNTER_L6", "Sajt...");
define("COUNTER_L7", "R&auml;knare");
define("COUNTER_L8", "Adminmeddelande: &lt;b&gt;Statistikloggning &auml;r inte aktiverad.&lt;/b&gt;<br />F&ouml;r att aktivera m&aring;ste du installera statistikloggningspluginen fr&aring;n din &lt;a href='".e_ADMIN."plugin.php'&gt;plugin hanterare&lt;/a&gt;, och sedan aktivera den fr&aring;n &lt;a href='".e_PLUGIN."log/admin_config.php'&gt;konfigurationssidan&lt;/a&gt;.");

?>
