<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/comment_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:35 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("CM_L1", "Inga kommentarer &auml;nnu.");
define("CM_L2", "");
define("CM_L3", "Rubrik");
define("CM_L4", "Antal kommentarer att visa?");
define("CM_L5", "Antal tecken att visa?");
define("CM_L6", "Postfix f&ouml;r f&ouml;r l&aring;nga kommentarer?");
define("CM_L7", "Visa originaltitel i meny?");
define("CM_L8", "Konfiguration f&ouml;r nya kommentarer");
define("CM_L9", "Uppdatera menyinst&auml;llningar");
define("CM_L10", "Kommentarsmeny konfiguration sparad");

?>
