<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("METLAN_1", "Meta tag-ek friss�tve");
define("METLAN_2", "Meta tag-ek");
define("METLAN_3", "Be�ll�t�sok ment�se");
define("METLAN_4", "Friss�tve");
define("METLAN_5", "Az oldal le�r�s�t");
define("METLAN_6", "Add, meg, a, kulcsszavak, list�j�t, kulcssz�, vessz�, sz�k�z, form�ban");
define("METLAN_7", "Copyright inform�ci�k");
define("METLAN_8", "Meta Tag-ek");

define("METLAN_9", "Le�r�s");
define("METLAN_10", "Kulcsszavak");
define("METLAN_11", "Szerz�i jog");
define("METLAN_12", "Haszn�ld a H�rek c�m�t �s az �sszegz�st meta-le�r�sk�nt a h�rek oldalon.");
define("METLAN_13", "Szerz�");
?>
