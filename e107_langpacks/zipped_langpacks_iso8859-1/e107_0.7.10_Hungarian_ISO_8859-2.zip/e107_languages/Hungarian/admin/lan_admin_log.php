<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Napl� (Log)");
define("LAN_ADMINLOG_1", "D�tum");
define("LAN_ADMINLOG_2", "C�m");
define("LAN_ADMINLOG_3", "Le�r�s");
define("LAN_ADMINLOG_4", "Felhaszn�l� IP");
define("LAN_ADMINLOG_5", "Felhaszn�l� ID");
define("LAN_ADMINLOG_6", "T�j�koztat� Ikon");
define("LAN_ADMINLOG_7", "T�j�koztat� �zenet");
define("LAN_ADMINLOG_8", "Figyelmeztet� Ikon");
define("LAN_ADMINLOG_9", "Figyelmeztet� �zenet");
define("LAN_ADMINLOG_10", "Riaszt�s Ikon");
define("LAN_ADMINLOG_11", "Riaszt�s �zenet");
define("LAN_ADMINLOG_12", "V�gzetes hiba Ikon");
define("LAN_ADMINLOG_13", "V�gzetes hiba �zenet");

?>
