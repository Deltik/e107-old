<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UCSLAN_1", "�rtes�t�s k�ld�se");
define("UCSLAN_2", "Jogosults�gok friss�t�se");
define("UCSLAN_3", "Kedves");
define("UCSLAN_4", "Jogosults�gaid friss�tve a k�vetkez� oldalon:");
define("UCSLAN_5", "Mostant�l el�rheted a k�vetkez� r�szleg(ek)et:");
define("UCSLAN_6", "Csoport be�ll�t�sa felhaszn�l�ra");
define("UCSLAN_7", "Csoport be�ll�t�sa");
define("UCSLAN_8", "Felhaszn�l� �rtes�t�se");
define("UCSLAN_9", "Csoportok friss�tve");
define("UCSLAN_10", "�dv�zlettel");
?>