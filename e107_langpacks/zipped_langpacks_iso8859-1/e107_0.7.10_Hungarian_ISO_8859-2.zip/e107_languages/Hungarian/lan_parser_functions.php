<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_GUEST", "Vend�g");
define("LAN_WROTE", "�rta"); // as in John wrote.."  ";
?>
