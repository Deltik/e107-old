<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Tagok");

define("LAN_20", "Hiba");
define("LAN_112", "E-mail c�m: ");
define("LAN_115", "ICQ azonos�t�: ");
define("LAN_116", "AIM azonos�t�: ");
define("LAN_117", "MSN azonos�t�: ");
define("LAN_118", "Sz�let�snap: ");
define("LAN_119", "Lakhely: ");
define("LAN_120", "Al��r�s: ");
define("LAN_137", "Err�l a felhaszn�l�r�l nem �ll rendelkez�sre inform�ci�, mert nem regisztr�lt");
define("LAN_138", "Regisztr�lt tagok: ");
define("LAN_139", "Rendez�s: ");
define("LAN_140", "Regisztr�lt tagok");
define("LAN_141", "M�g nem regisztr�lt senki.");
define("LAN_142", "Tag");
define("LAN_143", "[k�r�sre elrejtve]");
define("LAN_144", "Weboldal c�me: ");
define("LAN_145", "Regisztr�ci� d�tuma");
define("LAN_146", "L�togat�sok sz�ma a regisztr�ci� �ta: ");
define("LAN_147", "Chatbox �zenetek sz�ma: ");
define("LAN_148", "Hozz�sz�l�sok sz�ma: ");
define("LAN_149", "F�rum �zenetek: ");
define("LAN_308", "Val�di n�v: ");
define("LAN_400", "�rv�nytelen felhaszn�l�.");
define("LAN_401", "Nincs");
define("LAN_402", "Profil");
define("LAN_403", "Oldal statisztik�k");
define("LAN_404", "Utols� l�togat�s");
define("LAN_405", "nappal ezel�tt");
define("LAN_406", "Rang");
define("LAN_407", "Nincs");
define("LAN_408", "Nincs k�p");
define("LAN_409", "pont");
define("LAN_410", "Egy�b");
define("LAN_411", "Adataid m�dos�t�sa");
define("LAN_412", "Tag adatainak m�dos�t�sa");
define("LAN_413", "K�p t�rl�se");
define("LAN_414", "El�z� tag");
define("LAN_415", "K�vetkez� tag");
define("LAN_416", "Az oldal csak bel�p�s ut�n �rhet� el");
define("LAN_417", "F� adminisztr�tor");
define("LAN_418", "Adminisztr�tor");
define("LAN_419", "Mutat");
define("LAN_420", "Cs�kken�");
define("LAN_421", "N�vekv�");
define("LAN_422", "Mehet");
define("LAN_423", "A tag hozz�sz�l�sainak megtekint�se");
define("LAN_424", "A tag f�rum�zeneteinek megtekint�se");
define("LAN_425", "Priv�t �zenet k�ld�se");
define("LAN_426", "ezel�tt");

define("USERLAN_1", "Felhaszn�l�i �rt�kel�s");
define("USERLAN_2", "Nincs jogosults�god az oldal megtekint�s�re.");
?>
