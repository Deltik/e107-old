<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("TOP_LAN_0", "A legt�bb �zenetet �r� a f�rumban");
define("TOP_LAN_1", "Felhaszn�l�n�v");
define("TOP_LAN_2", "�zenetek");
define("TOP_LAN_3", "A legt�bb hozz�sz�l�st �r� tag");
define("TOP_LAN_4", "Hozz�sz�l�sok");
define("TOP_LAN_5", "A legt�bb chatbox �zenetet �r� tag");
define("TOP_LAN_6", "Weblap �rt�kel�se");

//v.616
define("LAN_1", "T�ma");
define("LAN_2", "K�ld�");
define("LAN_3", "Megtekint�s");
define("LAN_4", "V�laszok");
define("LAN_5", "Utols� �zenet");
define("LAN_6", "T�m�k");
define("LAN_7", "Legakt�vabb t�m�k");
define("LAN_8", "Legt�bb �zenetet �r� tagok");

?>
