<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LANHELP_1", "Fekete");
define("LANHELP_2", "K�k");
define("LANHELP_3", "Barna");
define("LANHELP_4", "Ci�n");
define("LANHELP_5", "S�t�tk�k");
define("LANHELP_6", "S�t�tpiros");
define("LANHELP_7", "Z�ld");
define("LANHELP_8", "Tintak�k");
define("LANHELP_9", "Olajz�ld");
define("LANHELP_10", "Narancs");
define("LANHELP_11", "V�r�s");
define("LANHELP_12", "Lila");
define("LANHELP_13", "Feh�r");
define("LANHELP_14", "S�rga");

define("LANHELP_15", "Apr�");
define("LANHELP_16", "Kicsi");
define("LANHELP_17", "Norm�l");
define("LANHELP_18", "Nagy");
define("LANHELP_19", "Nagyobb");
define("LANHELP_20", "�ri�s");

define("LANHELP_21", "Sz�n ..");
define("LANHELP_22", "M�ret ..");

define("LANHELP_23", "Link besz�r�sa: [link]http://teoldalad.hu[/link] vagy  [link=http://teoldalad.hu]A te oldalad[/link]");
define("LANHELP_24", "F�lk�v�r: [b]F�lk�v�r sz�veg[/b]", "font-weight:bold; width: 20px");
define("LANHELP_25", "D�lt: [i]D�lt sz�veg[/i]", "font-style:italic; width: 20px");
define("LANHELP_26", "Al�h�zott: [u]Al�h�zott sz�veg[/u]", "text-decoration: underline; width: 20px");
define("LANHELP_27", "K�p besz�r�sa: [img]k�p.jpg[/img]");
define("LANHELP_28", "K�z�pre z�r�s: [center]K�z�pre igaz�tott sz�veg[/center]");
define("LANHELP_29", "Balra z�r�s: [left]Balra igaz�tott sz�veg[/left]");
define("LANHELP_30", "Jobbra z�r�s: [right]Jobbra igaz�tott sz�veg[/right]");
define("LANHELP_31", "Blockquote: [blockquote]Sz�veg be�gyaz�sa[/blockquote]");
define("LANHELP_32", "K�d - el�re form�zott sz�veg: [code]\$foo = bah;[/code]");
define("LANHELP_33", "HTML - megsz�nteti a sort�r�seket: [html]<table><tr><td> stb.[/html]");
define("LANHELP_34", "[newpage] vagy [newpage=c�m] Newpage k�d besz�r�sa, a cikket t�bb oldalra osztja");
define("LANHELP_35", "hiperlink url");
define("LANHELP_36", "Sorsz�m n�lk�l: [list]line1*line2*line3[/list] Sorsz�mozva: [list=type]line1*line2*line3[/list]");

define("LANHELP_37", "K�p beilleszt�se az e107_images/newspost_images/ k�nyvt�rb�l");
define("LANHELP_38", "A teljes k�phez link gener�l�dott");

define("LANHELP_39", "Let�lt�s link beilleszt�se a megl�v� let�lt�st�l");
define("LANHELP_40", "Jelenleg nincs let�lt�s");

define("LANHELP_41", "Bet�m�ret...");
define("LANHELP_42", "K�p kiv�laszt�sa...");
define("LANHELP_43", "Let�lt�s kiv�laszt�sa...");
define("LANHELP_44", "Katt az emotikonok megnyit�s�hoz ...");
define("LANHELP_45", "K�p beilleszt�se az e107_images/custom/ k�nyvt�rb�l");
define("LANHELP_46", "* Nincs file itt: ");

define("LANHELP_47", "Flash beilleszt�se: [flash=width,height]http://www.example.com/file.swf[/flash]");
?>
