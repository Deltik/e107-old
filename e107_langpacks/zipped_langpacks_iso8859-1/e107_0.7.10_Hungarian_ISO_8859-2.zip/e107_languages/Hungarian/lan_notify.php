<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NT_LAN_US_1", "Felhaszn�l�i regisztr�ci�");

define("NT_LAN_UV_1", "Felhaszn�l�i regisztr�ci� ellen�rz�se");
define("NT_LAN_UV_2", "Felhaszn�l� ID: ");
define("NT_LAN_UV_3", "Felhaszn�l� Bejelentkez� N�v: ");
define("NT_LAN_UV_4", "Felhaszn�l� IP: ");


define("NT_LAN_LI_1", "Felhaszn�l� bejelentkezett");

define("NT_LAN_LO_1", "Felhaszn�l� kijelentkezett");
define("NT_LAN_LO_2", " kijelentkezett az oldalr�l");

define("NT_LAN_FL_1", "Kitilt�s");
define("NT_LAN_FL_2", "Kitiltott IP c�me");

define("NT_LAN_SN_1", "Bek�ld�tt h�r");

define("NT_LAN_NU_1", "Friss�tve");

define("NT_LAN_ND_1", "H�r t�r�lve");
define("NT_LAN_ND_2", "T�r�lt h�r id");

?>