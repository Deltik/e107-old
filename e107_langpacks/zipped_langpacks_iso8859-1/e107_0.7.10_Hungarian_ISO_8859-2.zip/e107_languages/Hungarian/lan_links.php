<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Linkek");

define("LAN_61", "Link kateg�ri�k");
define("LAN_62", "kateg�ri�ban");
define("LAN_63", "kateg�ri�ban");
define("LAN_64", "ebben a kateg�ri�ban");
define("LAN_65", "link");
define("LAN_66", "link");
define("LAN_67", "�sszes link megjelen�t�se");
define("LAN_68", "Szerkeszt�s");
define("LAN_69", "T�rl�s");
define("LAN_86", "Kateg�ria:");
define("LAN_88", "Hivatkoz�sok:");
define("LAN_89", "Admin: ");
define("LAN_90", "�j link hozz�ad�sa a kateg�ri�hoz");
define("LAN_91", "�j kateg�ria l�trehoz�sa");

define("LAN_92", "Link bek�ld�se");
define("LAN_93", "A bek�ld�tt linket az admin megvizsg�lja, ha megfelel a k�vetelm�nyeknek, beker�l a linkek k�z�.");
define("LAN_94", "Link neve:");
define("LAN_95", "Link URL-je:");
define("LAN_96", "Link le�r�sa:");
define("LAN_97", "URL a link gombhoz:");
define("LAN_98", "Link bek�ld�se");

define("LAN_99", "K�sz�nj�k");
define("LAN_100", "A link elmentve, az admin meg fogja vizsg�lni.");
define("LAN_101", "Link bek�ld�se");

define("LAN_102", "Itt");
define("LAN_103", "van");
define("LAN_104", "van");
define("LAN_105", "�sszesen");
define("LAN_106", "Az al�h�zott mez�k k�telez�k.");

define("LAN_Links_1", "�sszes link");
define("LAN_Links_2", "�sszes aktiv�lt link");
define("LAN_LINKS_3", "Anonymous");
?>
