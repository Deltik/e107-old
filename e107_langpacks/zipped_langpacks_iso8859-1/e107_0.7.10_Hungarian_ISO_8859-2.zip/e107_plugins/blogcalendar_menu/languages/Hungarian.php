<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("BLOGCAL_L1", " h�rei");
define("BLOGCAL_L2", "Arch�vum");

define("BLOGCAL_D1", "H");
define("BLOGCAL_D2", "K");
define("BLOGCAL_D3", "Sze");
define("BLOGCAL_D4", "Cs");
define("BLOGCAL_D5", "P");
define("BLOGCAL_D6", "Szo");
define("BLOGCAL_D7", "V");

define("BLOGCAL_M1", "janu�r");
define("BLOGCAL_M2", "febru�r");
define("BLOGCAL_M3", "m�rcius");
define("BLOGCAL_M4", "�prilis");
define("BLOGCAL_M5", "m�jus");
define("BLOGCAL_M6", "j�nius");
define("BLOGCAL_M7", "j�lius");
define("BLOGCAL_M8", "augusztus");
define("BLOGCAL_M9", "szeptember");
define("BLOGCAL_M10", "okt�ber");
define("BLOGCAL_M11", "november");
define("BLOGCAL_M12", "december");

define("BLOGCAL_1", "H�rek");

define("BLOGCAL_CONF1", "h�napok/sor");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF3", "Be�ll�t�sok friss�t�se");
define("BLOGCAL_CONF4", "BlogCal men� be�ll�t�sok");
define("BLOGCAL_CONF5", "Be�ll�t�sok friss�tve");

define("BLOGCAL_ARCHIV1", "Arch�vum kiv�laszt�sa");

?>