<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.5 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UTHEME_MENU_L1", "Nyelv be�ll�t�sa");
define("UTHEME_MENU_L2", "Nyelv kiv�laszt�sa");
define("UTHEME_MENU_L3", "t�bl�k");
?>