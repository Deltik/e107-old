<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.1 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "F�rum felt�lt�sek");

define('FRMUP_1','Felt�lt�tt file-ok a f�rumban');
define('FRMUP_2','File t�r�lve');
define('FRMUP_3','Hiba: A file nem t�r�lhet�');
define('FRMUP_4','File t�rl�s');
define('FRMUP_5','File neve');
define('FRMUP_6','Eredm�ny');
define('FRMUP_7','Tal�lat a t�m�ban');
define('FRMUP_8','Nincs tal�lat');
define('FRMUP_9','Nincs felt�lt�tt file');
define('FRMUP_10','T�rl�s');

?>
