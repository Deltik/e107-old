<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.3 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("TREE_L1", "Tree (Fa) Men� Be�ll�t�sa");
define("TREE_L2", "Tree (Fa) Men� be�ll�t�sok friss�t�se");
define("TREE_L3", "Tree (Fa) Men� be�ll�t�sok elmentve.");
define("TREE_L4", "Be");
define("TREE_L5", "Ki");
define("TREE_L6", "CSS class a nem megnyithat� likek r�sz�re");
define("TREE_L7", "CSS class a megnyithat� linkek r�sz�re");
define("TREE_L8", "CSS class a megnyitott linkek r�sz�re");
define("TREE_L9", "Haszn�ld a spacer class-t a f� linkek k�z�tt");

?>