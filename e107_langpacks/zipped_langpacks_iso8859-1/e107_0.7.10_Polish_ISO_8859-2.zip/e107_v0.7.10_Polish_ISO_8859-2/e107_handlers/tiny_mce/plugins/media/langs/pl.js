/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2007/02/19 16:57:37 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/media/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/media/langs/pl.php rev. 1.1
+-----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('media',{
title : 'Osad� / Edytuj plik medi�w',
desc : 'Osad� / Edytuj plik medi�w',
general : 'Og�lne',
advanced : 'Zaawansowane',
file : 'Plik',
list : 'Lista',
size : 'Wymiary',
preview : 'Podgl�d',
constrain_proportions : 'Zachowaj proporcje',
type : 'Typ',
id : 'Id',
name : 'Nazwa',
class_name : 'Klasa',
vspace : 'Marg.-V',
hspace : 'Marg.-H',
play : 'Autoodtwarzanie',
loop : 'P�tla',
menu : 'Poka� menu',
quality : 'Jako��',
scale : 'Skala',
align : 'Wyr�wnanie',
salign : 'Wyr�w. (SAlign)',
wmode : 'Tryb okna',
bgcolor : 'T�o',
base : 'Parametr base',
flashvars : 'Parametr flashvars',
liveconnect : 'SWLiveConnect',
autohref : 'Auto HREF',
cache : 'Pami�� podr�czna',
hidden : 'Ukryj film',
controller : 'Menu sterowani',
kioskmode : 'Tryb bez menu',
playeveryframe : 'Odtwarzaj ka�d� ramk�',
targetcache : 'Przechowuj filmy zew.',
correction : 'Bez korekty',
enablejavascript : 'Aktywuj JavaScript',
starttime : 'Czas rozp.',
endtime : 'Czas zako.',
href : 'Href',
qtsrcchokespeed : 'Szybko�� danych',
target : 'Cel (target)',
volume : 'G�o�no��',
autostart : 'Autostart',
enabled : 'Detekcja playera',
fullscreen : 'Pe�ny ekran',
invokeurls : 'Param. InvokeURLs',
mute : 'Wycisz',
stretchtofit : 'Dopasuj rozmiar',
windowlessvideo : 'Tryb windowless',
balance : 'Balans',
baseurl : 'Bazowy URL',
captioningid : 'Id opisu',
currentmarker : 'Wska�nik',
currentposition : 'Pozycja',
defaultframe : 'Domy�lna ramka',
playcount : 'Ilo�� powt�rze�',
rate : 'Tempo',
uimode : 'Param. uiMode',
flash_options : 'Opcje plik�w Flash',
qt_options : 'Opcje plik�w Quicktime',
wmp_options : 'Opcje Windows Media Player',
rmp_options : 'Opcje odtwarzacza Real Media',
shockwave_options : 'Opcje Shockwave',
autogotourl : 'Auto-przej�cie do URL',
center : 'Wy�rodkowanie',
imagestatus : 'Status obrazka',
maintainaspect : 'Zachowaj proporcje',
nojava : 'Bez Javy VM',
prefetch : 'Wst�pne �adowanie',
shuffle : 'Odtwarzaj losowo',
console : 'Elementy sterowania',
numloop : 'Ilo�� p�tli',
controls : 'Menu kontrolne',
scriptcallbacks : 'Skrypt odwo�ania',
swstretchstyle : 'Styl dopasowania',
swstretchhalign : 'Dopas. wyr�wnania-H',
swstretchvalign : 'Dopas. wyr�wnania-V',
sound : 'D�wi�k',
progress : 'Post�p',
qtsrc : '�r�d�o QT',
qt_stream_warn : '�r�d�o strumienia protoko�u RTSP powinno zosta� dodane do pola \'�r�d�o QT\' w zak�adce \'Zaawansowane\'.\nPowiniene� r�wnie� doda� wersj� bez streamingu do pola \'�r�d�o\'..'
});
