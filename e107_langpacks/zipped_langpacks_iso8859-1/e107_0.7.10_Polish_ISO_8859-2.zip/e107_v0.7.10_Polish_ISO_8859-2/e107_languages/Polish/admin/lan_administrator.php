<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2006/11/19 17:03:20 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_administrator.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_administrator.php rev. 1.16
+-----------------------------------------------------------------------------+
*/
 
define("ADMSLAN_0", "Nowe has�o u�ytkownika/administratora utworzone dla");
define("ADMSLAN_1", "teraz ma status administratora.");
define("ADMSLAN_2", "zosta� zaktualizowany w bazie danych.");
define("ADMSLAN_3", "jest g��wnym administratorem strony i nie mo�na go edytowa�.");
define("ADMSLAN_4", "Dalej");
define("ADMSLAN_5", "B��d!");
define("ADMSLAN_6", "jest g��wnym administratorem strony i nie mo�na go usun��.");

define("ADMSLAN_13", "Aktualni administratorzy");

define("ADMSLAN_16", "Nazwa administratora");
define("ADMSLAN_17", "Has�o administratora");
define("ADMSLAN_18", "Uprawnienia");
define("ADMSLAN_19", "Zmiana preferencji strony");
define("ADMSLAN_20", "Zmiana menu");
define("ADMSLAN_21", "Modyfikacja uprawnie� administrator�w");
define("ADMSLAN_22", "Moderacja u�ytkownik�w/blokowanych etc");
define("ADMSLAN_23", "Tworzenie/edytowanie zawarto�ci stron/menu");
define("ADMSLAN_24", "Zarz�dzanie kategoriami plik�w do pobrania");
define("ADMSLAN_25", "Nadsy�anie/zarz�dzanie plikami");
define("ADMSLAN_26", "Nadzorowanie kategorii aktualno�ci");
define("ADMSLAN_27", "Nadzorowanie kategorii link�w");
define("ADMSLAN_28", "Wy��czenie strony w celu konserwacji");
define("ADMSLAN_29", "Zarz�dzanie reklamami");
define("ADMSLAN_30", "Konfiguracja nag��wk�w zdalnych wiadomo�ci");
define("ADMSLAN_31", "Konfiguracja emotikon");
define("ADMSLAN_32", "Konfiguracja zawarto�ci strony g��wnej");
define("ADMSLAN_33", "Konfiguracja log�w/statystyk");
define("ADMSLAN_34", "Konfiguracja znacznik�w META");
define("ADMSLAN_35", "Konfiguracja publicznego uploadu");
define("ADMSLAN_36", "Konfiguracja ustawie� obraz�w");
define("ADMSLAN_37", "Moderacja komentarzy");
// define("ADMSLAN_38", "Moderacja/konfiguracja czata");
define("ADMSLAN_39", "Publikowanie aktualno�ci");
define("ADMSLAN_40", "Publikowanie link�w");
define("ADMSLAN_41", "Publikowanie artyku��w");
define("ADMSLAN_42", "Publikowanie recenzji");
define("ADMSLAN_43", "Publikowanie tre�ci");
define("ADMSLAN_44", "Publikowanie plik�w do pobrania");
define("ADMSLAN_45", "Publikowanie ankiet");
define("ADMSLAN_46", "Wiadomo�ci powitalne");
define("ADMSLAN_47", "Moderacja nades�anych aktualno�ci");

define("ADMSLAN_49", "Zaznacz wszystko");
define("ADMSLAN_51", "Odznacz wszystko");
define("ADMSLAN_52", "Aktualizacja uprawnie� administratora");
define("ADMSLAN_53", "Dodaj administratora");
define("ADMSLAN_54", "Administratorzy strony");

define("ADMSLAN_55", "Wymagane pola pozosta�y puste");

define("ADMSLAN_56", "Administrator strony");

define("ADMSLAN_58", "G��wny administrator strony");
define("ADMSLAN_59", "Usun�� status administratora");
define("ADMSLAN_60", "Czy jeste� pewien usuni�cia statusu administratora?");
define("ADMSLAN_61", "Administrator zosta� usuni�ty");

define("ADMSLAN_62", "Mened�er plugin�w");

define("ADMSLAN_64", "Czyszczenie pami�ci podr�cznej serwisu");
define("ADMSLAN_65", "Konfiguracja emaila oraz wysy�anie emaili");
define("ADMSLAN_66", "Konfiguracja wyszukiwania");
define("ADMSLAN_67", "Skanowanie inspektorem plik�w");
define("ADMSLAN_68", "Konfiguracja powiadomie� email");
define("ADMSLAN_69", "jest ju� administratorem i musi by� edytowany.");

define("ADMSLAN_70", "Powr�� do listy administrator�w");
define("ADMSLAN_71", "Kliknij tutaj, aby wy�wietli� uprawnienia");

?>
