<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2007/10/06 17:31:41 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_db_verify.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_db_verify.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("DBLAN_1", "Nie mog� czyta� danych pliku sql.<br /><br />Prosz� upewni� si�, �e plik <b>core_sql.php</b> znajduje si� w folderze <b>/admin/sql</b>.");
define("DBLAN_2", "Weryfikuj wszystko");

define("DBLAN_4", "Tabela");
define("DBLAN_5", "Pole");
define("DBLAN_6", "Status");
define("DBLAN_7", "Uwagi");
define("DBLAN_8", "Niedopasowane");
define("DBLAN_9", "Obecnie");
define("DBLAN_10", "Powinno by�");
define("DBLAN_11", "Brakuj�ce pola");
define("DBLAN_12", "Dodatkowe pole!");
define("DBLAN_13", "Brakuj�ca tabela!");
define("DBLAN_14", "Wybierz tabele do weryfikacji");
define("DBLAN_15", "Zacznij weryfikacj�");
define("DBLAN_16", "Weryfikacja SQL");
define("DBLAN_17", "Wstecz");
define("DBLAN_18", "Tabele");
define("DBLAN_19", "Spr�buj naprawi�");
define("DBLAN_20", "Proces naprawy tabel");
define("DBLAN_21", "Napraw zaznaczone");
define("DBLAN_22", " jest nie do odczytu");

?>