<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2007/10/06 17:31:44 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_users.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_users.php rev. 1.32
+-----------------------------------------------------------------------------+
*/
 
define("USRLAN_1", "Opcje zosta�y zapisane.");
define("USRLAN_3", "jest teraz administratorem - aby zmieni� uprawnienia przejd� do strony");
define("USRLAN_4", "administratora.");
define("USRLAN_5", "Nie mo�esz usun�� statusu administratora g��wnemu administratorowi strony");
define("USRLAN_6", "- utraci� status administratora.");
define("USRLAN_7", "Nie mo�esz zablokowa� g��wnego administratora strony");
define("USRLAN_8", "U�ytkownik zosta� zablokowany.");
define("USRLAN_9", "U�ytkownik zosta� odblokowany.");
define("USRLAN_10", "U�ytkownik zosta� usuni�ty.");
define("USRLAN_11", "Usuwanie zosta�o anulowane.");
define("USRLAN_12", "Nie mo�esz usun�� g��wnego administratora strony.");
define("USRLAN_13", "Prosz� potwierdzi�, je�li chcesz usun�� tego u�ytkownika");
// define("USRLAN_14", "raz usuni�ty u�ytkownik nie b�dzie m�g� by� odtworzony");
// define("USRLAN_15", "Anuluj");
define("USRLAN_16", "Potwierd� usuni�cie");
define("USRLAN_17", "Potwierd� usuni�cie u�ytkownika");
// define("USRLAN_18", "U�ytkownik aktywowany.");
// define("USRLAN_19", "Wyszukaj");
// define("USRLAN_20", "Sortuj wed�ug");
// define("USRLAN_21", "ID u�ytkownika");
// define("USRLAN_22", "Nazwa u�ytkownika");
// define("USRLAN_23", "Wizyt na stronie");
// define("USRLAN_24", "Status administratora");
// define("USRLAN_25", "Status");
// define("USRLAN_26", "Malej�co");
// define("USRLAN_27", "Rosn�co");
// define("USRLAN_28", "Sortuj");

define("USRLAN_30", "Zablokuj");
// define("USRLAN_31", "Blokada -dezaktywowana-");
define("USRLAN_32", "Aktywuj");
define("USRLAN_33", "Odblokuj");
define("USRLAN_34", "Usu� status admina");
define("USRLAN_35", "Nadaj status admina");
define("USRLAN_36", "Ustaw grup�");

// define("USRLAN_37", "U�ytkownicy");
// define("USRLAN_38", "Wyszukano");
// define("USRLAN_39", "wynik(i)");
// define("USRLAN_40", "Brak zdefiniowanych");

define("USRLAN_44", "Pozwoli� u�ytkownikom na nadsy�anie awatar�w?");

define("USRLAN_47", "Maksymalna szeroko�� awatara (w pikselach)");
define("USRLAN_48", "domy�lnie jest 120");
define("USRLAN_49", "Maksymalna wysoko�� awatara (w pikselach)");
define("USRLAN_50", "domy�lnie jest 100");
define("USRLAN_51", "Aktualizuj opcje");
define("USRLAN_52", "Opcje u�ytkownik�w");
define("USRLAN_53", "Pozwoli� u�ytkownikom na nadsy�anie zdj��?");
define("USRLAN_54", "Kliknij tutaj, aby usun�� wszystkich nieaktywowanych u�ytkownik�w");
define("USRLAN_55", "Oczyszczanie");
define("USRLAN_56", "Usuni�to");
define("USRLAN_57", "Usuwanie nieaktywowanych u�ytkownik�w..."); // Deleting un-activated members
define("USRLAN_58", "zapisywanie nades�anych plik�w jest wy��czone w php.ini");
define("USRLAN_59", "Szybkie dodawanie u�ytkownik�w");
define("USRLAN_60", "Dodaj u�ytkownika");
define("USRLAN_61", "Wy�wietlana nazwa");
define("USRLAN_62", "Has�o");
define("USRLAN_63", "Powt�rz has�o");
define("USRLAN_64", "Adres email");
define("USRLAN_65", "Podana nazwa wy�wietlana  nie mo�e by� zaakceptowana, prosz� zmieni� j� na inn�.");
define("USRLAN_66", "Podana nazwa wy�wietlana ju� istnieje w bazie danych, prosz� zmieni� j� na inn�.");
define("USRLAN_67", "Podane has�a r�ni� si�. Prosz� wprowadzi� je ponownie.");
define("USRLAN_68", "Pozosta�y niewype�nione pola");
define("USRLAN_69", "Podany adres email jest b��dny. Wprowad� go ponownie.");
define("USRLAN_70", "U�ytkownik zosta� dodany");
define("USRLAN_71", "Aktualni u�ytkownicy");
define("USRLAN_72", "Dodaj u�ytkownika");
define("USRLAN_73", "Oczyszczanie");
// define("USRLAN_75", "Opcje");
define("USRLAN_76", "Opcje u�ytkownik�w");
define("USRLAN_77", "Aktualni u�ytkownicy");
define("USRLAN_78", "Nazwa u�ytkownika");
define("USRLAN_79", "Status");
define("USRLAN_80", "Informacje");

// define("USRLAN_82", "Czy na pewno chcesz usun�� tego u�ytkownika");
define("USRLAN_84", "Obecnie jest");
define("USRLAN_85", "u�ytkownik�w, kt�rzy nie dokonali aktywacji kont - kliknij poni�ej, aby ich usun��.");
define("USRLAN_86", "U�ytkownik zweryfikowany");
define("USRLAN_87", "Ustawienia u�ytkownika zosta�y zaktualizowane");
define("USRLAN_88", "Grupy u�ytkownik�w zosta�y zaktualizowane");

define("USRLAN_90", "Szukaj/Od�wie�");
define("USRLAN_91", "Grupa");
define("USRLAN_92", "Niepoprawne znaki w nazwie u�ytkownika");

define("USRLAN_93", "Usu� niezweryfikowanych u�ytkownik�w");
define("USRLAN_94", "Usu� rejestracje, je�li nie zostan� zweryfikowane po wskazanym czasie - pozostaw puste, aby nie u�ywa� tej opcji<br />Ta opcja zostanie zignorowana, je�li rejestracja u�ytkownika jest moderowana przez administratora");
define("USRLAN_95", "minut");


define("USRLAN_112", "Ponowne wysy�anie emaila");
define("USRLAN_113", "Potwierdzenie rejestracji w serwisie");
define("USRLAN_114", "Drogi(a)");
define("USRLAN_115", "Dzi�kujemy za rejestracj�.");
define("USRLAN_116", "Prosz� potwierdzi� ch�� ponownego wys�ania emaila potwierdzaj�cego do:");
define("USRLAN_117", "Kliknij na przycisku poni�ej, aby przetestowa� email:");
define("USRLAN_118", "Testuj emaila");

define("USRLAN_120", "Ustawianie grup");
define("USRLAN_121", "Mailingi");
define("USRLAN_122", "Witaj na");
define("USRLAN_123", "Twoja rejestracja oraz tworzenie konta zosta�o zaakceptowane.");
define("USRLAN_124", "Twoje konto jest aktualnie odznaczone jako nieaktywne, aby aktywowa� swoje konto prosz� uda� si� pod nast�puj�cy adres");
define("USRLAN_125", "Od");

define("USRLAN_126", "Pozw�l u�ytkownikom na ocen� u�ytkownik�w");
define("USRLAN_127", "Pozw�l na komentarze w profilu u�ytkownika");

define("USRLAN_128", "U�ytkownik");

define("USRLAN_130", "W��cz �ledzenie u�ytkownik�w online");
define("USRLAN_131", "Musisz w��czy� t� opcje, aby u�ywa� opcji �ledzenia u�ytkownik�w online. Wymagane przez online.php, informacje online na forum oraz menu online");
define("USRLAN_132", "W��cz");

define("USRLAN_133", "Zmu� u�ytkownika do aktualizacji ustawie�");
define("USRLAN_134", "W��czenie tej opcji spowoduje automatyczne przes�anie u�ytkownika do jego ustawie�, je�li kt�re� z wymaganych p�l nie b�dzie wype�nione.");

define("USRLAN_135", "Nie znalaz�em adresu IP w informacjach o u�ytkownikach, IP nie jest zablokowany");
define("USRLAN_136", "Znalaz�em wielu u�ytkownik�w, kt�rzy u�ywaj� adresu IP {IP}, IP nie jest zablokowany.");
define("USRLAN_137", "U�ytkownicy o adresie IP {IP} s� zablokowani.");


define("USRLAN_138", "Konta bez weryfikacji");
define("USRLAN_139", "Twoje konto zosta�o aktywowane.\n\nOd tej chwili mo�esz si� zalogowa� na stronie {SITEURL} u�ywaj�c has�a i loginu podanego podczas procesu rejestracji.");

define("USRLAN_140", "Ponownie wys�ano emaila do");
define("USRLAN_141", "Nieudana pr�ba wys�ania ponownego emaila aktywacyjnego do");
define("USRLAN_142", "z nast�puj�cym linkiem aktywacyjnym");

define("USRLAN_143", "Sprawd� odpowied� do nadawc�w");
define("USRLAN_144", "Ponownie wy�lij emaile weryfikacyjne do wszystkich");
define("USRLAN_145", "Odrzuceni u�ytkownicy");
define("USRLAN_146", "Informacje o zarejestrowanych u�ytkownikach jest dost�pna dla");

define("USRLAN_147", "Adres email jest u�ywany przez zbanowanego u�ytkownika");
define("USRLAN_148", "Adres email jest zbanowany");

define("USRLAN_149", "Usu� wybrane wiadomo�ci");
define("USRLAN_150", "Usu� wszystkie wiadomo�ci");
define("USRLAN_151", "Wyczy�� odbicie, za��daj Aktywacji");
define("USRLAN_152", "Wyczy�� odbicie i Aktywuj");
define("USRLAN_153", "Usu� nieodbite wiadomo�ci");
define("USRLAN_154", "Wyczy�� wiadomo�� dla wybranych");
define("USRLAN_155", "Znaleziono {TOTAL} wszystkich wiadomo�ci. Usuni�to {DELCOUNT}.<br />{DELUSER} u�ytkownik�w oznaczono jako 'odbitych' (z {FOUND} wiadomo�ci)");

define("LAN_MAINADMIN","G��wny administrator");
define("LAN_ADMIN","Administrator");
define("LAN_NOTVERIFIED","Niezweryfikowany");
define("LAN_BANNED","Zablokowany");
define("LAN_BOUNCED", "Odbite");

define("DUSRLAN_1", "ID");
define("DUSRLAN_2", "Wy�wietlana nazwa");
define("DUSRLAN_3", "Login");
define("DUSRLAN_4", "Dodatkowy opis");
define("DUSRLAN_5", "Has�o");
define("DUSRLAN_6", "Sesja");
define("DUSRLAN_7", "Email");
define("DUSRLAN_8", "Strona domowa");
define("DUSRLAN_9", "ICQ");
define("DUSRLAN_10", "AIM");
define("DUSRLAN_11", "MSN");
define("DUSRLAN_12", "Miejscowo��");
define("DUSRLAN_13", "Urodziny");
define("DUSRLAN_14", "Sygnatura");
define("DUSRLAN_15", "Obraz");
define("DUSRLAN_16", "Strefa czasowa");
define("DUSRLAN_17", "Ukryj email");
define("DUSRLAN_18", "Data do��czenia");
define("DUSRLAN_19", "Ostatnia wizyta");
define("DUSRLAN_20", "Aktualnie ogl�da");
define("DUSRLAN_21", "Ostatni post");
define("DUSRLAN_22", "Posty na czacie");
define("DUSRLAN_23", "Komentarze");
define("DUSRLAN_24", "Posty na forum");
define("DUSRLAN_25", "IP");
define("DUSRLAN_26", "Zablokuj");
define("DUSRLAN_27", "Ustawienia");
define("DUSRLAN_28", "Nowe");
define("DUSRLAN_29", "Ods�on");
define("DUSRLAN_30", "Wizyt");
define("DUSRLAN_31", "Administrator");
define("DUSRLAN_32", "Prawdziwe imi�");
define("DUSRLAN_33", "Grupa u�ytkownika");
define("DUSRLAN_34", "Uprawnienia");
define("DUSRLAN_35", "Obraz");
define("DUSRLAN_36", "Zmie� has�o");
define("DUSRLAN_37", "XUP");

?>
