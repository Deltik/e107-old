<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_fla.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_fla.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("FLALAN_1", "Nieudane pr�by logowania");
define("FLALAN_2", "Obecnie nie wykryto nieudanych pr�b logowania");
define("FLALAN_3", "Usuni�tych pr�b");
define("FLALAN_4", "U�ytkownik pr�bowa� zalogowa� si� u�ywaj�c niepoprawnego loginu lub has�a");
define("FLALAN_5", "zablokowanych IP");
define("FLALAN_6", "Data");
define("FLALAN_7", "Dane");
define("FLALAN_8", "Adres IP/nazwa hosta");
define("FLALAN_9", "Opcje");
define("FLALAN_10", "Usu�/Zablokuj zaznaczone pozycje");
define("FLALAN_11", "zaznacz usuni�cie wszystkich");
define("FLALAN_12", "odznacz usuni�cie wszystkich");
define("FLALAN_13", "zaznacz zablokowanie wszystkich");
define("FLALAN_14", "odznacz zablokowanie wszystkich");
define("FLALAN_15", "Nast�puj�ce adresy IP zosta�y automatycznie zablokowane - u�ytkownik usi�owa� wi�cej ni� 10 razy zalogowa� si� u�ywaj�c b��dnych danych");
define("FLALAN_16", "usu� list� automatycznie zablokowanych");
define("FLALAN_17", "Lista automatycznie zablokowanych zosta�a usuni�ta");

?>
