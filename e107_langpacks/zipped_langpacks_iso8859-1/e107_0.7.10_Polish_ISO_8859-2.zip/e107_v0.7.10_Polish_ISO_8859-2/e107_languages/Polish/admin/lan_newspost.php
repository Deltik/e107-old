<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.7 $
|     $Date: 2007/10/29 10:19:42 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_newspost.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_newspost.php rev. 1.32
+-----------------------------------------------------------------------------+
*/
 
define("NWSLAN_1", "Historia aktualno�ci zosta�a usuni�ta.");
define("NWSLAN_2", "Prosz� zaznaczy� pole, aby potwierdzi� usuni�cie wskazanej aktualno�ci.");
define("NWSLAN_3", "Nie ma jeszcze �adnych aktualno�ci.");
define("NWSLAN_4", "Aktualne wiadomo�ci");
define("NWSLAN_5", "Otw�rz edytor HTML");
define("NWSLAN_6", "Kategoria");

define("NWSLAN_9", "Zaznacz, aby potwierdzi�");
define("NWSLAN_10", "Nie ma jeszcze �adnej kategorii");
define("NWSLAN_11", "Dodaj/Edytuj kategori�");
define("NWSLAN_12", "Tytu�");
define("NWSLAN_13", "Tre��");
define("NWSLAN_14", "Rozszerzenie");
define("NWSLAN_15", "Komentarze");
// define("NWSLAN_16", "W��czone"); // deprecated see lan_admin.php
// define("NWSLAN_17", "Wy��czone"); // deprecated see lan_admin.php
define("NWSLAN_18", "Pozw�l zamieszcza� komentarze dla tej wiadomo�ci");
define("NWSLAN_19", "Aktywacja");

define("NWSLAN_21", "Aktywuj pomi�dzy");
define("NWSLAN_22", "Widoczno��");

define("NWSLAN_24", "Ponowny podgl�d");
define("NWSLAN_25", "Aktualizuj wiadomo�� w bazie danych");
define("NWSLAN_26", "Wy�lij wiadomo�� do bazy danych");
define("NWSLAN_27", "Podgl�d");

define("NWSLAN_29", "Publikacja wiadomo�ci");

define("NWSLAN_31", "Wiadomo�� o pozycji");
define("NWSLAN_32", "zosta�a usuni�ta");
define("NWSLAN_33", "Kategoria aktualno�ci");
define("NWSLAN_34", "Nades�ane newsy");
define("NWSLAN_35", "Kategoria aktualno�ci zosta�a zapisana");
define("NWSLAN_36", "Kategoria aktualno�ci zosta�a zaktualizowana");
define("NWSLAN_37", "Czy na pewno usun�� wskazan� kategori�");
define("NWSLAN_38", "Czy na pewno usun�� nades�anego newsa?");
define("NWSLAN_39", "Czy na pewno usun�� wiadomo��?");
define("NWSLAN_40", "Tytu�");

define("NWSLAN_42", "Bez tytu�u");
define("NWSLAN_43", "Nie ma jeszcze aktualno�ci");
define("NWSLAN_44", "Aktualne wiadomo�ci");
define("NWSLAN_45", "Dodaj now� wiadomo��");
define("NWSLAN_46", "Kategorie");
define("NWSLAN_47", "Nades�ane aktualno�ci");
define("NWSLAN_48", "Opcje aktualno�ci");
define("NWSLAN_49", "Nades�ane przez");

define("NWSLAN_51", "Aktualne kategorie wiadomo�ci");
define("NWSLAN_52", "Nazwa kategorii");
define("NWSLAN_53", "Ikona kategorii");
define("NWSLAN_54", "Zobacz obrazki");
define("NWSLAN_55", "Aktualizuj kategori� aktualno�ci");
define("NWSLAN_56", "Utw�rz kategori� aktualno�ci");
define("NWSLAN_57", "Pozycja");
define("NWSLAN_58", "Wy�lij");
define("NWSLAN_59", "Brak nades�anych aktualno�ci");
// define("NWSLAN_60", "Nades�ane aktualno�ci"); //already defined above.

define("NWSLAN_62", "Id� do strony: ");
define("NWSLAN_63", "Wyszukaj wiadomo��");

define("NWSLAN_66", "Za�aduj plik");
define("NWSLAN_67", "Obraz");
define("NWSLAN_68", "Plik");
define("NWSLAN_69", "Za�aduj obraz albo plik, aby go u�y� w redagowanej wiadomo�ci");
// define("NWSLAN_70", "Folder ".e_FILE."downloads nie jest zapisywalny, przed �adowaniem plik�w ustaw CHMOD wskazanego folderu na warto�ci 777."); // deprecated see lan_admin.php
// define("NWSLAN_71", "Folder ".e_IMAGE."newspost_images nie jest zapisywalny, przed �adowaniem obrazk�w ustaw CHMOD wskazanego folderu na warto�ci 777."); // deprecated see lan_admin.php
define("NWSLAN_72", "Wy�wietlaj wiadomo�� tylko pomi�dzy wskazanymi datami");
define("NWSLAN_73", "Metoda prezentacji");
define("NWSLAN_74", "Wybierz jak i gdzie ma by� wy�wietlana wiadomo��");
define("NWSLAN_75", "Domy�lnie - publikacja na pierwszej stronie news�w");
define("NWSLAN_76", "Tylko tytu� - publikacja na pierwszej stronie news�w");
define("NWSLAN_77", "Publikacja w menu aktualno�ci");

// define("NWSLAN_78", "Ta opcja jest nieaktywna, poniewa� zapisywanie plik�w na Twoim serwerze jest wy��czone"); // deprecated see lan_admin.php
define("NWSLAN_79", "Wyczy�� formularz");

define("NWSLAN_83", "Rozszerzona wiadomo��");
define("NWSLAN_84", "Wybierz u�ytkownik�w, dla kt�rych jest przeznaczona ta wiadomo��");

define("NWSLAN_86", "Pokazuj kategori� wiadomo�ci w stopce menu");
define("NWSLAN_87", "Wy�wietla� kategorie w kolumnach?");
define("NWSLAN_88", "Ile aktualno�ci ma by� pokazywanych na pierwszej stronie?");
define("NWSLAN_89", "Zapisz preferencje aktualno�ci");
define("NWSLAN_90", "Preferencje aktualno�ci");
define("NWSLAN_100", "W��cz mo�liwo�� nadsy�ania obraz�w");
define("NWSLAN_101", "Automatyczna zmiana rozmiar�w nadsy�anych obraz�w");
define("NWSLAN_102", "szeroko�� w pikselach<br /> lub pozostaw puste, aby nie aktywowa�.");
define("NWSLAN_103", "Wy�lij ponownie");
define("NWSLAN_104", "przez");
define("NWSLAN_105", "Zaznacz, aby data publikacji by�a zast�piona aktualn�");
define("NWSLAN_106", "Nadsy�anie aktualno�ci jest mo�liwe przez:");
define("NWSLAN_107", "W��cz edytor WYSIWYG na stronie do nadsy�ania wiadomo�ci.");
define("NWSLAN_108", "dnia");

define("NWSLAN_111", "Poka� dat� nowego nag��wka");
define("NWSLAN_112", "je�li pole b�dzie odznaczone, wiadomo�ci zawieraj�ce dat� b�d� wy�wietlane ponad wiadomo�ciami wystawionymi w nowym dniu, przydatne dla oddzielenia wiadomo�ci pisanych w innym dniu");

define("NWSLAN_113", "U�ywaj niestandardowego szablonu dla uk�adu aktualno�ci");
define("NWSLAN_114", "je�li temat, kt�rego u�ywasz posiada w�asny szablon wy�wietlania aktualno�ci, u�yj tej opcji, aby go aktywowa�");

define("NWSLAN_115", "Ile aktualno�ci ma by� wy�wietlanych w archiwum?");
define("NWSLAN_116", "Najpierw zaktualizuj zmiany w ustawieniach wy�wietlania wiadomo�ci na stronie g��wnej, nast�pnie ponownie zaktualizuj ustawienia preferencji wy�wietlania wiadomo�ci w archiwum"); // First update the preferences with the changed display per page setting, then update again after setting the newsarchive preference. (0 oznacza nieaktywne)
define("NWSLAN_117", "Wpisz nazw� dla archiwum aktualno�ci");
// define("NWSLAN_118", "Zobacz obrazki"); // already defined above.
define("NWSLAN_119", "Ustawienia zosta�y zapisane");
define("NWSLAN_120", "Wiadomo�� dla os�b nasy�aj�cych newsy"); // Text to show at the top of Submit News

define("LAN_NEWS_5", "B��d! - Aktualizacja wiadomo�ci w bazie danych by�a niemo�liwa");
define("LAN_NEWS_6", "Aktualno�� zosta�a dodana do bazy danych.");
define("LAN_NEWS_7", "B��d! - Dodanie wiadomo�ci do bazy danych by�o niemo�liwe!");
define("LAN_NEWS_9", "Tylko tytu� - <b>b�dzie pokazywany tylko tytu� waidomo�ci</b>");
define("LAN_NEWS_10", "Wiadomo�� jest <b>nieaktywna</b> (nie b�dzie wy�wietlana na pierwszej stronie). ");
define("LAN_NEWS_11", "Wiadomo�� jest <b>aktywna</b> (b�dzie wy�wietlana na pierwszej stronie). ");
define("LAN_NEWS_12", "Komentarze s� <b>w��czone</b>.");
define("LAN_NEWS_13", "Komentarze s� <b>wy��czone</b>.");
define("LAN_NEWS_14", "<br />Okres aktywacji: ");
define("LAN_NEWS_15", "D�ugo�� tre�ci: ");
define("LAN_NEWS_16", "b. D�ugo�� rozszerzonej tre�ci: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Informacje");
define("LAN_NEWS_19", "Od teraz");
define("LAN_NEWS_21", "Wiadomo�� zosta�a zaktualizowana w bazie danych.");

define("LAN_NEWS_22", "Miniaturka");
define("LAN_NEWS_23", "Wybierz obrazek dla tej wiadomo�ci");
define("LAN_NEWS_24", "Obraz + auto-miniaturka");
define("LAN_NEWS_25", "Rozmiar auto-miniaturki");
define("LAN_NEWS_26", "Dodaj nowy plik");
define("LAN_NEWS_27", "Podtytu�");

define("LAN_NEWS_28", "Przyklej");
define("LAN_NEWS_29", "Wybierz je�li chcesz, aby wiadomo�� by�a przyklejona");
define("LAN_NEWS_30", "Je�li zaznaczysz, wiadomo�� b�dzie pokazywana ponad wszystkimi innymi aktualno�ciami");
define("LAN_NEWS_31", "Wiadomo�� jest <b>przyklejona</b> (b�dzie wy�wietlana ponad wszystkimi innymi wiadomo�ciami). ");
define("LAN_NEWS_32", "Data dodania"); // Datestamp
define("LAN_NEWS_33", "Ustaw znacznik czasu dla bie��cej wiadomo�ci");

define("LAN_NEWS_34", "Powi�zania");
define("LAN_NEWS_35", "Dodaj adres powi�zania");
define("LAN_NEWS_36", "<b><i>Pingback</i></b> (wy�lij <i>pingback</i> do wszystkich adres�w URL w tym wpisie)");
define("LAN_NEWS_37", "<b>Adresy powi�za�:</b> (jeden adres URL w ka�dej linii)");
define("LAN_NEWS_38", "Do��cz obrazki");

define("LAN_NEWS_39", "kliknij na pliku, aby umie�ci� znacznik pozycji");
define("LAN_NEWS_40", "Do��cz pliki do pobrania");

define("LAN_NEWS_42", "Pliki");
// define("LAN_NEWS_43", "(brak obrazk�w w ".e_IMAGE."/newspost_images)"); // deprecated see lan_admin.php
define("LAN_NEWS_44", "Powi�zania nieaktywne.");

define("LAN_NEWS_45", "ID");

define("LAN_NEWS_46", "Pozycja nie zosta�a zaktualizowana, poniewa� �adne zmiany nie zosta�y wprowadzone."); // News item not updated as no changes were made
// define("LAN_NEWS_47", "Obrazek"); // already defined above.
define("LAN_NEWS_48", "Brak obrazka");

define("LAN_NEWS_49", "Metoda prezentacji");

?>
