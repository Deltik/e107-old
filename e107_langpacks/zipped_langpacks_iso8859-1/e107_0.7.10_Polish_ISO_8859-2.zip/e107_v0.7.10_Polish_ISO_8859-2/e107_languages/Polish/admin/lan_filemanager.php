<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_filemanager.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_filemanager.php rev. 1.6
+-----------------------------------------------------------------------------+
*/
 
define("FMLAN_1", "Za�adowano");
define("FMLAN_2", "do");
define("FMLAN_3", "katalogu");
define("FMLAN_4", "Rozmiar �adowanego pliku przekracza warto�� <i>upload_max_filesize</i> (maksymalny rozmiar �adowanego pliku) znajduj�c� si� w pliku php.ini.");
// define("FMLAN_5", "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form.");
// define("FMLAN_6", "The uploaded file was only partially uploaded.");
// define("FMLAN_7", "No file was uploaded.");
// define("FMLAN_8", "Uploaded file size 0 bytes");
// define("FMLAN_9", "The file did not upload. Filename");
// define("FMLAN_10", "Error");
// define("FMLAN_11", "Probably incorrect permissions on upload directory.");
define("FMLAN_12", "plik");
define("FMLAN_13", "plik�w");
define("FMLAN_14", "katalog");
define("FMLAN_15", "katalog�w");
define("FMLAN_16", "G��wny katalog");
define("FMLAN_17", "Nazwa");
define("FMLAN_18", "Rozmiar");
define("FMLAN_19", "Ostatnio modyfikowany");

define("FMLAN_21", "Za�aduj plik do tego katalogu");
define("FMLAN_22", "Za�aduj");

define("FMLAN_26", "Usuni�ty");
define("FMLAN_27", "pomy�lnie");
define("FMLAN_28", "Nie mog� usun��");
define("FMLAN_29", "�cie�ka dost�pu");
define("FMLAN_30", "W g�r�");
define("FMLAN_31", "folder");

define("FMLAN_32", "Wybierz katalog");
define("FMLAN_33", "Wybierz");
define("FMLAN_34", "Wyb�r katalogu");
define("FMLAN_35", "Katalog plik�w");

define("FMLAN_36", "Katalog w�asnych menu");
define("FMLAN_37", "Katalog w�asnych stron");

define("FMLAN_38", "Plik pomy�lnie przeniesiony do");
define("FMLAN_39", "Nie mog� przenie�� pliku do");
define("FMLAN_40", "Obrazki aktualno�ci");


define("FMLAN_43", "Usu� zaznaczone pliki");


define("FMLAN_46", "Prosz� potwierdzi� ch�� USUNI�CIA zaznaczonych plik�w.");
define("FMLAN_47", "Pliki u�ytkownik�w");

define("FMLAN_48", "Przenie� zaznaczone do");
define("FMLAN_49", "Prosz� potwierdzi� ch�� PRZENIESIENIA zaznaczonych plik�w.");
define("FMLAN_50", "Przenie�");

?>
