<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2007/04/21 13:37:29 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_fpw.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_fpw.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Zmiana has�a");

define("LAN_02", "Przepraszam, wys�anie emaila jest niemo�liwe - prosz� skontaktowa� si� z g��wnym administratorem strony.");
define("LAN_03", "Zmiana has�a");
define("LAN_05", "Aby zresetowa� has�o, prosz� post�powa� zgodnie ze wskaz�wkami");
define("LAN_06", "Pr�ba zresetowania has�a");
define("LAN_07", "Kto� o adresie IP ");
define("LAN_08", "usi�owa� zresetowa� g��wne has�o administratora.");
define("LAN_09", "Resetowanie has�a z ");
define("LAN_112", "Adres email u�yty przy rejestracji");
define("LAN_156", "Wy�lij");
define("LAN_213", "Podany login/adres email nie zosta� odnaleziony w bazie danych.");
define("LAN_214", "Nie mog� zresetowa� has�a");
define("LAN_216", "Aby potwierdzi� nowe has�o prosz� przej�� pod nast�puj�cy URL...");
define("LAN_217", "Twoje nowe has�o zosta�o potwierdzone, mo�esz teraz zalogowa� si� u�ywaj�c nowego has�a.");
define("LAN_218", "Login:");
define("LAN_219", "Has�o skojarzone z tym adresem emailowym by�o ju� resetowane i nie mo�e by� skasowane ponownie. Prosz� skontaktowa� si� z administratorem strony w celu uzyskania dok�adniejszych informacji.");
define("LAN_FPW1","Login");
define("LAN_FPW2","Wpisz kod");
define("LAN_FPW3","Wpisany kod jest niepoprawny");
define("LAN_FPW4","Pro�ba w celu zresetowania has�a zosta�a ju� wys�ana. Je�li nie otrzyma�e� emaila, prosz� skontaktowa� si� z administratorem strony w celu uzyskania pomocy.");
define("LAN_FPW5","Pro�ba o zresetowanie has�a dla");
define("LAN_FPW6","Email zosta� wys�any wraz z linkiem, kt�ry pozwoli Ci zresetowa� twoje has�o.");
define("LAN_FPW7","Link do zresetowania has�a jest nieaktualny.<br />Prosz� skontaktowa� si� z administratorem strony w celu uzyskania dok�adniejszych informacji.");
define("LAN_FPW8","Has�o dla u�ytkownika");
define("LAN_FPW9","zosta�o pomy�lnie zmienione.<br /><br />Nowe has�o to:");
define("LAN_FPW10","Prosz�");
define("LAN_FPW11","si� zalogowa�");
define("LAN_FPW12","i niezw�ocznie zmieni� has�o w celach bezpiecze�stwa.");

define("LAN_FPW13", "prosz� post�powa� zgodnie z instrukcj� w emailu w celu potwierdzenia has�a.");
define("LAN_FPW14", "zosta�a wys�ana przez kogo� o adresie IP");
define("LAN_FPW15", "Nie znaczy to jednak, �e twoje has�o zosta�o ju� zresetowane. Aby tego dokona�, musisz przej�� pod link wskazany poni�ej i doko�czy� proces resetowania has�a.");
define("LAN_FPW16", "Je�li to nie Ty poprosi�e� o zresetowanie has�a i NIE chcesz go zresetowa�, mo�esz po prostu zignorowa� tego emaila");
define("LAN_FPW17", "Poni�szy link b�dzie wa�ny przez 48 godzin.");

?>
