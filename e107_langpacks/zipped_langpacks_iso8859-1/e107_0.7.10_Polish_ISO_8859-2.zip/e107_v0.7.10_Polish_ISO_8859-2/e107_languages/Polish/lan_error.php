<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/11/01 00:05:28 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_error.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_error.php rev. 1.7
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "B��d");

define("LAN_ERROR_1", "B��d 401 - Brak uprawnie�");
define("LAN_ERROR_2", "Nie masz w�a�ciwych uprawnie� dost�pu do ��danego adresu.");
define("LAN_ERROR_3", "Prosz� poinformowa� administratora odno�nie tej strony, je�li s�dzisz, �e strona b��du zosta�a wy�wietlona przez pomy�k�.");
define("LAN_ERROR_4", "B��d 403 - Dost�p zabroniony");
define("LAN_ERROR_5", "��dany URL wymaga poprawnej nazwy u�ytkownika i has�a. Albo wpisa�e� niepoprawne dane (nazwa u�ytkownika i has�o) albo twoja przegl�darka nie wspiera tej w�a�ciwo�ci.");
define("LAN_ERROR_6", "Prosz� poinformowa� administratora odno�nie tej strony, je�li s�dzisz, �e strona b��du zosta�a wy�wietlona przez pomy�k�.");
define("LAN_ERROR_7", "B��d 404 - Strona o podanej nazwie nie istnieje");
define("LAN_ERROR_9", "Prosz� poinformowa� administratora odno�nie tej strony, je�li s�dzisz, �e strona b��du zosta�a wy�wietlona przez pomy�k�.");
define("LAN_ERROR_10", "B��d 500 - Wewn�trzny b��d serwera");
define("LAN_ERROR_11", "Serwer napotka� wewn�trzny b��d lub jest b��dnie skonfigurowany i nie by� w stanie odpowiedzie� na twoje zapytanie");
define("LAN_ERROR_12", "Prosz� poinformowa� administratora odno�nie tej strony, je�li s�dzisz, �e strona b��du zosta�a wy�wietlona przez pomy�k�.");
define("LAN_ERROR_13", "B��d - Nieznany");
define("LAN_ERROR_14", "Serwer napotka� b��d");
define("LAN_ERROR_15", "Prosz� poinformowa� administratora odno�nie tej strony, je�li s�dzisz, �e strona b��du zosta�a wy�wietlona przez pomy�k�.");
define("LAN_ERROR_16", "Twoja nieudana pr�ba uzyskania dost�pu do");
define("LAN_ERROR_17", "zosta�a zapisana.");
define("LAN_ERROR_18", "Widocznie zosta�e� tutaj odes�any przez");
define("LAN_ERROR_19", "Niestety, link o wskazanym adresie jest nieaktualny.");
define("LAN_ERROR_20", "Prosz� klikn�� tutaj, aby powr�ci� na stron� g��wn�.");
define("LAN_ERROR_21", "��dany adres URL nie zosta� znaleziony na tym serwerze. Wskazany przez Ciebie adres jest prawdopodobnie nieaktualny.");
define("LAN_ERROR_22", "Prosz� klikn�� <a href='".e_BASE."search.php'>tutaj</a>, aby przej�� do strony wyszukiwania.");
define("LAN_ERROR_23", "Twoja pr�ba uzyskania dost�pu do ");
define("LAN_ERROR_24", " nie powiod�a si�.");

// 0.7.6
define("LAN_ERROR_25", "[1]: Nie mog� odczyta� ustawie� j�dra z bazy danych - Ustawienia j�dra istniej�, lecz nie mog� by� odzyskane. Usi�uj� przywr�ci� kopi� bezpiecze�stwa rdzenia...");
define("LAN_ERROR_26", "[2]: Nie mog� odczyta� ustawie� j�dra z bazy danych - ustawienia j�dra nie istniej�.");
define("LAN_ERROR_27", "[3]: Ustawienia j�dra zosta�y zapisane - kopia bezpiecze�stwa aktywowana.");
define("LAN_ERROR_28", "[4]: Kopia bezpiecze�stwa j�dra nie zosta�a odnaleziona. Prosz� uruchomi� narz�dzie <a href='".e_FILE."resetcore/resetcore.php'>Reset Core</a> do odnowienia ustawie� j�dra. <br />Po odnowieniu swoich ustawie�, prosz� zapisa� kopi� bezpiecze�stwa j�dra z poziomu strony: Panel administratora -> Baza danych.");
define("LAN_ERROR_29", "[5]: Wymagane pola pozosta�y puste. Prosz� wype�ni� wymagane pola i ponownie przes�a� formularz.");
define("LAN_ERROR_30", "[6]: Nie mog� nawi�za� poprawnego po��czenia z serwerem MySQL. Prosz� sprawdzi�, czy plik e107_config.php zawiera prawid�owe informacje.");
define("LAN_ERROR_31", "[7]: Proces MySQL jest uruchomiony, lecz baza danych ({$mySQLdefaultdb}) nie mo�e by� pod��czona.<br />Prosz� sprawdzi�, czy baza istnieje oraz czy plik e107_config.php zawiera prawid�owe informacje.");
define("LAN_ERROR_32", "Aby zako�czy� aktualizacj�, zapisz nast�puj�ce informacje do pliku e107_config.php:");


?>
