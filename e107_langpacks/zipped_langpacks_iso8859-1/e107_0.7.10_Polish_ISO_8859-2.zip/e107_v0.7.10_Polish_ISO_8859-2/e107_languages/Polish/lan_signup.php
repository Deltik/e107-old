<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.8 $
|     $Date: 2007/10/05 22:15:41 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_signup.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_signup.php rev. 1.28
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Rejestracja");

define("LAN_7", "Wy�wietlana nazwa: ");
define("LAN_8", "ta nazwa b�dzie wy�wietlana na stronie");
define("LAN_9", "U�ytkownik: ");
define("LAN_10", "ta nazwa b�dzie u�ywana do logowania");
define("LAN_17", "Has�o: ");
define("LAN_103", "Podana wy�wietlana nazwa lub login nie mo�e by� zaakceptowana, prosz� zmieni� te dane na jakie� inne.");
define("LAN_104", "Podana nazwa u�ytkownika ju� istnieje w bazie danych. Prosz� zmieni� j� na inn�.");
define("LAN_105", "Podane has�a r�ni� si�. Prosz� wprowadzi� je ponownie.");
define("LAN_106", "Podany adres email jest b��dny. Wprowad� go ponownie.");
define("LAN_107", "Dzi�kujemy! Jeste� teraz zarejestrowanym u�ytkownikiem ");
define("LAN_108", "Proces rejestracji zosta� uko�czony");
define("LAN_109", "Serwis ten przestrzega The Children's Online Privacy Protection Act (COPPA) z 1998 roku, w zwi�zku z czym nie mo�e zaakceptowa� rejestracji u�ytkownik�w poni�ej 13 roku �ycia bez pisemnego upowa�nienia ich rodzic�w lub opiekun�w. Aby uzyska� wi�cej informacji, mo�esz przeczyta� akt prawny (legislacj�) ");
define("LAN_110", "Rejestracja");
define("LAN_111", "Powt�rz has�o: ");
define("LAN_112", "Adres email: ");
define("LAN_113", "Ukry� adres email ?: ");
define("LAN_114", "Ta opcja pozwala ukry� adresu email na wy�wietlanych stronach");
define("LAN_123", "Rejestracja");
define("LAN_185", "Nie wype�ni�e� wszystkich wymaganych p�l");
define("LAN_201", "Tak");
define("LAN_200", "Nie");
define("LAN_202", "Posiadasz ju� konto. Je�li nie pami�tasz swojego has�a, prosz� klikn�� w link 'Zmiana has�a'");
define("LAN_309", "Poni�ej prosz� wpisa� swoje dane rejestracyjne. ");
define("LAN_399", "Dalej");
define("LAN_400", "Login oraz has�o s� <b>rozr�niane pod wzgl�dem wielko�ci liter</b>");
define("LAN_401", "Twoje konto zosta�o aktywowane");
define("LAN_402", "Proces rejestracji zosta� potwierdzony");
define("LAN_403", "Witamy w");
define("LAN_404", "Potwierdzenie rejestracji w serwisie");
define("LAN_405", "Ten etap rejestracji zosta� uko�czony pomy�lnie. Wkr�tce otrzymasz email weryfikacyjny wraz z informacj� obja�niaj�c� proces logowania. Prosz� klikn�� w link zawarty w emailu, aby sfinalizowa� proces rejestracji i aktywowa� swoje konto.");
define("LAN_406", "Dzi�kujemy!");
define("LAN_407", "Prosz� zachowa� t� wiadomo�� emaila dla w�asnej wiadomo�ci. Twoje has�o zosta�o zaszyfrowane, w zwi�zku z czym je�li je zgubisz lub zapomnisz nie b�dziemy mogli go odzyska�. Jednak�e, je�li dojdzie do takiej sytuacji b�dziesz m�g�(mog�a) otrzyma� nowe has�o.\n\nDzi�kujemy za Twoj� rejestracj�.\n\nW serwisie");
define("LAN_408", "U�ytkownik o podanym adresie email ju� istnieje. Prosz� u�y� opcji 'zapomnia�em has�a', aby odzyska� has�o.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "znak�w.");
define("LAN_SIGNUP_3", "Weryfikacja kodu nie powiod�a si�.");
define("LAN_SIGNUP_4", "Twoje has�o musi by� d�u�sze ni� ");
define("LAN_SIGNUP_5", " znaki�w.");
define("LAN_SIGNUP_6", "Twoje ");
define("LAN_SIGNUP_7", " jest wymagane");
define("LAN_SIGNUP_8", "Dzi�kujemy!");
define("LAN_SIGNUP_9", "Nie mog� zaakceptowa�.");
define("LAN_SIGNUP_10", "Tak");
define("LAN_SIGNUP_11", ".");

define("LAN_409", "Niedozwolone znaki w nazwie u�ytkownika");
define("LAN_410", "Wpisz kod widoczny na obrazku");
define("LAN_411", "Wy�wietlana nazwa ju� istnieje w bazie danych, prosz� zmieni� nazw� na jak�� inn�");

define("LAN_SIGNUP_12", "prosz� zachowa� sw�j has�o i login w bezpiecznym miejscu, poniewa� w wypadku zgubienia podanych danych odzyskanie b�dzie niemo�liwe.");
define("LAN_SIGNUP_13", "Mo�esz si� teraz zalogowa� za pomoc� Menu Login lub ze strony <a href='".e_BASE."login.php'>Logowanie</a>.");
define("LAN_SIGNUP_14", "tutaj");
define("LAN_SIGNUP_15", "Prosz� skontaktowa� si� z g��wnym administratorem strony");
define("LAN_SIGNUP_16", ", je�li potrzebujesz pomocy.");
define("LAN_SIGNUP_17", "Zgadzam si� z powy�szymi warunkami i mam 13 lub wi�cej lat");
define("LAN_SIGNUP_18", "Twoja rejestracja zosta�a zaakceptowana i utworzona wed�ug nast�puj�cych informacji...");
define("LAN_SIGNUP_19", "Login:");
define("LAN_SIGNUP_20", "Has�o:");
define("LAN_SIGNUP_21", "Twoje konto jest obecnie nieaktywne. Aby aktywowa� konto, prosz� uda� si� pod nast�puj�cy adres...");
define("LAN_SIGNUP_22", "kliknij tutaj");
define("LAN_SIGNUP_23", ", aby si� zalogowa�.");
define("LAN_SIGNUP_24", "Dzi�kujemy za rejestracj�");
define("LAN_SIGNUP_25", "Wy�lij w�asnego awatara");
define("LAN_SIGNUP_26", "Wy�lij swoje zdj�cie");
define("LAN_SIGNUP_27", "Poka�");
define("LAN_SIGNUP_28", "wybierz zawarto��/listy mailingowe");
define("LAN_SIGNUP_29", "Email weryfikacyjny zostanie wys�any na adres, kt�ry wpiszesz w poni�szym formularzu, w zwi�zku z czym musi on by� poprawny.");
define("LAN_SIGNUP_30", "Je�li nie chcesz, aby Tw�j adres email by� wy�wietlany dla innych u�ytkownik�w, prosz� zaznaczy� pole 'ukryj adres email'.");

define("LAN_SIGNUP_31", "Adres URL do pliku XUP");
define("LAN_SIGNUP_32", "Co to jest plik XUP?");
define("LAN_SIGNUP_33", "�cie�ka dost�pu lub wybierz awatar");
define("LAN_SIGNUP_34", "Zapami�taj: Ka�dy obraz nades�any do serwisu, kt�ry zostanie uznany przez administratora za nieodpowiedni, b�dzie natychmiast kasowany.");
define("LAN_SIGNUP_35", "Kliknij tutaj, aby si� zarejestrowa� u�ywaj�c pliku XUP");
define("LAN_SIGNUP_36", "Napotkano na niepokoj�cy b��d w Twoich danych u�ytkownika, prosz� skontaktowa� si� z administratorem strony");

define("LAN_LOGINNAME", "U�ytkownik");
define("LAN_PASSWORD", "Has�o");
define("LAN_USERNAME", "Wy�wietlana nazwa");
define("LAN_EMAIL_01", "Drogi(a)");
define("LAN_EMAIL_04", "Prosz� zachowa� tre�� emaila dla w�asnej wiadomo�ci.");
define("LAN_EMAIL_05", "Twoje has�o zosta�o zaszyfrowane, w zwi�zku z czym je�li je zgubisz lub zapomnisz nie b�dziemy mogli go odzyska�. Jednak�e, je�li dojdzie do takiej sytuacji b�dziesz m�g�(mog�a) otrzyma� nowe has�o.");
define("LAN_EMAIL_06", "Dzi�kujemy za Twoj� rejestracj�.");

define("LAN_SIGNUP_37", "Ten etap rejestracji zosta� zako�czony. Administrator strony wkr�tce dokona akceptacji Twojego nowego konta. Po zatwierdzeniu, otrzymasz emaila potwierdzaj�cego, �e Twoje nowe konto zosta�o zaakceptowane.");
define("LAN_SIGNUP_38", "Wpisa�e� dwa r�ni�ce si� od siebie adresy email. Prosz� wpisa� poprawny adres email w dw�ch wymaganych polach.");
define("LAN_SIGNUP_39", "Powt�rz adres email:");

define("LAN_SIGNUP_40", "Aktywacja nie jest wymagana");
define("LAN_SIGNUP_41", "Twoje konto zosta�o juz aktywowane.");
define("LAN_SIGNUP_42", "Wyst�pi� problem, email rejestracyjny nie zosta� wys�any, prosz� skontaktowa� si� z administratorem strony.");
define("LAN_SIGNUP_43", "Email zosta� wys�any");
define("LAN_SIGNUP_44", "Email aktywacyjny zosta� wys�any na adres:");
define("LAN_SIGNUP_45", "Prosz� sprawdzi� swoj� skrzynk� odbiorcz�.");
define("LAN_SIGNUP_47", "Ponowne wysy�anie emaila aktywacyjnego");
define("LAN_SIGNUP_48", "Login lub adres email");
define("LAN_SIGNUP_49", "Je�li rejestracja zosta�a dokonana z niew�a�ciwym adresem email, to wprowad� poni�ej poprawny i potwierd� wpisuj�c swoje stare has�o:");
define("LAN_SIGNUP_50", "Nowy adres email");
define("LAN_SIGNUP_51", "Stare has�o");
define("LAN_SIGNUP_52", "Niepoprawne has�o");
define("LAN_SIGNUP_53", "pole nie przesz�o testu walidacji");
define("LAN_SIGNUP_54", "Kliknij tutaj, aby wype�ni� formularz rejestracyjny."); // Click here to fill in your details to register
define("LAN_SIGNUP_55", "Wy�wietlana nazwa jest za d�uga. Prosz� wybra� inn�.");
define("LAN_SIGNUP_56", "Wy�wietlana nazwa jest za kr�tka. Prosz� wybra� inn�.");
define("LAN_SIGNUP_57", "Login ten jest zbyt d�ugi. Prosz� wybra� inny.");
define("LAN_SIGNUP_58", "Podgl�d rejestracji");


?>
