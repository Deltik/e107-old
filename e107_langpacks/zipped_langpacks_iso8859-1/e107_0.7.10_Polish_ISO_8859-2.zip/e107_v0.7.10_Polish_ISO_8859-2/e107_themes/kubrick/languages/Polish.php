<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2007/10/08 19:04:17 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_themes/kubrick/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_themes/kubrick/languages/English.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("LAN_THEME_1", "Temat 'kubrick' zosta� wykonany przez <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Bazuje na oryginalnym temacie wykonanym przez Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Komentarze zosta�y wy��czone");
define("LAN_THEME_3", "Komentarze: ");
define("LAN_THEME_4", "Czytaj reszt�...");
define("LAN_THEME_5", "Powi�zania: ");

?>