<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.16 $
|     $Date: 2007/10/21 22:08:41 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/content/languages/Polish/lan_content_admin.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/content/languages/English/lan_content_admin.php rev. 1.22
+-----------------------------------------------------------------------------+
*/
 
define("CONTENT_PLUGIN_LAN_1", "Zarz�dzanie publikacjami");
define("CONTENT_PLUGIN_LAN_2", "Plugin ten stanowi podstawowy zbi�r narz�dzi do zarz�dzania publikacjami, recenzjami, artyku�ami i innego typu tre�ciami.");
define("CONTENT_PLUGIN_LAN_3", "Konfiguracja plugina Zarz�dzanie publikacjami");
define("CONTENT_PLUGIN_LAN_4", "Plugin jest gotowy do u�ycia.");
define("CONTENT_PLUGIN_LAN_5", "Publikacje");
define("CONTENT_PLUGIN_LAN_6", "Struktura tabel plugina do zarz�dzania publikacjami zosta�a zaktualizowana.");

define("CONTENT_LATEST_LAN_1", "Nades�ane publikacje:");
define("CONTENT_STATUS_LAN_1", "Pozycje Publikacji:");

define("CONTENT_ADMIN_CAT_LAN_0", "Tworzenie kategorii publikacji");
define("CONTENT_ADMIN_CAT_LAN_1", "Edycja kategorii publikacji");
define("CONTENT_ADMIN_CAT_LAN_2", "Tytu�");
define("CONTENT_ADMIN_CAT_LAN_3", "Podtytu�");
define("CONTENT_ADMIN_CAT_LAN_4", "Tre��");
define("CONTENT_ADMIN_CAT_LAN_5", "Ikona");
define("CONTENT_ADMIN_CAT_LAN_6", "Wy�lij");
define("CONTENT_ADMIN_CAT_LAN_7", "Zaktualizuj");
define("CONTENT_ADMIN_CAT_LAN_8", "Wy�wietl ikony");
define("CONTENT_ADMIN_CAT_LAN_9", "Nie ma jeszcze �adnej kategorii publikacji");
define("CONTENT_ADMIN_CAT_LAN_10", "Kategorie publikacji");
define("CONTENT_ADMIN_CAT_LAN_11", "Kategoria publikacji zosta�a utworzona");
define("CONTENT_ADMIN_CAT_LAN_12", "Kategoria publikacji zosta�a zaktualizowana");
define("CONTENT_ADMIN_CAT_LAN_13", "Wymagane pola pozosta�y puste.");
define("CONTENT_ADMIN_CAT_LAN_14", "Komentarze");
define("CONTENT_ADMIN_CAT_LAN_15", "Ocena");
define("CONTENT_ADMIN_CAT_LAN_16", "Ikony: drukuj, email...");
define("CONTENT_ADMIN_CAT_LAN_17", "Widoczne dla grupy:");
define("CONTENT_ADMIN_CAT_LAN_18", "Autor:");
define("CONTENT_ADMIN_CAT_LAN_19", "Kategoria publikacji");
define("CONTENT_ADMIN_CAT_LAN_20", "Opcje");
define("CONTENT_ADMIN_CAT_LAN_21", "Wyczy�� formularz");
define("CONTENT_ADMIN_CAT_LAN_22", "Opcje zosta�y zaktualizowane");
define("CONTENT_ADMIN_CAT_LAN_23", "Kategoria publikacji zosta�a usuni�ta");
define("CONTENT_ADMIN_CAT_LAN_24", "ID");
define("CONTENT_ADMIN_CAT_LAN_25", "Ikona");
define("CONTENT_ADMIN_CAT_LAN_26", "Nowa kategoria g��wna");
define("CONTENT_ADMIN_CAT_LAN_27", "Kategoria");
define("CONTENT_ADMIN_CAT_LAN_28", "Przydziel u�ytkownik�w z lewego okna do Osobistego mened�era publikacji dla tej kategorii");
define("CONTENT_ADMIN_CAT_LAN_29", "Administratorzy - kliknij, aby przenie��... ");
define("CONTENT_ADMIN_CAT_LAN_30", "Osobisty mened�er publikacji");
define("CONTENT_ADMIN_CAT_LAN_31", "Usu�");
define("CONTENT_ADMIN_CAT_LAN_32", "Wyczy��");
define("CONTENT_ADMIN_CAT_LAN_33", "Przydziel mened�er�w publikacji");
define("CONTENT_ADMIN_CAT_LAN_34", "Administratorzy zostali pomy�lnie przydzieleni do wskazanej kategorii");
define("CONTENT_ADMIN_CAT_LAN_35", "Publikacje podkategorii zosta�y usuni�te");
define("CONTENT_ADMIN_CAT_LAN_36", "Sprawdzanie kategorii: Zosta�y wykryte podkategorie, kategoria NIE zosta�a usuni�ta. Najpierw usu� wszystkie podkategorie, a nast�pnie spr�buj ponownie.");
define("CONTENT_ADMIN_CAT_LAN_37", "Sprawdzanie publikacji: Zosta�y wykryte publikacje, kategoria NIE zosta�a usuni�ta. Najpierw usu� wszystkie publikacje, a nast�pnie spr�buj ponownie.");
define("CONTENT_ADMIN_CAT_LAN_38", "Sprawdzanie publikacji: nie odnaleziono �adnej publikacji.");
define("CONTENT_ADMIN_CAT_LAN_39", "Sprawdzanie kategorii: nie odnaleziono �adnej podkategorii.");
define("CONTENT_ADMIN_CAT_LAN_40", "Poni�ej zobaczysz wykaz g��wnych kategorii oraz wszystkich dost�pnych podkategorii.<br />");

define("CONTENT_ADMIN_CAT_LAN_41", "Osobisty mened�er kategorii publikacji umo�liwia przyporz�dkowanie okre�lonych administrator�w do danej kategorii. Z tym przywilejem wskazani administratorzy mog� zarz�dza� swoimi w�asnymi i tylko swoimi w�asnymi publikacjami z okre�lonej kategorii, bez potrzeby posiadania kontroli nad ca�ym pluginem <i>Zarz�dzanie publikacjami</i>. Z poziomu normalnej strony publikacji poza panelem admina zobacz� ikon� osobistego mened�era, kt�ra przekieruje ich do strony <i>Osobisty mened�er</i>.");
define("CONTENT_ADMIN_CAT_LAN_42", "Aby przeredagowa� t� sam� kategori�, ");

define("CONTENT_ADMIN_CAT_LAN_43", "kliknij tutaj.");
define("CONTENT_ADMIN_CAT_LAN_44", "Aby doda� kolejn� kategori� do wcze�niej wybranej kategorii g��wnej, ");
define("CONTENT_ADMIN_CAT_LAN_45", "Zezwoli� na komentarze?");
define("CONTENT_ADMIN_CAT_LAN_46", "Zezwoli� na ocen�?");
define("CONTENT_ADMIN_CAT_LAN_47", "Pokazywa� ikony drukuj oraz email?");
define("CONTENT_ADMIN_CAT_LAN_48", "Wybierz u�ytkownik�w, dla kt�rych ta pozycja zostanie wy�wietlona");
define("CONTENT_ADMIN_CAT_LAN_49", "Wybierz ikon� dla tej kategorii");
//define("CONTENT_ADMIN_CAT_LAN_50", "content menu created<br /><br />Because you have created a Main Parent Category, a Menu has been generated.<br />The menu file has been created in your /menus folder.<br /><br />In order to see the menu in action, you still need to activate this menu in your <a href='".e_ADMIN."menus.php'>admin menus area</a>.");
define("CONTENT_ADMIN_CAT_LAN_50", "
Plik menu jest tworzony tylko podczas dodawania nowego, g��wnego dzia�u kategorii.<br />
Plik ten zostanie utworzony w katalogu /menus.<br />
Aby zobaczy� menu w dzia�aniu, potrzebna jest jego aktywacja na stronie <a href ='".e_ADMIN."menus.php ' > Panel administratora - Menu</a>.<br /><br />
");
define("CONTENT_ADMIN_CAT_LAN_51", "B��d: Plik menu nie zosta� utworzony");
define("CONTENT_ADMIN_CAT_LAN_52", "ZAWSZE najpierw wybieraj kategori�, a dopiero po tym wype�niaj inne pole!");
define("CONTENT_ADMIN_CAT_LAN_53", "Aby zarz�dza� innymi kategoriami, ");
define("CONTENT_ADMIN_CAT_LAN_54", "u�ytkownik");
define("CONTENT_ADMIN_CAT_LAN_55", "u�ytkownicy");
define("CONTENT_ADMIN_CAT_LAN_56", "pozycja");
define("CONTENT_ADMIN_CAT_LAN_57", "pozycji");
define("CONTENT_ADMIN_CAT_LAN_58", "Ikona kategorii zosta�a pomy�lnie za�adowana<br />Uwaga: Pomimo za�adowana, musisz wci�� przydzieli� t� ikon� do tworzonej kategorii. W tym celu w sekcji <i>Ikona</i> kliknij na <i>Wy�wietl ikony</i> i z dost�pnych wybierz ikon� przed chwil� za�adowan�!<br />Oczywi�cie po tym musisz wys�a� formularz tworzenia (aktualizowania) danej kategorii.");
define("CONTENT_ADMIN_CAT_LAN_59", "Ikona kategorii nie zosta�a za�adowana");
define("CONTENT_ADMIN_CAT_LAN_60", "Przydziel ikon�");
define("CONTENT_ADMIN_CAT_LAN_61", "�adowanie nowej ikony");
define("CONTENT_ADMIN_CAT_LAN_62", "Po za�adowaniu nowej ikony dla danej kategorii, mo�esz przydzieli� t� ikon� przy pomocy poni�szej sekcji <i>Ikona</i><br />Je�li za�adujesz now� ikon�, zostanie ona przeskalowana do rozmiaru 48 pikseli, r�wnocze�nie dodatkowo zostanie utworzona ikona o rozmiarze 16 pikseli.<br /><br />");
define("CONTENT_ADMIN_CAT_LAN_63", "Za�aduj ikon�");

define("CONTENT_ADMIN_MANAGER_LAN_0", "Zatwierdzanie publikacji");
define("CONTENT_ADMIN_MANAGER_LAN_1", "U�ytkownicy z tej grupy, b�d� w stanie zatwierdza� nades�ane publikacje");
define("CONTENT_ADMIN_MANAGER_LAN_2", "Mened�er osobisty");
define("CONTENT_ADMIN_MANAGER_LAN_3", "U�ytkownicy z tej grupy b�d� w stanie zarz�dza� tylko swoimi w�asnymi publikacjami");
define("CONTENT_ADMIN_MANAGER_LAN_4", "Mened�er katagorii");
define("CONTENT_ADMIN_MANAGER_LAN_5", "U�ytkownicy z tej grupy b�d� w stanie zarz�dza� wszystkimi publikacjami we wskazanej kategorii");


define("CONTENT_ADMIN_ITEM_LAN_0", "Wymagane pola pozosta�y puste");
define("CONTENT_ADMIN_ITEM_LAN_1", "Publikacja zosta�a utworzona");
define("CONTENT_ADMIN_ITEM_LAN_2", "Publikacja zosta�a zaktualizowana");
define("CONTENT_ADMIN_ITEM_LAN_3", "Publikacja zosta�a usuni�ta");
define("CONTENT_ADMIN_ITEM_LAN_4", "Obecnie nie ma jeszcze �adnej publikacji");
define("CONTENT_ADMIN_ITEM_LAN_5", "Aktualne publikacje");
define("CONTENT_ADMIN_ITEM_LAN_6", "Indeks alfabetyczny");
define("CONTENT_ADMIN_ITEM_LAN_7", "Prosz� wybra� jedn� z wy�ej wymienionych liter");
define("CONTENT_ADMIN_ITEM_LAN_8", "ID");
define("CONTENT_ADMIN_ITEM_LAN_9", "Ikona");
define("CONTENT_ADMIN_ITEM_LAN_10", "Autor:");
define("CONTENT_ADMIN_ITEM_LAN_11", "Temat");
define("CONTENT_ADMIN_ITEM_LAN_12", "Opcje");
define("CONTENT_ADMIN_ITEM_LAN_13", "Wybierz g��wn� kategori�");
define("CONTENT_ADMIN_ITEM_LAN_14", "- Imi�");
define("CONTENT_ADMIN_ITEM_LAN_15", "- Adres email");
define("CONTENT_ADMIN_ITEM_LAN_16", "Podtemat");
define("CONTENT_ADMIN_ITEM_LAN_17", "Streszczenie");
define("CONTENT_ADMIN_ITEM_LAN_18", "Tre��");
define("CONTENT_ADMIN_ITEM_LAN_19", "Za�aduj ikon�");
define("CONTENT_ADMIN_ITEM_LAN_20", "Ikona");
define("CONTENT_ADMIN_ITEM_LAN_21", "Ta opcja jest wy��czona, poniewa� �adowanie plik�w na Tw�j serwer jest niemozliwe.");
define("CONTENT_ADMIN_ITEM_LAN_22", "Katalog");
define("CONTENT_ADMIN_ITEM_LAN_23", "jest niezapisywalny, przed za�adowaniem musisz ustawi� CHMOD tego folderu na warto�� 777.");
define("CONTENT_ADMIN_ITEM_LAN_24", "Za��czniki");
define("CONTENT_ADMIN_ITEM_LAN_25", "�adowanie nowej ikony");
define("CONTENT_ADMIN_ITEM_LAN_26", "Skasuj");
define("CONTENT_ADMIN_ITEM_LAN_27", "Obecne pliki dla publikacji");
define("CONTENT_ADMIN_ITEM_LAN_28", "�adowanie nowego pliku");
define("CONTENT_ADMIN_ITEM_LAN_29", "Nie ma jeszcze �adnych plik�w");
define("CONTENT_ADMIN_ITEM_LAN_30", "Plik dla publikacji");
define("CONTENT_ADMIN_ITEM_LAN_31", "Obrazy");
define("CONTENT_ADMIN_ITEM_LAN_32", "Obecne obrazy dla publikacji");
define("CONTENT_ADMIN_ITEM_LAN_33", "�adowanie nowego obrazu");
define("CONTENT_ADMIN_ITEM_LAN_34", "Obraz dla publikacji");
define("CONTENT_ADMIN_ITEM_LAN_35", "Ustaw preferencje dla tej publikacji");
define("CONTENT_ADMIN_ITEM_LAN_36", "Komentarze");
define("CONTENT_ADMIN_ITEM_LAN_37", "Ocena");
define("CONTENT_ADMIN_ITEM_LAN_38", "Ikona drukuj/email");
define("CONTENT_ADMIN_ITEM_LAN_39", "Widoczne dla grupy:");
define("CONTENT_ADMIN_ITEM_LAN_40", "Wynik");
define("CONTENT_ADMIN_ITEM_LAN_41", "Wybierz wynik...");
define("CONTENT_ADMIN_ITEM_LAN_42", "Zaznacz, aby zaktualizowa� dat� publikacji do bie��cego czas");
define("CONTENT_ADMIN_ITEM_LAN_43", "Wy�lij publikacj�");
define("CONTENT_ADMIN_ITEM_LAN_44", "Utw�rz publikacj�");
define("CONTENT_ADMIN_ITEM_LAN_45", "Aktualizuj publikacj�");
define("CONTENT_ADMIN_ITEM_LAN_46", "Podgl�d");
define("CONTENT_ADMIN_ITEM_LAN_47", "Ponowny podgl�d");
define("CONTENT_ADMIN_ITEM_LAN_48", "Dzia� g��wny");
define("CONTENT_ADMIN_ITEM_LAN_49", "Nades�ane publikacje");
define("CONTENT_ADMIN_ITEM_LAN_50", "Obecnie nie ma �adnych nades�anych publikacji");
define("CONTENT_ADMIN_ITEM_LAN_51", "Informacje o autorze");
define("CONTENT_ADMIN_ITEM_LAN_52", "Wy�lij publikacj�");
define("CONTENT_ADMIN_ITEM_LAN_53", "S�owa kluczowe<br />dla znacznika <i>meta</i>");
define("CONTENT_ADMIN_ITEM_LAN_54", "Dodatkowe dane");
define("CONTENT_ADMIN_ITEM_LAN_55", "Powr�� do <a href='".e_SELF."'>g��wnej strony mened�era publikacji</a>, aby zarz�dza� dalej swoimi publikacjami<br />lub<br />Przejd� do <a href='".e_PLUGIN."content/content.php'>g��wnej strony publikacji</a>, aby przejrze� publikacje.");
define("CONTENT_ADMIN_ITEM_LAN_56", "Osobisty mened�er publikacji");
define("CONTENT_ADMIN_ITEM_LAN_57", "Kategoria");
define("CONTENT_ADMIN_ITEM_LAN_58", "Pozycje");
define("CONTENT_ADMIN_ITEM_LAN_59", "Przesu�");
define("CONTENT_ADMIN_ITEM_LAN_60", "Kolejno��");
define("CONTENT_ADMIN_ITEM_LAN_61", "Zaktualizuj kolejno��");
define("CONTENT_ADMIN_ITEM_LAN_62", "Kolejno�� kategorii");
define("CONTENT_ADMIN_ITEM_LAN_63", "ro�nie"); // increases
define("CONTENT_ADMIN_ITEM_LAN_64", "maleje"); // decreases
define("CONTENT_ADMIN_ITEM_LAN_65", "Kolejno�� publikacji");
define("CONTENT_ADMIN_ITEM_LAN_66", "Poni�ej s� wy�wietlone pocz�tkowe litery tytu��w publikacji dla wszystkich pozycji w tej kategorii.<br />Klikni�cie na jedn� z liter spowoduje wy�wietlenie listy wszystkich pozycji rozpoczynaj�cych si� od wskazanej litery. Mo�esz r�wnie� wybra� przycisk ALL, aby wy�wietli� wszystkie pozycje w tej kategorii.");
define("CONTENT_ADMIN_ITEM_LAN_67", "Poni�ej zosta�a sporz�dzona lista publikacji dla wybranej kategorii lub jej odpowiednie zaw�enie dla wybranej litery.<br />Mo�esz edytowa� lub usun�� dan� pozycje poprzez klikni�cie w odpowiedni przycisk po prawej stronie.");
define("CONTENT_ADMIN_ITEM_LAN_68", "Poni�ej masz mo�liwo�� dodania w�asnych danych do tworzonej publikacji. Wszystkie dodane przez Ciebie dane musz� mie� zar�wno identyfikator (<i>kay</i>), a tak�e musz� zawiera� warto�� (<i>value</i>), kt�ra b�dzie prezentowana. Identyfikator (<i>kay</i>) mo�esz okre�li� w polu po lewej stronie, natomiast odpowiedni� warto�c (<i>value</i>) w polu po prawej.<br />(na przyk�ad, key='fotografia' oraz value='wszystkie zdj�cia s� wykonane przeze mnie'.");
define("CONTENT_ADMIN_ITEM_LAN_69", "Tutaj mo�esz za�adowa� ikony, za��czniki oraz obrazy, aby je nast�pnie do��czy� do danej publikacji. Dozwolone typy plik�w: ");
define("CONTENT_ADMIN_ITEM_LAN_70", "Ka�de s�owo oddzielaj przecinkiem, spacje nie s� dozwolone!");
define("CONTENT_ADMIN_ITEM_LAN_71", "Pozostaw bez zmian, je�li jeste� autorem tej publikacji");
define("CONTENT_ADMIN_ITEM_LAN_72", "Zdefiniuj informacje na temat autora");
define("CONTENT_ADMIN_ITEM_LAN_73", "Zdefiniuj dat� rozpocz�cia publikacji (opu��, je�li nie jest to wymagane)");
define("CONTENT_ADMIN_ITEM_LAN_74", "Zdefiniuj dat� zako�czenia publikacji (opu��, je�li nie jest to wymagane)");
define("CONTENT_ADMIN_ITEM_LAN_75", "Wybierz ikon�");
define("CONTENT_ADMIN_ITEM_LAN_76", "Do��cz za��czniki");
define("CONTENT_ADMIN_ITEM_LAN_77", "Do��cz obrazy");
define("CONTENT_ADMIN_ITEM_LAN_78", "Zezwala� na komentarze?");
define("CONTENT_ADMIN_ITEM_LAN_79", "Zezwala� na ocen�?");
define("CONTENT_ADMIN_ITEM_LAN_80", "Wy�wietla� ikony drukuj/email?");
define("CONTENT_ADMIN_ITEM_LAN_81", "Wybierz u�ytkownik�w, dla kt�rych zostanie wy�wietlona ta pozycja");
define("CONTENT_ADMIN_ITEM_LAN_82", "Zdefiniuj wynik");
define("CONTENT_ADMIN_ITEM_LAN_83", "Zdefiniuj s�owa kluczowe dla znacznika <i>meta</i>");
define("CONTENT_ADMIN_ITEM_LAN_84", "Zdefiniuj w�asne pola danych (identyfikator + warto��)");
define("CONTENT_ADMIN_ITEM_LAN_85", "W��cz");
define("CONTENT_ADMIN_ITEM_LAN_86", "Wy��cz");
define("CONTENT_ADMIN_ITEM_LAN_87", "Wybierz ikon� dla tej publikacji");
define("CONTENT_ADMIN_ITEM_LAN_88", "Aby utworzy� now� pozycj� w wcze�niej wybranej kategorii g��wnej, ");
define("CONTENT_ADMIN_ITEM_LAN_89", "Aby edytowa� pozycj� w wcze�niej wybranej kategorii g��wnej, ");
define("CONTENT_ADMIN_ITEM_LAN_90", "kliknij tutaj.");
define("CONTENT_ADMIN_ITEM_LAN_91", "Aby przeredagowa� t� sam� pozycj�, ");
define("CONTENT_ADMIN_ITEM_LAN_92", "Styl rozmieszczenia");
define("CONTENT_ADMIN_ITEM_LAN_93", "Wyb�r schematu uk�adu publikacji");
define("CONTENT_ADMIN_ITEM_LAN_94", "Wybierz schemat uk�adu publikacji");

define("CONTENT_ADMIN_ITEM_LAN_95", "Za�aduj now� ikon�");
define("CONTENT_ADMIN_ITEM_LAN_96", "Wybierz istniej�c� ikon�");
define("CONTENT_ADMIN_ITEM_LAN_97", "Po za�adowaniu ikony, mo�esz j� wybra� w poni�szej sekcji 'Wybierz istniej�c� ikon�'");

define("CONTENT_ADMIN_ITEM_LAN_98", "Za�aduj nowy za��cznik");
define("CONTENT_ADMIN_ITEM_LAN_99", "Wybierz istniej�cy za��cznik");
define("CONTENT_ADMIN_ITEM_LAN_100", "Po za�adowaniu nowego za��cznika, mo�esz go wybra� w poni�szej sekcji 'Wybierz istniej�cy za��cznik'");

define("CONTENT_ADMIN_ITEM_LAN_101", "Za�aduj nowy obraz");
define("CONTENT_ADMIN_ITEM_LAN_102", "Wybierz istniej�cy obraz");
define("CONTENT_ADMIN_ITEM_LAN_103", "Po za�adowaniu nowego obrazu, mo�esz go wybra� w poni�szej sekcji 'Wybierz istniej�cy obraz'");

define("CONTENT_ADMIN_ITEM_LAN_104", "Za�aduj pliki");
define("CONTENT_ADMIN_ITEM_LAN_105", "Podgl�d");

define("CONTENT_ADMIN_ITEM_LAN_106", "Ikona zosta�a pomy�lnie za�adowana<br />Uwaga: Wci�� jednak musisz przydzieli� t� ikon� do tworzonej publikacji. W tym celu w sekcji <i>Ikona</i> kliknij na <i>Wybierz ikon�</i>, nast�pnie kliknij <i>Podgl�d</i> i z dost�pnych wybierz ikon� przed chwil� za�adowan�!<br />Oczywi�cie po tym musisz wys�a� formularz tworzenia (aktualizowania) danej publikacji.");
define("CONTENT_ADMIN_ITEM_LAN_107", "Ikona nie zosta�a za�adowana");

define("CONTENT_ADMIN_ITEM_LAN_108", "Za��cznik zosta� pomy�lnie za�adowany<br />Uwaga: Wci�� jednak musisz przydzieli� ten za��cznik do tworzonej publikacji. W tym celu w sekcji <i>Za��cznik</i> kliknij na <i>Do��cz za��cznik</i>, nast�pnie kliknij <i>Podgl�d</i> i z dost�pnych za��cznik�w wybierz plik przed chwil� za�adowany!<br />Oczywi�cie po tym musisz wys�a� formularz tworzenia (aktualizowania) danej publikacji.");
define("CONTENT_ADMIN_ITEM_LAN_109", "Za��cznik nie zosta� za�adowany");

define("CONTENT_ADMIN_ITEM_LAN_110", "Obraz zosta� pomy�lnie za�adowany<br />Uwaga: Wci�� jednak musisz przydzieli� ten obraz do tworzonej publikacji. W tym celu w sekcji <i>Obrazy</i> kliknij na <i>Do��cz obrazy</i>, nast�pnie kliknij w danej pozycji na <i>Podgl�d</i> i z dost�pnych obraz�w wybierz ten przed chwil� za�adowany!<br />Oczywi�cie po tym musisz wys�a� formularz tworzenia (aktualizowania) danej publikacji.");
define("CONTENT_ADMIN_ITEM_LAN_111", "Obraz nie zosta� za�adowany");

define("CONTENT_ADMIN_ITEM_LAN_112", "Za�aduj ikon�, za��cznik lub obraz");
define("CONTENT_ADMIN_ITEM_LAN_113", "W polu wyboru wybierz typ �adowanego pliku przed za�adowaniem go na serwer.");
define("CONTENT_ADMIN_ITEM_LAN_114", "Ikona");
define("CONTENT_ADMIN_ITEM_LAN_115", "Za��cznik");
define("CONTENT_ADMIN_ITEM_LAN_116", "Obraz");
define("CONTENT_ADMIN_ITEM_LAN_117", "Nades�ana pozycja zosta�a opublikowana.");
define("CONTENT_ADMIN_ITEM_LAN_118", ""); // Obecnie nic nie
define("CONTENT_ADMIN_ITEM_LAN_119", " - nie przydzielono");
define("CONTENT_ADMIN_ITEM_LAN_120", "Domy�lne rozmieszczenie");

define("CONTENT_ADMIN_ITEM_LAN_121", "Nie za�adowano jeszcze �adnej nowej ikony");
define("CONTENT_ADMIN_ITEM_LAN_122", "Nie za�adowano jeszcze �adnego nowego za��cznika");
define("CONTENT_ADMIN_ITEM_LAN_123", "Nie za�adowano jeszcze �adnego nowego obrazka");

define("CONTENT_ADMIN_ITEM_LAN_124", "Aby obejrze� opublikowan� pozycj�, ");


define("CONTENT_ADMIN_ORDER_LAN_0", "Kolejno�� zosta�a zwi�kszona");
define("CONTENT_ADMIN_ORDER_LAN_1", "Kolejno�� zosta�a zmniejszona");
define("CONTENT_ADMIN_ORDER_LAN_2", "Nowa kolejno�� dla publikacji zosta�a zapisana");



define("CONTENT_ADMIN_MAIN_LAN_0", "Aktualne kategorie publikacji");
define("CONTENT_ADMIN_MAIN_LAN_1", "Nie ma jeszcze �adnej kategorii publikacji");
define("CONTENT_ADMIN_MAIN_LAN_2", "Kategorie publikacji");
define("CONTENT_ADMIN_MAIN_LAN_3", "Publikacja zosta�a usuni�ta");
define("CONTENT_ADMIN_MAIN_LAN_4", "Tre�� dzia�u");
define("CONTENT_ADMIN_MAIN_LAN_5", "Ikona dzia�u");
define("CONTENT_ADMIN_MAIN_LAN_6", "");
define("CONTENT_ADMIN_MAIN_LAN_7", "Witaj w Systemie zarz�dzania tre�ci�!");
define("CONTENT_ADMIN_MAIN_LAN_8", "Ta informacja zosta�a wy�wietlona, poniewa� tabela plugina Zarz�dzanie publikacjami nie zawiera �adnych rekord�w.");
define("CONTENT_ADMIN_MAIN_LAN_9", "Prosz� przeczyta� dok�adnie nast�puj�c� informacj� i wybra� to, co b�dziesz chcia� nast�pnie zrobi�.");
define("CONTENT_ADMIN_MAIN_LAN_10", "Na tej stronie mo�esz zarz�dza� publikacjami. Najpierw zdecyduj, w kt�rej kategorii chcia�by� zarz�dza� publikacjami. Aby rozpocz�� zarz�dzanie, wybierz z pola wyboru wybran� przez siebie kategori�.");
define("CONTENT_ADMIN_MAIN_LAN_11", "Poniewa� stare tabele publikacji zawieraj� rekordy, mo�esz wybra� jedn� z trzech nast�puj�cych opcji:");
define("CONTENT_ADMIN_MAIN_LAN_12", "");
define("CONTENT_ADMIN_MAIN_LAN_13", "Na tej stronie mo�esz utworzy� now� publikacj�. Na pocz�tku zdecyduj, w kt�rej kategorii publikacji chcia�by� to zrobi�. Nast�pnie kliknij na przycisk poni�ej i wybierz z listy g��wnych dzia��w kategori�, kt�r� wybra�e�.");
define("CONTENT_ADMIN_MAIN_LAN_14", "Na tej stronie mo�esz ustawi� kolejno�� publikacji. Kliknij na przycisk i wybierz dzia� g��wny, aby rozpocz�� dla niego porz�dkowanie publikacji lub kategorii");
define("CONTENT_ADMIN_MAIN_LAN_15", "Na tej stronie mo�esz zarz�dza� kategoriami. Wybierz g��wn� kategori� przy pomocy poni�szego przycisku, aby wy�wietli� podgl�d wszystkich kategorii i podkategorii znajduj�cych si� wewn�trz kategorii g��wnej.");
define("CONTENT_ADMIN_MAIN_LAN_16", "Na tej stronie mo�esz doda� now� kategori�. Dla nowej g��wnej kategorii, zostanie wy�wietlony domy�lny formularz tworzenia kategorii. Je�eli chcesz utworzy� podkategori� dla istniej�cej kategorii g��wnej, prosz� klikn�� na jeden z przycisk�w umieszczonych poni�ej, aby wy�wietli� formularz tworzenia podkategorii dla wybranej kategorii g��wnej.");
define("CONTENT_ADMIN_MAIN_LAN_17", "Prosz� utworzy� now� kategori� na stronie <a href='".e_SELF."?type.0.cat.create'>Tworzenie nowej kategorii</a>");

define("CONTENT_ADMIN_MAIN_LAN_18", "Konwertuj rekordy");
define("CONTENT_ADMIN_MAIN_LAN_19", "
Pierwsz� rzecz� jak� musisz zrobi� jest wykonanie kopii bezpiecze�stwa bie��cych tabel publikacji, a tak�e tabel komentarzy i ocen.<br />
Do wykonania backupu mo�esz wykorzysta� taki program jak, na przyk�ad: phpMyAdmin.<br />
Po utworzeniu kopii bezpiecze�stwa swoich starych tabel publikacji, mo�esz rozpocz�� konwersj� rekord�w do nowego plugina Zarz�dzanie publikacjami.<br />
Po wykonaniu konwersji swoich starych publikacji, nie powiniene� ju� nigdy wi�cej zobaczy� tej informacji. Od tego momentu mo�esz juz zarz�dza� swoimi aktualnymi publikacjami.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_20", "Rozpocz�cie z pustymi tabelami publikacji");
define("CONTENT_ADMIN_MAIN_LAN_21", "
Je�eli nie potrzebujesz ju� d�u�ej rekord�w ze starej tabeli publikacji,<br /> 
i chcesz tylko rozpocz�� od nowych tabel plugina Zarz�dzanie Publikacjami,<br />
a tak�e nie chcesz tworzy� domy�lnego zestawu kategorii,< br /> 
mo�esz rozpocz�� od utworzenia nowej kategorii.< br />
");
define("CONTENT_ADMIN_MAIN_LAN_22", "Utw�rz domy�lny zestaw kategorii");
define("CONTENT_ADMIN_MAIN_LAN_23", "
Je�eli chcesz rozpocz�� od �wie�ej instalacji, mo�esz najpierw utworzy� domy�lny zestaw kategorii publikacji.< br />
Z domy�lnym zestawem tworzone s� trzy g��wne dzia�y kategorii, mianowicie Kontent (Content), Recenzja (Review) oraz Artyku� (Article).< br /> 
");
define("CONTENT_ADMIN_MAIN_LAN_24", "To jest �wie�a instalacja / Stara tabela publikacji nie zawiera rekord�w");
define("CONTENT_ADMIN_MAIN_LAN_25", "
Poniewa� stara istniej�ca tabela publikacji nie zawiera jakichkolwiek rekord�w, mo�esz rozpocz�� od zarz�dzania nowymi publikacjami.<br />
Klikaj�c na przycisk 'Dalej', automatycznie utworzysz domy�lny zestaw kategorii, Kontent (Content), Recenzja (Review) oraz Artyku� (Article).<br />
");
define("CONTENT_ADMIN_MAIN_LAN_26", "Podgl�d");
define("CONTENT_ADMIN_MAIN_LAN_27", "Ponowny podgl�d");
define("CONTENT_ADMIN_MAIN_LAN_28", "Wybierz kategori� ...");
define("CONTENT_ADMIN_MAIN_LAN_29", "NOWA G��WNA KATEGORIA");



define("CONTENT_ADMIN_MENU_LAN_0", "Zarz�dzanie publikacjami");
define("CONTENT_ADMIN_MENU_LAN_1", "Dodaj publikacj�");
define("CONTENT_ADMIN_MENU_LAN_2", "Zarz�dzanie kategoriami");
define("CONTENT_ADMIN_MENU_LAN_3", "Dodaj kategori�");
define("CONTENT_ADMIN_MENU_LAN_4", "Nades�ane publikacje");
define("CONTENT_ADMIN_MENU_LAN_5", "Kategoria");
define("CONTENT_ADMIN_MENU_LAN_6", "Opcje");
define("CONTENT_ADMIN_MENU_LAN_7", "Admin: Tworzenie publikacji");
define("CONTENT_ADMIN_MENU_LAN_8", "Nadsy�anie publikacji");
define("CONTENT_ADMIN_MENU_LAN_9", "�cie�ki dost�pu i wygl�d");
define("CONTENT_ADMIN_MENU_LAN_10", "Og�lne");
define("CONTENT_ADMIN_MENU_LAN_11", "Podgl�d publikacji");
define("CONTENT_ADMIN_MENU_LAN_12", "Strona kategorii");
define("CONTENT_ADMIN_MENU_LAN_13", "Strona publikacji");
define("CONTENT_ADMIN_MENU_LAN_14", "Menu");
define("CONTENT_ADMIN_MENU_LAN_15", "Kolejno��");
define("CONTENT_ADMIN_MENU_LAN_16", "Strona archiwum");
define("CONTENT_ADMIN_MENU_LAN_17", "Osobisty mened�er publikacji");
define("CONTENT_ADMIN_MENU_LAN_18", "Strona autor�w");
define("CONTENT_ADMIN_MENU_LAN_19", "Mened�er publikacji");
define("CONTENT_ADMIN_MENU_LAN_20", "Najlepiej oceniane strony");
define("CONTENT_ADMIN_MENU_LAN_21", "Strony");
define("CONTENT_ADMIN_MENU_LAN_22", "Najlepiej punktowane strony");
define("CONTENT_ADMIN_MENU_LAN_23", "Admin: Tworzenie kategorii");


define("CONTENT_ADMIN_JS_LAN_0", "Czy na pewno chcesz usun�� wskazan� kategori�?");
define("CONTENT_ADMIN_JS_LAN_1", "Czy na pewno chcesz usun�� wskazan� publikacj�?");
define("CONTENT_ADMIN_JS_LAN_2", "Czy na pewno chcesz usun�� obecny obraz?");
define("CONTENT_ADMIN_JS_LAN_3", "Czy na pewno chcesz usun�� obecny plik?");
define("CONTENT_ADMIN_JS_LAN_4", "Obraz");
define("CONTENT_ADMIN_JS_LAN_5", "Plik");
define("CONTENT_ADMIN_JS_LAN_6", "ID");
define("CONTENT_ADMIN_JS_LAN_7", "Czy na pewno chcesz usun�� obecn� ikon�?");
define("CONTENT_ADMIN_JS_LAN_8", "Ikona");
define("CONTENT_ADMIN_JS_LAN_9", "UWAGA<br />Tylko puste kategorie mog� zosta� usni�te.<br />Kategoria jest pusta tylko wtedy, gdy:<br />NIE zawiera �adnych podkategorii!<br />NIE zawiera �adnych publikacji!");
define("CONTENT_ADMIN_JS_LAN_10", "Czy na pewno chcesz usun�� nades�an� publikacj� nie publikuj�c jej?");



define("CONTENT_ADMIN_SUBMIT_LAN_0", "Nie masz odpowiednich uprawnie� lub nadsy�anie publikacji nie jest aktywne.");
define("CONTENT_ADMIN_SUBMIT_LAN_1", "Rodzaj publikacji");
define("CONTENT_ADMIN_SUBMIT_LAN_2", "Dzi�kuj�, Twoja publikacja zosta�a wys�ana.");
define("CONTENT_ADMIN_SUBMIT_LAN_3", "Dzi�kuj�, Twoja publikacja zosta�a wys�ana i w najbli�szym czasie zostanie zweryfikowana przez administratora w celu dalszej publikacji.");
define("CONTENT_ADMIN_SUBMIT_LAN_4", "Wymagane pola pozosta�y puste");
define("CONTENT_ADMIN_SUBMIT_LAN_5", "Powr�� do strony wyboru <a href='".e_SELF."'>rodzaju publikacji</a>, aby wys�a� kolejne publikacje<br />lub<br />Przejd� do <a href='".e_PLUGIN."content/content.php'>strony g��wnej</a>, aby przegl�dn�� publikacje.");
define("CONTENT_ADMIN_SUBMIT_LAN_6", "");
define("CONTENT_ADMIN_SUBMIT_LAN_7", "");
define("CONTENT_ADMIN_SUBMIT_LAN_8", "Nades�ana publikacja zosta�a usuni�ta");
define("CONTENT_ADMIN_SUBMIT_LAN_9", "");
define("CONTENT_ADMIN_SUBMIT_LAN_10", "");
define("CONTENT_ADMIN_SUBMIT_LAN_11", "");
define("CONTENT_ADMIN_SUBMIT_LAN_12", "");
define("CONTENT_ADMIN_SUBMIT_LAN_13", "");
define("CONTENT_ADMIN_SUBMIT_LAN_14", "");
define("CONTENT_ADMIN_SUBMIT_LAN_15", "");
define("CONTENT_ADMIN_SUBMIT_LAN_16", "");
define("CONTENT_ADMIN_SUBMIT_LAN_17", "");
define("CONTENT_ADMIN_SUBMIT_LAN_18", "");
define("CONTENT_ADMIN_SUBMIT_LAN_19", "");



define("CONTENT_ADMIN_CONVERSION_LAN_0", "Kontent");
define("CONTENT_ADMIN_CONVERSION_LAN_1", "Recenzja");
define("CONTENT_ADMIN_CONVERSION_LAN_2", "Artyku�");
define("CONTENT_ADMIN_CONVERSION_LAN_3", "Kategoria");
define("CONTENT_ADMIN_CONVERSION_LAN_4", "Kategorie");
define("CONTENT_ADMIN_CONVERSION_LAN_5", "Strona");
define("CONTENT_ADMIN_CONVERSION_LAN_6", "Strony");
define("CONTENT_ADMIN_CONVERSION_LAN_7", "G��wny dzia� zosta� wstawiony");
define("CONTENT_ADMIN_CONVERSION_LAN_8", "Preferencje g��wnego dzia�u zosta�y wstawione");
define("CONTENT_ADMIN_CONVERSION_LAN_9", "brak");
define("CONTENT_ADMIN_CONVERSION_LAN_10", "Wymagany g��wny dzia�");
define("CONTENT_ADMIN_CONVERSION_LAN_11", "Analiza konwersji");
define("CONTENT_ADMIN_CONVERSION_LAN_12", "Wszystkich wierszy do przekonwertowania");
define("CONTENT_ADMIN_CONVERSION_LAN_13", "Wszystkich przekonwertowanych wierszy");
define("CONTENT_ADMIN_CONVERSION_LAN_14", "Wszystkich ostrze�e�");
define("CONTENT_ADMIN_CONVERSION_LAN_15", "Wszystkich niepowodze�");
define("CONTENT_ADMIN_CONVERSION_LAN_16", "Analiza starej tabeli publikacji");
define("CONTENT_ADMIN_CONVERSION_LAN_17", "Wszystkich wierszy");
define("CONTENT_ADMIN_CONVERSION_LAN_18", "Nierozpoznanych wierszy");
define("CONTENT_ADMIN_CONVERSION_LAN_19", "Wszystkie wiersze zosta�y rozpoznane");
define("CONTENT_ADMIN_CONVERSION_LAN_20", "G��wny dzia� kontentu");
define("CONTENT_ADMIN_CONVERSION_LAN_21", "G��wny dzia� recenzji");
define("CONTENT_ADMIN_CONVERSION_LAN_22", "G��wny dzia� artyku��w");
define("CONTENT_ADMIN_CONVERSION_LAN_23", "Wstawianie nie powiod�o si�");
define("CONTENT_ADMIN_CONVERSION_LAN_24", "Obecnie nie ma �adnych stron publikacji");
define("CONTENT_ADMIN_CONVERSION_LAN_25", "Aktualne strony publikacji");
define("CONTENT_ADMIN_CONVERSION_LAN_26", "Zosta�o wstawione");
define("CONTENT_ADMIN_CONVERSION_LAN_27", "Analiza konwersji");
define("CONTENT_ADMIN_CONVERSION_LAN_28", "Wszystkich starych wierszy");
define("CONTENT_ADMIN_CONVERSION_LAN_29", "Wszystkich nowych wierszy");
define("CONTENT_ADMIN_CONVERSION_LAN_30", "B��d�w");
define("CONTENT_ADMIN_CONVERSION_LAN_31", "Ostrze�e�");
define("CONTENT_ADMIN_CONVERSION_LAN_32", "Stara kategoria nie istnieje: pozycje zosta�y dodane do kategorii nadrz�dnej");
define("CONTENT_ADMIN_CONVERSION_LAN_33", "Nowa kategoria nie istnieje: pozycje zosta�y dodane do kategorii nadrz�dnej");
define("CONTENT_ADMIN_CONVERSION_LAN_34", "brak");
define("CONTENT_ADMIN_CONVERSION_LAN_35", "Aktualne strony kategorii");
define("CONTENT_ADMIN_CONVERSION_LAN_36", "Aktualne strony oraz nades�ane strony");
define("CONTENT_ADMIN_CONVERSION_LAN_37", "Konwersja kategorii");
define("CONTENT_ADMIN_CONVERSION_LAN_38", "Poprawne wstawienie");
define("CONTENT_ADMIN_CONVERSION_LAN_39", "Nieudane wstawienie");
define("CONTENT_ADMIN_CONVERSION_LAN_40", "Ostrze�enie");
define("CONTENT_ADMIN_CONVERSION_LAN_41", "Ostrze�enie");
define("CONTENT_ADMIN_CONVERSION_LAN_42", "Wynik konwersji starej tabeli publikacji do nowej tabeli publikacji");
define("CONTENT_ADMIN_CONVERSION_LAN_43", "Naci�nij przycisk, aby przekonwertowa� stara tabel� publikacji");
define("CONTENT_ADMIN_CONVERSION_LAN_44", "Nowa tabela publikacji zawiera ju� dane!<br />Czy na pewno chcesz przekonwertowa� star� tabel� publikacji do nowej tabeli?<br /><br />Je�li nadal chcesz przekonwertowa� tabel�, stare dane publikacji zostan� dodane do ju� istniej�cej tabeli publikacji, lecz nie mog� zagwarantowa� tego, �e wszystkie pozycje zostan� dodane do ju� istniej�cych nowych kategorii w nale�yty spos�b!");
define("CONTENT_ADMIN_CONVERSION_LAN_45", "Wstawianie nie powiod�o si�: g��wny dzia� nie zosta� wstawiony");
define("CONTENT_ADMIN_CONVERSION_LAN_46", "Rozpocznij zarz�dzanie publikacjami poprzez przej�cie do <a href='".e_PLUGIN."content/admin_content_config.php'>strony g��wnej plugina Zarz�dzanie publikacjami</a>!");
define("CONTENT_ADMIN_CONVERSION_LAN_47", "Konwersja zosta�a zako�czona");
define("CONTENT_ADMIN_CONVERSION_LAN_48", "Kliknij tutaj, aby uzyska� wi�cej informacji");
define("CONTENT_ADMIN_CONVERSION_LAN_49", "Konwersja stron");
define("CONTENT_ADMIN_CONVERSION_LAN_50", "Konwersja g��wnych dzia��w");
define("CONTENT_ADMIN_CONVERSION_LAN_51", "Nierozpoznane wiersze");
define("CONTENT_ADMIN_CONVERSION_LAN_52", "Domy�lny zestaw g��wnych dzia��w kategorii zosta� utworzony");
define("CONTENT_ADMIN_CONVERSION_LAN_53", "G��wny dzia� o tej nazwie juz istnieje");
define("CONTENT_ADMIN_CONVERSION_LAN_54", "Tworzenie domy�lnego zestawu dzia��w kategorii (kontent, recenzje i artyku�y)");
define("CONTENT_ADMIN_CONVERSION_LAN_55", "Zarz�dzanie publikacjami : opcje konwersji");
define("CONTENT_ADMIN_CONVERSION_LAN_56", "Kliknij w przycisk, aby przej�� do strony tworzenia nowej kategorii publikacji.");
define("CONTENT_ADMIN_CONVERSION_LAN_57", "Wybierz dzia�");
define("CONTENT_ADMIN_CONVERSION_LAN_58", "Aktualizacja do nowszej wersji zosta�a uko�czona pomy�lnie<br /><br /><b>Prosz� zapami�ta�:<br />Po aktualizacji musisz przekonfigurowa� opcje dla ka�dego g��wnego dzia�u<br />oraz musisz usun�� wszystkie menu, kt�re utworzy�e� w katalogu content/menus. Nast�pnie dla okre�lonych dzia��w g��wnych mo�esz utworzy� ponownie menu poprzez aktualizacj� odpowiednich opcji w ich preferencjach.</ b >");

define("CONTENT_ADMIN_CONVERSION_LAN_59", "Konwersja tabeli");
define("CONTENT_ADMIN_CONVERSION_LAN_60", "Utw�rz domy�lne");
define("CONTENT_ADMIN_CONVERSION_LAN_61", "Utw�rz now� kategori�");
define("CONTENT_ADMIN_CONVERSION_LAN_62", "Wersja plugina Zarz�dzanie Publikacjami zosta�a zaktualizowana do wersji:");
define("CONTENT_ADMIN_CONVERSION_LAN_63", "Dokonaj upgrade'u");
define("CONTENT_ADMIN_CONVERSION_LAN_64", "Struktura tabel pluginu Zarz�dzanie publikacjami zosta�a zaktualizowana");
define("CONTENT_ADMIN_CONVERSION_LAN_65", "Plugin Zarz�dzanie publikacjami : content_author - zaktualizowano");
define("CONTENT_ADMIN_CONVERSION_LAN_66", "Plugin Zarz�dzanie publikacjami : content_preferences oraz menus - zaktualizowano");
define("CONTENT_ADMIN_CONVERSION_LAN_67", "Plugin Zarz�dzanie publikacjami : content_preferences - zaktualizowano");
define("CONTENT_ADMIN_CONVERSION_LAN_68", "Plugin Zarz�dzanie publikacjami : content_theme - zaktualizowano");
define("CONTENT_ADMIN_CONVERSION_LAN_69", "");
define("CONTENT_ADMIN_CONVERSION_LAN_70", "");



define("CONTENT_ADMIN_OPT_LAN_MENU_1", "Opcje:");
define("CONTENT_ADMIN_OPT_LAN_MENU_2", "Strony:");
define("CONTENT_ADMIN_OPT_LAN_MENU_3", "Admin: Tworzenie publikacji");
define("CONTENT_ADMIN_OPT_LAN_MENU_4", "Nadsy�anie publikacji");
define("CONTENT_ADMIN_OPT_LAN_MENU_5", "Lokalizacja �cie�ek dost�pu i ustawienia wygl�du");
define("CONTENT_ADMIN_OPT_LAN_MENU_6", "Og�lne");
define("CONTENT_ADMIN_OPT_LAN_MENU_7", "Mened�er publikacji");
define("CONTENT_ADMIN_OPT_LAN_MENU_8", "W�a�ciwo�ci menu");
define("CONTENT_ADMIN_OPT_LAN_MENU_9", "Podgl�d publikacji");
define("CONTENT_ADMIN_OPT_LAN_MENU_10", "Strony kategorii");
define("CONTENT_ADMIN_OPT_LAN_MENU_11", "Strony publikacji");
define("CONTENT_ADMIN_OPT_LAN_MENU_12", "Strona autor�w");
define("CONTENT_ADMIN_OPT_LAN_MENU_13", "Strona archiwum");
define("CONTENT_ADMIN_OPT_LAN_MENU_14", "Lista Top : Najlepiej ocenione strony");
define("CONTENT_ADMIN_OPT_LAN_MENU_15", "Lista Top : Strony z najlepszymi wynikami");
define("CONTENT_ADMIN_OPT_LAN_MENU_16", "Strona wszystkich kategorii (wszystkie kategorie oraz dzia�y g��wne");
define("CONTENT_ADMIN_OPT_LAN_MENU_17", "Strona przegl�danej kategorii (dzia�, podkategorie oraz publikacje w tej kategorii)");
define("CONTENT_ADMIN_OPT_LAN_MENU_18", "Kategorie");
define("CONTENT_ADMIN_OPT_LAN_MENU_19", "Lista ostatnio dodanych");
define("CONTENT_ADMIN_OPT_LAN_MENU_20", "Linki do stron");
define("CONTENT_ADMIN_OPT_LAN_MENU_21", "Admin: Tworzenie kategorii");


define("CONTENT_ADMIN_OPT_LAN_SECTION_0", "Sekcje");
define("CONTENT_ADMIN_OPT_LAN_SECTION_1", "Wybierz sekcje, kt�re maj� by� wy�wietlone");
define("CONTENT_ADMIN_OPT_LAN_SECTION_2", "Za��czniki");
define("CONTENT_ADMIN_OPT_LAN_SECTION_3", "Obrazy");
define("CONTENT_ADMIN_OPT_LAN_SECTION_4", "Komentarze");
define("CONTENT_ADMIN_OPT_LAN_SECTION_5", "Ocena");
define("CONTENT_ADMIN_OPT_LAN_SECTION_6", "Wynik");
define("CONTENT_ADMIN_OPT_LAN_SECTION_7", "Widoczno��");
define("CONTENT_ADMIN_OPT_LAN_SECTION_8", "Okre�lenie znacznika 'meta'");
define("CONTENT_ADMIN_OPT_LAN_SECTION_9", "Schemat rozmieszczenia");
define("CONTENT_ADMIN_OPT_LAN_SECTION_10", "W�asne tagi danych");
define("CONTENT_ADMIN_OPT_LAN_SECTION_11", "Wst�pne dane tag�w");
define("CONTENT_ADMIN_OPT_LAN_SECTION_12", "Podtytu�");
define("CONTENT_ADMIN_OPT_LAN_SECTION_13", "Streszczenie");
define("CONTENT_ADMIN_OPT_LAN_SECTION_14", "Tre�� (okre�l ilo�� s��w)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_15", "Data");
define("CONTENT_ADMIN_OPT_LAN_SECTION_16", "Autor: Imi�");
define("CONTENT_ADMIN_OPT_LAN_SECTION_17", "Autor: Adres email");
define("CONTENT_ADMIN_OPT_LAN_SECTION_18", "Autor: Link - Informacje o autorze");
define("CONTENT_ADMIN_OPT_LAN_SECTION_19", "Autor: Link - Publikacje autora");
define("CONTENT_ADMIN_OPT_LAN_SECTION_20", "Ikony: email, drukuj, pdf");
define("CONTENT_ADMIN_OPT_LAN_SECTION_21", "Aktualnie jeste� w dziale");
define("CONTENT_ADMIN_OPT_LAN_SECTION_22", "Ods�ony (tylko, gdy w��czono zapis)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_23", "Ilo�� pozycji");
define("CONTENT_ADMIN_OPT_LAN_SECTION_24", "Ostatnia pozycja ka�dego autora");
define("CONTENT_ADMIN_OPT_LAN_SECTION_25", "Ilo�� pozycji ka�dego autora");
define("CONTENT_ADMIN_OPT_LAN_SECTION_26", "Ikona szybkiej edycji");
define("CONTENT_ADMIN_OPT_LAN_SECTION_27", "Ikona");
define("CONTENT_ADMIN_OPT_LAN_SECTION_28", "z kategori�");
define("CONTENT_ADMIN_OPT_LAN_SECTION_29", "z list� podkategorii");
define("CONTENT_ADMIN_OPT_LAN_SECTION_30", "W��czone");
define("CONTENT_ADMIN_OPT_LAN_SECTION_31", "Wy��czone");
define("CONTENT_ADMIN_OPT_LAN_SECTION_32", "Podtytu�");
define("CONTENT_ADMIN_OPT_LAN_SECTION_33", "Data rozpocz�cia");
define("CONTENT_ADMIN_OPT_LAN_SECTION_34", "Data zako�czenia");
define("CONTENT_ADMIN_OPT_LAN_SECTION_35", "�adowanie ikon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_36", "Przydzielanie ikon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_37", "Admin: Tworzenie kategorii");
define("CONTENT_ADMIN_OPT_LAN_SECTION_38", "Streszczenie");
define("CONTENT_ADMIN_OPT_LAN_SECTION_39", "");


define("CONTENT_PRESET_LAN_0", "B��d : Nazwa pola nie zosta�a wype�niona.");
define("CONTENT_PRESET_LAN_1", "B��d : Nie wszystkie pola s� wype�nione poprawnie.<br />Wszystkie pola musz� zosta� wype�nione.");
define("CONTENT_PRESET_LAN_2", "");
define("CONTENT_PRESET_LAN_3", "Zar�wno d�ugo��, jak i maksymalna ilo�� znak�w musz� by� podane w postaci liczbowej.");
define("CONTENT_PRESET_LAN_4", "Zar�wno kolumny, jak i wiersze musz� by� podane w postaci liczbowej.");
define("CONTENT_PRESET_LAN_5", "Musisz poda� jakie� opcje");
define("CONTENT_PRESET_LAN_6", "Zar�wno pole lata od, jak i pole lata do musz� by� podane w postaci liczbowej.");
define("CONTENT_PRESET_LAN_7", "Generator zawarto�ci wst�pnych ustawie� p�l");
define("CONTENT_PRESET_LAN_8", "Kreator wst�pnych ustawie� dla tagu danych typu");
define("CONTENT_PRESET_LAN_9", "Nazwa pola");
define("CONTENT_PRESET_LAN_10", "D�ugo��");
define("CONTENT_PRESET_LAN_11", "Maksymalna ilo��<br />znak�w");
define("CONTENT_PRESET_LAN_12", "Kolumny");
define("CONTENT_PRESET_LAN_13", "Wiersze");
define("CONTENT_PRESET_LAN_14", "Lata od");
define("CONTENT_PRESET_LAN_15", "Lata do");
define("CONTENT_PRESET_LAN_16", "Opcje");
define("CONTENT_PRESET_LAN_17", "Dodaj kolejn�");
define("CONTENT_PRESET_LAN_18", "Dodaj wst�pne ustawienia");
define("CONTENT_PRESET_LAN_19", "Musisz poda� w polach zar�wno tekst jak i warto��.");
define("CONTENT_PRESET_LAN_20", "Musisz okre�li� warto�� dla pola wyboru");
define("CONTENT_PRESET_LAN_21", "Tekst");
define("CONTENT_PRESET_LAN_22", "Warto��");
define("CONTENT_PRESET_LAN_23", "Tekst pocz�tkowy");
define("CONTENT_PRESET_LAN_24", "Pierwsza opcja nie ma warto�ci");
define("CONTENT_PRESET_LAN_25", "Dodaj pole...");
define("CONTENT_PRESET_LAN_26", "tekst");
define("CONTENT_PRESET_LAN_27", "pole tekstowe");
define("CONTENT_PRESET_LAN_28", "lista wyboru");
define("CONTENT_PRESET_LAN_29", "data");
define("CONTENT_PRESET_LAN_30", "pole wyboru");
define("CONTENT_PRESET_LAN_31", "pole wyboru (radio)");
define("CONTENT_PRESET_LAN_32", "Przyk�ad:");



define("CONTENT_ADMIN_OPT_LAN_0", "Opcje");
define("CONTENT_ADMIN_OPT_LAN_1", "Domy�lne preferencje");
define("CONTENT_ADMIN_OPT_LAN_2", "Zaktualizuj opcje");
define("CONTENT_ADMIN_OPT_LAN_3", "Ilo�� obraz�w, kt�re b�dzie mo�na za�adowa�");
define("CONTENT_ADMIN_OPT_LAN_4", "Ilo�� za��cznik�w, kt�re b�dzie mo�na za�adowa�");
define("CONTENT_ADMIN_OPT_LAN_5", "Ilo�� dost�pnych w�asnych tag�w danych");
define("CONTENT_ADMIN_OPT_LAN_6", "Wst�pne ustawienie tag�w danych");
define("CONTENT_ADMIN_OPT_LAN_7", "Zdefiniuj domy�lne wst�pne ustawienia dla tag�w danych");
//define("CONTENT_ADMIN_OPT_LAN_8", "Here you can provide additional preset data tags. The fields you provide here are the keys of the key=>value data tags. They will have a input element for the value to be set in the admin creation form. You can choose from the pulldown menu which type of element you want the preset data tag to be. Note: these are not part of the amount of custom data tags you have specified above, and will be used additionally.These Preset Tags are very usefull if you want to have a certain custom tag available standard for each new item. for instance, if you always want to be able to define a value for 'photographer' you can create such a preset tag, which will always be displayed for each new item in this main parent.");
define("CONTENT_ADMIN_OPT_LAN_9", "Zezwoli� na nadsy�anie publikacji?");
define("CONTENT_ADMIN_OPT_LAN_10", "Wybierz grup� uprawnion� do nadsy�ania publikacji?");
define("CONTENT_ADMIN_OPT_LAN_11", "Proste wysy�anie");
define("CONTENT_ADMIN_OPT_LAN_12", "Je�li w��czone, nadsy�ane publikacje zostan� dodane wprost do bazy danych i b�d� zaraz po tym widoczne na stronie, w przeciwnym wypadku administrator strony b�dzie musia� zaakceptowa� dan� publikacj�.");
define("CONTENT_ADMIN_OPT_LAN_13", "Tutaj mo�esz okre�li�, gdzie s� Twoje obrazy, lub gdzie maj� by� przechowywane. Stosuj klamry ( { } ) dla og�lnie zmiennych �cie�ek dost�pu (na przyk�ad {e_PLUGIN} lub {e_IMAGE}). Dla kategorii publikacji ikony wymagane s� w dw�ch wersjach, jeden zbi�r ma�ych ikon oraz drugi zbi�r du�ych ikon. Tymczasowe �cie�ki dost�pu wymagane s� do za�adowania plik�w, musisz je utworzy�!");
define("CONTENT_ADMIN_OPT_LAN_15", "�cie�ka dost�pu do ikon kategorii publikacji (du�a)");
define("CONTENT_ADMIN_OPT_LAN_16", "�cie�ka dost�pu do ikon kategorii publikacji (ma�a)");
define("CONTENT_ADMIN_OPT_LAN_17", "�cie�ka dost�pu do ikon publikacji");
define("CONTENT_ADMIN_OPT_LAN_18", "�cie�ka dost�pu do obraz�w publikacji");
define("CONTENT_ADMIN_OPT_LAN_19", "�cie�ka dost�pu do za��cznik�w publikacji");
define("CONTENT_ADMIN_OPT_LAN_20", "Zdefiniuj wygl�d g��wnej kategorii");
define("CONTENT_ADMIN_OPT_LAN_21", "Zdefiniuj domy�lny schemat rozmieszczenia");
define("CONTENT_ADMIN_OPT_LAN_22", "Aktywowa� zapis ilo�ci ods�on?");
define("CONTENT_ADMIN_OPT_LAN_23", "Pokazuj pust� ikon� publikacji, je�li nie ma bie��cej ikony");
define("CONTENT_ADMIN_OPT_LAN_24", "Pokazuj pust� ikon� kategorii, je�li nie ma bie��cej ikony");
define("CONTENT_ADMIN_OPT_LAN_25", "Wybierz schemat rozmieszczenia");
define("CONTENT_ADMIN_OPT_LAN_26", "Pokazuj sekcj� <i>Aktualnie jeste� w dziale</i> dla nast�puj�cych stronach:");
define("CONTENT_ADMIN_OPT_LAN_27", "Wszystkie kategorie");
define("CONTENT_ADMIN_OPT_LAN_28", "Pojedyncza kategoria");
define("CONTENT_ADMIN_OPT_LAN_29", "Wszyscy autorzy");
define("CONTENT_ADMIN_OPT_LAN_30", "Pojedynczy autor");
define("CONTENT_ADMIN_OPT_LAN_31", "Ostatnio dodane");
define("CONTENT_ADMIN_OPT_LAN_32", "Publikacje");
define("CONTENT_ADMIN_OPT_LAN_33", "Najlepiej oceniane");
define("CONTENT_ADMIN_OPT_LAN_34", "Archiwum");
define("CONTENT_ADMIN_OPT_LAN_35", "Najlepsze wyniki");
define("CONTENT_ADMIN_OPT_LAN_36", "Znak rozdzielaj�cy dla sekcji <i>Aktualnie jeste� w dziale</i>");
define("CONTENT_ADMIN_OPT_LAN_37", "Zdefiniuj jak przedstawia� informacje w sekcji <i>Aktualnie jeste� w dziale</i>");
define("CONTENT_ADMIN_OPT_LAN_38", "TYMCZASOWA");
define("CONTENT_ADMIN_OPT_LAN_39", "Zastosuj echo");
define("CONTENT_ADMIN_OPT_LAN_40", "U�yj oddzielnej sekcji");
define("CONTENT_ADMIN_OPT_LAN_41", "Po��cz w jedn� sekcj�");
define("CONTENT_ADMIN_OPT_LAN_42", "");
define("CONTENT_ADMIN_OPT_LAN_43", "Wy�wietl sekcj� nawigacyjn� na nast�puj�cych stronach:");
define("CONTENT_ADMIN_OPT_LAN_44", "Wy�wietl wyszukiwark� na nast�puj�cych stronach:");
define("CONTENT_ADMIN_OPT_LAN_45", "");
define("CONTENT_ADMIN_OPT_LAN_46", "Wy�wietl opcj� wyboru kolejno�ci na nast�puj�cych stronach:");
define("CONTENT_ADMIN_OPT_LAN_47", "");
define("CONTENT_ADMIN_OPT_LAN_48", "Metoda prezentacji nawigatora, wyszukiwarki, opcji kolejno�ci");
define("CONTENT_ADMIN_OPT_LAN_49", "Wy�wietlaj ograniczon� ilo�� publikacji na stronie?");
define("CONTENT_ADMIN_OPT_LAN_50", "Jak du�o pozycji ma by� wy�wietlonych?");
define("CONTENT_ADMIN_OPT_LAN_51", "Wybierz domy�ln� metod� sortowania");
define("CONTENT_ADMIN_OPT_LAN_52", "Maksymalna wielko�� obrazka");
define("CONTENT_ADMIN_OPT_LAN_53", "Zdefiniuj wielko��, do kt�rej b�d� zmniejszane za�adowane obrazki");
define("CONTENT_ADMIN_OPT_LAN_54", "Je�li szeroko�� lub wysoko�� za�adowanego obrazka b�dzie wi�ksza ni� podana warto��, to zostanie ona zmieniona do podanej warto�ci.<br />Obrazki w oknach typu popup (wyskakuj�ce) b�d� r�wnie� wy�wietlane zgodnie z podan� warto�ci�.");
define("CONTENT_ADMIN_OPT_LAN_55", "Wielko�� miniaturki obrazka");
define("CONTENT_ADMIN_OPT_LAN_56", "Zdefiniuj wielko�� miniaturki, kt�ra zostanie utworzona podczas �adowania obrazka");
define("CONTENT_ADMIN_OPT_LAN_57", "Je�li wysoko�� lub szeroko�� �adowanego obrazka b�dzie wi�ksza ni� podana warto��, to zostanie on zmniejszony do podanej warto�ci.<br />Obrazki wy�wietlane na stronach publikacji b�d� r�wnie� mia�y wymiary zgodne z warto�ci� podan� poni�ej.");
define("CONTENT_ADMIN_OPT_LAN_58", "Maksymalna szeroko�� ikony");
define("CONTENT_ADMIN_OPT_LAN_59", "Zdefiniuj maksymaln� szeroko�� dla �adowanych ikon");
define("CONTENT_ADMIN_OPT_LAN_60", "Je�li �adowana ikona b�dzie wi�ksza ni� podanej warto�ci, to zostanie zmniejszona zgodnie z t� warto�ci�. Ikony b�d� r�wnie� wy�wietlane zgodnie z podan� poni�ej warto�ci�");
define("CONTENT_ADMIN_OPT_LAN_61", "pikseli");
define("CONTENT_ADMIN_OPT_LAN_62", "Wybierz grup� u�ytkownik�w do zarz�dzania mened�erem");
define("CONTENT_ADMIN_OPT_LAN_63", "Mo�esz zdefiniowa� dla kilku obszar�w, kt�ra grupa u�ytkownik�w b�dzie w stanie przegl�da� okre�lone strony. U�ywaj�c tej opcji mo�esz ograniczy� dost�p do pewnych obszar�w oraz stron dla okre�lonych grup u�ytkownik�w.");
define("CONTENT_ADMIN_OPT_LAN_64", "Wy�wietlaj adres email niezarejestrowanych autor�w");
define("CONTENT_ADMIN_OPT_LAN_65", "Wy�wietlaj literowy indeks");
define("CONTENT_ADMIN_OPT_LAN_66", "Literowy indeks jest zbiorem przycisk�w utworzonym z pierwszych liter poszczeg�lnych publikacji. Mo�esz zaw�zi� list� archiwum poprzez klikni�cie na okre�lon� liter�, w ten spos�b spowodujesz, �e tylko publikacje rozpoczynaj�ce si� od wskazanej litery zostan� wy�wietlone na ekranie.");
define("CONTENT_ADMIN_OPT_LAN_67", "Zdefiniuj format wy�wietlanej daty");
define("CONTENT_ADMIN_OPT_LAN_68", "Wi�cej informacji na temat formatowania daty mo�esz uzyska� na stronie serwisu php.net - <a href='http://www.php.net/manual/pl/function.strftime.php' rel='external'>funkcja strftime</a>.");
define("CONTENT_ADMIN_OPT_LAN_69", "Wy�wietlaj ikony dla wszystkich pozycji<br />(ikony: drukuj, email, pdf)");
define("CONTENT_ADMIN_OPT_LAN_70", "Zezw�l na ocen� wszystkich pozycji");
define("CONTENT_ADMIN_OPT_LAN_71", "Zezw�l na komentowanie wszystkich pozycji");
define("CONTENT_ADMIN_OPT_LAN_72", "");
define("CONTENT_ADMIN_OPT_LAN_73", "Metoda prezentacji spisu tre�ci dla wielostronicowych publikacji");
define("CONTENT_ADMIN_OPT_LAN_74", "Je�li masz na przyk�ad wielostronicowy artyku�, mo�esz wy�wietli� jego indeks stron w postaci listy utworzonej z normalnych hiper��cz, albo w postaci listy wyboru.");
define("CONTENT_ADMIN_OPT_LAN_75", "Hiper��cza");
define("CONTENT_ADMIN_OPT_LAN_76", "Rozwijana lista");
define("CONTENT_ADMIN_OPT_LAN_77", "Zdefiniuj ilo�� znak�w");
define("CONTENT_ADMIN_OPT_LAN_78", "Zdefiniuj przyrostek");
define("CONTENT_ADMIN_OPT_LAN_79", "Pozostaw puste, aby wy�wietli� ca�o��");
define("CONTENT_ADMIN_OPT_LAN_80", "Pozostaw puste, aby nic nie wy�wietla�");
define("CONTENT_ADMIN_OPT_LAN_81", "Zdefiniuj ilo�� s��w");
define("CONTENT_ADMIN_OPT_LAN_82", "Tekst");
define("CONTENT_ADMIN_OPT_LAN_83", "Przyrostek w postaci linka");
define("CONTENT_ADMIN_OPT_LAN_84", "Wy�wietlaj dzia�y");
define("CONTENT_ADMIN_OPT_LAN_85", "Wy�wietlaj dzia�y podkategorii");
define("CONTENT_ADMIN_OPT_LAN_86", "Wy�wietlaj publikacje z dzia��w podkategorii");
define("CONTENT_ADMIN_OPT_LAN_87", "Je�li w��czysz, zostan� wy�wietlone wszystkie publikacje z wybranej kategorii oraz wszystkie publikacje podrz�dnych do niej kategorii.");
define("CONTENT_ADMIN_OPT_LAN_88", "Zdefiniuj kolejno�� wy�wietlania dzia��w oraz publikacji");
define("CONTENT_ADMIN_OPT_LAN_89", "Najpierw dzia�, nast�pnie publikacje");
define("CONTENT_ADMIN_OPT_LAN_90", "Najpierw publikacje, nast�pnie dzia�y");
define("CONTENT_ADMIN_OPT_LAN_91", "Metoda prezentacji dzia��w, podkategorii oraz publikacji");
define("CONTENT_ADMIN_OPT_LAN_92", "Wszystkie sekcje oddzielnie");
define("CONTENT_ADMIN_OPT_LAN_93", "Nag��wek");
define("CONTENT_ADMIN_OPT_LAN_94", "Dodaj sekcj� wyszukiwarki");
define("CONTENT_ADMIN_OPT_LAN_95", "Dodaj sekcj� ustawiania kolejno�ci");
define("CONTENT_ADMIN_OPT_LAN_96", "Wy�wietl linki nawigacyjne");
define("CONTENT_ADMIN_OPT_LAN_97", "Je�li wy��czone, wszystkie poni�sze opcje link�w zostan� pomini�te");
define("CONTENT_ADMIN_OPT_LAN_98", "Link : Wszystkie kategorie");
define("CONTENT_ADMIN_OPT_LAN_99", "Link : Wszyscy autorzy");
define("CONTENT_ADMIN_OPT_LAN_100", "Link : Wszystkie publikacje");
define("CONTENT_ADMIN_OPT_LAN_101", "Link : Najlepiej ocenione");
define("CONTENT_ADMIN_OPT_LAN_102", "Link : Najlepsze wyniki");
define("CONTENT_ADMIN_OPT_LAN_103", "Link : Ostatnio dodane");
define("CONTENT_ADMIN_OPT_LAN_104", "Link : Wy�lij publikacj�");
define("CONTENT_ADMIN_OPT_LAN_105", "Ikona : Linki");
define("CONTENT_ADMIN_OPT_LAN_106", "none (), bullet (), middot (&middot;), white bullet (�), arrow (&raquo;), category_icon()");
define("CONTENT_ADMIN_OPT_LAN_107", "Brak");
define("CONTENT_ADMIN_OPT_LAN_108", "Bullet (zdefiniowany w temacie)");
define("CONTENT_ADMIN_OPT_LAN_109", "Ma�y punktor");
define("CONTENT_ADMIN_OPT_LAN_110", "Okr�g�y punktor");
define("CONTENT_ADMIN_OPT_LAN_111", "Strza�eczka");
define("CONTENT_ADMIN_OPT_LAN_112", "Ikona kategorii");
define("CONTENT_ADMIN_OPT_LAN_113", "Ikona publikacji");
define("CONTENT_ADMIN_OPT_LAN_114", "Metoda prezentacji link�w");
define("CONTENT_ADMIN_OPT_LAN_115", "Nag��wek listy link�w");
define("CONTENT_ADMIN_OPT_LAN_116", "Ten nag��wek zostanie tylko zastosowany, je�li linki s� wy�wietlane jako 'normalne linki' (hiper��cza).");
define("CONTENT_ADMIN_OPT_LAN_117", "Wy�wietlaj kategorie");
define("CONTENT_ADMIN_OPT_LAN_118", "Uwzgl�dniaj g��wne kategorie");
define("CONTENT_ADMIN_OPT_LAN_119", "Je�li wy��czone, zostan� wy�wietlone tylko podkategorie g��wnych dzia��w.");
define("CONTENT_ADMIN_OPT_LAN_120", "Wy�wietlaj ilo�� publikacji w ka�dej kategorii");
define("CONTENT_ADMIN_OPT_LAN_121", "Ikona : Kategorii");
define("CONTENT_ADMIN_OPT_LAN_122", "Ikona : Kategorii (domy�lna)");
define("CONTENT_ADMIN_OPT_LAN_123", "Metoda prezentacji listy kategorii");
define("CONTENT_ADMIN_OPT_LAN_124", "Nag��wek listy kategorii");
define("CONTENT_ADMIN_OPT_LAN_125", "Wy�wietlaj ostatnio dodane");
define("CONTENT_ADMIN_OPT_LAN_126", "Wy�wietlaj dat�");
define("CONTENT_ADMIN_OPT_LAN_127", "Wy�wietlaj autora");
define("CONTENT_ADMIN_OPT_LAN_128", "Wy�wietlaj podtytu�");
define("CONTENT_ADMIN_OPT_LAN_129", "Podtytu� : Zdefiniuj ilo�� s��w");
define("CONTENT_ADMIN_OPT_LAN_130", "Podtytu� : Zdefiniuj przyrostek");
define("CONTENT_ADMIN_OPT_LAN_131", "Ile publikacji ma zosta� wy�wietlonych");
define("CONTENT_ADMIN_OPT_LAN_132", "Ikona dla ostatnio dodanych publikacji");
define("CONTENT_ADMIN_OPT_LAN_133", "Ikona : szeroko��");
define("CONTENT_ADMIN_OPT_LAN_134", "Je�li wybra�e� 'Ikona publikacji', zdefiniuj szeroko�� dla wykorzystywanych ikon.");
define("CONTENT_ADMIN_OPT_LAN_135", "Nag��wek ostatnio dodanych publikacji");
define("CONTENT_ADMIN_OPT_LAN_136", "Back End");
define("CONTENT_ADMIN_OPT_LAN_137", "Front End");
define("CONTENT_ADMIN_OPT_LAN_138", "Zarz�dzanie publikacjami");
define("CONTENT_ADMIN_OPT_LAN_139", "Tworzenie publikacji");
define("CONTENT_ADMIN_OPT_LAN_140", "Zarz�dzanie kategoriami");
define("CONTENT_ADMIN_OPT_LAN_141", "Tworzenie kategorii");
define("CONTENT_ADMIN_OPT_LAN_142", "Kolejno��");
define("CONTENT_ADMIN_OPT_LAN_143", "Opcje");
define("CONTENT_ADMIN_OPT_LAN_144", "Osobisty mened�er publikacji");
define("CONTENT_ADMIN_OPT_LAN_145", "Ostatnio dodane");
define("CONTENT_ADMIN_OPT_LAN_146", "Wszystkie kategorie");
define("CONTENT_ADMIN_OPT_LAN_147", "Pojedyncza kategoria");
define("CONTENT_ADMIN_OPT_LAN_148", "Publikacje");
define("CONTENT_ADMIN_OPT_LAN_149", "Strona autor�w");
define("CONTENT_ADMIN_OPT_LAN_150", "Strona archiwum");
define("CONTENT_ADMIN_OPT_LAN_151", "Najlepiej ocenione strone");
define("CONTENT_ADMIN_OPT_LAN_152", "Najlepiej punktowane strony");
define("CONTENT_ADMIN_OPT_LAN_153", "Strona nadsy�ania");
define("CONTENT_ADMIN_OPT_LAN_154", "Strona zarz�dzania");
define("CONTENT_ADMIN_OPT_LAN_155", "Nag��wek");
define("CONTENT_ADMIN_OPT_LAN_156", "Nag��wek strony indeksowej");
define("CONTENT_ADMIN_OPT_LAN_157", "Nag��wek strony autor�w");
define("CONTENT_ADMIN_OPT_LAN_158", "Do��czaj nazw� autora do nag��wka");
define("CONTENT_ADMIN_OPT_LAN_159", "Nag��wek strony kategorii");
define("CONTENT_ADMIN_OPT_LAN_160", "Do��czaj nazw� kategorii do nag��wka");
define("CONTENT_ADMIN_OPT_LAN_161", "Nag��wek dzia�u podkategorii (u�ywane tylko, je�li metoda prezentacji jest ustawiona na oddzielne menu)");
define("CONTENT_ADMIN_OPT_LAN_162", "Nag��wek publikacji (u�ywane tylko, je�li metoda prezentacji jest ustawiona na oddzielne menu)");
define("CONTENT_ADMIN_OPT_LAN_163", "Wy�wietlaj linki do nast�pnej oraz poprzedniej strony");
define("CONTENT_ADMIN_OPT_LAN_164", "Nag��wek dla linka - poprzednia strona<br />(u�yj {PAGETITLE}, aby doda� tytu� poprzedniej strony)");
define("CONTENT_ADMIN_OPT_LAN_165", "Nag��wek dla linka - nast�pna strona<br />(u�yj {PAGETITLE}, aby doda� tytu� nast�pnej strony)");
define("CONTENT_ADMIN_OPT_LAN_166", "U�yj wszystkich ('all'), aby wy�wietli� pe�ny tekst");
define("CONTENT_ADMIN_OPT_LAN_167", "dziedziczenie");
define("CONTENT_ADMIN_OPT_LAN_168", "Pierwsza strona");
define("CONTENT_ADMIN_OPT_LAN_169", "Ostatnia strona");
define("CONTENT_ADMIN_OPT_LAN_170", "Gdzie na wielostronicowych publikacjach powinny byc przedstawione w�asne oraz wcze�niej zdefiniowane tagi?");
define("CONTENT_ADMIN_OPT_LAN_171", "Ilo�� poziom�w");
define("CONTENT_ADMIN_OPT_LAN_172", "Liczbowa warto�� do wy�wietlenia ilo�ci podkategorii drzewa kategorii. Pozostaw puste, aby pokaza� wszystkie poziomy.");
define("CONTENT_ADMIN_OPT_LAN_173", "Uwzgl�dniaj 'Stron� domow�' w �cie�kach dla 'Aktualnie jeste� w dziale'");
define("CONTENT_ADMIN_OPT_LAN_174", "Uwzgl�dniaj 'Stron� publikacji' w �cie�kach dla 'Aktualnie jeste� w dziale'");

?>
