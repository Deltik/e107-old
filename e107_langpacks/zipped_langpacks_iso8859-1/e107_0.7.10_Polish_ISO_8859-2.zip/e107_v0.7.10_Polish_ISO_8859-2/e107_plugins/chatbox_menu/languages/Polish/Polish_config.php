<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:37:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/chatbox_menu/languages/Polish/Polish_config.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/chatbox_menu/languages/English/English_config.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("CHBLAN_1", "Ustawienia czatu zosta�y zaktualizowane.");
define("CHBLAN_2", "Zmoderowany.");
define("CHBLAN_3", "Nie ma jeszcze �adnych post�w na czacie.");
define("CHBLAN_4", "U�ytkownik");
define("CHBLAN_5", "Go��");
define("CHBLAN_6", "Odblokuj");
define("CHBLAN_7", "Zablokuj");
define("CHBLAN_8", "Usu�");
define("CHBLAN_9", "Moderuj czat");
define("CHBLAN_10", "Moderuj posty");
define("CHBLAN_11", "Wybierz ilo�� wy�wietlanych post�w na czacie");
define("CHBLAN_12", "Ilo�� post�w widocznych na czacie");
define("CHBLAN_13", "Zast�p linki");
define("CHBLAN_14", "Je�li zaznaczone, nades�ane linki b�d� zast�powane przez tekst wpisany poni�ej");
define("CHBLAN_15", "Zast�p wyra�eniem, je�li opcja jest aktywna");
define("CHBLAN_16", "Linki b�d� zast�pione przez podane wyra�enie");
define("CHBLAN_17", "D�ugo�� zawijanego s�owa");
define("CHBLAN_18", "S�owa d�u�sze ni� zdefiniowanej d�ugo�ci b�d� zawijane");
define("CHBLAN_19", "Aktualizuj ustawienia");
define("CHBLAN_20", "Ustawienia czata");
define("CHBLAN_21", "Czyszczenie");
define("CHBLAN_22", "Usu� posty starsze ni� podany okres czasu");
define("CHBLAN_23", "Usu� starsze posty ni� ");

define("CHBLAN_24", "Dzie�");
define("CHBLAN_25", "Tydzie�");
define("CHBLAN_26", "Miesi�c");
define("CHBLAN_27", "- Usu� wszystkie posty -");
define("CHBLAN_28", "Czat zosta� wyczyszczony.");

define("CHBLAN_29", "Wy�wietlaj czat wewn�trz przewijalnej sekcji");
define("CHBLAN_30", "Wysoko�� sekcji");
define("CHBLAN_31", "Pokazuj emotikony");
define("CHBLAN_32", "Grupa moderator�w");

define("CHBLAN_33", "Ilo�� post�w zosta�a skalkulowana"); // User counts recalculated
define("CHBLAN_34", "Przelicz ponownie ilo�� post�w u�ytkownika"); // Recalculate user post counts
define("CHBLAN_35", "Przelicz");

define("CHBLAN_36", "Opcje wy�wietlania czata");
define("CHBLAN_37", "Normalny czat");
define("CHBLAN_38", "U�ywaj j�zyka javascript do dynamicznej aktualizacji post�w (AJAX)");

?>
