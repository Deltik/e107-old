<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/21 12:35:15 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/chatbox_menu/languages/Polish/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/chatbox_menu/languages/English/English.php rev. 1.7
+-----------------------------------------------------------------------------+
*/
 
define("CHATBOX_L1", "Post zosta� odrzucony, poniewa� podana nazwa u�ytkownika jest ju� zarejestrowana - je�li to jest Twoja nazwa u�ytkownika zaloguj si�, aby pisa� posty.");
define("CHATBOX_L2", "Czat");
define("CHATBOX_L3", "Musisz by� zalogowany, aby wystawia� komentarze na tej stronie. Prosz� si� zalgowa� lub je�li nie masz jeszcze konta <a href='".e_BASE."signup.php'>zarejestruj si�</a>");
define("CHATBOX_L4", "Wy�lij");
define("CHATBOX_L5", "Wyczy��");
define("CHATBOX_L6", "[zablokowane przez administratora]");
define("CHATBOX_L7", "Odblokuj");
define("CHATBOX_L8", "Informacje");
define("CHATBOX_L9", "Zablokuj");
define("CHATBOX_L10", "Usu�");
define("CHATBOX_L11", "Nie ma jeszcze �adnych wiadomo�ci.");
define("CHATBOX_L12", "Zobacz wszystkie posty");
define("CHATBOX_L13", "Moderuj czat");
define("CHATBOX_L14", "Emoty");
define("CHATBOX_L15", "Wys�ana wiadomo�� jest za d�uga lub nie zawiera �adnych znak�w");
define("CHATBOX_L16", "Anonim");
define("CHATBOX_L17", "Wykryto duplikat postu");
define("CHATBOX_L18", "Wiadomo�� zmoderowana");
define("CHATBOX_L19", "Mo�esz pisa� tylko jeden post co ka�de ".(FLOODPROTECT ? FLOODTIMEOUT : 'n/a')." sekund");

define("CHATBOX_L20", "Czat (wszystkie posty)");
define("CHATBOX_L21", "Posty na czacie");
define("CHATBOX_L22", "dnia");
define("CHATBOX_L23", "B��d!");
define("CHATBOX_L24", "Nie masz odpowiednich uprawnie� do przegl�dania tej strony.");
define("CHATBOX_L25", "[ten post zosta� zablokowany przez administratora]");

// Powiadomienia
define("NT_LAN_CB_1", "Wiadomo�ci na czacie"); // Chatbox Events kto wymy�li lepsze t�umaczenie niech da zna� ;)
define("NT_LAN_CB_2", "Wiadomo�� zosta�a wys�ana");
define("NT_LAN_CB_3", "Dodane przez");
define("NT_LAN_CB_4", "Adres IP");
define("NT_LAN_CB_5", "Wiadomo��");
define("NT_LAN_CB_6", "Wystawione posty na czacie"); // ??

?>
