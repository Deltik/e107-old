<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2006/11/19 17:05:21 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/newsfeed/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/newsfeed/languages/English.php rev. 1.9
+-----------------------------------------------------------------------------+
*/
 
define("NFLAN_01", "Kana�y informacyjne"); //  (Agregator RSS)
define("NFLAN_02", "Ten plugin b�dzie odbiera� kana�y rss z innych stron internetowych, a nast�pnie wy�wietli je zgodnie z Twoim preferencjami.");  // This plugin will retrieve rss feeds from other websites and display them according to your preferences
define("NFLAN_03", "Konfiguruj Kana�y informacyjne");
define("NFLAN_04", "Plugin Kana�y informacyjne zosta� pomy�lnie zainstalowany. Aby doda� kana�y wiadomo�ci i je skonfigurowa�, powr�� do <i>Panelu administratora</i> i kliknij w sekcji plugin�w na linku <i>Kana�y informacyjne</i>.");
define("NFLAN_05", "Edytuj");
define("NFLAN_06", "Usu�");
define("NFLAN_07", "Aktualne kana�y informacyjne");
define("NFLAN_08", "Strona g��wna Kana�y informacyjne");
define("NFLAN_09", "Utw�rz kana� informacyjny");
define("NFLAN_10", "URL do kana�u rss");
define("NFLAN_11", "�cie�ka dost�pu do obrazka");
define("NFLAN_12", "Aktywacja");
define("NFLAN_13", "Nigdzie (nieaktywne)");
define("NFLAN_14", "Tylko w menu");
define("NFLAN_15", "Utw�rz kana� informacyjny");
define("NFLAN_16", "Zaktualizuj kana� informacyjny");
define("NFLAN_17", "Aby u�ywa� obrazka zdefiniowanego w kanale wpisz 'default'. Je�li chcesz u�ywa� w�asnego obrazka wpisz pe�n� �cie�k� dost�pu, aby nie wy�wietla� obrazka pozostaw to pole puste.");
define("NFLAN_18", "Okres aktualizacji w sekundach");
define("NFLAN_19", "np, warto�� 3600 oznacza, �e kana� informacyjny b�dzie aktualizowany co godzin�");
define("NFLAN_20", "Tylko na stronie g��wnej kana��w informacyjnych");
define("NFLAN_21", "Jednocze�nie w menu i na stronie kana��w informacyjnych");
define("NFLAN_22", "Wybierz miejsce wy�wietlania wskazanego kana�u informacyjnego"); // choose where you want the newsfeed displayed
define("NFLAN_23", "Kana� informacyjny zosta� dodany do bazy danych.");
define("NFLAN_24", "Wymagane pola pozosta�y puste.");
define("NFLAN_25", "Kana� informacyjny zosta� zaktualizowany w bazie danych.");
define("NFLAN_26", "Okres aktualizacji");
define("NFLAN_27", "Opcje");
define("NFLAN_28", "URL");
define("NFLAN_29", "Dost�pne kana�y informacyjne");
define("NFLAN_30", "Nazwa kana�u");
define("NFLAN_31", "Powr�� do listy kana��w informacyjnych");
define("NFLAN_32", "Nie mog� odnale�� kana�u ze wskazanym numerem identyfikacyjnym"); // 
define("NFLAN_33", "Data publikacji: ");
define("NFLAN_34", "nieznana");
define("NFLAN_35", "dodane przez ");
define("NFLAN_36", "Opis");
define("NFLAN_37", "kr�tki opis kana�u, aby u�y� opisu zdefiniowanego przez nadawc� kana�u wpisz 'default'");
define("NFLAN_38", "Serwis wiadomo�ci");
define("NFLAN_39", "Szczeg�y");
define("NFLAN_40", "Kana� wiadomo�ci zosta� usuni�ty");
define("NFLAN_41", "Nie ma jeszcze zdefiniowanych kana��w informacyjnych");

define("NFLAN_42", "<b>&raquo;</b> <u>Nazwa kana�u:</u>
	Nazwa pod jak� kana� b�dzie identyfikowany, mo�e to by� dowolna nazwa.
	<br /><br />
	<b>&raquo;</b> <u>URL do kana�u rss:</u>
	Adres do wskazanego kana�u rss
	<br /><br />
	<b>&raquo;</b> <u>�cie�ka dost�pu do obrazka:</u>
	Je�li kana� posiada zdefiniowany obrazek, wpisz 'default', aby go u�y�. Je�li chcesz u�y� w�asnego obrazka, wpisz pe�n� �cie�k� dost�pu do niego. Pozostaw puste aby nie u�ywa� �adnych obrazk�w.
	<br /><br />
	<b>&raquo;</b> <u>Opis:</u>
	Zredaguj kr�tki opis o kanale, lub wpisz 'default' i u�yj zdefiniowanego opisu przez nadawc� kana�u (je�li taki posiada).
	<br /><br />
	<b>&raquo;</b> <u>Okres aktualizacji w sekundach:</u>
	Ilo�� sekunda jaka musi up�yn�� zanim kana� zostanie zaktualizowany, na przyk�ad, 1800: 30 minut, 3600: godzina.
	<br /><br />
	<b>&raquo;</b> <u>Aktywacja:</u>
	tutaj mo�esz wskaza� sekcj�, w kt�rej b�d� wy�wietlane utworzone przez Ciebie kana�y wiadomo�ci, aby zobaczy� wiadomo�ci w postaci menu musisz je najpierw aktywowa� na stronie <a href='".e_ADMIN."menus.php'>dost�pnych menu</a>.
	<br /><br />Pod adresami <a href='http://www.syndic8.com/' rel='external'>syndic8.com</a> oraz <a href='http://feedfinder.feedster.com/index.php' rel='external'>feedster.com</a> mo�esz znale�� wiele aktualnych kana��w posortowanych wed�ug kategorii. Je�li poszukujesz polskiego kana�u wiadomo�ci przejrzyj stron� <a href='http://rss.mrok.org/' rel='external'>rss.mrok.org</a>.");
define("NFLAN_43", "Pomoc");
define("NFLAN_44", "aby wy�wietli� kliknij");

define("NFLAN_45", "Ilo�� pozycji wy�wietlanych w menu");
define("NFLAN_46", "Ilo�� pozycji wy�wietlanych na stronie g��wnej");
define("NFLAN_47", "0 lub puste pole oznacza wszystkie");

define("NFLAN_48", "Nie mog� zapisa� danych w bazie danych.");
define("NFLAN_49", "Nie mog� wyodr�bni� danych RSS - u�yta jest niestandardowa sk�adnia");


?>
