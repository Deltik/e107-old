<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.6 $
|     $Date: 2007/10/08 19:03:24 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/list_new/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/list_new/languages/English.php rev. 1.18
+-----------------------------------------------------------------------------+
*/

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Lista nowo�ci"); }

define("LIST_PLUGIN_1", "Lista nowo�ci");
define("LIST_PLUGIN_2", "Plugin Lista nowo�ci pozwoli Ci przegl�da� wykaz ostatnich zmian we wszystkich kategoriach e107. Mo�esz przegl�da� list� ze zmianami od Twojej ostatniej wizyty, albo przejrze� list� og�ln� ostatnich zmian. Opr�cz strony do prezentacji zmian jest r�wnie� dost�pne menu. Ka�da sekcja jest konfigurowalna z poziomu panelu admina.");
define("LIST_PLUGIN_3", "Konfiguracja menu Lista nowo�ci");
define("LIST_PLUGIN_4", "Plugin Lista nowo�ci zosta� zainstalowany i jest gotowy do u�ywania.");
define("LIST_PLUGIN_5", "Lista nowo�ci");
define("LIST_PLUGIN_6", "Wskazany plugin nie jest zainstalowany.");

define("LIST_ADMIN_1", "Ostatnie zmiany");
define("LIST_ADMIN_2", "Aktualizuj ustawienia");
define("LIST_ADMIN_3", "Ustawienia zosta�y zaktualizowane");
define("LIST_ADMIN_4", "Sekcja");
define("LIST_ADMIN_5", "Menu");
define("LIST_ADMIN_6", "Strona");
define("LIST_ADMIN_7", "W��czone");
define("LIST_ADMIN_8", "Wy��czone");
define("LIST_ADMIN_9", "Otwarte");
define("LIST_ADMIN_10", "Zamkni�te");
define("LIST_ADMIN_11", "Aktualizacja");
define("LIST_ADMIN_12", "Wybierz");
define("LIST_ADMIN_13", "Witaj na stronie ostatnich zmian w serwisie  ".SITENAME."! Na tej stronie s� pokazane najbardziej popularne sekcje serwisu wraz z lista ostatnio dokonanych tam zmian.");
define("LIST_ADMIN_14", "Ostatnio dodane");
define("LIST_ADMIN_15", "Nowo�ci w serwisie");
define("LIST_ADMIN_16", "Witaj na stronie nowo�ci serwisu ".SITENAME."! Na tej stronie s� pokazane najbardziej popularne sekcje serwisu wraz z lista zmian dokonanych w tych sekcjach od Twojej ostatniej wizyty.");

define("LIST_ADMIN_SECT_1", "Sekcje");
define("LIST_ADMIN_SECT_2", "Wybierz sekcje do pokazania");
define("LIST_ADMIN_SECT_3", "");

define("LIST_ADMIN_SECT_4", "Styl wy�wietlania");
define("LIST_ADMIN_SECT_5", "Wybierz w celu ustawienia sekcji domy�lnie otwartych");
define("LIST_ADMIN_SECT_6", "");

define("LIST_ADMIN_SECT_7", "Autor");
define("LIST_ADMIN_SECT_8", "Wybierz, je�li powinien by� wy�wietlany autor");
define("LIST_ADMIN_SECT_9", "");

define("LIST_ADMIN_SECT_10", "Kategorie");
define("LIST_ADMIN_SECT_11", "Wybierz, je�li powinny by� wy�wietlane kategorie");
define("LIST_ADMIN_SECT_12", "");

define("LIST_ADMIN_SECT_13", "Data");
define("LIST_ADMIN_SECT_14", "Wybierz, je�li powinna by� wy�wietlana data");
define("LIST_ADMIN_SECT_15", "");

define("LIST_ADMIN_SECT_16", "Ilo�� pozycji");
define("LIST_ADMIN_SECT_17", "Wybierz w celu ustawienia ilo�ci pozycji wy�wietlanych w ka�dej sekcji");
define("LIST_ADMIN_SECT_18", "");

define("LIST_ADMIN_SECT_19", "Kolejno�� pozycji");
define("LIST_ADMIN_SECT_20", "Wybierz w celu ustawienia kolejno�ci, w jakiej powinny byc wy�wietlane sekcje");
define("LIST_ADMIN_SECT_21", "");

define("LIST_ADMIN_SECT_22", "Ikona");
define("LIST_ADMIN_SECT_23", "Wybierz ikon� dla ka�dej sekcji");
define("LIST_ADMIN_SECT_24", "");

define("LIST_ADMIN_SECT_25", "Nag��wek");
define("LIST_ADMIN_SECT_26", "Zdefiniuj nag��wek dla ka�dej sekcji");
define("LIST_ADMIN_SECT_27", "");

define("LIST_ADMIN_OPT_1", "Og�lne");
define("LIST_ADMIN_OPT_2", "Strona ostatnich zmian");
define("LIST_ADMIN_OPT_3", "Menu ostatnich zmian");
define("LIST_ADMIN_OPT_4", "Strona nowo�ci");
define("LIST_ADMIN_OPT_5", "Menu nowo�ci");
define("LIST_ADMIN_OPT_6", "Opcje");

define("LIST_ADMIN_MENU_2", "Ikona : domy�lna");
define("LIST_ADMIN_MENU_3", "U�yj domy�lnego znaku (bullet) u�ywanego tematu, je�li nie ma dost�pnych ikon, lub je�li jest wy��czone u�ywanie ikon w <i>Ikona : Ustawienie</i>");
define("LIST_ADMIN_MENU_4", "");

define("LIST_ADMIN_LAN_2", "Nag��wek");
define("LIST_ADMIN_LAN_3", "Zdefiniuj nag��wek");
define("LIST_ADMIN_LAN_4", "");

define("LIST_ADMIN_LAN_5", "Ikona : Ustawianie");
define("LIST_ADMIN_LAN_6", "Ustaw ikon� dla ka�dej sekcji");
define("LIST_ADMIN_LAN_7", "");

define("LIST_ADMIN_LAN_8", "Ilo�� znak�w");
define("LIST_ADMIN_LAN_9", "Wybierz ilo�� znak�w nag��wka, kt�re b�d� wy�wietlane");
define("LIST_ADMIN_LAN_10", "Pozostaw puste, aby wy�wietli� pe�ny nag��wek");

define("LIST_ADMIN_LAN_11", "Przyrostek");
define("LIST_ADMIN_LAN_12", "Wybierz przyrostek, je�li nag��wek jest wi�kszy ni� podana ilo�� znak�w");
define("LIST_ADMIN_LAN_13", "Pozostaw puste, aby nie wy�wietla� przyrostka");

define("LIST_ADMIN_LAN_14", "Data");
define("LIST_ADMIN_LAN_15", "Wybierz format daty");
define("LIST_ADMIN_LAN_16", "W celu uzyskania bardziej szczeg�owych informacji o formatowaniu daty udaj si� na <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>php.net i przeczytaj opis funkcji <i>strftime</i></a>");

define("LIST_ADMIN_LAN_17", "Format dzisiejszej daty");
define("LIST_ADMIN_LAN_18", "Wybierz format daty, dla pozycji, kt�rych data dodania jest dzisiejsza");
define("LIST_ADMIN_LAN_19", "W celu uzyskania bardziej szczeg�owych informacji o formatowaniu daty udaj si� na <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>php.net i przeczytaj opis funkcji <i>strftime</i></a>");

define("LIST_ADMIN_LAN_20", "Kolumny");
define("LIST_ADMIN_LAN_21", "Wybierz ilo�� kolumn");
define("LIST_ADMIN_LAN_22", "Zdefiniuj ilo�� kolumn, jak� chcia�by� u�ywa�. Liczba, kt�r� podasz, spowoduje podzia� strony na tak� ilo�� r�wnych kolumn");

define("LIST_ADMIN_LAN_23", "Tekst powitalny");
define("LIST_ADMIN_LAN_24", "Zdefiniuj powitalny tekst, kt�ry zostanie umieszczony na g�rze strony");
define("LIST_ADMIN_LAN_25", "");

define("LIST_ADMIN_LAN_26", "Poka� puste");
define("LIST_ADMIN_LAN_27", "Zdefiniuj, je�li chcesz wy�wietli� wiadomo��, gdy dana sekcja nie zawiera �adnych wynik�w");
define("LIST_ADMIN_LAN_28", "");

define("LIST_ADMIN_LAN_29", "Ikona : domy�lna");
define("LIST_ADMIN_LAN_30", "U�yj domy�lnego znaku (bullet) u�ywanego tematu, je�li nie ma dost�pnych ikon, lub je�li jest wy��czone u�ywanie ikon w <i>Ikona : Ustawienie</i>");
define("LIST_ADMIN_LAN_31", "");

define("LIST_ADMIN_LAN_32", "Okres czasu wstecz : dni");
define("LIST_ADMIN_LAN_33", "Maksymalna ilo�� dni, jak� u�ytkownicy mog� przegl�da� wstecz");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "dni");

define("LIST_ADMIN_LAN_36", "Okres czasu wstecz");
define("LIST_ADMIN_LAN_37", "Wy�wietli� pole wyboru z ilo�ci� dni do przegl�dania wstecz?");
define("LIST_ADMIN_LAN_38", "");

define("LIST_ADMIN_LAN_39", "Otw�rz, je�li istnieje rekord");
define("LIST_ADMIN_LAN_40", "Czy sekcje, kt�re zawieraj� rekordy, powinny by� otwarte domy�lnie?"); // should sections that contain records be opened by default?
define("LIST_ADMIN_LAN_41", "");

define("LIST_MENU_1", "Ostatnio dodane");
define("LIST_MENU_2", "autor");
define("LIST_MENU_3", "dnia");
define("LIST_MENU_4", "w dziale");
define("LIST_MENU_5", "dni");
define("LIST_MENU_6", "Podgl�d zawarto�ci dla ilu dni?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");

define("LIST_NEWS_1", "Aktualno�ci");
define("LIST_NEWS_2", "Brak nowych pozycji");

define("LIST_COMMENT_1", "Komentarze");
define("LIST_COMMENT_2", "Brak komentarzy");
define("LIST_COMMENT_3", "Aktualno�ci");
define("LIST_COMMENT_4", "FAQ");
define("LIST_COMMENT_5", "Ankieta");
define("LIST_COMMENT_6", "Dokumentacja");
define("LIST_COMMENT_7", "Bugtracker");
define("LIST_COMMENT_8", "Publikacje");
define("LIST_COMMENT_9", "Download");
define("LIST_COMMENT_10", "Pomys�y");

define("LIST_DOWNLOAD_1", "Download");
define("LIST_DOWNLOAD_2", "Brak nowych plik�w");

define("LIST_MEMBER_1", "U�ytkownicy");
define("LIST_MEMBER_2", "Brak nowych u�ytkownik�w");

define("LIST_CONTENT_1", "Publikacje");
define("LIST_CONTENT_2", "brak publikacji w");
define("LIST_CONTENT_3", "brak poprawnych kategorii publikacji");

define("LIST_CHATBOX_1", "Czat");
define("LIST_CHATBOX_2", "Brak nowych post�w na czacie");

define("LIST_CALENDAR_1", "Kalendarz");
define("LIST_CALENDAR_2", "Brak nowych wydarze�");

define("LIST_LINKS_1", "Linki");
define("LIST_LINKS_2", "Brak link�w");

define("LIST_FORUM_1", "Forum");
define("LIST_FORUM_2", "Nie ma nowych post�w na forum");
define("LIST_FORUM_3", "przegl�da:");
define("LIST_FORUM_4", "odpowiedzi:");
define("LIST_FORUM_5", "ostatni post:");
define("LIST_FORUM_6", "dnia:");

?>