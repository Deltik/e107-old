<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2007/10/08 19:03:11 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum_post.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_forum_post.php rev rev. 1.12
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Forum");

define("LAN_01", "Forum");
define("LAN_02", "Odpowied� na: ");
define("LAN_03", "Zamieszczanie wypowiedzi");
define("LAN_1", "Normalny");
define("LAN_2", "Przyklejony");
define("LAN_3", "Og�oszenie");
define("LAN_4", "Ankieta do wypowiedzi");
define("LAN_5", "Pytanie:");
define("LAN_6", "Kolejna opcja");
define("LAN_7", "Opcja g�osowania:");
define("LAN_8", "Pozw�l g�osowa� wszystkim");
define("LAN_9", "Pozw�l g�osowa� tylko zarejestrowanym");
define("LAN_10", "Zaloguj");//login
define("LAN_11", "Zapami�taj mnie");
define("LAN_16", "Login: ");
define("LAN_17", "Has�o: ");
define("LAN_20", "B��d");
define("LAN_27", "Wymagane pola pozosta�y puste");
define("LAN_28", "Niczego nie napisa�e�...");
define("LAN_29", "Edytowany");
define("LAN_45", "Na tym forum mog� si� wypowiada� tylko zarejestrowani u�ytkownicy, prosze klikn��");
define("LAN_60", "Rozpoczynanie nowego tematu");
define("LAN_61", "Twoje imi�: ");
define("LAN_62", "Temat: ");
define("LAN_63", "Tre�� posta: ");
define("LAN_64", "Wy�lij");
define("LAN_73", "Tre�� posta: ");
define("LAN_74", "Wy�lij");
define("LAN_77", "Aktualizacja");
define("LAN_78", "Aktualizacja");
define("LAN_94", "Napisany przez");
define("LAN_95", "Brak uprawnie�");
define("LAN_96", "Nie posiadasz uprawnie� do redagowania wskazanej wypowiedzi.");
define("LAN_100", "Temat przewodni"); //Thread Topic
define("LAN_101", "Ostanie ");
define("LAN_102", " posty");
define("LAN_103", "Przejrzyj w ca�o�ci temat. (Otworzy si� osobne okno.)");
define("LAN_133", "Dzi�kujemy");
define("LAN_174", "Rejestracja");
define("LAN_175", "Login");
define("LAN_212", "Zapomnia�e� has�a?");
define("LAN_310", "Nie mog� zamie�ci� tego posta, jako �e u�ytkownik o danej nazwie ju� istnieje - je�li jest to Twoja nazwa zaloguj si� w celu wys�ania posta.");
define("LAN_311", "Anonim");
define("LAN_322", "Wys�any: ");
define("LAN_323", "Podgl�d");
define("LAN_324", "Twoja wypowied� zosta�a pomy�lnie wys�ana.");
define("LAN_325", "Kliknij tutaj, aby zobaczy� swoj� wypowied�");
define("LAN_326", "Kliknij tutaj, aby powr�ci� do forum");
define("LAN_327", "Przegl�daj");//review
define("LAN_380", "Je�li chcesz by� powiadomiony emailem o odpowiedziach zamieszczonych w tym temacie, zaznacz pole obok ");
define("LAN_381", "Udzielone odpowiedzi na forum ");
define("LAN_382", "Wysy�anie wykonane: "); //Post made
define("LAN_383", "Prosz� klikn�� na nast�puj�cy link, aby zobaczy� ca�y temat...");
define("LAN_384", "Udzielanie odpowiedzi na "); //Forum reply at
define("LAN_385", "Tre��: ");
define("LAN_386", "Je�li nie chcesz dodawa� ankiety do swojego tematu, pozostaw pola niewype�nione ");
define("LAN_387", "Przejd�");
define("LAN_388", "Powr�t do g�ry");
define("LAN_389", "Taki post ju� istnieje, przekierowywanie...");
define("LAN_390", "Za��czanie pliku lub obrazka");
define("LAN_391", "Opcje wyboru");
define("LAN_392", "Za��cznik");
define("LAN_393", "<b>UWAGA!</b><br />Dozwolone typy plik�w:");
define("LAN_394", "Jakiekolwiek inne za�adowane pliki zostan� natychmiast usuni�te.");
define("LAN_395", "Maksymalny rozmiar pliku");
define("LAN_396", " bajt�w");
define("LAN_397", "Ten temat jest zamkni�ty.");
define("LAN_398", "Forum tylko do odczytu");
define("LAN_399", "Nie posiadasz uprawnie� do zamieszczania post�w na tym forum.");
define("LAN_400", "Rodzaj tematu");
define("LAN_401", "Przejd� do");
	
define("LAN_402", "ankieta");
define("LAN_403", "og�oszenie");
define("LAN_404", "przyklejony");
define("LAN_405", "Forum");
define("LAN_406", "Odp:");

//v.616
define("LAN_407", "Przekierowanie");
define("LAN_408", "Je�li twoja przegl�darka nie wspiera automatycznych przekierowa�, prosz� klikn��");
define("LAN_409", "TUTAJ");
define("LAN_410", ", aby zostac przekierowanym.");
define("LAN_411", "tutaj");
define("LAN_412", ", aby przej�� do strony rejestracji. W wypadku posiadania ju� konta <a href='".e_BASE."login.php'>zaloguj si�</a>.");
	
define("LAN_413", "Twoja ankieta zosta�a pomy�lnie wys�any.");
define("LAN_414", "Kliknij tutaj, aby obejrze� swoj� ankiet�");
define("LAN_415", "Tw�j post zosta� pomy�lnie wys�any.");

define("LAN_416", "Za��cz plik");
define("LAN_417", "Dodaj kolejny za��cznik");

define("POLL_506", "Zezwala� na wielokrotny wyb�r?");
define("POLL_507", "Tak");
define("POLL_508", "Nie");

define("LAN_FORUM_1", "Nadsy�anie plik�w jest niemo�liwe: katalog ".e_FILE."public jest niezapisywalny");
define("LAN_FORUM_2", "Taki post ju� istnieje");

?>
