<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Felhaszn�l�i hozz�sz�l�sok/�zenetek");

define("UP_LAN_0", "�sszes f�rum �zenete ");
define("UP_LAN_1", "�sszes hozz�sz�l�sa ");
define("UP_LAN_2", "T�ma");
define("UP_LAN_3", "Megn�zem");
define("UP_LAN_4", "M�solatok");
define("UP_LAN_5", "Utols� �zenete");
define("UP_LAN_6", "T�m�k");
define("UP_LAN_7", "Nincs hozz�sz�l�s");
define("UP_LAN_8", "Nincs f�rum�zenet");
define("UP_LAN_9", " - ");
define("UP_LAN_10", "V�lasz");
define("UP_LAN_11", "�rta: ");
define("UP_LAN_12", "Keres�s");
define("UP_LAN_13", "hozz�sz�l�s");
define("UP_LAN_14", "f�rum�zenet");
define("UP_LAN_15", "V�lasz");
define("UP_LAN_16", "IP c�m");
?>
