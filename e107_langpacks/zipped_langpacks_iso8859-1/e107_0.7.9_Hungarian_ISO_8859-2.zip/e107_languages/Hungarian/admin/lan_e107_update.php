<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_UPDATE_2", "M�veletek");
define("LAN_UPDATE_3", "Nem sz�ks�ges");

define("LAN_UPDATE_5", "Van(nak) friss�t�s(ek)");
define("LAN_UPDATE_7", "Futtat�s");
define("LAN_UPDATE_8", "Friss�t�s:");
define("LAN_UPDATE_9", " -> ");
define("LAN_UPDATE_10", "El�rhet� friss�t�sek");
define("LAN_UPDATE_11", ".617 -> .7 friss�t�s folytat�sa");
define("LAN_UPDATE_12", "Az egyik t�bl�d duplik�lt bejegyz�seket tartalmaz.");
?>
