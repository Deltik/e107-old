<?php
$caption = "Linkek s�g�";
$text = "�rd be ide az oldalad �sszes f�men� linkj�t. A t�bbi linkhez haszn�ld a Links page plugint. 
<br />";
$ns -> tablerender($caption, $text);
?>
