<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/banlist.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/02/11 10:33:58 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Kitilt�sok s�g�";
$text = "Kitilthatsz felhaszn�l�kat az oldalr�l itt.<br />
Add meg a teljes IP c�met, vagy haszn�lj *-ot egy IP c�m tartom�ny kitilt�s�hoz.<br /><br />
<b>Kitilt�s IP c�mmel:</b><br />
Az 123.123.123.123 IP c�m megad�s�val letiltod az err�l a c�mr�l �rkez� felhaszn�l�kat.<br />
Az 123.123.123.* IP c�m megad�s�val letiltod az err�l az IP c�m tartom�nyr�l �rkez� felhaszn�l�kat.<br /><br />
<b>Kitilt�s email c�mmel</b><br />
A foo@bar.com email c�m megad�sa letiltja ennek az email c�mnek a haszn�lat�t, �gy e c�mmel senki nem fog tudni regisztr�lni.<br />
Az *@bar.com c�m megad�sa a bar.com domain-t tiltja le, �gy e domainr�l semmilyen email c�mmel senki nem fog tudni regisztr�lni.<br /><br />
<b>Kitilt�s felhaszn�l�n�vvel</b><br />
Ezt v�grehajthatod a felhaszn�l�k adminisztr�ci�s oldalr�l.";
$ns -> tablerender($caption, $text);
?>
