<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/menus2.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text .= "Itt be�ll�thatod, hogy hol �s milyen sorrendben jelenjenek meg a men�k. Haszn�ld a nyilakat a men�k le- ill. fel-mozgat�s�hoz, am�g el�red a megfelel� poz�ci�t.<br />
A k�perny� k�zep�n elhelyezked� linkek inakt�vak, aktiv�l�sukhoz ki kell v�lasztani �s megnyomni a megfelel� men�ter�let gombj�t.
";

$ns -> tablerender("Men� - S�g�", $text);
?>
