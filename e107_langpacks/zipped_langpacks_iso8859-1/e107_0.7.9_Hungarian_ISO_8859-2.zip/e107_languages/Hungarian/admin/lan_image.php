<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("IMALAN_1", "K�pek enged�lyez�se");
define("IMALAN_2", "K�pek megjelen�t�se, a teljes oldalra �rv�nyes lesz (hozz�sz�l�sok, chatbox stb)");
define("IMALAN_3", "�tm�retez�si elj�r�s");
define("IMALAN_4", "A k�pek �tm�retez�s�hez haszn�lt elj�r�s: a GD1/GD2/ImageMagick");
define("IMALAN_5", "Az ImageMagick el�r�si �tja (ha ezt v�lasztottad �s elt�r az alap�rtelmezett telep�t�st�l)");
define("IMALAN_6", "Az ImageMagick Convert teljes el�r�si �tja");
define("IMALAN_7", "K�p be�ll�t�sok");
define("IMALAN_8", "Be�ll�t�sok ment�se");
define("IMALAN_9", "K�pbe�ll�t�sok friss�tve");
define("IMALAN_10", "K�pet bek�ldhet�k csoportja");
define("IMALAN_11", "Kik k�ldhetnek be k�pet");
define("IMALAN_12", "Letiltott k�p kezel�se");
define("IMALAN_13", "Mi a teend� a k�pekkel, ha a k�p tiltott");
define("IMALAN_14", "K�p URL-j�nek megjelen�t�sea");
define("IMALAN_15", "Nem mutat semmit");
define("IMALAN_16", "Felt�lt�tt avatarok mutat�sa");
define("IMALAN_17", "Felt�lt�tt avatarok");
define("IMALAN_18", "Felt�lt�tt k�pek");

define("IMALAN_21", "Haszn�lja");
define("IMALAN_22", "Nem haszn�lt k�p");
define("IMALAN_23", "Avatar");
define("IMALAN_24", "Fot�");
define("IMALAN_25", "�sszes nem haszn�lt k�p t�rl�se");
define("IMALAN_26", "k�p t�r�lve");

define("IMALAN_28", "t�r�lve");
define("IMALAN_29", "Nincsenek k�pek");
define("IMALAN_30", "Mindenki (publikus)");
define("IMALAN_31", "Csak Vend�gek");
define("IMALAN_32", "Csak tagok");
define("IMALAN_33", "Csak adminok");
define("IMALAN_34", "Enable Sleight");
define("IMALAN_35", "Fixes transparent PNG-24's with alpha transparency in IE 5 / 6 (Applies Sitewide)");

define("IMALAN_36", "Avatar m�ret �s hozz�f�r�s j�v�hagy�sa");
define("IMALAN_37", "Avatar J�v�hagy�s");
define("IMALAN_38", "Megengedett maxim�lis sz�less�g");
define("IMALAN_39", "Megengedett maxim�lis magass�g");
define("IMALAN_40", "T�l sz�les");
define("IMALAN_41", "T�l magas");
define("IMALAN_42", "Nem tal�lom");
define("IMALAN_43", "Felt�lt�tt avatar t�rl�se");
define("IMALAN_44", "K�ls� hivatkoz�s t�rl�se");
define("IMALAN_45", "Nem tal�lom");
define("IMALAN_46", "T�l nagy");
define("IMALAN_47", "�sszes felt�lt�tt avatar");
define("IMALAN_48", "�sszes k�ls� avatar");
define("IMALAN_49", "Avatar-val rendelkez� felhaszn�l�k");
define("IMALAN_50", "�sszes");
define("IMALAN_51", "Avatar, kinek ");

define("IMALAN_52", "Az ImageMagick �tvonala nem megfelel�");
define("IMALAN_53", "Az ImageMagick �tvonala megfelel�, de a file konvert�l�sa tal�n nem �rv�nyes");
define("IMALAN_54", "GD verzi� telep�tve:");
define('IMALAN_55', 'Nincs telep�tve');

?>
