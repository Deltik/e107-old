<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UDALAN_1", "Hiba - k�ldd el �jra");
define("UDALAN_2", "Be�ll�t�sok friss�tve");
define("UDALAN_3", "Be�ll�t�sok friss�tve:");
define("UDALAN_4", "N�v");
define("UDALAN_5", "Jelsz�");
define("UDALAN_6", "Jelsz� meger�s�t�se");
define("UDALAN_7", "Jelsz� m�dos�t�sa");
define("UDALAN_8", "Jelsz� m�dos�t�sa erre:");

?>