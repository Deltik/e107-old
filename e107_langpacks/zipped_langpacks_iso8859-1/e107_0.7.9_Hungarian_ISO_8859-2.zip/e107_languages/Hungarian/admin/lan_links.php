<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LCLAN_1", "Be�ll�t�sok elmentve");
define("LCLAN_2", "Link hozz�adva");
define("LCLAN_3", "Link friss�tve");
//define("LCLAN_4", "Link t�r�lve");
define("LCLAN_6", "Elrendez�s friss�tve");
define("LCLAN_8", "Linkek");
define("LCLAN_12", "Megjelen�t�s m�dja");
define("LCLAN_15", "Link neve");
define("LCLAN_16", "URL");
define("LCLAN_17", "Le�r�s");
define("LCLAN_18", "Gomb / ikon");
define("LCLAN_19", "Megnyit�s m�dja");
define("LCLAN_20", "Azonos ablakban");
define("LCLAN_23", "�j ablakban");
define("LCLAN_24", "600x400 ablak");
define("LCLAN_25", "El�rhet�s�g");
define("LCLAN_26", "Hozz�f�r�s megad�sa");
define("LCLAN_27", "Link friss�t�se");
define("LCLAN_28", "�j link");
define("LCLAN_29", "Linkek");
define("LCLAN_30", "Fel");
define("LCLAN_31", "Le");
define("LCLAN_39", "K�pek megjelen�t�se");
define("LCLAN_53", "Link");
define("LCLAN_54", "t�r�lve");
define("LCLAN_58", "Biztosan t�r�lni akarod ezt a linket?");
define("LCLAN_61", "Nincsenek linkek");
define("LCLAN_62", "Linkek f�oldala");
define("LCLAN_63", "�j link l�trehoz�sa");
define("LCLAN_68", "Be�ll�t�sok");
define("LCLAN_78", "Le�r�s mutat�sa s�g�k�nt");
define("LCLAN_79", "A le�r�s akkor fog megjelenni, amikor az eg�r a link f�l� �r");
define("LCLAN_80", "Kinyithat� almen�k aktiv�l�sa");
define("LCLAN_81", "Az almen�k a sz�l�j�kre kattint�s ut�n lesznek l�that�ak. (A link sz�l� letiltva)");
define("LCLAN_83", "Almen� gener�tor");
define("LCLAN_88", "F�men� linkek opci�i");
define("LCLAN_89", "K�p");

define("LCLAN_91", "�thelyez�s");
define("LCLAN_95", "Csoport");

define("LCLAN_96", "Megjelen�t�s a t�m�ban, mint");


define("LINKLAN_1", "Megnyit�s 800x600 -as ablakban");
define("LINKLAN_2", "Sz�l�");
define("LINKLAN_3", "Nincs sz�l� (Norm�l link)");
define("LINKLAN_4", "Allink Gener�tor");
define("LINKLAN_5", "Allinkek l�trehoz�sa");
define("LINKLAN_6", "Mib�l hozzon l�tre allinket:");
define("LINKLAN_7", "Melyik link al� k�sz�tsen allinket?");
define("LINKLAN_8", "H�r kateg�ri�k");
define("LINKLAN_9", "Let�lt�s kateg�ri�k");
define("LINKLAN_10", "Al-link l�trehoz�sa");
?>
