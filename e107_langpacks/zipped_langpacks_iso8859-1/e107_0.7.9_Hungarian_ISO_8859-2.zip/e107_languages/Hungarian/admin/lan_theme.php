<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("TPVLAN_1", "Ez a(z) <b>'".PREVIEWTHEMENAME."'</b> theme el�n�zete. Ez nem az oldalad theme-je, csak azt mutatja meg, hogy n�z ki az oldalad e theme-vel.<br />A theme haszn�lat�hoz l�pj <a href='".e_ADMIN."theme.php'>a theme kezel�be</a> �s v�laszd a 'Be�ll�t�s az oldal t�m�jak�nt' opci�t.<br /><a href='".e_ADMIN."theme.php'>Tov�bbi t�m�k el�n�zete</a>");
define("TPVLAN_2", "Theme el�n�zet");
define("TPVLAN_3", "Az oldal t�m�ja:");
define("TPVLAN_4", "K�sz�tette");
define("TPVLAN_5", "Weboldal");
define("TPVLAN_6", "Kiad�s d�tuma");
define("TPVLAN_7", "Inform�ci�");
define("TPVLAN_8", "Opci�k");
define("TPVLAN_9", "Theme el�n�zete");
define("TPVLAN_10", "Be�ll�t�s az oldal t�m�jak�nt");
define("TPVLAN_11", "Verzi�");
define("TPVLAN_12", "Nincs el�n�zet");

define("TPVLAN_13", "Theme felt�lt�se (.zip vagy .tar.gz form�tum)");
define("TPVLAN_14", "Theme felt�lt�se");
define("TPVLAN_15", "Az automatikus felt�lt�s nem lehets�ges, mert a(z) ".e_THEME." k�nyvt�r nem �rhat� - adj r� �r�si jogot (CHMOD 777).");
define("TPVLAN_16", "Admin �zenet");
define("TPVLAN_17", "A file nem t�nik t�nylegesen .zip vagy .tar arch�vnak.");
define("TPVLAN_18", "Hiba: a file kicsomagol�sa nem siker�lt");
define("TPVLAN_19", "A theme felt�ltve �s kicsomagolva, g�rgesd lefel� az oldalt, ha l�tni akarod a theme-t a  list�ban.");
define("TPVLAN_20", "Az automatikus felt�lt�s �s kicsomagol�s nem lehets�ges, mert a themes k�nyvt�r nem �rhat� - adj r� �r�si jogot (CHMOD 777).");

define("TPVLAN_21", "Jelenleg ez a be�ll�tott theme");

define("TPVLAN_22", "a theme t�bb st�luslapot tartalmaz");
define("TPVLAN_23", "alap�rtelmezett st�luslap");
define("TPVLAN_24", "nincs inform�ci�");
define("TPVLAN_25", "A haszn�land� st�luslap kiv�laszt�s�hoz l�pj a <a href='".e_ADMIN."prefs.php'>be�ll�t�sok</a> r�szbe, �s kattints a 'Theme'-re.");

define("TPVLAN_26", "Theme Manager");
define("TPVLAN_27", "V�laszd ki a haszn�land� st�luslapot");
define("TPVLAN_28", "be");
define("TPVLAN_29", "ki");
define("TPVLAN_30", "Theme k�pek el�t�lt�se:");

define("TPVLAN_31", "Jelenleg ez az admin theme");
define("TPVLAN_32", "Be�ll�t�s admin theme-k�nt");

define("TPVLAN_33", "Jelenlegi oldal theme");
define("TPVLAN_34", "Jelenlegi admin theme");
define("TPVLAN_35", "Be�ll�t�sok ment�se");
define("TPVLAN_36", "Admin �zenet");
define("TPVLAN_37", "Theme be�ll�t�sok elmentve");
define("TPVLAN_38", "Theme felt�lt�se");
define("TPVLAN_39", "Haszn�lhat� theme-k");
define("TPVLAN_40", "Be�ll�t�s admin theme-k�nt");

define("TPVLAN_41", "V�laszd ki a haszn�land� admin elrendez�si st�lust");
define("TPVLAN_42", "Admin be�ll�t�sok ment�se");
define("TPVLAN_43", "Admin be�ll�t�sok elmentve");


define("TPVLAN_46", "PCLZIP kicsomagol�si hiba:");
define("TPVLAN_47", "PCLTAR kicsomagol�si hiba: ");
define("TPVLAN_48", "k�d:");

?>
