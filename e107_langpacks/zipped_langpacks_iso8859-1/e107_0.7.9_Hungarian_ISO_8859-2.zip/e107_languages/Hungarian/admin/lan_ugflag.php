<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UGFLAN_1", "Karbantart�si be�ll�t�sok friss�tve");
define("UGFLAN_2", "Bekapcsol�s");
define("UGFLAN_3", "Be�ll�t�sok ment�se");
define("UGFLAN_4", "Karbantart�si be�ll�t�sok");

define("UGFLAN_5", "Karbantart�si �zenet");
define("UGFLAN_6", "Hagyd �resen az alap�rtelmezett �zenet megjelen�t�s�hez");

?>