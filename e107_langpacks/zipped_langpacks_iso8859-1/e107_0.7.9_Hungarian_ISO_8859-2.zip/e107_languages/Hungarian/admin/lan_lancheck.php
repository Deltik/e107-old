<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_CHECK_1", "V�lassz nyelvet az ellen�rz�shez");
define("LAN_CHECK_2", "Ellen�rz�s ind�t�sa");
define("LAN_CHECK_3", "Ellen�rz�s");
define("LAN_CHECK_4", "Hi�nyz� file!");
define("LAN_CHECK_5", "Hi�nyz� kifejez�s!");

define("LAN_CHECK_7", "kifejez�s");

define("LAN_CHECK_8", "A f�jl hi�nyzik...");
define("LAN_CHECK_9", " hi�nyz� f�jl...");
define("LAN_CHECK_10", "Kritikus hiba: ");
define("LAN_CHECK_11", "Nincs hi�nyz� f�jl!");
define("LAN_CHECK_12", "Egy f�jl hib�s...");
define("LAN_CHECK_13", " f�jl hib�s...");
define("LAN_CHECK_14", "Minden file j�!");

define("LAN_CHECK_15", "Illeg�lis karakterek a '&lt;?php' el�tt");
define("LAN_CHECK_16", "Eredeti File");
define("LAN_CHECK_17", "Egy �r�si probl�ma keletkezett a file ment�se sor�n.");
define("LAN_CHECK_18", "Szabv�ny form�ban a nyelvi file nem enged�lyezett ehhez a plugin-hoz/theme-hez.");
define("LAN_CHECK_19", "Nem-UTF-8 karakterek!");
?>
