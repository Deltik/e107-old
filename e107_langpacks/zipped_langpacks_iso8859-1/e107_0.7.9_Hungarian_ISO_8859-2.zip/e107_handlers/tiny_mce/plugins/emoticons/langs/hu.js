// UK lang variables

tinyMCELang['lang_insert_emoticons_title'] = 'Emotikon beilleszt�se';
tinyMCELang['lang_emoticons_desc'] = 'Emotikonok';
