<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.4 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("Integ_01", "Sikeres ment�s");
define("Integ_02", "Sikertelen ment�s");
define("Integ_03", "Hi�nyz� f�jlok:");
define("Integ_04", "CRC-hib�k:");
define("Integ_05", "File nem nyithat� meg...");
define("Integ_06", "File-integrit�s ellen�rz�se");
define("Integ_07", "Nincsenek el�rhet� f�jlok");
define("Integ_08", "Integrit�s ellen�rz�se");
define("Integ_09", "sfv-file l�trehoz�sa");
define("Integ_10", "A kijel�lt k�nyvt�r <u>nem</u> lesz mentve a crc-f�jlba.");
define("Integ_11", "F�jln�v:");
define("Integ_12", "sfv file l�trehoz�sa");
define("Integ_13", "Integrit�s ellen�rz�s");
define("Integ_14", "SFV file nem hozhat� l�tre, mivel az ".e_PLUGIN."integrity_check/<b>{output}</b> nem �rhat�. �ll�tsd ezen mappa jogosults�g�t 777-re (CHMOD 777 mappa)!");
define("Integ_15", "�sszes file ellen�rizve �s minden rendben!");
define("Integ_16", "core-crc-file nem el�rhet�");
define("Integ_17", "plugin-crc-files nem el�rhet�");
define("Integ_18", "Plugin-CRC-File l�trehoz�sa");
define("Integ_19", "Core-Checksum-F�jlok");
define("Integ_20", "Plugin-Checksum-F�jlok");
define("Integ_21", "V�laszd ki a plugint, melyhez crc f�jlt akarsz csin�lni.");
define("Integ_22", "gzip haszn�lata");
define("Integ_23", "Csak theme-k ellen�rz�se");
define("Integ_24", "Admin kezd�lap");
define("Integ_25", "Adminter�let elhagy�sa");
define("Integ_26", "Oldal bet�lt�se norm�l fejl�ccel");
define("Integ_27", "HASZN�LD A FILE ELLEN�RZ�T A CORE FILE-K ELLEN�RZ�S�HEZ");

//define("Integ_29", "<br /><br /><b>*<u>CRC-HIBA:</u></b><br />CRC hib�k vannak, melynek k�t oka lehet:<br />-Megv�ltoztatt�l valamit a file tartalm�ban, �gy az m�r nem egyezik az eredetivel.<br />-A file megs�r�lt. �jra fel kell t�ltened!");
// language file should contain NO html.

define("Integ_30", "Az alacsonyabb CPU terhel�s �rdek�ben megcsin�lhatod az ellen�rz�st 1-10 l�p�sben.");
define("Integ_31", "L�p�sek: ");
define("Integ_32", "Van egy <b>log_crc.txt</b> nevezet� file a crc-mapp�dban. T�r�ld le! (Vagy friss�ts)");
define("Integ_33", "Van egy <b>log_miss.txt</b> nevezet� file a crc-mapp�dban. T�r�ld le! (Vagy friss�ts)");
define("Integ_34", "A crc-mapp�d nem �rhat�!");
define("Integ_35", "Az al�bbi ok(ok) miatt csak <b>egy</b> l�p�st jel�lhetsz ki:");
define("Integ_36", "Kattints ide, ha nem akarsz 5 m�sodpercet v�rni a k�vetkez� l�p�sig:");
define("Integ_37", "Kattints");
define("Integ_38", "M�g tov�bbi <u><i>{counts}</i></u> sor van h�tra...");
define("Integ_39", "T�r�ld ezt a f�jlt:<br />".e_PLUGIN."integrity_check/<u><i>do_core_file.php</i></u>!<br />Idej�tm�lt �s sohasem k�sz�lt publikus felhaszn�l�sra...");

?>
