<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.5 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define('CLOCK_MENU_L1', 'Be�ll�t�s elmentve');
define('CLOCK_MENU_L2', 'C�m/fejl�c');
define('CLOCK_MENU_L3', 'Be�ll�t�s friss�t�se');
define('CLOCK_MENU_L4', 'Be�ll�t�s');
define('CLOCK_MENU_L5', 'h�tf�');
define('CLOCK_MENU_L6', 'kedd');
define('CLOCK_MENU_L7', 'szerda');
define('CLOCK_MENU_L8', 'cs�t�rt�k');
define('CLOCK_MENU_L9', 'p�ntek');
define('CLOCK_MENU_L10', 'szombat');
define('CLOCK_MENU_L11', 'vas�rnap');
define('CLOCK_MENU_L12', 'janu�r');
define('CLOCK_MENU_L13', 'febru�r');
define('CLOCK_MENU_L14', 'm�rcius');
define('CLOCK_MENU_L15', '�prilis');
define('CLOCK_MENU_L16', 'm�jus');
define('CLOCK_MENU_L17', 'j�nius');
define('CLOCK_MENU_L18', 'j�lius');
define('CLOCK_MENU_L19', 'augusztus');
define('CLOCK_MENU_L20', 'szeptember');
define('CLOCK_MENU_L21', 'okt�ber');
define('CLOCK_MENU_L22', 'november');
define('CLOCK_MENU_L23', 'december');
define('CLOCK_MENU_L24', '');
?>