<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.1 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LWLAN_1", "�res mez�(k).");
define("LWLAN_2", "Link sz� elmentve.");
define("LWLAN_3", "Link sz� friss�tve.");
define("LWLAN_4", "Nincs link sz� defini�lva.");
define("LWLAN_5", "Sz�");
define("LWLAN_6", "Link");
define("LWLAN_7", "Akt�v?");
define("LWLAN_8", "Opci�k");
define("LWLAN_9", "igen");
define("LWLAN_10", "nem");
define("LWLAN_11", "Jelenlegi linkszavak");
define("LWLAN_12", "Igen");
define("LWLAN_13", "Nem");
define("LWLAN_14", "Link sz� ment�se");
define("LWLAN_15", "Link sz� friss�t�se");
define("LWLAN_16", "M�dos�t�s");
define("LWLAN_17", "T�rl�s");
define("LWLAN_18", "Biztosan t�r�lni akarod ezt a link sz�t?");
define("LWLAN_19", "Link sz� t�r�lve.");
define("LWLAN_20", "Ez a link sz� nem tal�lhat�.");
define("LWLAN_21","Sz� az automatikus linkhez");
define("LWLAN_22","Aktiv�l�s?");
define("LWLAN_23", "Link szavak Adminisztr�ci�");
define("LWLAN_24", "Szavak karbantart�sa");
define("LWLAN_25", "Be�ll�t�sok");
define("LWLAN_26", "Ter�letek, melyeken enged�lyezettek a link szavak");
define("LWLAN_27", "A megjelen� sz�veg 'context' r�sze");
define("LWLAN_28", "Oldalak, melyeken letiltva a link szavak");
define("LWLAN_29", "N�h�ny forma, mint men� l�that�s�g szab�lyoz�s. Egy beilleszt�s/sor. Az el��r�s szerinti relat�v vagy teljes URL. A v�g�n '!' jel, a link v�g�nek pontos meghat�roz�s�hoz");
define("LWLAN_30", "Be�ll�t�sok ment�se");
define("LWLAN_31", "Link szavak hozz�ad�sa/szerkeszt�se");
define("LWLAN_32", "Link szavak be�ll�t�sa");
define("LWLAN_33", 'C�m ter�letek');
define("LWLAN_34", '�sszegz�sek');
define("LWLAN_35", 'Sz�vegt�rzs');
define("LWLAN_36", 'Le�r�sok (linkek ...stb.)');
define("LWLAN_37", 'Z�rad�k ter�letek');
define("LWLAN_38", 'Kattinthat� linkek');
define("LWLAN_39", 'Folyamat n�lk�li sz�vegek');
define("LWLAN_40", 'Felhaszn�l� �ltal-megadott c�mek, fejl�cek (Pl.: f�rum)');
define("LWLAN_41", 'Felhaszn�l� �ltal-megadott t�rzs sz�veg (Pl.: f�rum)');


define("LWLANINS_1", "Link szavak");
define("LWLANINS_2", "A plugin linket rendel a megadott sz�hoz");
define("LWLANINS_3", "Link szavak be�ll�t�sa");
define("LWLANINS_4", "A be�ll�t�shoz kattints a linkre a plugin manager-ben.");

?>
