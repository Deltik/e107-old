<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_350", "T�ma be�ll�t�sa");
define("LAN_351", "T�ma kiv�laszt�sa");

?>