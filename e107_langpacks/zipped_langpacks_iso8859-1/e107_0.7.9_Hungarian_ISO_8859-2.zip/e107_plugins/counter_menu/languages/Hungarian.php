<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.5 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("COUNTER_L1", "Admin l�togat�sok nincsennek sz�ml�lva.");
define("COUNTER_L2", "Ma");
define("COUNTER_L3", "�sszesen");
define("COUNTER_L4", "Legt�bb");
define("COUNTER_L5", "Egyedi");
define("COUNTER_L6", "Oldal ...");
define("COUNTER_L7", "Sz�ml�l�");
define("COUNTER_L8", "Admin �zenet: <b>Statisztika napl�z�sa letiltva.</b><br />Az aktiv�l�shoz telep�teni kell a Statisztika napl�z�sa plugin-t a <a href='".e_ADMIN."plugin.php'>plugin manager</a>-ben, majd aktiv�lni <a href='".e_PLUGIN."log/admin_config.php'>a be�ll�t�sok fel�leten</a>.");

?>