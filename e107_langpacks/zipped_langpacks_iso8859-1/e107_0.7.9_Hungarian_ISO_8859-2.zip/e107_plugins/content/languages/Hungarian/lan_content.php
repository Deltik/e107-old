<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.66 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CONTENT_EMAILPRINT_LAN_1", "ez a tartalom innen van");

define("POPUP_LAN_1", "Katt ide a nagyobb k�phez");

define("CONTENT_NOTIFY_LAN_1", "Tartalom esem�nyek");
define("CONTENT_NOTIFY_LAN_2", "A tartalmat bek�ldte");
define("CONTENT_NOTIFY_LAN_3", "Tartalom bek�ldve");

define("CONTENT_TYPE_LAN_0", "Kateg�ri�k");
define("CONTENT_TYPE_LAN_1", "Szerz�k");
define("CONTENT_TYPE_LAN_2", "Arch�vum");
define("CONTENT_TYPE_LAN_3", "Legjobb �rt�kel�s");
define("CONTENT_TYPE_LAN_4", "Legt�bb pontsz�m");
define("CONTENT_TYPE_LAN_5", "Leg�jabb");

define("CONTENT_ICON_LAN_0", "M�dos�t�s");
define("CONTENT_ICON_LAN_1", "T�rl�s");
define("CONTENT_ICON_LAN_2", "Opci�k");
define("CONTENT_ICON_LAN_3", "Felhaszn�l� adatai");
define("CONTENT_ICON_LAN_4", "Mell�klet let�lt�se");
define("CONTENT_ICON_LAN_5", "�j");
define("CONTENT_ICON_LAN_6", "Bek�ld�s");
define("CONTENT_ICON_LAN_7", "Szerz�k list�ja");
define("CONTENT_ICON_LAN_8", "Figyelmeztet�s");
define("CONTENT_ICON_LAN_9", "Ok");
define("CONTENT_ICON_LAN_10", "Hiba");
define("CONTENT_ICON_LAN_11", "Tartalmak sorrendje a kateg�ri�ban");
define("CONTENT_ICON_LAN_12", "Kateg�ri�k sorrendje");
define("CONTENT_ICON_LAN_13", "Szem�lyes admin");
define("CONTENT_ICON_LAN_14", "Saj�t tartalomkezel�");
define("CONTENT_ICON_LAN_15", "Megtekint�s");

define("CONTENT_ADMIN_DATE_LAN_0", "Janu�r");
define("CONTENT_ADMIN_DATE_LAN_1", "Febru�r");
define("CONTENT_ADMIN_DATE_LAN_2", "M�rcius");
define("CONTENT_ADMIN_DATE_LAN_3", "�prilis");
define("CONTENT_ADMIN_DATE_LAN_4", "M�jus");
define("CONTENT_ADMIN_DATE_LAN_5", "J�nius");
define("CONTENT_ADMIN_DATE_LAN_6", "J�lius");
define("CONTENT_ADMIN_DATE_LAN_7", "Augusztus");
define("CONTENT_ADMIN_DATE_LAN_8", "Szeptember");
define("CONTENT_ADMIN_DATE_LAN_9", "Okt�ber");
define("CONTENT_ADMIN_DATE_LAN_10", "November");
define("CONTENT_ADMIN_DATE_LAN_11", "December");
define("CONTENT_ADMIN_DATE_LAN_12", "nap");
define("CONTENT_ADMIN_DATE_LAN_13", "h�nap");
define("CONTENT_ADMIN_DATE_LAN_14", "�v");
define("CONTENT_ADMIN_DATE_LAN_15", "kezd� d�tum");
define("CONTENT_ADMIN_DATE_LAN_16", "z�r� d�tum");
define("CONTENT_ADMIN_DATE_LAN_17", "Megadhatsz a tartalomhoz egy kezd� d�tumot. Ha j�v�beni d�tumot haszn�lsz, akkor a tartalom att�l a d�tumt�l kezd�d�en lesz l�that�. Ha sz�ks�gtelen kezd� d�tum, akkor hagyd �gy a mez�ket, ahogy vannak.");
define("CONTENT_ADMIN_DATE_LAN_18", "Megadhatsz e tartalomhoz egy z�r� d�tumot. A z�r�d�tummal meghat�rozhatod, meddig legyen l�that� a tartalom. Ha sz�ks�gtelen z�r� d�tum, akkor hagyd �gy a mez�ket, ahogy vannak.");

define("CONTENT_PAGETITLE_LAN_0", "Tartalom");
define("CONTENT_PAGETITLE_LAN_1", "F�");
define("CONTENT_PAGETITLE_LAN_2", "Leg�jabb");
define("CONTENT_PAGETITLE_LAN_3", "Kateg�ria");
define("CONTENT_PAGETITLE_LAN_4", "Legjobb �rt�kel�st kaptak");
define("CONTENT_PAGETITLE_LAN_5", "Szerz�");
define("CONTENT_PAGETITLE_LAN_6", "Arch�vum");
define("CONTENT_PAGETITLE_LAN_7", "Mehet");
define("CONTENT_PAGETITLE_LAN_8", "Tartalom bek�ld�se");
define("CONTENT_PAGETITLE_LAN_9", "Szem�lyes tartalomkezel�");
define("CONTENT_PAGETITLE_LAN_10", "Tartalom megtekint�se");
define("CONTENT_PAGETITLE_LAN_11", "Tartalom m�dos�t�sa");
define("CONTENT_PAGETITLE_LAN_12", "Tartalom l�trehoz�sa");
define("CONTENT_PAGETITLE_LAN_13", "Kateg�ri�k");
define("CONTENT_PAGETITLE_LAN_14", "Szerz� lista");
define("CONTENT_PAGETITLE_LAN_15", "Legt�bb pont");

define("CONTENT_SEARCH_LAN_0", "Ezzel a kulcssz�val nem tal�ltam tartalmat.");

define("CONTENT_ORDER_LAN_0", "rendez�s ...");
define("CONTENT_ORDER_LAN_1", "C�m (n�vekv�)");
define("CONTENT_ORDER_LAN_2", "C�m (cs�kken�)");
define("CONTENT_ORDER_LAN_3", "D�tum (n�vekv�)");
define("CONTENT_ORDER_LAN_4", "D�tum (cs�kken�)");
define("CONTENT_ORDER_LAN_5", "Hivatkoz�s (n�vekv�)");
define("CONTENT_ORDER_LAN_6", "Hivatkoz�s (cs�kken�)");
define("CONTENT_ORDER_LAN_7", "Sz�l� (n�vekv�)");
define("CONTENT_ORDER_LAN_8", "Sz�l� (cs�kken�)");
define("CONTENT_ORDER_LAN_9", "Sorsz�m (n�vekv�)");
define("CONTENT_ORDER_LAN_10", "Sorsz�m (cs�kken�)");
define("CONTENT_ORDER_LAN_11", "Szerz� (n�vekv�)");
define("CONTENT_ORDER_LAN_12", "Szerz� (cs�kken�)");

define("CONTENT_LAN_0", "Tartalom");
define("CONTENT_LAN_1", "Leg�jabb lista");
define("CONTENT_LAN_2", "Kateg�ria lista");
define("CONTENT_LAN_3", "Kateg�ria");
define("CONTENT_LAN_4", "Szerz� lista");
define("CONTENT_LAN_5", "Szerz�");
define("CONTENT_LAN_6", "�sszes kateg�ria");
define("CONTENT_LAN_7", "�sszes szerz�");
define("CONTENT_LAN_8", "Legjobb �rt�kel�s");
define("CONTENT_LAN_9", "kateg�ria:");
define("CONTENT_LAN_10", "-");
define("CONTENT_LAN_11", "szerz�:");
define("CONTENT_LAN_12", "Legt�bb pont");
define("CONTENT_LAN_13", "Lista");
define("CONTENT_LAN_14", "-- Kateg�ri�k --");
define("CONTENT_LAN_15", "m�g nincs szerz�");
define("CONTENT_LAN_16", "[tov�bb]");
define("CONTENT_LAN_17", "");
define("CONTENT_LAN_18", "kulcssz� alapj�n");
define("CONTENT_LAN_19", "Keres�s");
define("CONTENT_LAN_20", "Keres�s eredm�nye");
define("CONTENT_LAN_21", "m�g nincs tartalom t�pus.");
define("CONTENT_LAN_22", "Tartalom t�pusok");
define("CONTENT_LAN_23", "Leg�jabb tartalmak list�ja");
define("CONTENT_LAN_24", "breadcrumb");
define("CONTENT_LAN_25", "Tartalom kateg�ri�k");
define("CONTENT_LAN_26", "Tartalom kateg�ria");
define("CONTENT_LAN_27", "Alkateg�ri�k");
define("CONTENT_LAN_28", "Sz�l� alkateg�ri�k");
define("CONTENT_LAN_29", "ismeretlen");
define("CONTENT_LAN_30", "Tartalom");
define("CONTENT_LAN_31", "Tartalom");
define("CONTENT_LAN_32", "Szerz�k list�ja");
define("CONTENT_LAN_33", "Ugr�s a k�vetkez� oldalra");
define("CONTENT_LAN_34", "Tartalom");
define("CONTENT_LAN_35", "Hozz�sz�l�s");
define("CONTENT_LAN_36", "Hozz�sz�l�s moder�l�sa");
define("CONTENT_LAN_37", "m�g nincs �rt�kelve");
define("CONTENT_LAN_38", "Legjobb �rt�kel�st kapott tartalmak");
define("CONTENT_LAN_39", "Szerz�k list�ja");
define("CONTENT_LAN_40", "Szerz� adatai");
define("CONTENT_LAN_41", "Mell�klet");
define("CONTENT_LAN_42", "file");
define("CONTENT_LAN_43", "file-k");
define("CONTENT_LAN_44", "Megtekint�s:");
define("CONTENT_LAN_45", "Szerz�nek odait�lt pontok:");
define("CONTENT_LAN_46", "Cikk index");
define("CONTENT_LAN_47", "Szerz�");
define("CONTENT_LAN_48", "Tartalom");
define("CONTENT_LAN_49", "Leg�jabb tartalom");
define("CONTENT_LAN_50", "D�tum");
define("CONTENT_LAN_51", "T�pus lista");
define("CONTENT_LAN_52", "Nincs �rv�nyes szerz� tal�lat");
define("CONTENT_LAN_53", "r�sz");
define("CONTENT_LAN_54", "r�sz");
define("CONTENT_LAN_55", "leg�jabb r�sz");
define("CONTENT_LAN_56", "�ttekint�s");
define("CONTENT_LAN_57", "Hozz�sz�l�s:");
define("CONTENT_LAN_58", "Kezd�lap");
define("CONTENT_LAN_59", "Tartalom");
define("CONTENT_LAN_60", "Leg�jabb");
define("CONTENT_LAN_61", "Leg�jabb tartalom megtekint�se");
define("CONTENT_LAN_62", "�sszes kateg�ria megtekint�se");
define("CONTENT_LAN_63", "�sszes szerz� megtekint�se");
define("CONTENT_LAN_64", "Legjobb �rt�kel�st kapott tartalom megtekint�se");
define("CONTENT_LAN_65", "Tartalom bek�ld�se");
define("CONTENT_LAN_66", "Katt ide a tartalom bek�ld�s�hez, v�lassz kateg�ri�t a bek�ld�s oldalon.");
define("CONTENT_LAN_67", "Szem�lyes Tartalomkezel�");
define("CONTENT_LAN_68", "Katt ide a szem�lyes tartalom karbantart�s�hoz.");
define("CONTENT_LAN_69", "Email");
define("CONTENT_LAN_70", "Nyomtat�s");
define("CONTENT_LAN_71", "tartalom");
define("CONTENT_LAN_72", "kateg�ria");
define("CONTENT_LAN_73", "jelenleg nincs tartalom");
define("CONTENT_LAN_74", "");
define("CONTENT_LAN_75", "Tartalom bek�ld�se");
define("CONTENT_LAN_76", "pdf file l�trehoz�sa");
define("CONTENT_LAN_77", "Keres�s");
define("CONTENT_LAN_78", "C�mn�lk�li oldal");
define("CONTENT_LAN_79", "oldal");
define("CONTENT_LAN_80", "Leg�jabb : ");
define("CONTENT_LAN_81", "kateg�ri�k");
define("CONTENT_LAN_82", "Jelenleg nincs tartalom a(az)");
define("CONTENT_LAN_83", "arch�v r�szben");
define("CONTENT_LAN_84", "Arch�vum");
define("CONTENT_LAN_85", "Szerz�k list�ja");
define("CONTENT_LAN_86", "legt�bb pontot el�rt r�sz megtekint�se");
define("CONTENT_LAN_87", "Legt�bb pontot el�rt Tartalom");
define("CONTENT_LAN_88", "m�g nincs tartalom pontozva");
define("CONTENT_LAN_89", "oldal kiv�laszt�sa");
define("CONTENT_LAN_90", "el�z� oldal");
define("CONTENT_LAN_91", "k�vetkez� oldal");
define("CONTENT_LAN_92", " - aktu�lis");

define("CONTENT_MENU_LAN_0", "Tartalom Men� :");
define("CONTENT_MENU_LAN_1", "Jelenleg nincs tartalom");
define("CONTENT_MENU_LAN_2", "Leg�jabb tartalmak");
define("CONTENT_MENU_LAN_3", "Kateg�ri�k");
define("CONTENT_MENU_LAN_4", "Tartalom linkek");
define("CONTENT_MENU_LAN_5", "");
define("CONTENT_MENU_LAN_6", "");
define("CONTENT_MENU_LAN_7", "");
define("CONTENT_MENU_LAN_8", "");
define("CONTENT_MENU_LAN_9", "");
define("CONTENT_MENU_LAN_10", "");
define("CONTENT_MENU_LAN_11", "");
define("CONTENT_MENU_LAN_12", "");
define("CONTENT_MENU_LAN_13", "");
define("CONTENT_MENU_LAN_14", "");
define("CONTENT_MENU_LAN_15", "");
define("CONTENT_MENU_LAN_16", "");
define("CONTENT_MENU_LAN_17", "");
define("CONTENT_MENU_LAN_18", "");
define("CONTENT_MENU_LAN_19", "");
define("CONTENT_MENU_LAN_20", "");

?>




