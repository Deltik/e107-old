<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.13 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "�jdons�g lista"); }

define("LIST_PLUGIN_1", "�jdons�g lista");
define("LIST_PLUGIN_2", "Ez a plugin lehet�s�get ad, hogy az �sszes kateg�ria �jdons�gait megjelen�tse. Megtekintheted a list�t az utols� l�togat�sod �ta a d�tummal egy�tt vagy �ltal�nosan a leg�jabb hozz�adott list�t. Ezenk�v�l egy men�t is megjelen�thetsz ugyanezekkel. Minden szekci�t be�ll�thatsz az admin fel�leten.");
define("LIST_PLUGIN_3", "F�men� be�ll�t�sa");
define("LIST_PLUGIN_4", "A List_new plugin haszn�latra k�sz.");
define("LIST_PLUGIN_5", "�jdons�glista");
define("LIST_PLUGIN_6", "Ez a plugin nincs telep�tve.");

define("LIST_ADMIN_1", "�jdons�gok");
define("LIST_ADMIN_2", "Be�ll�t�sok friss�t�se");
define("LIST_ADMIN_3", "Be�ll�t�sok friss�tve");
define("LIST_ADMIN_4", "Ter�let");
define("LIST_ADMIN_5", "Men�");
define("LIST_ADMIN_6", "Oldal");
define("LIST_ADMIN_7", "Enged�lyezve");
define("LIST_ADMIN_8", "Letiltva");
define("LIST_ADMIN_9", "Nyitva");
define("LIST_ADMIN_10", "Z�rva");
define("LIST_ADMIN_11", "Friss�t�s");
define("LIST_ADMIN_12", "V�lassz");
define("LIST_ADMIN_13", "K�sz�ntelek a ".SITENAME." �jdons�gai oldal�n! Ezen az oldalom l�thatod az oldalra felt�lt�tt, �ltal�nos r�szekhez tartoz� leg�jabb h�reket, hozz�sz�l�sokat, let�lt�seket, chatbox �zeneteket ...stb. !");
define("LIST_ADMIN_14", "�jdons�gok");
define("LIST_ADMIN_15", "az utols� l�togat�sod �ta");
define("LIST_ADMIN_16", "K�sz�ntelek a ".SITENAME." �jdons�gai oldal�n! Ezen az oldalom l�thatod az oldalra felt�lt�tt, �ltal�nos r�szekhez tartoz� leg�jabb h�reket, hozz�sz�l�sokat, let�lt�seket, chatbox �zeneteket ...stb. !");

define("LIST_ADMIN_SECT_1", "Ter�let");
define("LIST_ADMIN_SECT_2", "v�laszd ki, melyik ter�let jelenjen meg");
define("LIST_ADMIN_SECT_3", "");

define("LIST_ADMIN_SECT_4", "Megjelen�t�si st�lus");
define("LIST_ADMIN_SECT_5", "V�laszd ki, melyik ter�let legyen nyitva alap�rtelmez�sben");
define("LIST_ADMIN_SECT_6", "");

define("LIST_ADMIN_SECT_7", "Szerz�");
define("LIST_ADMIN_SECT_8", "V�laszd ki, hol jelenjen meg a szerz�");
define("LIST_ADMIN_SECT_9", "");

define("LIST_ADMIN_SECT_10", "Kateg�ria");
define("LIST_ADMIN_SECT_11", "V�laszd ki, hol jelenjen meg a kateg�ria");
define("LIST_ADMIN_SECT_12", "");

define("LIST_ADMIN_SECT_13", "D�tum");
define("LIST_ADMIN_SECT_14", "V�laszd ki, hol jelenjen meg a d�tum");
define("LIST_ADMIN_SECT_15", "");

define("LIST_ADMIN_SECT_16", "�jdons�gok mennyis�ge");
define("LIST_ADMIN_SECT_17", "V�laszd ki, h�ny �jdons�g jelenjen meg az adott ter�leten");
define("LIST_ADMIN_SECT_18", "");

define("LIST_ADMIN_SECT_19", "Sorrend");
define("LIST_ADMIN_SECT_20", "V�laszd ki a ter�letek sorrendj�t");
define("LIST_ADMIN_SECT_21", "");

define("LIST_ADMIN_SECT_22", "Ikon");
define("LIST_ADMIN_SECT_23", "V�lassz ikont a ter�letekhez");
define("LIST_ADMIN_SECT_24", "");

define("LIST_ADMIN_SECT_25", "C�m, fejl�c");
define("LIST_ADMIN_SECT_26", "Hat�rozd meg a ter�letek c�m�t");
define("LIST_ADMIN_SECT_27", "");

define("LIST_ADMIN_OPT_1", "�ltal�nos");
define("LIST_ADMIN_OPT_2", "�jdons�g oldal");
define("LIST_ADMIN_OPT_3", "�jdons�g men�");
define("LIST_ADMIN_OPT_4", "�j oldal");
define("LIST_ADMIN_OPT_5", "�j men�");
define("LIST_ADMIN_OPT_6", "Be�ll�t�sok");

define("LIST_ADMIN_MENU_2", "ikon : Alap�rtelmezett");
define("LIST_ADMIN_MENU_3", "alap�rtelmezett theme bullet haszn�lata, ha nincs ikon kiv�lasztva vagy ikon: haszn�lat letiltva");
define("LIST_ADMIN_MENU_4", "");

define("LIST_ADMIN_LAN_2", "C�m, fejl�c");
define("LIST_ADMIN_LAN_3", "adj meg egy c�met");
define("LIST_ADMIN_LAN_4", "");

define("LIST_ADMIN_LAN_5", "ikon : Felhaszn�lt");
define("LIST_ADMIN_LAN_6", "egy ikon haszn�lata b�rmelyik r�szb�l");
define("LIST_ADMIN_LAN_7", "");

define("LIST_ADMIN_LAN_8", "Karakterek");
define("LIST_ADMIN_LAN_9", "hat�rozd meg a c�mben megjelen�tend� karakterek sz�m�t");
define("LIST_ADMIN_LAN_10", "hagyd �resen a teljes c�m megjelen�t�s�hez");

define("LIST_ADMIN_LAN_11", "postfix");
define("LIST_ADMIN_LAN_12", "v�lassz egy postfix-et, ha a c�m hosszabb a megadott karaktersz�mn�l");
define("LIST_ADMIN_LAN_13", "hagyd �resen, ha ne legyen postfix");

define("LIST_ADMIN_LAN_14", "D�tum");
define("LIST_ADMIN_LAN_15", "v�lassz d�tum st�lust");
define("LIST_ADMIN_LAN_16", "A d�tumform�tumokr�l tov�bbi inform�ci�kat kaphatsz a <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>php.net strftime funkci� oldal�n</a>");

define("LIST_ADMIN_LAN_17", "Mai id�");
define("LIST_ADMIN_LAN_18", "v�lassz egy id� st�lust a mai naphoz");
define("LIST_ADMIN_LAN_19", "A d�tumform�tumokr�l tov�bbi inform�ci�kat kaphatsz a <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>php.net strftime funkci� oldal�n</a>");

define("LIST_ADMIN_LAN_20", "Oszlopok");
define("LIST_ADMIN_LAN_21", "v�lassz egy oszlop mennyis�get");
define("LIST_ADMIN_LAN_22", "Hat�rozd meg a haszn�lni k�v�nt oszlopok sz�m�t. Az oldalon az oszlopok egyenl� ar�nyban fognak elk�l�n�lni");

define("LIST_ADMIN_LAN_23", "�dv�zl� �zenet");
define("LIST_ADMIN_LAN_24", "egy �dv�zl� �zenet meghat�roz�sa, amely megjelenik az oldal tetej�n");
define("LIST_ADMIN_LAN_25", "");

define("LIST_ADMIN_LAN_26", "�res megjelen�t�se");
define("LIST_ADMIN_LAN_27", "hat�rozd meg, megjelenjen-e, ha nincs �jdons�g a ter�leten ");
define("LIST_ADMIN_LAN_28", "");

define("LIST_ADMIN_LAN_29", "ikon : Alap�rtelmezett");
define("LIST_ADMIN_LAN_30", "alap�rtelmezett theme bullet haszn�lata, ha nincs ikon kiv�lasztva vagy ikon: haszn�lat letiltva");
define("LIST_ADMIN_LAN_31", "");

define("LIST_ADMIN_LAN_32", "Eltelt id�: napok");
define("LIST_ADMIN_LAN_33", "a visszatekint�s maxim�lis napja");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "nap");

define("LIST_ADMIN_LAN_36", "Eltelt id�");
define("LIST_ADMIN_LAN_37", "Megjelen�tsen egy kiv�laszt�dobozt az el�z� napok sz�m�val?");
define("LIST_ADMIN_LAN_38", "");

define("LIST_ADMIN_LAN_39", "megnyit�s, ha a rekord l�tezik");
define("LIST_ADMIN_LAN_40", "a rekordok tartalma megny�ljon alap�rtelmez�sben?");
define("LIST_ADMIN_LAN_41", "");

define("LIST_MENU_1", "Legfrissebb");
define("LIST_MENU_2", "�rta");
define("LIST_MENU_3", " - ");
define("LIST_MENU_4", "r�sz");
define("LIST_MENU_5", "nap");
define("LIST_MENU_6", "h�ny napig tekinthet� meg a tartalom?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");

define("LIST_NEWS_1", "�jdons�gok");
define("LIST_NEWS_2", "Nincs �jdons�g");

define("LIST_COMMENT_1", "Hozz�sz�l�s");
define("LIST_COMMENT_2", "Nincs hozz�sz�l�s");
define("LIST_COMMENT_3", "H�rek");
define("LIST_COMMENT_4", "GYIK");
define("LIST_COMMENT_5", "Szavaz�s");
define("LIST_COMMENT_6", "Dokumentum");
define("LIST_COMMENT_7", "bugtrack");
define("LIST_COMMENT_8", "Tartalom");
define("LIST_COMMENT_9", "Let�lt�s");
define("LIST_COMMENT_10", "�tletek");

define("LIST_DOWNLOAD_1", "Let�lt�s");
define("LIST_DOWNLOAD_2", "Nincs let�lt�s");

define("LIST_MEMBER_1", "Tagok");
define("LIST_MEMBER_2", "Nincs Tag");

define("LIST_CONTENT_1", "Tartalom");
define("LIST_CONTENT_2", "Nincs tartalom");
define("LIST_CONTENT_3", "nincs tartalom kateg�ria");

define("LIST_CHATBOX_1", "Chatbox");
define("LIST_CHATBOX_2", "Nincs chatbox �zenet");

define("LIST_CALENDAR_1", "Napt�r");
define("LIST_CALENDAR_2", "Nincs esem�ny");

define("LIST_LINKS_1", "Linkek");
define("LIST_LINKS_2", "Nincs link");

define("LIST_FORUM_1", "F�rum");
define("LIST_FORUM_2", "Nincs f�rum�zenet");
define("LIST_FORUM_3", "megtekint�s:");
define("LIST_FORUM_4", "v�lasz:");
define("LIST_FORUM_5", "utols� �zenet:");
define("LIST_FORUM_6", " - ");


?>
