<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF l�trehoz�s t�mogat�s");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "A plugin haszn�latra k�sz.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF be�ll�t�sok");
define("PDF_LAN_3", "Enged�lyezve");
define("PDF_LAN_4", "Letiltva");
define("PDF_LAN_5", "Oldal marg� balra");
define("PDF_LAN_6", "Oldal marg� jobbra");
define("PDF_LAN_7", "Oldal marg� fel�l");
define("PDF_LAN_8", "Bet�t�pus");
define("PDF_LAN_9", "Alap�rtelmezett bet� m�ret");
define("PDF_LAN_10", "Oldaln�v bet�m�rete");
define("PDF_LAN_11", "Oldal URL bet�m�rete");
define("PDF_LAN_12", "Oldalsz�moz�s bet�m�rete");
define("PDF_LAN_13", "Megjelen�tse a logo-t a pdf-ben?");
define("PDF_LAN_14", "Megjelen�tse az oldal nev�t a pdf-ben?");
define("PDF_LAN_15", "Megjelen�tse a k�sz�t� oldal�nak url-j�t a pdf-ben?");
define("PDF_LAN_16", "Megjelen�tse az oldalsz�mot a pdf-ben?");
define("PDF_LAN_17", "Friss�t�s");
define("PDF_LAN_18", "PDF be�ll�t�sok sikeresen friss�tve");
define("PDF_LAN_19", "Oldal");
define("PDF_LAN_20", "hiba jelent�se");

?>
