<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.3 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LOGIN_MENU_L1", "Felhaszn�l�n�v: ");
define("LOGIN_MENU_L2", "Jelsz�: ");
define("LOGIN_MENU_L3", "Regisztr�ci�");
define("LOGIN_MENU_L4", "Elfelejtett jelsz�?");
define("LOGIN_MENU_L5", "�dv�zlet");
define("LOGIN_MENU_L6", "Adatok megjegyz�se");
define("LOGIN_MENU_L7", "Egyedi azonos�t� nem felismerhet� (val�sz�n�leg hib�s cookie).<br /><a href=\"".e_BASE."index.php?logout\">Kattints ide</a> a cookie megsemmis�t�s�hez.");
define("LOGIN_MENU_L8", "Kijelentkez�s");
define("LOGIN_MENU_L9", "Bejelentkez�si hiba");
define("LOGIN_MENU_L10", "Karbantart�s �zemm�d bekapcsolva - A norm�l felhaszn�l�k csak a sitedown.php -t �rhetik el. Kikapcsolhat� az admin r�szlegben");
define("LOGIN_MENU_L11", "Admin");
define("LOGIN_MENU_L12", "Be�ll�t�sok");
define("LOGIN_MENU_L13", "Profil");
define("LOGIN_MENU_L14", "�j h�r");
define("LOGIN_MENU_L15", "�j h�r");
define("LOGIN_MENU_L16", "�j chatbox �zenet");
define("LOGIN_MENU_L17", "�j chatbox �zenet");
define("LOGIN_MENU_L18", "�j hozz�sz�l�s");
define("LOGIN_MENU_L19", "�j hozz�sz�l�s");
define("LOGIN_MENU_L20", "�j f�rum �zenet");
define("LOGIN_MENU_L21", "�j f�rum �zenet");
define("LOGIN_MENU_L22", "�j tag");
define("LOGIN_MENU_L23", "�j tag");
define("LOGIN_MENU_L24", "Kattints ide a list�hoz");
define("LOGIN_MENU_L25", "Utols� l�togat�sod �ta");
define("LOGIN_MENU_L26", "nincs");
define("LOGIN_MENU_L27", "�s");
define("LOGIN_MENU_L28", "Bel�p�s");

define("LOGIN_MENU_L29", "�j cikk");
define("LOGIN_MENU_L30", "�j cikk");

// New config options
define('LOGIN_MENU_L31', '�j h�rek sz�m�nak mutat�sa');
define('LOGIN_MENU_L32', '�j cikkek sz�m�nak mutat�sa');
define('LOGIN_MENU_L33', '�j chatbox �zenetek sz�m�nak mutat�sa');
define('LOGIN_MENU_L34', '�j hozz�sz�l�sok sz�m�nak mutat�sa');
define('LOGIN_MENU_L35', '�j f�rum�zenetek sz�m�nak mutat�sa');
define('LOGIN_MENU_L36', '�j tagok sz�m�nak mutat�sa');
define('LOGIN_MENU_L37', 'Be�ll�t�sok friss�t�se');
define('LOGIN_MENU_L38', 'Be�ll�t�sok friss�tve');


define('LOGIN_MENU_L39', 'Admin elhagy�sa');

define("LOGIN_MENU_L40", "Aktiv�l� Email �jrak�ld�se");
define("LOGIN_MENU_L41", "Login Men� Be�ll�t�sok");
?>
