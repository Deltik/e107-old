<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/poll.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/poll.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie mo�esz tworzy� ankiety oraz sondy. Aby utworzy� ankiet� (sond�) wpisz jej tytu� oraz opcje g�osowania, nast�pnie podejrzyj j� i, po zaakceptowaniu wygl�du, wybierz grup�, kt�r� b�dzie mog�a uczestniczy� w g�osowaniu.<br /><br />
Aby zobaczy� ankiet�, przejd� do strony <i>Menu</i> i upewnij si�, �e menu <i>poll_menu</i> jest aktywne.";
$ns -> tablerender("Ankiety", $text);

?>
