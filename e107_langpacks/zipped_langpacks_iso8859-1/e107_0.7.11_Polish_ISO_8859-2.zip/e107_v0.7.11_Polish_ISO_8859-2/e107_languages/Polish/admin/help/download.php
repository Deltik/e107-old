<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:05 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/download.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/download.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Prosz� za�adowa� swoje pliki do nast�puj�cych katalog�w: <br />pliki - ".e_FILE."downloads
<br />obrazki - ".e_FILE."downloadimages
<br />miniaturki obrazk�w - ".e_FILE."downloadthumbs
<br /><br />
Aby doda� plik do pobrania, najpierw utw�rz dzia� g��wny, nast�pnie utw�rz podkategori� do utworzonego dzia�u g��wnego, po wykonaniu przedstawionych czynno�ci b�dziesz m�g� udost�pni� pliki do pobrania.";
$ns -> tablerender("Download", $text);

?>
