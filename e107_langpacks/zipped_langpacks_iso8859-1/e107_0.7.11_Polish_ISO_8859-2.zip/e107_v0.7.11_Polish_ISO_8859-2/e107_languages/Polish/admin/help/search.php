<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/search.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/search.php rev. 1.6
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Je�li Twoja wersja serwera MySQL wspiera ta opcj� mo�esz prze��czy� na metod� sortowania MySQL, poniewa� jest ona szybsza ni� metoda sortowania PHP. Zobacz w preferencjach.<br /><br />
Je�li Twoja strona zawiera j�zyki ideograficzne takie jak chi�ski oraz japo�ski, musisz u�ywa� metody sortowania PHP oraz musisz r�wnie� wy��czy� opcj� <i>Tylko pe�ne s�owa</i>.";
$ns -> tablerender("Wyszukiwanie", $text);

?>
