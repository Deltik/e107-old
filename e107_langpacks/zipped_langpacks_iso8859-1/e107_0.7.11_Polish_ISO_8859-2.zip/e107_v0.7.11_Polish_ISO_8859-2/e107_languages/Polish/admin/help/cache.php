<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/25 12:22:25 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/cache.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/cache.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$caption = "Pami�� podr�czna";
$text = "W��czenie pami�ci podr�cznej znacznie zwi�kszy szybko�� dzia�ania Twojego serwisu oraz zminimalizujesz ilo�� po��cze� do bazy danych SQL.<br /><br /><b>UWAGA! Podczas tworzenia w�asnego tematu graficznego powiniene� wy��czy� cachowanie, poniewa� w przeciwnym wypadku jakiekolwiek wprowadzone zmiany nie b�d� odzwierciedlone.</b>";
$ns -> tablerender($caption, $text);

?>
