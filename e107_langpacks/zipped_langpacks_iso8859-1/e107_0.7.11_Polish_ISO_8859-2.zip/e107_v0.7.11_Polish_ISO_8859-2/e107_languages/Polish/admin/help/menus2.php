<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/menus2.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/menus2.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$caption = "Menu";
$text .= "Na tej stronie mo�esz zarz�dza� gdzie i w jakiej kolejno�ci b�d� wy�wietlane Twoje menu. U�ywaj strza�ek do przenoszenia menu w g�r� i w d� do momentu a� b�dziesz zadowolony z ich rozmieszczenia.<br />Menu w �rodkowej cz�ci ekranu s� nieaktywne, mo�esz je aktywowa� poprzez ich wyb�r i aktywacj� we wskazanym obszarze.";

$ns -> tablerender($caption, $text);

?>
