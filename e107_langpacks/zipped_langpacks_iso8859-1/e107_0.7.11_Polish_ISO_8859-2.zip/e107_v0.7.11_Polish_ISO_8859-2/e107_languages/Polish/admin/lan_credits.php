<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/11/01 00:05:09 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_credits.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_credits.php rev. 1.5
+-----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Podzi�kowania e107");

define("CRELAN_1", "Podzi�kowania");
define("CRELAN_2", "Poni�ej znajduje si� lista wsp�tw�rc�w oprogramowania u�ytego w systemie e107. Zesp� odpowiedzialny za rozw�j e107 pragnie osobi�cie podzi�kowa� developerom, kt�rzy wyrazili zgod� i ch�� na to, aby redystrybuowa� napisany przez nich kod programowy wraz z systemem e107 oraz rozpowszechnia� go zgodnie z licencj� GPL.");
define("CRELAN_3", "wszelkie prawa zastrze�one");
define("CRELAN_4", "Poka� zesp� e107 Dev Team");
define("CRELAN_5", "Poka� list� zapo�yczonych skrypt�w");
define("CRELAN_6", "e107 v0.7 jest rozwijany dla Ciebie przez...");
define("CRELAN_7", "wersja");
define("CRELAN_8", "udzielono zezwolenia");
define("CRELAN_9", "Licencja");

// third party scripts

define("CRELAN_10", "MagpieRSS zapewnia parser RSS dla PHP bazuj�cy na technologii XML.");
define("CRELAN_11", "Biblioteka PclZip oferuje funkcje kompresji i dekompresji archiw�w w formacie ZIP (WinZip, PKZIP).");
define("CRELAN_12", "Biblioteka PclTar daje mo�liwo�� archiwizacji listy plik�w lub katalog�w z wykorzystaniem lub bez wykorzystania algorytm�w kompresji. Archiwa utworzone przez bibliotek� PclTar s� czytane przez wi�kszo�� aplikacji obs�uguj�cych format gzip/tar orz przez aplikacj� Windows WinZip.");
define("CRELAN_13", "TinyMCE stanowi samodzieln� platform� internetow� bazuj�c� na edytorze WYSIWYG opartym o technologie Javascript oraz HTML. TinyMCE jest rozwijany przez Moxiecode Systems AB i rozpowszechniany jako Open Source zgodnie z warunkami licencji LGPL. Podstawow� funkcj� edytora jest konwersja p� tekstowych (textarea) lub innych element�w j�zyka na potrzeby edytora.");
define("CRELAN_14", "Ikony u�yte w e107");
define("CRELAN_15", "W pe�ni funkcjonalna klasa dla PHP s�u��ca do wysy�ania emaili");
define("CRELAN_16", "System menu u�yty w temacie Jayya");
define("CRELAN_17", "Okienkowy kalendarz w postaci widgeta");
define("CRELAN_18", "Wsparcie PDF");
define("CRELAN_19", "Wsparcie PDF dla kodowania UTF-8");

// end third party scripts

// dev team

define("CRELAN_20", ""); // asperon
define("CRELAN_21", "Always a pressure..err..pleasure!"); // CaMer0n
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\""); // jalist
define("CRELAN_23", ""); // lisa
define("CRELAN_24", ""); // McFly
define("CRELAN_25", ""); // que
define("CRELAN_26", ""); // streaky
define("CRELAN_27", "\"Wot? No tea?? 0_0\""); // SweetAs
define("CRELAN_28", ""); // MrPete

// end dev team

?>
