<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_banner.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_banner.php rev. 1.11
+-----------------------------------------------------------------------------+
*/
 
define("BNRLAN_1", "Reklama zosta�a usuni�ta.");
define("BNRLAN_2", "Prosz� potwierdzi� usuni�cie reklamy - raz usuni�ta nie mo�e by� odzyskana");
define("BNRLAN_5", "Potwierd� usuni�cie reklamy");
define("BNRLAN_6", "Usuwanie zosta�o anulowane.");
define("BNRLAN_7", "Aktualne reklamy");
define("BNRLAN_8", "ID reklamy");
define("BNRLAN_9", "Klient");
define("BNRLAN_10", "Klikaj�cych");
define("BNRLAN_11", "% klikni��");
define("BNRLAN_12", "Wy�wietle�");
define("BNRLAN_13", "Pozosta�ych wy�wietle�");
define("BNRLAN_15", "Nie ma jeszcze reklam.");
define("BNRLAN_16", "Bez limitu");
define("BNRLAN_17", "Brak");
define("BNRLAN_21", "Zako�czenie");
define("BNRLAN_22", "Aktualizacja reklamy");
define("BNRLAN_23", "Dodawanie nowej reklamy");
define("BNRLAN_24", "Kampania");
define("BNRLAN_25", "wybierz istniej�c� kampani�");
define("BNRLAN_26", "wpisz now� kampani�");
define("BNRLAN_27", "Klient");
define("BNRLAN_28", "wybierz istniej�cego klienta");
define("BNRLAN_29", "zarejestruj nowego klienta");
define("BNRLAN_30", "Login klienta");
define("BNRLAN_31", "Has�o klienta");
define("BNRLAN_32", "Obraz reklamy");
define("BNRLAN_33", "Odno�nik URL");
define("BNRLAN_34", "Kupionych wy�wietle�");
define("BNRLAN_35", "bez limitu");
define("BNRLAN_36", "Data pocz�tkowa");
define("BNRLAN_37", "Data ko�cowa");
define("BNRLAN_38", "puste = bez limitu");
define("BNRLAN_39", "Widoczno��");
define("BNRLAN_40", "Aktualizuj");
define("BNRLAN_41", "Utw�rz now� reklam�");
define("BNRLAN_42", "System rotacji reklam");
define("BNRLAN_43", "Wybierz obraz reklamy");
define("BNRLAN_45", "Rozpocz�cie");
define("BNRLAN_46", "Kod");
define("BNRLAN_58", "Aktualne reklamy");
define("BNRLAN_59", "Utw�rz now� reklam�");
define("BNRLAN_60", "Kampanie");
define("BNRLAN_61", "Menu reklam");
define("BNRLAN_62", "Opcje reklam");
define("BNRLAN_63", "Reklama zosta�a utworzona");
define("BNRLAN_64", "Reklama zosta�a zaktualizowana");

define("BANNER_MENU_L1", "Reklama");
define("BANNER_MENU_L2", "Konfiguracja menu reklam zosta�a zapisana");

define("BANNER_MENU_L3", "Nag��wek");
define("BANNER_MENU_L5", "Konfiguracja reklam"); 
define("BANNER_MENU_L6", "Wybierz kampanie do pokazania w menu");
define("BANNER_MENU_L7", "Dost�pne kampanie");
define("BANNER_MENU_L8", "Wybrane kampanie");
define("BANNER_MENU_L9", "Usu� zaznaczone");
define("BANNER_MENU_L10", "Metoda wy�wietlania");
define("BANNER_MENU_L12", "Prosta");
define("BANNER_MENU_L13", "Z nag��wkiem menu");
define("BANNER_MENU_L18", "Aktualizuj ustawienia");
define("BANNER_MENU_L19", "Ilo�� reklam do wy�wietlenia:<br />Ta opcja zostanie u�yta tylko w�wczas, gdy zostanie wybrana wielokrotno�� kampanii.");

?>
