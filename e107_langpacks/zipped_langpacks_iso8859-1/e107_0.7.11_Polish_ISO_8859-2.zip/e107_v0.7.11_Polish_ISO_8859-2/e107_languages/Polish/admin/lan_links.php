<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2006/10/14 13:07:12 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_links.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_links.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("LCLAN_1", "Opcje zosta�y zapisane");
define("LCLAN_2", "Link zosta� zapisany w bazie danych.");
define("LCLAN_3", "Link zosta� zaktualizowany.");
// define("LCLAN_4", "Link zosta� usuni�ty.");
define("LCLAN_6", "Kolejno�� zosta�a zaktualizowana.");
define("LCLAN_8", "Aktualne linki");
define("LCLAN_12", "Spos�b wy�wietlania linka");
define("LCLAN_15", "Nazwa");
define("LCLAN_16", "Adres URL");
define("LCLAN_17", "Opis");
define("LCLAN_18", "Przycisk/Ikona linka");
define("LCLAN_19", "Spos�b otwierania strony");
define("LCLAN_20", "Otwieranie w tym samym oknie");
define("LCLAN_23", "Otwieranie w nowym oknie");
define("LCLAN_24", "Otwieranie w mini-oknie 800x600");
define("LCLAN_25", "Grupa");
define("LCLAN_26", "Wyb�r spowoduje, �e link b�dzie widoczny tylko dla u�ytkownik�w ze wskazanej grupy");
define("LCLAN_27", "Aktualizuj link");
define("LCLAN_28", "Dodaj link");
define("LCLAN_29", "Linki");
define("LCLAN_30", "Przesu� w g�r�");
define("LCLAN_31", "Przesu� w d�");
define("LCLAN_39", "Poka� obrazki");
define("LCLAN_53", "Usuni�to link o numerze ID");
define("LCLAN_54", "."); // deleted - zmiana szyku dotyczy: LCLAN_54
define("LCLAN_58", "Czy na pewno usun�� link?");
define("LCLAN_61", "Nie ma jeszcze �adnych link�w");
define("LCLAN_62", "Aktualne linki");
define("LCLAN_63", "Dodaj nowy link");
define("LCLAN_68", "Opcje link�w");
define("LCLAN_78", "Pokazuj opis jako chmurk�");
define("LCLAN_79", "Opis b�dzie wy�wietlany, gdy kursor myszy najedzie na link");
define("LCLAN_80", "Aktywuj rozwijalne podmenu");
define("LCLAN_81", "Podmenu b�dzie wy�wietlane tylko po klikni�ciu na g��wny link. (G��wny link jest nieaktywny)");
define("LCLAN_83", "Generator podmenu");
define("LCLAN_88", "Opcje link�w");
define("LCLAN_89", "Obraz");
// define("LCLAN_90", "Nazwa");
define("LCLAN_91", "Przesu�");
define("LCLAN_95", "Grupa");

define("LCLAN_96", "Wy�wietlaj w swoim temacie jako");


define("LINKLAN_1", "Otwieranie w oknie 800x600");
define("LINKLAN_2", "Link nadrz�dny");
define("LINKLAN_3", "Brak nadrz�dnego linka (normalny link)");
define("LINKLAN_4", "Generator podlink�w");
define("LINKLAN_5", "Generuj podlinki");
define("LINKLAN_6", "Utw�rz podlink u�ywaj�c:");
define("LINKLAN_7", "Dla kt�rego linka utworzy� grup� podlink�w?");
define("LINKLAN_8", "Kategorii aktualno�ci");
define("LINKLAN_9", "Kategorii plik�w do pobrania");
define("LINKLAN_10", "Dodaj podlink");

?>
