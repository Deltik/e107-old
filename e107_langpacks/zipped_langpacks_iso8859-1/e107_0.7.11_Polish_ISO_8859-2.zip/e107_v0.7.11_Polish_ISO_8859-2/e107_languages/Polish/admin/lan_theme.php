<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2007/02/10 17:13:01 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_theme.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_theme.php rev. 1.10
+-----------------------------------------------------------------------------+
*/
 
define("TPVLAN_1", "Ogl�dasz podgl�d tematu <b>'".PREVIEWTHEMENAME."'</b>. Nie jest on ustawiony jako g��wny temat strony, lecz zosta� aktywowany, aby zapewni� podgl�d wygl�du tematu.<br />Aby ustawi� ten temat jako g��wny wygl�d strony, <a href='".e_ADMIN."theme.php'>powr�� do mened�era temat�w</a> i wybierz 'Ustaw jako g��wny temat strony'.<br />Aby zobaczy� wi�cej temat�w prosz� <a href='".e_ADMIN."theme.php'>klikn�� tutaj</a>");
define("TPVLAN_2", "Podgl�d tematu");
define("TPVLAN_3", "G��wny temat strony zosta� ustawiony na");
define("TPVLAN_4", "Autor");
define("TPVLAN_5", "Strona domowa");
define("TPVLAN_6", "Data");
define("TPVLAN_7", "Informacje");
define("TPVLAN_8", "Opcje");
define("TPVLAN_9", "Podejrzyj temat");
define("TPVLAN_10", "Ustaw jako g��wny temat strony");
define("TPVLAN_11", "Wersja");
define("TPVLAN_12", "Brak dost�pnego podgl�du");

define("TPVLAN_13", "Wybierz temat (format .zip lub .tar.gz)");
define("TPVLAN_14", "Za�aduj temat");
define("TPVLAN_15", "Plik nie m�g� by� za�adowany do ".e_THEME." - folder nie ma prawid�owych uprawnie� - prosz� ustawi� CHMOD na warto�� 777 i ponownie za�adowa� plik.");
define("TPVLAN_16", "Wiadomo�� administracyjna");
define("TPVLAN_17", "Plik jest prawdopodobnie uszkodzonym archiwum .zip lub .tar.");
define("TPVLAN_18", "Wyst�pi� b��d, nie mog� wyodr�bni� pliku z archiwum");
define("TPVLAN_19", "Tw�j temat zosta� za�adowany i rozpakowany, prosz� przewin�� stron� w d� i poszuka� tematu na li�cie.");
define("TPVLAN_20", "Automatyczne �adowanie i rozpakowanie tematu jest niemo�liwe, je�li tw�j folder temat�w ma nie nieprawid�owe uprawnienia. Prosz� ustawi� CHMOD g��wnego folderu temat�w na warto�� 777.");

define("TPVLAN_21", "To jest aktualnie wybrany temat strony g��wnej");

define("TPVLAN_22", "Zbi�r zestaw�w styli tematu");
define("TPVLAN_23", "Domy�lny zestaw styli"); //  stylesheet
define("TPVLAN_24", "Brak informacji");
define("TPVLAN_25", "Aby wybra� kt�ry� ze zestaw�w styli prosz� przej�� do <a href='".e_ADMIN."prefs.php'>ustawie�</a> i klikn�� na 'Theme'.");

define("TPVLAN_26", "Mened�er temat�w");
define("TPVLAN_27", "Prosz� wybra� zestaw stylu do u�ycia");
define("TPVLAN_28", "W��czone");
define("TPVLAN_29", "Wy��czone");
define("TPVLAN_30", "Prze�adowuj grafik� tematu:");

define("TPVLAN_31", "To jest aktualnie wybrany temat strony administracyjnej");
define("TPVLAN_32", "Ustaw jako temat strony administracyjnej");

define("TPVLAN_33", "Bie��cy temat strony g��wnej");
define("TPVLAN_34", "Bie��cy temat strony administracyjnej");
define("TPVLAN_35", "Zapisz opcje");
define("TPVLAN_36", "Wiadomo�� administracyjna");
define("TPVLAN_37", "Opcje tematu zosta�y zapisane");
define("TPVLAN_38", "Za�aduj temat");
define("TPVLAN_39", "Dost�pne tematy");
define("TPVLAN_40", "Temat strony administracyjne zosta� ustawiony na");

define("TPVLAN_41", "Prosz� wybra� styl uk�adu strony administracyjnej");
define("TPVLAN_42", "Zapisz opcje dla administracji");
define("TPVLAN_43", "Opcje administracji zosta�y zapisane");

define("TPVLAN_46", "PCLZIP - B��d wypakowywania:");
define("TPVLAN_47", "PCLTAR - B��d wypakowywaniar: ");
define("TPVLAN_48", "kod:");

?>
