<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.6 $
|     $Date: 2007/02/18 19:42:45 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_db.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_db.php rev. 1.7
+-----------------------------------------------------------------------------+
*/
 
define("DBLAN_1", "Kopia bezpiecze�stwa ustawie� j�dra zosta�a zapisana w bazie danych.");
define("DBLAN_2", "Kliknij w przycisk, aby zapisa� kopi� bezpiecze�stwa bazy danych e107");
define("DBLAN_3", "Wykonaj kopi� bazy danych SQL");
define("DBLAN_4", "Kliknij w przycisk, aby sprawdzi� poprawno�� bazy danych e107");
define("DBLAN_5", "Sprawd� poprawno�� bazy danych");
define("DBLAN_6", "Kliknij w przycisk, aby zoptymalizowa� baz� danych e107");
define("DBLAN_7", "Optymalizuj baz� danych SQL");
define("DBLAN_8", "Kliknij w przycisk, aby wykona� kopi� ustawie� j�dra");
define("DBLAN_9", "Wykonaj kopi� bezpiecze�stwa j�dra");
define("DBLAN_10", "Narz�dzia bazy danych");
define("DBLAN_11", "Baza danych MySQL");
define("DBLAN_12", "zosta�a zoptymalizowana");
define("DBLAN_13", "Cofnij");
define("DBLAN_14", "Gotowe");
define("DBLAN_15", "Kliknij w przycisk, aby sprawdzi� czy s� dost�pne uaktualnienia BD");
define("DBLAN_16", "Sprawd� uaktualnienia");
define("DBLAN_17", "Nazwa preferencji");
define("DBLAN_18", "Warto�� preferencji");
define("DBLAN_19", "Kliknij w przycisk, aby otworzy� edytor preferencji (tylko dla zaawansowanych u�ytkownik�w)");
define("DBLAN_20", "Edytor preferencji");
define("DBLAN_21", "Usu� zaznaczone"); // Delete Checked
define("DBLAN_22", "Pluginy: Analiza i przegl�d");
define("DBLAN_23", "Skanowanie zosta�o zako�czone pomy�lnie");
define("DBLAN_24", "Nazwa");
define("DBLAN_25", "Katalog");
define("DBLAN_26", "Zawarte dodatki");
define("DBLAN_27", "Zainstalowany");
define("DBLAN_28", "Kliknij w przycisk, aby przeskanowa� katalogi wtyczek w poszukiwaniu zmian");
define("DBLAN_29", "Skanowanie katalog�w wtyczek");
define("DBLAN_30", " (Je�li dodatek pokazuje b��d, sprawd� czy na zewn�trz tag�w otwarcia/zamkni�cia kodu PHP wyst�puj� jakie� znaki)");
define("DBLAN_31", "OK");
define("DBLAN_32", "B��d");
define("DBLAN_33", "Niedost�pny");
define("DBLAN_34", "Niesprawdzony");

?>
