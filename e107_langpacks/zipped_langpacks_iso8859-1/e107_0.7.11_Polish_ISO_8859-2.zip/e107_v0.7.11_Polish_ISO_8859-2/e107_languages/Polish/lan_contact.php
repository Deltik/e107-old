<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2007/02/19 16:58:12 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_contact.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_contact.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("LANCONTACT_01", "Dane kontaktowe");
define("LANCONTACT_02", "Formularz kontaktowy");
define("LANCONTACT_03", "Twoje imi�:");
define("LANCONTACT_04", "Adres email:");
define("LANCONTACT_05", "Temat wiadomo�ci:");
define("LANCONTACT_06", "Wiadomo��:");
define("LANCONTACT_07", "Wy�lij kopi� tej wiadomo�ci na m�j w�asny email.");
define("LANCONTACT_08", "Wy�lij");
define("LANCONTACT_09", "Twoja wiadomo�� zosta�a wys�ana.");
define("LANCONTACT_10", "Wyst�pi� problem podczas wysy�ania Twojej wiadomo�ci.");
define("LANCONTACT_11", "Tw�j adres email wydaje si� by� niepoprawny.\\nProsz� go sprawdzi� i spr�bowa� ponownie.");
define("LANCONTACT_12", "Twoja wiadomo�� jest za kr�tka.");
define("LANCONTACT_13", "Prosz� uwzgl�dni� temat."); 

define("LANCONTACT_14", "Wy�lij wiadomo�� do:");
define("LANCONTACT_15", "Wprowadzony kod jest niepoprawny");
define("LANCONTACT_16", "Wprowad� kod");

?>
