<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2007/10/05 22:15:41 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_email.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_email.php rev. 1.7
+-----------------------------------------------------------------------------+
*/
 
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }

define("LAN_EMAIL_1", "Nadawc� jest:");
define("LAN_EMAIL_2", "Adres IP nadawcy:");
define("LAN_EMAIL_3", "Wiadomo�� email od ");
define("LAN_EMAIL_4", "Wy�lij");
define("LAN_EMAIL_5", "Wy�lij email do znajomego");
define("LAN_EMAIL_6", "Witaj! S�dz�, �e zainteresujesz si� wiadomo�ci� pochodz�c� ze strony -");
define("LAN_EMAIL_7", "Wy�lij emaila do znajomego");
define("LAN_EMAIL_8", "Komentarz");
define("LAN_EMAIL_9", "Wy�lij komentarz"); // Przepraszam - nie mog� wys�a� emaila - Sorry - unable to send email
define("LAN_EMAIL_10", "Wiadomo�� email zosta�a wys�ana do");
define("LAN_EMAIL_11", "Email zosta� wys�any");
define("LAN_EMAIL_12", "B��d");
define("LAN_EMAIL_13", "Wy�lij artyku� przyjacielowi");
define("LAN_EMAIL_14", "Wy�lij newsa przyjacielowi");
define("LAN_EMAIL_15", "U�ytkownik: ");
define("LAN_EMAIL_106", "Podany adres email jest b��dny. Wprowad� go ponownie.");
define("LAN_EMAIL_185", "Wy�lij artyku�");
define("LAN_EMAIL_186", "Wy�lij newsa");
define("LAN_EMAIL_187", "Docelowy adres email");
define("LAN_EMAIL_188", "Witaj! S�dz�, �e zainteresujesz si� tym newsem pochodz�cym ze strony -");
define("LAN_EMAIL_189", "Witaj! S�dz�, �e zainteresujesz si� tym artyku�em pochodz�cym ze strony -");
define("LAN_EMAIL_190", "Wprowad� kod");

?>
