<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2007/10/05 22:15:41 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_upload_handler.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_upload_handler.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("LANUPLOAD_1", "Typ pliku");
define("LANUPLOAD_2", "jest niedozwolony i zostanie usuni�ty.");
define("LANUPLOAD_3", "Wysy�anie zako�czone pomy�lnie");
define("LANUPLOAD_4", "Prawdopodobnie folder docelowy nie istnieje, albo nie jest zapisywalny.");
define("LANUPLOAD_5", "Wysy�any plik przewy�sza dyrektyw� <i>upload_max_filesize</i> w <i>php.ini</i>.");
define("LANUPLOAD_6", "Wysy�any plik przewy�sza dyrektyw� <i>MAX_FILE_SIZE</i>, kt�ra zosta�a wyszczeg�lniona w formularzu HTML.");
define("LANUPLOAD_7", "Wysy�any plik tylko cz�ciowo zosta� za�adowany.");
define("LANUPLOAD_8", "�aden plik nie zosta� wys�any.");
define("LANUPLOAD_9", "Wysy�any plik posiada rozmiar 0 bajt�w");
define("LANUPLOAD_10", "B��d wysy�ania [napotkano duplikat nazwy] - Plik z tak� sama nazw� ju� istnieje.");
define("LANUPLOAD_11", "Plik nie zosta� wys�any. Nazwa pliku: ");
define("LANUPLOAD_12", "B��d");
define("LANUPLOAD_13", "Brakuj�cy folder tymczasowy");
define("LANUPLOAD_14", "B��d zapisu pliku");
define("LANUPLOAD_15", "Upload zabroniony");
define("LANUPLOAD_16", "Nieznany b��d");
define("LANUPLOAD_17", "Niepoprawna nazwa wysy�anego pliku");
define("LANUPLOAD_18", "Wysy�any plik przekracza dozwolon� wielko��.");
define("LANUPLOAD_19", "Wys�ano zbyt wiele plik�w - usuni�to nadmiar.");


?>