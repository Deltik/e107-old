<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/11/24 14:06:59 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_news.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_news.php rev. 1.11
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Aktualno�ci");

define("LAN_NEWS_1", "Wiadomo�� tylko dla okre�lonych u�ytkownik�w");
define("LAN_NEWS_2", "Nie masz uprawnie� do przegl�dania tej wiadomo�ci");
// define("LAN_NEWS_3", "Prosz� usun�� plik <b>install.php</b> z Twojego serwera,");
// define("LAN_NEWS_4", "je�li tego nie zrobisz istnieje potencjalne ryzyko zagro�enia bezpiecze�stwa dla Twojej stron internetowej");

define("LAN_NEWS_5", "B��d! Nie mog� zaktualizowa� wiadomo�ci w bazie danych!");
define("LAN_NEWS_6", "Wiadomo�� zosta�a dodana do bazy danych.");
define("LAN_NEWS_7", "B��d! Nie mog� zapisa� wiadomo�ci w bazie danych!");
define("LAN_NEWS_8", "Wiadomo�� zosta�a dodana do bazy danych dla wszystkich wersji j�zykowych. ID: ");
define("LAN_NEWS_9", "Ustaw tylko tytu� - <b>b�dzie pokazywany tylko tytu� wiadomo�ci</b><br />");
define("LAN_NEWS_10", "Ta wiadomo�� jest <b>nieaktywna</b> (Nie b�dzie pokazywana na stroni g��wnej). ");
define("LAN_NEWS_11", "Ta wiadomo�� jest <b>aktywna</b> (B�dzie pokazywana na stronie g��wnej). ");
define("LAN_NEWS_12", "Komentarze zosta�y <b>w��czone</b>. ");
define("LAN_NEWS_13", "Komentarze zosta�y <b>wy��czone</b>. ");
define("LAN_NEWS_14", "<br />Czas aktywacji: ");
define("LAN_NEWS_15", "D�ugo��: ");
define("LAN_NEWS_16", "b. D�ugo�� rozwini�cia: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Informacje:");
define("LAN_NEWS_19", "Teraz");
define("LAN_NEWS_20", "Wiadomo�� zosta�a zaktualizowana w bazie danych dla nast�puj�cego j�zyka: ");
define("LAN_NEWS_21", "Wiadomo�� zosta�a zaktualizowana w bazie danych.");
// define("LAN_NEWS_22", "Id� do strony: ");
define("LAN_NEWS_23", "Kategorie aktualno�ci");
define("LAN_NEWS_24", "Pobierz t� wiadomo�� w postaci pdf");

define("LAN_NEWS_82", "Aktualno�ci - Kategoria");
define("LAN_NEWS_83", "Nie ma jeszcze �adnych wiadomo�ci - zapraszamy wkr�tce.");
define("LAN_NEWS_84", "Wiadomo�ci");
define("LAN_NEWS_99", "Komentarze");
define("LAN_NEWS_100", "Dalej");
define("LAN_NEWS_307", "Wszystkich pozycji w tej kategorii: ");
define("LAN_NEWS_462", "Brak aktualno�ci dla wskazanego miesi�ca.");

?>
