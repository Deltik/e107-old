<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/07/27 11:15:22 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_user.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_user.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "U�ytkownicy");

define("LAN_20", "B��d");
define("LAN_112", "Adres email");
define("LAN_115", "Numer ICQ");
define("LAN_116", "Adres AIM");
define("LAN_117", "MSN Messenger");
define("LAN_118", "Urodziny");
define("LAN_119", "Miejscowo��");
define("LAN_120", "Sygnatura");
define("LAN_137", "Nie ma �adnych informacji o wskazanych u�ytkownikach, poniewa� nie s� oni zarejestrowani w serwisie");
define("LAN_138", "Zarejestrowani u�ytkownicy: ");
define("LAN_139", "Sortuj: ");
define("LAN_140", "Zarejestrowani u�ytkownicy");
define("LAN_141", "Nie ma jeszcze zarejestrowanych u�ytkownik�w.");
define("LAN_142", "U�ytkownik");
define("LAN_143", "[ukryto na �yczenie]");
define("LAN_144", "Strona domowa");
define("LAN_145", "Do��czy�");
define("LAN_146", "Wizyt na stronie od czasu rejestracji");
define("LAN_147", "Post�w na czacie");
define("LAN_148", "Napisanych komentarzy");
define("LAN_149", "Post�w na forum");
define("LAN_308", "Prawdziwe imi�");
define("LAN_400", "To nie jest poprawna nazwa u�ytkownika.");
define("LAN_401", "brak danych");
define("LAN_402", "Profil u�ytkownika");
define("LAN_403", "Statystyki u�ytkownika");
define("LAN_404", "Ostatnia wizyta");
define("LAN_405", "dni temu");
define("LAN_406", "Ranga");
define("LAN_407", "brak");
define("LAN_408", "brak zdj�cia");
define("LAN_409", "punkt�w");
define("LAN_410", "Dodatkowe informacje");
define("LAN_411", "Prosz� klikn�� tutaj, aby zaktualizowa� swoje dane");
define("LAN_412", "Kliknij tutaj, aby edytowa� informacje o tym u�ytkowniku");
define("LAN_413", "usu� zdj�cie");
define("LAN_414", "poprzedni u�ytkownik");
define("LAN_415", "nast�pny u�ytkownik");
define("LAN_416", "Musisz by� zalogowany, aby uzyska� dost�p do tej strony");
define("LAN_417", "G��wny administrator strony");
define("LAN_418", "Administrator strony");
define("LAN_419", "Wy�wietl");
define("LAN_420", "Malej�co");
define("LAN_421", "Rosn�co");
define("LAN_422", "Prze�aduj");
define("LAN_423", "Kliknij tutaj, aby zobaczy� komentarze u�ytkownika");
define("LAN_424", "Kliknij tutaj, aby zobaczy� postu u�ytkownika na forum");
define("LAN_425", "Wy�lij wiadomo�� prywatn�");
define("LAN_426", "temu");

define("USERLAN_1", "Przegl�d ocen");
define("USERLAN_2", "Nie posiadasz dost�pu do przegl�dania tej strony.");

?>
