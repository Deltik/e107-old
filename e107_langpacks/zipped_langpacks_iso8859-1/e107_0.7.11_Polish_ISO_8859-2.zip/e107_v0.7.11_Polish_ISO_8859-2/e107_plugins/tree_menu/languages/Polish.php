<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:37:50 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/tree_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/tree_menu/languages/English.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("TREE_L1", "Konfiguracja Tree Menu");
define("TREE_L2", "Aktualizuj ustawienia");
define("TREE_L3", "Konfiguracja Tree Menu zosta�a zapisana.");
define("TREE_L4", "W��czone");
define("TREE_L5", "Wy��czone");
define("TREE_L6", "Klasa CSS dla nieodwiedzonych link�w");
define("TREE_L7", "Klasa CSS dla aktywnych link�w");
define("TREE_L8", "Klasa CSS dla odwiedzonych link�w");
define("TREE_L9", "U�yj klasy <i>spacer</i> pomi�dzy g��wnymi linkami");

?>
