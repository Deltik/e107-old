<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/06/28 17:05:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/integrity_check/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/integrity_check/languages/English.php rev. 1.6
+-----------------------------------------------------------------------------+
*/
 
define("Integ_01", "Zapis zako�czono pomy�lnie");
define("Integ_02", "Zapis nieudany");
define("Integ_03", "Brakuj�ce pliki:");
define("Integ_04", "B��dy CRC:");
define("Integ_05", "Nie mog� otworzy� pliku...");
define("Integ_06", "Sprawdzenie integralno�ci plik�w");
define("Integ_07", "Nie ma dost�pnych plik�w");
define("Integ_08", "Sprawd� integralno��");
define("Integ_09", "Utw�rz plik sfv");
define("Integ_10", "Wybrany katalog <u>nie</u> nie zostanie zapisany wewn�trz pliku crc.");
define("Integ_11", "Nazwa pliku:");
define("Integ_12", "Utw�rz plik sfv");
define("Integ_13", "Sprawdzanie integralno�ci");
define("Integ_14", "Utworzenie pliku SFV nie jest mo�liwe, poniewa� folder ".e_PLUGIN."integrity_check/<b>{output}</b> nie jest zapisywalny. Prosz� ustawi� chmod tego folderu na warto�� 777!");
define("Integ_15", "Wszystkie pliki zosta�y sprawdzone i s� poprawne!");
define("Integ_16", "Plik crc j�dra jest niedost�pny");
define("Integ_17", "Pliki crc plugin�w s� niedost�pne");
define("Integ_18", "Tworzenie pliku CRC dla plugin�w");
define("Integ_19", "Pliki sum kontrolnych j�dra");
define("Integ_20", "Pliki sum kontrolnych dla plugin�w");
define("Integ_21", "Wybierz plugin, dla kt�rego chcia�by� utworzy� plik crc.");
define("Integ_22", "U�yj formatu gzip");
define("Integ_23", "Sprawd� tylko zainstalowane tematy");
define("Integ_24", "Panel administratora");
define("Integ_25", "Opu�� panel admina");
define("Integ_26", "Za�aduj stron� z normalnym nag��wkiem");
define("Integ_27", "U�YJ INSPEKTORA PLIK�W W CELU SPRAWDZENIA PLIK�W J�DRA");
	
// define("Integ_29", "<br /><br /><b>*<u>CRC-ERRORS:</u></b><br />These are checksum errors and there are two possible reasons for this:<br />-You changed something within the mentioned file, so it isn't longer the same as the original.<br />-The mentioned file is corrupt, you should reupload it!");
// language file should contain NO html. 

define("Integ_30", "Dla mniejszego zu�ycia procesora, mo�esz wykona� sprawdzenie plik�w w krokach od 1 do 10.");
define("Integ_31", "Kroki: ");
define("Integ_32", "Aktualnie w katalogu crc znajduje si� plik nazwany <b>log_crc.txt</b>. Prosz� go usun��! (Lub spr�bowa� od�wie�y�).");
define("Integ_33", "Aktualnie w katalogu crc znajduje si� plik nazwany <b>log_miss.txt</b>. Prosz� go usun��! (Lub spr�bowa� od�wie�y�).");
define("Integ_34", "Tw�j folder crc jest niezapisywalny!");
define("Integ_35", "Z powodu nast�puj�cych przyczyn mo�esz wybra� tylko <b>jeden</b> krok:");
define("Integ_36", "Kliknij tutaj, je�li nie chcesz czeka� 5 sekund do nast�pnego kroku:");
define("Integ_37", "Kliknij");
define("Integ_38", "Jeszcze <u><i>{counts}</i></u> linii do wykonania...");
define("Integ_39", "Prosz� usun�� plik:<br />".e_PLUGIN."integrity_check/<u><i>do_core_file.php</i></u>!<br />Jest on nieaktualny i nigdy nie by� przeznaczony do publicznego wypuszczenia...");

?>
