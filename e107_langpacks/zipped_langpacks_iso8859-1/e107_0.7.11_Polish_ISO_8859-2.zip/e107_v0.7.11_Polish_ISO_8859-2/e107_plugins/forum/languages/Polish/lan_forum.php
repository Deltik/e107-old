<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2008/01/08 18:40:59 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_forum.php rev. 1.8
+-----------------------------------------------------------------------------+
*/
 
define("e_PAGETITLE", "Forum");

define("LAN_30", "Witaj");
define("LAN_31", "Od czasu Twojej ostatniej wizyty na forum nie zamieszczono nowych"); //Obecnie na forum nie ma nowych wypowiedzi
define("LAN_32", "Od czasu Twojej ostatniej wizyty na forum jest jedna nowa ");
define("LAN_33", "Od czasu Twojej ostatniej wizyty na forum jest ");
define("LAN_34", "nowych");
define("LAN_35", " wypowiedzi.");
define("LAN_36", "Ostatnio odwiedzi�e� nasze forum dnia: ");
define("LAN_37", "Dzisiaj jest: ");
define("LAN_38", ", wszystkie czasy s� ");
define("LAN_41", "Najnowszy u�ytkownik: ");
define("LAN_42", "Zarejestrowanych: ");
define("LAN_44", "Na forum mog� si� wypowiada� niezarejestrowani u�ytkownicy, lecz prosz� by� �wiadomym tego, �e adres IP z jakiego opublikujesz swoj� wypowied� zostanie zapisany do wgl�du dla moderator�w.<br />Aby uzyska� dost�p do wszystkich funkcji tego forum musisz si�");
define("LAN_45", "Na forum mog� si� wypowiada� tylko zarejestrowani u�ytkownicy, je�li posiadasz ju� swoje konto <a href='".e_BASE."login.php'>zaloguj si�</a>, w przeciwnym wypadku dokonaj rejestracji");
define("LAN_46", "Forum");
define("LAN_47", "Tematy");
define("LAN_48", "Posty");
define("LAN_49", "Ostatni post");
define("LAN_51", "W tej chwili nie ma jeszcze �adnych dyskusji. Zapraszamy wkr�tce.");
define("LAN_52", "Obecnie w tym dziale nie ma jeszcze �adnych temat�w. Zapraszamy wkr�tce.");
define("LAN_79", "Nowe posty");
define("LAN_80", "Brak nowych post�w");
define("LAN_81", "Temat zamkni�ty");
define("LAN_100", "artyku�y"); //articles
define("LAN_180", "Szukaj");
define("LAN_191", "Informacje");
define("LAN_192", "U�ytkownicy tego forum opublikowali ��cznie ");
define("LAN_196", "Przeczyta�e� ju� ");
define("LAN_197", " wypowiedzi.");
define("LAN_198", " Wszystkie nowe wypowiedzi zosta�y przeczytane.");
define("LAN_199", "Oznacz wszystkie wypowiedzi jako przeczytane");
define("LAN_204", "<b>Mo�esz</b> rozpoczyna� nowe tematy");
define("LAN_205", "<b>Nie mo�esz</b> rozpoczyna� nowych temat�w");
define("LAN_206", "<b>Mo�esz</b> odpowiada� w tematach");
define("LAN_207", "<b>Nie mo�esz</b> odpowiada� w tematach");
define("LAN_208", "<b>Mo�esz</b> redagowa� swoje posty");
define("LAN_209", "<b>Nie mo�esz</b> redagowa� swoich post�w");
define("LAN_392", "Zako�cz �ledzenie tematu");
define("LAN_393", "Wykaz �ledzonych temat�w");
define("LAN_394", "Forum zamkni�te");
define("LAN_397", "�ledzone tematy");
define("LAN_398", "Zamkni�ty");
define("LAN_399", "Dost�p ograniczony");
define("LAN_400", "Wskazane forum mo�e by� tylko przegl�dane przez zarejestrowanych u�ytkownik�w");
define("LAN_401", "Strefa tylko dla zarejestrowanych");

define("LAN_402", "Obecnie to forum jest przeznaczone tylko do odczytu");
	
define("LAN_403", "Nie ma jeszcze post�w");
define("LAN_404", "wypowiedzi");
define("LAN_405", "Dost�p ograniczony");
	
define("LAN_406", "Forum tylko dla administrator�w");
define("LAN_407", "Forum tylko dla zarejestrowanych u�ytkownik�w");
define("LAN_408", "Forum tylko do odczytu");
define("LAN_409", "Forum tylko dla grupy");
define("LAN_410", "Witaj go�ciu");
	
define("LAN_411", "tematy");
define("LAN_412", "post");
define("LAN_413", "temat�w");
define("LAN_414", "posty(�w)");
define("LAN_415", "u�ytkownik aktualnie przegl�da to forum");
define("LAN_416", "u�ytkownik�w aktualnie przegl�da to forum");
	
define("LAN_417", "zarejestrowany");
define("LAN_418", "go��");
define("LAN_419", "zarejestrowanych");
define("LAN_420", "go�ci");
	
define("LAN_421", "Poka� nowe posty");
define("LAN_422", "Nowe posty od Twojej ostatniej wizyty");
define("LAN_423", "Autor");
define("LAN_424", "Nowe tematy");
define("LAN_425", "Odp:");
	
//v.616
define("LAN_426", "Aktualnie na forum s� online: ");
define("LAN_427", "Wy�wietl szczeg�owy spis.");
define("LAN_428", "Odp:");
define("LAN_429", "Lista Top : Najbardziej aktywni");
define("LAN_430", "Lista Top : Najch�tniej czytane");
define("LAN_431", "Moje posty");
define("LAN_432", "Moje ustawienia");
define("LAN_433", "Regulamin forum");
define("LAN_434", "Powr�t do forum");
define("LAN_435", "M�j profil");
define("LAN_436", " (Zostanie wy�wietlony w nowym oknie.)");

define("LAN_437", "zarejestrowa�");
define("LAN_438", ", je�li natomiast posiadasz ju� swoje konto <a href='".e_BASE."login.php'>zaloguj si�</a>.");
define("LAN_439", "tutaj");
define("LAN_440", "w celu uzyskania pe�nego dost�pu do strony.");

define("LAN_441", "Statystyki forum");
	
define('FORLAN_441', 'Aktualnie nie ma zdefiniowanych regu�.');
define('FORLAN_442', 'M�j upload');
define('FORLAN_443', '[u�ytkownik usuni�ty]');
define('FORLAN_444', 'Subfora');

?>
