<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2007/10/08 19:03:11 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum_admin.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_forum_admin.php rev rev. 1.23
+-----------------------------------------------------------------------------+
*/
 
define("FORLAN_1", "Musisz wpisa� ilo�� dni, kt�ra b�dzie oczyszczona.");
define("FORLAN_2", "Prosz� wybra� jedn� z mo�liwo�ci, albo ca�kowite usuwanie wypowiedzi, albo zmiana ich statusu na nieaktywny (nie zostan� usuni�te, ale r�wnie� nie b�d� widoczne na forach)");
define("FORLAN_3", "zosta�o usuni�tych");
define("FORLAN_4", "Zmieni�o status na nieaktywny");
define("FORLAN_5", "Wykonaj oczyszczanie");
define("FORLAN_6", "Anuluj");
define("FORLAN_7", "Opcje forum");
define("FORLAN_8", "Forum zosta�o oczyszczone.");
define("FORLAN_9", "Oczyszczanie nie jest wymagane.");
define("FORLAN_10", "Opcje zosta�y zapisane");
define("FORLAN_11", "Forum zosta�o utworzone");
define("FORLAN_12", "Forum zosta�o zaktualizowane");
define("FORLAN_13", "Dzia� zosta� utworzony");
define("FORLAN_14", "Dzia� forum zosta� zaktualizowany");
define("FORLAN_15", "Prosz� zaznaczy� pole potwierdzenia, aby usun�� to forum");
define("FORLAN_16", "Forum");
define("FORLAN_17", "Dzia�y nie zosta�y jeszcze utworzone");
define("FORLAN_18", "Aktualne dzia�y");
define("FORLAN_19", "Edytuj");
define("FORLAN_20", "Usu�");
define("FORLAN_21", "zaznacz, aby potwierdzi�");
define("FORLAN_22", "Dzia�");
define("FORLAN_23", "Widoczny dla");
define("FORLAN_24", "Wska� grup� dopuszczon� do przegl�dania forum");
define("FORLAN_25", "Aktualizuj dzia�");
define("FORLAN_26", "Utw�rz dzia�");
define("FORLAN_27", "Musisz zdefiniowa� przynajmniej jeden dzia� dla forum przed jego utworzeniem.");
define("FORLAN_28", "Forum");
define("FORLAN_29", "Nie utworzono jeszcze �adnego forum");
define("FORLAN_30", "Aktualne fora");
define("FORLAN_31", "Nazwa");
define("FORLAN_32", "Opis");
define("FORLAN_33", "Moderatorzy");
define("FORLAN_34", "Wybierz grup� u�ytkownik�w, kt�ra b�dzie mog�a moderowa� to forum");
define("FORLAN_35", "Aktualizuj forum");
define("FORLAN_36", "Utw�rz forum");
define("FORLAN_37", "Kolejno��");
define("FORLAN_38", "Zamkni�ty");
define("FORLAN_39", "Tylko dla zarejestrowanych");
define("FORLAN_40", "Ograniczenie");
define("FORLAN_41", "przesu� w g�ry");
define("FORLAN_42", "przesu� w d�");
define("FORLAN_43", "Podgl�d oraz kolejno�� forum");
define("FORLAN_44", "Ogranicz tabel�");
define("FORLAN_45", "Zaznacz to, aby wy�wietla� forum wewn�trz tabeli tematu");
define("FORLAN_46", "Tytu� wy�wietlany w nag��wku, je�li zaznaczona jest opcja ograniczania forum tabel�");
define("FORLAN_47", "W��cz powiadamianie emailem");
define("FORLAN_48", "Zaznacz to, aby umo�liwi� u�ytkownikom otrzymywanie powiadomie� email, gdy kto� odpowie na ich wypowied�.");
define("FORLAN_49", "W��cz ankiety");
define("FORLAN_50", "Zaznacz to, aby zezwoli� u�ytkownikom na umieszczanie ankiet na forum - Do u�ywania tej funkcji musi by� zainstalowany plugin <i>Ankieta</i> (Poll).");
define("FORLAN_51", "W��cz �ledzenie");
define("FORLAN_52", "Zaznacz to, aby zezwoli� u�ytkownikom na �ledzenie temat�w i otrzymywanie emaili, gdy kto� odpowie w danym temacie.");
define("FORLAN_53", "Prefiks wiadomo�ci email");
define("FORLAN_54", "Tekst kt�ry wprowadzisz zostanie dodany jako przedrostek tematu do wszystkich emaili wysy�anych bezpo�rednio przez forum.");
define("FORLAN_55", "Pr�g popularno�ci tematu");
define("FORLAN_56", "Ilo�� post�w w temacie zanim zostanie on oznaczony jako popularny");
define("FORLAN_57", "Post�w na stronie");
define("FORLAN_58", "Ilo�� post�w wy�wietlanych na jednej stronie");
define("FORLAN_59", "Oczyszczanie");
define("FORLAN_60", "Z poziomu tej strony mo�esz usun�� wszystkie tematy, kt�re nie otrzyma�y odpowiedzi w przeci�gu podanej przez Ciebie ilo�ci dni. <br /><b> Prosz� zachowa� ostro�no�� podczas u�ywania tej funkcji!</b>");
define("FORLAN_61", "Aktualizuj opcje");
define("FORLAN_62", "Opcje forum");
define("FORLAN_63", "Rangi");
define("FORLAN_64", "Z poziomu tej strony mo�esz zarz�dza� rangami i ustali� dla nich poziom, je�li pozostawisz puste pola, zostan� u�yte og�lne oznaczenia poziom�w. Poziomy oddziel przecinkami. Maksymalni jest 10 poziom�w, najni�szy jest pierwszy.");
define("FORLAN_65", "Nag��wek forum");
define("FORLAN_66", "Wtyczka Ankieta nie zainstalowana");

define("FORLAN_70", "W��cz za��czanie obrazk�w oraz plik�w");
define("FORLAN_71", "Umo�liwi u�ytkownikom �adowanie obrazk�w oraz plik�w i za��czanie ich do wypowiedzi na forum,");
define("FORLAN_72", "Aktualizuj kolejno��");
define("FORLAN_73", "Kolejno�� zosta�a zaktualizowana");

define("FORLAN_75", "Dzia�y forum");
define("FORLAN_76", "Aktualne fora");
define("FORLAN_77", "Utw�rz forum");
define("FORLAN_78", "Kolejno�� forum");
define("FORLAN_79", "Preferencje");
define("FORLAN_80", "Opcje");
define("FORLAN_81", "Czy na pewno chcesz usun�� wskazany dzia�? - fora z tego dzia�u zostan� r�wnie� usuni�te");
define("FORLAN_82", "Czy na pewno chcesz usun�� wskazane forum?");
define("FORLAN_83", "Utw�rz dzia�");
define("FORLAN_84", "Tylko dla zarejestrowanych");
define("FORLAN_85", "Tylko do odczytu");
define("FORLAN_86", "Tylko dla administrator�w");
define("FORLAN_87", "Oczy�� tematy, na kt�re nikt nie odpowiedzia�, w podanej ilo�ci dni:");

define("FORLAN_88", "Oczy�� tematy, na kt�re nikt nie odpowiedzia�, w podanej ilo�ci dni:");

define("FORLAN_89", "Usu� ca�kowicie");
define("FORLAN_90", "Zmie� ich status na nieaktywny");

define("FORLAN_91", "post(�w) zmieni�(o) status na nieaktywny");
define("FORLAN_92", "temat(�w) zosta�(o) usuni�ty(ch)");
define("FORLAN_93", "post(�w) zosta�(o) usuni�ty(ch)");

define("FORLAN_94", "Ustaw rangi");
define("FORLAN_95", "Rangi zosta�y zapisane");
define("FORLAN_96", "Forum zosta�o usuni�te");
define("FORLAN_97", "Dzia� zosta� usuni�ty");

define("FORLAN_98", "Nazwa rangi");
define("FORLAN_99", "ilo�� punkt�w niezb�dna do zmiany poziomu");
define("FORLAN_100", "za�aduj obrazki do ".THEME."forum/");
define("FORLAN_101", "G��wny administrator");
define("FORLAN_102", "Pr�g");
define("FORLAN_103", "Administrator");
define("FORLAN_104", "Obraz Rangi");
define("FORLAN_105", "Moderator");


define("FORLAN_106", "Typ oczyszczania:");
define("FORLAN_107", "Forum");
define("FORLAN_108", " zosta�o usuni�te");
define("FORLAN_109", "dni:");
define("FORLAN_110", "Oczy��");
define("FORLAN_111", "dezaktywowane");

define("FORLAN_112", "W��cz przekierowywanie");
define("FORLAN_113", "Zaznacz to, aby przegl�darka automatycznie przekierowywa�a, po zamieszczeniu posta, na stron� forum.");
define("FORLAN_114", "Nazwa w�asna u�ytkownika");
define("FORLAN_115", "Zaznacz to, aby zezwoli� u�ytkownikom na zmian� swojej nazwy w�asnej");
define("FORLAN_116", "Raporty");
define("FORLAN_117", "Zostanie usuni�ty zapis na temat zg�oszonego posta, a nie sam post.");
define("FORLAN_118", "Raport zosta� usuni�ty");
// define("FORLAN_119", "Klikniecie na link otworzy forum w nowym oknie.");
define("FORLAN_120", "Zaznacz to, aby zezwoli� u�ytkownikom na zmian� swojej nazwy w�asnej");
define("FORLAN_121", "Aktualnie nie ma zg�oszonych post�w");
define("FORLAN_122", "Kliknij tutaj, aby administrator by� powiadamiany, gdy kto� zg�osi posta na forum.");
define("FORLAN_123", "Regulaminy");
define("WMGLAN_1", "Regulamin dla go�ci");
define("WMGLAN_2", "Regulamin dla zarejestrowanych");
define("WMGLAN_3", "Regulamin dla administrator�w");
define("WMGLAN_4", "Wy�lij");
define("WMGLAN_5", "Ustawianie zasad forum");
define("WMGLAN_6", "Aktywowa�?");
// define("FORLAN_124", "Otwieraj linki w nowym oknie");
// define("FORLAN_125", "Zaznacz tutaj, aby linki otwiera�y si� w nowym oknie (<i>opcja ta dotyczy ca�ego serwisu</i>). ");
define("FORLAN_126", "Pokazuj podpowiedzi");
define("FORLAN_127", "Zaznacz to, aby wy�wietla� podpowiedzi, zawieraj�ca fragment pierwszego posta z danego tematu, po najechaniu myszka na jego nazw�.");
define("FORLAN_128", "D�ugo�� podpowiedzi");
define("FORLAN_129", "Tutaj mo�esz okre�li� ilo�� znak�w pokazywanych w wypowiedzi.");
define("FORLAN_130", "kliknij tutaj");
define("FORLAN_131", ", aby ustawi� maksymalny rozmiar pliku, dozwolone typy plik�w itd.");
define("FORLAN_132", "Uwydatniaj przyklejone tematy");
define("FORLAN_133", "Zaznaczenie spowoduje, �e przyklejone tematy zostan� dodatkowo uwydatnione na forum (oddzielna sekcja z nag��wkiem)");
define("FORLAN_134", "Maksymalna szeroko�� �adowanych obrazk�w");
define("FORLAN_135", "Pozostaw puste, aby wy��czy� autorozmiarowanie obrazk�w");
define("FORLAN_136", "Utw�rz link do obrazka pe�nowymiarowego");
define("FORLAN_137", "W��czenie tego spowoduje zmian� wielko�ci du�ych obrazk�w, a tak�e utworzy link do oryginalnych obrazk�w w pe�nym wymiarze. Je�eli jest wy��czone, oryginalne obrazki b�d� odrzucane.");
define("FORLAN_138", "Oczy�� nast�puj�ce fora");
define("FORLAN_139", "Aby u�ywa� tej opcji musisz r�wnie� zaznaczy� 'Uaktywnij obrazy w postach' na stronie <a href='".e_ADMIN."image.php'>Obrazy</a>.");
define("FORLAN_140", "Przegl�danie");
define("FORLAN_141", "Odpowiadanie");
define("FORLAN_142", "Uprawnieni do odpowiadania");
define("FORLAN_143", "Wybierz grup� dopuszczon� do udzielania odpowiedzi na forum");
define("FORLAN_144", "Moderatorzy zostali przypisani");
define("FORLAN_145", "Konfiguracja subforum");
define("FORLAN_146", "Aktualnie nie ma jeszcze �adnego subforum");
define("FORLAN_147", "Aktualizuj subforum");
define("FORLAN_148", "Utw�rz subforum");
define("FORLAN_149", "subfora");
define("FORLAN_150", "subforum");
define("FORLAN_151", "ID");
define("FORLAN_152", "posty");
define("FORLAN_153", "Narz�dzia");
define("FORLAN_154", "Odpowiedzi zosta�y usuni�te");
define("FORLAN_155", "Kategorie forum");

define("FORLAN_156", "Wybierz forum, aby wykona� na nim dzia�anie");
define("FORLAN_157", "Wszystkie fora");
define("FORLAN_158", "Przeliczanie informacji o ostatnich postach na forum");
define("FORLAN_159", "Wybierz, aby przeliczy� informacj� o ostatnich postach.");
define("FORLAN_160", "Wybierz, aby wykona� to zadanie tylko na forach, pomijaj�c tematy.");
define("FORLAN_161", "Przeliczanie ilo�ci post�w");
define("FORLAN_162", "Wybierz, aby przeliczy� ilo�� post�w i temat�w na forum.");
define("FORLAN_163", "Przeliczanie ilo�ci post�w u�ytkownik�w");
define("FORLAN_164", "Wybierz, aby przeliczy� ilo�� wypowiedzi u�ytkownik�w");
define("FORLAN_165", "Wykonaj zadania");
define("FORLAN_166", "Narz�dzia forum");
define("FORLAN_167", "Obliczenia zosta�y zaktualizowane dla forum");
define("FORLAN_168", "Informacje o ostatnich postach zosta�a zaktualizowana dla forum");
define("FORLAN_169", "Ilo�� poszczeg�lnych wypowiedzi u�ytkownik�w forum zosta�y zaktualizowane");
define("FORLAN_170", "Raporty");
define("FORLAN_171", "Raport na temat wypowiedzi na forum");
define("FORLAN_172", "Usu� ten raport");
define("FORLAN_173", "Nazwa tematu");
define("FORLAN_174", "Raport dostarczy�(a)");
define("FORLAN_175", "Raport dostarczono dnia");
define("FORLAN_176", "Tre�� raportu");

define("FORLAN_177", "Powiadomienia email domy�lnie W��CZONE");
define("FORLAN_178", "Zaznacz to, aby pole powiadomie� email by�o domy�lnie zaznaczone.");

define("FORLAN_179", "(Dodanie * do pocz�tku nazwy forum spowoduje, �e forum b�dzie zawiera�o tylko subfora. Temat forum musi r�wnie� wspiera� t� opcj�.)");
define("FORLAN_180", "Potwierd� operacj� usuwania");
define("FORLAN_181", "Potwierd� usuwanie");
define("FORLAN_182", "r�wnie� przelicza odpowiedzi dla wszystkich temat�w w wybranym forum");
define("FORLAN_183", "(ta funkcja nie jest dozwolona, kiedy jest wybrana opcja 'wszystkie fora dyskusyjne' ze wzgl�du na ilo�� zapyta� jak� ta funkcja wygeneruje)");

?>
