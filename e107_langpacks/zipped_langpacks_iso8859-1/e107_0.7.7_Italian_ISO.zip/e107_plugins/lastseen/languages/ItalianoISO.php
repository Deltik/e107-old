<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/lastseen/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/28 20:13:14 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/

define("LSP_LAN_1", "Last seen");


?>