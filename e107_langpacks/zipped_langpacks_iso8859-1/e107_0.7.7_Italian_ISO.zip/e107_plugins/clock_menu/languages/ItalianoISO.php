<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/

define('CLOCK_MENU_L1', "Configurazione Clock men� salvata");
define('CLOCK_MENU_L2', "Titolo");
define('CLOCK_MENU_L3', "Aggiorna impostazioni Men�");
define('CLOCK_MENU_L4', "Configurazione Clock Men�");
define('CLOCK_MENU_L5', " Luned�,");
define('CLOCK_MENU_L6', " Marted�,");
define('CLOCK_MENU_L7', " Mercoled�,");
define('CLOCK_MENU_L8', " Gioved�,");
define('CLOCK_MENU_L9', " Venerd�,");
define('CLOCK_MENU_L10', " Sabato,");
define('CLOCK_MENU_L11', " Domenica,");
define('CLOCK_MENU_L12', "Gennaio");
define('CLOCK_MENU_L13', "Febbraio");
define('CLOCK_MENU_L14', "Marzo");
define('CLOCK_MENU_L15', "Aprile");
define('CLOCK_MENU_L16', 'Maggio');
define('CLOCK_MENU_L17', "Giugno");
define('CLOCK_MENU_L18', "Luglio");
define('CLOCK_MENU_L19', "Agosto");
define('CLOCK_MENU_L20', "Settembre");
define('CLOCK_MENU_L21', "Ottobre");
define('CLOCK_MENU_L22', "Novembre");
define('CLOCK_MENU_L23', "Dicembre");
define('CLOCK_MENU_L24', "");
?>
