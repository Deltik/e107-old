<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_extended_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/05 22:44:37 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Ospiti: ");
define("ONLINE_EL2", "Utenti: ");
define("ONLINE_EL3", "In questa pagina: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Utenti");
define("ONLINE_EL6", "Ultimo iscritto");
define("ONLINE_EL7", "sta visitando");
	
define("ONLINE_EL8", "Massimo n. utenti in linea");
define("ONLINE_EL9", "il");

define("TRACKING_MESSAGE", "La tracciatura utenti Online � disabilitata, per abilitarla clicca <a href='".e_ADMIN."users.php?options'>qui</a></span><br />");

?>
