<?php
//  Italian Translation: e107 Italian Team http://www.e107it.org

define("NFPM_LAN_1", "Discussioni");
define("NFPM_LAN_2", "Autore");
define("NFPM_LAN_3", "Visite");
define("NFPM_LAN_4", "Repliche");
define("NFPM_LAN_5", "Ultimo messaggio di");
define("NFPM_LAN_6", "Discussioni");
define("NFPM_LAN_7", "di");
	
define("NFPM_L1", "Questo plugin visualizza la lista dei nuovi messaggi del forum sulla tua Homepage");
define("NFPM_L2", "Ultimi Messaggi Forum");
define("NFPM_L3", "Per configurare vai nella sezione Gestione Plugin dell'amministrazione");
define("NFPM_L4", "In quale area della pagina vuoi attivare il plugin?");
define("NFPM_L5", "Inattivo");
define("NFPM_L6", "In alto");
define("NFPM_L7", "In basso");
define("NFPM_L8", "Titolo");
define("NFPM_L9", "Numero di nuovi messaggi da visualizzare");
define("NFPM_L10", "Spunta per visualizzare i messaggi entro un box 'scrolling layer'");
define("NFPM_L11", "Altezza Layer");
define("NFPM_L12", "Configurazione Plugin Ultimi Messaggi Forum");
define("NFPM_L13", "Aggiornamento configurazione");
define("NFPM_L14", "Impostazioni aggiornate.");
define("NFPM_L15", "Spunta per visualizzare gli ultimi messaggi.<br />Per default gli ultimi topics.");
define('NFPM_L16', '[Utente Eliminato]');
	
	
?>
