<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/banner_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/01/27 19:52:35 $
|     $Author: streaky $
|     Italian Translation: 
|           e107 Italian Team http://www.e107it.org
|           con la collaborazione di Stefano Vecchi	
+----------------------------------------------------------------------------+
*/
	
define("BANNER_MENU_L1", "Pubblicit�");
define("BANNER_MENU_L2", "Configurazione Banner men� salvata");
	
//v.617
define("BANNER_MENU_L3", "Titolo");
define("BANNER_MENU_L4", "Campagna");
define("BANNER_MENU_L5", "Configuraziane Banner Men�");
define("BANNER_MENU_L6", "Scegli la campagna da mostrare nel men�");
define("BANNER_MENU_L7", "Campagne disponibili");
define("BANNER_MENU_L8", "Campagne Selezionate");
define("BANNER_MENU_L9", "Rimuovi Selezione");
define("BANNER_MENU_L10", "Come deve essere visualizzata la campagna selezionata?");
define("BANNER_MENU_L11", "Scegli un tipo di visualizzazione ...");
define("BANNER_MENU_L12", "una camagna in men� singolo");
define("BANNER_MENU_L13", "tutte le campagne selezoinate in men� singolo");
define("BANNER_MENU_L14", "tutte le campagne selezionate in men� separati");
define("BANNER_MENU_L15", "quanti banner devono essere mostrati?");
define("BANNER_MENU_L16", "Queste impostazioni saranno usate solamente con l'opzione 2 e 3.<br />Se sono presenti meno banner sar� usato il massimo numero disponibile.");
define("BANNER_MENU_L17", "Imposta il totale ...");
define("BANNER_MENU_L18", "Aggiorna Impostazioni Men�");
	
?>