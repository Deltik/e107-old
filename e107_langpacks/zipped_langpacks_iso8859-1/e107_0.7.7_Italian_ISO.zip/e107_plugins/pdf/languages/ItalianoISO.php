<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/16 10:36:59 $
|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Supporto Creazione PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Il Plugin � pronto per essere usato. Configuralo in Gestione Plugin.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Preferenze PDF");
define("PDF_LAN_3", "Attivo");
define("PDF_LAN_4", "Non Attivo");
define("PDF_LAN_5", "Margine Sinistro Pagina");
define("PDF_LAN_6", "Margine Destro Pagina");
define("PDF_LAN_7", "Margine Superiore Pagina");
define("PDF_LAN_8", "font family");
define("PDF_LAN_9", "Dimensioni font di default");
define("PDF_LAN_10", "Dimensione font del Nome Sito");
define("PDF_LAN_11", "Dimensione font della pagina URL");
define("PDF_LAN_12", "Dimensione font dei numeri pagina");
define("PDF_LAN_13", "Mostri il logo nel pdf?");
define("PDF_LAN_14", "Mostri il nome sito nel pdf?");
define("PDF_LAN_15", "Mostri l'URL della pagina di creazione nel pdf?");
define("PDF_LAN_16", "Mostri il numero di pagina nel pdf?");
define("PDF_LAN_17", "Aggiorna");
define("PDF_LAN_18", "Preferenze PDF Aggiornate");
define("PDF_LAN_19", "Pagina");
define("PDF_LAN_20", "error reporting");

?>