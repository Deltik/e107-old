<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/23 23:10:14 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Utenti registrati");

define("NT_LAN_UV_1", "Utenti registrati verificati");
define("NT_LAN_UV_2", "ID Utente: ");
define("NT_LAN_UV_3", "Nome di Login Utente: ");
define("NT_LAN_UV_4", "IP Utente: ");


define("NT_LAN_LI_1", "Utenti Loggati");

define("NT_LAN_LO_1", "Utenti logged out");
define("NT_LAN_LO_2", " logged out dal sito");

define("NT_LAN_FL_1", "Flood Ban");
define("NT_LAN_FL_2", "Indirizzi IP bannati per flooding");

define("NT_LAN_SN_1", "Nuovi oggetti inviati");

define("NT_LAN_NU_1", "Updated");

define("NT_LAN_ND_1", "News Eliminate");
define("NT_LAN_ND_2", "Deleted news item id");
?>
