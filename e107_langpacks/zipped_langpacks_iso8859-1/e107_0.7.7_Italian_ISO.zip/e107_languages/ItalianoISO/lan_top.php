<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "Top Autori Forum");
define("TOP_LAN_1", "Nome Utente");
define("TOP_LAN_2", "Messaggi");
define("TOP_LAN_3", "Top Autori Commenti");
define("TOP_LAN_4", "Commenti");
define("TOP_LAN_5", "Top Autori Chatbox");
define("TOP_LAN_6", "Valutazione");
//v.616
define("LAN_1", "Discussione");
define("LAN_2", "Inviato da");
define("LAN_3", "Visite");
define("LAN_4", "Repliche");
define("LAN_5", "Ultimo messaggio");
define("LAN_6", "Discussioni");
define("LAN_7", "Discussioni pi� attive");
define("LAN_8", "Classifica Autori");
?>