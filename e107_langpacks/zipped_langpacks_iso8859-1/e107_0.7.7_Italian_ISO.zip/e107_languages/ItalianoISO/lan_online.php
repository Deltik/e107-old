<?php
/*
+---------------------------------------------------------------+
|     e107 website system
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+---------------------------------------------------------------+*/
define("ONLINE_EL1", "Ospiti:");
define("ONLINE_EL2", "Utenti: ");
define("ONLINE_EL3", "In questa pagina: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Utenti");
define("ONLINE_EL6", "Ultimo iscritto");
define("ONLINE_EL7", "viewing");
define("ONLINE_EL8", "Massimo n. utenti in linea: ");
define("ONLINE_EL9", "il");define("ONLINE_EL10", "Nome utente");
define("ONLINE_EL10", "Nome Utente");
define("ONLINE_EL11", "sta visitando");
define("ONLINE_EL12", "sta rispondendo a");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Discussione");
define("ONLINE_EL15", "Pagina");
define("CLASSRESTRICTED", "Pagina riservata Gruppo Utenti");
define("ARTICLEPAGE", "Articolo/Recensione");
define("CHAT", "Chat");
define("COMMENT", "Commenti");
define("DOWNLOAD", "Downloads");
define("EMAIL", "email.php");
define("FORUM", "Indice principale del Forum");
define("LINKS", "Links");
define("NEWS", "News");
define("OLDPOLLS", "Vecchi sondaggi");
define("POLLCOMMENT", "Sondaggio");
define("PRINTPAGE", "Stampa");
define("LOGIN", "Logging In");
define("SEARCH", "Modulo ricerca");
define("STATS", "Statistiche Sito");
define("SUBMITNEWS", "Invia News");
define("UPLOAD", "Uploads");
define("USERPAGE", "Profilo utenti");
define("USERSETTINGS", "Impostazione Utenti");
define("ONLINE", "Utenti online");
define("LISTNEW", "Elenco nuove news");
define("USERPOSTS", "Messaggi Utenti");
define("SUBCONTENT", "Invia Contenuto");
define("TOP", "Top Posters/Discussioni pi� attive");
define("ADMINAREA", "Amministrazione");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Elenco Eventi");
define("CALENDAR", "Calendario Eventi");
define("FAQ", "Faq");
define("PM", "Messaggi Privati");
define("SURVEY", "Survey");
define("ARTICLE", "Contenuti");
define("CONTENT", "Contenuto");
define("REVIEW", "Recensione");


?>