<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/03 15:57:25 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Invia email di notifica a");
define("UCSLAN_2", "Privilegi aggiornati");
define("UCSLAN_3", "Ciao");
define("UCSLAN_4", "I tuoi privilegi sono stati aggiornati al");
define("UCSLAN_5", "Da questo momento puoi accedere alla/e seguente/i area/e");
define("UCSLAN_6", "Imposta Gruppo Utente");
define("UCSLAN_7", "Imposta Gruppi");
define("UCSLAN_8", "Notifica Utente");
define("UCSLAN_9", "Gruppi Utenti aggiornati.");
define("UCSLAN_10", "Cordiali saluti");
?>