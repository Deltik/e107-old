<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/09/06 19:34:04 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags aggiornati nel database");
define("METLAN_2", "Inserici meta-tags addizionali");
define("METLAN_3", "Inserisci nuove impostazioni meta tag");
define("METLAN_4", "Aggiornato");
define("METLAN_5", "Scrivi la descrizione qui");
define("METLAN_6", "Scrivi una lista delle tue keywords qui");
define("METLAN_7", "Scrivi le tue informazioni sul copyright qui");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "Descrizione");
define("METLAN_10", "Keywords");
define("METLAN_11", "Copyright");

define("METLAN_12", "Usa il titolo della news e il sommario come meta-descrption sulle nuove pagine.");
define("METLAN_13", "Autore");


?>
