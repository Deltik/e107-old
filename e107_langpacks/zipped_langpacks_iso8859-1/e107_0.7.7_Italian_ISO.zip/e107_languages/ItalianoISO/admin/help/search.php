<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
if (!defined('e107_INIT')) { exit; }

$text = "Se la versione del tuo server MySql lo supporta puoi impostare MySql come Metodo 
di ricerca che � indubbiamente pi� veloce di quello PHP.<br />
Vedi l'opzione Preferenze.<br /><br />";

$ns -> tablerender("Help Ricerca", $text);
?>
