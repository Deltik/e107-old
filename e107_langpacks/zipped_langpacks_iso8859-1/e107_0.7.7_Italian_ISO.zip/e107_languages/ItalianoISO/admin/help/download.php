<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Carica i file nella Directory  ".e_FILE."downloads, le immagini nella Directory ".e_FILE."downloadimages e le Miniature nella Directory ".e_FILE."downloadthumbs.
<br /><br />
Per inviare un download, crea prima una Categoria Principale, poi crea una Sottocategoria. In questo modo renderai disponibile il Download.";
$ns -> tablerender("Help Area Download", $text);
?>
