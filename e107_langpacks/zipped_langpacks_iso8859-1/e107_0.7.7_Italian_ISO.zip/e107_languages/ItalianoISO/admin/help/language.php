<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "L'impostazione di una nuova Lingua ti consentir� di ottenere una versione di tutti i contenuti del tuo sito nella lingua prescelta.";
$ns -> tablerender("Help Lingua del Sito", $text);
?>
