<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Attivando le Faccine (= Emoticons), le stringhe di testo standard per gli 'smiley' saranno 
sostituite  dalle rispettive immagini in tutti i contenuti del sito.";

$ns -> tablerender("Help Emoticon", $text);
?>
