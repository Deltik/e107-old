<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Da questo Pannello puoi gestire i file delle Directory /files. Se ricevi un messaggio 
di Errore circa i permessi di upload, imposta CHMOD 777 per la cartella dove vuoi caricare.";
$ns -> tablerender("File Manager Help", $text);
?>
