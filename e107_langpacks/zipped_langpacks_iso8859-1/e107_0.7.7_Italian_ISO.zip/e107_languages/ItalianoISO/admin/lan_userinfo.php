<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userinfo.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Impossibile trovare l'indirizzo IP immesso - nessuna informazione disponibile.");
//define("USFLAN_2", "Errore");
define("USFLAN_3", "Messaggi provenienti dall'indirizzo IP");
define("USFLAN_4", "Host");
define("USFLAN_5", "Clicca qui per inserire indirizzo IP nella Pagina dei banner.");
define("USFLAN_6", "ID Utente");
define("USFLAN_7", "Informazioni Utente");
?>