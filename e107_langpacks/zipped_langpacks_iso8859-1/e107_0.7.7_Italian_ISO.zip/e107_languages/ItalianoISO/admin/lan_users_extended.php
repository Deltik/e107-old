<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_users_extended.php,v $
|     $Revision: 1.14 $
|     $Date: 2006/01/15 01:08:04 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/
define("EXTLAN_1", "Nome");
define("EXTLAN_2", "Anteprima");
define("EXTLAN_3", "Valori");
define("EXTLAN_4", "Richiesto");
define("EXTLAN_5", "Applicabile");
define("EXTLAN_6", "Leggi accesso");
define("EXTLAN_7", "Scrivi accesso");
define("EXTLAN_8", "Azione");
define("EXTLAN_9", "Campi Completi Utente");
define("EXTLAN_10", "Campo nome");
define("EXTLAN_11", "Questo � il nome del campo registrato nella tabella, deve essere diverso dagli altri");
define("EXTLAN_12", "Campo testo");
define("EXTLAN_13", "Questo � il nome del campo che verr� visualizzato nelle pagine");
define("EXTLAN_14", "Campo type");
define("EXTLAN_15", "Campo Includi Testo'");
define("EXTLAN_16", "Valore di Default");
define("EXTLAN_17", "Inserisci un valore per riga <br /> Per tabella DB vedi Help.");
define("EXTLAN_18", "Richiesto");
define("EXTLAN_19", "All'utente sar� richiesto di inserire un valore in questo campo quando aggiorner� le impostazioni.");
define("EXTLAN_20", "Determina a quali Utenti verr� applicato il campo.");
define("EXTLAN_21", "Questo determiner� chi potr� visualizzare il campo nel proprio Profilo Utente.");
define("EXTLAN_22", "Questo determiner� chi potr� visualizzare il valore nel proprio Profilo Utente <br />NOTA: Impostando permessi di sola Lettura sar� visualizzato solo dall'Amministratore e dagli Utenti.");
define("EXTLAN_23", "Inserisci Campi Completi");
define("EXTLAN_24", "Aggiorna Campi Completi");
define("EXTLAN_25", "sposta gi�");
define("EXTLAN_26", "sposta su");
define("EXTLAN_27", "Conferma cancellazione");
define("EXTLAN_28", "Nessun Campo Completo definito");
define("EXTLAN_29", "Campi Completi Utente salvati.");
define("EXTLAN_30", "Campi Completi Utente cancellati.");
define("EXTLAN_33", "Cancella Modifica");
define("EXTLAN_34", "Campi Completi");
define("EXTLAN_35", "Categorie");
define("EXTLAN_36", "Nessuna Categoria assegnata");
define("EXTLAN_37", "Nessuna Categoria definita");
define("EXTLAN_38", "Nome Categoria");
define("EXTLAN_39", "Inserisci categoria");
define("EXTLAN_40", "Categoria creata");
define("EXTLAN_41", "Categoria cancellata");
define("EXTLAN_42", "Aggiorna Categoria");
define("EXTLAN_43", "Categoria aggiornata");
define("EXTLAN_44", "Categoria");
define("EXTLAN_45", "Inserisci nuovo Campo");
define("EXTLAN_46", "Help");
define("EXTLAN_47", "Inserisci nuovo parametro");
define("EXTLAN_48", "Inserisci nuovo valore");
define("EXTLAN_49", "Consenti all'Utente di nascondere");
define("EXTLAN_50", "Impostando SI consentirai che l'Utente possa nascondere questo valore ai non-Amministratori.");
define("EXTLAN_51", "Qualunque parametro validato w3c pu� essere inserito qui<br />Es. <i><b>class='tbox' size='40' maxlength='80'</i></b>");
define("EXTLAN_52", "Codice di Validazione regex");
define("EXTLAN_53", "Inserisci il Codice regex necessario per effettuare un inserimento valido <br />**delimitatori regex sono richiesti**");
define("EXTLAN_54", "Messaggio errore regex");
define("EXTLAN_55", "Inserisci il messaggio di errore che verr� visualizzato qualora la validazione Regex abbia esito negativo.");
define("EXTLAN_56", "Campi Predefiniti");
define("EXTLAN_57", "Attivo");
define("EXTLAN_58", "Non attivo");
define("EXTLAN_59", "Attiva");
define("EXTLAN_60", "Disattiva");
define("EXTLAN_61", "Nessuno");
define("EXTLAN_62", "Tabella");
define("EXTLAN_63", "ID campo");
define("EXTLAN_64", "Mostra valore");
define("EXTLAN_65", "No - non sar� visualizzato in registrazione");
define("EXTLAN_66", "Yes - sar� visualizzato in amministrazione");
define("EXTLAN_67", "No - visualizza in registrazione");
define("EXTLAN_68", "Campo:");
define("EXTLAN_69", "� stato attivato");
define("EXTLAN_70", "ERRORE: campo:");
define("EXTLAN_71", "non � stato attivato");
define("EXTLAN_72", "� stato disattivato");
define("EXTLAN_73", "non � stato disattivato");
define("EXTLAN_74", "campo riservato e non pu� essere usato");
define("EXTLAN_HELP_1", "<b><i>Parametri:</i></b><br />size - formato campo<br />maxlength - lunghezza max campo<br /><br />class - class.css del campo<br />style - stringa style.css<br /><br />regex - Codice di validazione Regex<br />regexfail - Messaggio errore Regex");
define("EXTLAN_HELP_2", "Testo di Help per radio buttons");
define("EXTLAN_HELP_3", "Testo di Help per dropdownt");
define("EXTLAN_HELP_4", "<b><i>Valori:</i></b><br />Devono SEMPRE essere inseriti tre valori:<br /><ol><li>dbtable</li><li>campo contenente l'id</li><li>campo contenente il valore</li></ol><br />");
define("EXTLAN_HELP_5", "Testo di Help per Textarea");
define("EXTLAN_HELP_6", "Testo di Help per Integer");
define("EXTLAN_HELP_7", "Testo di Help per date");


?>