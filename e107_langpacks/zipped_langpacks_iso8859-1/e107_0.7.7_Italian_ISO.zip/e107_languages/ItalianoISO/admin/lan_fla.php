<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_fla.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/17 07:51:40 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("FLALAN_1", "Tentativi di connessione falliti");
define("FLALAN_2", "Nessun tentativo di connessione fallito � stato registrato");
define("FLALAN_3", "Tentativi cancellati");
define("FLALAN_4", "Utente ha cercato di connettersi usando Nome utente/Password inesatti");
define("FLALAN_5", "IP(s) bannati");
define("FLALAN_6", "Data");
define("FLALAN_7", "Dati");
define("FLALAN_8", "IP address/ Host");
define("FLALAN_9", "Opzioni");
define("FLALAN_10", "Cancella / Banna ingressi selezionati");
define("FLALAN_11", "seleziona tutte le caselle 'cancella'");
define("FLALAN_12", "deseleziona tutte le caselle 'cancella'");
define("FLALAN_13", "seleziona tutte le caselle 'banna'");
define("FLALAN_14", "deseleziona tutte le caselle 'banna'");
define("FLALAN_15", "I seguenti indirizzi IP sono stati auto-bannati - pi� di dieci tentativi falliti di login");
define("FLALAN_16", "cancella questa lista di auto-bannati");
define("FLALAN_17", "Lista di auto-bannati cancellata");

?>
