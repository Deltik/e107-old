<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Impostazioni di Manutenzione aggiornate");
define("UGFLAN_2", "Attiva flag di Manutenzione");
define("UGFLAN_3", "Aggiorna impostazioni Manutenzione");
define("UGFLAN_4", "Impostazioni di Manutenzione");
define("UGFLAN_5", "Testo da visualizzare quando il sito � in Manutenzione");
define("UGFLAN_6", "Lascia vuoto per visualizzare Messaggio di default");
?>