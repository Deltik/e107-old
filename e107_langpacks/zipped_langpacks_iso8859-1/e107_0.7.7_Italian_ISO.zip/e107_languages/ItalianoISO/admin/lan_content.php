<?php

define("CNTLAN_1", "Campi non completi.");
define("CNTLAN_2", "Contenuto aggiornato nel database.");
define("CNTLAN_3", "Spunta il box di conferma per elinare questa pagina");
define("CNTLAN_4", "Ancora nessun contentuo.");
define("CNTLAN_5", "Contenuti Esistenti");
define("CNTLAN_6", "Edita");
define("CNTLAN_7", "Elimina");
define("CNTLAN_8", "spunta per confermare");
define("CNTLAN_9", "Apri l'editor HTML");
define("CNTLAN_10", "Nome Link");
define("CNTLAN_11", "Intestazione Pagina");
define("CNTLAN_12", "Contenuti");
define("CNTLAN_13", "Permetti commenti");
define("CNTLAN_14", "On");
define("CNTLAN_15", "Off");
define("CNTLAN_16", "Aggiorna Contenuto");
define("CNTLAN_17", "Crea Contenuto");
define("CNTLAN_18", "Contenuti");
define("CNTLAN_19", "Visibile a");
define("CNTLAN_20", "Contenuto Eliminato.");
define("CNTLAN_21", "Interruzione automatica riga");
define("CNTLAN_22", "( se stai immettendo codice HTML imposta questo su Off )");

define("CNTLAN_23", "Contenuto aggiunto senza link - per linkare a questo contenuto usa questo url");
define("CNTLAN_24", "Contenuto aggiunto e link creato nel Mainmen�");

define("CNTLAN_25", "Titolo");
define("CNTLAN_26", "Opzioni");
define("CNTLAN_27", "Sei sicuro di voler eliminare questo contentuto?");

//v.617

define("CNTLAN_28", "Aggiungi icone email/stampa?");
define("CNTLAN_29", "S�");
define("CNTLAN_30", "No");

?>