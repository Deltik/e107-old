<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Upload");

define("LAN_20", "Errore");
define("LAN_61", "Il tuo nome: ");
define("LAN_112", "Indirizzo Email: ");
define("LAN_144", "URL Sito web: ");
define("LAN_402", "Devi essere un tente registrato per caricare i file sul server.");
define("LAN_403", "Non hai i permessi coretti per caricare i file su questo server.");
define("LAN_404", "Grazie. Il tuo allegato sar� esaminato da un amministratore e quindi approvato se ritenuto idoneo al sito.");
define("LAN_405", "Il file eccede i limiti massimi consentiti. Eliminato.");
define("LAN_406", "Attento");
define("LAN_407", "ogni altra estensione caricata sar� automaticamente eliminata.");
define("LAN_408", "Sottolineato");
define("LAN_409", "Nome del file");
define("LAN_410", "Versione");
define("LAN_411", "File");
define("LAN_412", "Miniatura");
define("LAN_413", "Descrizione");
define("LAN_414", "Demo funzionante");
define("LAN_415", "inserisci l'indirizzo web del sito dove � possibile vedere in funzione la demo");
define("LAN_416", "Invia e carica");
define("LAN_417", "Caricamento File");
define("LAN_418", "Massime dimensioni File: ");
define("DOWLAN_11", "Categoria");
define("LAN_419", "Estensioni ammesse");
define("LAN_420", "i campi sono richiesti.");

?>
