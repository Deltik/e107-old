<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: mrpete $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Stampa Veloce"); }

define("LAN_PRINT_86", "Categoria:");
define("LAN_PRINT_87", "da ");
define("LAN_PRINT_94", "Inviato da");
define("LAN_PRINT_135", "News: ");
define("LAN_PRINT_303", "Questa news proviene da ");
define("LAN_PRINT_304", "Titolo: ");
define("LAN_PRINT_305", "Sottotitolo: ");
define("LAN_PRINT_306", "Questa news proviene da ");
define("LAN_PRINT_307", "Stampa questa pagina");

define("LAN_PRINT_1", "stampa friendly");
?>