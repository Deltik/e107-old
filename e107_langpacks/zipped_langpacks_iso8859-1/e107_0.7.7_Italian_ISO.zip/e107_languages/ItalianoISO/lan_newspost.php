<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "News cancellata.");
define("NWSLAN_2", "Spunta il box di conferma per eliminare questa news.");
define("NWSLAN_3", "Nessuna news in archivio.");
define("NWSLAN_4", "News esistente");
define("NWSLAN_5", "Apri Editor HTML");
define("NWSLAN_6", "Categoria");
define("NWSLAN_7", "Edita");
define("NWSLAN_8", "Cancella");
define("NWSLAN_9", "Spunta per confermare");
define("NWSLAN_10", "Nessuna categoria selezionata.");
define("NWSLAN_11", "Aggiungi/Edita Categorie");
define("NWSLAN_12", "Titolo");
define("NWSLAN_13", "Testo");
define("NWSLAN_14", "Testo esteso");
define("NWSLAN_15", "Commenti");
define("NWSLAN_16", "Abilitati");
define("NWSLAN_17", "Non abilitati");
define("NWSLAN_18", "Consenti invio commenti a questa news.");
define("NWSLAN_19", "Attivazione");
define("NWSLAN_20", "Lascia vuoto per disabilitare auto-attivazione.");
define("NWSLAN_21", "Attiva tra");
define("NWSLAN_22", "Visibilit�");
define("NWSLAN_23", "Seleziona per consentire la visulaizzazione ad uno o pi� gruppi di utenti.");
define("NWSLAN_24", "Nuova Anteprima");
define("NWSLAN_25", "Aggiorna");
define("NWSLAN_26", "Pubblica");
define("NWSLAN_27", "Anteprima");
define("NWSLAN_28", "Nuova News");
define("NWSLAN_29", "News Post");

define("NWSLAN_30", "Mostra solo titolo");

?>
