<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/28 23:02:59 $
|     $Author: whoisrich $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Lista pagine non abilitata");
define("LAN_PAGE_2", "Non ci sono pagine");
define("LAN_PAGE_3", "La pagina richiesta non esiste");
define("LAN_PAGE_4", "Valuta questa pagine");
define("LAN_PAGE_5", "Grazie per aver valutato questa pagina");
define("LAN_PAGE_6", "Non hai i permessi pere vedere questa pagina");
define("LAN_PAGE_7", "Password Incorretta");
define("LAN_PAGE_8", "Pagina protetta da password");
define("LAN_PAGE_9", "Password");
define("LAN_PAGE_10", "Invia");
define("LAN_PAGE_11", "Lista Pagine");

define("LAN_PAGE_12", "Pagina invalida");
define("LAN_PAGE_13", "Pagina");


?>
