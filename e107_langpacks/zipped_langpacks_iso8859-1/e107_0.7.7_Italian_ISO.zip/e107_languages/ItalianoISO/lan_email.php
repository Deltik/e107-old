<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/07 19:06:54 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Email");}
define("LAN_EMAIL_1", "Da:");
define("LAN_EMAIL_2", "Indirizzo IP dell'inviante:");
define("LAN_EMAIL_3", "Oggetto inviato da ");
define("LAN_EMAIL_4", "Invia Email");
define("LAN_EMAIL_5", "Invia oggetto a un amico");
define("LAN_EMAIL_6", "Se pesni di essere interessato in questo oggetta da");
define("LAN_EMAIL_7", "Invia mail a un amico");
define("LAN_EMAIL_8", "Commento");
define("LAN_EMAIL_9", "Spiacente - impossibile inviare la mail");
define("LAN_EMAIL_10", "Mail inviata a");
define("LAN_EMAIL_11", "Email inviata");
define("LAN_EMAIL_12", "Errore");
define("LAN_EMAIL_13", "Invia l'articolo a  un amico");
define("LAN_EMAIL_14", "Invia la  news a un amico");
define("LAN_EMAIL_15", "Nome di Login: ");
define("LAN_EMAIL_106", "Questo non sembra essere un valido indirizzo e mail");
define("LAN_EMAIL_185", "Invia articolo");
define("LAN_EMAIL_186", "Invia News");
define("LAN_EMAIL_187", "Indirizzo e mail a cui inviare");
define("LAN_EMAIL_188", "Penso tu possa essere interessato a questa news da");
define("LAN_EMAIL_189", "Penso tu possa essere interessato a questo articolo da:");
define("LAN_EMAIL_190", "Inserisci il codice visualizzato");


?>