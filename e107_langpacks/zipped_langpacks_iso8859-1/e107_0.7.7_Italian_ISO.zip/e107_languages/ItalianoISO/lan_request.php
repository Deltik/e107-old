<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/09 15:38:12 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Errore di Download");
define("LAN_dl_62", "Non ti � consentito prelevare questo file, hai superato il limite consentito per il download");
define("LAN_dl_63", "Non ti � consentito prelevare questo file.");
define("LAN_dl_64", "Torna indietro");
define("LAN_dl_65", "File non trovato");

?>
