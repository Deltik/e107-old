<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_submitnews.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Enviar Noticia");

define("LAN_7", "Usuario: ");

define("LAN_62", "Asunto: ");

define("LAN_112", "Email: ");

define("LAN_133", "Gracias");
define("LAN_134", "Su envio ha sido realizado. Ser� revisado por uno de los administradores del sitio.");
define("LAN_135", "Noticia: ");
define("LAN_136", "Enviar Noticia");

define("NWSLAN_6", "Categor�a");
define("NWSLAN_10", "No hay categorias");
define("NWSLAN_11", "No tiene acceso a este �rea.");
define("NWSLAN_12", "Acceso denegado.");

define("SUBNEWSLAN_1", "Debe incluir un t�tulo.\\n");
define("SUBNEWSLAN_2", "Debe incluir alg�n texto en la noticia.\\n");
define("SUBNEWSLAN_3", "El archivo adjunto debe ser jpg, gif � png");
define("SUBNEWSLAN_4", "Archivo demasiado grande");
define("SUBNEWSLAN_5", "Imagen");
define("SUBNEWSLAN_6", "(jpg, gif � png)");
?>