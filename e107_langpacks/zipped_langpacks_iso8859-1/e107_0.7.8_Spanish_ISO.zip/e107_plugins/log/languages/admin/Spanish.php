<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/log/languages/admin/Spanish.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("ADSTAT_ON", "On");
define("ADSTAT_OFF", "Off");
define("ADSTAT_L1", "Este plugin registrar� todas las visitas de su p�gina, y crear� varias pantallas con la informaci�n recibida.");
define("ADSTAT_L2", "El registro de estad�sticas se ha instalado con �xito. Para activar, vaya a la pantalla de configuraci�n de estad�stics y pulse 'Activar'.<br /><b>Debe fijar los permisos a la carpeta e107_plugins/log/logs a 777 (chmod 777)</b>");
define("ADSTAT_L3", "Log de estad�sticas");
define("ADSTAT_L4", "Activar monitor de estad�sticas");
define("ADSTAT_L5", "Tipos de estad�sticas");
define("ADSTAT_L6", "Navegadores");
define("ADSTAT_L7", "Sistemas operativos");
define("ADSTAT_L8", "Resoluci�n y colores de pantalla");
define("ADSTAT_L9", "Paises de or�gen");
define("ADSTAT_L10", "Referidos");
define("ADSTAT_L11", "Buscar consultas");
define("ADSTAT_L12", "Resetear estad�sticas");
define("ADSTAT_L13", "Esto borrar� las estadisticas - �Cuidado!");
define("ADSTAT_L14", "Cantidad de p�ginas");
define("ADSTAT_L15", "Actualizar ajustes de estad�sticas");
define("ADSTAT_L16", "Ajustes de estad�sticas del sitio");
define("ADSTAT_L17", "Ajustes de estad�sticas actualizado");
define("ADSTAT_L18", "Permitir acceder a la p�gina de estad�sticas principales ...");
define("ADSTAT_L19", "Visitantes recientes");
define("ADSTAT_L20", "Cantidad de visitas del Admin");
define("ADSTAT_L21", "M�x registros a mostrar en la p�gina de estad�sticas");
define("ADSTAT_L22", "Ejecutar rutina de actualizaci�n");
define("ADSTAT_L23", "Se han detectado registros de versiones previas a e107, actualicelas aqu�");
define("ADSTAT_L24", "Ir al script de actualizaci�n");
define("ADSTAT_L25", "Estad�sticas seleccionadas Reseteadas");
define("ADSTAT_L26", "Eliminar entradas de p�ginas");
define("ADSTAT_L27", "Si sus estad�sticas tiene p�ginas incorrectas, puede eliminarlas desde aqu�");
define("ADSTAT_L28", "Abrir p�gina");
define("ADSTAT_L29", "Nombre de p�gina");
define("ADSTAT_L30", "Activa para eliminar");
define("ADSTAT_L31", "Eliminar las p�ginas seleccionadas");
define("ADSTAT_L32", "P�gina ordenada");
define("ADSTAT_L33", "Configurar estad�sticas de conexi�n");
?>