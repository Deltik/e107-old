<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/online_extended_menu/languages/Spanish.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/01/10 18:26:28 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Invitados: ");
define("ONLINE_EL2", "Miembros: ");
define("ONLINE_EL3", "en esta p�gina: ");
define("ONLINE_EL4", "En linea");
define("ONLINE_EL5", "Miembros");
define("ONLINE_EL6", "�ltimo miembro");
define("ONLINE_EL7", "viendo");
define("ONLINE_EL8", "M�ximo de visitas ");
define("ONLINE_EL9", "el");

define("ONLINE_TRACKING_MESSAGE", "El tracking del usuario conectado est� desactivado, por favor act�velo [link=".e_ADMIN."users.php?options]aqu�[/link][br]");
?>