<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_parser_functions.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/29 12:57:43 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Invitado");
define("LAN_WROTE", "escribió"); // as in John wrote.."  ";
?>