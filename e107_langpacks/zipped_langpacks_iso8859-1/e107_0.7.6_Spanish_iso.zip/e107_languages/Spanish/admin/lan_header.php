<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_header.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Men� Admin.");
define("LAN_head_2", "Su servidor no admite la transferencia de archivos via HTTP, los usuarios no podr�n transferir sus avatares/archivos etc. Para corregir esto cambie file_uploads a On en su php.ini y reinicie el servidor. Si usted no tiene acceso al servidor p�ngase en contacto con su proovedor de hosting.");
define("LAN_head_3", "Su servidor est� ejecutando una restricci�n en el directorio principal. Esto no permitir� el uso de algunos archivos fuera de su carpeta principal y afectar� a determinados Scripts como el gestor de ficheros.");
define("LAN_head_4", "Area Admin.");
define("LAN_head_5", "Idioma mostrado en el �rea del Admin: ");
define("LAN_head_6", "Info de plugins");
?>