<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_db.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/12 17:23:20 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Configuraci�n del nucleo guardada con backup en la base de datos.");
define("DBLAN_2", "Backup BD");
define("DBLAN_3", "Hacer Backup de base de datos SQL");
define("DBLAN_4", "Chequear validaci�n");
define("DBLAN_5", "Chequear validaci�n de la base de datos");
define("DBLAN_6", "Optimizar BD");
define("DBLAN_7", "Optimizar base de datos SQL");
define("DBLAN_8", "Backup del N�cleo");
define("DBLAN_9", "Hacer Backup de n�cleo");
define("DBLAN_10", "Utilidades de la base de datos");
define("DBLAN_11", "Base de datos MySQL");
define("DBLAN_12", "Optimizada");
define("DBLAN_13", "Volver");
define("DBLAN_14", "Hecho");
define("DBLAN_15", "Ver actualizaciones disponibles");
define("DBLAN_16", "Buscar actualizaciones");
define("DBLAN_17", "Pref. Nombre"); 
define("DBLAN_18", "Pref. Valor"); 
define("DBLAN_19", "Haga click en el bot�n para abrir las preferencias del editor (solo ususarios avanzados)"); 
define("DBLAN_20", "Preferencias Editor"); 
define("DBLAN_21", "Eliminar marcados"); 
?>