<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_lancheck.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/29 12:57:43 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Verificar archivos de idioma"); // modified in 0.7.6
define("LAN_CHECK_2", "Verificar");
define("LAN_CHECK_3", "Verificaci�n de");
define("LAN_CHECK_4", "�Archivo perdido!");
define("LAN_CHECK_5", "�Frase perdida!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "Frase");
define("LAN_CHECK_8", "Falta un archivo...");
define("LAN_CHECK_9", " Faltan archivos...");
define("LAN_CHECK_10", "Error cr�tico: ");
define("LAN_CHECK_11", "�No falta/n archivo/s !");
define("LAN_CHECK_12", "Un archivo est� mal...");
define("LAN_CHECK_13", " Los archivos est�n mal...");
define("LAN_CHECK_14", "�Todos los archivos son v�lidos!");
?>