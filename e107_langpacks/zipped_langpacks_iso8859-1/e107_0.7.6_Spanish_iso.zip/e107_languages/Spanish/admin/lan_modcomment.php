<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_modcomment.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderado.");
define("MDCLAN_2", "No hay comentarios");
define("MDCLAN_3", "Miembro");
define("MDCLAN_4", "Invitado");
define("MDCLAN_5", "Desbloquear");
define("MDCLAN_6", "Bloquear");

define("MDCLAN_8", "Moderar comentarios");
define("MDCLAN_9", "�Cuidado! Borrando el comentario ra�z borrar� todas sus respuestas!");
define("MDCLAN_10", "Opciones");
define("MDCLAN_11", "Comentario");
define("MDCLAN_12", "Comentarios");
define("MDCLAN_13", "Bloqueado");
define("MDCLAN_14", "Bloquear comentarios");
define("MDCLAN_15", "Abiertos");
define("MDCLAN_16", "Cerrados");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");
?>