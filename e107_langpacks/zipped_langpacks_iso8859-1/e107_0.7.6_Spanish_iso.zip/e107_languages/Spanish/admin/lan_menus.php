<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_menus.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/25 19:38:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Visible para todos");
define("MENLAN_2", "Visible solo para miembros");
define("MENLAN_3", "Visible solo para administradores");
define("MENLAN_4", "Solo visible para clase");
//define("MENLAN_5", "");
define("MENLAN_6", "Actualizar clase para el men�");
define("MENLAN_7", "Configuraci�n de clase para");
define("MENLAN_8", "Clases actualizadas");
define("MENLAN_9", "Nuevo men� de cliente instalado");
define("MENLAN_10", "Nuevo men� instalado");
define("MENLAN_11", "Men� retirado");
define("MENLAN_12", "Activar este men�");
define("MENLAN_13", "Activar en �rea");
define("MENLAN_14", "�rea");
define("MENLAN_15", "Desactivar");
define("MENLAN_16", "Configurar");
define("MENLAN_17", "Mover arriba");
define("MENLAN_18", "Mover abajo");
define("MENLAN_19", "Mover al �rea");
define("MENLAN_20", "Visible");
//define("MENLAN_21", "Visible solo para Visitas");
define("MENLAN_22", "Men�s inactivos");
define("MENLAN_23", "Mover al �ltimo");
define("MENLAN_24", "Mover al primero");
define("MENLAN_25", "Funci�n ...");
define("MENLAN_26", "Este men� solo se <strong>MOSTRAR�</strong> en las siguientes p�ginas");
define("MENLAN_27", "Este men� solo se <strong>OCULTAR�</strong> en las siguientes p�ginas");
define("MENLAN_28", "Escriba una p�gina por l�nea, escriba la URL completa para identificarla");
define("MENLAN_29", "Seleccionar plantilla");
define("MENLAN_30", "Para ver �reas de men� y sus posiciones en las plantillas personalizadas, seleccione su plantilla personalizada aqu�:");
define("MENLAN_31", "Plantilla predeterminada");
define("MENLAN_32", "Plantilla cabecera de noticias");
define("MENLAN_33", "Plantilla personalizada");
define("MENLAN_34", "Integrado");
define("MENLAN_35", "Configurar Men�s");
define("MENLAN_36", "Escoja el/los men�/s a activar");
define("MENLAN_37", "y donde activarlos.");
define("MENLAN_38", "Mantenga la tecla CRTL para seleccionar m�ltiples men�s.");
?>