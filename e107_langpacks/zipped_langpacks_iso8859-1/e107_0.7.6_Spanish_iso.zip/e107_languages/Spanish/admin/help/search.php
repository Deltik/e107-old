<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/search.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/16 23:45:35 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Si su versi�n de servidor MySQL lo soporta usted puede cambiar m�todo corto de MySql  que es m�s r�pido que el m�todo corto de PHP.<br />Ver Preferencias<br />Si su sitio incluye idiomas ideogr�ficos como el Chino o Japon�s debe usar el m�todo corto de PHP y desactivar la coincidencia total de la palabra.";
$ns -> tablerender("Ayuda b�squedas", $text);
?>