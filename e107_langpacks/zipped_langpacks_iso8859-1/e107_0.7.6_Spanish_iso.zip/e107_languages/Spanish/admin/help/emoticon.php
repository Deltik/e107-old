<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/emoticon.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Con los emoticonos activados, los s�mbolos de texto se reemplazar�n por emoticonos a trav�s de su sitio de contenidos.";

$ns -> tablerender("Ayuda Emoticon", $text);
?>