<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/wmessage.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Esta p�gina le permite configurar un mensaje que aparecer� al principio de su p�gina inicial todo el tiempo que est� activada.
Puede configurar un mensaje diferente para invitados, miembros registrados/con sesi�n iniciada o administradores.";
$ns -> tablerender("Ayuda Mensaje de bienvenida", $text);
?>