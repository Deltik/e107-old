<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_filemanager.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "Actualizado");
define("FMLAN_2", "A");
define("FMLAN_3", "Directorio");
define("FMLAN_4", "El fichero transferido excede el m�ximo tama�o permitido en php.ini.");
//define("FMLAN_5", "El fichero transferido excede el m�ximo tama�o permitido especificado en el formulario html.");
//define("FMLAN_6", "El fichero transferido fu� transferido parcialmente.");
//define("FMLAN_7", "El fichero no fu� transferido.");
//define("FMLAN_8", "Tama�o del fichero transferido 0 bytes");
//define("FMLAN_9", "El fichero no se pudo transferir. Nombre del fichero");
//define("FMLAN_10", "Error");
//define("FMLAN_11", "Probablemente los permisos del directorio a transferir son incorrectos.");
define("FMLAN_12", "Fichero");
define("FMLAN_13", "Ficheros");
define("FMLAN_14", "Directorio");
define("FMLAN_15", "Directorios");
define("FMLAN_16", "Directorio ra�z");
define("FMLAN_17", "Nombre");
define("FMLAN_18", "Tama�o");
define("FMLAN_19", "�ltima modificaci�n");

define("FMLAN_21", "Transferir fichero a este directorio");
define("FMLAN_22", "Transferir");

define("FMLAN_26", "Borrado");
define("FMLAN_27", "Completado");
define("FMLAN_28", "No se pudo borrar");
define("FMLAN_29", "Ruta");
define("FMLAN_30", "Transferir");
define("FMLAN_31", "Carpeta");
define("FMLAN_32", "Seleccione Directorio");
define("FMLAN_33", "Seleccionar");
define("FMLAN_34", "Elegir directorio");
define("FMLAN_35", "Directorio Files");
define("FMLAN_36", "Directorio Custom");
define("FMLAN_37", "Directorio CustomPages");
define("FMLAN_38", "Archivo/s movido/s con �xito a");
define("FMLAN_39", "Imposible mover el/los archivo/s a");
define("FMLAN_40", "Directorio Newspost-Images");

define("FMLAN_43", "Eliminar archivos seleccionados");

define("FMLAN_46", "Confirme que desea ELIMINAR los archivos seleccionados.");
define("FMLAN_47", "Transferencias de usuario");
define("FMLAN_48", "Mover los seleccionados a");
define("FMLAN_49", "Por favor, confirme que desea mover los archivos seleccionados.");
define("FMLAN_50", "Mover");
?>