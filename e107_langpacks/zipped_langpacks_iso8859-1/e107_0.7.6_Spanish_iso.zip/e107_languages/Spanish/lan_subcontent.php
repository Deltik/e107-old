<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_subcontent.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "Gracias, su art�culo ha sido guardado y ser� revisado por un administrador.");
define("ARLAN_1", "Ha dejado campos en blanco.");
define("ARLAN_2", "Gracias, su revisi�n ha sido guardado y ser� revisado por un administrador.");

define("ARLAN_15", "Enviar art�culo");

define("ARLAN_17", "Titular");
define("ARLAN_18", "Sub-Titular");
define("ARLAN_19", "Resumen");
define("ARLAN_20", "Art�culo");
define("ARLAN_21", "�Permitir comentarios?");
define("ARLAN_22", "Si");
define("ARLAN_23", "No");
define("ARLAN_24", "�A�adir iconos email/impresora?");
define("ARLAN_25", "Si");
define("ARLAN_26", "No");
define("ARLAN_27", "Enviar art�culo");
define("ARLAN_28", "Previsualizar");

define("ARLAN_55", "Visible para");

define("ARLAN_73", "Abrir editor HTML");
define("ARLAN_74", "Categor�a");
define("ARLAN_75", "Nada");

define("ARLAN_82", "Autor");
define("ARLAN_84", "Nombre");
define("ARLAN_85", "Email");
define("ARLAN_86", "Revisi�n");
define("ARLAN_87", "Puntuaci�n");
define("ARLAN_88", "Punt�e");
define("ARLAN_89", "Enviar revisi�n");
define("ARLAN_90", "Ha dejado campos en blanco, por favor vuelva a la p�gina anterior y verifique que ha rellenado todos los campos.");
define("ARLAN_91", "Previsualizar");
define("ARLAN_92", "Por favor escriba su nombre y direcci�n email");
define("ARLAN_93", "Art�culo");
define("ARLAN_94", "Revisi�n");
define("ARLAN_95", "El envio de art�culos est� desactivado");
define("ARLAN_96", "El envio de revisiones est� desactivado");
define("ARLAN_97", "No tiene privilegios para enviar art�culos");
define("ARLAN_98", "No tiene privilegios para enviar revisiones");
define("ARLAN_99", "Insertar imagen: Transferir im�genes a images/articles");
define("ARLAN_100", "Insertar imagen: Transferir im�genes a images/review");
define("ARLAN_101", "Transferir una imagen para usar en este art�culo");
define("ARLAN_102", "Transferir una imagen para usar en esta revisi�n");
define("ARLAN_103", "<b>La carpeta images/articles no tiene permisos de escritura<br />");
define("ARLAN_104", "<b>La carpeta images/review no tiene permisos de escritura<br />");
define("ARLAN_105", "Insertar imagen ...");
define("ARLAN_106", "Transferir");

?>