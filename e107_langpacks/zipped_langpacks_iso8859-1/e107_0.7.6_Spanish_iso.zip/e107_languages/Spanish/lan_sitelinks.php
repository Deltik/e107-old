<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_sitelinks.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/17 10:47:08 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Men� Principal");
define("LAN_SITELINKS_502", "Administraci�n");
?>