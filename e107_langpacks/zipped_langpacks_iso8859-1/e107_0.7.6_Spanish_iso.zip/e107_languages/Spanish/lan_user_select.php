<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/10 10:16:39 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Selecciona usuario");
define("US_LAN_2", "Seleccionar clase de usuario");
define("US_LAN_3", "Todos los usuarios");
define("US_LAN_4", "Buscar usuario");
define("US_LAN_5", "Usuaio(s) encontrado(s)");
define("US_LAN_6", "Buscar");
?>