<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_equery_secure.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Esta siendo redirigido a una funci�n de Administraci�n, posiblemente hay modificaciones de la base de datos");
define("EQSEC_LAN2", "Por favor, confirme esta acci�n:");
define("EQSEC_LAN3", "Sin referir");
define("EQSEC_LAN4", "Acci�n desde:");
define("EQSEC_LAN5", "Acci�n para:");
define("EQSEC_LAN6", "Confirmar acci�n");
define("EQSEC_LAN7", "O cancelar");
?>