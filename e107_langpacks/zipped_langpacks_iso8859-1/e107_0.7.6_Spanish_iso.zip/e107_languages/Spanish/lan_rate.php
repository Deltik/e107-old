<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_rate.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("RATELAN_0", "Voto");
define("RATELAN_1", "Votos");
define("RATELAN_2", "�Como valora este elemento?");
define("RATELAN_3", "Gracias por su voto");
define("RATELAN_4", "Sin valorar");
define("RATELAN_5", "Valorar");
?>