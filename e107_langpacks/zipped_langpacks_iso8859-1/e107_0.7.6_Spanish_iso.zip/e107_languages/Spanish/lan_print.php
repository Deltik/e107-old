<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_print.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/29 12:57:43 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Vista de impresi�n"); }

define("LAN_PRINT_86", "Categor�a:");
define("LAN_PRINT_87", "por ");

define("LAN_PRINT_94", "Enviada por");

define("LAN_PRINT_135", "Noticias: ");

define("LAN_PRINT_303", "Esta noticia proviene de ");
define("LAN_PRINT_304", "T�tulo del art�culo: ");
define("LAN_PRINT_305", "Encabezado: ");
define("LAN_PRINT_306", "Este art�culo es de ");
define("LAN_PRINT_307", "Imprimir esta p�gina");

define("LAN_PRINT_1", "modo impresi�n");
?>