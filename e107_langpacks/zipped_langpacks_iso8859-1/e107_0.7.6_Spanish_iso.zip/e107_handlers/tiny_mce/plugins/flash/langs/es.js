/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_handlers/tiny_mce/plugins/flash/langs/es.js,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('flash',{
title : 'Insertar / editar Flash',
desc : 'Insertar / editar Flash',
file : 'Archivo (.swf)',
size : 'Tama�o',
list : 'Archivos',
props : 'Propiedades',
general : 'General'
});
