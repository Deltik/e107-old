<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/featurebox/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("FBLAN_01","Caja de Caracter�sticas");
define("FBLAN_02","Este plugin le permite mostrar una caja encima de sus noticias con ciertas caracter�sticas. Los mensajes pueden girar aleatoriamente o apagarse din�micamente.");
define("FBLAN_03","Configurar la caja de caracter�sticas");
define("FBLAN_04","El plugin se ha instalado con �xito. Para a�adir mensajes y configurarlos vaya a la p�gina del administrador y haga click en 'caja de caracter�sticas' de la secci�n de plugins.");
define("FBLAN_05","No hay mensajes en la caja de caracter�sticas");
define("FBLAN_06","Mensajes de la caja de caracter�sticas");
define("FBLAN_07","T�tulo");
define("FBLAN_08","Texto del mensaje");
define("FBLAN_09","Visibilidad del mensaje");
define("FBLAN_10","Crear mensaje en caja de caracter�sticas");
define("FBLAN_11","Actualizar mensaje en caja de caracter�sticas");
define("FBLAN_12","Modo");
define("FBLAN_13","Girar mensajes aleatoriamente");
define("FBLAN_14","Mostrar solo este mensaje");
define("FBLAN_15","Mensaje a�adido a la BD");
define("FBLAN_16","Mensaje actualizado a la BD");
define("FBLAN_17","Campos en blanco");
define("FBLAN_18","Mensaje de la caja de caracter�sticas borrado");
define("FBLAN_19","Opciones");
define("FBLAN_20","Editar");
define("FBLAN_21","Eliminar");
define("FBLAN_22","Tipo de renderizado");
define("FBLAN_23","En el propio tema");
define("FBLAN_24","Plano");
define("FBLAN_25","Plantilla");
define("FBLAN_26","Puede usar diferentes plantillas para cada mensaje. A�ada plantillas a la carpeta e107_plugins/featurebox/templates/");

?>