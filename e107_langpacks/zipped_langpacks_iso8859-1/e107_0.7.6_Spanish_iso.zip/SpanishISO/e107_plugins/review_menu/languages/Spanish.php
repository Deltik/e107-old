<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/review_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_190", "Enviar Revisi�n");
define("LAN_RVW_1", "Actualizar configuraci�n");
define("LAN_RVW_2", "Configuraci�n guardada");
define("LAN_RVW_3", "T�tulo");
define("LAN_RVW_4", "N� de revisiones");
define("LAN_RVW_5", "�Mostrar categorias en men�?");
define("LAN_RVW_6", "T�tulo lista de revisiones");
define("LAN_RVW_7", "�Mostrar enlace a enviar revisi�n?");
define("LAN_RVW_8", "Configuraci�n");
?>