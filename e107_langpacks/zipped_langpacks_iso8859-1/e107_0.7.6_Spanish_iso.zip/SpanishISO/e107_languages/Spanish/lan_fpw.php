<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_fpw.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/14 10:37:10 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Cambiar Contrase�a");
define("LAN_01", "La nueva contrase�a ha sido enviada a ".$_POST['email'].", por favor siga las instrucciones en el email para validar su contrase�a.");
define("LAN_02", "Lo sentimos, no se puede enviar el email - por favor p�ngase en contacto con el administrador del sitio.");
define("LAN_03", "Cambiar Contrase�a");
define("LAN_04", "Por favor escriba su direcci�n email");
define("LAN_05", "Por favor escriba su direcci�n email ...");
define("LAN_06", "Intento de Cambio de contrase�a");
define("LAN_07", "Alguien con la direcci�n IP ");
define("LAN_08", "intent� cambiar la contrase�a del administrador principal.");
define("LAN_09", "Contrase�a cambiada desde ");

define("LAN_112", "Email: ");

define("LAN_156", "Enviar");

define("LAN_213", "La direcci�n email no se encuentra en la base de datos.");
define("LAN_214", "No se puede cambiar la contrase�a");
define("LAN_215", "Su contrase�a para ".SITENAME." ha sido cambiada. Su nueva contrase�a es\n\n");
define("LAN_216", "Para validar su nueva contrase�a por favor vaya a la siguiente direcci�n web ...");
define("LAN_217", "Su nueva contrase�a ha sido validada, ahora solo tiene que iniciar sesi�n en el portal con su nueva contrase�a.");
define("LAN_218", "Su nombre de usuario es:");
define("LAN_219", "La contrase�a asociada a esta cuenta de email fu� cambiada y no se puede volver a cambiar. Por favor p�ngase en contacto con el administrador del sitio.");

define("LAN_FPW1","Usuario");
define("LAN_FPW2","C�digo");
define("LAN_FPW3","C�digo Incorrecto");
define("LAN_FPW4","Se envi� una solicitud para cambiar esta contrase�a, si no ha recibido el email, por favor p�ngase en contacto con el administrador del sitio.");
define("LAN_FPW5","Se ha solicitado el cambio de su contrase�a en");
define("LAN_FPW6","Se ha enviado un email a su cuenta de correo con un enlace que le permitir� cambiar su contrase�a.");
define("LAN_FPW7","Este no es un enlace v�lido para cambiar su contrase�a.<br />Por favor p�ngase en contacto con el administrador del sitio.");
define("LAN_FPW8","La contrase�a del usuario");
define("LAN_FPW9","ha sido cambiada.<br /><br />La nueva contrase�a es:");
define("LAN_FPW10","Por favor inicie sesi�n y cambie su contrase�a inmediatamente por seguridad.");
define("LAN_FPW11","Inicie sesi�n");
define("LAN_FPW12","e inmediatamente cambie su contrase�a, por motivos de seguridad.");
define("LAN_FPW13", "por favor siga las instrucciones del email para validar su contrase�a.");
define("LAN_FPW14", "Fu� enviado por alguien con la IP");
define("LAN_FPW15", "Esto no quiere decir que su contrase�a haya sido cambiada.  Debe acceder al enlace proporcionado al final de este mensaje para completar el cambio de contrase�a.");
define("LAN_FPW16", "Si no solicit� resetear su contrase�a y NO quiere resetearla, simplemente ignore este correo");
define("LAN_FPW17", "El siguiente enlace ser� v�lido durante 48 horas.");
?>