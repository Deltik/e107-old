<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_userinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "No se puede encontrar direcci�n IP de usuario - no hay informaci�n disponible.");
//define("USFLAN_2", "Error");
define("USFLAN_3", "Mensajes enviados desde direci�n IP");
define("USFLAN_4", "Alojado");
define("USFLAN_5", "Pulse aqu� para transferir direcci�n IP a p�gina de prohibici�n de la Administraci�n");
define("USFLAN_6", "ID de usuario");
define("USFLAN_7", "Informaci�n de usuario");

?>