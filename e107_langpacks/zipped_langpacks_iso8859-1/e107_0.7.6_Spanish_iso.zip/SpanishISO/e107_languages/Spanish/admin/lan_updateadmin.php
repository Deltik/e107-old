<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Error - por favor re-envia");
define("UDALAN_2", "Configuraci�n actualizada");
define("UDALAN_3", "Configuraci�n actualizada para");
define("UDALAN_4", "Nombre");
define("UDALAN_5", "Contrase�a");
define("UDALAN_6", "Re-escriba contrase�a");
define("UDALAN_7", "Cambiar contrase�a");
define("UDALAN_8", "Actualizar contrase�a de");

?>