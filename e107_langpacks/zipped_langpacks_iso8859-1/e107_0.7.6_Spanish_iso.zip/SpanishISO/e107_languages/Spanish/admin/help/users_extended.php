<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/users_extended.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = " Los campos extendidos de usuario le permiten a�adir tipos adicionales de datos que estar�n disponibles en el perfil del usuario.";
$ns -> tablerender(" Ayuda de campos extendidos de usuarios", $text);
?>