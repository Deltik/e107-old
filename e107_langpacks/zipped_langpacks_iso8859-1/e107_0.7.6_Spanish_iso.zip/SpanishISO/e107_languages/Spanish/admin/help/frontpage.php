<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/frontpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$caption = "Ayuda P�gina de Inicio";
$text = "Desde esta pantalla puede elegir qu� mostrar en la p�gina inicial de su sitio,
la predeterminada es noticias.
Puede asimismo usar esta p�gina para configurar 'splashscreen',
una p�gina que solo aparecer� cuando el visitante entra por primera vez a su sitio.";
$ns -> tablerender($caption, $text);
?>