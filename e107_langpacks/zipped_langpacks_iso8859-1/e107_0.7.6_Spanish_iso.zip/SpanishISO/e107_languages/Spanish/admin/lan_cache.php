<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_cache.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "�Activar Cach�");
define("CACLAN_2", "Cambiar estado de la cach�");
define("CACLAN_3", "Sistema de Cach�");
define("CACLAN_4", "Estado de Cach� cambiado");
define("CACLAN_5", "Vaciar Cach�");
define("CACLAN_6", "Cach� vaciada");
define("CACLAN_7", "Cach� desactivada");
//define("CACLAN_8", "Guardar Cach� en MySQL");
define("CACLAN_9", "Guardar Cach� en archivo");
define("CACLAN_10", "La carpeta cach� [e107_files\cache] no tiene permisos de escritura. Aseg�rese de cambiar el directorio con CHMOD 777");
?>