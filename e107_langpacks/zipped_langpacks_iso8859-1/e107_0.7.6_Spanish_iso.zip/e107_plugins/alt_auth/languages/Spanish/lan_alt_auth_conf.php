<?php
define("LAN_ALT_1", "Tipo de autorizaci�n actual");
define("LAN_ALT_2", "Actualizar ajustes");
define("LAN_ALT_3", "Escoja tipo de autorizaci�n alternada");
define("LAN_ALT_4", "Configure par�metros para");
define("LAN_ALT_5", "Configure par�metros de autorizaci�n");
define("LAN_ALT_6", "Fall� la acci�n de conexi�n");
define("LAN_ALT_7", "Si falla el m�todo de conexi�n alternativo, �Como ser� dirigido?");
define("LAN_ALT_8", "El usuario no encontr� la acci�n");
define("LAN_ALT_9", "Si el nombre de usuario no se encuentra usando el m�todo alternativo, �Como ser� dirigido?");

define("LAN_ALT_FALLBACK", "Use la tabla e107");
define("LAN_ALT_FAIL", "Conexi�n fallida");
?>
