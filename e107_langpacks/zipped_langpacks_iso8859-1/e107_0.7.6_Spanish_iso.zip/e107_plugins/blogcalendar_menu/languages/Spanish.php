<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/blogcalendar_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Noticias para ");
define("BLOGCAL_L2", "Archivo");

define("BLOGCAL_D1", "Lu");
define("BLOGCAL_D2", "Ma");
define("BLOGCAL_D3", "Mi");
define("BLOGCAL_D4", "Ju");
define("BLOGCAL_D5", "Vi");
define("BLOGCAL_D6", "Sa");
define("BLOGCAL_D7", "Do");

define("BLOGCAL_M1", "Enero");
define("BLOGCAL_M2", "Febrero");
define("BLOGCAL_M3", "Marzo");
define("BLOGCAL_M4", "Abril");
define("BLOGCAL_M5", "Mayo");
define("BLOGCAL_M6", "Junio");
define("BLOGCAL_M7", "Julio");
define("BLOGCAL_M8", "Agosto");
define("BLOGCAL_M9", "Septiembre");
define("BLOGCAL_M10", "Octubre");
define("BLOGCAL_M11", "Noviembre");
define("BLOGCAL_M12", "Diciembre");

define("BLOGCAL_1", "Noticia");

define("BLOGCAL_CONF1", "Meses/columna");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF3", "Actualizar par�metros de men�");
define("BLOGCAL_CONF4", "BlogCal Configuraci�n del men�");
define("BLOGCAL_CONF5", "BlogCal configuraci�n del men� guardada");

define("BLOGCAL_ARCHIV1", "Seleccione archivo");

?>