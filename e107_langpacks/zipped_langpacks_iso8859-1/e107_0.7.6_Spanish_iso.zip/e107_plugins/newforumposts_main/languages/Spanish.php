<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/newforumposts_main/languages/Spanish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/14 10:37:10 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Tema");
define("NFPM_LAN_2", "Usuario");
define("NFPM_LAN_3", "Vistas");
define("NFPM_LAN_4", "Respuestas");
define("NFPM_LAN_5", "�ltimo");
define("NFPM_LAN_6", "Temas");
define("NFPM_LAN_7", "por");

define("NFPM_L1", "Este Plugin muestra una lista de nuevos mensajes en los foros en la p�gina principal");
define("NFPM_L2", "�ltimos mensajes en los foros");
define("NFPM_L3", "");
define("NFPM_L4", "�Activar en el �rea?");
define("NFPM_L5", "Inactivo");
define("NFPM_L6", "Superior");
define("NFPM_L7", "Inferior");
define("NFPM_L8", "T�tulo");
define("NFPM_L9", "N�mero de mensajes nuevos a mostrar");
define("NFPM_L10", "�Mostrar en una caja con scroll?");
define("NFPM_L11", "Alto");
define("NFPM_L12", "Configuraci�n");
define("NFPM_L13", "Actualizar configuraci�n");
define("NFPM_L14", "Configuraci�n actualizada.");
define("NFPM_L15", "Marque para ver los �ltimos mensajes en los foros.<br />Por defecto son los �ltimos temas.");
define('NFPM_L16', '[Usuario eliminado]');
?>