<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/linkwords/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "Campo/s en blanco.");
define("LWLAN_2", "Palabra enlazada guardada.");
define("LWLAN_3", "Palabra enlazada actualizada.");
define("LWLAN_4", "Sin palabras enlazadas definidas a�n.");
define("LWLAN_5", "Palabra");
define("LWLAN_6", "Enlace");
define("LWLAN_7", "�Activa?");
define("LWLAN_8", "Opciones");
define("LWLAN_9", "Si");
define("LWLAN_10", "No");
define("LWLAN_11", "Palabras enlazadas ya existentes");
define("LWLAN_12", "Si");
define("LWLAN_13", "No");
define("LWLAN_14", "Enviar palabra enlazada");
define("LWLAN_15", "Actualizar palabra enlazada");
define("LWLAN_16", "Editar");
define("LWLAN_17", "Eliminar");
define("LWLAN_18", "�Esta seguro de eliminar esta palabra enlazada?");
define("LWLAN_19", "Palabra enlazada eliminada.");
define("LWLAN_20", "No encuentro la entrada de la palabra enlazada.");

define("LWLANINS_1", "Palabras enlazadas");
define("LWLANINS_2", "Este plugin enlaza palabras a un enlace determinado");
define("LWLANINS_3", "Configurar palabras enlazadas");
define("LWLANINS_4", "Para configurar, haga click en la seccion de plugins del men� del administrador");

?>