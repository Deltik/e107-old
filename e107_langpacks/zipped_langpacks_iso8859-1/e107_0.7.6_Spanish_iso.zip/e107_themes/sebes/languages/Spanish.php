<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/sebes/languages/Spanish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'sebes' por <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Leer/enviar comentario: ");
define("LAN_THEME_3", "Comentarios desactivados ");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");

?>