/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/28 13:19:22 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/media/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/media/langs/pl.php rev. 1.1
+-----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('media',{
title : 'Insert / edit embedded media',
desc : 'Insert / edit embedded media',
general : 'Og�lne',
advanced : 'Zaawansowane',
file : 'Plik',
list : 'Lista',
size : 'Wymiary',
preview : 'Podgl�d',
constrain_proportions : 'Zachowaj proporcje',
type : 'Typ',
id : 'Id',
name : 'Nazwa',
class_name : 'Klasa',
vspace : 'V-Space',
hspace : 'H-Space',
play : 'Auto odtwarzanie',
loop : 'P�tla',
menu : 'Poka� menu',
quality : 'Jako��',
scale : 'Scale',
align : 'Wyr�wnanie',
salign : 'SAlign',
wmode : 'WMode',
bgcolor : 'T�o',
base : 'Base',
flashvars : 'Flashvars',
liveconnect : 'SWLiveConnect',
autohref : 'AutoHREF',
cache : 'Cache',
hidden : 'Hidden',
controller : 'Controller',
kioskmode : 'Kiosk mode',
playeveryframe : 'Play every frame',
targetcache : 'Target cache',
correction : 'No correction',
enablejavascript : 'Enable JavaScript',
starttime : 'Czas rozpocz�cia',
endtime : 'Czas zako�czenia',
href : 'Href',
qtsrcchokespeed : 'Choke speed',
target : 'Target',
volume : 'G�o�no��',
autostart : 'Auto start',
enabled : 'Enabled',
fullscreen : 'Pe�ny ekran',
invokeurls : 'Invoke URLs',
mute : 'Wycisz',
stretchtofit : 'Stretch to fit',
windowlessvideo : 'Windowless video',
balance : 'Balance',
baseurl : 'Base URL',
captioningid : 'Captioning id',
currentmarker : 'Current marker',
currentposition : 'Current position',
defaultframe : 'Default frame',
playcount : 'Play count',
rate : 'Rate',
uimode : 'UI Mode',
flash_options : 'Opcje plik�w Flash',
qt_options : 'Opcje plik�w Quicktime',
wmp_options : 'Opcje Windows media player',
rmp_options : 'Opcje Real media player',
shockwave_options : 'Opcje Shockwave',
autogotourl : 'Auto goto URL',
center : 'Center',
imagestatus : 'Status obrazka',
maintainaspect : 'Maintain aspect',
nojava : 'No java',
prefetch : 'Prefetch',
shuffle : 'Shuffle',
console : 'Console',
numloop : 'Ilo�c p�tli',
controls : 'Controls',
scriptcallbacks : 'Script callbacks',
swstretchstyle : 'Stretch style',
swstretchhalign : 'Stretch H-Align',
swstretchvalign : 'Stretch V-Align',
sound : 'D�wi�k',
progress : 'Post�p',
qtsrc : '�r�d�o QT',
qt_stream_warn : 'Streamed rtsp resources should be added to the QT Src field under the advanced tab.\nYou should also add a non streamed version to the Src field..'
});
