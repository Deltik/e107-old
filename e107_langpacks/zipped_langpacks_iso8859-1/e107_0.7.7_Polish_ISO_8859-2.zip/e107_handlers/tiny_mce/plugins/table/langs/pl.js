/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:32:56 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/table/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/table/langs/en.php rev. 1.8
+-----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('table',{
general_tab : 'G��wne ustawienia',
advanced_tab : 'Zaawansowane',
general_props : 'G��wne ustawienia',
advanced_props : 'Zaawansowane ustawienia',
desc : 'Wstawia now� tabel�',
row_before_desc : 'Wstaw wiersz przed',
row_after_desc : 'Wstaw wiersz za',
delete_row_desc : 'Usu� wiersz',
col_before_desc : 'Wstaw kolumn� przed',
col_after_desc : 'Wstaw kolumn� za',
delete_col_desc : 'Usu� kolumn�',
rowtype : 'Wiersz w cz�ci tabeli',
title : 'Wstaw/Zmie� tabel�',
width : 'Szeroko��',
height : 'Wysoko��',
cols : 'Kolumn',
rows : 'Wierszy',
cellspacing : 'Odst�py mi�dzy kom�rkami',
cellpadding : 'Margines wewn�trz kom�rek',
border : 'Ramka',
align : 'Wyr�wnanie',
align_default : 'Domy�lne',
align_left : 'Lewo',
align_right : 'Prawo',
align_middle : '�rodek',
row_title : 'W�a�ciwo�ci wiersza',
cell_title : 'W�a�ciwo�ci kom�rki',
cell_type : 'Typ kom�rki',
row_desc : 'W�a�ciwo�ci wiersza',
cell_desc : 'W�a�ciwo�ci kom�rki',
valign : 'Wyr�wnanie pionowe',
align_top : 'Do g�ry',
align_bottom : 'Do do�u',
props_desc : 'W�a�ciwo�ci tabeli',
bordercolor : 'Kolor ramki',
bgcolor : 'Kolor t�a',
merge_cells_title : 'Po��cz kom�rki',
split_cells_desc : 'Rozdziel kom�rki',
merge_cells_desc : 'Po��cz kom�rki',
cut_row_desc : 'Wytnij wiersz',
copy_row_desc : 'Kopiuj wiersz',
paste_row_before_desc : 'Wklej wiersz przed',
paste_row_after_desc : 'Wklej wiersz za',
id : 'Id',
style: 'Styl',
langdir : 'Kierunek tekstu',
langcode : 'Kod j�zyka',
mime : 'Docelowy typ MIME',
ltr : 'Lewy do prawego',
rtl : 'Prawy do lewego',
bgimage : 'Obrazek t�a',
summary : 'Podsumowanie',
td : "Dane",
th : "Nag��wek",
cell_cell : 'Aktualizuj bie��c� kom�rk�',
cell_row : 'Aktualizuj wszystkie kom�rki w wierszu',
cell_all : 'Aktualizuj wszystkie kom�rki w tabeli',
row_row : 'Aktualizuj bie��c� kom�rk�',
row_odd : 'Aktualizuj nieparzyste kom�rki w tabeli',
row_even : 'Aktualizuj parzyste kom�rki w tabeli',
row_all : 'Aktualizuj wszystkie kom�rki w tabeli',
thead : 'Nag��wek tabeli',
tbody : 'Cia�o tabeli',
tfoot : 'Stopka tabeli',
del : 'Usu� tabel�',
scope : 'Zasi�g',
row : 'Wiersz',
col : 'Kolumna',
rowgroup : 'Grupa wiersza',
colgroup : 'Grupa kolumny',
col_limit : 'Przekroczy�e� maksymaln� ilo�� kolumn {$cols}.',
row_limit : 'Przekroczy�e� maksymaln� ilo��  wierszy {$rows}.',
cell_limit : 'Przekroczy�e� maksymaln� ilo�� kom�rek {$cells}.',
missing_scope: 'Czy jeste� pewien, �e chcesz kontynuowa� bez sprecyzowania zasi�gu dla nag��wka tej tabeli? Bez tego, niekt�rzy u�ytkownicy mog� mie� problem ze zrozumieniem zawarto�ci tej tabeli, je�eli maj� w��czone jakie� ograniczenia w przegl�darkach.',
});
