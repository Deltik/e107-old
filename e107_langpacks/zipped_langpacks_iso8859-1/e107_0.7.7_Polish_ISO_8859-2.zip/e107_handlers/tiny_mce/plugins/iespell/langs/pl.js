/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:32:56 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/iespell/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/iespell/langs/en.php rev. 1.2
+-----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
iespell_desc : 'Uruchom sprawdzanie pisowni',
iespell_download : "Nie wykryto pluginu, kliknij aby przej�� do strony z pluginami."
});
