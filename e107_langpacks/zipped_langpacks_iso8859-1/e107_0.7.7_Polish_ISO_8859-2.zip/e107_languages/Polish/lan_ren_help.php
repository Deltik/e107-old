<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2006/08/27 13:41:10 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_ren_help.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_ren_help.php rev. 1.13
+-----------------------------------------------------------------------------+
*/
 
define("LANHELP_1", "Czarny");
define("LANHELP_2", "Niebieski");
define("LANHELP_3", "Br�zowy");
define("LANHELP_4", "Cyjan");
define("LANHELP_5", "Ciemnoniebieski");
define("LANHELP_6", "Ciemnoczerwony");
define("LANHELP_7", "Zielony");
define("LANHELP_8", "Indygo");
define("LANHELP_9", "Oliwkowy");
define("LANHELP_10", "Pomara�czowy");
define("LANHELP_11", "Czerwony");
define("LANHELP_12", "Fioletowy");
define("LANHELP_13", "Bia�y");
define("LANHELP_14", "��ty");

define("LANHELP_15", "Bardzo ma�y");
define("LANHELP_16", "Ma�y");
define("LANHELP_17", "Normalny");
define("LANHELP_18", "Du�y");
define("LANHELP_19", "Bardzo du�y");
define("LANHELP_20", "Ogromny");

define("LANHELP_21", "Kliknij, aby wybra� kolor...");
define("LANHELP_22", "Kliknij, aby wybra� rozmiar...");

define("LANHELP_23", "Wstawia link: [link]http://e107.org.pl[/link] lub  [link=http://e107.org.pl]Odwied� t� stron�[/link]");
define("LANHELP_24", "Pogrubiony tekst: [b]Ten tekst b�dzie pogrubiony[/b]", "font-weight:bold; width: 20px");
define("LANHELP_25", "Pochylony tekst: [i]Ten tekst b�dzie podkre�lony[/i]", "font-style:italic; width: 20px");
define("LANHELP_26", "Podkre�lony tekst: [u]Ten tekst b�dzie podkre�lony[/u]", "text-decoration: underline; width: 20px");
define("LANHELP_27", "Wstawia obraz: [img]mojobraz.jpg[/img]");
define("LANHELP_28", "Wy�rodkowanie: [center]Ten tekst b�dzie wy�rodkowany[/center]");
define("LANHELP_29", "Wyr�wnanie do lewej: [left]Ten tekst b�dzie wyr�wnany do lewej[/left]");
define("LANHELP_30", "Wyr�wnanie do prawej: [right]Ten tekst b�dzie wyr�wnany do prawej[/right]");
define("LANHELP_31", "Cytuje tekst: [blockquote]Ten tekst b�dzie cytatem (wci�ty)[/blockquote]");
define("LANHELP_32", "Kod - niesformatowany tekst: [code]\$foo = bah;[/code]");
define("LANHELP_33", "HTML - usuwa �amanie linii z tekstu : [html]&lt;table&gt;&lt;tr&gt;&lt;td&gt; etc[/html]");
define("LANHELP_34", "[newpage] lub [newpage=tytu�] Wstawia znacznik nowej strony, dzieli artyku� na wi�cej ni� jedn� stron�");
define("LANHELP_35", "odno�nik URL");
define("LANHELP_36", "Lista nieuporz�dkowana: [list]linia*linia2*linia3[/list] Lista uporz�dkowana: [list=typ]linia1*linia2*linia3[/list]");

define("LANHELP_37", "Wstaw obrazek z katalogu e107_images/newspost_images/");
define("LANHELP_38", "Zostanie wygenerowany link do obrazka");

define("LANHELP_39", "Wstaw link do pliku z dzia�u download");
define("LANHELP_40", "Nie ma jeszcze �adnych plik�w do pobrania");

define("LANHELP_41", "Rozmiar czcionki...");
define("LANHELP_42", "Wybierz obrazek...");
define("LANHELP_43", "Wybierz plik do pobrania...");
define("LANHELP_44", "Kliknij, aby otworzy�/zamkn�� okienko wyboru emotikon...");
define("LANHELP_45", "Wstaw obrazek z katalogu: ");
define("LANHELP_46", "* Nie znaleziono plik�w w: ");

define("LANHELP_47", "Wstaw element flash: [flash=szeroko��,wysoko��]http://www.nazwastrony.pl/plik.swf[/flash]");

?>
