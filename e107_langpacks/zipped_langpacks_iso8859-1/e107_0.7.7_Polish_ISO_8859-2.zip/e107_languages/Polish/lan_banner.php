<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_banner.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_banner.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Reklamy");

define("BANNERLAN_16", "Klient: ");
define("BANNERLAN_17", "Has�o: ");
define("BANNERLAN_18", "Kontynuuj");
define("BANNERLAN_19", "Aby kontynuowa�, prosz� wpisa� nazw� klienta i has�o.");
define("BANNERLAN_20", "Przepraszam, nie mog� odnale�� wskazanych informacji w bazie danych. Prosz� skontaktowa� si� z administratorem strony w celu wyja�nienia.");
define("BANNERLAN_21", "Statystyki reklam");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "ID reklamy");
define("BANNERLAN_24", "Klikaj�cych");
define("BANNERLAN_25", "% klikni��");
define("BANNERLAN_26", "Wy�wietle�");
define("BANNERLAN_27", "Kupionych wy�wietle�");
define("BANNERLAN_28", "Pozosta�o wy�wietle�");
define("BANNERLAN_29", "Brak reklam");
define("BANNERLAN_30", "Bez limitu");
define("BANNERLAN_31", "Nie dotyczy");
define("BANNERLAN_32", "Tak");
define("BANNERLAN_33", "Nie");
define("BANNERLAN_34", "Zako�czenie:");
define("BANNERLAN_35", "Adresy IP klikaj�cych");
define("BANNERLAN_36", "Aktywny:");
define("BANNERLAN_37", "Rozpocz�cie:");
define("BANNERLAN_38", "B��d");

?>
