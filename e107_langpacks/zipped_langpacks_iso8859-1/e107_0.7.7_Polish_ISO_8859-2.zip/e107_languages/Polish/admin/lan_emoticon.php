<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_emoticon.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_emoticon.php rev. 1.8
+-----------------------------------------------------------------------------+
*/
 
define("EMOLAN_1", "Aktywacja emotikon");
define("EMOLAN_2", "Nazwa");
define("EMOLAN_3", "Emotikony");
define("EMOLAN_4", "Aktywowa� emotikony?");

define("EMOLAN_5", "Obraz");
define("EMOLAN_6", "Kod obrazka");
define("EMOLAN_7", "do oddzielenia wi�cej ni� jednego wpisu stosuj spacj�");

define("EMOLAN_8", "Status");
define("EMOLAN_9", "Opcje");
define("EMOLAN_10", "Aktywny");
define("EMOLAN_11", "Aktywuj zestaw'");

define("EMOLAN_12", "Edycja/konfiguracja zestawu");
define("EMOLAN_13", "Zainstalowane zestawy");

define("EMOLAN_14", "Zapisz konfiguracj�");
define("EMOLAN_15", "Edycja/konfiguracja emotikon");
define("EMOLAN_16", "Konfiguracja emotikon zosta�a zapisana");
define("EMOLAN_17", "Obecnie posiadasz zestaw emotikon, kt�ry zawiera w nazwie niedozwolone odst�py!");
define("EMOLAN_18", "Prosz� zmieni� nazw� wymienionych poni�ej przypadk�w tak, aby nie zawiera�y w nazwie odst�p�w:");
define("EMOLAN_19", "Nazwa");
define("EMOLAN_20", "Lokalizacja");
define("EMOLAN_21", "B��d");
//define("EMOLAN_2", "Nazwa");

?>
