<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:05 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/links.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/links.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Tutaj mo�esz doda� wszystkie linki zwi�zane bezpo�rednio z Twoim serwisem. Dodane linki zostan� wy�wietlone w g��wnym menu strony. Je�li chcesz utworzy� stron� z linkami do zewn�trznych serwis�w u�yj plugina <i>Links Page</i> (Strona link�w).
<br />
";
$ns -> tablerender("Linki", $text);

?>
