<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:05 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/list_menu_conf.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/list_menu_conf.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "W tej sekcji mo�esz skonfigurowa� 3 menu<br>
<b> Menu nowych artyku��w</b> <br>
Wpisz w pierwszym polu liczb�, na przyk�ad '5', aby wy�wietli� 5 pierwszych artyku��w. Pozostaw puste, aby wy�wietli� wszystkie dost�pne artyku�y, W drugim polu mo�esz skonfigurowa� nazw� linku do reszty artyku��w. Je�li wskazane pole pozostawisz puste nie zostanie utworzony link do dzia�u artyku��w, na przyk�ad: 'Wszystkie artyku�y'<br>
<b> Menu komentarzy/forum</b> <br>
Domy�lna ilo�� komentarzy to 5, natomiast domy�lna dozwolona ilo�� znak�w to 10000. Przyrostek s�u�y do przyci�cia linii, kt�re s� zbyt d�ugie, a nast�pnie dodania na ich ko�cu wskazanego tutaj ci�gu znak�w, dobrym wyborem dla tej opcji s� trzy kropki '...'. Sprawd� oryginalny temat, je�li chcesz zobaczy� t� funkcj� w praktyce.<br>
";
$ns -> tablerender("Konfiguracja menu", $text);

?>
