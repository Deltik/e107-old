<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:05 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/chatbox.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/chatbox.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie mo�esz ustawi� preferencje dla czata..<br />Je�li zaznaczysz pole <i>Zast�p linki</i>, ka�dy wpisany link b�dzie zast�piony przez tekst, kt�ry wpiszesz w pole tekstowe obok zaznaczonego pola - Ta opcja rozwi�zuje problem z wy�wietlaniem d�ugich link�w.<br />Opcja <i>Zawijanie wyraz�w</i> b�dzie zwija� tekst d�u�szy ni� zdefiniowanej tutaj d�ugo�ci.";

$ns -> tablerender("Czat", $text);

?>
