<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/11/19 17:03:20 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_image.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_image.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("IMALAN_1", "Uaktywnij obrazy w postach");
define("IMALAN_2", "Wy�wietla nadsy�ane obrazy, funkcja b�dzie stosowana na wszystkich stronach (komentarze, czat etc)");
define("IMALAN_3", "Metoda zmiany rozmiaru");
define("IMALAN_4", "Metoda u�ywana do zmiany rozmiaru obraz�w, wybierz albo bibloteki GD1/2,  albo ImageMagick");
define("IMALAN_5", "�cie�ka dost�pu do ImageMagick (je�li wybra�e� t� metod�)");
define("IMALAN_6", "Pe�na �cie�ka dost�pu do narz�dzia ImageMagick Convert");
define("IMALAN_7", "Ustawienia obrazk�w");
define("IMALAN_8", "Aktualizuj ustawienia obrazk�w");
define("IMALAN_9", "Ustawienia obraz�w zosta�y zaktualizowane");
define("IMALAN_10", "Uprawniona grupa u�ytkownik�w");
define("IMALAN_11", "Ograniczenie u�ytkownik�w, kt�rzy b�d� mogli korzysta� we wpisach z obraz�w (tylko w�wczas gdy uaktywni�e� powy�sz� funkcj�)");
define("IMALAN_12", "Metoda wstawiania nieaktywnych obraz�w");
define("IMALAN_13", "Wybierz co robi� z obrazami, gdy funkcja ich wstawiania jest nieaktywna");
define("IMALAN_14", "Pokazuj adres URL obrazka");
define("IMALAN_15", "Nic nie pokazuj");
define("IMALAN_16", "Poka� nades�ane awatary");
define("IMALAN_17", "Kliknij tutaj");
define("IMALAN_18", "Nades�ane obrazki");

define("IMALAN_21", "U�ywany przez");
define("IMALAN_22", "Obraz nie jest w u�yciu");
define("IMALAN_23", "Awatar");
define("IMALAN_24", "Fotografia");
define("IMALAN_25", "Kliknij tutaj, aby usun�� wszystkie niestosowne obrazy"); // Kliknij tutaj, aby usun�� wszystkie u�ywane obrazy
define("IMALAN_26", "obrazy zosta�y usuni�te");

define("IMALAN_28", "usuni�ty");
define("IMALAN_29", "Nie ma jeszcze obraz�w");
define("IMALAN_30", "Wszyscy (publicznie)");
define("IMALAN_31", "Go�cie");
define("IMALAN_32", "Zarejestrowani u�ytkownicy");
define("IMALAN_33", "Administratorzy");
define("IMALAN_34", "Uaktywnij Sleight");
define("IMALAN_35", "Naprawia przezroczysto�� kana�u alpha dla plik�w PNG-24 w przegl�darce internetowej IE 5/6 (stosuje <i>Sitewide</i>)"); // Fixes transparent PNG-24's with alpha transparency in IE 5 / 6 (Applies Sitewide)

define("IMALAN_36", "Walidacja rozmiaru oraz dost�pu awatar�w");
define("IMALAN_37", "Walidacja awatar�w");
define("IMALAN_38", "Maksymalna dopuszczalna szeroko��");
define("IMALAN_39", "Maksymalna dopuszczalna wysoko��");
define("IMALAN_40", "Za szeroki");
define("IMALAN_41", "Za wysoki");
define("IMALAN_42", "Nie znaleziono");
define("IMALAN_43", "Usu� za�adowane awatary");
define("IMALAN_44", "Usu� odsy�acze do zewn�trznych awatar�w");
define("IMALAN_45", "Nie znaleziono");
define("IMALAN_46", "Za du�y");
define("IMALAN_47", "Wszystkie za�adowane awatary");
define("IMALAN_48", "Wszystkie zewn�trzne awatary");
define("IMALAN_49", "U�ytkownik�w z awatarami");
define("IMALAN_50", "Wszystkich");
define("IMALAN_51", "Awatar dla ");

?>
