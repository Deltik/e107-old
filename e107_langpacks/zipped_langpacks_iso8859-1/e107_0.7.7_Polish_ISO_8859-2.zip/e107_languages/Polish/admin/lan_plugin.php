<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2006/08/27 22:38:19 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_plugin.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_plugin.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
define("EPL_ADLAN_0", "Zainstaluj");
define("EPL_ADLAN_1", "Deinstalacja");
define("EPL_ADLAN_2", "Czy na pewno odinstalowa� plugin");
define("EPL_ADLAN_3", "Potwierd� deinstalacj�");
define("EPL_ADLAN_4", "Deinstalacja zosta�a anulowana.");
define("EPL_ADLAN_5", "Procedura instalacji utworzy nowe pozycje w ustawieniach.");
define("EPL_ADLAN_6", "...nast�pnie kliknij tutaj, aby rozpocz�� procedur� instalacji");
define("EPL_ADLAN_7", "Aktualizacja tabel bazy danych zosta�a zako�czona.");
define("EPL_ADLAN_8", "Ustawienia preferencji zosta�y utworzone.");
define("EPL_ADLAN_9", "Wyst�pi�y b��dy komend SQL. Sprawd� czy na pewno wszystkie zmiany aktualizacyjne s� poprawne.");
define("EPL_ADLAN_10", "Nazwa");
define("EPL_ADLAN_11", "Wersja");
define("EPL_ADLAN_12", "Autor");
define("EPL_ADLAN_13", "Kompatybilno��");
define("EPL_ADLAN_14", "Opis");
define("EPL_ADLAN_15", "Przeczytaj plik <i>README</i> (CZYTAJTO), aby uzyska� wi�cej informacji");
define("EPL_ADLAN_16", "Informacje o pluginach");
define("EPL_ADLAN_17", "Wi�cej informacji...");
define("EPL_ADLAN_18", "Nie mog� utworzy� tabel(i) dla tego pluginu.");
define("EPL_ADLAN_19", "Tabele bazy danych zosta�y utworzone.");
// define("EPL_ADLAN_20", "Ustawienia preferencji zosta�y utworzone."); // duplicate of EPL_ADLAN_8;

define("EPL_ADLAN_21", "Plugin jest ju� zainstalowany.");
define("EPL_ADLAN_22", "Zainstalowane");
define("EPL_ADLAN_23", "Niezainstalowane");
define("EPL_ADLAN_24", "Dost�pne aktualizacje");
define("EPL_ADLAN_25", "Nie wymaga instalacji");
define("EPL_ADLAN_26", "...nast�pnie kliknij tutaj, aby rozpocz�� procedur� deinstalacyjn�");
define("EPL_ADLAN_27", "Nie mog� usun�� ");
define("EPL_ADLAN_28", "Tabele bazy danych zosta�y usuni�te.");
define("EPL_ADLAN_29", "Ustawienia preferencji zosta�y usuni�te.");
define("EPL_ADLAN_30", "prosz� usun�� to r�cznie.");
define("EPL_ADLAN_31", "Prosz� teraz usun�� folder ");
define("EPL_ADLAN_32", "oraz wszystkie pliki wewn�trz, aby zako�czy� proces deinstalacyjny.");
define("EPL_ADLAN_33", "Plugin zosta� pomy�lnie zainstalowany.");
define("EPL_ADLAN_34", "Plugin zosta� pomy�lnie zaktualizowany.");
define("EPL_ADLAN_35", "Ustawienia parsera (analizatora sk�adni) zosta�y dodane pomy�lnie.");
define("EPL_ADLAN_36", "Wstawienie kodu parsera nie powiod�o si�, niepoprawnie sformatowany.");

define("EPL_ADLAN_37", "Wybierz plugin (format .zip lub .tar.gz)");
define("EPL_ADLAN_38", "Za�aduj plugin");
define("EPL_ADLAN_39", "Plik nie m�g� by� za�adowany do ".e_PLUGIN." folder nie ma prawid�owych uprawnie� - prosz� ustawi� CHMOD na warto�� 777 i ponownie za�adowa� plik.");
define("EPL_ADLAN_40", "Wiadomo�� administracyjna");
define("EPL_ADLAN_41", "Plik jest prawdopodobnie uszkodzonym archiwum .zip lub .tar.");
define("EPL_ADLAN_42", "Wyst�pi� b��d, nie mog� wyodr�bni� pliku z archiwum");
define("EPL_ADLAN_43", "Tw�j plugin zosta� za�adowany i rozpakowany, prosz� przewin�� stron� w d� i poszuka� tematu na li�cie.");
define("EPL_ADLAN_44", "Automatyczne �adowanie i rozpakowanie pluginu jest niemo�liwe, je�li folder plugin�w ma nie nieprawid�owe uprawnienia. Prosz� ustawi� CHMOD g��wnego folderu plugin�w na warto�� 777.");
define("EPL_ADLAN_45", "Twoje menu zosta�o pomy�lnie za�adowane oraz rozpakowane, aby je aktywowa� prosz� si� uda� do <a href='".e_ADMIN."menus.php'>strony ustawie� menu</a>.");

// define("EPL_CANCEL", "Anuluj"); use LAN_CANCEL instead !!
// define("EPL_EMAIL", "email");
define("EPL_WEBSITE", "Strona domowa");
// define("EPL_OPTIONS", "Opcje"); use LAN_OPTIONS instead!
define("EPL_NOINSTALL", "Nie wymaga instalacji, wystarczy aktywowa� menu. Aby odinstalowa�, usu� ");
define("EPL_DIRECTORY", "katalog.");
define("EPL_NOINSTALL_1", "Nie wymaga instalacji, aby usun�� skasuj ");
define("EPL_UPGRADE", "Aktualizuj");

define("EPL_ADLAN_50", "Komentarze zosta�y pomy�lnie usuni�te");

define("EPL_ADLAN_53", "Wskazany katalog jest niezapisywalny");
define("EPL_ADLAN_54", "Prosz� wybra� opcj� deinstalacji plugina:");
define("EPL_ADLAN_55", "Odinstalowanie plugina");

define("EPL_ADLAN_57", "Usuni�cie tabel plugina");
define("EPL_ADLAN_58", "Je�li tabele nie zostan� usuni�te, plugin b�dzie m�g� by� przeinstalowany bez utraty danych. Utworzenie tabel podczas ponownej instalacji b�dzie niemo�liwe. Usuni�cie tabel b�dzie mo�liwe tylko poprzez r�czne wykasowanie.");
define("EPL_ADLAN_59", "Usuni�cie plik�w plugina");
define("EPL_ADLAN_60", "e107 b�dzie usi�owa� usun�� wszystkie pliki sk�adowe wybranego plugina.");
// define("EPL_ADLAN_61", "Potwierd� deinstalacj�"); // duplicated. can be deleted.
define("EPL_ADLAN_62", "Anuluj deinstalacj�");
define("EPL_ADLAN_63", "Deinstalacja:");

define("LAN_UPGRADE_SUCCESSFUL", "Aktualizacja zosta�a zako�czona pomy�lnie");
define("LAN_INSTALL_SUCCESSFUL", "Instalacja zosta�a zako�czona pomy�lnie");

?>
