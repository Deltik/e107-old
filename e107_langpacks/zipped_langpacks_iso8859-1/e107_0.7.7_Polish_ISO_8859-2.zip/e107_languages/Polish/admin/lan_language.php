<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2006/10/25 11:56:35 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_language.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_language.php rev. 1.14
+-----------------------------------------------------------------------------+
*/
 
define("LANG_LAN_00", "nie mo�na by�o utworzy� (ju� istnieje).");
define("LANG_LAN_01", "zosta�a usuni�ta i ponownie utworzona.");
define("LANG_LAN_02", "nie mo�na by�o usun��");
define("LANG_LAN_03", "Tabele");

define("LANG_LAN_05", "Nie zainstalowane");
define("LANG_LAN_06", "Utw�rz tabele");
define("LANG_LAN_07", "Pomi� istniej�ce tabele?");
define("LANG_LAN_08", "Przywr�� istniej�ce tabele (dane zostan� utracone).");
define("LANG_LAN_10", "Potwierd� usuni�cie");
define("LANG_LAN_11", "Usu� niesprawdzone tabele znajduj�ce si� powy�ej (je�li takie istniej�).");
define("LANG_LAN_12", "Uaktywnij tryb tabel wieloj�zykowych");
define("LANG_LAN_13", "Preferencje j�zyka");
define("LANG_LAN_14", "Domy�lny j�zyk strony");
define("LANG_LAN_15", "Zaznacz, aby skopiowa� dane z domy�lnego j�zyka (przydatne dla link�w, kategorii aktualno�ci itp).");
define("LANG_LAN_16", "U�ywanie wieloj�zycznej bazy danych"); 
define("LANG_LAN_17", "Domy�lny j�zyk - Nie wymaga dodatkowych tabel.");
define("LANG_LAN_18", "U�ywaj zaparkowanych subdomen dla ustawionego j�zyka:");
define("LANG_LAN_19", "np. fr.mojadomena.com, aby ustawi� j�zyk na francuski.");
define("LANG_LAN_20", "Wprowad� nazw� g��wnej domeny w celu skorzystania z tej opcji. np. mojadomena.com");

define("LANG_LAN_21", "Narz�dzia j�zykowe");

?>
