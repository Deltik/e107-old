<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.8 $
|     $Date: 2006/11/24 14:06:44 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_prefs.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_prefs.php rev. 1.59
+-----------------------------------------------------------------------------+
*/
 
define("PRFLAN_1", "Informacje o stronie");
define("PRFLAN_2", "Nazwa strony");
define("PRFLAN_3", "Adres URL strony");
define("PRFLAN_4", "Link do buttona strony");
define("PRFLAN_5", "Znacznik Tagline strony");
define("PRFLAN_6", "Opis strony");
define("PRFLAN_7", "G��wny administrator strony");
define("PRFLAN_8", "Email g��wnego administratora strony");
define("PRFLAN_9", "Disclaimer strony");
define("PRFLAN_10", "Temat");
define("PRFLAN_11", "Temat strony");
define("PRFLAN_12", "Kliknij tutaj, aby podejrze� tematy");
define("PRFLAN_13", "Wy�wietlane informacje");
define("PRFLAN_14", "Wy�wietli� informacje o temacie?");
define("PRFLAN_15", "Wy�wietli� czas generowania strony?");
define("PRFLAN_16", "Wy�wietli� ilo�� zapyta� sql?");
define("PRFLAN_17", "Kompresuj wysy�an� stron� u�ywaj�c funkcji gzip");
define("PRFLAN_19", "Opcje rejestracji");
define("PRFLAN_21", "Opcje wy�wietlania daty");
define("PRFLAN_22", "Kr�tki format daty");
define("PRFLAN_23", "D�ugi format daty");
define("PRFLAN_24", "Format daty na forum");
define("PRFLAN_25", "Aby uzyska� wi�cej informacji o formatach daty zobacz");
define("PRFLAN_26", "Przesuni�cie czasu");
define("PRFLAN_27", "Przyk�adowo, je�li ustawisz dla tej opcji +2, w�wczas do wszystkich czas�w na Twojej stronie zostan� dodane 2 godziny");
define("PRFLAN_28", "Rejestracja oraz publikacje");
define("PRFLAN_29", "Aktywowa� system rejestracji u�ytkownik�w?");
define("PRFLAN_30", "pozwala u�ytkownikom na rejestracj� na Twojej stronie");
// define("PRFLAN_31", "U�ywa� weryfikacji emailem dla zarejestrowanych?");
define("PRFLAN_32", "Zezwoli� na anonimowe publikacje?");
define("PRFLAN_33", "wy��czenie opcji spowoduje, �e tylko zarejestrowani u�ytkownicy b�d� mogli pisa� komentarze etc");
define("PRFLAN_35", "W��czy� zabezpieczenie przeciwko atakom typu flood?");
define("PRFLAN_36", "Restrykcje czasu dla ataku typu flood"); // Flood timeout
define("PRFLAN_37", "Auto-blokowanie");
define("PRFLAN_38", "Czas w sekundach, kt�ry musi up�yn�� pomi�dzy dwoma kolejnymi wpisami w strefach do tego przeznaczonych, np czat, forum, etc. Je�li u�ytkownik doda wpis zbyt szybko, zostanie przekierowany do strony g��wnej");
define("PRFLAN_40", "Filtrowa� wulgaryzmy?");
define("PRFLAN_41", "w��czenie spowoduje zast�pienie wykrytych wulgaryzm�w poni�szym wyra�eniem");
define("PRFLAN_42", "Zast�p wyra�eniem");
define("PRFLAN_43", "Filtrowane s�owa");
define("PRFLAN_44", "s�owa do ocenzurowania, oddziel przecinkami");
define("PRFLAN_45", "U�ywa� przy rejestracji standardu ochrony COPPA?");
define("PRFLAN_46", "wi�cej informacji o COPPA mo�esz zobaczy�");
define("PRFLAN_47", "Bezpiecze�stwo &amp; ochrona");
define("PRFLAN_48", "Metoda �ledzenia u�ytkownika");
define("PRFLAN_49", "Ciasteczka");
define("PRFLAN_50", "Sesje");
define("PRFLAN_52", "Zapisz zmiany");
define("PRFLAN_53", "Preferencje strony");
define("PRFLAN_55", "Nazwa ciasteczka (je�li wybra�e� t� metod�)");
define("PRFLAN_56", "Strefa czasowa");
define("PRFLAN_58", "Ogranicz serwis tylko do zarejestrowanych u�ytkownik�w");
define("PRFLAN_59", "w��czenie tego spowoduje ograniczenia w dost�pnie do wszystkich obszar�w serwisu opr�cz strony g��wnej oraz strony rejestracyjnej"); // ticking will restrict all areas apart from the front page and signup page to members only
define("PRFLAN_60", "W��cz SSL");
define("PRFLAN_61", "W��cz SSL tylko, w�wczas gdy <b>jeste� tego pewien i wiesz co robisz!</b>");
define("PRFLAN_76", "W��cz weryfikacj� Image-code podczas rejestracji.");
define("PRFLAN_77", "Opcje wygl�du administracji");
define("PRFLAN_78", "Pozostaw puste, aby wy��czy�");
define("PRFLAN_80", "Kliknij tutaj, aby zobaczy�");
define("PRFLAN_81", "W��cz weryfikacj� Image-code podczas logowania.");
define("PRFLAN_83", "przyk�adowo");
define("PRFLAN_87", "Komentarze");
define("PRFLAN_88", "Zagnie�d�anie komentarzy");
define("PRFLAN_89", "Wy�wietlaj ikon� nowego komentarza");
define("PRFLAN_90", "Pozw�l pisz�cym na edycj� swoich komentarzy");

define("CUSTSIG_1", "Ustawienia zapisane!");
define("CUSTSIG_2", "Prawdziwe imi�:");
define("CUSTSIG_3", "Strona domowa:");
define("CUSTSIG_4", "Urodziny:");
define("CUSTSIG_5", "Miejscowo��:");
define("CUSTSIG_6", "Sygnatura:");
define("CUSTSIG_7", "Awatar:");
define("CUSTSIG_8", "Strefa czasowa:");
define("CUSTSIG_12", "Ukryj");
define("CUSTSIG_13", "Pola");
define("CUSTSIG_14", "Wy�wietl");
define("CUSTSIG_15", "Wymagane");
define("CUSTSIG_16", "Minimalna d�ugo�� dla hase�");
define("CUSTSIG_17", "Zapisz si� na list� mailingow�"); // Subscribe to content/mailouts
define("CUSTSIG_18", "Odrzucaj nazwy u�ytkownik�w");
define("CUSTSIG_19", "nazwy u�ytkownik�w zawieraj�ce nast�puj�ce wyra�enia b�d� odrzucane, poszczeg�lne s�owa oddzielaj przecinkami");

define("PRFLAN_91", "Je�li kto� b�dzie atakowa� Twoj� stron� poprzez wielokrotne zapytania/odwo�ania do twojego serwera, jego IP zostanie automatycznie zablokowane! Nie zmieniaj prawid�owej konfiguracji serwera!!!");
define("PRFLAN_92", "Zabezpieczenie procesu weryfikacji rejestracji -- ukry� has�o w mailu?");
define("PRFLAN_93", "funkcj� <i>strftime</i> na stronie php.net</a> - <a href='http://pl.php.net/manual/pl/function.strftime.php'>pl.php.net");
define("PRFLAN_94", "tutaj");
define("PRFLAN_95", "Wy�wietl informacj� o pluginach:");
define("PRFLAN_96", "B�d� wy�wietlane informacje na wszystkich stronach administracyjnych dla ka�dego pluginu wspieraj�cego ten rodzaj funkcji");
define("PRFLAN_97", "Unikalne menu 'Informacje o pluginach':");
define("PRFLAN_98", "Je�li odznaczysz, ka�dy plugin b�dzie wy�wietla� swoje informacje w indywidualnym menu. Je�li zaznaczysz wszystkie informacje b�d� wy�wietlane w tym samym menu.");
define("PRFLAN_101", "Opcje wy�wietlania tekstu");
define("PRFLAN_102", "Zast�powanie adres�w URL tekstem");
define("PRFLAN_103", "Je�li ta opcja oraz powy�sza b�dzie aktywna, w�wczas wstawione adresy URL zostan� wy�wietlone jako hyperlinki z wykorzystaniem tekstu z poni�szych p�l tekstowych. W��czenie tego zapobiega naruszeniu struktury strony przez zbyt d�ugie adresy URL.");
define("PRFLAN_104", "Zast�p adresy URL tekstem");
define("PRFLAN_105", "Tekst do zast�pienia w tekscie adres�w URL. Mo�esz u�y� dowolnej grafiki wykorzystuj�c znaczniki &lt;img&gt; wraz z pe�n� �cie�k� dost�pu do obrazka");
define("PRFLAN_106", "Ustawienia j�dra zosta�y zapisane w bazie danych.");
define("PRFLAN_107", "Zast�p linki email tekstem");
define("PRFLAN_108", "Tekst do zast�pienia adres�w email, Mo�esz u�y� dowolnej grafiki wykorzystuj�c znaczniki &lt;img&gt; wraz z pe�n� �cie�k� dost�pu do obrazka");
define("PRFLAN_109", "Zawijaj d�ugie s�owa w tek�cie");
define("PRFLAN_110", "s�owa d�u�sze ni� zdefiniowanej d�ugo�ci b�d� zawijane do nowej linii");
define("PRFLAN_111", "Zawijaj d�ugie s�owa w menu");
define("PRFLAN_112", "W��czone");
define("PRFLAN_113", "Wy��czone");
define("PRFLAN_116", "Zezw�l na wpisy w HTML-u");
define("PRFLAN_117", "Ta funkcja pozwoli u�ytkownikom na pisanie w kodzie HTML wssz�dzie na stronie gdzie jest to mo�liwe. Wybierz grup� u�ytkownik�w, kt�ra b�dzie mia�a na to zezwolenie.");
define("PRFLAN_118", "U�yj Geshi do kolorowania sk�adni kodu");
define("PRFLAN_119", "Geshi jest wieloj�zykowym projektem open source do kolorowania sk�adni kodu, aby uzyska� wi�cej informacji zobacz http://qbnz.com/highlighter/");
define("PRFLAN_120", "Domy�lny j�zyk sk�adni Geshi");
define("PRFLAN_121", "je�li �aden j�zyk nie zostanie wybrany w kodzie bbtag, to ten j�zyk b�dzie u�ywany do kolorowania kodu");
define("PRFLAN_122", "W��cz edytor tekstu WYSIWYG");
define("PRFLAN_123", "Funkcja edytora tekstu zgodna z zasad� to-co-widzisz-b�dzie-tym-co-otrzymasz. U�yteczne tylko dla administrator�w i u�ytkownik�w, w�wczas gdy zezwolono na pisanie w HTML-u.");
define("PRFLAN_124", "U�ywaj 'klasycznego' wygl�du dla funkcji nast�pny/poprzedni");
define("PRFLAN_125", "W��czenie tego przedstawi strony nast�pne/poprzednie w postaci 1 2 3 ... 21 22 23, zamiast nowego wygl�du z rozwijaln� list�.");
define("PRFLAN_126", "Tre�� do wy�wietlenia na stronie rejestracyjnej");
define("PRFLAN_127", "Zamieniaj adresy URL na klikalne linki");
define("PRFLAN_128", "W��czenie tego spowoduje zamian� wstawionych adres�w URL na hyperlinki");
define("PRFLAN_129", "Nie zezwalaj na wielokrotne logowanie");
define("PRFLAN_130", "Aktywowanie tej opcji uniemo�liwi wi�cej ni� jednej osobie na logowanie z u�yciem tej samej nazwy u�ytkownika/has�a (specyfikacja systemu logowania)");
define("PRFLAN_131", "Aktywuj u�ywanie bbcode [php]");
define("PRFLAN_132", "Aktywowanie tego pozwoli autoryzowanym u�ytkownikom na wpisywanie kodu [php] w niekt�rych obszarach");
define("PRFLAN_133", "wymagane dodatkowe rozszerzenie GD - nie znaleziono");
define("PRFLAN_134", "Przekierowanie wszystkich odwo�a� do strony");
define("PRFLAN_135", "na przyk�ad, je�li powy�szy adres Twojej strony jest ustawiony na  http://foo.com, ka�de ��danie http://www.foo.com zostanie przekierowane na http://foo.com");
define("PRFLAN_136", "Maksymalnie ilo�� dopuszczonych rejestracji z tego samego adresu IP.");
define("PRFLAN_137", "Wy�wietlaj u�ycie pami�ci");
define("PRFLAN_138", "W��cz weryfikacj� Image-code podczas zmiany zapomnianego has�a.");
define("PRFLAN_139", "Wy�wietl ostrze�enie, gdy has�o administratora nie zosta�o zmienione w ci�gu ostatnich 30 dni");
define("PRFLAN_140", "Tre�� do wy�wietlenia po wys�aniu formularza rejestracyjnego.");
define("PRFLAN_141", "Zezw�l na rejestracj� przy u�yciu profili u�ytkownika XML (XUP)");
define("PRFLAN_142", "Tylko ataki <i>flood</i>");
define("PRFLAN_143", "Tylko b��dy logowa�");
define("PRFLAN_144", "Ataki <i>flood</i> & b��dy logowa�");
define("PRFLAN_145", "Linki w nowym oknie");
define("PRFLAN_146", "Zaznacz to aby otwiera� wszystkie linki w nowym oknie (<i>to pozwoli na sitewide</i>). "); // Tick here to make all links open in a new window (<i>this will apply sitewide</i>).
define("PRFLAN_147", "Tryb deweloperski");
define("PRFLAN_148", "Ta opcja jest przeznaczona tylko dla deweloper�w ze wzgl�du na aktywacj� niekt�rych funkcji deweloperskich. Ze wzgl�du na bezpiecze�stwo serwisu nie u�ywaj tej opcji na stronach firmowych itp.");
define("PRFLAN_149", "Zaawansowane opcje");
define("PRFLAN_150", "Wybierz metod� identyfikacji e107");
define("PRFLAN_151", "e107 - Nie ma zainstalowanych metod alternatywnej identyfikacji");

define("PRFLAN_31", "Weryfikacja email");
define("PRFLAN_152", "Brak weryfikacji");
define("PRFLAN_153", "Zatwierdzenie przez admina");
define("PRFLAN_154", "Metoda weryfikacji nowego u�ytkownika <br />Je�li jest wybrana metoda 'Zatwierdzenie przez admina', zalecane jest aktywowanie powiadamiania email o rejestracji nowych u�ytkownik�w <a href='".e_ADMIN."notify.php'>(kliknij tutaj)</a>.");

define("PRFLAN_155", "Wy�wietlana nazwa u�ytkownika widoczna dla");
define("PRFLAN_156", "Resetuj WSZYSTKIE wy�wietlana nazwy");
define("PRFLAN_157", "Wszystkie wy�wietlane nazwy zosta�y zresetowane i zast�pione loginem");
define("PRFLAN_158", "Maksymalna d�ugo�� wy�wietlanej nazwy");
define("PRFLAN_159", "wy�wietlaj t� stron� jako");
define("PRFLAN_160", "Sprawdzaj serwery zdalne, kiedy walidujesz adresy email.");
define("PRFLAN_161", "Wy��cz wszystkie komentarze na tej stronie");

define("PRFLAN_162", "Strona - Dane kontaktowe");
define("PRFLAN_163", "np. nazwa firmy, adres, telefon itp.");

define("PRFLAN_164", "Zezw�l u�ytkownikom na wysy�anie kopii emaila kontaktowego na w�asny adres pocztowy");
define("PRFLAN_165", "Mo�e sta� si� przyczyn� spamowania, u�ywaj z rozwag�");
define("PRFLAN_166", "Wy�wietlaj obrazki emotikon w formularzu wystawianego komentarza");

define("PRFLAN_167", "Wprowad� opcjonalne adresy email"); // subject to change.
define("PRFLAN_168", "Strona kontaktowa"); //Site Contact Person(s)
define("PRFLAN_169", "Je�li wybrana grupa zawiera wi�cej ni� jedn� osob�, u�ytkownik zostanie poproszony o wybranie odpowiedniej osoby z grupy.");
define("PRFLAN_170", "U�ywaj rDNS, aby umo�liwi� blokowanie host�w");
define("PRFLAN_171", "Zmiana tej opcji umo�liwi Ci blokowanie u�ytkownik�w ze wzgl�du na nazw� hosta, pr�dzej ni� tylko adres IP lub adres email. <br />UWAGA: Mo�e wp�yn�� na czas �adowania strony na niekt�rych hostach.");

?>
