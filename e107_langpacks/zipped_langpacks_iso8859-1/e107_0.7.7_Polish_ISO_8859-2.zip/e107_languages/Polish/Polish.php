<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.6 $
|     $Date: 2006/11/19 17:02:44 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/English.php rev. 1.9
+-----------------------------------------------------------------------------+
*/
 
setlocale(LC_ALL, 'pl_PL.ISO-8859-2', 'pl_PL.ISO8859-2', 'pl_PL@euro', 'pl_PL', 'pl', 'Polish', 'Polish_Poland');
define("CORE_LC", 'pl');
define("CORE_LC2", 'pl');
// define("TEXTDIRECTION","rtl");
define("CHARSET", "iso-8859-2");
define("CORE_LAN1","B��d : brak tematu.\\n\\nZmie� u�ywany temat w ustawieniach (panel administratora) lub za�aduj pliki aktualnie u�ywanego tematu na serwer.");

//v.616
define("CORE_LAN2"," \\1 napisa�:");// "\\1" reprezentuje nazw� u�ytkownika.
define("CORE_LAN3","wysy�anie plik�w zosta�o zablokowane");

//v0.7+
define("CORE_LAN4", "Prosz� usun�� plik install.php ze swojego serwera.");
define("CORE_LAN5", "Je�li tego nie zrobisz, mo�e istnie� ryzyko naruszenia bezpiecze�stwa na Twojej stronie internetowej.");

// v0.7.6
define("CORE_LAN6", "Ochrona przeciwko atakom typu flood na tej stronie zosta�a aktywowana. Ostrzegam, �e kontynuacja wywo�ywania tej strony mo�e spowodowa� dla Ciebie  zablokowanie dost�pu do serwisu.");
define("CORE_LAN7", "Usi�uj� przywr�ci� preferencje j�dra z automatycznej kopii bezpiecze�stwa.");
define("CORE_LAN8", "B��d preferencji j�dra");
define("CORE_LAN9", "J�dro nie mo�e zosta� przywr�cone z automatycznej kopii bezpiecze�stwa. Zatrzymano wykonywanie.");
define("CORE_LAN10", "Wykryto uszkodzony plik cookie - wyloguj si�.");


define("LAN_WARNING", "Ostrze�enie!");
define("LAN_ERROR", "B��d");
define("LAN_ANONYMOUS", "Anonim");

?>
