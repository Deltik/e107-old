<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_login.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_login.php rev. 1.12
+-----------------------------------------------------------------------------+
*/
 
define("LAN_27", "Nie wype�ni�e� wszystkich wymaganych p�l");
define("LAN_300", "B��d logowania. Wprowadzone dane nie pasuj� do �adnego u�ytkownika. Sprawd� czy masz wci�ni�ty klawisz <i>Caps Lock</i>, je�li tak - dezaktywuj go i spr�buj ponownie.");
define("LAN_302", "Twoje konto nie zosta�o jeszcze aktywowane. W najbli�szym czasie powiniene� otrzyma� email z instrukcj� aktywacji konta. Je�li go nie otrzyma�e�, prosz� klikn�� <a href='".e_BASE."signup.php?resend'>tutaj</a>.");
define("LAN_303", "Wprowadzony kod jest nieprawid�owy.");
define("LAN_304", "Podany login/has�o s� ju� w u�yciu.");
define("LAN_LOGIN_1", "Login");
define("LAN_LOGIN_2", "Has�o");
define("LAN_LOGIN_3", "Serwis chroniony");
define("LAN_LOGIN_4", "Poni�ej prosz� wpisa� wymagane dane, aby uzyska� dost�p do strony.");
define("LAN_LOGIN_5", "Kliknij tutaj, aby si� zalogowa�");
define("LAN_LOGIN_6", "W tej chwili nie przyjmujemy nowych u�ytkownik�w");
define("LAN_LOGIN_7", "Wpisz widoczny kod");
define("LAN_LOGIN_8", "Zapami�taj mnie");
define("LAN_LOGIN_9", "Zaloguj");
define("LAN_LOGIN_10", "Kliknij, aby si� zalogowa�");
define("LAN_LOGIN_11", "Rejestruj nowego u�ytkownika");
define("LAN_LOGIN_12", "Zapomnia�em has�a");
define("LAN_LOGIN_13", "Wpisz tekst z obrazka");

define("LAN_LOGIN_14", "Pr�ba logowania z nierozpoznan� nazw� u�ytkownika");
define("LAN_LOGIN_15", "Pr�ba logowania z niepoprawnym has�em");
define("LAN_LOGIN_16", "Pr�ba logowania z nazw� u�ytkownika/has�em, kt�re jest w u�yciu");
define("LAN_LOGIN_17", "Has�o u�ytkownika (hashed)");
define("LAN_LOGIN_18", "Auto-blokowanie: Wi�cej ni� 10 b��dnych logowa�");
define("LAN_LOGIN_19", "> 10 b��dnych pr�b logowania");

?>
