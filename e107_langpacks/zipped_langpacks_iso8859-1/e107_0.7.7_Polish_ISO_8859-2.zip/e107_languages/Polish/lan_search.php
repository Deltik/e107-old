<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_search.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_search.php rev. 1.12
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Wyszukiwanie");

define("LAN_98", "Aktualno�ci");
define("LAN_99", "Komentarze");
define("LAN_140", "Zarejestrowani u�ytkownicy");
define("LAN_180", "Szukaj");
define("LAN_192", "Wszystkie kategorie");
define("LAN_193", "Kalendarz wydarze�");
define("LAN_194", "Wszystkie kategorie");
define("LAN_195", "Przeszukuj�");
define("LAN_196", "trafie�");

define("LAN_197", "Download");
define("LAN_198", "Szukana fraza nie zosta�a odnaleziona");
define("LAN_199", "Szukaj:");
define("LAN_200", "Kategori�:");

define("LAN_201", "Prosz� zmieni� tre�� zapytania");
define("LAN_416", "Musisz si� zalogowa�, aby uzyska� dost�p do tej strony");
define("LAN_417", "Wyszukiwana fraza musi zawiera� przynajmniej 3 znaki.");

define("LAN_418", "Inne strony");

define("LAN_SEARCH_1", "Zaznacz wszystko");
define("LAN_SEARCH_2", "Odznacz wszystko");
define("LAN_SEARCH_3", "Dodane dnia ");
define("LAN_SEARCH_4", "Wynik znaleziono w tytule wiadomo�ci");
define("LAN_SEARCH_5", "Wynik znaleziono w tre�ci wiadomo�ci");
define("LAN_SEARCH_6", "Wynik znaleziono w rozszerzonym tre�ci wiadomo�ci");
define("LAN_SEARCH_7", "Dodane przez ");
define("LAN_SEARCH_8", " dnia ");
define("LAN_SEARCH_9", "Bez tytu�u");
define("LAN_SEARCH_10", "Id� do strony:");
define("LAN_SEARCH_11", "Wyniki");
define("LAN_SEARCH_12", " spo�r�d ");
define("LAN_SEARCH_13", " dla dzia�u ");
define("LAN_SEARCH_14", "Kategoria:");
define("LAN_SEARCH_15", "Autor:");
define("LAN_SEARCH_17", "Przepraszamy, szukanie jest ograniczone do pojedynczego wyszukiwania co ka�de ");
define("LAN_SEARCH_18", " sekund.");
define("LAN_SEARCH_19", "Przeszukaj dzia�:");
define("LAN_SEARCH_20", "Wymagana autoryzacja");
define("LAN_SEARCH_21", "Nie masz uprawnie� do przegl�dania tej strony.");



define("LAN_SEARCH_22", "Ca�y serwis");
define("LAN_SEARCH_23", "Rozszerzona forma zapytania");
define("LAN_SEARCH_24", "Musi zawiera� s�owa");
define("LAN_SEARCH_25", "Nie musi zawiera� s��w");
define("LAN_SEARCH_26", "Wymagane wyra�enie");
define("LAN_SEARCH_27", "S�owa rozpoczynaj�ce si� od");
define("LAN_SEARCH_28", "Wszystko bez zaawansowanego wyszukiwania");
define("LAN_SEARCH_29", "Podstawowe");
define("LAN_SEARCH_30", "Zaawansowane");
define("LAN_SEARCH_31", "Nie ma zaawansowanego wyszukiwania");
define("LAN_SEARCH_32", "Nast�puj�ce s�owa zosta�y usuni�te z wyszukiwania");
define("LAN_SEARCH_33", "Nast�puj�ce s�owo zosta�o usuni�te z wyszukiwania");
define("LAN_SEARCH_34", "Nowszy ni�");
define("LAN_SEARCH_35", "Starszy ni�");
define("LAN_SEARCH_36", "Kiedykolwiek");
define("LAN_SEARCH_37", "Jeden dzie�");
define("LAN_SEARCH_38", "Dwa dni");
define("LAN_SEARCH_39", "Trzy dni");
define("LAN_SEARCH_40", "Jeden tydzie�");
define("LAN_SEARCH_41", "Dwa tygodnie");
define("LAN_SEARCH_42", "Trzy tygodnie");
define("LAN_SEARCH_43", "Jeden miesi�c");
define("LAN_SEARCH_44", "Dwa miesi�ce");
define("LAN_SEARCH_45", "Trzy miesi�ce");
define("LAN_SEARCH_46", "P� roku");
define("LAN_SEARCH_47", "Rok");
define("LAN_SEARCH_48", "Dwa lata");
define("LAN_SEARCH_49", "Trzy lata");

define("LAN_SEARCH_50", "Data wpisu");
define("LAN_SEARCH_51", "Wszystkie kategorie");
define("LAN_SEARCH_52", "Pokazuj");
define("LAN_SEARCH_53", "Ca�� pozycj�");
define("LAN_SEARCH_54", "Tylko tytu�");
define("LAN_SEARCH_55", "Szukaj w kategorii aktualno�ci");
define("LAN_SEARCH_56", "Wszystkie kategorie aktualno�ci");
define("LAN_SEARCH_57", "Komentarzach dodanych do");
define("LAN_SEARCH_58", "Wszystkie obszary");
define("LAN_SEARCH_59", "Wszystkie komentarze");
define("LAN_SEARCH_60", "Komentarzach dodanych do");
define("LAN_SEARCH_61", "Autora");
define("LAN_SEARCH_62", "Data do��czenia");
define("LAN_SEARCH_63", "Szukaj w kategorii");
define("LAN_SEARCH_64", "Wszystkie kategorie downloadu");
define("LAN_SEARCH_65", "Pliki do pobrania");
define("LAN_SEARCH_66", "Data dodania");
define("LAN_SEARCH_67", "Wszystkie szczeg�y plik�w do pobierania");
define("LAN_SEARCH_68", "Data");
define("LAN_SEARCH_69", "Trafno��");

define("LAN_SEARCH_70", "Dopisano pozycj� do downloadu");
define("LAN_SEARCH_71", "W odpowiedziach do pozycji wiadomo�ci");
define("LAN_SEARCH_72", "Sygnatura");
define("LAN_SEARCH_73", "Bez sygnatury.");
define("LAN_SEARCH_74", "Do��czy�(a) dnia");

define("LAN_SEARCH_75", "Spos�b wyszukiwania");
define("LAN_SEARCH_76", "Wyszukuj na stronie");
define("LAN_SEARCH_77", "Wyszukuj w opisie strony");

?>
