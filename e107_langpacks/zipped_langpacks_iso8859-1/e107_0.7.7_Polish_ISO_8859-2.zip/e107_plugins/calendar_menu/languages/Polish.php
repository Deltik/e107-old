<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.8 $
|     $Date: 2006/11/19 18:01:15 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/calendar_menu/languages/Polish.php,v $
|
|     Various mods by steved:
|     a) To reflect updates
|     b) To reflect CVS update to version 1.14 made 29.10.06
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/calendar_menu/languages/English.php rev. 1.18
+-----------------------------------------------------------------------------+
*/
 
define('EC_ADLAN_1', "Kalendarz wydarze�");
define('EC_ADLAN_2', "Konfiguruj kalendarz wydarze�");
define('EC_INSTALL', "Instaluj kalendarz wydarze�");
define('EC_UNINSTALL', "Odinstaluj kalendarz wydarze�");
define('EC_LAN_TODAY', "dzisiaj");

define('EC_LAN_DAY_1', "1");
define('EC_LAN_DAY_2', "2");
define('EC_LAN_DAY_3', "3");
define('EC_LAN_DAY_4', "4");
define('EC_LAN_DAY_5', "5");
define('EC_LAN_DAY_6', "6");
define('EC_LAN_DAY_7', "7");
define('EC_LAN_DAY_8', "8");
define('EC_LAN_DAY_9', "9");
define('EC_LAN_DAY_10', "10");
define('EC_LAN_DAY_11', "11");
define('EC_LAN_DAY_12', "12");
define('EC_LAN_DAY_13', "13");
define('EC_LAN_DAY_14', "14");
define('EC_LAN_DAY_15', "15");
define('EC_LAN_DAY_16', "16");
define('EC_LAN_DAY_17', "17");
define('EC_LAN_DAY_18', "18");
define('EC_LAN_DAY_19', "19");
define('EC_LAN_DAY_20', "20");
define('EC_LAN_DAY_21', "21");
define('EC_LAN_DAY_22', "22");
define('EC_LAN_DAY_23', "23");
define('EC_LAN_DAY_24', "24");
define('EC_LAN_DAY_25', "25");
define('EC_LAN_DAY_26', "26");
define('EC_LAN_DAY_27', "27");
define('EC_LAN_DAY_28', "28");
define('EC_LAN_DAY_29', "29");
define('EC_LAN_DAY_30', "30");
define('EC_LAN_DAY_31', "31");

define('EC_LAN_0', "Stycze�");
define('EC_LAN_1', "Luty");
define('EC_LAN_2', "Marzec");
define('EC_LAN_3', "Kwiecie�");
define('EC_LAN_4', "Maj");
define('EC_LAN_5', "Czerwiec");
define('EC_LAN_6', "Lipiec");
define('EC_LAN_7', "Sierpie�");
define('EC_LAN_8', "Wrzesie�");
define('EC_LAN_9', "Pa�dziernik");
define('EC_LAN_10', "Listopad");
define('EC_LAN_11', "Grudzie�");
define('EC_LAN_JAN', "Sty");
define('EC_LAN_FEB', "Lut");
define('EC_LAN_MAR', "Mar");
define('EC_LAN_APR', "Kwi");
define('EC_LAN_MAY', "Maj");
define('EC_LAN_JUN', "Cze");
define('EC_LAN_JUL', "Lip");
define('EC_LAN_AUG', "Sie");
define('EC_LAN_SEP', "Wrz");
define('EC_LAN_OCT', "Pa�");
define('EC_LAN_NOV', "Lis");
define('EC_LAN_DEC', "Gru");
define('EC_LAN_12', "Poniedzia�ek");
define('EC_LAN_13', "Wtorek");
define('EC_LAN_14', "�roda");
define('EC_LAN_15', "Czwartek");
define('EC_LAN_16', "Pi�tek");
define('EC_LAN_17', "Sobota");
define('EC_LAN_18', "Niedziela");
define('EC_LAN_19', "Pon");
define('EC_LAN_20', "Wto");
define('EC_LAN_21', "�ro");
define('EC_LAN_22', "Czw");
define('EC_LAN_23', "Pi�");
define('EC_LAN_24', "Sob");
define('EC_LAN_25', "Nie");
define('EC_LAN_26', "Wydarzenia miesi�ca");
define('EC_LAN_27', "W tym miesi�cu nie ma �adnych wydarze�.");
define('EC_LAN_28', "Zapisz nowe wydarzenie");
define('EC_LAN_29', "Rozpocz�cie:");
define('EC_LAN_30', "Kategoria:");
define('EC_LAN_31', "Autor:");
define('EC_LAN_32', "Miejsce:");
define('EC_LAN_33', "Kontakt:");
define('EC_LAN_34', "Skocz do");
define('EC_LAN_35', "Edytuj");
define('EC_LAN_36', "Usu�");
define('EC_LAN_37', "Nie sporz�dzono jeszcze listy.");
define('EC_LAN_38', "Nie okre�lono");
define('EC_LAN_39', "Kliknij tutaj, aby uzyska� wi�cej informacji");
define('EC_LAN_40', "Poka� bie��cy miesi�c");
define('EC_LAN_41', "Nowa kategoria zosta�a utworzona.");
define('EC_LAN_42', "Wydarzenie nie mo�e si� zako�czy� przed swoim rozpocz�ciem.");
define('EC_LAN_43', "Wymagane pola pozosta�y puste.");
define('EC_LAN_44', "Nowe wydarzenie zosta�o utworzone i dodane do bazy danych.");
define('EC_LAN_45', "Wydarzenie zosta�o zaktualizowane w bazie danych.");
define('EC_LAN_46', "Potwierdzenie usuni�cia wydarzenia");
define('EC_LAN_47', "Usuwanie zosta�o anulowane.");
define('EC_LAN_48', "Potwierd� ch�� usuni�cia wskazanego wydarzenia - jak tylko zostanie ono usuni�te nie b�dzie mo�liwe do odzyskania");
define('EC_LAN_49', "Anuluj");
define('EC_LAN_50', "Potwierd� usuni�cie");
define('EC_LAN_51', "Wydarzenie zosta�o usuni�te.");
define('EC_LAN_52', "Kategoria wydarzenia:");
define('EC_LAN_53', "Utworzy� now� kategori�?:");
define('EC_LAN_54', "Nazwa:");
define('EC_LAN_55', "Ikona:");
define('EC_LAN_56', "Utw�rz");
define('EC_LAN_57', "Wydarzenie:");
define('EC_LAN_58', "Adres URL do �r�d�a informacji:");
define('EC_LAN_59', "Kontaktowy email:");
define('EC_LAN_60', "Aktualizuj wydarzenie");
define('EC_LAN_61', "Dalej");
define('EC_LAN_62', "Nadchodz�ce wydarzenia - -NUM-");
define('EC_LAN_63', "Zaznacz to, je�li wydarzenie odbywa si� tego samego dnia ka�dego roku, np. urodziny, imieniny, rocznica itp.");
define('EC_LAN_64', "Zaznacz pole dla wydarze� ca�odniowych");
define('EC_LAN_65', "Wydarzenie powtarzaj�ce si�:");
define('EC_LAN_66', "Edycja wydarzenia");
define('EC_LAN_67', "Rozpocz�cie:");
define('EC_LAN_68', "Wydarzenie ca�odniowe:");
define('EC_LAN_69', "Zako�czenie:");
define('EC_LAN_70', "Nazwa wydarzenia:");
define('EC_LAN_71', "Godzina wydarzenia:");
define('EC_LAN_72', "Data wydarzenia:");
define('EC_LAN_73', "Zako�czenie:");
//define('edesc_LAN_0', "Odliczanie");
//define('edesc_LAN_1', "Od tej pory "); 
//define('edesc_LAN_2', "do wydarzenie dnia w serwisie ".SITENAME); //before event on
//define('edesc_LAN_3', "sek");
//define('edesc_LAN_4', "sek");
//define('edesc_LAN_5', "min");
//define('edesc_LAN_6', "min");
//define('edesc_LAN_7', "h");
//define('edesc_LAN_8', "h");
//define('edesc_LAN_9', "dzie�");
//define('edesc_LAN_10', "dni");
define('EC_LAN_VIEWCALENDAR', "Przegl�daj kalendarz");
define('EC_LAN_VIEWALLEVENTS', "Przegl�daj wszystkie wydarzenia");
define('EC_LAN_ALLEVENTS', "Wszystkie wydarzenia");
define('EC_LAN_74', "Przegl�daj kategorie");
// ADMIN
define('EC_LAN_75', "Ustawienia kalendarza zosta�y zaktualizowane.");
define('EC_LAN_76', "Wydarzenia mog� by� dodawane przez:");
define('EC_LAN_77', "Aktualizuj ustawienia");
define('EC_LAN_78', "Ustawienia kalendarza");
define('EC_LAN_79', "Kalendarz");
define('EC_LAN_80', "Lista wydarze�");
define('EC_LAN_81', "Konfiguracja Kalendarza wydarze�");
define('EC_LAN_82', "Aby aktywowa�, prosz� przej�� do <i>Panelu administratora - Menu</i> i aktywowa� <i>calendar_menu</i> w jednym z dost�pnych obszar�w.");
define('EC_LAN_83', "Kalendarz");

//define('EC_LAN_84', "Zastosowany styl CSS dla nag��wka dnia");
//define('EC_LAN_85', "Domy�lny jest 'forumheader'");
//define('EC_LAN_86', "Zastosowany styl CSS dla listy dni");
//define('EC_LAN_87', "Domy�lny jest 'forumheader3'");
//define('EC_LAN_88', "Zastosowany styl CSS dla wybranego dnia");
//define('EC_LAN_89', "Domy�lny jest 'indent'");

//  *BK* Corrections to hard coding by Barry 
define('EC_LAN_90', "Wybierz");	
define('EC_LAN_91', "Nie zdefiniowane");	
define('EC_LAN_92', "Przegl�daj kategori�");		
define('EC_LAN_93', "Przegl�d listy wydarze�");		
define('EC_LAN_94', "Dodaj nowe wydarzenie");			
define('EC_LAN_95', "Dzisiaj");	
define('EC_LAN_96', "Przegl�daj kalendarz");	
define('EC_LAN_97', "Wszystkie");		
define('EC_LAN_98', "Wymagane pola pozosta�y puste");		
define('EC_LAN_99', "Wydarzenie musi by� wydarzeniem ca�odniowym lub ko�czy� si� o danej godzinie po rozpocz�ciu, a nie np. przed nim. Wszystkie inne przypadki s� niedozwolone.");			
//define('EC_LAN_100', "Kategorie mog� by� dodawane przez:");			
//define('EC_LAN_101', "Ustawienie na Nikt (nieaktywne), wy��czy formularz nowego wydarzenia.");	
define('EC_LAN_102', "Pokazuj link 'wi�cej informacji' dla danego wydarzenia");	
//define('EC_LAN_103', "Dotyczy tylko formularza do dodawania nowych wydarze�.");
define('EC_LAN_104', "Grupa administracyjna kalendarza");		
define('EC_LAN_105', "* wymagane pola");		
define('EC_LAN_106', "Wydarzenia");		
define('EC_LAN_107', "Ten plugin to w pe�ni funkcjonalny kalendarz wydarze� wraz z menu w postaci kalendarza do wy�wietlenia na stronie.");		
define('EC_LAN_108', "Kalendarz Wydarze� zosta� zaktualizowany do nowszej wersji. Zapoznaj si� z plikiem 'readme.pdf', aby uzyska� szczeg�owe informacje.");	
define('EC_LAN_109', "Nie mog� usun�� wskazanego wydarzenia.");	
define('EC_LAN_110', "Numer wydarzenia ");	
define('EC_LAN_111', "Wszystkie wydarzenia na miesi�c ");	
define('EC_LAN_112', "Wszystkie wydarzenia na miesi�c ");	
define('EC_LAN_113', "Formularz wydarzenia zosta� ju� wys�any.");
define('EC_LAN_114', "Tydzie� rozpocznie si� od dnia:");
define('EC_LAN_115', "Niedziela");
define('EC_LAN_116', "Poniedzia�ek");
define('EC_LAN_117', "D�ugo�� nazwy dnia (ilo�� znak�w)");
define('EC_LAN_118', "Format daty w nag��wku kalendarza:");
define('EC_LAN_119', "miesi�c/rok");
define('EC_LAN_120', "rok/miesi�c");
define('EC_LAN_121', "Kalendarz");	
//define('EC_LAN_122', "Zastosowany element stylu CSS do wy�wietlania wydarze� na dany dzie� (menu)");	
define('EC_LAN_123', "Subskrypcja");
define('EC_LAN_124', "Subskrypcja kalendarza");
define('EC_LAN_125', "Kategorie dost�pne do subskrypcji");
define('EC_LAN_126', "Zaprenumerowane");
define('EC_LAN_127', "Kategoria");
define('EC_LAN_128', "Aktualnie nie ma �adnych kategorii do zam�wienia subskrypcji");
define('EC_LAN_129', "Aktualizuj");
define('EC_LAN_130', "Subskrypcja zosta�a zaktualizowana");
define('EC_LAN_131', "Powr�t");
define('EC_LAN_132', "Rozwi� szczeg�y");
define('EC_LAN_133', "[czytaj wi�cej]");
define('EC_LAN_134', "Musisz okre�li� nazw� kategorii");
define('EC_LAN_135', "Wydarzenie");
define('EC_LAN_136', "Opis kategorii");
define('EC_LAN_137', "Przysz�e wydarzenia");

// Added 12.07.06 for next_event_menu.php
define('EC_LAN_140', "Nadchodz�ce wydarzenia");
define('EC_LAN_141', "Nie ma nadchodz�cych wydarze�");
define('EC_LAN_142', "Tylko zarejestrowani i jednocze�nie zalogowani u�ytkownicy mog� subskrybowa� wydarzenia");
define('EC_LAN_143', "Brak mo�liwo�ci"); // Facility not available 
define('EC_LAN_144', " w ");

define('EC_ADLAN_A10', "Konfiguracja");
define('EC_ADLAN_A11', "Kategorie");
define('EC_ADLAN_A12', "Kalendarz");
define('EC_ADLAN_A13', "Edytuj");
define('EC_ADLAN_A14', "Nowy");
define('EC_ADLAN_A15', "Usu�");
define('EC_ADLAN_A16', "Potwierd�");
define('EC_ADLAN_A17', "Przejd� dalej");
define('EC_ADLAN_A18', "Dzia�ania");
define('EC_ADLAN_A19', "Zarz�dzanie kategoriami");
define('EC_ADLAN_A20', "Kategorie kalendarza");
define('EC_ADLAN_A21', "Nazwa kategorii");

define('EC_ADLAN_A23', "Utw�rz kategori�");
define('EC_ADLAN_A24', "Edycja kategorii");
define('EC_ADLAN_A25', "Zapisz");
define('EC_ADLAN_A26', "Kategoria zosta�a utworzona");
define('EC_ADLAN_A27', "Nie mog� utworzy� kategorii");
define('EC_ADLAN_A28', "Zmiany zosta�y zapisane");
define('EC_ADLAN_A29', "Nie mog� zapisa� zmian");

define('EC_ADLAN_A30', "Kategoria zosta�a usuni�ta");
define('EC_ADLAN_A31', "Zaznacz pole, aby usun��");
define('EC_ADLAN_A32', "Nie mog� usun�� wskazanej kategorii");
define('EC_ADLAN_A33', "Nie zdefiniowano");
define('EC_ADLAN_A34', "Grupa administracyjna kalendarza");
define('EC_ADLAN_A35', "");
define('EC_ADLAN_A59', "Wskazana kategoria jest w u�yciu. Usuwanie jest niemo�liwe.");

define('EC_ADLAN_A80', "Widoczne dla");
define('EC_ADLAN_A81', "Zezw�l na subskrypcj�");
define('EC_ADLAN_A82', "Wymuszaj powiadamianie grupy");
define('EC_ADLAN_A83', "Wysy�aj na prz�d powiadomienie o wydarzeniu (ilo�� dni)");
define('EC_ADLAN_A84', "Zaawansowana wiadomo��");
define('EC_ADLAN_A85', "Wiadomo�� na ten dzie�");
define('EC_ADLAN_A86', "Wysy�anie wiadomo�ci email");
define('EC_ADLAN_A87', "Nie");
define('EC_ADLAN_A88', "Tylko rozszerzona");
define('EC_ADLAN_A89', "Tylko na dany dzie�");
define('EC_ADLAN_A90', "Zaawansowana oraz na dany dzie�");
define('EC_ADLAN_A91', "Temat emaila");
define('EC_ADLAN_A92', "Email od (nazwa)");
define('EC_ADLAN_A93', "Zwrotny adres email");
define('EC_ADLAN_A94', "Grupa z uprawnieniem dodawania nowych wydarze�");
define('EC_ADLAN_A95', "Udost�pni� r�czne subskrypcje?");
define('EC_ADLAN_A96', "Wy��czenie tej opcji spowoduje usuni�cie przycisku subskrypcji oraz uniewa�ni wszystkie ustawienia r�cznej subskrypcji kategorii.");
//define('EC_ADLAN_A97', "Je�li ustawisz wymuszenie subskrypcji tej kategorii, nie zostanie ona wy�wietlona na li�cie dost�pnych subskrypcji dla u�ytkownik�w.");

// Added from here 12.07.06 for forthcoming events and mailout upgrades
define('EC_ADLAN_A100', "Nadchodz�ce wydarzenia");
define('EC_ADLAN_A101', "Ilo�� dni do przodu branych pod uwag�:");
define('EC_ADLAN_A102', "Ilo�� wy�wietlanych wydarze�:");
define('EC_ADLAN_A103', "Zawrzyj powtarzaj�ce si� wydarzenia:");
define('EC_ADLAN_A104', "Tytu� jest linkiem do listy wydarze�:");
define('EC_ADLAN_A105', "Konfiguracja menu Nadchodz�ce Wydarzenia");
define('EC_ADLAN_A106', "Menu zosta�o aktywowane na stronie 'Menu'");
define('EC_ADLAN_A107', "Nie dzia�a poprawnie, je�li ilo�� dni branych pod uwag� jest wi�ksza nic 59");
define('EC_ADLAN_A108', "Nag��wek menu");
define('EC_ADLAN_A109', "Preferencje zosta�y zaktualizowane");

define('EC_ADLAN_A110', "Tylko w poprzedzaj�cym dniu");
define('EC_ADLAN_A111', "Zaawansowana w poprzedzaj�cym dniu");
define('EC_ADLAN_A112', "Poprzedni dzie� oraz dany dzie�");
define('EC_ADLAN_A113', "Zaawansowana, poprzedni dzie� oraz dany dzie�");

define('EC_ADLAN_A114', "Rejestracja emaili");
define('EC_ADLAN_A115', "Skr�cona");
define('EC_ADLAN_A116', "Szczeg�owa");
define('EC_ADLAN_A117', "Wiadomo�� na dany dzie� lub poprzedzaj�cy dzie�");
define('EC_ADLAN_A118', "Kategorie do wy�wietlenia");
define('EC_ADLAN_A119', "Brak zdefiniowanych kategorii lub b��d odczytu bazy danych");
define('EC_ADLAN_A120', "Pokazuj ikon� kategorii w menu");
define('EC_ADLAN_A121', "Opis kategorii");
define('EC_ADLAN_A122', "�r�d�o czasu kalendarza");
define('EC_ADLAN_A123', "Format czasu kalendarza");
define('EC_ADLAN_A124', "Obecny czas serwera: ");
define('EC_ADLAN_A125', "Obecny czas strony: ");
define('EC_ADLAN_A126', "Obecny czas uzytkownika: ");
define('EC_ADLAN_A127', "Okre�la wy�wietlany format czasu przez ca�y kalendarz wydarze�.");
define('EC_ADLAN_A128', "Opcja czasu 'Custom' u�ywa formatu z pola po prawej stronie");
define('EC_ADLAN_A129', '"Czas strony" u�ywa przesuni�cia zdefiniowanego w preferencjach');
define('EC_ADLAN_A130', "Nazwa wydarzenia jest linkiem do:");
define('EC_ADLAN_A131', "Kalendarza wydarze�");
define('EC_ADLAN_A132', "�r�d�a informacji - URL");
define('EC_ADLAN_A133', "Format daty dla wydarze�: ");
define('EC_ADLAN_A134', "Poziom zapisywanych zmian w logu administracyjnym:");
define('EC_ADLAN_A135', "Edytuj/usu�");
define('EC_ADLAN_A136', "Wszystkie zmiany");
define('EC_ADLAN_A137', "Mo�e obj�� dodawania do oraz usuwanie z listy wydarze�, a tak�e aktualizacje");
define('EC_ADLAN_A138', "Czas rozpocz�cia/zako�czenia wydarzenia na granicy 5 minut");
define('EC_ADLAN_A139', "(Redukuje ilo�c wpis�w na rozwijalnej li�cie)");
define('EC_ADLAN_A140', "Pokazuj ilo�� wydarze� dla danego miesi�ca w menu kalendarza");
define('EC_ADLAN_A141', "Konserwacja");
define('EC_ADLAN_A142', "Usu� minione wydarzenia zako�czone wi�cej ni� x miesi�cy temu");
define('EC_ADLAN_A143', "czas jest mierzony od rozpoczynaj�cego sie obecnie miesi�ca");
define('EC_ADLAN_A144', "Konserwacja kalendarza wydarze�");
define('EC_ADLAN_A145', "Usu� stare wpisy");
define('EC_ADLAN_A146', "Wydarzenia starsze ni� ");
define('EC_ADLAN_A147', " zosta�y usuni�te");
define('EC_ADLAN_A148', "B��d parametru - nic nie usuni�to");
define('EC_ADLAN_A149', "Brak starych wydarze� do usuni�cia lub usuni�cie przesz�ych wydarze� zawiod�o.");
define('EC_ADLAN_A150', "Potwierd� usuni�cie wydarze� starszych ni� ");

define('EC_ADLAN_A151', "e107 Web Site");
define('EC_ADLAN_A152', "kalendarz@twojastrona.com");
define('EC_ADLAN_A153', "Katalog log�w musi zosta� utworzony r�cznie - utw�rz podkatalog 'log' w�r�d katalog�w wtyczki 'Kalendarz wydarze�' z prawami dost�pu '666'");
define('EC_ADLAN_A154', "Nie mog� zmieni� uprawnie� katalogu 'log'");
define('EC_ADLAN_A155', "Uprawnienia katalogu log�w mog� wymaga� r�cznej aktualizacji do CHMOD 0666 lub CHMOD 0766, chocia� zale�nie od instalacji serwera mog� one dzia�a�");
define('EC_ADLAN_A156', "Baza danych zosta�a zaktualizowana");
define('EC_ADLAN_A157', "Kana� RSS dla wpis�w z Kalendarza Wydarze�");
define('EC_ADLAN_A158', "Nie mog� utworzy� katalogu 'log'");

define('EC_ADLAN_A159', "Zarz�dzanie pami�ci� podr�czn�");
define('EC_ADLAN_A160', "(Stosowane tylko, je�li pami�� podr�czna jest aktywna)");
define('EC_ADLAN_A161', "Opr�nij pami�� podr�czn� kalendarza");
define('EC_ADLAN_A162', "Potwierd� opr�nienie pami�ci podr�cznej");
define('EC_ADLAN_A163', "Pami�� podr�czna zosta�a opr�niona");

define('EC_ADLAN_A164', "Akualizacja zako�czona pomyslnie");
define('EC_ADLAN_A165', "Nag��wek kalendarza wydarze� jest linkiem do:");
define('EC_ADLAN_A166', "Wy�wietlana data na 'Li�cie wydarze�':");
define('EC_ADLAN_A167', "Wy�wietlana data w menu 'Nadchodz�ce wydarzenia':");
define('EC_ADLAN_A168', "Opcja 'Custom' u�ywa formatu daty z pola po prawej stronie");
define('EC_ADLAN_A169', "Okre�la format wy�wietlanej daty dla wykazu wydarze�");
define('EC_ADLAN_A170', "Okre�la format wy�wietlanej daty dla menu nadchodz�cych wydare�");
define('EC_ADLAN_A171', "Oznaczenia ostatnio dodanych/zaktualizowanych wydarze�");
define('EC_ADLAN_A172', "Warto�ci� jest czas od aktualizacji w godzinach; zero oznacza wy��czon� opcj�");


// Notify
define("NT_LAN_EC_1", "Wydarzenie - Kalendarz Wydarze�");
define("NT_LAN_EC_2", "Wydarzenie zaktualizowane");
define("NT_LAN_EC_3", "Zaktualizowane przez");
define("NT_LAN_EC_4", "Adres IP");
define("NT_LAN_EC_5", "Wiadomo��");
define("NT_LAN_EC_6", "Kalendarz wydarze� - Wydarzenie dodane");
define("NT_LAN_EC_7", "Nowe wydarzenie dodane");
define("NT_LAN_EC_8", "Kalendarz Wydarze� - Wydarzenie zmodyfikowane");

?>
