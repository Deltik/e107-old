<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.16 $
|     $Date: 2006/11/19 17:04:16 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/content/languages/Polish/lan_content.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/content/languages/English/lan_content.php rev. 1.74
+-----------------------------------------------------------------------------+
*/
 
define("CONTENT_EMAILPRINT_LAN_1", "Ta publikacja pochodzi ze strony"); 

define("POPUP_LAN_1", "Kliknij. aby powi�kszy� obrazek");

define("CONTENT_NOTIFY_LAN_1", "Publikacje - wydarzenia");
define("CONTENT_NOTIFY_LAN_2", "Publikacje nades�ane przez u�ytkownika");
define("CONTENT_NOTIFY_LAN_3", "Nades�ane publikacje");

define("CONTENT_TYPE_LAN_0", "kategorie");
define("CONTENT_TYPE_LAN_1", "autorzy");
define("CONTENT_TYPE_LAN_2", "archiwum");
define("CONTENT_TYPE_LAN_3", "najlepiej ocenione");
define("CONTENT_TYPE_LAN_4", "najlepszy wynik");
define("CONTENT_TYPE_LAN_5", "ostatnio dodane");

define("CONTENT_ICON_LAN_0", "Edytuj");
define("CONTENT_ICON_LAN_1", "Usu�");
define("CONTENT_ICON_LAN_2", "Opcje");
define("CONTENT_ICON_LAN_3", "Informacje o autorze");
define("CONTENT_ICON_LAN_4", "Za��cznik do pobrania");
define("CONTENT_ICON_LAN_5", "Nowy");
define("CONTENT_ICON_LAN_6", "Wy�lij publikacj�");
define("CONTENT_ICON_LAN_7", "Publikacje autora");
define("CONTENT_ICON_LAN_8", "Ostrze�enie");
define("CONTENT_ICON_LAN_9", "OK");
define("CONTENT_ICON_LAN_10", "B��d");
define("CONTENT_ICON_LAN_11", "Kolejno�� pozycji w kategorii");
define("CONTENT_ICON_LAN_12", "kolejno�� pozycji w dziale g��wnym");
define("CONTENT_ICON_LAN_13", "administrator dzia�u");
define("CONTENT_ICON_LAN_14", "Osobisty mened�er ");
define("CONTENT_ICON_LAN_15", "Przejrzyj");

define("CONTENT_ADMIN_DATE_LAN_0", "Stycznia");
define("CONTENT_ADMIN_DATE_LAN_1", "Lutego");
define("CONTENT_ADMIN_DATE_LAN_2", "Marca");
define("CONTENT_ADMIN_DATE_LAN_3", "Kwietnia");
define("CONTENT_ADMIN_DATE_LAN_4", "Maja");
define("CONTENT_ADMIN_DATE_LAN_5", "Czerwca");
define("CONTENT_ADMIN_DATE_LAN_6", "Lipca");
define("CONTENT_ADMIN_DATE_LAN_7", "Sierpnia");
define("CONTENT_ADMIN_DATE_LAN_8", "Wrze�nia");
define("CONTENT_ADMIN_DATE_LAN_9", "Pa�dziernika");
define("CONTENT_ADMIN_DATE_LAN_10", "Listopada");
define("CONTENT_ADMIN_DATE_LAN_11", "Grudnia");
define("CONTENT_ADMIN_DATE_LAN_12", "dzie�");
define("CONTENT_ADMIN_DATE_LAN_13", "miesi�c");
define("CONTENT_ADMIN_DATE_LAN_14", "rok");
define("CONTENT_ADMIN_DATE_LAN_15", "Data rozpocz�cia");
define("CONTENT_ADMIN_DATE_LAN_16", "Data zako�czenia");
define("CONTENT_ADMIN_DATE_LAN_17", "Tutaj mo�esz ustali� dat�, od kt�rej ta publikacja b�dzie widoczna na stronie. Je�li u�yjesz daty, kt�ra jeszcze nie nast�pi�a, publikacja b�dzie widoczna dopiero od wybranego przez Ciebie czasu. Je�li natomiast chcesz opublikowa� ten materia� od zaraz, pozostaw te pola bez zmian.");
define("CONTENT_ADMIN_DATE_LAN_18", "Tutaj mo�esz ustali� dat� zako�czenia wy�wietlania publikacji. Za pomoc� daty zako�czenia mo�esz okre�li�, do kt�rego momentu czasu wskazana publikacja ma by� widoczna. Je�li chcesz, aby ta publikacja by�a widoczna przez ca�y czas od daty rozpocz�cia pozostaw te pola bez zmian.");

define("CONTENT_PAGETITLE_LAN_0", "Publikacje");
define("CONTENT_PAGETITLE_LAN_1", "Strona g��wna");
define("CONTENT_PAGETITLE_LAN_2", "Ostatnio dodane");
define("CONTENT_PAGETITLE_LAN_3", "Kategorie");
define("CONTENT_PAGETITLE_LAN_4", "Najlepiej oceniane");
define("CONTENT_PAGETITLE_LAN_5", "Autor:");
define("CONTENT_PAGETITLE_LAN_6", "Archiwum");
define("CONTENT_PAGETITLE_LAN_7", "Wysy�anie publikacji");
define("CONTENT_PAGETITLE_LAN_8", "Wy�lij publikacj�");
define("CONTENT_PAGETITLE_LAN_9", "Osobisty mened�er publikacji");
define("CONTENT_PAGETITLE_LAN_10", "Przegl�daj pozycj�");
define("CONTENT_PAGETITLE_LAN_11", "Edytuj pozycj�");
define("CONTENT_PAGETITLE_LAN_12", "Utw�rz pozycj�");
define("CONTENT_PAGETITLE_LAN_13", "Kategorie");
define("CONTENT_PAGETITLE_LAN_14", "Autorzy publikacji");
define("CONTENT_PAGETITLE_LAN_15", "Najlepsze wyniki");

define("CONTENT_SEARCH_LAN_0", "Nie znaleziono publikacji ze wskazanym has�em.");

define("CONTENT_ORDER_LAN_0", "Sortuj wed�ug...");
define("CONTENT_ORDER_LAN_1", "tematu (rosn�co)");
define("CONTENT_ORDER_LAN_2", "tematu (malej�co)");
define("CONTENT_ORDER_LAN_3", "daty (rosn�co)");
define("CONTENT_ORDER_LAN_4", "daty (malej�co)");
define("CONTENT_ORDER_LAN_5", "ods�on (rosn�co)");
define("CONTENT_ORDER_LAN_6", "ods�on (malej�co)");
define("CONTENT_ORDER_LAN_7", "dzia��w (rosn�co)");
define("CONTENT_ORDER_LAN_8", "dzia��w (malej�co)");
define("CONTENT_ORDER_LAN_9", "kolejno�ci (rosn�co)");
define("CONTENT_ORDER_LAN_10", "kolejno�ci (malej�co)");
define("CONTENT_ORDER_LAN_11", "autora (rosn�co)");
define("CONTENT_ORDER_LAN_12", "autora (malej�co)");

define("CONTENT_LAN_0", "Publikacje");
define("CONTENT_LAN_1", "Ostatnio dodane");
define("CONTENT_LAN_2", "Lista kategorii");
define("CONTENT_LAN_3", "Kategoria");
define("CONTENT_LAN_4", "Publikacje autora");
define("CONTENT_LAN_5", "Autor:");
define("CONTENT_LAN_6", "Kategorie");
define("CONTENT_LAN_7", "Autorzy publikacji");
define("CONTENT_LAN_8", "Najlepiej oceniane");
define("CONTENT_LAN_9", "Dzia�:");
define("CONTENT_LAN_10", "Data publikacji:");
define("CONTENT_LAN_11", "Autor:");
define("CONTENT_LAN_12", "Najlepsze wyniki");
define("CONTENT_LAN_13", "lista");
define("CONTENT_LAN_14", "-- kategorie --");
define("CONTENT_LAN_15", "Brak autor�w");
define("CONTENT_LAN_16", "");
define("CONTENT_LAN_17", "");
define("CONTENT_LAN_18", "Szukana fraza");
define("CONTENT_LAN_19", "Szukaj");
define("CONTENT_LAN_20", "Wyniki przeszukiwania publikacji");
define("CONTENT_LAN_21", "Obecnie nie ma jeszcze utworzonych �adnych publikacji.");
define("CONTENT_LAN_22", "Publikacje");
define("CONTENT_LAN_23", "Ostatnio dodane publikacje");
define("CONTENT_LAN_24", "Szybka nawigacja");  // Aktualnie jeste� w dziale - sprawdzi� czy pasuje
define("CONTENT_LAN_25", "Kategorie publikacji");
define("CONTENT_LAN_26", "Kategoria publikacji");
define("CONTENT_LAN_27", "Podkategorie");
define("CONTENT_LAN_28", "Podkategorie dzia�u");
define("CONTENT_LAN_29", "Nieznany");
define("CONTENT_LAN_30", "Pozycja publikacji");
define("CONTENT_LAN_31", "Publikacje");
define("CONTENT_LAN_32", "Autorzy publikacji");
define("CONTENT_LAN_33", "Przejd� do strony");
define("CONTENT_LAN_34", "Publikacje");
define("CONTENT_LAN_35", "komentarze");
define("CONTENT_LAN_36", "Moderuj komentarze");
define("CONTENT_LAN_37", "Obecnie nie ma ocenionych publikacji.");
define("CONTENT_LAN_38", "Najlepiej oceniane publikacje");
define("CONTENT_LAN_39", "Publikacje autora");
define("CONTENT_LAN_40", "Informacje o autorze");
define("CONTENT_LAN_41", "Za��czony");
define("CONTENT_LAN_42", "plik");
define("CONTENT_LAN_43", "plik");
define("CONTENT_LAN_44", "Ods�on:");
define("CONTENT_LAN_45", "Autor przyzna� wynik:");
define("CONTENT_LAN_46", "Spis tre�ci");
define("CONTENT_LAN_47", "Autor:");
define("CONTENT_LAN_48", "Pozycje publikacji");
define("CONTENT_LAN_49", "Ostatnio dodane publikacje");
define("CONTENT_LAN_50", "Data");
define("CONTENT_LAN_51", "Rodzaje");
define("CONTENT_LAN_52", "Nie znaleziono autora");
define("CONTENT_LAN_53", "pozycja");
define("CONTENT_LAN_54", "pozycji");
define("CONTENT_LAN_55", "Ostatnia pozycja dnia");
define("CONTENT_LAN_56", "Wy�wietl wybrany dzia�");//show overview of
define("CONTENT_LAN_57", "Komentarzy:");
define("CONTENT_LAN_58", "Strona g��wna");
define("CONTENT_LAN_59", "Publikacje");
define("CONTENT_LAN_60", "Ostatnio dodane");
define("CONTENT_LAN_61", "Ostatnio dodane");
define("CONTENT_LAN_62", "Wszystkie kategorie");
define("CONTENT_LAN_63", "Wszyscy autorzy");
define("CONTENT_LAN_64", "Najlepiej ocenione");
define("CONTENT_LAN_65", "Wy�lij publikacj�");
define("CONTENT_LAN_66", "Kliknij tutaj, aby wys�a� publikacj�. Pami�taj, �e mo�esz wybra� kategori� dla wysy�anie pozycji.");
define("CONTENT_LAN_67", "Osobisty mened�er publikacji");
define("CONTENT_LAN_68", "Kliknij tutaj, aby zarz�dza� w�asnymi publikacjami.");
define("CONTENT_LAN_69", "Wy�lij emailem wybran�");
define("CONTENT_LAN_70", "Drukuj");
define("CONTENT_LAN_71", "publikacj�");
define("CONTENT_LAN_72", "Pozycja kategorii");
define("CONTENT_LAN_73", "Obecnie nie ma �adnych publikacji.");
define("CONTENT_LAN_74", "");
define("CONTENT_LAN_75", "Wy�lij publikacj�");
define("CONTENT_LAN_76", "Zapisz jako plik pdf");
define("CONTENT_LAN_77", "Wyszukiwanie publikacji");
define("CONTENT_LAN_78", "Strona nie zawiera tytu�u");
define("CONTENT_LAN_79", "Strona");
define("CONTENT_LAN_80", "Ostatnio dodane: ");
define("CONTENT_LAN_81", "Kategorie");
define("CONTENT_LAN_82", "Nie ma jeszcze pozycji w dziale");
define("CONTENT_LAN_83", "Archiwum");
define("CONTENT_LAN_84", "Publikacje archiwalne");
define("CONTENT_LAN_85", "Autorzy publikacji");
define("CONTENT_LAN_86", "Najlepiej ocenione");
define("CONTENT_LAN_87", "Publikacje z najlepszymi wynikami");
define("CONTENT_LAN_88", "Obecnie nie ma �adnej publikacji posiadaj�cej przyznany wynik.");
define("CONTENT_LAN_89", "Wybierz stron�");
define("CONTENT_LAN_90", "poprzednia strona");
define("CONTENT_LAN_91", "nast�pna strona");
define("CONTENT_LAN_92", " - bie��ca");

define("CONTENT_MENU_LAN_0", "Publikacje");
define("CONTENT_MENU_LAN_1", "Nie ma jeszcze �adnej publikacji");
define("CONTENT_MENU_LAN_2", "Ostatnio dodane");
define("CONTENT_MENU_LAN_3", "Kategorie");
define("CONTENT_MENU_LAN_4", "Linki nawigacyjne");
define("CONTENT_MENU_LAN_5", "");
define("CONTENT_MENU_LAN_6", "");
define("CONTENT_MENU_LAN_7", "");
define("CONTENT_MENU_LAN_8", "");
define("CONTENT_MENU_LAN_9", "");
define("CONTENT_MENU_LAN_10", "");
define("CONTENT_MENU_LAN_11", "");
define("CONTENT_MENU_LAN_12", "");
define("CONTENT_MENU_LAN_13", "");
define("CONTENT_MENU_LAN_14", "");
define("CONTENT_MENU_LAN_15", "");
define("CONTENT_MENU_LAN_16", "");
define("CONTENT_MENU_LAN_17", "");
define("CONTENT_MENU_LAN_18", "");
define("CONTENT_MENU_LAN_19", "");
define("CONTENT_MENU_LAN_20", "");

?>
