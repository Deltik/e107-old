<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/11/01 00:16:19 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/clock_menu/languages/admin/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/clock_menu/languages/admin/English.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("CLOCK_AD_L1", "Konfiguracja menu Data / Czas zosta�a zapisana");
define("CLOCK_AD_L2", "Nag��wek");
define("CLOCK_AD_L3", "Aktualizuj ustawienia");
define("CLOCK_AD_L4", "Konfiguracja menu Data / Czas");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Je�li zaznaczy�e�, godzina zostanie wy�wietlona w standardzie angielskim (format 0-12 AM/PM). Je�li natomiast pole jest odznaczone, godzina b�dzie wy�wietlana w standardzie 'militarnym' z wykorzystaniem 24 godzin (format 0-24)");
define("CLOCK_AD_L7", "Prefiks dla daty");
define("CLOCK_AD_L8", "Je�li j�zyk, kt�rego u�ywasz, wymaga przed dat� przys��wka (Przyk�adowo 'on' dla j�zyka angielskiego, 'le' dla j�zyka francuskiego lub 'den' dla j�zyka niemieckiego...), u�yj tego pola. Je�li nie wymaga, pozostaw puste.");
define("CLOCK_AD_L9", "Przyrostek dla 1");
define("CLOCK_AD_L10", "Przyrostek dla 2");
define("CLOCK_AD_L11", "Przyrostek dla 3");
define("CLOCK_AD_L12", "Przyrostek dla 4 i wi�kszych cyfr");
define("CLOCK_AD_L13", "Je�li j�zyk, kt�rego u�ywasz, wymaga wy�wietlenia po cyfrach daty przyrostka, wype�nij te pola u�ywaj�c tylko tego przyrostka (Na przyk�ad: dla u�ytkownik�w m�wi�cych w j�zyku angielskim 'st' dla 1, 'nd' dla 2, 'rd' dla 3 oraz 'th' dla 4 i wi�kszych cyfr). Je�li nie wymaga, pozostaw puste.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>
