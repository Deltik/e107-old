<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.5 $
|     $Date: 2006/11/19 17:06:38 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/poll/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/poll/languages/English.php rev. 1.12
+-----------------------------------------------------------------------------+
*/
 
define("POLL_ADLAN01", "Ankieta");
define("POLL_ADLAN02", "Plugin ankiet, pozwoli Ci na definiowanie ankiet w menu lub na forum.");
define("POLL_ADLAN03", "Konfiguracja ankiet");
define("POLL_ADLAN04", "Plugin ankiet zosta� pomy�lnie zainstalowany. Aby doda� ankiet� kliknij na ikon� Ankiety w sekcji plugin�w na stronie g��wnej administratora oraz pami�taj aby po jej dodaniu aktyowa� menu pool na stronie konfiguracji menu.");

define("POLLAN_MENU_CAPTION", "Ankieta");

define("POLLAN_1", "Aktualne ankiety");
define("POLLAN_2", "Utw�rz/Edytuj ankiet�");
define("POLLAN_3", "Pytanie ankietowe");
define("POLLAN_4", "Mo�liwe odpowiedzi");
define("POLLAN_5", "Edytuj");
define("POLLAN_6", "Usu�");
define("POLLAN_7", "Nie ma jeszcze �adnych ankiet.");
define("POLLAN_8", "Dodaj dodatkow� odpowied�");
define("POLLAN_9", "Zezwoli� na wielokrotny wyb�r?");
define("POLLAN_10", "Tak");
define("POLLAN_11", "Nie");
define("POLLAN_12", "Poka� wyniki");
define("POLLAN_13", "Po g�osowaniu");
define("POLLAN_14", "Po klikni�ciu na link z wynikami - do u�ywania tej opcji musisz w��czy� komentarze");
define("POLLAN_15", "Zezwalaj na g�osowanie w tej ankiecie");
define("POLLAN_16", "Spos�b zliczania g�os�w");
define("POLLAN_17", "Ciasteczka (<i>cookie</i>)");
define("POLLAN_18", "Adres IP");
define("POLLAN_19", "ID u�ytkownika (tylko zarejestrowani u�ytkownicy mog� g�osowa�)");
define("POLLAN_20", "Zezwoli� na komentowanie ankiet?");
define("POLLAN_21", "Ponowny podgl�d");
define("POLLAN_22", "Aktualizuj ankiet�");
define("POLLAN_23", "Utw�rz ankiet�");
define("POLLAN_24", "Podgl�d");
define("POLLAN_25", "Wyczy�� formularz");
define("POLLAN_26", "G�osy");
define("POLLAN_27", "Komentarze");
define("POLLAN_28", "Poprzednie ankiety");
define("POLLAN_29", "Autor");
define("POLLAN_30", "Wy�lij");
define("POLLAN_31", "G�osy");
define("POLLAN_32", "Kliknij tutaj, aby zobaczy� wyniki");
define("POLLAN_33", "Nie przeprowadzono jeszcze �adnej ankiety.");
define("POLLAN_34", "Tytu�");
define("POLLAN_35", "Autor");
define("POLLAN_36", "Czas trwania");
define("POLLAN_37", "Aktywna od");
define("POLLAN_38", "do");
define("POLLAN_39", "Dzi�kujemy za oddanie g�osu!");
define("POLLAN_40", "Kliknij tutaj, aby zobaczy� wyniki");

define("POLLAN_41", "Ta ankieta jest przeznaczona tylko dla zarejestrowanych uy�ytkownik�w");
define("POLLAN_42", "Ta ankieta jest przeznaczona tylko dla administrator�w");
define("POLLAN_43", "Nie masz uprawnie� do oddania g�osu w tej ankiecie");

define("POLLAN_44", "Czy usun�� t� ankiet�?");

define("POLLAN_45", "Ankieta zosta�a zaktualizowana");
define("POLLAN_46", "Pola pozosta�y puste");
?>
