<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/28 12:18:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/linkwords/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/linkwords/languages/English.php rev. 1.2 (06 Apr 2005)
+-----------------------------------------------------------------------------+
*/
 
define("LWLAN_1", "Wymagane pola pozosta�y puste.");
define("LWLAN_2", "Link s�owny zosta� zapisany.");
define("LWLAN_3", "Link s�owny zosta� zaktualizowany.");
define("LWLAN_4", "Nie zdefiniowano jeszcze �adnych link�w s�ownych.");
define("LWLAN_5", "S�owo");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktywny?");
define("LWLAN_8", "Opcje");
define("LWLAN_9", "Tak");
define("LWLAN_10", "Nie");
define("LWLAN_11", "Aktualne linki s�owne");
define("LWLAN_12", "Tak");
define("LWLAN_13", "Nie");
define("LWLAN_14", "Wy�lij link s�owny");
define("LWLAN_15", "Zaktualizuj link s�owny");
define("LWLAN_16", "Edytuj");
define("LWLAN_17", "Usu�");
define("LWLAN_18", "Czy na pewno usun�� wskazany link s�owny?");
define("LWLAN_19", "Link s�owny zosta� usuni�ty.");
define("LWLAN_20", "Nie mog� odnale�� wpisu linka s�ownego.");
define("LWLAN_21", "S�owo do automatycznego zlinkowania");
define("LWLAN_22", "Aktywowa�?");

define("LWLANINS_1", "Linki s�owne");
define("LWLANINS_2", "Plugin Linki s�owne ��czy �ci�le wyszczeg�lnione s�owa ze zdefiniowanymi wcze�niej dla nich linkami.");
define("LWLANINS_3", "Konfiguracja link�w s�ownych");
define("LWLANINS_4", "Aby skonfigurowa� ten plugin, prosz� klikn�� na link w sekcji plugin�w na g��wnej stronie administracyjnej.");

?>
