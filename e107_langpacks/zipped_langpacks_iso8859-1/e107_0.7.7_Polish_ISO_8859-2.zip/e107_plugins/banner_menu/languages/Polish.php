<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/06/28 17:05:49 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/banner_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/banner_menu/languages/English.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("BANNER_MENU_L1", "Reklama");
define("BANNER_MENU_L2", "Ustawienia banner�w zosta�y zapisane");

//v.617
define("BANNER_MENU_L3", "Nag��wek");
define("BANNER_MENU_L4", "Kampania");
define("BANNER_MENU_L5", "Konfiguracja menu banner�w");
define("BANNER_MENU_L6", "Wybierz kampanie do pokazania w menu.");
define("BANNER_MENU_L7", "Dost�pne kampanie");
define("BANNER_MENU_L8", "Wybrane kampanie");
define("BANNER_MENU_L9", "Usu� zaznaczone");
define("BANNER_MENU_L10", "Jak powinny by� wy�wietlane wybrane kampanie?");
define("BANNER_MENU_L11", "Wybierz spos�b wy�wietlania...");
define("BANNER_MENU_L12", "Jedna kampania w pojedynczym menu");
define("BANNER_MENU_L13", "Wszystkie wybrane kampanie w pojedynczym menu");
define("BANNER_MENU_L14", "Wszystkie wybrane kampanie w oddzielnych menu");
define("BANNER_MENU_L15", "Ile banner�w powinno by� wy�wietlanych?");
define("BANNER_MENU_L16", "To ustawienie mo�e by� u�ywane tylko z opcj� 2 i 3.<br />Je�li jest prezentowanych mniej baner�w, zostanie u�yta maksymalna dost�pna ilo��."); // Do poprawki - if less banners are present the maximum available amount will be used
define("BANNER_MENU_L17", "Ustaw ilo��...");
define("BANNER_MENU_L18", "Aktualizuj ustawienia");

?>
