<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.6 $
|     $Date: 2006/11/24 14:07:25 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/pm/languages/admin/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/pm/languages/admin/English.php rev. 1.9
+-----------------------------------------------------------------------------+
*/
 
define('ADLAN_PM', "Wiadomo�ci Prywatne");
define('ADLAN_PM_1', "Aby aktywowa� tego plugina prosz� przej�� do Panel administratora - Menu, a nast�pnie zaznaczy� <i>private_msg</i> w obszarze <i>Nieaktywne menu</i> i umie�ci� go w jednym z dost�pnych obszar�w menu. <br /><br />Je�li potrzebujesz przekonwertowa� wiadomo�ci z poprzedniej wersji WP, prosz� przej�� do strony konfiguracji tego pluginu i klikn�� w link 'Konwersja'.");
define('ADLAN_PM_2', "Konfiguruj Wiadomo�ci Prywatne");
define('ADLAN_PM_3', "Ustawienia Wiadomo�ci Prywatnych nie zosta�y odnalezione, ustawiono domy�lne warto�ci");
define('ADLAN_PM_4', "Opcje zaktualizowane");
define('ADLAN_PM_5', "Ograniczenie dla wybranej grupy u�ytkownik�w ju� istnieje");
define('ADLAN_PM_6', "Limit zosta� pomy�lnie dodany");
define('ADLAN_PM_7', "Limit nie zosta� dodany - nieokre�lony b��d");
define('ADLAN_PM_8', "Status limit�w zaktualizowany");
define('ADLAN_PM_9', " - Limit pomy�lnie usuni�ty");
define('ADLAN_PM_10', " - Limit nie zosta� usuni�ty - nieokre�lony b��d");
define('ADLAN_PM_11', " - Limit zosta� pomy�lnie zaktualizowany");
define('ADLAN_PM_12', "Opcje wiadomo�ci prywatnych");
define('ADLAN_PM_13', "Konwersja WP");
define('ADLAN_PM_14', "Limity wiadomo�ci prywatnych");
define('ADLAN_PM_15', "Dodaj limit wiadomo�ci prywatnych");
define('ADLAN_PM_16', "Nazwa pluginu");
define('ADLAN_PM_17', "Poka� animacj� nowej wiadomo�ci prywatnej");
define('ADLAN_PM_18', "Poka� rozwijaln� list� u�ytkownik�w");
define('ADLAN_PM_19', "Odznacz jako CZYTAN� wiadomo�� po up�ywie:");  // READ message timeout
define('ADLAN_PM_20', "Odznacz jako NIEPRZECZYTAN� wiadomo�� po up�ywie:"); // UNREAD message timeout
define('ADLAN_PM_21', "Powiadomienia w oknie popup dla nowych wiadomo�ci");
define('ADLAN_PM_22', "Op�nienie wyskakuj�cego okienka"); // Popup delay timeou
define('ADLAN_PM_23', "Ogranicz u�ywanie Wiadomo�ci Prywatnych do");
define('ADLAN_PM_24', "Ilo�� wiadomo�ci prywatnych wy�wietlanych na stronie");
define('ADLAN_PM_25', "Aktywuj powiadomienia email o wiadomo�ciach prywatnych"); // Enable PM email notifications
define('ADLAN_PM_26', "Zezwalaj u�ytkownikom na ��danie potwierdzenia przeczytania wiadomo�ci za po�rednictwem powiadomie� email"); // Allow user to request read receipt email notifications
define('ADLAN_PM_27', "Zezw�l na do��czanie za��cznik�w");
define('ADLAN_PM_28', "Maksymalny rozmiar za��cznika");
define('ADLAN_PM_29', "Zezwalaj na wysy�anie do wszystkich u�ytkownik�w");
define('ADLAN_PM_30', "Zezwalaj na wysy�anie do wielu odbiorc�w");
define('ADLAN_PM_31', "Aktywuj wysy�anie do grupy u�ytkownik�w");
define('ADLAN_PM_32', "Aktualizuj ustawienia");
define('ADLAN_PM_33', "Nieaktywne (brak limit�w)");
define('ADLAN_PM_34', "Ilo�� wiadomo�ci");
define('ADLAN_PM_35', "Rozmiar skrzynki");
define('ADLAN_PM_36', "Grupa u�ytkownik�w");
define('ADLAN_PM_37', "Ograniczenia ilo�ci");
define('ADLAN_PM_38', "Ograniczenie rozmiaru (w KB)");
define('ADLAN_PM_39', "Skrzynka nadawcza :");
define('ADLAN_PM_40', "Skrzynka odbiorcza :");
define('ADLAN_PM_41', "Aktualnie nie ma ustawionych �adnych ogranicze�.");
define('ADLAN_PM_42', "Aktualizuj limity");
define('ADLAN_PM_43', "Dodaj nowy limit");
define('ADLAN_PM_44', "sekund");
define('ADLAN_PM_45', "Limity WP dla: ");
define('ADLAN_PM_46', "Konwersja WP");
define('ADLAN_PM_47', "Nie wykryto �adnych starych wiadomo�ci, w zwi�zku z tym mo�esz bezpiecznie odinstalowa� starsz� wersj� plugina"); // You do not appear to have any old messages from previous vesions, it is safe to uninstall the old plugin
define('ADLAN_PM_48', "Masz {OLDCOUNT} wiadomo�ci pochodz�cych ze starszej wersji, prosz� zdecydowa� co zrobi� z tymi wiadomo�ciami.<br /><br />Je�li konwersja wiadomo�ci pomy�lnie przekonwertowa�a jak�� wiadomo��, zostanie ona usuni�ta ze starszej wersji skrzynki."); // If converting messages, any message successfully converted will be removed from old system.
define('ADLAN_PM_49', "Konwertuj do nowych WP");
define('ADLAN_PM_50', "Usu� stare wiadomo�ci"); // Discard old messages
define('ADLAN_PM_51', "WP #{PMNUM} nie przekonwertowano");
define('ADLAN_PM_52', "wiadomo�ci przekonwertowane");
define('ADLAN_PM_53', "Nie znaleziono wpis�w do konwersji.");

define('ADLAN_PM_54', "Opcje g��wne");
define('ADLAN_PM_55', "Limity");
define('ADLAN_PM_56', "Konwersja");

define('ADLAN_PM_57', "Plugin ten stanowi w pe�ni funkcjonalny system wiadomo�ci prywatnych.");
define('ADLAN_PM_58', "Wiadomo�ci Prywatne");

?>
