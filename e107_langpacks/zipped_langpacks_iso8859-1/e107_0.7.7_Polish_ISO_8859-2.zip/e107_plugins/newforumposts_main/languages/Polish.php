<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/11/01 20:21:33 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/newforumposts_main/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/newforumposts_main/languages/English.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("NFPM_LAN_1", "Temat");
define("NFPM_LAN_2", "Autor");
define("NFPM_LAN_3", "Ods�on");
define("NFPM_LAN_4", "Posty");
define("NFPM_LAN_5", "Ostatni post");
define("NFPM_LAN_6", "Temat�w");
define("NFPM_LAN_7", "przez");

define("NFPM_L1", "Ten plugin wy�wietla na stronie g��wnej list� nowych post�w na forum.");
define("NFPM_L2", "Nowe posty na forum");
define("NFPM_L3", "Aby skonfigurowa� plugin kliknij na linku w sekcji plugin�w na stronie Panel Administratora");
define("NFPM_L4", "W kt�rej strefie aktywowa�?");
define("NFPM_L5", "Nieaktywny");
define("NFPM_L6", "Na g�rze strony");
define("NFPM_L7", "Na dole strony");
define("NFPM_L8", "Nag��wek");
define("NFPM_L9", "Ilo�� wy�wietlanych post�w?");
define("NFPM_L10", "Wy�wietli� wewn�trz przewijaneej sekcji?");
define("NFPM_L11", "Wysoko�� sekcji");
define("NFPM_L12", "Konfiguracja Nowe posty na forum");
define("NFPM_L13", "Aktualizuj ustawienia");
define("NFPM_L14", "Ustawienia pluginu zosta�y zaktualizowane.");
define("NFPM_L15", "Aby wy�wietli� najnowsze posty na forum zaznacz pole.<br />Domy�lnie jest najnowszy w�tek.");
define('NFPM_L16', '[u�ytkownik zosta� usuni�ty]');

?>
