<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_wmessage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/05/13 16:12:19 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
//define("WMGLAN_1", "Mensaje para invitados");
//define("WMGLAN_2", "Mensaje para miembros");
//define("WMGLAN_3", "Mensaje para Administradores");
//define("WMGLAN_4", "Enviar");
//define("WMGLAN_5", "Poner mensaje de bienvenida");
//define("WMGLAN_6", "�Activar?");
//define("WMGLAN_7", "Ajustes de mensajes de bienvenida actualizado.");

define("WMLAN_00","Mensajes de bienvenida");
define("WMLAN_01","Crear nuevo mensaje");
define("WMLAN_02","Mensaje");
define("WMLAN_03","Ver");
define("WMLAN_04","Texto de mensaje");
define("WMLAN_05","Encerrado");
define("WMLAN_06","<b>On:</b> El mensaje se renderizar� en la caja");
define("WMLAN_07","Invalidar el m�todo abreviado {WMESSAGE}:");
//define("WMLAN_08","Preferencias");
define("WMLAN_09","No hay mensajes de bienvenida");
define("WMLAN_10","Texto del mensaje");

?>