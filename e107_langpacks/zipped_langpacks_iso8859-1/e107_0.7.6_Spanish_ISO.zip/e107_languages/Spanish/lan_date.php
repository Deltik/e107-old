<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_date.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LANDT_01", "A�o");
define("LANDT_02", "Mes");
define("LANDT_03", "Semana");
define("LANDT_04", "D�a");
define("LANDT_05", "Hora");
define("LANDT_06", "Minuto");
define("LANDT_07", "Segundo");
define("LANDT_01s", "A�os");
define("LANDT_02s", "Meses");
define("LANDT_03s", "Semanas");
define("LANDT_04s", "D�as");
define("LANDT_05s", "Horas");
define("LANDT_06s", "Minutos");
define("LANDT_07s", "Segundos");
define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "seg");
define("LANDT_09s", "segs");
define("LANDT_AGO", "hace");
?>