<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/alt_auth/languages/Spanish/lan_otherdb_auth.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/10/29 12:57:43 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("OTHERDB_LAN_1", "Tipo de base de datos:");
define("OTHERDB_LAN_2", "Servidor:");
define("OTHERDB_LAN_3", "Usuario:");
define("OTHERDB_LAN_4", "Contrase�a:");
define("OTHERDB_LAN_5", "Base de datos");
define("OTHERDB_LAN_6", "Tabla");
define("OTHERDB_LAN_7", "Campo usuario");
define("OTHERDB_LAN_8", "Campo contrase�a:");
define("OTHERDB_LAN_9", "M�todo contrase�a:");
define("OTHERDB_LAN_10", "Configurar otrabd aut");
define("OTHERDB_LAN_11", "** Los siguientes campos no son obligatorios si usa la base de datos de e107");
?>