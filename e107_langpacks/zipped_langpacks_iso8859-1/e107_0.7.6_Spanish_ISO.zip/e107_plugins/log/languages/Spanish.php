<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/log/languages/Spanish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/11 11:02:28 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME","Estad�sticas");

define("ADSTAT_L1", "Este plugin registrar� todas las visitas de su p�gina, y crear� varias pantallas con la informaci�n obtenida.");
define("ADSTAT_L2", "El registro de estad�sticas se instal� exitosamente.");
define("ADSTAT_L3", "Registro estad�stico");
define("ADSTAT_L4", "No tiene permisos para ver esta p�gina.");
define("ADSTAT_L5", "Las caracter�sticas de esta p�gina han sido desactivadas.");
define("ADSTAT_L6", "Estad�sticas del sitio");
define("ADSTAT_L7", "No se han recogido estad�sticas de este tipo.");
define("ADSTAT_L8", "Estad�sticas de hoy");
define("ADSTAT_L9", "Estad�sticas de todo el tiempo");
define("ADSTAT_L10", "Diarias");
define("ADSTAT_L11", "Mensuales");
define("ADSTAT_L12", "Navegadores");
define("ADSTAT_L13", "Sistemas operativos");
define("ADSTAT_L14", "Dominios");
define("ADSTAT_L15", "Resoluci�n pantalla / profundidad de color");
define("ADSTAT_L16", "Estad�sticas de referencia");
define("ADSTAT_L17", "Buscar cadenas de estad�sticas");
define("ADSTAT_L18", "Visitas recientes");
define("ADSTAT_L19", "P�gina");
define("ADSTAT_L20", "Visitas hoy");
define("ADSTAT_L21", "Total");
define("ADSTAT_L22", "�nicas");
define("ADSTAT_L23", "Visitas totales");
define("ADSTAT_L24", "Visitas �nicas totales");
define("ADSTAT_L25", "Sin estad�sticas.");
define("ADSTAT_L26", "Navegador");
define("ADSTAT_L27", "Sistema operativo");
define("ADSTAT_L28", "Pa�ses / Dominios");
define("ADSTAT_L29", "Resoluci�n de pantalla");
define("ADSTAT_L30", "Referencias del sitio");
define("ADSTAT_L31", "Motor de b�squeda de cadenas");
define("ADSTAT_L32", "Procedente de");
define("ADSTAT_L33", "�ltimas visitas");
define("ADSTAT_L34", "Visitas");
define("ADSTAT_L35", "�ltimas visitas �nicas");
define("ADSTAT_L36", "D�as por p�gina");
define("ADSTAT_L37", "Visitas por mes");
define("ADSTAT_L38", "Visitas �nicas por mes");
define("ADSTAT_L39", "Eliminar esta entrada");
define("ADSTAT_L40", "D�as");
define("ADSTAT_L41", "Error");
?>