<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/forum/languages/Spanish/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Estad�sticas del foro");

define("FSLAN_1", "General");
define("FSLAN_2", "Foro abierto");
define("FSLAN_3", "Abierto para");
define("FSLAN_4", "Env�os totales");
define("FSLAN_5", "Temas del foro");
define("FSLAN_6", "Respuestas del foro");
define("FSLAN_7", "Temas vistos del foro");
define("FSLAN_8", "Tama�o de la base de datos (solo tablas)");
define("FSLAN_9", "Tama�o medio de la fila en la tabla del foro");
define("FSLAN_10", "Temas m�s activos");
define("FSLAN_11", "Rango");
define("FSLAN_12", "Tema");
define("FSLAN_13", "Respuestas");
define("FSLAN_14", "Iniciado por");
define("FSLAN_15", "Fecha");
define("FSLAN_16", "Temas m�s vistos");
define("FSLAN_17", "Vistas");
define("FSLAN_18", "Mejores foreros");
define("FSLAN_19", "Nombre");
define("FSLAN_20", "Env�os");
define("FSLAN_21", "Los mejores foreros iniciales");
define("FSLAN_22", "Los mejores participantes");
define("FSLAN_23", "Estad�sticas del foro");
define("FSLAN_24", "Promedio de env�os por d�a");

?>