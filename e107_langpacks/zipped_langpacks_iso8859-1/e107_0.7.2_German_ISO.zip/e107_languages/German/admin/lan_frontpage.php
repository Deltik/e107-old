<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_frontpage.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Hauptseiten Einstellungen aktualisiert.");
define("FRTLAN_2", "Anzeige");

define("FRTLAN_6", "Links");
//define("FRTLAN_7", "Inhaltsseite");

define("FRTLAN_12", "Hauptseiten Einstellungen aktualisieren");
define("FRTLAN_13", "Hauptseiten Einstellungen");


define("FRTLAN_15", "Andere (Bitte vollst&auml;ndige URL angeben):");
define("FRTLAN_16", "Fehler: Es wurde keine Inhalts-Hauptkategorie gew&auml;hlt");
define("FRTLAN_17", "Fehler: Es wurde keine Inhalts-Unterkategorie gew&auml;hlt");
define("FRTLAN_18", "Fehler: Kein Inhalts-Eintrag gew&auml;hlt");
define("FRTLAN_19", "Inhalts-Hauptkategorie");
define("FRTLAN_20", "Inhalts-Unterkategorie");
define("FRTLAN_21", "Inhalts-Eintrag");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Alle Benutzer");
define("FRTLAN_27", "G&auml;ste");
define("FRTLAN_28", "Mitglieder");
define("FRTLAN_29", "Administratoren");
define("FRTLAN_31", "Alle Benutzer");
define("FRTLAN_32", "Benutzerklassen");
define("FRTLAN_33", "Bestehende Einstellungen");
define("FRTLAN_34", "Seite");

?>
