<?php
$caption = "Hauptseiten Administrator - Hilfe";
$text = "Benutzen Sie diese Seite, um neue Administratoren anzulegen, zu &auml;ndern oder zu l&ouml;schen. Der Administrator hat nur zu denen von Ihnen zugeteilten Rechten bzw. Men&uuml;s zugang. Aktivieren Sie dazu die entsprechende Checkbox.";
$ns -> tablerender($caption, $text);
?>
