<?php
$text = "Sie k&ouml;nnen andere Webseiten abfragen und analysieren adere Seiten Datenbanken 'RSS' News Einspeisungen und lassen diese auf Ihrer Seite anzeigen. <br /> Geben Sie hierzu den vollen Pfad (URL) zur datenabnk an, zB http://e107.org/news.xml. Sie k&ouml;nnen einen Pfad f&uuml;r ein Bild angeben, wenn Sie das Original nich m&ouml;gen bzw. keines definiert ist. Sie haben die Option die Datenbank (Backend) abzuschalten, falls Wartungsarbeiten anfallen.<br /><br /> Um die &Uuml;berschriften auf Ihrer Homeoage zu aktivieren stellen Sie sicher, dass das &Uuml;berschriften anzeigen (headlines_menu) auf der Admin Seite Men&uuml;s aktiviert ist.";

$ns -> tablerender("&Uuml;berschriften", $text);
?>
