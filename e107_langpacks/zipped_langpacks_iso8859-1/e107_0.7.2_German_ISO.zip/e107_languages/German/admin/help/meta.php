<?php
$text = "Alle Meta-Tags, die Sie hier eingeben werden im Monitor am richtigen Platz angezeigt.";

$ns -> tablerender("Meta Tags", $text);
?>
