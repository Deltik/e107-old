<?php
$text = "Umfragen und Abstimmungen k&ouml;nnen Sie &uuml;ber dieses Men&uuml; steuern. Schreiben Sie den Titel der Umfrage und aktivieren die Optionen und verfassen die Fragen. &Uuml;er die Voransicht sehen Sie das Aussehen Ihrer Kundenbefragung. Dann aktivieren Sie die Aktion<br /><br />
Um die Umfragen auch sichtbar zu machen, m&uuml;ssen Sie ImMen&uuml; die Umfrage aktivieren 'aktiviere Umfrage'.";
$ns -> tablerender("Meinungsumfragen, Abstimmungen", $text);
?>
