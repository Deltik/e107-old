<?php
$text = "Berichet sind vergleichbar mit Artikeln, sie werden aber in einem eigenen Men&uuml;element erfasst.<br />
F&uuml;r einen mehrseitigen Bericht geben Sie f&uuml;r einen Seitenumbruch das Tag '[newpage]' ein. Sie k&ouml;nnen ebefalls Berichtkategorien festelgen. Vergleichn Sie dazu die Hinweise unter Artikel Hilfe.";
$ns -> tablerender("Berichte Hilfe", $text);
?>
