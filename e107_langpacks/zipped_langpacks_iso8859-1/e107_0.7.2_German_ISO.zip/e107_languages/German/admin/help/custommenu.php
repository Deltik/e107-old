<?php
$text = "&Uuml;ber dieses Men&uuml; k&ouml;nnen Sie individuelle Men&uuml;s bzw. Seiten erstellen, die Sie ebenfalls mit eigenen Inhalten versehen k&ouml;nnen.<br /><br />
<b>Wichtiger Hinweis!</b><br />
- um dieses Extra zu nutzen, m&uuml;ssen Sie den Ordner /e107_plugins/custom/ und /e107_plugins/custompages/ per CHMOD auf 777 setzen.
<br />
- Sie k&ouml;nnen nat&uuml;rlich HTML Code nutzen. Achten Sie aber darauf, dass Sie f&uuml;r die Attribute nur das Teichen ' nutzen und NICHT! die klassischen Anf&uuml;hrungszeichen \". Letzteres wird Ihre Seite im Layout zerst&ouml;ren!
<br /><br />
<i>Men&uuml;/Seiten-Dateiname</i>: Der Name Ihres Men&uuml;s bzw. Ihre Seite wird gespeichert als 'Seitenname.php' in dem ".e_PLUGIN."custom/ Verzeichnis<br />
Die Seite ansich wird als Seitenname.php im ".e_PLUGIN."custompages/ Verzeichnis<br /><br />
<i>Men&uuml;/Seiten&uuml;berschrift<i/>: Der Text wird als Seiten&uuml;berschrift des Men&uuml;s bzw. im Seitentitel angezeigt.<br /><br />
<i>Men&uuml;/ Seitentext</I>: Die von Ihnen eingegebenen Daten in den Bereich 'BODY' oder als normaler Text eingegeben. Es ist nicht notwendig, dass Sie die Zeilen einf&uuml;gen, um die class2.php aufzurufen bzw. die Zeilen HEADER oder FOOTER. Diese Zeilen werden automtisch hinzugef&uuml;gt.<br /> Wenn Sie dennoch Ihre Seite etwas anpassen wollen, haben Sie die M&ouml;glichkeit &uuml;ber das CSS Stylesheet, classen zu vergeben, die dann Ihre Seite anders aussehen l&auml;sst.";
$ns -> tablerender(CUSLAN_18, $text);
?>
