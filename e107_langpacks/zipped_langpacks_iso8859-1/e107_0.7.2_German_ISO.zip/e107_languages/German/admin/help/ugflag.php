<?php
$text = "Wenn Sie e107 aufr&uuml;sten (Upgrade) oder Ihre Seite f&uuml;r Wartungsarbeiten offline ist, dann gehen Sie auf das Men&uuml; Wartung und aktivieren Sie die Checkbox 'aktiviere Wartungsstatus'. Danach erhalten Ihre Besucher f&uuml;r den zeitraum der Wartun eine Meldung, dass die Seite offline ist. Anschlie&szlig;end deaktivieren Sie bitte die Checkbox.";

$ns -> tablerender("Wartung", $text);
?>
