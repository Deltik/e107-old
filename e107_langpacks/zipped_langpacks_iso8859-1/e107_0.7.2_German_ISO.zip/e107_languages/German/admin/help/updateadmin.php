<?php
$text = "Aktualisieren Sie Ihr Passwort hier.";
$ns -> tablerender("Admin Passwort update - Hilfe", $text);
?>
