<?php

$text = "Um Text Emoticons (Emotes/Smilies) durch kleine Bilder zu ersetzen, Aktivieren Sie bitte die Checkbox.<br /><br />
Dann gehen Sie auf Einstellungen speichern und Die Daten werden aktualisiert. F&uuml;r neue Emotes geben Sie die entsprechenden K&uuml;rzel ein und laden Sie die Bilder in das e107_images/emoticons/ Verzeichnis. Benutzen Sie herf&uuml; die unteren Felder.";
$ns -> tablerender("Emoticon/Smilies Hilfe", $text);
?>
