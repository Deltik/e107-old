<?php
$text = "Sie k&ouml;nnen eine Nachricht erstellen, die solange erscheint, bis Sie die Checkbox deaktivieren. Diese Nachrichten k&ouml;nnen Sie f&uuml;r G&auml;ste, Mitglieder und Administratoren eingeben. Die Nachrichten k&ouml;nnen Sie jederzeit &uuml;ber dieses Men&uuml; &auml;ndern";
$ns -> tablerender("Begr&uuml;&szlig;ungstext - Hilfe", $text);
?>
