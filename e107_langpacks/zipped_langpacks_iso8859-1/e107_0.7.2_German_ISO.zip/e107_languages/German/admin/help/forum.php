<?php
$caption = "Foren Hilfe";
$text = "<b>Allgemeines</b><br />
Nutzen Sie dieses Men&uuml; um Foren zu editieren oder zu erstellen.<br />
<br />
<b>Haupt- bzw. Ursprungskategorie/Foren</b><br />
EIne Ursprungskategorie ist eine &Uuml;berschrift unter der die zum Thema geh&ouml;rigen Foren gruppiert sind. Dadurch wird die Darstellung und die Navigation f&uuml; die Nutzer einfacher.
<br /><br />
<b>Erreichbarkeit</b>
<br /> 
Sie k&ouml;nnen Foren f&uuml;r bestimmte Benutzerklassen erstellen, die dann nur f&uuml;r diese erreichbar sind. Dazu m&uuml;ssen Sie die Klassen vergeben. Wenn Sie die Klassen Vegeben haben, sehen nur diese das f&uuml;r sie zung&auml;ngliche Forum. Das Gleiche gilt auch f&uuml;r Haupt- bzw. Ursprungskategorien.
<br /><br />
<b>Moderatoren</b>
<br />
W&auml;hlen Sie die Namen der Administratoren, denen Sie den Forum Moderator Status erteilen wollen. Die Moderatoren m&uuml;ssen vorher den Status 'Forum Moderator' erhalten, um hier aufgelistet zu sein! Diese Einstellung nehemen Sie &uuml;ber das Men&uuml; Administratoren vor.
<br /><br />
<b>Benutzer Ranking</b>
<br />
Ebfalls k&ouml;nnen Sie &uuml;ber dieses Men&uuml; die Benutzer Rankings verwalten. Wenn die Bild Felder ausgew&auml;hlt sind, werden die Bilder genutzt. Um die Raking Namen zu nutzen, lassen Sie das Feld Ranking Bild leer.<br /> Der Schwellenwert ist die Anzahl von Punkten, die ein User ben&ouml;tigt, um in den n&auml;sten Rang hochgestuft zu werden.";
$ns -> tablerender($caption, $text);
unset($text);
?>
