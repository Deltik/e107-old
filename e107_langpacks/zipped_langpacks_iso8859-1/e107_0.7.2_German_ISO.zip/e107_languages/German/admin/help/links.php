<?php
$text = "Geben Sie Ihre Seitenlinks hier ein. Hier eingetragene Links, werden im Hauptnavigationsmen&uuml; angezeigt. F&uuml;r andere Links nutzen Sie bitte das Links Page Plugin.
<br />
<br />
Der Submen&uuml;generator ist nur f&uuml;r e107 DHTML-Men&uuml;s sinnvoll. (TreeMenu, UltraTreeMenu, eDynamicMenu, ypSlideMenu...)";
$ns -> tablerender("Links Hilfe", $text);
?>
