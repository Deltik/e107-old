<?php
$text = "Sie k&ouml;nnen Ihre News in verschiedene Kategorien einteilen und erm&ouml;glichen dem Besucher so, nur die News anzuzeigen in den jeweilgen Kategorien interessant f&uuml;r den Leser sind.<br /><br />
Laden Sie Ihre News Icons entweder in den Ordner ".e_THEME."-IhrTheme-/images/ oder themes/shared/newsicons/";
$ns -> tablerender("News Kategorie Hilfe", $text);
?>
