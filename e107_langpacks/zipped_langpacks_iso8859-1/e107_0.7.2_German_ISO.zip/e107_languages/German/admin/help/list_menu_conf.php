<?php
$text = "In dieser Sektion k&ouml;nnen Sie drei Men&uuml;s konfigrieren.<br />
<b>Men&uuml; Neue Artikel</b> <br>
Geben Sie eine Zahl, zB die Zahl '5' in das erste Feld ein. Das f&uuml;hrt dazu, dass die ersten '5' Artikel angezeigt werden. Lassen Sie das Feld leer, werden alle angezeigt. Sie k&ouml;nnen auch den Link bennen, der zu dem rest der Artikel f&uuml;hrt, im zweiten Feld, zB 'Alle Artikel'. Lassen Sie das Feld leer, wird kein Link erstellt.<br />
<b>Kommentare im Men&uuml; Forum</b><br />
Die Standardeinstellung ist auf #5 gesetzt. Die Anzahl der Zeichen standardm&auml;szlig;ig auf 10.000! Der Zeichenschluss ist f&uuml;r zu lange Zeilen. Er schneidet sie am ende ab. Eine gute Wahl den Zeichenschluss anzuzeigen ist '...'. Schauen Sie sich Originalbeitr&auml;ge an, um zu sehen wie es aussieht.<br />";
$ns -> tablerender("Men&uuml; Konfiguration Hilfe", $text);
?>
