<?php
$caption = "Benutzerklassen Hilfe";
$text = "Sie &ouml;nnen Benutzerklassen editieren, erstellen und Louml;schen. <br /> Dieser Bereich ist hilfreich f&uuml;r die Zugangsbeschr&auml;kung f&uuml;r bestimmte Nutzzer Ihrer Website. Hilfreich ist es, wenn Sie eine Klasse ADMIN anlegen. Diese Klasse k&ouml;nnen Sie dann nur f&uuml;r sich freischalten. Das ist hilfreich, wenn Sie Berichte, news, Artikel oder Content erstellen und das Layout auf der Seite im Original sehen wollen oder, wenn Sie Ihre Artikel &uuml;ber einen l&auml;ngeren Zeitraum bearbeiten.<br /><br />
Das Gleiche machen Sie dann f&uuml;r die Nutzer, die Sie in bestimmte Bereich lassne m&ouml;chten. Bitte achten Sie darauf, dass Sie den Klassen auch die benutzer zuweisen. <br /><br />
TIPP:<br />
L&ouml;schen Sie m&ouml;glichst NIE eine ganze Klasse, wenn Sie nicht ABSOLUT sicher sind! Es gibt KEINE M&ouml;glichkeit einmal gel&ouml;schte Klassen wieder herzustellen!";
$ns -> tablerender($caption, $text);
?>
