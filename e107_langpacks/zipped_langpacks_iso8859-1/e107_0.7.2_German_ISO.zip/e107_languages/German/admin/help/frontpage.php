<?php
$caption = "Erste Seite Hilfe";
$text = "&Uuml;ber dieses Men&uuml; k&ouml;nnen Sie die Eingangs- bzw. Startseite Ihres Internet-Auftritts bestimmen. Die Standardeinstellung ist 'news.php'. Sie k&ouml;nnen diese Einstellung auch nutzen f&uuml;r einen sog. Splashscreen. Das ist eine Seite, die nur bei dem ersten Besuch der Seite eines 'neuen' Nutzers erscheint.";
$ns -> tablerender($caption, $text);
?>
