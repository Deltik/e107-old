<?php

$text = "Sie k&ouml;nnen eine normale Seite mit diesem Men&uuml; hinzuf&uuml;gen. Es wird ein link zu Ihrer neuen Seite gesetzt in der Hauptnavigationsleiste. Wenn Sie beispielsweise einen neue Seite (test.php auch mit html code m&ouml;glich) mit dem Namen Test eintragen, dann erscheint in Ihrer Haupnavigation die Seite Test.<br />
Wenn Ihre neue Seite eine &Uuml;berschrift haben soll, dann tragen Sie diese bitte in dem daf&uuml;r vorgesehen Feld 'Seiten&uuml;berschrift' ein.";
$ns -> tablerender("Inhalt Hilfe", $text);
?>
