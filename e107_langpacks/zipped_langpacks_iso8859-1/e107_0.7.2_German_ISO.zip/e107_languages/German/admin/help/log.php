<?php
$text = "Aktivieren Sie das 'logging' mit diesem Men&uuml;. Wenn Sie geringen Server Speicherplatz haben, aktivieren Sie die Checkbox 'nur Domain/Dom&auml;ne als Bezug'. das erzeugt nur ein Kurz-Log f&uuml;r die URL, zB 'waketime.com' anstelle von 'http://www.waketime.com/news.php'";
$ns -> tablerender("Logging Hilfe", $text);
?>
