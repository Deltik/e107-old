<?php
$caption = "Men&uuml; Hilfe";
$text .= "Sie k&ouml;nnen &uuml;ber diesen Schirm Ort und Reihenfolge Ihrer anzuzeigenden Men&uuml;s arrangieren. Benutzen Sie die Pfeile, um die Men&uuml;s auf- und abw&auml;rts zu bewegen, solange, bis Sie mit der Einstellung zufrieden sind.
<br />
Die Men&uuml; Elemente in der Mitte des Bildschirms sind deaktiviert! Sie aktivieren diese, indem Sie die Platzierung w&auml;hlen (zB Beriech 1, 2, 3 usw.).";

$ns -> tablerender("Menus Hilfe", $text);
?>
