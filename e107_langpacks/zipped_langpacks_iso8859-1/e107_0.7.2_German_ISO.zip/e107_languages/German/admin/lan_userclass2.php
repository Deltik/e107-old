<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Alle Benutzer aus Klassen entfernt.");
define("UCSLAN_2", "Klassen Benutzer aktualisiert.");
define("UCSLAN_3", "Klasse gel&ouml;scht.");
define("UCSLAN_4", "Bitte markieren Sie die Box um das L&ouml;schen des Benutzers aus dieser Klasse zu best&auml;tigen");
define("UCSLAN_5", "Klasse aktualisiert.");
define("UCSLAN_6", "Klasse in Datenbank gesichert.");
define("UCSLAN_7", "Keine Benutzerklasse.");
define("UCSLAN_8", "Bestehende Benutzerklassen");

//define("UCSLAN_9", "Bearbeiten");
//define("UCSLAN_10", "L&ouml;schen");
define("UCSLAN_11", "Bitte hier markieren um Vorgang zu best&auml;tigen.");
define("UCSLAN_12", "Klassen Name");
define("UCSLAN_13", "Klassen Beschreibung");
define("UCSLAN_14", "Benutzerklasse aktualisiert");
define("UCSLAN_15", "Neue Beutzerklasse anlegen");
define("UCSLAN_16", "Benutzer in Klassen einordnen");
define("UCSLAN_17", "Entfernen");
define("UCSLAN_18", "Klasse leeren");
define("UCSLAN_19", "Benutzer hinzuf&uuml;gen zu");
define("UCSLAN_20", "Klasse");
define("UCSLAN_21", "Benutzerklassen Einstellungen");

define("UCSLAN_22", "Benutzer - klicke um zu verschieben ...");
define("UCSLAN_23", "Benutzer in dieser Klasse ...");

define("UCSLAN_24", "Wer darf Klassen managen");

?>
