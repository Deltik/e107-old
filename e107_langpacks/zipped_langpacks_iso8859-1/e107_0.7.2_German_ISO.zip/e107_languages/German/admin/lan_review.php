<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_review.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("REVLAN_1", "Bericht in Datenbank eingef&uuml;gt.");
define("REVLAN_2", "Felder sind freigelassen worden.");
define("REVLAN_3", "Bericht in Datenbank aktualisiert.");
define("REVLAN_4", "Bericht gel&ouml;scht.");
define("REVLAN_5", "Bitte markieren Sie die Best&auml;tigungsbox um den Bericht zu l&ouml;schen");
define("REVLAN_6", "Keine Berichte bis jetzt.");
define("REVLAN_7", "Bestehende Berichte");
define("REVLAN_8", "Bearbeiten");
define("REVLAN_9", "L&ouml;schen");
define("REVLAN_10", "markiere um zu best&auml;tigen");
define("REVLAN_11", "&Ouml;ffne den HTML Editor");
define("REVLAN_12", "&Uuml;berschrift");
define("REVLAN_13", "Unter-&Uuml;berschrift");
define("REVLAN_14", "Zusammenfassung");
define("REVLAN_15", "Bericht");
define("REVLAN_16", "Bewertung");
define("REVLAN_17", "Bitte w&auml;hlen Sie eine Bewertung");
define("REVLAN_18", "Kommentare erlauben?");
define("REVLAN_19", "an");
define("REVLAN_20", "aus");
define("REVLAN_21", "Sichtbar f&uuml;r");
define("REVLAN_22", "Bericht aktualisieren");
define("REVLAN_23", "Bericht &uuml;bermitteln");
define("REVLAN_24", "Berichte");




define("REVLAN_25", "Bericht Kategorie gespeichert");
define("REVLAN_26", "Bericht Kategorie aktualisiert");
define("REVLAN_27", "Kategorie gel&ouml;scht");
define("REVLAN_28", "Kategorie");
define("REVLAN_29", "Optionen");
define("REVLAN_30", "Bearbeiten");
define("REVLAN_31", "L&ouml;schen");
define("REVLAN_32", "Keine Bericht Kategorien");
define("REVLAN_33", "Bestehende Bericht Kategorien");
define("REVLAN_34", "Kategorien Name");
define("REVLAN_35", "Kategorien Icon");
define("REVLAN_36", "Bilder zeigen");
define("REVLAN_37", "Kategorien &Uuml;bersicht");
define("REVLAN_38", "Bericht Kategorie updaten");
define("REVLAN_39", "Bericht Kategorie erstellen");
define("REVLAN_40", "Keine Berichte");
define("REVLAN_41", "Bestehende Berichte");
define("REVLAN_42", "&Ouml;ffne den HTML Editor");
define("REVLAN_43", "Kategorie");
define("REVLAN_44", "Keine");
define("REVLAN_45", "Bericht erste Seite");
define("REVLAN_46", "Neuen Bericht erstellen");
define("REVLAN_47", "Kategorien");
define("REVLAN_48", "Bericht Optionen");
define("REVLAN_49", "Sind Sie sicher diese Kategorie l&ouml;schen zu wollen?");
define("REVLAN_50", "Sind Sie sicher diesen Bericht l&ouml;schen zu wollen?");
define("REVLAN_51", "Autor Angaben");
define("REVLAN_52", "lassen Sie das Feld frei, wenn Sie den Bericht geschrieben haben");
define("REVLAN_53", "Autor Name");
define("REVLAN_54", "Autor Email Adresse");


define("REVLAN_55", "Erlaube Berichte zu &uuml;bermitteln");
define("REVLAN_56", "Erlaube Besuchern Berichte zu &uuml;bermitteln");
define("REVLAN_57", "&Uuml;bermittle Bericht Klasse");
define("REVLAN_58", "W&auml;hlen Sie welche User Berichte &uuml;bermitteln k&ouml;nnen");
define("REVLAN_59", "Aktualisiere Optionen");
define("REVLAN_60", "Bericht Optionen");
define("REVLAN_61", "Bericht Optionen aktualisiert");

define("REVLAN_62", "&Uuml;bermittelte Berichte");
define("REVLAN_63", "Keine Berichte &uuml;bermittelt");
define("REVLAN_64", "Keine Email Adresse angegeben");
define("REVLAN_65", "Bericht &Uuml;berschrift");
define("REVLAN_66", "Eintragen");
define("REVLAN_67", "User &uuml;bermittelten Bericht eintragen");
define("REVLAN_68", "User &uuml;bermittelter Bericht in Datenbank gespeichert");

define("REVLAN_69", "Formular zur&uuml;cksetzen");
define("REVLAN_70", "Hier klicken um Autorfelder auszuf&uuml;llen");
define("REVLAN_71", "E-Mail hinzuf&uuml;gen/Icons drucken?");
define("REVLAN_72", "Ja");
define("REVLAN_73", "Nein");






?>
