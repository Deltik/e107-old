<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_modcomment.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 19:14:20 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("MDCLAN_1", "Moderiert.");
define("MDCLAN_2", "Keine Kommentare f&uuml;r diesen Eintrag");
define("MDCLAN_3", "Mitglied");
define("MDCLAN_4", "Gast");
define("MDCLAN_5", "Blockierung aufheben");
define("MDCLAN_6", "Blockieren");

define("MDCLAN_8", "Kommentare moderieren");
define("MDCLAN_9", "Warnung! Das L&ouml;schen von ganzen Kommentaren l&ouml;scht auch s&auml;mtliche Antworten!");
define("MDCLAN_10", "Optionen");
define("MDCLAN_11", "Kommentar");
define("MDCLAN_12", "Kommentare");
define("MDCLAN_13", "geblockt");
define("MDCLAN_14", "Kommentare loggen");
define("MDCLAN_15", "offen");
define("MDCLAN_16", "gelogged");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>
