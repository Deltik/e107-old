<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_filemanager.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("FMLAN_1", "Hochgeladen");
define("FMLAN_2", "zu");
define("FMLAN_3", "Verzeichnis");
define("FMLAN_4", "Die hochzuladende Datei &uuml;berschreitet die in der php.ini festgelegte Dateigr&ouml;&szlig;e.");
//define("FMLAN_5", "Die hochzuladende Datei &uuml;berschreitet die im HTML Formular festgelegte Dateigr&ouml;&szlig;e (MAX_FILE_SIZE - Anweisung).");
//define("FMLAN_6", "Die Datei wurde nur teilweise hochgeladen.");
//define("FMLAN_7", "Es wurde keine Datei hochgeladen.");
//define("FMLAN_8", "Dateigr&ouml;&szlig;e der hochgeladenen Datei ist 0 Byte");
//define("FMLAN_9", "Die Datei wurde nicht hochgeladen. Dateiname");
//define("FMLAN_10", "Fehler");
//define("FMLAN_11", "Wahrscheinlich falsche Chmod-Rechte f&uuml;r das Upload Verzeischnis.");
define("FMLAN_12", "Datei");
define("FMLAN_13", "Dateien");
define("FMLAN_14", "Verzeichnis");
define("FMLAN_15", "Verzeichnisse");
define("FMLAN_16", "Root Verzeichnis");
define("FMLAN_17", "Name");
define("FMLAN_18", "Gr&ouml;sse");
define("FMLAN_19", "Zuletzt modifiziert");

define("FMLAN_21", "Datei Upload in dieses Verzeichnis");
define("FMLAN_22", "Upload");

define("FMLAN_26", "Gel&ouml;scht");
define("FMLAN_27", "erfolgreich");
define("FMLAN_28", "kann nicht gel&ouml;scht werden");
define("FMLAN_29", "Pfad");
define("FMLAN_30", "Level h&ouml;her");
define("FMLAN_31", "Ordner");
define("FMLAN_32", "Verzeichnis ausw&auml;hlen");
define("FMLAN_33", "Ausw&auml;hlen");
define("FMLAN_34", "Gew&auml;hltes Verzeichnis");
define("FMLAN_35", "Datei Verzeichnis");
define("FMLAN_36", "Custom Men&uuml; Verzeichnis");
define("FMLAN_37", "Custom Page Verzeichnis");

define("FMLAN_38", "Datei erfolgreich verschoben nach");
define("FMLAN_39", "Es ist nicht m&ouml;glich die Datei zu verschieben nach");
define("FMLAN_40", "Newspost-Images Verzeichnis");
define("FMLAN_41", "In Downloads dir. verschieben");
define("FMLAN_42", "In Downloadimages dir. verschieben");
define("FMLAN_43", "Ausgew&auml;hlte Dateien l&ouml;schen");
define("FMLAN_44", "Bitte best&auml;tigen Sie die ausgew&auml;hlte Datei in das DOWNLOADS Verzeichnis verschieben zu wollen.");
define("FMLAN_45", "Bitte best&auml;tigen Sie die ausgew&auml;hlte Datei in das DOWNLOADIMAGES Verzeichnis verscheiben zu wollen.");
define("FMLAN_46", "Bitte best&auml;tigen Sie die ausgew&auml;hlte Datei l&ouml;schen zu wollen.");
define("FMLAN_47", "Benutzer Uploads");
define("FMLAN_48", "Ausgew&auml;hltes verschieben nach");
define("FMLAN_49", "Bitte best&auml;tigen Sie, ausgew&auml;hlte Datei verschieben zu wollen.");
define("FMLAN_50", "Verschieben");


?>
