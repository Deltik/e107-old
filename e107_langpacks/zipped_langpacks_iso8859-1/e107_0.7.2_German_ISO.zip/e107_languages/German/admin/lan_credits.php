<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_credits.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Credits");
define("CRELAN_2", "Im folgenden sehen Sie eine Liste von Drittanbieter-Software / benutzt im e107. Das e107 Entwichlerteam  m&ouml;chte es nicht vers&auml;men sich bei den Entwicklern folgender Software und die Erlaubnis ihren Code im e107 zu verwenden und unter der GPL Lizenz berietgestellt zu haben.");
// define("CRELAN_3", "Herkunft");
// define("CRELAN_4", "Beschreibung");
// define("CRELAN_5", "Webseite");
// define("CRELAN_6", "Erlaubnis");
define("CRELAN_7", "Version");



?>
