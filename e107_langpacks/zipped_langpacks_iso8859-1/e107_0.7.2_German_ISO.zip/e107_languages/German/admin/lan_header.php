<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_header.php,v $
|     $Revision: 1.3 $
|     $Date: 2004/10/25 16:11:40 $
|     $Author: loloirie $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Admin Navigation");
define("LAN_head_2", "Ihr Server erlaubt keine HTTP-Dateien hochzuladen, sodass es Ihren Usern nicht m&ouml;glich sein wird to uploads Avatare/Dateien etc hochzuladen . Um es doch zu erm&ouml;glichen setzen Sie die file_uploads auf On in Ihrer php.ini und starten Sie den Server neu. Wenn Sie keine M&ouml;glichkeit haben auf die php.ini zuzugreifen, wenden Sie sich an Ihren Provider.");
define("LAN_head_3", "Ihr Server l&auml;ft unter einer basedir restriction in effect. Dies verbietet es Ihnen auf Dateien ausserhalb Ihres Home-Verzeichnisses zuzugreifen. Dies kann einige Scripte betreffen, wie zum Beispiel den Filemananger, die dann nicht ordnungsgem&auml;ss arbeiten k&ouml;nnen.");


define("LAN_head_4", "Admin Bereich");
define("LAN_head_5", "angezeigte Sprache des Adminbereiches: ");
define("LAN_head_6", "Plugins Info");

?>
