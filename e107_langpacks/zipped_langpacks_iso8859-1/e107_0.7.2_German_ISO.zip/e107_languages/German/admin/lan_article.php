<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_article.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:04 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("ARLAN_0", "Artikel in Datenbank gespeichert.");
define("ARLAN_1", "Felder sind freigelassen.");
define("ARLAN_2", "Artikel in Datenbank upgedatet.");
define("ARLAN_3", "Hauptkategorie in Datenbank hinzugef&uuml;gt.");
define("ARLAN_4", "Artikel Hauptkategorie in Datenbank upgedatet.");
define("ARLAN_5", "Artikel Hauptkategorie gel&ouml;scht.");
define("ARLAN_6", "Bitte markieren Sie die Best&auml;tigungsbox um den Artikel zu l&ouml;schen");
define("ARLAN_7", "Artikel");
define("ARLAN_8", "Keine Hauptkategorien angelegt");
define("ARLAN_9", "Bestehende Hauptkategorien");
define("ARLAN_10", "Hauptkategorien Titel");
define("ARLAN_11", "Hauptkategorien &Uuml;bersicht");
define("ARLAN_12", "Hauptkategorie");
define("ARLAN_13", "Hauptkategorien");
define("ARLAN_14", "Keine Artikel");
define("ARLAN_15", "Artikel");
define("ARLAN_16", "Keine Hauptkategorien");
define("ARLAN_17", "&Uuml;berschrift");
define("ARLAN_18", "Unter-&Uuml;berschrift");
define("ARLAN_19", "&Uuml;bersicht");
define("ARLAN_20", "Artikel");
define("ARLAN_21", "Erlaube Kommentare?");
define("ARLAN_22", "an");
define("ARLAN_23", "Aus");
define("ARLAN_24", "Email hinzuf&uuml;gen/Icons drucken?");
define("ARLAN_25", "Ja");
define("ARLAN_26", "Nein");
define("ARLAN_27", "Erneute Voransicht");
define("ARLAN_28", "Voransicht");
define("ARLAN_29", "Bitte markieren Sie die Best&auml;tigungsbox um den Artikel zu l&ouml;schen");
define("ARLAN_30", "Artikel gel&ouml;scht.");
define("ARLAN_31", "Erste Buchstaben.");
define("ARLAN_32", "Bitte w&auml;hlen Sie einen Buchstaben.");
define("ARLAN_55", "Sichtbar f&uuml;r");
define("ARLAN_56", "Artikel Kategorie gespeichert");
define("ARLAN_57", "Artikel Kategorie upgedatet");
define("ARLAN_58", "Kategorie gel&ouml;scht");
define("ARLAN_59", "Kategorie");
define("ARLAN_60", "Optionen");
define("ARLAN_61", "Bearbeiten");
define("ARLAN_62", "L&ouml;schen");
define("ARLAN_63", "Keine Artikel Kategorien angelegt");
define("ARLAN_64", "Bestehende Artikel Kategorien");
define("ARLAN_65", "Kategorien Name");
define("ARLAN_66", "Kategorien Icon");
define("ARLAN_67", "Bilder ansehen");
define("ARLAN_68", "Kategorien &Uuml;bersicht");
define("ARLAN_69", "Update Artikel Kategorien");
define("ARLAN_70", "Setze Eingabe auf 0");
define("ARLAN_71", "Artikel Kategorie erstellen");
define("ARLAN_72", "Bestehende Artikel");
define("ARLAN_73", "&Ouml;ffne den HTML Editor");
define("ARLAN_74", "Kategorie");
define("ARLAN_75", "Keine");
define("ARLAN_76", "Artikel Erste Seite");
define("ARLAN_77", "Neuen Artikel erstellen");
define("ARLAN_78", "Kategorien");
define("ARLAN_79", "Artikel Optionen");
define("ARLAN_80", "Sind Sie sicher diese Kategorie l&ouml;schen zu wollen?");
define("ARLAN_81", "Sind Sie sicher diesen Artikel l&ouml;schen zu wollen?");
define("ARLAN_82", "Autor Angaben");
define("ARLAN_83", "frei lassen, wenn Sie den Artikel geschrieben haben");
define("ARLAN_84", "Autor Name");
define("ARLAN_85", "Autor Email Adresse");
define("ARLAN_86", "Erlaube Artikel zu &uuml;bermitteln");
define("ARLAN_87", "Erlaube Besuchern Artikel zu &uuml;bermitteln");
define("ARLAN_88", "&Uuml;bermittle Artikel Klasse");
define("ARLAN_89", "W&auml;hlen Sie welche User Artikel &uuml;bermitteln k&ouml;nnen");
define("ARLAN_90", "Update Optionen");
define("ARLAN_91", "Artikel Optionen");
define("ARLAN_92", "Artikel Optionen upgedatet");
define("ARLAN_93", "&Uuml;bermittelte Artikel");
define("ARLAN_94", "Keine &uuml;bermittelten Artikel");
define("ARLAN_95", "Keine Email Adresse angegeben");
define("ARLAN_96", "Artikel &Uuml;berschrift");
define("ARLAN_97", "Eintragen");
define("ARLAN_98", "User &uuml;bermittelten Artikel eintragen");
define("ARLAN_99", "User &uuml;bermittelter Artikel in Datenbank abgespeichert");
define("ARLAN_100", "Klicken Sie hier um die Autorfelder auszuf&uuml;llen");
define("ARLAN_101", "von");


?>
