<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_submenusgen.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/21 06:27:37 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("LAN_MENGEN_1", "Hauptmen&uuml;links einstellen");
define("LAN_MENGEN_2", "Automatischer Men&uuml; Generator");
define("LAN_MENGEN_3", "Links in einem Submen&uuml; hinzuf&uuml;gen f&uuml;r :");
//define("LAN_MENGEN_4", "News");
define("LAN_MENGEN_5", "Forum");
define("LAN_MENGEN_6", "Artikel");
//define("LAN_MENGEN_7", "Downloads");
define("LAN_MENGEN_8", "F&uuml;r jede Newskategorie wird ein neuer Link im Submen&uuml; angezeigt um die Kategorie direkt zu erreichen");
define("LAN_MENGEN_9", "F&uuml;r jedes Forum wird ein neuer Link im Submen&uuml; angezeigt um das Forum direkt zu erreichen.");
//define("LAN_MENGEN_10", "Alle n&ouml;tigen Links wurden erfolgreich erstellt.");
define("LAN_MENGEN_11", "F&uuml;r jede Artikelkategorie wird ein neuer Link im Submen&uuml; angezeigt um direkt zur Liste der Artikel f&uuml;r diese Kategorie zu gelangen.");
define("LAN_MENGEN_12", "F&uuml;r jede neue Downloadkategorie wird ein neuer Link im Submen&uuml; angezeigt um diese Kategorie direkt zu erreichen");
//define("LAN_MENGEN_13", "Erstelle");
define("LAN_MENGEN_14", "Alle Links im Submen&uuml;");
define("LAN_MENGEN_15", "Nachricht");
//define("LAN_MENGEN_16", "Alle angezeigten Links im Submen&uuml; werden gel&ouml;scht.");
define("LAN_MENGEN_17", "Alle angezeigten Links in ALLEN Submen&uuml;s werden gel&ouml;scht ( NICHT NUR die Submen&uuml;s f&uuml;r ");
//define("LAN_MENGEN_18", "L&ouml;schen");
define("LAN_MENGEN_19", "Hauptmen&uuml; s&auml;ubern");
define("LAN_MENGEN_20", "L&ouml;sche Links in einem Submen&uuml; f&uuml;r");
define("LAN_MENGEN_21", "Alle Links angezeigt im ");
define("LAN_MENGEN_22", "Submen&uuml; werden gel&ouml;scht");
define("LAN_MENGEN_23", "Hauptlinks wurden NICHT gel&ouml;scht. Falls Sie sie l&ouml;schen m&ouml;chten, gehen Sie zu Ihrem");
define("LAN_MENGEN_24", "Link Bereich");
define("LAN_MENGEN_25", "Hauptlink erstellt: ");
define("LAN_MENGEN_26", "Link genannt: ");
define("LAN_MENGEN_27", " ist der HAUPT Link.");
define("LAN_MENGEN_28", " wird nun im Subme&uuml; angezeigt von ");
define("LAN_MENGEN_29", " besteht betreits. Keine &Auml;nderung vollzogen.");
define("LAN_MENGEN_30", " wurde im Submen&uuml; erstellt von ");
define("LAN_MENGEN_31", " Im Linkbereich zu konfigurieren.");
define("LAN_MENGEN_32", " wurde gel&ouml;scht ! ");
define("LAN_MENGEN_33", "Keine Links gel&ouml;scht...");
define("LAN_MENGEN_34", "Andere Hauptlinks:");
define("LAN_MENGEN_35", "Submen&uuml; Links Namen und URLs");
define("LAN_MENGEN_36", "F&uuml;gt Links im Submen&uuml; ein f&uuml;r:");
define("LAN_MENGEN_37", "Name: ");
define("LAN_MENGEN_38", "Sie k&ouml;nnen 1 bis 5 Links diesem Hauptlink unterordnen, aber... falls erforderlich, k&ouml;nnen Sie dieses Tool nochmals n&uuml;tzen um mehr Links einzuf&uuml;gen. Oder nutzen Sie PHPMYADMIN wenn sie zuviele Links einzuf&uuml;gen haben...");
define("LAN_MENGEN_39", "URL:");
define("LAN_MENGEN_40", " Kann nicht erstellt werden, URL fehlt...");
define("LAN_MENGEN_41", "Links");
define("LAN_MENGEN_42", "F&uuml;r jede Linkkategorie wird ein neuer Link im Submen&uuml; erstellt um diese Kategorie direkt zu erreichen");
define("LAN_MENGEN_43", "Alle angezeigten Links im Links Submen&uuml; werden gel&ouml;scht");


?>
