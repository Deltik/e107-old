<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_menus.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/04/05 07:13:47 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("MENLAN_1", "Sichtbar f&uuml;r alle");
define("MENLAN_2", "Nur sichtbar f&uuml;r Mitglieder");
define("MENLAN_3", "Nur sichtbar f&uuml;r Administratoren");
define("MENLAN_4", "Nur sichtbar f&uuml;r Benutzer in ");
//define("MENLAN_5", "Klasse");
define("MENLAN_6", "Men&uuml;-Klasse aktualisieren");
define("MENLAN_7", "Klasse einstellen f&uuml;r");
define("MENLAN_8", "Klasse aktualisiert");
define("MENLAN_9", "Neues Spezialmen&uuml; installiert");
define("MENLAN_10", "Neues Men&uuml; installiert");
define("MENLAN_11", "Men&uuml; entfernt");
define("MENLAN_12", "Dieses Men&uuml; aktivieren - bitte w&auml;hlen Sie einen Ort");
define("MENLAN_13", "Aktivieren im Bereich");
define("MENLAN_14", "Bereich");
define("MENLAN_15", "Deaktivieren");
define("MENLAN_16", "Konfigurieren");
define("MENLAN_17", "Nach oben");
define("MENLAN_18", "Nach unten");
define("MENLAN_19", "Verschieben zum Bereich");
define("MENLAN_20", "Sichtbarkeit");
//define("MENLAN_21", "Nur f&uuml;r G&auml;ste sichtbar");
define("MENLAN_22", "Inaktive Menus");
define("MENLAN_23", "Verschiebe nach unten");
define("MENLAN_24", "Verschiebe nach oben");
define("MENLAN_25", "Funktion ...");
define("MENLAN_26", "Diese Men&uuml; wird <strong>angezeigt</strong> auf den folgenden Seiten.");
define("MENLAN_27", "Diese Men&uuml; wird <strong>versteckt</strong> auf den folgenden Seiten.");
define("MENLAN_28", "Geben Sie eine Seite pro Zeile ein. Achten Sie darauf die Url ausreichend/stimmig einzugeben f&uuml;r Funktionsgarantie.");

define("MENLAN_29", "Layout w&auml;hlen");
define("MENLAN_30", "Um die Men&uuml;-Bereiche und deren Positionen f&uuml;r Benutzer-Layouts zu sehen, w&auml;hlen Sie das Benutzer-Layout hier:");
define("MENLAN_31", "Gesetztes Layout");
define("MENLAN_32", "Newskopf Layout");
define("MENLAN_33", "Benutzer Layout");
define("MENLAN_34", "Eingebettet");
define("MENLAN_35", "Men&uuml;s konfigurieren");
define("MENLAN_36", "W&auml;hlen Sie das Men&uuml; um es zu aktivieren");
define("MENLAN_37", "danach w&auml;hlen Sie bitte den Ort wo das Men&uuml; erscheinen soll.");
define("MENLAN_38", "AltGr gedr&uuml;ckt halten um mehrere Men&uuml;s zu w&auml;hlen.");


?>
