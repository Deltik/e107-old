<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_users.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/04/02 22:09:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("USRLAN_1", "Einstellungen gespeichert.");

define("USRLAN_3", "einen Administrator hinzugef&uuml;gt - Um die Rechte zu vergeben gehe zur");
define("USRLAN_4", "Administratoren Seite");
define("USRLAN_5", "Der Status des Haupseitenadministrators kann nicht ver&auml;ndert werden");
define("USRLAN_6", "hat Administratorstatus entfernen lassen.");
define("USRLAN_7", "Der Hauptseitenadministrator l&auml;sst sich nicht bannen");
define("USRLAN_8", "Gebannte User.");
define("USRLAN_9", "Nichtgebannte User.");
define("USRLAN_10", "Gel&ouml;schte User.");
define("USRLAN_11", "L&ouml;schen r&uuml;ckg&auml;ngig gemacht.");
define("USRLAN_12", "Der Hauptseitenadministrator l&auml;sst sich nicht l&uuml;schen.");
define("USRLAN_13", "Bitte best&auml;tigen Sie das L&ouml;schen dieses Mitglieds");
//define("USRLAN_14", "einmal gel&ouml;scht, kann man es nicht wieder herstellen");
//define("USRLAN_15", "R&uuml;ckg&auml;ngig machen");
define("USRLAN_16", "L&ouml;schbest&auml;tigung");
define("USRLAN_17", "Best&auml;tigung der Userl&ouml;schung");
//define("USRLAN_18", "User aktiviert.");
//define("USRLAN_19", "Suche");
//define("USRLAN_20", "Kriterien");
//define("USRLAN_21", "User ID");
//define("USRLAN_22", "User Name");
//define("USRLAN_23", "Seitenbesuche");
//define("USRLAN_24", "Admin Status");
//define("USRLAN_25", "Status");
//define("USRLAN_26", "Absteigend");
//define("USRLAN_27", "Aufsteigend");
//define("USRLAN_28", "Sortieren");

define("USRLAN_30", "Bannen");
//define("USRLAN_31", "Bannen -inaktiviert-");
define("USRLAN_32", "Aktivieren");
define("USRLAN_33", "Entbannen");
define("USRLAN_34", "Entferne Admin Status");
define("USRLAN_35", "Zum Admin erkl&auml;ren");
define("USRLAN_36", "Klasse vergeben");
//define("USRLAN_37", "Mitglieder");
//define("USRLAN_38", "Search returned");
//define("USRLAN_39", "Resultat(e)");
//define("USRLAN_40", "Nichts gefunden");

define("USRLAN_44", "Erlaube Mitgliedern einen Avatar upzuloaden?");

define("USRLAN_47", "Maximmale Avatarbreite (in Pixel)");
define("USRLAN_48", "gesetzt ist 70");
define("USRLAN_49", "Maximale Avatarh&ouml;he (in Pixel)");
define("USRLAN_50", "gesetzt ist 100");
define("USRLAN_51", "Update Optionen");
define("USRLAN_52", "Member Optionen");
define("USRLAN_53", "Erlaube Mitgliedern ein Foto upzuloaden?");
define("USRLAN_54", "Klicke hier um alle unaktivierten User zu l&ouml;schen");
define("USRLAN_55", "Prune");
define("USRLAN_56", "Gel&ouml;scht");
define("USRLAN_57", "Unaktivierte Mitglieder l&ouml;schen ...");
define("USRLAN_58", "Datei Uploads sind in der php.ini nicht erlaubt");
define("USRLAN_59", "Schnellhinzuf&uuml;gen von Benutzern");
define("USRLAN_60", "Benutzer hinzuf&uuml;gen");
define("USRLAN_61", "Username");
define("USRLAN_62", "Passwort");
define("USRLAN_63", "Wiederhole Passwort");
define("USRLAN_64", "Email Adresse");
define("USRLAN_65", "Dieser Username kann nicht akzeptiert werden, bitte suchen Sie einen anderen");
define("USRLAN_66", "Dieser Username existiert bereits in unserer Datenbank, bitte benutzen Sie einen anderen");
define("USRLAN_67", "Die zwei Passw&ouml;rter stimmen nicht &uuml;berein");
define("USRLAN_68", "Sie haben erforderliche Felder leer gelassen");
define("USRLAN_69", "es scheint keine g&uuml;ltige Email Adresse zu sein");
define("USRLAN_70", "User angelegt");
define("USRLAN_71", "Users Erste Seite");
define("USRLAN_72", "Schnellhinzuf&uuml;gen von Usern");
define("USRLAN_73", "Prune Users");

//define("USRLAN_75", "Optionen");
define("USRLAN_76", "User Optionen");
define("USRLAN_77", "Existierende Users");
define("USRLAN_78", "User Name");
define("USRLAN_79", "Status");
define("USRLAN_80", "Info");

//define("USRLAN_82", "Sind Sie sicher diesen User l&ouml;schen zu wollen?");

define("USRLAN_84", "Es gibt");
define("USRLAN_85", "User, die Ihren Account nicht aktiviert haben - klicken Sie unten um sie zu l&ouml;schen.");
define("USRLAN_86", "Best&auml;tigte User");
define("USRLAN_87", "User Einstellungen upgedated");
define("USRLAN_88", "User Klassen upgedated");

define("USRLAN_90", "Finde Mitglieder");
define("USRLAN_91", "Klassen");
define("USRLAN_92", "Ung&uuml;ltige Zeichen im Benutzernamen");
define("USRLAN_93", "Nichtbest&auml;tigte User l&ouml;schen");
define("USRLAN_94", "L&ouml;sche Registrierungen die nicht best&auml;tigt werden in der Zeitspanne - bitte frei lassen, wenn sie diese Option nicht nutzen m&ouml;chten");
define("USRLAN_95", "Minuten");

define("USRLAN_112", "Nochmaliges Senden der E-mail");
define("USRLAN_113", "Registrierungsdetails f&uuml;r");
define("USRLAN_114", "Guten Tag ");
define("USRLAN_115", "Danke f&uuml;r Ihre Registrierung.");
define("USRLAN_116", "Bitte best&auml;tigen Sie den Wusch eine Best&auml;tigungs E-mail senden zu wollen:");
define("USRLAN_117", "Klicken Sie den unteren Button um die folgende E-mail zu testen:");
define("USRLAN_118", "Test E-mail");

define("USRLAN_120", "Klassen setzen");
define("USRLAN_121", "Mailing");
define("USRLAN_122", "Willkommen");
define("USRLAN_123", "Ihre Registrierungswunsch ist bei uns eingegangen und Ihr Account wurde vorgemerkt bis zur Aktivierung durch Sie.");
define("USRLAN_124", "Ihr Account ist noch auf inaktiv gesetzt. Um ihn zu aktivieren, gehen Sie bitte zu folgendem Link.");
define("USRLAN_125", "von");

define("USRLAN_126", "Erlaube Mitgliedern Mitglieder zu bewerten");
define("USRLAN_127", "Erlaube Kommentare in Mitgliederprofilen");

define("USRLAN_128", "Login Name");


define("LAN_MAINADMIN","Haupt Admin");
define("LAN_ADMIN","Admin");
define("LAN_NOTVERIFIED","Nicht best&auml;tigt");
define("LAN_BANNED","Gebannt");

define("USRLAN_130", "Online User Tracking freischalten");
define("USRLAN_131", "Sie m&uuml;ssen diese Option freischalten um Online User Tracking Optionen verwenden zu k&ouml;nnen, wie online.php, Forum Online Info und Online Men&uuml;s");
define("USRLAN_132", "Freischalten");
define("USRLAN_133", "Benutzer zum Aktualisieren ihrer Einstellungen zwingen");
define("USRLAN_134", "Wenn diese Option freigeschalten ist, wird der Benutzer automatisch zur Benutzer-Einstellungsseite weitergeleitet falls ein erforderliches Feld nicht ausgef&uuml;llt wurde.");
define("USRLAN_135", "Es wurde in der Benutzerinfo keine IP-Adresse gefunden, IP konnte deswegen nicht gebannt werden");
define("USRLAN_136", "Es wurde mehrere Benutzer mit der IP {IP} gefunden, IP konnte deswegen nicht gbannt werden.");
define("USRLAN_137", "Benutzer IP-Adresse {IP} wurde gebannt.");

define("DUSRLAN_1", "ID");
define("DUSRLAN_2", "Angezeigter Name");
define("DUSRLAN_3", "Benutzer Name");
define("DUSRLAN_4", "Eigener Titel");
define("DUSRLAN_5", "Passwort");
define("DUSRLAN_6", "Session");
define("DUSRLAN_7", "Email");
define("DUSRLAN_8", "Webseite");
define("DUSRLAN_9", "ICQ");
define("DUSRLAN_10", "AIM");
define("DUSRLAN_11", "MSN");
define("DUSRLAN_12", "Ort");
define("DUSRLAN_13", "Geburtstag");
define("DUSRLAN_14", "Signatur");
define("DUSRLAN_15", "Bild");
define("DUSRLAN_16", "Zeitzone");
define("DUSRLAN_17", "Email verstecken");
define("DUSRLAN_18", "Tag der Anmeldung");
define("DUSRLAN_19", "Letzter Besuch");
define("DUSRLAN_20", "Besuche bis jetzt");
define("DUSRLAN_21", "Letzter Eintrag");
define("DUSRLAN_22", "Chatbox Eintr&auml;ge");
define("DUSRLAN_23", "Kommentare");
define("DUSRLAN_24", "Forum Eintr&auml;ge");
define("DUSRLAN_25", "IP");
define("DUSRLAN_26", "Verbannung");
define("DUSRLAN_27", "Voreinstellungen");
define("DUSRLAN_28", "Neu");
define("DUSRLAN_29", "Gesehen");
define("DUSRLAN_30", "Besuche");
define("DUSRLAN_31", "Admin");
define("DUSRLAN_32", "Richtiger Name");
define("DUSRLAN_33", "Benutzerklasse");
define("DUSRLAN_34", "Rechte");
define("DUSRLAN_35", "Bild");
define("DUSRLAN_36", "Passwort &Auml;nderung");
define("DUSRLAN_37", "XUP");

define("USRLAN_138", "Unverified users");
define("USRLAN_139", "Ihr Account wurde aktiviert.\n\nSie k&ouml;nnen sich nun auf {SITEURL} mit Ihren Daten einloggen.");

?>
