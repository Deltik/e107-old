<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_mailout.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/01/31 06:06:21 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "&Auml;nderungen speichern");

define("PRFLAN_63", "Test Email senden");
define("PRFLAN_64", "Wenn Sie den Button klicken, wird eine Test Email an den Hauptseitenadministrator geschickt");
define("PRFLAN_65", "Klicken Sie hier um eine Email zu senden an");
define("PRFLAN_66", "Test Email von");
define("PRFLAN_67", "Diese ist eine Test Email, es scheint Ihre Emaileinstellungen funktionieren\n\nGl&uuml;ckwunsch\nvom e107Website System.");
define("PRFLAN_68", "Die Email konnte nicht gesendet werden. Es scheint, Ihr Server ist nicht richtig konfiguriert um Emails zu senden, bitte versuchen Sie es erneut, indem Sie SMTP nutzen, oder kontaktieren Sie ihren Provider um die Funktion sendmail zu checken / Email Server Einstellungen.");
define("PRFLAN_69", "Die Email wurde erfolgreich gesendet, bitte gehen Sie zu Ihrem Emaileingangsordner.");
define("PRFLAN_70", "SMTP freischalten");
define("PRFLAN_71", "Hier markiert, werden die Emails &uuml;ber den SMTP Server verschickt");
define("PRFLAN_72", "SMTP Server");
define("PRFLAN_73", "SMTP Benutzername");
define("PRFLAN_74", "SMTP Passwort");
define("PRFLAN_75", "Die Email konnte nicht gesendet werden. Bitte &uuml;berpr&uuml;fen Sie Ihre SMTP Einstellungen, oder deaktivieren Sie das Senden &uuml;ber SMTP und versuchen es erneut.");

define("MAILAN_01","Von Name");
define("MAILAN_02","Von Email");
define("MAILAN_03","Zu");
define("MAILAN_04","Cc");
define("MAILAN_05","Bcc");
define("MAILAN_06","Betreff");
define("MAILAN_07","Anhang");
define("MAILAN_08","Email senden");
define("MAILAN_09","Benutze den Theme Style");

define("MAILAN_10","Angemeldete Benutzer");
define("MAILAN_11","Variablen einf&uuml;gen");
define("MAILAN_12","Alle Mitglieder");
define("MAILAN_13","Alle nicht aktivierten Mitglieder ");
define("MAILAN_14","F&uuml;r das Versenden gro&szlig;er Anzahl an Mails wird dringend vorgeschlagen freizuschalten. -  in nachfolgenden Voreinstellungen einzustellen.");
define("MAILAN_15","Mail-Out");
define("MAILAN_16","Benutzername");
define("MAILAN_17","Registrierungslink");
define("MAILAN_18","Benutzer id");
define("MAILAN_19","Es wurde keine E-mail Adresse f&uuml;r den Seitenadministrator gefunden. &Uuml;berpr&uuml;fen Sie Ihre Einstellungen und versuchen es erneut.");
define("MAILAN_20","Sendmail-Pfad");
define("MAILAN_21","Massen-Mail Eing&auml;nge");
define("MAILAN_22","Es gibt keine bestehenden, gespeicherten Eing&auml;nge");
define("MAILAN_23","Benutzerklasse: ");
define("MAILAN_24", "Email(s) sind fertig und k&ouml;nnen gesendet werden");



?>
