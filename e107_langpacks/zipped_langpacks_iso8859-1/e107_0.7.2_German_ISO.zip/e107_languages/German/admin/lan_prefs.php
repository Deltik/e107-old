<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_prefs.php,v $
|     $Revision: 1.28 $
|     $Date: 2005/04/18 02:33:01 $
|     $Author: sweetas $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
+----------------------------------------------------------------------------+
*/

define("PRFLAN_1", "Seiten Information");
define("PRFLAN_2", "Seiten Name");
define("PRFLAN_3", "Seiten URL");
define("PRFLAN_4", "Seiten Link Button");
define("PRFLAN_5", "Seiten &Uuml;berschrift");
define("PRFLAN_6", "Seiten Beschreibung");
define("PRFLAN_7", "Hauptseiten Administrator");
define("PRFLAN_8", "Hauptseiten Administrator E-mail");
define("PRFLAN_9", "Seiten Disclaimer");
define("PRFLAN_10", "Layout");
define("PRFLAN_11", "Seiten Layout");
define("PRFLAN_12", "Klicke hier um die Layouts vorher anzusehen");
define("PRFLAN_13", "Zeige Information");
define("PRFLAN_14", "Zeige Layout Information?");
define("PRFLAN_15", "Zeige Seitenaufbauzeit?");
define("PRFLAN_16", "Zeige Sql Queries?");

define("PRFLAN_17", "Seitenausgabe komprimieren mittels gzip");

define("PRFLAN_19", "Registrierungsseite Optionen");


define("PRFLAN_21", "Datumsanzeige Optionen");
define("PRFLAN_22", "Kurz Datum Format");
define("PRFLAN_23", "Lang Datum Format");
define("PRFLAN_24", "Forum Datum Format");
define("PRFLAN_25", "F&uuml;r mehr Informationen zum Forum Datum Format besuchen Sie bitte die");
define("PRFLAN_26", "Time offset");
define("PRFLAN_27", "Beispiel, wenn Sie es auf +2 setzen, werden bei allen Zeitangaben auf Ihrer Page zwei Stunden addiert");
define("PRFLAN_28", "User Registrierung/Posting");
define("PRFLAN_29", "Userregistrierungs System aktivieren?");
define("PRFLAN_30", "erlaubt es Usern sich auf Ihrer Seite zu registrieren");
//define("PRFLAN_31", "Best&auml;tigungsemail bei Registrierung benutzen?");
define("PRFLAN_32", "erlaubt es anonymen Besuchern zu posten?");
define("PRFLAN_33", "wenn nicht markiert, k&ouml;nnen nur registrierte Mitglieder Kommentare posten etc");



define("PRFLAN_35", "Schalte Flood Protection frei?");
define("PRFLAN_36", "Flood Hits");
define("PRFLAN_37", "Flood Zeit");
define("PRFLAN_38", "Beispiel, Flood Hits auf 100 and Flood Zeit auf 50 gesetzt: Wenn irgendeine Unterseite 100 Hits in 50 Sekunden erzielt wird die Seite f&uuml;r 50 Sekunden nicht erreichbar sein");


define("PRFLAN_40", "Filter profanities?");
define("PRFLAN_41", "wenn markiert, swearing wird durch die untere Zeichenkette ersetzt");
define("PRFLAN_42", "Zeichenkette ersetzen");
define("PRFLAN_43", "Wordfilter");
define("PRFLAN_44", "W&ouml;rter zensieren, mit Komma trennen");
define("PRFLAN_45", "COPPA benutzen bei der Registrierung?");
define("PRFLAN_46", "f&uuml;r mehr Informationen &uuml;ber COPPA besuchen Sie bitte");
define("PRFLAN_47", "User Tracking");
define("PRFLAN_48", "Tracking Methode");
define("PRFLAN_49", "Cookies");
define("PRFLAN_50", "Sessions");

define("PRFLAN_52", "&Auml;nderungen speichern");
define("PRFLAN_53", "Seiten Voreinstellungen");


define("PRFLAN_55", "Cookie Name (falls Cookies erlaubt)");
define("PRFLAN_56", "Zeitzone");



define("PRFLAN_58", "Erlaubt es nur Mitgliedern die Webseite zu nutzen");
define("PRFLAN_59", "Hier markieren bedeutet, dass alle Teile der Webseite nur Mitgliedern zug&auml;nglich sind, ausser der ersten Seite und der Registrierung");
define("PRFLAN_60", "Schalte SSL frei");
define("PRFLAN_61", "Schalten Sie SSL Verschl&uuml;sselung nur dann frei <b>wenn Sie sich absolut sicher sind was sie tun!</b>");


define("PRFLAN_76", "Erlaube Bildcode&uuml;berpr&uuml;fung w&auml;hrend des Registrierungsprozesses.");
define("PRFLAN_77", "Adminanzeige Optionen ");
define("PRFLAN_78", "Freilassen um es nicht freizuschalten");
define("PRFLAN_80", "Klicke hier um es anzusehen");
define("PRFLAN_81", "Erlaube Bildcode&uuml;berpr&uuml;fung w&auml;hrend des Loginprozesses.");

define("PRFLAN_83", "Beispiel");


define("PRFLAN_87", "Kommentare");
define("PRFLAN_88", "Klicke hier um -nested- Kommentare zu erlauben");
define("PRFLAN_89", "Zeige neues Kommentar Icon");
define("PRFLAN_90", "Erlaube gepostete Kommentare zu bearbeiten");

define("CUSTSIG_1", "Einstellungen gespeichert!");
define("CUSTSIG_2", "Richtiger Name:");
define("CUSTSIG_3", "Webseite:");
define("CUSTSIG_4", "Geburtstag:");
define("CUSTSIG_5", "Ort:");
define("CUSTSIG_6", "Signatur:");
define("CUSTSIG_7", "Avatar");
define("CUSTSIG_8", "Zeit-Zone:");

define("CUSTSIG_12", "Verstecken");
define("CUSTSIG_13", "Felder");
define("CUSTSIG_14", "Anzeige");
define("CUSTSIG_15", "Ben&ouml;tigt");
define("CUSTSIG_16", "Minimale L&auml;nge des Passworts");
define("CUSTSIG_17", "Anmelden f&uuml;r Inhalt/Mailouts");
define("CUSTSIG_18", "Nichterlaubte Benutzernamen");
define("CUSTSIG_19", "Benutzernamen mit folgendem Text werden abgelehnt, - trenne Eingaben mit Komma");


define("PRFLAN_91", "falls jemand Ihre Seite attackiert durch multiple Serveranfragen, wird die IP automatisch gebannt! Vergewissern Sie sich keine korrekte Serverkonfiguration zu ersetzen.");
define("PRFLAN_92", "Sichere Registrierungsbest&auml;tigung -- Passwort in E-mail verstecken?");
define("PRFLAN_93", "strftime function page zu finden bei php.net");
define("PRFLAN_94", "hier");
define("PRFLAN_95", "Plugin Info Anzeige:");
define("PRFLAN_96", "Zeigt Infos auf allen Adminseiten f&uuml;r jedes Plugin, welches dieses Feature unterst&uuml;tzt");
define("PRFLAN_97", "Globales 'Plugins info' Men&uuml;:");
define("PRFLAN_98", "Falls nicht markiert, wird f&uuml;r jedes Plugin ein eigenes individuelles Men&uuml; angezeigt. Falls markiert, werden alle Infos in einem Men&uuml; angezeigt.");


define("PRFLAN_101", "Textverarbeitung");
define("PRFLAN_102", "<b>Links ersetzen</b>");
define("PRFLAN_103", "Falls markiert, werden gepostete Links mit dem Text ersetzt den Sie in der nachfolgenden Textbox eingegeben k&ouml;nnen. Dadurch wird verhindert, dass sehr lange Links eventuell Ihr Layout verschieben");
define("PRFLAN_104", "<b>Ihr Text um Links zu ersetzen</b>");
define("PRFLAN_105", "Text um Links zu ersetzen. Es k&ouml;nnen auch Grafiken verwendet werden, indem man &lt;img tags benutzt, mit absolutem Pfad zur Grafik.");
define("PRFLAN_106", "Core Voreinstellungen in der Datenbank gespeichert.");
define("PRFLAN_107", "<b>Ihr Text um Email-Link's zu ersetzen</b>");
define("PRFLAN_108", "Text um Email-Links zu ersetzen. Es k&ouml;nnen auch Grafiken verwendet werden, indem man &lt;img tags benutzt, mit absolutem Pfad zur Grafik.");
define("PRFLAN_109", "<b>Zeilenumbruch f&uuml;r lange W&ouml;rter im Haupttext</b>");
define("PRFLAN_110", "W&ouml;rter die l&auml;nger sind als die eingegebenen Attribute, werden in eine neue Zeile gesetzt.");
define("PRFLAN_111", "<b>Zeilenumbruch f&uuml;r lange W&ouml;rter im Men&uuml;text</b>");
define("PRFLAN_112", "An");
define("PRFLAN_113", "Aus");


define("PRFLAN_116", "<b>Erlaube HTML Eintr&auml;ge</b>");
define("PRFLAN_117", "Dies erlaubt Benutzern &uuml;berall auf Ihrer Seite HTML Code zu schreiben. Bitte w&auml,hlen Sie die Benutzerklasse f&uuml;r dieses Feature.");
define("PRFLAN_118", "Benutze Geshi f&uuml;r Syntaxhervorhebung");
define("PRFLAN_119", "Geshi ist ein Open Source Multi-Language Syntaxhervorheber. F&uuml;r mehr Informationen besuchen Sie bitte http://qbnz.com/highlighter/");
define("PRFLAN_120", "Gesetzte Geshi Syntax Sprache");
define("PRFLAN_121", "Falls keine Sprache im code bbtag gew&auml;hlt ist, wird diese Sprache zur Hervorhebung benutzt");
define("PRFLAN_122", "WYSIWYG-Editor f&uuml;r Textbereiche benutzen");
define("PRFLAN_123", "zeigt einen what-you-see-is-what-you-get Editor in den Textbereichen, falls verf&uuml;gbar.");
define("PRFLAN_124", "Benutze 'classic' Nextprev-Aussehen");
define("PRFLAN_125", "Dieses Feature nutzend, werden die n&auml;chsten Seiten als 1 2 3 ... 21 22 23 dargestellt, anstelle des neuen Aussehens mit dem Dropdown-Men&uuml;.");
define("PRFLAN_126", "Text der auf der Registrierungsseite angezeigt werden soll.");
define("PRFLAN_127", "Gepostet Links klickbar machen");
define("PRFLAN_128", "Bei Aktivierung, werden gepostete Links zu Hyperlinks umgewandelt.");
define("PRFLAN_129", "Verhindere Mehrfachlogins");
define("PRFLAN_130", "Hier aktiviert, wir Mehrfacheinloggen mit ein und demselben Benutzernamen/Passwort verhindert (Login Details)");
define("PRFLAN_131", "[php] bbcode aktivieren");
define("PRFLAN_132", "Hier aktiviert, erlaubt es authorisierten Usern [php] code zu posten an bestimmten Stellen.");
define("PRFLAN_133", "Erforderliche GD Erweiterung, nicht gefunden");
define("PRFLAN_134", "Umleiten aller Anfragen zur Seiten URL");
define("PRFLAN_135", "zum Beispiel, falls Sie die Seiten URL oben auf http://foo.com gesetzt haben, wird jede Anfrage auf http://www.foo.com umgeleitet nach http://foo.com");

define("PRFLAN_136", "Maximal erlaubte Registrierungen mit der selben IP Adresse.");

define("PRFLAN_137", "Memory Benutzung anzeigen");
define("PRFLAN_138", "Bild-Code Vertifizierung freischalten bei vergessenem Passwort.");
define("PRFLAN_139", "Warnung anzeigen, wenn Passwort des Hauptseitenadministratorsinnerhalb letzter 30 Tage nicht ge&auml;ndert wurde");
define("PRFLAN_140", "Text der angezeigt wird, nachdem das Registrierungsformular ausgef&uuml;llt wurde.");
define("PRFLAN_141", "Registrierung erlauben mit XML User Profilen");
define("PRFLAN_142", "Nur Flood");
define("PRFLAN_143", "Nur fehlerhafte Logins");
define("PRFLAN_144", "Flood & fehlerhafte Logins");

define("PRFLAN_145", "Links in neuem Fenster");
define("PRFLAN_146", "Hier markiert, werden alle Links in einem neuen Fenster ge&ouml;ffnet (<i>wirkt sich auf die ganze Seite aus</i>). ");
define("PRFLAN_147", "Entwichkler-Modus");
define("PRFLAN_148", "Aktivierung der Entwicklerfunktionen. Nur f&uuml;r Entwickler. Bitte aus Sicherheitsgr&uuml;nden nicht auf &ouml;ffentlichen Seiten verwenden.");
define("PRFLAN_149", "Erweiterte Einstellungen");
define("PRFLAN_150", "e107-Authentifizierungsmethode w&auml;hlen");
define("PRFLAN_151", "e107 - keine alternativen Authentifizierungsmethoden installiert");

define("PRFLAN_31", "Email Verifizierung");
define("PRFLAN_152", "Keine Verifizierung");
define("PRFLAN_153", "Admin &Uuml;berpr&uuml;fung");
define("PRFLAN_154", "Methode f&uuml;r neue Benutzer Verifizierung <br />Falls 'Admin &Uuml;berpr&uuml;fung' gew&auml;hlt wurde, sollten Sie E-Mail Benachrichtigung bei Benutzerregistrierung freischalten <a href='".e_ADMIN."notify.php'>link</a>.");

?>
