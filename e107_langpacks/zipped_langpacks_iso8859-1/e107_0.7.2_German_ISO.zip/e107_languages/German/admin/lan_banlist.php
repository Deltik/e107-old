<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_banlist.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/05/10 17:00:02 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("BANLAN_1", "Verbannung aufgehoben.");
define("BANLAN_2", "Keine Verbannungen.");
define("BANLAN_3", "Existierende Verbannungen");
define("BANLAN_4", "Verbannung aufheben");
define("BANLAN_5", "Geben Sie entweder IP, E-Mail Adresse oder Host ein");

define("BANLAN_7", "Grund");
define("BANLAN_8", "Benutzer verbannen");
define("BANLAN_9", "Benutzer von Seite verbannen");
define("BANLAN_10", "IP / E-mail / Grund");
define("BANLAN_11", "Auto-Verbannung: Mehr als 10 fehlerhafte Loginversuche");



?>
