<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_search.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/04/09 17:58:18 $
|     $Author: sweetas $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Suche");

define("LAN_98", "News Eintr&auml;ge");
define("LAN_99", "Kommentare");
define("LAN_140", "Registrierte Mitglieder");
define("LAN_180", "Suche");
define("LAN_192", "Alle Kategorien");
define("LAN_193", "Kalender");
define("LAN_194", "Alle Kategorien");
define("LAN_195", "Suchen");
define("LAN_196", "&Uuml;bereinstimmungen");
define("LAN_197", "Downloads");
define("LAN_198", "Keine &Uuml;bereinstimmungen gefunden");
define("LAN_199", "Suche nach:");
define("LAN_200", "Kategorien:");
define("LAN_201", "Bitte formulieren Sie ihre Suchanfrage um");
define("LAN_416", "Sie m&uuml;ssen eingelogged sein um Zugriff zu haben");
define("LAN_417", "Suchanfragen m&uuml;ssen mindestens aus 3 Zeichen bestehen.");
define("LAN_418", "Andere Seiten");
define("LAN_SEARCH_1", "Alle ausw&auml;hlen");
define("LAN_SEARCH_2", "Auswahl aufheben");
define("LAN_SEARCH_3", "Eintrag geschrieben am");
define("LAN_SEARCH_4", "Anfrage wurde im News Titel gefunden");
define("LAN_SEARCH_5", "Anfrage wurde im News Text gefunden");
define("LAN_SEARCH_6", "Anfrage wurde im erweiterten News Text gefunden");
define("LAN_SEARCH_7", "geschrieben von");
define("LAN_SEARCH_8", "am");
define("LAN_SEARCH_9", "Ohne Titel");
define("LAN_SEARCH_10", "Gehe zur Seite:");
define("LAN_SEARCH_11", "Resultate");
define("LAN_SEARCH_12", " von ");
define("LAN_SEARCH_13", " in ");
define("LAN_SEARCH_14", "Kategorie:");
define("LAN_SEARCH_15", "Autor:");
define("LAN_SEARCH_16", "Suche eingeschr&auml;nkt");
define("LAN_SEARCH_17", "Entschuldigung, aber die Suchefunktion ist eingeschr&auml;nkt auf eine Suchanfrage pro ");
define("LAN_SEARCH_18", " Sekunde.");
define("LAN_SEARCH_19", "Suche in:");
define("LAN_SEARCH_20", "Autorisierung erfoderlich");
define("LAN_SEARCH_21", "Sie haben keine Berechtigung diese Seite anzusehen.");

define("LAN_SEARCH_22", "Alle Bereiche");
define("LAN_SEARCH_23", "Erweitertes Anfrageformular");
define("LAN_SEARCH_24", "Muss Wort (W&ouml;rter) enthalten");
define("LAN_SEARCH_25", "Muss keine Worte (W&ouml;rter) enthalten");
define("LAN_SEARCH_26", "Genaue Phrase");
define("LAN_SEARCH_27", "Wort(W&ouml;rter) beginnend mit");
define("LAN_SEARCH_28", "Alle - hat keine erweiterte Suchanfragem&ouml;glichkeit");
define("LAN_SEARCH_29", "Basis Suche");
define("LAN_SEARCH_30", "Erweiterte Suche");
define("LAN_SEARCH_31", "Hatt keine erweiterte Suche");
define("LAN_SEARCH_32", "Folgende W&ouml;rter sind von der Suchanfrage ausgeschlossen");
define("LAN_SEARCH_33", "Das folgende Wort ist von der Suchanfrage ausgeschlossen");
define("LAN_SEARCH_34", "Neuer als");
define("LAN_SEARCH_35", "&Auml;lter als");
define("LAN_SEARCH_36", "Immer");
define("LAN_SEARCH_37", "Ein Tag");
define("LAN_SEARCH_38", "Zwei Tage");
define("LAN_SEARCH_39", "Drei Tage");
define("LAN_SEARCH_40", "Eine Woche");
define("LAN_SEARCH_41", "Zwei Wochen");
define("LAN_SEARCH_42", "Drei Wochen");
define("LAN_SEARCH_43", "Ein Monat");
define("LAN_SEARCH_44", "Zwei Monate");
define("LAN_SEARCH_45", "Drei Monate");
define("LAN_SEARCH_46", "Ein halbens Jahr");
define("LAN_SEARCH_47", "Ein Jahr");
define("LAN_SEARCH_48", "Zwei Jahre");
define("LAN_SEARCH_49", "Drei Jahre");

define("LAN_SEARCH_50", "Datum geposted");
define("LAN_SEARCH_51", "Alle Kategorien");
define("LAN_SEARCH_52", "Suchergebnis in");
define("LAN_SEARCH_53", "Ganzer Eintrag");
define("LAN_SEARCH_54", "Nur Titel");
define("LAN_SEARCH_55", "In News Kategorien suchen");
define("LAN_SEARCH_56", "Alle News Kategorien");
define("LAN_SEARCH_57", "Kommentare geschrieben zu");
define("LAN_SEARCH_58", "Alle Bereiche");
define("LAN_SEARCH_59", "Alle Kommentare");
define("LAN_SEARCH_60", "Kommentare geschrieben zu");
define("LAN_SEARCH_61", "Nach Autor");
define("LAN_SEARCH_62", "Gew&auml;htem Datum");
define("LAN_SEARCH_63", "In Kategorie suchen");
define("LAN_SEARCH_64", "Alle Downloadkategorien");
define("LAN_SEARCH_65", "Downloads");
define("LAN_SEARCH_66", "Datum hinzugef&uuml;gt");
define("LAN_SEARCH_67", "Alle Downloads Details");
define("LAN_SEARCH_68", "Datum");
define("LAN_SEARCH_69", "Relevance");

define("LAN_SEARCH_70", "Geschrieben zum Downloadeintrag");
define("LAN_SEARCH_71", "Geschrieben als Anwort zum Newseintrag");
define("LAN_SEARCH_72", "Signatur");
define("LAN_SEARCH_73", "Keine Signatur.");
define("LAN_SEARCH_74", "Gew&auml;hlt am");


?>
