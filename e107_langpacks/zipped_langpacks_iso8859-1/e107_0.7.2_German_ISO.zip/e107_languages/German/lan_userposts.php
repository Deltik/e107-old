<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/30 19:36:50 $
|     $Author: sweetas $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "User Eintr&auml;ge"); 

define("UP_LAN_0", "Alle Forumeintr&auml;ge f&uuml;r ");
define("UP_LAN_1", "Alle Kommentare f&uuml;r ");
define("UP_LAN_2", "Thread");
define("UP_LAN_3", "Ansichten");
define("UP_LAN_4", "Antworten");
define("UP_LAN_5", "Letzter Eintrag");
define("UP_LAN_6", "Threads");
define("UP_LAN_7", "Keine Kommentare");
define("UP_LAN_8", "Keine Eintr&auml;ge");
define("UP_LAN_9", " am ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Geschrieben am: ");
define("UP_LAN_12", "Suche");
define("UP_LAN_13", "Kommentare");
define("UP_LAN_14", "Forum Beitr&auml;ge");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP Adresse");
?>
