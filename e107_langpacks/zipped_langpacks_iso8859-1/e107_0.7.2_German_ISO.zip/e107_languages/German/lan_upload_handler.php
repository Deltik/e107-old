<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_upload_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
+----------------------------------------------------------------------------+
*/

define("LANUPLOAD_1", "Der Dateityp");
define("LANUPLOAD_2", "ist nicht erlaubt und wurde gel&ouml;scht.");
define("LANUPLOAD_3", "Erfolgreich hochgeladen");
define("LANUPLOAD_4", "Zielordner existiert nicht oder ist nicht beschreibbar.");
define("LANUPLOAD_5", "Die hochzuladende Datei &uuml;bersteigt die upload_max_dateigr&ouml;sse Vorgabe in der php.ini.");
define("LANUPLOAD_6", "Die hochzuladende Datei &uuml;bersteigt die MAX_DATEI_Gr&ouml;sse Vorgabe die im html Formular spezifiziert ist.");
define("LANUPLOAD_7", "Die hochzuladende Datei wurde nur teiweise &uuml;bertragen.");
define("LANUPLOAD_8", "Es wurde keine Datei hochgeladen.");
define("LANUPLOAD_9", "Hochgeladene Dateigr&ouml;sse 0 Bytes");
define("LANUPLOAD_10", "Upload fehlgeschlagen  [Doppelter Dateiname] - Eine Datei mit dem selben Namen existiert bereits.");
define("LANUPLOAD_11", "Die Datei ist nicht hochgeladen. Dateiname:");
define("LANUPLOAD_12", "Fehler");


?>
