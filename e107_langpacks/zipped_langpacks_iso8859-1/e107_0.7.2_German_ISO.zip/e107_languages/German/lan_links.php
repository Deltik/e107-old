<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_links.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Links");
define("LAN_61", "Link Kategorien");
define("LAN_62", "Kategorien");
define("LAN_63", "Kategorie");
define("LAN_64", "In dieser Kategorie");
define("LAN_65", "Link");
define("LAN_66", "Links");
define("LAN_67", "Zeige alle Links");
define("LAN_68", "Editieren");
define("LAN_69", "L&ouml;schen");
define("LAN_86", "Kategorie:");
define("LAN_88", "Referals:");
define("LAN_89", "Admin: ");
define("LAN_90", "Einen neuen Link in dieser Kategorie einf&uuml;gen");
define("LAN_91", "Neue Kategorie hinzuf&uuml;gen");
define("LAN_92", "Einen Link &uuml;bermitteln ");
define("LAN_93", "Nachdem Sie Ihren Link &uuml;bermittelt haben, wird er vom Seitenadmin &uuml;berpr&uuml;ft werden und bei Akzeptanz auf der Link Hauptseite ver&ouml;ffentlicht werden.");
define("LAN_94", "Link Name:");
define("LAN_95", "Link URL:");
define("LAN_96", "Link Beschreibung:");
define("LAN_97", "URL zum Link Button:");
define("LAN_98", "Link &uuml;bermitteln");
define("LAN_99", "Danke");
define("LAN_100", "Ihr Link wurde gespeichert und wird von einem Seitenadministrator &uuml;berpr&uuml;ft.");
define("LAN_101", "Bitte hier klicken um eine Link zu &uuml;bermitteln");
define("LAN_102", "Es");
define("LAN_103", "gibt");
define("LAN_104", "sind");
define("LAN_105", "insgesamt");
define("LAN_106", "Unterstrichene Felder sind zwingend auszuf&uuml;llen.");
define("LAN_Links_1", "Links insgesamt");
define("LAN_Links_2", "Insgesamt aktivierte Links");
define("LAN_LINKS_3", "Anonymous");


?>
