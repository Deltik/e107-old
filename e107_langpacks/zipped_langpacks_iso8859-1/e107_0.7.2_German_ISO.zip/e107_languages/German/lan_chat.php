<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_chat.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Chat Box"); 

define("LAN_11", "Chat Box (alle Eintr&auml;ge)");
define("LAN_12", "Chat Eintr&auml;ge");

define("LAN_13", "vom");
define("LAN_14", "Fehler!");
define("LAN_15", "Sie haben nicht die Erlaubnis, diese Seite anzusehen.");

define("LAN_16", "[ Der Eintrag wurde vom Admin geblockt ]");

?>
