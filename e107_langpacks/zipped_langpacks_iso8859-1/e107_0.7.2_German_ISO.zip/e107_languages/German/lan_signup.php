<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_signup.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/04/17 21:24:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Registrierung");
define("LAN_7", "Angezeigter Name: ");
define("LAN_8", "dies ist der Name, der auf der Seite angezeigt wird");
define("LAN_9", "Login Name: ");
define("LAN_10", "dies ist der Name, den Sie f&uuml;r das Login benutzen");
define("LAN_17", "Passwort: ");
define("LAN_103", "Dieser Username kann nicht akzeptiert werden, bitte suchen Sie sich einen anderen");
define("LAN_104", "Dieser Username existiert schon in unserer Datenbank, bitte suchen sie sich einen anderen");
define("LAN_105", "Die beiden Passw&ouml;rter stimmen nicht &uuml;berein");
define("LAN_106", "Es scheint keine g&uuml;ltige E-Mailadresse zu sein");
define("LAN_107", "Danke! Sie sind nun ein registriertes Mitglied bei ");
define("LAN_108", "Registrierung vollst&auml;ndig");
define("LAN_109", "Diese Seite stimmt dem  The Children's Online Privacy Protection Act of 1998 (COPPA) zu und deshalb k&ouml;nnen Registrierungen von Usern unter 13 Jahren, ohne schriftliche Erlaubnis der Eltern nicht angenommen werden. F&uuml;r mehr Informationen lesen Sie bitte ");
define("LAN_110", "Registrierung");
define("LAN_111", "Passwort wiederholen: ");
define("LAN_112", "Email Adresse: ");
define("LAN_113", "Verstecke Email Adresse?: ");
define("LAN_114", "Dies verhindert, dass Ihre Email Adresse auf der Seite angezeigt wird");
define("LAN_123", "Registrierung");
define("LAN_185", "Sie haben erforderliche Felder frei gelassen");
define("LAN_201", "Ja");
define("LAN_200", "Nein");
define("LAN_202", "Registrierung fehlerhaft");
define("LAN_309", "Bitte tragen Sie Ihre Angaben unten ein -  <b>eine Best&auml;tigungs E-mail wird an Ihre Email Adresse gesendet, die g&uuml;ltig sein muss. </b>Wenn Sie nicht wollen das Ihre Email Adresse angezeigt wird, markieren Sie die Verstecke Email Box.");
define("LAN_399", "Fahren Sie fort");
define("LAN_400", "Usernamen und Passw&ouml;rter sind <b>streng vertraulich</b>");
define("LAN_401", "Ihr Benutzeraccount ist nun aktiviert, bitte loggen Sie sich &uuml;ber die Login Box ein. Danke f&uuml;r Ihre Registrierung.");
define("LAN_402", "Registrierung aktiviert");
define("LAN_403", "Willkommen bei ");
define("LAN_404", "Registrierungsinformationen f&uuml;r");
define("LAN_405", "Dieser Teil der Registrierung ist abgeschlossen, Sie werden eine Best&auml;tigungsemail mit Ihren Login informationen erhalten, bitte folgen Sie dem Link in der Email um die Registrierung abzuschliessen und Ihren Benutzeraccount zu aktivieren.");
define("LAN_406", "Herzlichen Dank!");
define("LAN_407", "\n\nBitte speichern Sie die Email zur eigenen Sicherheit, da Ihr Passwort verschl&uuml;sselt wurde und bei Verlust nicht mehr hergestellt werden kann. Sie k&ouml;nnen aber bei Verlust ein neues Passwort beantragen.\n\nVielen Dank f&uuml;r Ihre Registrierung.\n\nBei");
define("LAN_408", "Ein User mit dieser Email Adresse existiert bereits. Bitte benutzen Sie die fpw.php Passwort vergessen Seite um Ihr Passwort zu erhalten.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "Zeichen.");
define("LAN_SIGNUP_3", "Code Verifizierung fehlgeschlagen.");
define("LAN_SIGNUP_4", "Ihr Passwort mu&szlig; mindestens ");
define("LAN_SIGNUP_5", " Zeichen lang sein.");
define("LAN_SIGNUP_6", "Ihr ");
define("LAN_SIGNUP_7", " ist verbindlich");
define("LAN_SIGNUP_8", "Danke!");
define("LAN_SIGNUP_9", "Durchf&uuml;hrung nicht m&ouml;glich.");
define("LAN_SIGNUP_10", "Ja");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Ung&uuml;ltige Zeichen im Benutzernamen!");
define("LAN_410", "Den sichtbaren Code des Bildes bitte eingeben");
define("LAN_411", "Der Anzeigename besteht bereits in der Datenbank, bitte w&auml;hlen Sie einen anderen Anzeigename");
define("LAN_SIGNUP_12", " Bitte speichern Sie ihren Benutzernamen und das Passwort an einem sichern Platz ab, da , einmal verloren, es nicht wieder herstellbar ist.");
define("LAN_SIGNUP_13", "Sie k&ouml;nnen sich nun &uuml;ber die Loginbox einloggen");
define("LAN_SIGNUP_14", "hier");
define("LAN_SIGNUP_15", "Bitte kontaktieren Sie den Hauptseitenadministrator");
define("LAN_SIGNUP_16", "falls Sie Hilfe ben&ouml;tigen.");
define("LAN_SIGNUP_17", "Bitte best&auml;tigen Sie &uuml;ber 13 Jahre alt zu sein.");
define("LAN_SIGNUP_18", "Ihren Registrierungswunsch haben wir mit folgenden Informationen erhalten ...");
define("LAN_SIGNUP_19", "Benutzername");
define("LAN_SIGNUP_20", "Passwort");
define("LAN_SIGNUP_21", "Ihr  Account ist noch als inaktiv gekennzeichnet, falls Sie ihn aktivieren m&ouml;chten, folgen Sie bitte folgendem Link");
define("LAN_SIGNUP_22", "Bitte hier klicken");
define("LAN_SIGNUP_23", "um sich einzuloggen.");
define("LAN_SIGNUP_24", "Vielen dank f&uuml;r Ihre Registrierung auf");
define("LAN_SIGNUP_25", "Ihren Avatar hochladen");
define("LAN_SIGNUP_26", "Ihr Foto hochladen");
define("LAN_SIGNUP_27", "Zeige");

define("LAN_SIGNUP_28", "Wahl des Inhalts/Mail-Listen");

define("LAN_SIGNUP_29", "Eine Best&auml;tigungs-E-mail wird an die hier eingegebene Adresse verschickt, deshalb muss die Adresse g&uuml;ltig sein, die Sie eingeben.");
define("LAN_SIGNUP_30", "Falls Sie es nicht w&uuml;nschen, dass Ihre E-mail Adresse auf der Seite angezeigt wird, markieren Sie bitte die 'verstecke e-mail' Box.");

define("LAN_SIGNUP_31", "URL zu Ihrer XUP Datei");
define("LAN_SIGNUP_32", "Was ist eine XUP Datei?");
define("LAN_SIGNUP_33", "Pfad angeben oder Avatar w&auml;hlen");
define("LAN_SIGNUP_34", "Merke: Jegliche Bilduploads zu diesem Server die vom Administrator f&uuml;r unpassend gehalten werden, werden sofort gel&ouml;scht.");
define("LAN_SIGNUP_35", "Bitte hier klicken um sich zu registrieren wenn Sie eine XUP Datei haben");
define("LAN_SIGNUP_36", "Es ist ein Fehler entstanden beim Erstellen Ihrer Benutzerinformationen, bitte kontaktieren Sie den Seitenadmin");

define("LAN_LOGINNAME", "Login Name");
define("LAN_PASSWORD", "Passwort");
define("LAN_USERNAME", "Angezeigter Name");
define("LAN_EMAIL_01", "Lieber");
define("LAN_EMAIL_04", "Bitte diese E-mail zur eigenen Information aufbewahren.");
define("LAN_EMAIL_05", "Ihr Passwort wurde verschl&uuml;sselt und kann nicht wiederhergestellt werden falls Sie es verlegt oder vergessen haben. Sie k&ouml;nnen aber ein neues beantragen, falls dies passiert ist.");
define("LAN_EMAIL_06", "Danke f&uuml;r Ihre Registrierung.");

define("LAN_SIGNUP_37", "Dieser Teil der Registrierung ist vollst&auml;ndig. Der Seitenadmin wird Ihren Wunsch Mitgleidschaft &uuml;berpr&uuml;fen.  Sie werden nach Pr&uuml;fung eine E-mail erhalten mit Ank&uuml;ndigung dass Ihr Wunsch auf Mitgliedschaft &uuml;berpr&uuml;ft wurde.");
define("LAN_SIGNUP_38", "Sie haben zwei verschiedene E-mail Adressen eingegeben. Bitte geben Sie EINE g&uuml;ltige E-mail-Adresse in beide Felder ein.");
define("LAN_SIGNUP_39", "E-mail Adresse nochmals eingeben:");


?>
