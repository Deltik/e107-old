<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
//v.616
define("ONLINE_EL1", "G&auml;ste: ");
define("ONLINE_EL2", "Mitglieder: ");
define("ONLINE_EL3", "Auf dieser seite: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Mitglieder");
define("ONLINE_EL6", "Neuestes Mitglied");
define("ONLINE_EL7", "befindet sich auf");
define("ONLINE_EL8", "am meisten online: ");
define("ONLINE_EL9", "am");
define("ONLINE_EL10", "Mitglieds Name");
define("ONLINE_EL11", "Befindet sich auf Seite");
define("ONLINE_EL12", "Antworten");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Thread");
define("ONLINE_EL15", "Seite");
define("CLASSRESTRICTED", "Benutzerklassen beschr&auml;nkte Seite");
define("ARTICLEPAGE", "Artikel/Bericht");
define("CHAT", "Chat");
define("COMMENT", "Kommentare");
define("DOWNLOAD", "Downloads");
define("EMAIL", "email.php");
define("FORUM", "Haupt Forum Index");
define("LINKS", "Links");
define("NEWS", "News");
define("OLDPOLLS", "Old Umfragen");
define("POLLCOMMENT", "Umfrage");
define("PRINTPAGE", "Drucken");
define("LOGIN", "Einloggen");
define("SEARCH", "Suchen");
define("STATS", "Seitenstatistik");
define("SUBMITNEWS", "News eintragen");
define("UPLOAD", "Uploads");
define("USERPAGE", "Mitglieder Profile");
define("USERSETTINGS", "Benutzer Einstellungen");
define("ONLINE", "Benutzer Online");
define("LISTNEW", "News Eintr&auml;ge auflisten");
define("USERPOSTS", "Benutzer Eintr&auml;ge");
define("SUBCONTENT", "&Uuml;bermittle Artikel/Bericht");
define("TOP", "Top Posters/Meist aktive Threads");
define("ADMINAREA", "Admin Bereich");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Ereignis Liste");
define("CALENDAR", "Ereignis Kalender");
define("FAQ", "Faq");
define("PM", "Private Nachrichten");
define("SURVEY", "Umfragen");
define("ARTICLE", "Artikel");
define("CONTENT", "Inhaltsseiten");
define("REVIEW", "Bericht");

?>
