<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Upload");

define("LAN_20", "Fehler");
define("LAN_61", "Ihr Name: ");
define("LAN_112", "E-mail Adresse: ");
define("LAN_144", "Webseiten URL: ");
define("LAN_402", "Sie m&uuml;ssen ein tregistriertes Mitgleid sein um Dateien auf diesen Server hochladen zu k&ouml;nnen.");
define("LAN_403", "Sie haben nicht die n&ouml;tigen Rechte um Dateien auf diesen Server zu laden.");
define("LAN_404", "Danke. Ihr Upload wird von einem Administrator &uuml;berpr&uuml;ft werden und falls angenommen, freigeschalten werden.");
define("LAN_405", "Die Datei &uuml;berschreitet das maximale Dateigr&ouml;&szlig;enlimit - sie wurde gel&ouml;scht.");
define("LAN_406", "Zur Beachtung");
define("LAN_407", "Andere Dateitypen werden sofort gel&ouml;scht.");
define("LAN_408", "Unterstrichene");
define("LAN_409", "Dateiname");
define("LAN_410", "Version");
define("LAN_411", "Datei");
define("LAN_412", "Screenshot");
define("LAN_413", "Beschreibung");
define("LAN_414", "Funktionierende Demo");
define("LAN_415", "Geben Sie hier die URL zur Seite an, wo die Demo angesehen werden kann");
define("LAN_416", "&Uuml;bermittlung und Upload");
define("LAN_417", "Datei hochladen");
define("LAN_418", "Maximale Dateigr&ouml;&szlig;e: ");
define("DOWLAN_11", "Kategorie");
define("LAN_419", "Erlaubte Dateitypen");
define("LAN_420", "Felder sind notwendig");

define("TOP_LAN_0", "Top Forum Poster");
define("TOP_LAN_1", "Benutzer Name");
define("TOP_LAN_2", "Eintr&auml;ge");
define("TOP_LAN_3", "Top Kommentare Poster");
define("TOP_LAN_4", "Kommentare");
define("TOP_LAN_5", "Top Chatbox Poster");
define("TOP_LAN_6", "Seitenbewertung");

//v.616
define("LAN_1", "Thread");
define("LAN_2", "Poster");
define("LAN_3", "Ansichten");
define("LAN_4", "Antworten");
define("LAN_5", "Letzter Eintrag");
define("LAN_6", "Threads");
define("LAN_7", "Meist aktiven Threads");
define("LAN_8", "Top Poster");


?>
