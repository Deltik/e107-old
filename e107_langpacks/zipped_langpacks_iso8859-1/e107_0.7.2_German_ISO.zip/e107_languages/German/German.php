<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/German.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/29 07:43:11 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'de_DE@euro', 'de_DE', 'deu_deu');
define("CHARSET", "ISO-8859-1");
define("CORE_LC", 'de');
define("CORE_LC2", 'de');
define("CORE_LAN1","Fehler : Theme fehlt.\\n\\n&Auml;ndern Sie das Theme unter Einstellungen oder laden Sie ein neues Theme auf den Server.");
//v.616
define("CORE_LAN2"," \\1 schrieb:");// "\\1" Zeigt den Usernamen noch einmal.
define("CORE_LAN3","Dateianhang nicht erlaubt/ausgeschaltet");
?>
