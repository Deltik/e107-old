<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_newspost.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Newseintrag gel&ouml;scht.");
define("NWSLAN_2", "Bitte best&auml;tigen Sie das L&ouml;schen dieses Newseintrags, indem Sie die Box markieren.");
define("NWSLAN_3", "Keine Newseintr&auml;ge bis jetzt.");
define("NWSLAN_4", "Bestehende News");
define("NWSLAN_5", "&Ouml;ffne den HTML-Editor");
define("NWSLAN_6", "Kategorie");
define("NWSLAN_7", "Bearbeiten");
define("NWSLAN_8", "L&ouml;schen");
define("NWSLAN_9", "markiere um zu best&auml;tigen");
define("NWSLAN_10", "Keine Kategorien bis jetzt angelegt.");
define("NWSLAN_11", "Hinzuf&uuml;gen/Bearbeiten von Kategorien");
define("NWSLAN_12", "Titel");
define("NWSLAN_13", "Inhalt");
define("NWSLAN_14", "Erweitert");
define("NWSLAN_15", "Kommentare");
define("NWSLAN_16", "erlaubt");
define("NWSLAN_17", "nicht erlaubt");
define("NWSLAN_18", "Erlaube Kommentare abzugeben");
define("NWSLAN_19", "Aktivierung");
define("NWSLAN_20", "Bitte frei lassen um Auto-Aktivierung nicht zu erlauben");
define("NWSLAN_21", "Aktiviere zwischen");
define("NWSLAN_22", "Sichtbarkeit");
define("NWSLAN_23", "Hier markiert, ist es nur Mitgliedern dieser Klasse sichtbar");
define("NWSLAN_24", "Nochmalige Voransicht");
define("NWSLAN_25", "News in Datenbank updaten");
define("NWSLAN_26", "News in Datenbank eintragen");
define("NWSLAN_27", "Voransicht");
define("NWSLAN_28", "Neue Story");
define("NWSLAN_29", "News Eintrag");

define("NWSLAN_30", "Zeige nur den Titel");

?>
