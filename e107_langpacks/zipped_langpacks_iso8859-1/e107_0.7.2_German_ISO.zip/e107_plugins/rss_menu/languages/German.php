<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/rss_menu/languages/German.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/08 12:15:42 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
	
define("BACKEND_MENU_L1", " k&ouml;nnen eingespeist werden, wenn Sie diese rss Feeds nutzen.");
define("BACKEND_MENU_L2", "RSS Einspeisungen");

define("BACKEND_MENU_L3", "Unsere News");
define("BACKEND_MENU_L4", "Unsere Kommentare");
define("BACKEND_MENU_L5", "Unsere Forum Threads");
define("BACKEND_MENU_L6", "Unsere Forumeintr&auml;ge");

define("BACKEND_MENU_L7", "Unsere Chatboxeintr&auml;ge");
define("BACKEND_MENU_L8", "Unsere Bugtrackereintr&auml;ge");
define("BACKEND_MENU_L9", "Unsere Downloads");

define("RSS_LAN01", "Wollen Sie f&uuml;r jede Newskategorie eine M&ouml;glichkeit geben, seperate Feeds zu erlauben?");
define("RSS_LAN02", "Wollen Sie f&uuml;r jede Downloadkategorie die M&ouml;glichkeit geben, seperate Feeds zu erlauben?");

define("RSS_NEWS","News");
define("RSS_COM","Kommentare"); 
define("RSS_ART","Artikel");
define("RSS_REV", "Berichte");
define("RSS_FT","Forum Threads");
define("RSS_FP","Forum Eintr&auml;ge");
define("RSS_FSP","Forum Spezielle Eintr&auml;ge");
define("RSS_BUG","Bugtracker");
define("RSS_FOR","Forum");
define("RSS_DL","Downloads");
	
?>
