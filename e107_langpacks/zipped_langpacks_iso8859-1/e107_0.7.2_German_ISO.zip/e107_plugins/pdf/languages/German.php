<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/01/11 15:54:58 $
|     $Author: lisa_ $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF Erstellung Support");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Das Plugin kann ab sofort genutzt werden.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF Voreinstellungen");
define("PDF_LAN_3", "freigeschalten");
define("PDF_LAN_4", "nicht freigeschalten");
define("PDF_LAN_5", "Seitenabstand links");
define("PDF_LAN_6", "Seitenabstand rechts");
define("PDF_LAN_7", "Seitenabstand oben");
define("PDF_LAN_8", "Schriftart");
define("PDF_LAN_9", "Gesetzte Schriftgr&ouml;&szlig;e");
define("PDF_LAN_10", "Schriftgr&ouml;&szlig;e Seitenname");
define("PDF_LAN_11", "Schriftgr&ouml;&szlig;e Seitenurl");
define("PDF_LAN_12", "Schriftgr&ouml;&szlig;e Seitennummer");
define("PDF_LAN_13", "Logo anzeigen?");
define("PDF_LAN_14", "Seitenname anzeigen?");
define("PDF_LAN_15", "Erstellungsseiten-Url anzeigen?");
define("PDF_LAN_16", "Seitennummer anzeigen?");
define("PDF_LAN_17", "Aktualisieren");
define("PDF_LAN_18", "PDF -Voreinstellungen erfolgreich aktualisiert");
define("PDF_LAN_19", "Seite");
define("PDF_LAN_20", "Fehler Anzeige");

?>
