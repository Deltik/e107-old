<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/German/lan_forum_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/03/08 16:25:07 $
|     $Author: sweetas $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Suche im Forum");
define("FOR_SCH_LAN_3", "Alle Foren");
define("FOR_SCH_LAN_4", "Ganzer Post");
define("FOR_SCH_LAN_5", "Als Teil des Threads");

?>
