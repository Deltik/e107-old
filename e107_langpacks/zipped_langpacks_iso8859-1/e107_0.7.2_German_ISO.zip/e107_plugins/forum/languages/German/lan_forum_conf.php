<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/German/lan_forum_conf.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:52:49 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("FORLAN_5", "Umfrage gel&ouml;scht.");
define("FORLAN_6", "Thread gel&ouml;scht");
define("FORLAN_7", "Antworten gel&ouml;scht");
define("FORLAN_8", "L&ouml;schen aufgehoben.");
define("FORLAN_9", "Thread verschoben.");
define("FORLAN_10", "Verschieben aufgehoben");
define("FORLAN_11", "Zur&uuml;ck zu den Foren");
define("FORLAN_12", "Forum Konfiguration");
define("FORLAN_13", "Sind Sie absolut sicher diese Umfrage l&ouml;schen zu wollen?<br />Einmal gel&ouml;scht <b><u>kann sie nicht wieder</u></b> hergestellt werden");
define("FORLAN_14", "Aufheben");
define("FORLAN_15", "Best&auml;tigung den Foreneintrag l&ouml;schen zu wollen");
define("FORLAN_16", "Best&auml;tigung die Umfrage l&ouml;schen zu wollen");
define("FORLAN_17", "geschrieben von");
define("FORLAN_18", "Sind Sie absolut sicher diesen Foren-Thread l&ouml;schen zu wollen");
define("FORLAN_19", "und die zugeh&ouml;rigen Eintr&auml;ge?");
define("FORLAN_20", "Die Umfrage wird dann auch gel&ouml;scht");
define("FORLAN_21", "einmal gel&ouml;scht");
define("FORLAN_22", "Eintrag?<br /> Einaml gel&ouml;scht");
define("FORLAN_23", "<b><u>kann es nicht wieder</u></b> hergestellt werden.");
define("FORLAN_24", "Verschiebe den Thread zum Forum");
define("FORLAN_25", "Verschiebe den Thread");
define("FORLAN_26", "Antwort gel&ouml;scht");
define("FORLAN_27", "verschoben");

define("FORLAN_28", "Threadnamen nicht umbenennen");
define("FORLAN_29", "Hinzuf&uuml;gen");
define("FORLAN_30", "zum Titel");
define("FORLAN_31", "Umbenennen nach:");
define("FORLAN_32", "Threadoptionen umbenennen:");


?>
