<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/German/lan_newforumposts_menu.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/04 15:49:47 $
|     $Author: mcfly_e107 $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("NFP_1", "Alle letzten Forumeintr&auml;ge sind ausserhalb Ihrer Gesetzten Benutzerklasse, deswegen besteht keine M&ouml;glichkeit sie anzuzeigen.");
define("NFP_2", "Keine Eintr&auml;ge");
define("NFP_3", "New Forum Posts Men&uuml; Konfiguration gespeichert");
define("NFP_4", "&Uuml;berschrift");
define("NFP_5", "Anzahl der Eintr&auml;ge die angezeigt werden sollen?");
define("NFP_6", "Anzahl der Zeichen die angezeigt werden?");
define("NFP_7", "Postfix f&uuml;r zu lange Eintr&auml;ge?");
define("NFP_8", "Zeige die orginalen Topics im Men&uuml;?");
define("NFP_9", "Men&uuml;einstellungen aktualisieren");
define("NFP_10", "New Forum Posts Men&uuml; Konfiguration");
define("NFP_11", "Geschrieben von");

?>
