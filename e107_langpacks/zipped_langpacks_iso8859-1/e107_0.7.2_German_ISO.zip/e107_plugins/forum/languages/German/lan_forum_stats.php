<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/German/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/25 11:38:50 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Forum Statistik");

define("FSLAN_1", "Generell");
define("FSLAN_2", "Forum er&ouml;ffnet");
define("FSLAN_3", "Ge&ouml;ffnet seit");
define("FSLAN_4", "Eintr&auml;ge insgesamt");
define("FSLAN_5", "Forum Topics");
define("FSLAN_6", "Forum Antworten");
define("FSLAN_7", "Forum Thread Ansichten");
define("FSLAN_8", "Datenbankgr&ouml;sse (nur Forumtabellen)");
define("FSLAN_9", "Durchschnittliche Zeilenl&auml;nge in den Forumtabellen");
define("FSLAN_10", "Aktivste Topics");
define("FSLAN_11", "Rang");
define("FSLAN_12", "Topic");
define("FSLAN_13", "Antworten");
define("FSLAN_14", "Gestartet von");
define("FSLAN_15", "Datum");
define("FSLAN_16", "Meist gesehene Topics");
define("FSLAN_17", "Ansichten");
define("FSLAN_18", "Top Posters");
define("FSLAN_19", "Name");
define("FSLAN_20", "Eintr&auml;ge");
define("FSLAN_21", "Top Topic Starter");
define("FSLAN_22", "Top Antworter");
define("FSLAN_23", "Forum Statistiken");
define("FSLAN_24", "Durchschnittliche Eintr&auml;ge pro Tag");

?>
