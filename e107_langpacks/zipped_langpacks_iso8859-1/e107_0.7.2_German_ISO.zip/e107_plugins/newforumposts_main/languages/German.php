<?php

define("NFPM_LAN_1", "Eintrag");
define("NFPM_LAN_2", "Schreiber");
define("NFPM_LAN_3", "Ansichten");
define("NFPM_LAN_4", "Antworten");
define("NFPM_LAN_5", "Letzter Eintrag");
define("NFPM_LAN_6", "Eintr&auml;ge");
define("NFPM_LAN_7", "von");

define("NFPM_L1", "Dieses Plugin zeigt eine Liste von Neuen Forumseintr&auml;gen auf der Hauptseite");
define("NFPM_L2", "Letzte Forumeintr&auml;ge"); 
define("NFPM_L3", "Zum Konfigurieren klicken Sie bitte auf der Adminhauptseite - Neue Forum Eintr&auml;ge -");
define("NFPM_L4", "In welchem Bereich aktivieren?");
define("NFPM_L5", "Inaktiv");
define("NFPM_L6", "Oben auf der Seite");
define("NFPM_L7", "Unten auf der Seite");
define("NFPM_L8", "&Uuml;berschrift");
define("NFPM_L9", "Die Anzahl der anzuzeigenden neuen Eintr&auml;ge?");
define("NFPM_L10", "Anzeige im srollenden Bereich?");
define("NFPM_L11", "Layer H&ouml;he");
define("NFPM_L12", "Konfiguration");
define("NFPM_L13", "Einstellungen aktualisieren");
define("NFPM_L14", "Einstellungen aktualisiert.");
define("NFPM_L15", "Markieren Sie hier um die letzten Forumeintr&auml;ge anzeigen zu lassen.<br />Gesetzt sind letzte Forumtopics.");
define('NFPM_L16', '[Benutzer gel&ouml;scht]');


?>
