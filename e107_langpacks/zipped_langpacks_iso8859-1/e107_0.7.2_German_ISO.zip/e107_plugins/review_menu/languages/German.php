<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/review_menu/languages/German.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:53:17 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("LAN_190", "Bericht &uuml;bermitteln");
define("LAN_RVW_1", "Men&uuml;einstellungen aktualisieren");
define("LAN_RVW_2", "Berichte men&uuml; Konfiguaration gespeichert");
define("LAN_RVW_3", "&Uuml;berschrift");
define("LAN_RVW_4", "Anzahl der Berichte die angezeigt werden sollen");
define("LAN_RVW_5", "Zeige Berichte-Kategorien im Men&uuml;?");
define("LAN_RVW_6", "Titel f&uuml;r die Berichte Auflistungseite");
define("LAN_RVW_7", "Zeige Link um Berichte zu &uuml;bermitteln?");
define("LAN_RVW_8", "Berichte Men&uuml; Konfiguration");

?>
