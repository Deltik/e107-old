<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content_help.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/05/14 16:46:43 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("CONTENT_ADMIN_HELP_ORDER_1", "
<i>Diese Seite zeigt alle bestehenden Kategorien und Unerkategorien.</i><br /><br />
<b>Ausf&uuml;hrliche Liste</b><br />Sie sehen die Kategorie Id und den Kategorie Namen. Ausserdem sehen Sie verschiedene Optionen, die Sortierung der Kategorien zu managen.<br />
<br />
<b>Erkl&auml;rung der Icons</b><br />
".CONTENT_ICON_ORDERALL." Managed die globale Sortierung der Inhaltseintr&auml;ge unabh&auml;ngig von Kategorien.<br />
".CONTENT_ICON_ORDERCAT." Managed die Sortierung der Inhaltseintr&auml;ge in der speziellen Kategorie.<br />
<img src='".e_IMAGE."admin_images/up.png' alt='' /> Der -Nachoben-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach oben zu verschieben.<br />
<img src='".e_IMAGE."admin_images/down.png' alt='' /> Der -Nachunten-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach unten zu verschieben.<br />
<br />
<b>Sortierung</b><br />Hier k&ouml;nnen sie manuell die Sortierung der Kategorien inerhalb der Hauptkategorien vornehmen. Hierzu m&uuml;ssen Sie den Wert in den Auswahlboxen &auml;ndern und dann den Aktualisierungsbutton klicken, um die Neue Sortierung abzuspeichern.<br />
");
define("CONTENT_ADMIN_HELP_ORDER_2", "
<i>Diese Seite zeigt alle Inhaltseintr&auml;ge der Kategorie , die Sie ausgew&auml;hlt haben.</i><br /><br />
<b>Ausf&uuml;hrliche Liste</b><br />Sie sehen die Inhalts Id, den Inhalts Autor und die Inhalts&uuml;berschrift. Ausserdem sehen Sie verschiedene Optionen, die Sortierung der Inhaltseintr&auml;ge zu managen.<br />
<br />
<b>Erkl&auml;rung der Icons</b><br />
<img src='".e_IMAGE."admin_images/up.png' alt='' /> Der -Nachoben-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach oben zu verschieben.<br />
<img src='".e_IMAGE."admin_images/down.png' alt='' /> Der -Nachunten-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach unten zu verschieben.<br />
<br />
<b>Sortierung</b><br />Hier k&ouml;nnen sie manuell die Sortierung der Kategorien inerhalb der Hauptkategorien vornehmen. Hierzu m&uuml;ssen Sie den Wert in den Auswahlboxen &auml;ndern und dann den Aktualisierungsbutton klicken, um die Neue Sortierung abzuspeichern.<br />
");
define("CONTENT_ADMIN_HELP_ORDER_3", "
<i>Diese Seite zeigt alle Inhaltseintr&auml;ge der Haupt-Kategorie , die Sie ausgew&auml;hlt haben.</i><br /><br />
<b>Ausf&uuml;hrliche Liste</b><br />Sie sehen die Inhalts Id, den Inhalts Autor und die Inhalts&uuml;berschrift. Ausserdem sehen Sie verschiedene Optionen, die Sortierung der Inhaltseintr&auml;ge zu managen.<br />
<br />
<b>Erkl&auml;rung der Icons</b><br />
<img src='".e_IMAGE."admin_images/up.png' alt='' /> Der -Nachoben-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach oben zu verschieben.<br />
<img src='".e_IMAGE."admin_images/down.png' alt='' /> Der -Nachunten-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach unten zu verschieben.<br />
<br />
<b>Sortierung</b><br />Hier k&ouml;nnen sie manuell die Sortierung der Kategorien inerhalb der Hauptkategorien vornehmen. Hierzu m&uuml;ssen Sie den Wert in den Auswahlboxen &auml;ndern und dann den Aktualisierungsbutton klicken, um die Neue Sortierung abzuspeichern.<br />
");



define("CONTENT_ADMIN_HELP_SUBMIT_1", "
<i>Auf dieser Seite sehen Sie eine Liste aller Inhaltseintr&auml;ge, die durch User &uuml;bermittelt wurden.</i><br /><br />
<b>Ausf&uuml;hrliche Liste</b><br />Sie sehen eine Liste dieser Inhaltseintr&auml;ge mit deren Id, Icon, Hauptkategorie, &Uuml;berschrift [Unter-&Uuml;berschrift], Autor und Optionen.<br /><br />
<b>Optionen</b><br />Sie k&ouml;nnen mit den angezeigten Buttons Inhaltseintr&auml;ge vornehmen oder l&ouml;schen.
");



define("CONTENT_ADMIN_HELP_CAT_1", "
<i>Diese Seite zeigt alle verf&uuml;gbaren Haupt- und Unterkategorien.</i><br /><br />
<b>Ausf&uuml;hrliche Liste</b><br />Sie sehen einen Liste aller Unterkategorien mit deren Id, Icon, Autor, Kategorie [Unter&uuml;berschrift] und Optionen.<br />
<br />
<b>Erkl&auml;rung der Icons</b><br />
".CONTENT_ICON_EDIT." : f&uuml;r alle Kategorien k&ouml;nnen Sie diesen Button klicken um Sie zu bearbeiten.<br />
".CONTENT_ICON_DELETE." : f&uuml;r alle Kategorien k&ouml;nnen Sie diesen Button klicken um sie zu l&ouml;schen.<br />
".CONTENT_ICON_OPTIONS." : f&uuml;r alle Hauptkategorien (oben auf der Liste) k&ouml;nnen Sie diesen Button klicken um Optionen zu setzen und bearbeiten.<br />
");
define("CONTENT_ADMIN_HELP_CAT_2", "
".CONTENT_ICON_CONTENTMANAGER_SMALL." : (Nur f&uuml;r den Seitenadmin) f&uuml;r jede Unterkategorie k&ouml;nnen Sie diesen Button klicken um den pers&ouml;nlichen Inhaltsmanager f&uuml;r andere Admins zu managen.<br />
<br />
<b>Pers&ouml;nlicher Inhaltsmanager</b><br />Sie k&ouml;nnen verschiedenen Kategorien Admins zuweisen. Dadurch k&ouml;nnen diese Admins, ihre pers&ouml;nlichen Inhaltseintr&auml;ge dieser Kategorie ausserhalb der Administrationsseite managen (content_manager.php).
");
define("CONTENT_ADMIN_HELP_CAT_3", "
<i>Diese Seite erlaubt Ihnen, neue Kategorien zu erstellen</i><br /><br />
IMMER ZUERST EINEN HAUPTKATEGORIE W&Auml;HLEN, BEVOR SIE DIE ANDEREN FELDER AUSF&Uuml;LLEN !<br /><br />
Dies muss getan werden, da Kategorievoreinstellungen im System geladen werden m&uuml;ssen.
");
define("CONTENT_ADMIN_HELP_CAT_4", "
<i>Diese Seite zeigt das Kategoriebearbeitungsformular.</i><br /><br />
<b>Kategoriebearbeitungsformular</b><br />Sie k&ouml;nnen nun alle Informationen f&uuml;r diese (Unter)Kategorien bearbeiten und die &Auml;nderungen &uuml;bermitteln.
");
define("CONTENT_ADMIN_HELP_CAT_5", "
");
define("CONTENT_ADMIN_HELP_CAT_6", "
<i>Diese Seite zeigt die Optionen, die Sie f&uuml;r diese Hauptkategorie setzen k&ouml;nnen. F&uuml;r jede Hauptkategorie k&ouml;nnen eigene spezifische Optionen gesetzt werden.</i><br /><br />
<b>Gesetzte Werte</b><br />Gesetzt ist, dass ale Werte pr&auml;sent sind und in den Voreinstellungen aktualisiert, wenn Sie diese Seite ansehen, sie k&ouml;nnen aber jedwede &Auml;nderungen vornehmen und Ihren Bed&uuml;rfnissen anpassen.<br /><br />
<b>Teilung in acht Bereiche</b><br />Die Optionen sind in acht Hauptbereiche unterteilt. Die verschiedEnen Bereiche sehen Sie im rechten Men&uuml;.<br /><br />
<b>Erstellen</b><br />in diesem Bereich k&ouml;nnen Sie Optionen festlegen f&uuml;r die Erstellung von Inhaltseintr&auml;gen auf den Adminseiten.<br /><br />
<b>&Uuml;bermitteln</b><br />in diesem Bereich k&ouml;nnen Sie die Optionen f&uuml;r das &Uuml;bermittlungsformular der Inhaltseintr&auml;ge festlegen.<br /><br />
<b>Pfad und Theme</b><br />in diese Bereich k&ouml;nnen Sie ein Theme f&uuml;r diese Hauptkategorie setzen, und Pfade angeben, wo Sie die Bilder zu dieser Hauptkategorie abgespeichert haben.<br /><br /><b>general</b><br />in this section you can specify general options to use throughout all the content pages.<br /><br />
<b>Auflistung der Seiten</b><br />in diesem Bereich k&ouml;nnen Sie Optionsseiten anlegen, wo Inhaltseintr&auml;ge gelisted werden.<br /><br />
<b>Kategorie Seiten</b><br />in diesem Bereich k&ouml;nnen Sie festlegen, wie die Kategorieseiten angezeigt werden sollen.<br /><br />
<b>Inhalts Seiten</b><br />in diesem Bereich k&ouml;nnen Sie festlegen, wie die Inhaltsseiten angezeigt werden sollen.<br /><br />
<b>Men&uuml;</b><br />In diesem Bereich k&ouml;nnen Sie Optionen f&uuml;r die Men&uuml;s in dieser Hauptkategorie setzen.<br /><br />
");
define("CONTENT_ADMIN_HELP_CAT_7", "
<i>Auf dieser Seite k&ouml;nnen Sie den ausgew&auml;hlten Kategorien, die sie geklickt haben, Admins zuweisen</i><br /><br />
Weisen Sie die Admins von der linken Spalte zu, indem Sie auf deren Namen klicken. Sie sehen dann die Namen der Admins auf die rechte Seite wechseln.
");

define("CONTENT_ADMIN_HELP_ITEMCREATE_1", "
<b>Kategorie</b><br />Bitte w&auml;hlen Sie eine Kategorie aus der Auswahlbox, in der Sie einen Inhaltseintrag vornehmen wollen.<br />
");
define("CONTENT_ADMIN_HELP_ITEMCREATE_2", "
Immer zuerst eine Kategorie ausw&auml;hlen, bevor Sie andere Felder ausf&uuml;llen !<br />
dies ist n&ouml;tig, da jede Hauptkategorie (und Unterkategorie in ihr) eigene Voreinstellungen haben k&ouml;nnen.<br /><br />
<b>Erstellungsformular</b><br />Sie k&ouml;nnen nun alle Informationen f&uuml;r diesen Inhaltseintrag festlegen und &uuml;bermitteln.<br /><br />
Es sei nochmals daran erinnert, dass jede Hauptkategorie ihre eigenen Voreinstellungen haben kann, wodurch sie mehr Felder zur Verf&uum;gung haben k&ouml;nnen.
");


define("CONTENT_ADMIN_HELP_ITEM_1", "
<i>Falls Sie bis jetzt keine Hauptkategorien angelegt haben, gehen Sie bitte auf die <a href='".e_SELF."?type.0.cat.create'>Neue Kategorie erstellen</a> Seite.</i><br /><br />
<b>Kategorie</b><br />W&auml;hlen Sie eine Kategorie aus dem  Pull-Down Men&uuml; um Inhalt f&uuml;r diese Kategorie zu managen.<br /><br />
Die Hauptkategorien werden fettgedruckt angezeigt und haben das (ALL) extenstion nach ihnen angezeigt. Eines dieser ausgew&auml;hlt, wird alle Eintr&auml;ge dieser Hauptkategorie anzeigen.<br /><br />
F&uuml;r jede Hauptkategorie werden alle Unterkategorien angezeigt inclusive der &Uuml;berkategorie (sie werden alle in Plain Text angezeigt). Wenn Sie eine dieser Kategorien ausw&auml;hlen werden nur Eintr&auml;ge dieser Kategorie angezeigt.
");
define("CONTENT_ADMIN_HELP_ITEM_2", "
<b>Erste Buchstaben</b><br />Falls mehrere Inhaltseintr&auml;ge mit Anfangsbuchstaben der Inhalts&uuml;berschriften vorhanden sind, sehen Sie verschiedene Buttons um Inhaltseintr&auml;ge auszuw&auml;hlen mit demselben Anfangsbuchstaben. Wenn Sie den 'alle' Button ausw&auml;hlen, werden alle Inhaltseintr&auml;ge dieser Kategorie angezeigt.<br /><br />
<b>Ausf&uuml;hrliche Liste</b><br />Sie sehen eine Liste aller Inhaltseintr&auml;ge mit deren Id, Icon, Autor, &Uuml;berschrift [Unter-&Uuml;berschrift] und Optionen.<br /><br />
<b>Erkl&auml;rung der Icons</b><br />
".CONTENT_ICON_EDIT." : Inhaltseintrag bearbeiten.<br />
".CONTENT_ICON_DELETE." : Inhaltseintrag l&ouml;schen.<br />
");


define("CONTENT_ADMIN_HELP_ITEMEDIT_1", "
<b>Bearbeitungsformular</b><br />Sie k&ouml;nnen hier alle Informationen zu dem Inhaltseintrag bearbeiten und die &Auml;nderungen &uuml;bermitteln.<br /><br />
falls Sie die Kategorie dieses Inhaltseintrags einer anderen Hauptkategorie zuweisen wollen, m&uuml;ssten Sie eventuel den Newseintrag nochmals bearbeiten, nach der Kategorieverschiebung.<br />Da sie die Hauptkategorie gewechselt haben und somit andere Voreinstellungen gegeben sein k&ouml;nnen.
");

define("CONTENT_ADMIN_HELP_1", "Inhalts Management Hilfe Bereich");


define("CONTENT_ADMIN_HELP_ITEM_LETTERS", "Unten sehen Sie die verfuuml;gbaren Buchstaben der Inhalts&uuml;berschriften der Inhaltseint&auml;ge dieser Kategorie.<br />By clicking on one of the letters you will see a list of all items starting with the selected letter. You can also choose the ALL button to display all items in this category.");


?>
