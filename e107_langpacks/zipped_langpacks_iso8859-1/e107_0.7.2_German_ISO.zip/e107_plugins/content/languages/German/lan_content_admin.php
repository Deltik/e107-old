<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content_admin.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/29 16:38:23 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("CONTENT_PLUGIN_LAN_1", "Content Management");
define("CONTENT_PLUGIN_LAN_2", "Ein kompletter Content Management Bereich.");
define("CONTENT_PLUGIN_LAN_3", "Content Mamagement konfigurieren");
define("CONTENT_PLUGIN_LAN_4", "Dieses Plugin ist nun bereit genutzt zu werden.");
define("CONTENT_PLUGIN_LAN_5", "Inhalt");
define("CONTENT_PLUGIN_LAN_6", "Content Management Plugin Tabellenstruktur aktualisiert");

define("CONTENT_ADMIN_CAT_LAN_0", "Inhaltskategorie erstellen");
define("CONTENT_ADMIN_CAT_LAN_1", "Inhaltskategorie bearbeiten");
define("CONTENT_ADMIN_CAT_LAN_2", "Inhaltskategorie Haupt&uuml;berschrift");
define("CONTENT_ADMIN_CAT_LAN_3", "Inhaltskategorie Unter&uuml;berschrift");
define("CONTENT_ADMIN_CAT_LAN_4", "Inhaltskategorie Text");
define("CONTENT_ADMIN_CAT_LAN_5", "Inhaltskatzegorie Icon");
define("CONTENT_ADMIN_CAT_LAN_6", "Abschicken");
define("CONTENT_ADMIN_CAT_LAN_7", "Aktualisieren");
define("CONTENT_ADMIN_CAT_LAN_8", "Icons ansehen");
define("CONTENT_ADMIN_CAT_LAN_9", "Keine Inhaltskategorien bis jetzt");
define("CONTENT_ADMIN_CAT_LAN_10", "Inahaltskategorien");
define("CONTENT_ADMIN_CAT_LAN_11", "Inahltskategorie erstellt");
define("CONTENT_ADMIN_CAT_LAN_12", "Inhaltskategorie aktualisiert");
define("CONTENT_ADMIN_CAT_LAN_13", "Erforderliche(s) Feld(er) frei gelassen");
define("CONTENT_ADMIN_CAT_LAN_14", "Kommentare erlauben");
define("CONTENT_ADMIN_CAT_LAN_15", "Abstimmungen erlauben");
define("CONTENT_ADMIN_CAT_LAN_16", "Email Druckicon anzeigen");
define("CONTENT_ADMIN_CAT_LAN_17", "Sichtbarkeit");
define("CONTENT_ADMIN_CAT_LAN_18", "Autor");
define("CONTENT_ADMIN_CAT_LAN_19", "Inhaltskategorie");
define("CONTENT_ADMIN_CAT_LAN_20", "Optionen");
define("CONTENT_ADMIN_CAT_LAN_21", "Formular leeren");
define("CONTENT_ADMIN_CAT_LAN_22", "Optionen aktualisiert");
define("CONTENT_ADMIN_CAT_LAN_23", "Inhaltskategorie gel&ouml;scht");
define("CONTENT_ADMIN_CAT_LAN_24", "Id");
define("CONTENT_ADMIN_CAT_LAN_25", "Icon");
define("CONTENT_ADMIN_CAT_LAN_26", "Neue Hauptkategorie");
define("CONTENT_ADMIN_CAT_LAN_27", "Kategorie");
define("CONTENT_ADMIN_CAT_LAN_28", "Admins zu pers&ouml;nlichen Managern dieser Kategorie erkl&auml;ren");
define("CONTENT_ADMIN_CAT_LAN_29", "Admins - click to move ... ");
define("CONTENT_ADMIN_CAT_LAN_30", "Pers&ouml;nliche Admins dieser Kategorie ...");
define("CONTENT_ADMIN_CAT_LAN_31", "Aufheben");
define("CONTENT_ADMIN_CAT_LAN_32", "Klasse zur&uuml;chsetzen");
define("CONTENT_ADMIN_CAT_LAN_33", "Admins Kategorie zuweisen");
define("CONTENT_ADMIN_CAT_LAN_34", "Admins erfolgreich der Kategorie zugewiesen");
define("CONTENT_ADMIN_CAT_LAN_35", "Inhaltsunterkategorie gel&ouml;scht");
define("CONTENT_ADMIN_CAT_LAN_36", "Kategorie &Uuml;berpr&uuml;fung: es sind noch Unterkategorien angelegt, die Kategorie kann NICHT gel&oumlscht werden. Bitte l&ouml;schen Sie zuerst alle Unterkategorien und versuchen Sie es erneut.");
define("CONTENT_ADMIN_CAT_LAN_37", "Inhaltseintrag &Uuml;berpr&uuml;fung: es sind noch Inhalteintr&auml;ge angelegt, die Kategorie kann nicht gel&ouml;scht werden. Bitte l&ouml;schen Sie zuerst alle Inhaltseintr&auml;ge und versuchen Sie es erneut.");
define("CONTENT_ADMIN_CAT_LAN_38", "Inhaltseintrag &Uuml;berpr&uuml;fung: keine Eintr&auml;ge gefunden");
define("CONTENT_ADMIN_CAT_LAN_39", "Kategorie &Uuml;berpr&uuml;fung: keine Unterkategorien gefunden");
define("CONTENT_ADMIN_CAT_LAN_40", "Im Folgenden sehen Sie eine Liste aller Haupt- und Unterkategorien, falls vorhanden.<br />");

define("CONTENT_ADMIN_CAT_LAN_41", "Der pers&ouml;nliche Kategorien-Inhaltsmanager erlaubt es Ihnen, bestimmten Kategorien, Administratoren zuzuweisen. Mit diesem Feature k&ouml;nnen jene Administratoren ihren eigenen pers&ouml;nlichen Inhalt in angegebenen Inhaltskategorien anlegen und verwalten, ohne Kontrolle &uuml;ber das gesamte Inhaltsplugin haben zu m&uuml;ssen. Der Zugriff hierf&uuml;r erfolgt ausserhalb des Adminbereichs von der Inhaltsseite aus, indem auf das Icon des pers&ouml;nlichen Inhaltsmanager geklickt, was dann zur pers&ouml;nlichen Inhalssmanagerseite f&uuml;hrt.");
define("CONTENT_ADMIN_CAT_LAN_42", "um mehr Kategorien aus der vorher gew&auml;hlten Hauptkategorie zu bearbeiten, bitte");

define("CONTENT_ADMIN_CAT_LAN_43", "hier klicken");
define("CONTENT_ADMIN_CAT_LAN_44", "um eine andere Kategorie in der vorher ausgew&auml;hlten Hauptkategorie hinzuzuf&uuml;gen");
define("CONTENT_ADMIN_CAT_LAN_45", "Legen Sie fest ob Kommentare erlaubt sein sollten");
define("CONTENT_ADMIN_CAT_LAN_46", "Legen Sie fest ob Bewertungen erlaubt sein sollten");
define("CONTENT_ADMIN_CAT_LAN_47", "Legen Sie fest ob das Druck/Email Icon angezeigt werden soll");
define("CONTENT_ADMIN_CAT_LAN_48", "W&auml;hlen Sie welche Benutzer diesen Eintrag sehen k&ouml;nnen");
define("CONTENT_ADMIN_CAT_LAN_49", "W&auml;hlen Sie ein Icon f&uuml;r diese Kategorie");
define("CONTENT_ADMIN_CAT_LAN_50", "Inhalts Men&uuml; erstellt<br /><br />
Weil Sie eine Hauptkategorie erstellt haben, wurde ein Men&uuml; generiert.<br />
Die Men&uuml;datei wurde im /Men&uuml;verzeichnis erstellt.<br /><br />
Wenn Sie das Men&uuml; in Aktion sehen wollen, m&uuml;ssen Sie es nur in Ihrem <a href='".e_ADMIN."menus.php'> Men&uuml;bereich in der Admin Men&uuml; Area</a> aktivieren.
");
define("CONTENT_ADMIN_CAT_LAN_51", "Fehler, die Men&uuml;datei wurde nicht erstellt");
define("CONTENT_ADMIN_CAT_LAN_52", "Bitte zuerst immer eine Kategorie w&auml;hlen, bevor Sie andere Felder ausf&uuml;llen!");
define("CONTENT_ADMIN_CAT_LAN_53", "Hauptkategorie");
define("CONTENT_ADMIN_CAT_LAN_54", "Benutzer");
define("CONTENT_ADMIN_CAT_LAN_55", "Benutzer");
define("CONTENT_ADMIN_CAT_LAN_56", "Eintrag");
define("CONTENT_ADMIN_CAT_LAN_57", "Eintr&auml;ge");
define("CONTENT_ADMIN_CAT_LAN_58", "Kategorie Icon erfolgreich hochgeladen<br />Merke: Sie m&uuml;ssen der Kategorie noch das Icon zuweisen im Bereich bestehende Icons zu w&auml;hlen !<br />and of course after that you still need to submit the form to create/update this category");
define("CONTENT_ADMIN_CAT_LAN_59", "Kategorie Icon nicht hochgeladen");
define("CONTENT_ADMIN_CAT_LAN_60", "W&auml;hlen Sie ein bestehendes Icon");
define("CONTENT_ADMIN_CAT_LAN_61", "Oder laden Sie ein neues Icon hoch");
define("CONTENT_ADMIN_CAT_LAN_62", "Nachdem Sie ein neues Kategorie Icon hochgeladen haben, k&ouml;nnen Sie das Icon im obigen Bereich 'W&auml;hle bestehendes Icon' zuweisen<br />Falls Sie ein neues Icon hochgeladen haben, wird dieses auf 48 Pixel gebracht, und zus&auml;tzlich wird ein 16 Pixels Icon erstellt<br /><br />");
define("CONTENT_ADMIN_CAT_LAN_63", "Icon hochladen");

define("CONTENT_ADMIN_ITEM_LAN_0", "Erforderliche(s) Feld(er) frei gelassen");
define("CONTENT_ADMIN_ITEM_LAN_1", "Inhaltseintrag erstellt");
define("CONTENT_ADMIN_ITEM_LAN_2", "Inhaltseintrag aktualisiert");
define("CONTENT_ADMIN_ITEM_LAN_3", "Inhaltseintrag gel&ouml;scht");
define("CONTENT_ADMIN_ITEM_LAN_4", "Keine Inhaltseintr&auml;ge bis jetzt");
define("CONTENT_ADMIN_ITEM_LAN_5", "Bestehende Inhalteintr&auml;ge");
define("CONTENT_ADMIN_ITEM_LAN_6", "Erste Buchstaben");
define("CONTENT_ADMIN_ITEM_LAN_7", "Bitte w&auml;hlen Sie einen Buchstaben von unten.");
define("CONTENT_ADMIN_ITEM_LAN_8", "Id");
define("CONTENT_ADMIN_ITEM_LAN_9", "Icon");
define("CONTENT_ADMIN_ITEM_LAN_10", "Autor");
define("CONTENT_ADMIN_ITEM_LAN_11", "&Uuml;berschrift");
define("CONTENT_ADMIN_ITEM_LAN_12", "Optionen");
define("CONTENT_ADMIN_ITEM_LAN_13", "Hauptkategorie w&auml;hlen");
define("CONTENT_ADMIN_ITEM_LAN_14", "Autor Name");
define("CONTENT_ADMIN_ITEM_LAN_15", "Autor Email Adresse");
define("CONTENT_ADMIN_ITEM_LAN_16", "Unter-&Uuml;berschrift");
define("CONTENT_ADMIN_ITEM_LAN_17", "Zusammenfassung");
define("CONTENT_ADMIN_ITEM_LAN_18", "Text");
define("CONTENT_ADMIN_ITEM_LAN_19", "Upload Icon");
define("CONTENT_ADMIN_ITEM_LAN_20", "Inhalts Icon");
define("CONTENT_ADMIN_ITEM_LAN_21", "Diese Option ist abgeschalten, da Datei-Upload durch Ihren Server nicht freigeschalten ist");
define("CONTENT_ADMIN_ITEM_LAN_22", "Die");
define("CONTENT_ADMIN_ITEM_LAN_23", "Verzeichnis ist nicht beschreibbar, sie m&uuml;ssen das Verzeichnis erst mit 777 CHMOD Rechten versehen");
define("CONTENT_ADMIN_ITEM_LAN_24", "Anh&auml;nge hochladen");
define("CONTENT_ADMIN_ITEM_LAN_25", "Neues Icon hochladen");
define("CONTENT_ADMIN_ITEM_LAN_26", "Entfernen");
define("CONTENT_ADMIN_ITEM_LAN_27", "Jetzige Inhalts Datei");
define("CONTENT_ADMIN_ITEM_LAN_28", "Neue Datei hochladen");
define("CONTENT_ADMIN_ITEM_LAN_29", "Keine Datei bis jetzt");
define("CONTENT_ADMIN_ITEM_LAN_30", "Inhalts Datei");
define("CONTENT_ADMIN_ITEM_LAN_31", "Bilder hochladen");
define("CONTENT_ADMIN_ITEM_LAN_32", "Jetziges Inhaltsbild");
define("CONTENT_ADMIN_ITEM_LAN_33", "Neues Bild hochladen");
define("CONTENT_ADMIN_ITEM_LAN_34", "Inhalts Bild");
define("CONTENT_ADMIN_ITEM_LAN_35", "Voreinstellungen f&uuml;r diesen Inhaltseintrag setzen");
define("CONTENT_ADMIN_ITEM_LAN_36", "Kommentare erlauben");
define("CONTENT_ADMIN_ITEM_LAN_37", "Bewertung erlauben");
define("CONTENT_ADMIN_ITEM_LAN_38", "Zeige Drucke Email/Icons");
define("CONTENT_ADMIN_ITEM_LAN_39", "Sichtbarkeit");
define("CONTENT_ADMIN_ITEM_LAN_40", "Score");
define("CONTENT_ADMIN_ITEM_LAN_41", "W&auml;hle einen Score ...");
define("CONTENT_ADMIN_ITEM_LAN_42", "Markiere hier um den Timestamp auf die jetzige Zeit zu aktualisieren");
define("CONTENT_ADMIN_ITEM_LAN_43", "Benutzer&uuml;bermittelten Inhaltseintrag posten");
define("CONTENT_ADMIN_ITEM_LAN_44", "Inhaltseintrag erstellen");
define("CONTENT_ADMIN_ITEM_LAN_45", "Inhaltseintrag aktualisieren");
define("CONTENT_ADMIN_ITEM_LAN_46", "Voransicht");
define("CONTENT_ADMIN_ITEM_LAN_47", "Nochmalige Voransicht");
define("CONTENT_ADMIN_ITEM_LAN_48", "Hauptkategorie");
define("CONTENT_ADMIN_ITEM_LAN_49", "&Uuml;bermittelter Inhaltseintrag");
define("CONTENT_ADMIN_ITEM_LAN_50", "Kein &uuml;bermittelter Inhaltseintrag");
define("CONTENT_ADMIN_ITEM_LAN_51", "Autor Details<br /> leer lassen, wenn Inhalt durch Sie geschrieben wurde");
define("CONTENT_ADMIN_ITEM_LAN_52", "Inhaltseintrag &uuml;bermitteln");
define("CONTENT_ADMIN_ITEM_LAN_53", "Meta-Schl&uuml;sselw&ouml;rter f&uuml;r diesen Inhaltseintrag (Mit Kommatas trennen, kein Freizeichen erlaubt !)");
define("CONTENT_ADMIN_ITEM_LAN_54", "Zus&auml;tzliche Daten");
define("CONTENT_ADMIN_ITEM_LAN_55", "Gehe zur&uuml;ck zur <a href='".e_SELF."'>Hauptinhaltsmanager Seite</a> um mehr pers&ouml;nlichen Inhalt zu managen<br />or<br />Gehe zur <a href='".e_PLUGIN."content/content.php'>Inhaltshauptseite</a> um Inhaltseintr&auml;ge anzusehen.");
define("CONTENT_ADMIN_ITEM_LAN_56", "Pers&ouml;nlicher Inhaltsmanager");
define("CONTENT_ADMIN_ITEM_LAN_57", "Kategorie");
define("CONTENT_ADMIN_ITEM_LAN_58", "Eintr&auml;ge");
define("CONTENT_ADMIN_ITEM_LAN_59", "Verschieben");
define("CONTENT_ADMIN_ITEM_LAN_60", "Sortierung");
define("CONTENT_ADMIN_ITEM_LAN_61", "Sortierung aktualisieren");
define("CONTENT_ADMIN_ITEM_LAN_62", "Kategorien sortieren");
define("CONTENT_ADMIN_ITEM_LAN_63", "aufsteigend");
define("CONTENT_ADMIN_ITEM_LAN_64", "absteigend");
define("CONTENT_ADMIN_ITEM_LAN_65", "Sortiere Inhaltseintr&auml:ge");
define("CONTENT_ADMIN_ITEM_LAN_66", "Unten sehen Sie die verschiedenen Anfangsbuchstaben aller Inhalts&uuml;berschriften in dieser Kategorie.<br />Wenn Sie einen Buchstaben anklicken kommen Sie zu einer Auflistung aller Inhaltseintr&auml;ge die mit diesem Buchstaben beginnen. Sie k&ouml;nnen auch den ALL-Button klicken, wodurch alle Eintr&auml;ge dieser Kategorie angezeigt werden.");
define("CONTENT_ADMIN_ITEM_LAN_67", "Unten sehen Sie eine Auflistung aller Inhaltseintr&auml;ge der gew&auml;hlten Kategorie oder zusammengefasst mittels gew&auml;hlten Buchstaben.<br />Die Eintr&auml;ge lassen sich bearbeiten oder l&ouml;schen, indem Sie auf den zugeh&ouml;rigen Button, rechts, klicken.");
define("CONTENT_ADMIN_ITEM_LAN_68", "Unten haben Sie die M&ouml;glichkeit eigene Daten dem Inhaltseintrag beizuf&uuml;gen. Jede dieser Daten braucht sowohl einen Schl&uuml;ssel als auch einen Wert. Der Schl&uuml;ssel kann im linken, der Wert im rechten Feld eingegeben werden.<br />(zum Beispiel, Schl&uuml;ssel='Fotografie' und Wert='alle Fotos sind durch mich gemacht'.");
define("CONTENT_ADMIN_ITEM_LAN_69", "Hier k&ouml;nnen Sie Icons, Anh&auml;nge und/oder Bilder hochladen zu den Eintr&auml;gen. Die erlaubten Feldtypen sind : ");
define("CONTENT_ADMIN_ITEM_LAN_70", "In der n&auml;chsten Box k&ouml;nnen Sie Meta-Schl&uuml;sselw&ouml;rter zu den Eintr&auml;gen anlegen. Diese Meta-Schl&uuml;sselw&ouml;rter werden im Header gerendert. Bitte mit Komma trennen, KEINE Leerstellen erlaubt !");
define("CONTENT_ADMIN_ITEM_LAN_71", "frei lassen, falls es von Ihnen geschrieben wurde");
define("CONTENT_ADMIN_ITEM_LAN_72", "Autor Details angeben");
define("CONTENT_ADMIN_ITEM_LAN_73", "Startdatum f&uuml;r diesen Eintrag angeben (freilassen, falls nicht ben&ouml;tigt)");
define("CONTENT_ADMIN_ITEM_LAN_74", "Enddatum f&uuml;r diesen Eintrag angeben(freilassen, falls nicht ben&ouml;tigt)");
define("CONTENT_ADMIN_ITEM_LAN_75", "Icon f&uuml;r diesen Eintrag hochladen und zuweisen");
define("CONTENT_ADMIN_ITEM_LAN_76", "Anhang f&uuml;r diesen Eintrag hochladen und zuweisen");
define("CONTENT_ADMIN_ITEM_LAN_77", "Bild f&uuml;r diesen Eintrag hochladen und zuweisen");
define("CONTENT_ADMIN_ITEM_LAN_78", "sollen Kommentare erlaubt sein?");
define("CONTENT_ADMIN_ITEM_LAN_79", "soll Bewertung erlaubt sein?");
define("CONTENT_ADMIN_ITEM_LAN_80", "soll das Druck/Email Icon angezeigt werden?");
define("CONTENT_ADMIN_ITEM_LAN_81", "w&auml;hlen Sie welche Benutzer diesen Eintrag sehen k&ouml;nnen");
define("CONTENT_ADMIN_ITEM_LAN_82", "Score definieren");
define("CONTENT_ADMIN_ITEM_LAN_83", "Meta Schl&uuml;sselw&ouml;rter definieren");
define("CONTENT_ADMIN_ITEM_LAN_84", "Eigene Datenfelder definieren (Schl&uuml;ssel + Wert)");
define("CONTENT_ADMIN_ITEM_LAN_85", "freigeschalten");
define("CONTENT_ADMIN_ITEM_LAN_86", "nicht freigeschalten");
define("CONTENT_ADMIN_ITEM_LAN_87", "W&auml;hlen Sie ein Ikon f&uuml;r diesen Eintrag");
define("CONTENT_ADMIN_ITEM_LAN_88", "um einen Eintrag in der vorher gew&auml;hlten Hauptkategorie zu erstellen");
define("CONTENT_ADMIN_ITEM_LAN_89", "um einen Eintrag in der vorher gew&auml;hlten Hauptkategorie zu bearbeiten");
define("CONTENT_ADMIN_ITEM_LAN_90", "bitte hier klicken");
define("CONTENT_ADMIN_ITEM_LAN_91", "um denselben Eintrag nochmals zu bearbeiten");
define("CONTENT_ADMIN_ITEM_LAN_92", "Template");
define("CONTENT_ADMIN_ITEM_LAN_93", "W&auml;hle ein Layout Template");
define("CONTENT_ADMIN_ITEM_LAN_94", "Layout Template ausw&auml;hlen");
define("CONTENT_ADMIN_ITEM_LAN_95", "Neues Icon hochladen");
define("CONTENT_ADMIN_ITEM_LAN_96", "W&auml;hlen Sie ein bestehendes Icon");
define("CONTENT_ADMIN_ITEM_LAN_97", "Nachdem Sie ein neues Icon hochgeladen haben, k&ouml;nnen Sie es dem unteren 'W&auml;hle ein bestehendes Icon' Bereich zuweisen");

define("CONTENT_ADMIN_ITEM_LAN_98", "Einen neuen Anhang hochladen");
define("CONTENT_ADMIN_ITEM_LAN_99", "W&auml;hlen Sie einen bestehenden Anhang");
define("CONTENT_ADMIN_ITEM_LAN_100", "Nachdem Sie einen neuen Anhang hochgeladen haben, k&ouml;nnen Sie es dem unteren 'W&auml;hle einen bestehnden Anhang' Bereich zuweisen");

define("CONTENT_ADMIN_ITEM_LAN_101", "Ein neues Bild hochladen");
define("CONTENT_ADMIN_ITEM_LAN_102", "W&auml;hlen Sie ein bestehendes Bild");
define("CONTENT_ADMIN_ITEM_LAN_103", "Nachdem Sie ein neues Bild hochgeladen haben, k&ouml;nnen Sie es dem unteren 'W&auml;hle ein bestehdes Bild' Bereich zuweisen");

define("CONTENT_ADMIN_ITEM_LAN_104", "Hochladen");
define("CONTENT_ADMIN_ITEM_LAN_105", "Ansehen");

define("CONTENT_ADMIN_ITEM_LAN_106", "Icon wurde erfolgreich hochgeladen<br />Merke: Sie m&uuml;ssen dieses Icon dem Inhaltseintrag im 'W&auml;hle ein bestehendes Icon' Bereich zuweisen !<br />und nat&uuml;rlich m&uuml;ssen Sie danach das Formular abschicken um den Inhaltseintrag  zu erstellen/aktualisieren");
define("CONTENT_ADMIN_ITEM_LAN_107", "Icon wurde nicht hochgeladen");

define("CONTENT_ADMIN_ITEM_LAN_108", "Anhang erfolgreich hochgladen<br />Merke: Sie m&uuml;ssen diesen Anhang dem Inhaltseintrag im 'W&auml;hle einen bestehenden Anhang' Bereich zuweisen !<br />und nat&uuml;rlich m&uuml;ssen Sie danach das Formular abschicken um den Inhaltseintrag  zu erstellen/aktualisieren");
define("CONTENT_ADMIN_ITEM_LAN_109", "Anhang wurde nicht hochgeladen");

define("CONTENT_ADMIN_ITEM_LAN_110", "Bild erfolgreich hochgeladen<br />Merke: Sie m&uuml;ssen dieses Bild dem Inhaltseintrag im 'W&auml;hle ein bestehendes Bild' Bereich zuweisen !<br />und nat&uuml;rlich m&uuml;ssen Sie danach das Formular abschicken um den Inhaltseintrag  zu erstellen/aktualisieren");
define("CONTENT_ADMIN_ITEM_LAN_111", "Bild wurde nicht hochgeladen");

define("CONTENT_ADMIN_ITEM_LAN_112", "Laden Sie ein Icon, einen Anhang oder ein Bild hoch");
define("CONTENT_ADMIN_ITEM_LAN_113", "W&auml;hlen Sie den Upload-Typ in der Auswahlbox, bevor Sie die Datei hochladen");
define("CONTENT_ADMIN_ITEM_LAN_114", "Icon");
define("CONTENT_ADMIN_ITEM_LAN_115", "Anhang");
define("CONTENT_ADMIN_ITEM_LAN_116", "Bild");
define("CONTENT_ADMIN_ITEM_LAN_117", "&Uuml;bermittelter Inhaltseintrag wurde gepostet");
define("CONTENT_ADMIN_ITEM_LAN_118", "Nein");
define("CONTENT_ADMIN_ITEM_LAN_119", "Zugewiesen");
define("CONTENT_ADMIN_ITEM_LAN_120", "Gesetztes Layout");
define("CONTENT_ADMIN_ITEM_LAN_121", "Kein neues Icon bis jetzt hochgeladen");
define("CONTENT_ADMIN_ITEM_LAN_122", "Kein neuer Anhang bis jetzt hochgeladen");
define("CONTENT_ADMIN_ITEM_LAN_123", "kein neues Bild bis jetzt hochgeladen");
define("CONTENT_ADMIN_ITEM_LAN_124", "den Eintrag ansehen");

define("CONTENT_ADMIN_ORDER_LAN_0", "Sortierung ist aufsteigend");
define("CONTENT_ADMIN_ORDER_LAN_1", "Sortierung ist absteigend");
define("CONTENT_ADMIN_ORDER_LAN_2", "Neue Sortierung f&uuml;r Inhaltseintr&auml;ge abgespeichert");

define("CONTENT_ADMIN_MAIN_LAN_0", "Bestehende Inhaltskategorien");
define("CONTENT_ADMIN_MAIN_LAN_1", "Keine Inhaltskategorien bis jetzt");
define("CONTENT_ADMIN_MAIN_LAN_2", "Hauptinhalts Kategorien");
define("CONTENT_ADMIN_MAIN_LAN_3", "Inhaltseintrag gel&ouml;scht");
define("CONTENT_ADMIN_MAIN_LAN_4", "Hauptkategorie Text");
define("CONTENT_ADMIN_MAIN_LAN_5", "Hauptkategorie Icon");
define("CONTENT_ADMIN_MAIN_LAN_6", "");


define("CONTENT_ADMIN_MAIN_LAN_7", "Willkommen zu Ihrem Content Management System !");
define("CONTENT_ADMIN_MAIN_LAN_8", "Diese Information wird angezeigt, da die Tabelle des Content Manager Plugins keine Inhalte aufweist.");
define("CONTENT_ADMIN_MAIN_LAN_9", "Bitte lesen Sie die folgenden Informationen aufmerksam und w&auml;hlen Sie dann was Sie tun m&ouml;chten");
define("CONTENT_ADMIN_MAIN_LAN_10", "Sie k&ouml;nnen Inhaltseintr&auml;ge auf dieser Seite managen. Entscheiden Sie sich zuerst f&uuml;r die Kategorie in der Sie Inhalt managen wollen. Klicken Sie hierbei auf die Buttons der aufgelisteten Hauptkategorien um mit dem Managen der Inhalte f&uuml;r diese Kategorie zu beginnen.");
define("CONTENT_ADMIN_MAIN_LAN_11", "Falls die alten Contenttabellen Eitr&auml;ge enthalten, k&ouml;nnen Sie eine der zwei folgenden Optionen w&auml;hlen:");
define("CONTENT_ADMIN_MAIN_LAN_12", "");
define("CONTENT_ADMIN_MAIN_LAN_13", "Sie k&ouml;nnen neue Inhaltseintr&auml;ge auf dieser Seite erstellen. Enscheiden Sie sich zuerst f&uuml;r die Kategorie in der Sie Inhalt managen wollen. Klicken Sie auf die Buttons der Hauptkategorien um neuen Inhalt in der Hauptkategorie zu erstellen.");
define("CONTENT_ADMIN_MAIN_LAN_14", "Sie k&ouml;nnen die Anordnung der Inhaltseintr&auml;ge auf dieser Seite setzen. Klicken Sie auf die Buttons der Hauptkategorien um die Inhaltseintr&auml;ge oder Kategorien f&uuml;r die gew&auml;hlte Hauptkategorie zu sortieren.");
define("CONTENT_ADMIN_MAIN_LAN_15", "Sie k&ouml;nnen auf dieser Seite Ihre Kategorien managen. W&auml;hlen Sie die Hauptkategorie mittels Buttons um sich alle Kategorien, Unterkategorien, dieser Hauptkategorie anzeigen zu lassen.");
define("CONTENT_ADMIN_MAIN_LAN_16", "Sie k&ouml;nnen neue Kategorien auf dieser Seite erstellen. Das Erstellungsformular f&uuml;r neue Hauptkategorien wird angezeigt. Falls Sie eine Unterkategorie f&uuml;r eine bestehende Hauptkategorie erstellen wollen, klicken Sie auf einen der unten aufgelisteten Buttons um sich das Erstellungsformular f&uuml;r Unterkategorien, innerhalb dieser Hauptkategorie, anzeigen zu lassen.");
define("CONTENT_ADMIN_MAIN_LAN_17", "bitte erstellen Sie eine neue Kategorie auf der <a href='".e_SELF."?type.0.cat.create'>Neue Kategorie erstellen</a> Seite");
define("CONTENT_ADMIN_MAIN_LAN_18", "Rekords konvertieren");
define("CONTENT_ADMIN_MAIN_LAN_19", "
Zuerst sollten Sie ein Backup Ihrer bestehenden Inhalt,- Kommentar, - und Abstimmungstabellen anlegen.<br />
Benutzen Sie hierf&uuml;r am besten ein Programm wie, phpmyadmin.<br />
Nchdem Sie die Backups gemacht haben, k&ouml;nnen sie beginnen, die alten Eintr&auml;ge ins neue Content Mnangement Plugin zu konvertieren.<br />
Nachdem Sie den alten Inhalt konvertiert haben, werden Sie diese Aufforderung nicht mehr sehen, und Sie k&ouml;nnen Ihren bestehenden Inhalt managen.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_20", "Beginnen Sie mit einer leeren Inhaltstabelle");
define("CONTENT_ADMIN_MAIN_LAN_21", "
Falls Sie die Eintr&auml;ge Ihrer alten Inhaltstabellen nicht mehr ben&ouml;tigen,<br />
und mit einer leeren Content Management Tabelle beginnen m&ouml;chten,<br />
und kein gesetztes Kategorienset erstellen m&ouml;chten<br />
fangen Sie am besten mit der Erstellung einer neuen Kategorie an.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_22", "Gesetztes Kategorienset erstellen");
define("CONTENT_ADMIN_MAIN_LAN_23", "
Falls Sie mit einer NEU-Installierung beginnen m&ouml;chten, k&ouml;nnen Sie zuerst ein gesetztes Kategorienset erstellen.<br />
Mit der Erstellung dieses Sets, werden drei Hauptkategorien angelegt, --- Inhalt, Bericht und Artikel.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_24", "Dies ist eine Neuinstallation /Die alten Inhaltstabellen weisen keine Eintr&auml;ge auf");
define("CONTENT_ADMIN_MAIN_LAN_25", "
Da die alten Inhaltstabellen keine Eintr&auml;ge aufweisen, k&ouml;nnen Sie nun beginnen neuen Inhalt zu managen<br />
Wenn Sie den n&auml;chsten Button klicken, wird automatisch ein gesetztes Kategorienset erstellt, --- Inhalt, Bericht und Artikel.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_26", "Voransicht");
define("CONTENT_ADMIN_MAIN_LAN_27", "nochmalige Voransicht");
define("CONTENT_ADMIN_MAIN_LAN_28", "W&auml;hle Kategorie ...");
define("CONTENT_ADMIN_MAIN_LAN_29", "NEUE HAUPTKATEGORIE");

define("CONTENT_ADMIN_MENU_LAN_0", "Bestehenden Inhalt managen");
define("CONTENT_ADMIN_MENU_LAN_1", "neuen Inhalt erstellen");
define("CONTENT_ADMIN_MENU_LAN_2", "bestehende Kategorien managen");
define("CONTENT_ADMIN_MENU_LAN_3", "Neue Kategorie erstellen");
define("CONTENT_ADMIN_MENU_LAN_4", "Inhalteintrag erstellen");
define("CONTENT_ADMIN_MENU_LAN_5", "Kategorie");
define("CONTENT_ADMIN_MENU_LAN_6", "Optionen");
define("CONTENT_ADMIN_MENU_LAN_7", "Erstellen");
define("CONTENT_ADMIN_MENU_LAN_8", "&Uuml;bermitteln");
define("CONTENT_ADMIN_MENU_LAN_9", "Pfad und Theme");
define("CONTENT_ADMIN_MENU_LAN_10", "Generell");
define("CONTENT_ADMIN_MENU_LAN_11", "Seiten auflisten");
define("CONTENT_ADMIN_MENU_LAN_12", "Kategorie Seiten");
define("CONTENT_ADMIN_MENU_LAN_13", "Inhalts Seiten");
define("CONTENT_ADMIN_MENU_LAN_14", "Men&uuml");
define("CONTENT_ADMIN_MENU_LAN_15", "Reihenfolge festlegen");
define("CONTENT_ADMIN_MENU_LAN_16", "Archiv-Seite");
define("CONTENT_ADMIN_MENU_LAN_17", "ContentManager");
define("CONTENT_ADMIN_MENU_LAN_18", "Autor Seite");
define("CONTENT_ADMIN_MENU_LAN_19", "Content Manager");
define("CONTENT_ADMIN_MENU_LAN_20", "Best bewertete Seiten");
define("CONTENT_ADMIN_MENU_LAN_21", "Seiten");
define("CONTENT_ADMIN_MENU_LAN_22", "Top Score Page");

define("CONTENT_ADMIN_JS_LAN_0", "Sind Sie sicher diese Kategorie l&ouml;schen zu wollen?");
define("CONTENT_ADMIN_JS_LAN_1", "Sind Sie sicher diesen Inhalt l&ouml;schen zu wollen?");
define("CONTENT_ADMIN_JS_LAN_2", "Sind Sie sicher das jetztige Bild l&ouml;schen zu wollen ?");
define("CONTENT_ADMIN_JS_LAN_3", "Sind Sie sicher die jetzige datei l&ouml;schen zu wollen ?");
define("CONTENT_ADMIN_JS_LAN_4", "Bild");
define("CONTENT_ADMIN_JS_LAN_5", "Datei");
define("CONTENT_ADMIN_JS_LAN_6", "ID");
define("CONTENT_ADMIN_JS_LAN_7", "Sind Sie sicher das jetzige Icon l&ouml;schen zu wollen ?");
define("CONTENT_ADMIN_JS_LAN_8", "Icon");
define("CONTENT_ADMIN_JS_LAN_9", "WARNUNG :\\nwenn Sie diese Kategorie l&ouml;schen, werden alle Unterkategorien (falls Hauptkategorie f&uuml;r diese Kategorie),\\nauch gel&ouml;scht!");
define("CONTENT_ADMIN_JS_LAN_10", "Sind Sie sicher diesen &uuml;bermittelten Inhalt l&ouml;schen zu wollen bevor er eingetragen wurde?");


define("CONTENT_ADMIN_SUBMIT_LAN_0", "Keine Inhaltkategorie erlaubt zur Zeit Benutzereintr&auml;ge");
define("CONTENT_ADMIN_SUBMIT_LAN_1", "Inhaltstypen f&Uuml;r &Uuml;bermittlung");
define("CONTENT_ADMIN_SUBMIT_LAN_2", "Danke, Ihr Inhalteintrag wurde &uuml;bermittelt.");
define("CONTENT_ADMIN_SUBMIT_LAN_3", "Danke, Ihr Inhalteintrag wurde &uuml;bermittelt und wird durch einen Seitenadministrator in Augenschein genommen.");
define("CONTENT_ADMIN_SUBMIT_LAN_4", "Zwingende(s) Feld(er) wurden freigelassen");
define("CONTENT_ADMIN_SUBMIT_LAN_5", "Bitte gehen Sie zur&uuml;ck zur <a href='".e_SELF."'>Haupteingabemaske.</a> Um mehr Inhalt zu &uuml;bermitteln<br />or<br />gehen Sie zur <a href='".e_PLUGIN."content/content.php'>Inhalts Hauptseite</a> um sich Inhaltseintr&auml;ge anzusehen.");
define("CONTENT_ADMIN_SUBMIT_LAN_6", "");
define("CONTENT_ADMIN_SUBMIT_LAN_7", "");
define("CONTENT_ADMIN_SUBMIT_LAN_8", "&Uuml;bermittelter Inhaltseintrag gel&ouml;scht");
define("CONTENT_ADMIN_SUBMIT_LAN_9", "");

define("CONTENT_ADMIN_SUBMIT_LAN_10", "");
define("CONTENT_ADMIN_SUBMIT_LAN_11", "");
define("CONTENT_ADMIN_SUBMIT_LAN_12", "");
define("CONTENT_ADMIN_SUBMIT_LAN_13", "");
define("CONTENT_ADMIN_SUBMIT_LAN_14", "");
define("CONTENT_ADMIN_SUBMIT_LAN_15", "");
define("CONTENT_ADMIN_SUBMIT_LAN_16", "");
define("CONTENT_ADMIN_SUBMIT_LAN_17", "");
define("CONTENT_ADMIN_SUBMIT_LAN_18", "");
define("CONTENT_ADMIN_SUBMIT_LAN_19", "");


define("CONTENT_ADMIN_CONVERSION_LAN_0", "Inhalt");
define("CONTENT_ADMIN_CONVERSION_LAN_1", "Bericht");
define("CONTENT_ADMIN_CONVERSION_LAN_2", "Artikel");
define("CONTENT_ADMIN_CONVERSION_LAN_3", "Kategorie");
define("CONTENT_ADMIN_CONVERSION_LAN_4", "Kategorien");
define("CONTENT_ADMIN_CONVERSION_LAN_5", "Seite");
define("CONTENT_ADMIN_CONVERSION_LAN_6", "Seiten");
define("CONTENT_ADMIN_CONVERSION_LAN_7", "Hauptkategorie eingef&uuml;gt");
define("CONTENT_ADMIN_CONVERSION_LAN_8", "Hauptkategorie Voreinstellungen eingef&uuml;gt");
define("CONTENT_ADMIN_CONVERSION_LAN_9", "nein");
define("CONTENT_ADMIN_CONVERSION_LAN_10", "Hauptkategorie n&ouml;tig");
define("CONTENT_ADMIN_CONVERSION_LAN_11", "Konvertierungs-Analyse");
define("CONTENT_ADMIN_CONVERSION_LAN_12", "Zeilen insgesamt zu konvertieren");
define("CONTENT_ADMIN_CONVERSION_LAN_13", "Insgesamt konvertierte Zeilen");
define("CONTENT_ADMIN_CONVERSION_LAN_14", "Warnungen insgesamt");
define("CONTENT_ADMIN_CONVERSION_LAN_15", "Fehler insgesamt");
define("CONTENT_ADMIN_CONVERSION_LAN_16", "ALTE INHALTSTABELLE : ANALYSE");
define("CONTENT_ADMIN_CONVERSION_LAN_17", "Zeilen insgesamt");
define("CONTENT_ADMIN_CONVERSION_LAN_18", "Unbekannte Zeilen");
define("CONTENT_ADMIN_CONVERSION_LAN_19", "Alle Zeilen sind familiar");
define("CONTENT_ADMIN_CONVERSION_LAN_20", "INHALTS HAUPTKATEGORIE");
define("CONTENT_ADMIN_CONVERSION_LAN_21", "BERICHTE HAUPTKATEGORIE");
define("CONTENT_ADMIN_CONVERSION_LAN_22", "ARTIKEL HAUPTKATEGORIE");
define("CONTENT_ADMIN_CONVERSION_LAN_23", "Einf&uuml;gen fehlgeschlagen");
define("CONTENT_ADMIN_CONVERSION_LAN_24", "KEINE BESTEHENDEN INHALTSSEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_25", "BESTEHENDE INHALTSSEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_26", "Eingef&uuml;gt");
define("CONTENT_ADMIN_CONVERSION_LAN_27", "Konvertierungs-Analyse");
define("CONTENT_ADMIN_CONVERSION_LAN_28", "Alte Zeilen Insgesamt");
define("CONTENT_ADMIN_CONVERSION_LAN_29", "Neue Zeilen insgesamt");
define("CONTENT_ADMIN_CONVERSION_LAN_30", "Fehlgeschlagen");
define("CONTENT_ADMIN_CONVERSION_LAN_31", "Warnung");
define("CONTENT_ADMIN_CONVERSION_LAN_32", "Alte Kategorie existiert nicht: Eintr&auml;ge werden der n&auml;chsth&ouml;heren Kategorie hinzugef&uuml;gt");
define("CONTENT_ADMIN_CONVERSION_LAN_33", "Neue Kategorie existiert nicht: Eintrag wird eine Kategorie h&ouml;her hinzugef&uuml;gt");
define("CONTENT_ADMIN_CONVERSION_LAN_34", "KEINE BESTEHENDEN BERICHTE KATEGORIE SEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_35", "BESTEHENDE BERICHTE KATEGORIE SEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_36", "KEINE BERICHTE SEITEN UND/ODER &Uuml;BERMITTELTE BERICHTE SEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_37", "BERICHTE SEITEN UND/ODER &Uuml;BERMITTELTE BERICHTE SEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_38", "KEINE BESTEHENDEn ARTIKEL KATEGORIESEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_39", "BESTEHENDE ARTIKEL KATEGORIESEITEN");

define("CONTENT_ADMIN_CONVERSION_LAN_40", "KEINE ARTIKEL SEITEN UND/ODER BESTEHENDE &Uuml;BERMITTELTE ARTIKEL SEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_41", "ARTIKEL SEITEN UND/ODER BESTEHENDE &Uuml;BERMITTELTE ARTIKEL SEITEN");
define("CONTENT_ADMIN_CONVERSION_LAN_42", "Konvertierungsergebnis der alten Inhaltstabelle zur neuen Inhalts-Plugin-Tabelle");
define("CONTENT_ADMIN_CONVERSION_LAN_43", "press the button to convert the old content table");
define("CONTENT_ADMIN_CONVERSION_LAN_44", "Die neue Inhaltstabelle beinhaltet schon Daten !<br />Sind Sie sicher die alte Inhaltstabelle in die neue Inhaltstabelle konvertieren zu wollen ?<br /><br />Falls Sie immer noch die alte Tabelle konvertieren wollen, werden die alten Inhaltdaten zu den neuen Inhaltsdaten zugef&uuml;gt.Es kann aber nicht garantiert werden, dass alle Eintr&auml;ge zu den bereits existierenden, neuen Kategorien in korrekter Weise hinzugef&uuml;gt werden!");

define("CONTENT_ADMIN_CONVERSION_LAN_45", "Einf&uuml;gen fehlgeschlagen: Hauptkategorie wurde nicht eingef&uuml,gt");
define("CONTENT_ADMIN_CONVERSION_LAN_46", "Beginnen Sie Ihren Inhalt zu managen, indem Sie auf die <a href='".e_PLUGIN."content/admin_content_config.php'>Content Manager Plugin Erste Seite</a> gehen!");
define("CONTENT_ADMIN_CONVERSION_LAN_47", "Konvertierung abgeschlossen");
define("CONTENT_ADMIN_CONVERSION_LAN_48", "F&uuml;r Details bitte hier klicken");
define("CONTENT_ADMIN_CONVERSION_LAN_49", "Seitenkonvertierungen");
define("CONTENT_ADMIN_CONVERSION_LAN_50", "Hauptkategoriekonvertierungen");
define("CONTENT_ADMIN_CONVERSION_LAN_51", "unbekannte Spalten");
define("CONTENT_ADMIN_CONVERSION_LAN_52", "Gesetztes Set an Hauptkategorien erstellt");
define("CONTENT_ADMIN_CONVERSION_LAN_53", "Eine Hauptkategorie mit diesem Nmen besteht bereits");
define("CONTENT_ADMIN_CONVERSION_LAN_54", "Ein gesetztes Set an Hauptkategorien erstellen (Inhalt, Bericht und Artikel)");
define("CONTENT_ADMIN_CONVERSION_LAN_55", "Content Management Plugin : Konvertierungsoptionen");
define("CONTENT_ADMIN_CONVERSION_LAN_56", "Bitte den Button klicken um zur Inhaltskategorieerstellungsseite zu gelangen.");
define("CONTENT_ADMIN_CONVERSION_LAN_57", "Hauptkategorie w&auml;hlen");
define("CONTENT_ADMIN_CONVERSION_LAN_58", "Aktualisierung erfolgreich<br /><br /><b>Merke:<br />Sie m&uuml;ssen die Optionen f&uuml;r jede Hauptkategorie neu konfigurieren<br />und Sie m&uuml;ssen die Men&uuml;'s l&ouml;schen die sie in Ihrem Inhalts/Men&uuml;verzeichnis erstellt haben. Danach m&uuml;ssen Sie sie neu erstellen indem Sie die Optionen f&uuml;r jede spezielle Hauptkategorie aktualisieren, die ein Men&uuml; haben soll.</b>");
define("CONTENT_ADMIN_CONVERSION_LAN_59", "TAabellen konvertieren");
define("CONTENT_ADMIN_CONVERSION_LAN_60", "Gesetzte erstellen");
define("CONTENT_ADMIN_CONVERSION_LAN_61", "Neue Kategorie erstellen");
define("CONTENT_ADMIN_CONVERSION_LAN_62", "Content Management Plugin Version aktualisiert zu Version:");
define("CONTENT_ADMIN_CONVERSION_LAN_63", "aktualisieren");
define("CONTENT_ADMIN_CONVERSION_LAN_64", "");
define("CONTENT_ADMIN_CONVERSION_LAN_65", "");

define("CONTENT_ADMIN_OPT_LAN_MENU_1", "Optionen:");
define("CONTENT_ADMIN_OPT_LAN_MENU_2", "Seiten:");
define("CONTENT_ADMIN_OPT_LAN_MENU_3", "Admin : Eintrag erstellen");
define("CONTENT_ADMIN_OPT_LAN_MENU_4", "Eintrag &uuml;bermitteln");
define("CONTENT_ADMIN_OPT_LAN_MENU_5", "Pfade und Theme Voreinstellungen");
define("CONTENT_ADMIN_OPT_LAN_MENU_6", "Generel");
define("CONTENT_ADMIN_OPT_LAN_MENU_7", "Inhaltsmanager");
define("CONTENT_ADMIN_OPT_LAN_MENU_8", "Men&uuml; Einstellungen");
define("CONTENT_ADMIN_OPT_LAN_MENU_9", "Inhaltseintrag Voransicht");
define("CONTENT_ADMIN_OPT_LAN_MENU_10", "Kategorie Seiten");
define("CONTENT_ADMIN_OPT_LAN_MENU_11", "Inhalts Seiten");
define("CONTENT_ADMIN_OPT_LAN_MENU_12", "Autor Seite");
define("CONTENT_ADMIN_OPT_LAN_MENU_13", "Archiv Seite");
define("CONTENT_ADMIN_OPT_LAN_MENU_14", "Best Bewertet Seite");
define("CONTENT_ADMIN_OPT_LAN_MENU_15", "Top Score Seite");
define("CONTENT_ADMIN_OPT_LAN_MENU_16", "Alle Kategorie Seiten (Alle Kategorien der Hauptkategorien)");
define("CONTENT_ADMIN_OPT_LAN_MENU_17", "Kategorie Seite ansehen (Hauptkategorien, Unterkategorien und Inhaltseintr&auml;ge in dieser Kategorie");
define("CONTENT_ADMIN_OPT_LAN_MENU_18", "Kategorien");
define("CONTENT_ADMIN_OPT_LAN_MENU_19", "Liste der letzten Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_MENU_20", "Links zu Seiten");

define("CONTENT_ADMIN_OPT_LAN_SECTION_0", "Bereiche");
define("CONTENT_ADMIN_OPT_LAN_SECTION_1", "W&auml;hlen Sie was angezeigt werden soll");
define("CONTENT_ADMIN_OPT_LAN_SECTION_2", "Anh&auml;nge");
define("CONTENT_ADMIN_OPT_LAN_SECTION_3", "Bilder");
define("CONTENT_ADMIN_OPT_LAN_SECTION_4", "Kommentar");
define("CONTENT_ADMIN_OPT_LAN_SECTION_5", "Bewertung");
define("CONTENT_ADMIN_OPT_LAN_SECTION_6", "Score");
define("CONTENT_ADMIN_OPT_LAN_SECTION_7", "Sichtbarkeit");
define("CONTENT_ADMIN_OPT_LAN_SECTION_8", "Metadefinitionen");
define("CONTENT_ADMIN_OPT_LAN_SECTION_9", "Layout Schematas");
define("CONTENT_ADMIN_OPT_LAN_SECTION_10", "Eigene Daten-tags");
define("CONTENT_ADMIN_OPT_LAN_SECTION_11", "Vorgefertigte Daten-tags");
define("CONTENT_ADMIN_OPT_LAN_SECTION_12", "Unter&uuml;berschrift");
define("CONTENT_ADMIN_OPT_LAN_SECTION_13", "Zusammenfassung");
define("CONTENT_ADMIN_OPT_LAN_SECTION_14", "Text (legen Sie die Anzahl der Worte fest)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_15", "Datum");
define("CONTENT_ADMIN_OPT_LAN_SECTION_16", "Autor : Name");
define("CONTENT_ADMIN_OPT_LAN_SECTION_17", "Autor : Email");
define("CONTENT_ADMIN_OPT_LAN_SECTION_18", "Autor : Link zum Autorprofil");
define("CONTENT_ADMIN_OPT_LAN_SECTION_19", "Autor : Link zur Autorenliste");
define("CONTENT_ADMIN_OPT_LAN_SECTION_20", "Email/Druck/pdf Icon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_21", "Haupt breadcrumb");
define("CONTENT_ADMIN_OPT_LAN_SECTION_22", "Refer (nur wenn logging freigeschalten ist)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_23", "Anzahl der Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_SECTION_24", "Letzer Eintrag jedes Autors");
define("CONTENT_ADMIN_OPT_LAN_SECTION_25", "Anzahl an Eintr&auml;gen jdes Autors");
define("CONTENT_ADMIN_OPT_LAN_SECTION_26", "Icon bearbeiten f&uuml;r Schnellbearbeitung");
define("CONTENT_ADMIN_OPT_LAN_SECTION_27", "Icon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_28", "des Kategorie Icons");
define("CONTENT_ADMIN_OPT_LAN_SECTION_29", "der Liste von Unterkategorien");
define("CONTENT_ADMIN_OPT_LAN_SECTION_30", "freigeschalten");
define("CONTENT_ADMIN_OPT_LAN_SECTION_31", "nicht freigeschalten");

define("CONTENT_PRESET_LAN_0", "Fehler : Feldname wurde nicht ausgef&uuml;llt");
define("CONTENT_PRESET_LAN_1", "Fehler : Nicht alle Felder wurden richtig ausgef&uuml;llt");
define("CONTENT_PRESET_LAN_2", "Alle Felder m&uuml;ssen ausgef&uuml;llt werden");
define("CONTENT_PRESET_LAN_3", "Sowohl Gr&ouml;&szlig;e als auch maximale Gr&ouml;&szlig;e m&uuml;ssen einen Zahlenwert haben");
define("CONTENT_PRESET_LAN_4", "Sowohl Spalten als auch Zeilen m&uuml;ssen einen Zahlenwert haben");
define("CONTENT_PRESET_LAN_5", "Sie m&uuml;ssen Optionen angeben");
define("CONTENT_PRESET_LAN_6", "Sowohl Jahr von als auch Jahr nach m&uuml;ssen einen Zahlenwert haben");
define("CONTENT_PRESET_LAN_7", "Feldgenerator f&uuml;r gesetzten Inhalt");
define("CONTENT_PRESET_LAN_8", "Formular um einen neuen gesetzten Daten-tag Typ zu erstellen");
define("CONTENT_PRESET_LAN_9", "Feldname");
define("CONTENT_PRESET_LAN_10", "Gr&ouml;&szlig;e");
define("CONTENT_PRESET_LAN_11", "Maximale L&auml;nge");
define("CONTENT_PRESET_LAN_12", "Spalten");
define("CONTENT_PRESET_LAN_13", "Zeilen");
define("CONTENT_PRESET_LAN_14", "Jahre von");
define("CONTENT_PRESET_LAN_15", "Jahre nach");
define("CONTENT_PRESET_LAN_16", "Optionen");
define("CONTENT_PRESET_LAN_17", "Mehr hinzuf&uuml;gen");
define("CONTENT_PRESET_LAN_18", "Vorgefertigtes hinzuf&uuml;gen");
define("CONTENT_PRESET_LAN_19", "Anzahl der Text und Wertfelder muss gleich sein");
define("CONTENT_PRESET_LAN_20", "Sie m&uuml;ssen einen Wert f&uuml;r die Checkbos angeben");
define("CONTENT_PRESET_LAN_21", "Text");
define("CONTENT_PRESET_LAN_22", "Wert");
define("CONTENT_PRESET_LAN_23", "W&auml;hlen Sie einen Text");
define("CONTENT_PRESET_LAN_24", "Die erste Option mit keinem Wert");
define("CONTENT_PRESET_LAN_25", "Feld hinzuf&uuml;gen ...");
define("CONTENT_PRESET_LAN_26", "Text");
define("CONTENT_PRESET_LAN_27", "Textbereich");
define("CONTENT_PRESET_LAN_28", "Ausw&auml;hlen");
define("CONTENT_PRESET_LAN_29", "Datum");
define("CONTENT_PRESET_LAN_30", "checkbox");
define("CONTENT_PRESET_LAN_31", "Radio");
define("CONTENT_PRESET_LAN_32", "Beispiel:");

define("CONTENT_ADMIN_OPT_LAN_0", "Optionen");
define("CONTENT_ADMIN_OPT_LAN_1", "Gesetzte Voreinstellungen");
define("CONTENT_ADMIN_OPT_LAN_2", "Optionen aktualisieren");
define("CONTENT_ADMIN_OPT_LAN_3", "Anzahl an Bilder die hochgeladen werden k&ouml;nnen");
define("CONTENT_ADMIN_OPT_LAN_4", "Anzahl an Anh&auml;ngen die hochgeladen werden k&ouml;nnen");
define("CONTENT_ADMIN_OPT_LAN_5", "Anzahl an verf&uuml;gbaren eigenen Daten-tags");
define("CONTENT_ADMIN_OPT_LAN_6", "Eigene Daten-tags");
define("CONTENT_ADMIN_OPT_LAN_7", "Gesetzte eigene Daten-tags definieren");
define("CONTENT_ADMIN_OPT_LAN_8", "
Hier k&ouml;nnen Sie vorgefertigte, zus&auml;tzliche Daten-tags erstellen. Die Felder die Sie hier erstellen sind die Schl&uuml;ssel des Schl&uuml;ssels=>Wert Daten-tag. Sie werden im Admin Erstellungsformular eine Eingabemaske f&uuml;r den Wert haben. Aus dem Pulldownmen&uuml; k&ouml;nnen Sie dann den Type des Elements f&uuml;r die vorgefertigten Daten-tags w&auml;hlen. Merke: Diese sind nicht Teil der Zahl der Eigenen Tags die Sie oberhalb erstellt haben, und sind deshlab zus&auml;tzliche Tags.
Die vorgefertigten Tags sind sehr n&uuml;tzlich falls Sie einen bestimmten Eigenen Tag als Standard zur Verf&uuml;gung haben m&ouml;chten f&uuml;r jeden neuen Inhaltseintrag. Zum Beispiel, falls Sie immer die M&ouml;glichkeit haben m&ouml;chten, einen Wert f&uuml;r 'photographer' zu haben, k&ouml;nnen Sie einen solch vorgefertigten Datentag erstellen, wobei dieser dann immer in der Hauptkategorie f&uuml;r jeden neuen Inhaltseintrag angezeigt wird.");
define("CONTENT_ADMIN_OPT_LAN_9", "Erlaube es Eintr&auml;ge zu &uuml;bermitteln ?");
define("CONTENT_ADMIN_OPT_LAN_10", "Wer darf Eintr&auml;ge &uuml;bermitteln ?");
define("CONTENT_ADMIN_OPT_LAN_11", "Direkte Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_12", "Falls freigeschalten, wird ein &uuml;bermittelter Eintrag direkt in die Datenbank geschrieben und wird dadurch sofort sichtbar, auch wenn ein Seitenadmin dies noch &uuml;berr&uuml;fen m&uuml;&szlig;te.");
define("CONTENT_ADMIN_OPT_LAN_13", "Hier k&ouml;nnen Sie festlegen, wo Ihre Bilder gespeichert werden sollen. Bitte geschweifte Klammern verwenden ( { } ) f&uuml;r generelle e107 eigene Pfade (wie ( {e_PLUGIN} oder {e_IMAGE} ). F&uuml;r Inhaltskategorie Icons sind zwei n&ouml;tig, ein Set mit gro&szlig;en und kleinen Icons.");
define("CONTENT_ADMIN_OPT_LAN_15", "Pfad zu Inhalt Cat Icons (gro&szlig;)");
define("CONTENT_ADMIN_OPT_LAN_16", "Pfad zu Inhalt Cat Icons (klein)");
define("CONTENT_ADMIN_OPT_LAN_17", "Pfad zu Inhalt Eintrag Icons");
define("CONTENT_ADMIN_OPT_LAN_18", "Pfad zu Inhalt Eintrag Bildern");
define("CONTENT_ADMIN_OPT_LAN_19", "Pfad zu Inhalt Eintrag Anh&auml;ngen");
define("CONTENT_ADMIN_OPT_LAN_20", "Legen Sie ein Theme f&uuml;r diese Hauptkategorie fest");
define("CONTENT_ADMIN_OPT_LAN_21", "Legen Sie ein gesetztes Layoutschema fest");
define("CONTENT_ADMIN_OPT_LAN_22", "Loggin aktivieren um Z&auml;hlung zu erm&ouml;glichen");
define("CONTENT_ADMIN_OPT_LAN_23", "Zeige ein leeres Inhaltsicon, falls kein eigenes Icon vorhanden.");
define("CONTENT_ADMIN_OPT_LAN_24", "Zeige leeres Kategorie Icon, falls kein eigenes Icon vorhanden");
define("CONTENT_ADMIN_OPT_LAN_25", "W&auml;hlen Sie ein Layout Schema");
define("CONTENT_ADMIN_OPT_LAN_26", "Zeige breadcrumb auf diesen Seiten:");
define("CONTENT_ADMIN_OPT_LAN_27", "Alle Kategorien");
define("CONTENT_ADMIN_OPT_LAN_28", "Einzelkategorie");
define("CONTENT_ADMIN_OPT_LAN_29", "Alle Autoren");
define("CONTENT_ADMIN_OPT_LAN_30", "Einzelautor");
define("CONTENT_ADMIN_OPT_LAN_31", "Letzter");
define("CONTENT_ADMIN_OPT_LAN_32", "Inhaltseintrag");
define("CONTENT_ADMIN_OPT_LAN_33", "Bestbewertet");
define("CONTENT_ADMIN_OPT_LAN_34", "Archiv");
define("CONTENT_ADMIN_OPT_LAN_35", "Score");
define("CONTENT_ADMIN_OPT_LAN_36", "breadcrumb Trennzeichen");
define("CONTENT_ADMIN_OPT_LAN_37", "W&auml;hlen Sie hier, wie die Breadcrumb Informationen angezeigt werden sollen");
define("CONTENT_ADMIN_OPT_LAN_38", "");
define("CONTENT_ADMIN_OPT_LAN_39", "Echo");
define("CONTENT_ADMIN_OPT_LAN_40", "Benutze ein eigenes separates Men&uuml;");
define("CONTENT_ADMIN_OPT_LAN_41", "Kombination in einem Men&uuml;");
define("CONTENT_ADMIN_OPT_LAN_42", "");
define("CONTENT_ADMIN_OPT_LAN_43", "Einen Navigator auf diesen Seiten anzeigen:");
define("CONTENT_ADMIN_OPT_LAN_44", "Die uche auf diesen Seite anzeigen:");
define("CONTENT_ADMIN_OPT_LAN_45", "");
define("CONTENT_ADMIN_OPT_LAN_46", "Anordnungsoptionen auf diesen Seiten anzeigen:");
define("CONTENT_ADMIN_OPT_LAN_47", "");
define("CONTENT_ADMIN_OPT_LAN_48", "Anzeigemethode Navigator/Suche/Anordnung");
define("CONTENT_ADMIN_OPT_LAN_49", "Begrenzte Zahl an Eintr&auml;gen pro Seite anzeigen");
define("CONTENT_ADMIN_OPT_LAN_50", "Wieviele Eintr&auml;ge angezeigt werden");
define("CONTENT_ADMIN_OPT_LAN_51", "Eine gesetzte Sortierungsmethode w&auml;hlen");
define("CONTENT_ADMIN_OPT_LAN_52", "Maximale Bildgr&ouml;&szlig;e");
define("CONTENT_ADMIN_OPT_LAN_53", "Legen Sie hier die Gr&ouml;&szlig;e fest, in die hochgeladene Bilder ver&auml;ndert werden");
define("CONTENT_ADMIN_OPT_LAN_54", "Falls die Breite oder H&ouml;he des hochgeladenen Bildes gr&ouml;&szlig;er als der gesetzte Wert ist, wird das Bild in diesen Wert ge&auml;ndert.<br />Die Popup-Bilder werden dann ebenso in dieser Gr&ouml;&szlig;e angezeigt werden.");
define("CONTENT_ADMIN_OPT_LAN_55", "Thumb Bildgr&ouml;&szlig;e");
define("CONTENT_ADMIN_OPT_LAN_56", "Legen Sie hier die Gr&ouml;&szlig;e fest, in die hochgeladene Thumb Bilder ver&auml;ndert werden");
define("CONTENT_ADMIN_OPT_LAN_57", "Falls die Breite oder H&ouml;he des hochgeladenen Bildes gr&ouml;&szlig;er als der gesetzte Wert ist, wird das Bild in diesen Wert ge&auml;ndert.<br />Das Bild wird auch auf der Inhaltsseite in dieser gesetzte Gr&ouml;&szlig;e angezeigt werden.");
define("CONTENT_ADMIN_OPT_LAN_58", "Maximale Iconbeite");
define("CONTENT_ADMIN_OPT_LAN_59", "Legen Sie hier die maximale Breite des Icons fest");
define("CONTENT_ADMIN_OPT_LAN_60", "Falls die Breite oder H&ouml;he des hochgeladenen Icons gr&ouml;&szlig;er als der gesetzte Wert ist, wird das Bild in diesen Wert ge&auml;ndert.<br />Das Icon wird auch in dieser Gr&ouml;&szlig;e angezeigt werden.");
define("CONTENT_ADMIN_OPT_LAN_61", "px");
define("CONTENT_ADMIN_OPT_LAN_62", "W&auml;hlen Sie Manager dieser Benutzerklasse");
define("CONTENT_ADMIN_OPT_LAN_63", "Die Benutzerliste im Admin Inhaltsmanagerbereich wird nur aus Mitgliedern dieser gesetzte Klasse bestehen. Sie m&uuml;ssen Benutzer zu jeder Kategorie zuweisen! Diese Klasse wird dann eine Liste anzeigen aus der Sie ausw&auml;hlen k&ouml;nnen");
define("CONTENT_ADMIN_OPT_LAN_64", "EMAIL eines Autors anzeigen, der kein Mitglied ist");
define("CONTENT_ADMIN_OPT_LAN_65", "Einen Buchstaben-INDEX anzeigen");
define("CONTENT_ADMIN_OPT_LAN_66", "Der Buchstabenindex ist eine Liste von Buttons mit allen ersten Buchstaben der Inhalts&uuml;berschriftfelder. Sie k&ouml;nnen die Archivliste ansehen indem Sie einen bestimmten Buchstaben anklicken sodass nur Inhaltseintr&auml;ge, beginnend mit diesem Buchstaben auf dem Bildschirm angezeigt werden.");
define("CONTENT_ADMIN_OPT_LAN_67", "Datumsstil f&uuml;r Datumsanzeige festlegen");
define("CONTENT_ADMIN_OPT_LAN_68", "F&uuml;r mehr Informationen zum Datumsformat, besuchen Sie bitte <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime function page at php.net</a>");
define("CONTENT_ADMIN_OPT_LAN_69", "F&uuml;r jeden Eintrag ein Icon anzeigen lassen<br />(Druck/Email/pdf Icons)");
define("CONTENT_ADMIN_OPT_LAN_70", "Erlaube Bewertung f&uuml;r alle Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_71", "Erlaube Kommentare f&uuml;r alle Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_72", "");
define("CONTENT_ADMIN_OPT_LAN_73", "Anzeigemodus Multipage Index");
define("CONTENT_ADMIN_OPT_LAN_74", "Falls Sie einen Multipageartikel haben, k&ouml;nnen Sie sich entweder den Artikelindex dieser Seiten als Liste normaler Hyperlinks, oder in einer Auswahlbox anzeigen lassen.");
define("CONTENT_ADMIN_OPT_LAN_75", "Hyperlinks");
define("CONTENT_ADMIN_OPT_LAN_76", "Auswahlbox");
define("CONTENT_ADMIN_OPT_LAN_77", "Anzahl an Zeichen festlegen");
define("CONTENT_ADMIN_OPT_LAN_78", "Postfix festlegen");
define("CONTENT_ADMIN_OPT_LAN_79", "Freilassen um alles anzeigen zu lassen");
define("CONTENT_ADMIN_OPT_LAN_80", "Freilassen um nichts anzeigen zu lassen");
define("CONTENT_ADMIN_OPT_LAN_81", "Anzahl der Worte festlegen");
define("CONTENT_ADMIN_OPT_LAN_82", "Text");
define("CONTENT_ADMIN_OPT_LAN_83", "Dem Postfix einen Link hinzuf&uuml;gen");
define("CONTENT_ADMIN_OPT_LAN_84", "Hauptkategorieeintrag anzeigen");
define("CONTENT_ADMIN_OPT_LAN_85", "Unterkategorien anzeigen");
define("CONTENT_ADMIN_OPT_LAN_86", "Eintrage der Unterkategorie anzeigen");
define("CONTENT_ADMIN_OPT_LAN_87", "Falls hier freigeschalten, werden aller Eintr&auml;ge der gew&auml;hlten Kategorie angezeigt zuz&uuml;glich aller Eintr&auml;ge s&auml;mtlicher Unterkategorien.");
define("CONTENT_ADMIN_OPT_LAN_88", "Anordnungsmodus der Haupt,- und Unterkategorieeintr&auml;ge festlegen");
define("CONTENT_ADMIN_OPT_LAN_89", "Hauptkategorie zuerst, dann Einr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_90", "Eintr&auml;ge zuerst, dann Hauptkategorien");
define("CONTENT_ADMIN_OPT_LAN_91", "Anzeigemodus f&uuml;r Hauptkategorien, Unterkategorien und Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_92", "Jedes in einem eigenen Men&uuml;");
define("CONTENT_ADMIN_OPT_LAN_93", "&Uuml;berschrift");
define("CONTENT_ADMIN_OPT_LAN_94", "Suchebox hinzuf&uuml;gen");
define("CONTENT_ADMIN_OPT_LAN_95", "Sortierungs, - und Anordnungsbox hinzuf&uuml;gen");
define("CONTENT_ADMIN_OPT_LAN_96", "Linksnavigator anzeigen lassen");
define("CONTENT_ADMIN_OPT_LAN_97", "Falls freigeschalten, sind alle weiteren Optionen hinf&auml;llig");
define("CONTENT_ADMIN_OPT_LAN_98", "Link : alle Kategorien");
define("CONTENT_ADMIN_OPT_LAN_99", "Link : alle Autoren");
define("CONTENT_ADMIN_OPT_LAN_100", "Link : alle Inhaltseintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_101", "Link : Bestbewertet");
define("CONTENT_ADMIN_OPT_LAN_102", "Link : Top Score");
define("CONTENT_ADMIN_OPT_LAN_103", "Link : Letzte Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_104", "Link : Eintrag &uuml;bermitteln");
define("CONTENT_ADMIN_OPT_LAN_105", "Icon : Links");
define("CONTENT_ADMIN_OPT_LAN_106", "Keines (), bullet (), middot (&middot;), weisses bullet (�), Pfeil (&raquo;), Kategorie_Icon()");
define("CONTENT_ADMIN_OPT_LAN_107", "Keines");
define("CONTENT_ADMIN_OPT_LAN_108", "Bullet");
define("CONTENT_ADMIN_OPT_LAN_109", "Middot");
define("CONTENT_ADMIN_OPT_LAN_110", "Weisses Bullet");
define("CONTENT_ADMIN_OPT_LAN_111", "Pfeil");
define("CONTENT_ADMIN_OPT_LAN_112", "Kategorie Icon");
define("CONTENT_ADMIN_OPT_LAN_113", "Inhalts Icon");
define("CONTENT_ADMIN_OPT_LAN_114", "Anzeigemodus f&uuml;r Links");
define("CONTENT_ADMIN_OPT_LAN_115", "&Uuml;berschrift f&uuml;r die Link Liste");
define("CONTENT_ADMIN_OPT_LAN_116", "Diese &Uuml;berschrift wird nur angezeigt wenn die Links als 'Normale Links' gelten.");
define("CONTENT_ADMIN_OPT_LAN_117", "Kategorien anzeigen");
define("CONTENT_ADMIN_OPT_LAN_118", "Hauptkategorie inbegriffen");
define("CONTENT_ADMIN_OPT_LAN_119", "Falls nicht freigeschalten, werden nur die Unterkategorien der Hauptkategorie angezeigt");
define("CONTENT_ADMIN_OPT_LAN_120", "Anzahl der Eintr&auml;ge pro Kategorie anzeigen");
define("CONTENT_ADMIN_OPT_LAN_121", "Icon: Kategorie");
define("CONTENT_ADMIN_OPT_LAN_122", "Icon: Kategorie (gesetzt)");
define("CONTENT_ADMIN_OPT_LAN_123", "Anzeigemodus der Kategorie Liste");
define("CONTENT_ADMIN_OPT_LAN_124", "&Uuml;berschrift Kategorie Liste");
define("CONTENT_ADMIN_OPT_LAN_125", "Liste der letzten Eintr&auml;ge anzeigen");
define("CONTENT_ADMIN_OPT_LAN_126", "Datum anzeigen");
define("CONTENT_ADMIN_OPT_LAN_127", "Autor anzeigen");
define("CONTENT_ADMIN_OPT_LAN_128", "Unter&uuml;berschrift anzeigen");
define("CONTENT_ADMIN_OPT_LAN_129", "Unter&uuml;berschrift : Anzahl der Worte festlegen");
define("CONTENT_ADMIN_OPT_LAN_130", "Unter&uuml;berschrift : Postfix festlegen");
define("CONTENT_ADMIN_OPT_LAN_131", "Wieviele Eintr&auml;ge werden angezeigt");
define("CONTENT_ADMIN_OPT_LAN_132", "Icon der letzten Eintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_133", "Icon : Breite");
define("CONTENT_ADMIN_OPT_LAN_134", "Falls 'Inhalts Icon' gew&auml;hlt, legen Sie die Breite des cons fest, welches Sie benutzen wollen");
define("CONTENT_ADMIN_OPT_LAN_135", "&Uuml;berschrift der Liste letzter Inhaltseintr&auml;ge");
define("CONTENT_ADMIN_OPT_LAN_136", "");
define("CONTENT_ADMIN_OPT_LAN_137", "");
define("CONTENT_ADMIN_OPT_LAN_138", "");
define("CONTENT_ADMIN_OPT_LAN_139", "");




?>
