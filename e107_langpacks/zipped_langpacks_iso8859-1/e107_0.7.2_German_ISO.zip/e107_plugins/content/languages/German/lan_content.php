<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content.php,v $
|     $Revision: 1.13 $
|     $Date: 2005/02/11 16:17:29 $
|     $Author: lisa_ $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/


define("CONTENT_EMAILPRINT_LAN_1", "Dieser Inhaltseintrag ist von");

define("CONTENT_ICON_LAN_0", "Bearbeiten");
define("CONTENT_ICON_LAN_1", "L&ouml;schen");
define("CONTENT_ICON_LAN_2", "Optionen");
define("CONTENT_ICON_LAN_3", "Benutzer Details");
define("CONTENT_ICON_LAN_4", "Download Anhang");
define("CONTENT_ICON_LAN_5", "Neu");
define("CONTENT_ICON_LAN_6", "Inhalt &uuml;bermitteln");
define("CONTENT_ICON_LAN_7", "Autor Liste");
define("CONTENT_ICON_LAN_8", "Warnung");
define("CONTENT_ICON_LAN_9", "Ok");
define("CONTENT_ICON_LAN_10", "Fehler");
define("CONTENT_ICON_LAN_11", "Eintr&auml;ge nach Kategorien ordnen");
define("CONTENT_ICON_LAN_12", "Eintr&auml;ge nach Hauptkategorien ordnen");
define("CONTENT_ICON_LAN_13", "Pers&ouml;nlicher Admin");
define("CONTENT_ICON_LAN_14", "Pers&ouml;nlicher Inhaltsmanager");
define("CONTENT_ICON_LAN_15", "Ansehen");


define("CONTENT_ADMIN_DATE_LAN_0", "Januar");
define("CONTENT_ADMIN_DATE_LAN_1", "Februar");
define("CONTENT_ADMIN_DATE_LAN_2", "M&auml;rz");
define("CONTENT_ADMIN_DATE_LAN_3", "April");
define("CONTENT_ADMIN_DATE_LAN_4", "Mai");
define("CONTENT_ADMIN_DATE_LAN_5", "Juni");
define("CONTENT_ADMIN_DATE_LAN_6", "Juli");
define("CONTENT_ADMIN_DATE_LAN_7", "August");
define("CONTENT_ADMIN_DATE_LAN_8", "September");
define("CONTENT_ADMIN_DATE_LAN_9", "Oktober");
define("CONTENT_ADMIN_DATE_LAN_10", "November");
define("CONTENT_ADMIN_DATE_LAN_11", "Dezember");
define("CONTENT_ADMIN_DATE_LAN_12", "Tag");
define("CONTENT_ADMIN_DATE_LAN_13", "Monat");
define("CONTENT_ADMIN_DATE_LAN_14", "Jahr");
define("CONTENT_ADMIN_DATE_LAN_15", "Setzen Sie ein eigenes Startdatum");
define("CONTENT_ADMIN_DATE_LAN_16", "Setzen Sie ein Enddatum");
define("CONTENT_ADMIN_DATE_LAN_17", "Sie k&ouml;nnen f&uuml;r diesen Eintrag ein Startdatum festsetzen. Bitte frei lassen f&uuml;r jetziges Datum");
define("CONTENT_ADMIN_DATE_LAN_18", "Sie k&ouml;nnen f&uuml;r diesen Eintrag ein Enddatum festsetzen. Bitte frei lassen f&uuml;r endlos");

define("CONTENT_PAGETITLE_LAN_0", "Inhalt");
define("CONTENT_PAGETITLE_LAN_1", "Haupt");
define("CONTENT_PAGETITLE_LAN_2", "Letzte");
define("CONTENT_PAGETITLE_LAN_3", "Kategorie");
define("CONTENT_PAGETITLE_LAN_4", "Meist bewertet");
define("CONTENT_PAGETITLE_LAN_5", "Autor");
define("CONTENT_PAGETITLE_LAN_6", "Archiv");
define("CONTENT_PAGETITLE_LAN_7", "&Uuml;bermitteln");
define("CONTENT_PAGETITLE_LAN_8", "Inhaltseintrag &uuml;bermitteln");
define("CONTENT_PAGETITLE_LAN_9", "Pers&ouml;nlicher Inhaltmanager");
define("CONTENT_PAGETITLE_LAN_10", "Eintrage ansehen");
define("CONTENT_PAGETITLE_LAN_11", "Eintr&auml;ge bearbeiten");
define("CONTENT_PAGETITLE_LAN_12", "Eintrag erstellen");
define("CONTENT_PAGETITLE_LAN_13", "Kategorien");
define("CONTENT_PAGETITLE_LAN_14", "Autorliste");
define("CONTENT_PAGETITLE_LAN_15", "Top Score");

define("CONTENT_SEARCH_LAN_0", "Keine Inhaltseintr&auml;ge f&uuml;r diese Schl&uuml;sselw&ouml;rter gefunden.");


define("CONTENT_ORDER_LAN_0", "Sortiert nach ...");
define("CONTENT_ORDER_LAN_1", "&Uuml;berschrift (Absteigend)");
define("CONTENT_ORDER_LAN_2", "&Uuml;berschrift (Aufsteigend)");
define("CONTENT_ORDER_LAN_3", "Datum (Absteigend)");
define("CONTENT_ORDER_LAN_4", "Datum (Aufsteigend)");
define("CONTENT_ORDER_LAN_5", "Refer (Absteigend)");
define("CONTENT_ORDER_LAN_6", "refer (Aufsteigend)");
define("CONTENT_ORDER_LAN_7", "Hauptkategorie (Absteigend)");
define("CONTENT_ORDER_LAN_8", "Hauptkategorie (Aufsteigend)");
define("CONTENT_ORDER_LAN_9", "Ordnung (Absteigend)");
define("CONTENT_ORDER_LAN_10", "Ordnung (Aufsteigend)");
define("CONTENT_ORDER_LAN_11", "Autor (Absteigend)");
define("CONTENT_ORDER_LAN_12", "Autor (Aufsteigend)");

define("CONTENT_LAN_0", "Inhalt");
define("CONTENT_LAN_1", "Letzte Eintr&auml;ge Liste");
define("CONTENT_LAN_2", "Kategorien Liste");
define("CONTENT_LAN_3", "Kategorie");
define("CONTENT_LAN_4", "Autor Liste");
define("CONTENT_LAN_5", "Autor");
define("CONTENT_LAN_6", "Alle Kategorien");
define("CONTENT_LAN_7", "Alle Autoren");
define("CONTENT_LAN_8", "Best bewertete Eintr&auml;ge");
define("CONTENT_LAN_9", "in");

define("CONTENT_LAN_10", "am");
define("CONTENT_LAN_11", "von");
define("CONTENT_LAN_12", "Top score Einr&auml;ge");
define("CONTENT_LAN_13", "");
define("CONTENT_LAN_14", "");
define("CONTENT_LAN_15", "");
define("CONTENT_LAN_16", "");
define("CONTENT_LAN_17", "");
define("CONTENT_LAN_18", "Suche nach Schl&uuml;sselw&ouml;rtern");
define("CONTENT_LAN_19", "Suche");

define("CONTENT_LAN_20", "Einhaltssuche Ergebnisse");
define("CONTENT_LAN_21", "Keine Inhaltstypen bis jetzt.");
define("CONTENT_LAN_22", "Inhaltstypen");
define("CONTENT_LAN_23", "Inhaltsliste letzte Eintr&auml;ge");
define("CONTENT_LAN_24", "breadcrumb");
define("CONTENT_LAN_25", "Inhaltskategorien");
define("CONTENT_LAN_26", "Hauptkategorie");
define("CONTENT_LAN_27", "Unterkategorie");
define("CONTENT_LAN_28", "Haupt-Unterkategorie");
define("CONTENT_LAN_29", "unbekannt");
define("CONTENT_LAN_30", "Inhaltseintrag");
define("CONTENT_LAN_31", "Inhaltseintr&auml;ge");
define("CONTENT_LAN_32", "Inhaltsliste Autoren");
define("CONTENT_LAN_33", "Gehe zur Seite");
define("CONTENT_LAN_34", "Inhalt");
define("CONTENT_LAN_35", "Kommentare");
define("CONTENT_LAN_36", "Kommentare moderieren");
define("CONTENT_LAN_37", "Keine Inhalteintr&auml;ge bewertet bis jetzt");
define("CONTENT_LAN_38", "Bestbewertete Inhalteintr&auml;ge");
define("CONTENT_LAN_39", "Autor Liste");

define("CONTENT_LAN_40", "Autor Benutzer Details");
define("CONTENT_LAN_41", "Download angeh&auml;ngt");
define("CONTENT_LAN_42", "Datei");
define("CONTENT_LAN_43", "Dateien");
define("CONTENT_LAN_44", "Hits:");
define("CONTENT_LAN_45", "Autor bezogener Score:");
define("CONTENT_LAN_46", "Artikel Index");
define("CONTENT_LAN_47", "Autor");
define("CONTENT_LAN_48", "Inhalt Eintr&auml;ge");
define("CONTENT_LAN_49", "Letzter Inhaltseintrag");

define("CONTENT_LAN_50", "Datum");
define("CONTENT_LAN_51", "Typen Liste");
define("CONTENT_LAN_52", "keine g&uuml;ltigen Autoren gefunden");
define("CONTENT_LAN_53", "Eintrag");
define("CONTENT_LAN_54", "Eintr&auml;ge");
define("CONTENT_LAN_55", "Letzter Eintrag von");
define("CONTENT_LAN_56", "Zeige &Uuml;bersicht");
define("CONTENT_LAN_57", "Kommentare:");
define("CONTENT_LAN_58", "Home");
define("CONTENT_LAN_59", "Inhalt");
define("CONTENT_LAN_60", "Letzte");
define("CONTENT_LAN_61", "Zeige letzte Eintr&auml;ge");
define("CONTENT_LAN_62", "Zeige alle Kategorien");
define("CONTENT_LAN_63", "Zeige alle Autoren");
define("CONTENT_LAN_64", "Zeige bestbewertete Eintr&auml;ge");
define("CONTENT_LAN_65", "Inhalt &uuml;bermitteln");
define("CONTENT_LAN_66", "Klicke hier um Inhalt zu &uuml;bermitteln, Sie k&ouml;nnen die Kategorie auf der &Uuml;bermittlungsseite w&auml;hlen.");
define("CONTENT_LAN_67", "Pers&ouml;nlicher Inhaltsmanager");
define("CONTENT_LAN_68", "Klicken Sie hier um Ihren pers&ouml;nlichen Inhalt zu managen.");
define("CONTENT_LAN_69", "Email an");
define("CONTENT_LAN_70", "Drucke das");
define("CONTENT_LAN_71", "Inhaltseintrag");
define("CONTENT_LAN_72", "Kategorieeintrag");
define("CONTENT_LAN_73", "Keine Inhaltseintr&auml;ge bis jetzt");
define("CONTENT_LAN_74", "");
define("CONTENT_LAN_75", "Inhaltseintrag &uuml;bermitteln");
define("CONTENT_LAN_76", "pdf-Datei erstellen");
define("CONTENT_LAN_77", "Inhalts Suche");
define("CONTENT_LAN_78", "Seite ohne &Uuml;berschrift");
define("CONTENT_LAN_79", "Seite");
define("CONTENT_LAN_80", "Letzte Eintr&auml;ge : ");
define("CONTENT_LAN_81", "Kategorien");
define("CONTENT_LAN_82", "Keine Eintr&auml;ge bis jetzt in");
define("CONTENT_LAN_83", "Eintrags Archiv");
define("CONTENT_LAN_84", "Inhalts Archiv");
define("CONTENT_LAN_85", "Autorliste");
define("CONTENT_LAN_86", "Top Score Eintr&auml;ge ansehen");
define("CONTENT_LAN_87", "Top Score Inhalt");
define("CONTENT_LAN_88", "Keine Inhaltseintr&auml;ge haben bis jetzt einen Score");
define("CONTENT_LAN_89", "Seite ausw&auml;hlen");


define("CONTENT_MENU_LAN_0", "Inhalts-Men&uuml; :");
define("CONTENT_MENU_LAN_1", "Keine Inhaltseint&auml;ge bis jetzt");
define("CONTENT_MENU_LAN_2", "Letzte Eintr&auml;ge");
define("CONTENT_MENU_LAN_3", "Kategorien");
define("CONTENT_MENU_LAN_4", "Inhalts Links");
define("CONTENT_MENU_LAN_5", "");
define("CONTENT_MENU_LAN_6", "");
define("CONTENT_MENU_LAN_7", "");
define("CONTENT_MENU_LAN_8", "");
define("CONTENT_MENU_LAN_9", "");
define("CONTENT_MENU_LAN_10", "");
define("CONTENT_MENU_LAN_11", "");
define("CONTENT_MENU_LAN_12", "");
define("CONTENT_MENU_LAN_13", "");
define("CONTENT_MENU_LAN_14", "");
define("CONTENT_MENU_LAN_15", "");
define("CONTENT_MENU_LAN_16", "");
define("CONTENT_MENU_LAN_17", "");
define("CONTENT_MENU_LAN_18", "");
define("CONTENT_MENU_LAN_19", "");
define("CONTENT_MENU_LAN_20", "");




?>
