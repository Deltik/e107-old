<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/admin/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:52:39 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
	
define("CLOCK_AD_L1", "Clock Men&uuml; Konfiguration gespeichert");
define("CLOCK_AD_L2", "&Uuml;berschrift");
define("CLOCK_AD_L3", "Men&uuml;einstellungen aktualisieren");
define("CLOCK_AD_L4", "Clock Men&uuml; Konfiguration");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Falls markiert, wird die Zeit im US Format angezeigt (0-12 AM/PM format). Falls nicht markiert wird die Zeit im 0-24 Stundenformat angezeigt.");
define("CLOCK_AD_L7", "Datum Prefix");
define("CLOCK_AD_L8", "Falls f&uuml;r Ihre Sprache eine L&auml;nderk&uuml;rzel vor dem Datum erforderlich ist (Beispiel 'le' f&uuml;r franz&ouml;sisch oder 'den' f&uuml;r deutsch...), nutze dieses Feld. Falls nicht erforderlich, einfach freilassen.");
define("CLOCK_AD_L9", "Suffix 1");
define("CLOCK_AD_L10", "Suffix 2");
define("CLOCK_AD_L11", "Suffix 3");
define("CLOCK_AD_L12", "Suffix 4 und mehr");
define("CLOCK_AD_L13", "Falls f&uuml;r Ihre Sprache eine Suffix unmittelbar nach den Zeichen des Datums erforderlich ist, tragen Sie bitte nur die Suffix hier ein (Beispiel: 'st' f&uuml;r 1, 'nd' f&uuml;r 2, 'rd' f&uuml;r 3 und 'th' f&uuml;r 4 und mehr f&uuml;r englische Benutzer). Falls nicht erforderlich, bitte freilassen.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>
