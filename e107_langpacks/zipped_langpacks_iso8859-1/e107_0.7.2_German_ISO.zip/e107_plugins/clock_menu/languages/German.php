<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/German.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define('CLOCK_MENU_L1','Clock Men&uuml; Konfiguration gespeichert');
define('CLOCK_MENU_L2','Bezeichnung');
define('CLOCK_MENU_L3','Men&uuml;einstellungen aktuallisieren');
define('CLOCK_MENU_L4','Clock Men&uuml; Einstellungen');
define('CLOCK_MENU_L5','Montag,');
define('CLOCK_MENU_L6','Dienstag,');
define('CLOCK_MENU_L7','Mittwoch,');
define('CLOCK_MENU_L8','Donnerstag,');
define('CLOCK_MENU_L9','Freitag,');
define('CLOCK_MENU_L10','Samstag,');
define('CLOCK_MENU_L11','Sonntag,');
define('CLOCK_MENU_L12','Januar');
define('CLOCK_MENU_L13','Februar');
define('CLOCK_MENU_L14','MÃ¤rz');
define('CLOCK_MENU_L15','April');
define('CLOCK_MENU_L16','Mai');
define('CLOCK_MENU_L17','Juni');
define('CLOCK_MENU_L18','Juli');
define('CLOCK_MENU_L19','August');
define('CLOCK_MENU_L20','September');
define('CLOCK_MENU_L21','Oktober');
define('CLOCK_MENU_L22','November');
define('CLOCK_MENU_L23','Dezember');
define('CLOCK_MENU_L24','');

?>
