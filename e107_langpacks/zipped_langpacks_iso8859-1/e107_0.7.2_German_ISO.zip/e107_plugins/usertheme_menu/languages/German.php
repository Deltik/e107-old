<?php

define("LAN_350", "Theme setzen");
define("LAN_351", "Theme w&auml;hlen");

?>
