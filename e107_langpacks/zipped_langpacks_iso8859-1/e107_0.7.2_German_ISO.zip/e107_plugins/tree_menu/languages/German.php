<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/German.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/12 21:33:27 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
	
	
define("TREE_L1", "Tree Men&uuml; konfigurieren");
define("TREE_L2", "Tree Menu Einstellungen aktualisieren");
define("TREE_L3", "Tree Menu Konfiguration gespeichert.");
define("TREE_L4", "An");
define("TREE_L5", "Aus");
?>
