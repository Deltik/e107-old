<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/banner_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/01/27 19:52:35 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Werbung");
define("BANNER_MENU_L2", "Banner Men&uuml; Konfiguration gespeichert");

define("BANNER_MENU_L3", "&Uuml;berschrift");
define("BANNER_MENU_L4", "Kampagne");
define("BANNER_MENU_L5", "Banner Men&uuml; Konfiguration");
define("BANNER_MENU_L6", "W&auml;hlen Sie die Kampagnen, die im Men&uuml; angezeigt werden sollen");
define("BANNER_MENU_L7", "Bestehende Kampagnen");
define("BANNER_MENU_L8", "Gew&auml;hlte Kampagnen");
define("BANNER_MENU_L9", "Auswahl aufheben");
define("BANNER_MENU_L10", "Wie sollen die gew&auml;hlten Kampagnen angezeigt werden ?");
define("BANNER_MENU_L11", "W&auml;hlen Sie die Anzeigeoption ...");
define("BANNER_MENU_L12", "Eine Kampagne in einem Men&uuml;");
define("BANNER_MENU_L13", "Alle Kampagnen in einem Men&uuml;");
define("BANNER_MENU_L14", "Alle Kampagnen in separaten Men&uuml;s");
define("BANNER_MENU_L15", "Wieviele Banner sollen angezeigt werden ?");
define("BANNER_MENU_L16", "Diese Einstellungen gelten nur in Verbindung mit Option 2 und 3.<br />Falls weniger Banner vorhanden sind, wird die maximale Anzahl gesetzt.");
define("BANNER_MENU_L17", "Anzahl setzen ...");
define("BANNER_MENU_L18", "Men&uuml;einstellungen aktualisieren");

?>
