<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/German_config.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/01 05:15:01 $
|     $Author: sweetas $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Chatbox Einstellungen aktualisiert.");
define("CHBLAN_2", "Moderiert.");
define("CHBLAN_3", "Keine Chatboxeintr&auml;ge bis jetzt.");
define("CHBLAN_4", "Mitglied");
define("CHBLAN_5", "Gast");
define("CHBLAN_6", "Blocken aufheben");
define("CHBLAN_7", "Blockieren");
define("CHBLAN_8", "L&ouml;schen");
define("CHBLAN_9", "Chatbox moderieren");
define("CHBLAN_10", "Eintr&auml;ge moderieren");
define("CHBLAN_11", "Anzeige der Chatboxeintr&auml;ge");
define("CHBLAN_12", "Anzahl der angezeigten Eintr&auml;ge in der Chatbox");
define("CHBLAN_13", "Links ersetzen");
define("CHBLAN_14", "falls hier markiert, werden gepostete Links mit dem Text ersetzt der in der unteren Box einzugeben ist");
define("CHBLAN_15", "Links durch Zeichenketten ersetzen, falls aktiviert");
define("CHBLAN_16", "Links werden ersetzt durch diese Zeichenkette");
define("CHBLAN_17", "Zeilenumbruch Zahl");
define("CHBLAN_18", "W&ouml;rter die l&auml;nger sind, als die von Ihnen hier gesetzte Zahl werden in die n&auml;chste Zeile gesetzt.");
define("CHBLAN_19", "Chatbox Einstellungen aktualisieren");
define("CHBLAN_20", "Chatbox Einstellungen");
define("CHBLAN_21", "Abschicken");
define("CHBLAN_22", "Chatboxeintr&auml;ge einer bestimmten Zeitperiode l&ouml;schen");
define("CHBLAN_23", "Chatboxeintr&auml;ge l&ouml;schen, die &auml;lter sind als ");

define("CHBLAN_24", "Ein Tag");
define("CHBLAN_25", "Eine Woche");
define("CHBLAN_26", "Ein Monat");
define("CHBLAN_27", "- Alle Eintr&auml;ge l&ouml;schen -");
define("CHBLAN_28", "Chatbox pruned.");

define("CHBLAN_29", "Chatbox innerhalb eines Scrolling Layer's anzeigen");
define("CHBLAN_30", "Layer H&ouml;he");
define("CHBLAN_31", "Smilies anzeigen");
define("CHBLAN_32", "Moderator Benutzerklassen");

define("CHBLAN_33", "Neukalkulierte Benutzerz&auml;hlung");
define("CHBLAN_34", "Benutzerz&auml;hlung neu kalkulieren");
define("CHBLAN_35", "Neu kalkulieren");

define("CHBLAN_36", "Chatbox Anzeigeoptionen");
define("CHBLAN_37", "Normale Chatbox");
define("CHBLAN_38", "Javascript Code verwenden um Eintr&auml;ge dynamisch zu aktualisieren (AJAX)");

?>
