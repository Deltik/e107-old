<?php

define("LDAPLAN_1", "Server Adresse");

define("LDAPLAN_2", "Basis DN oder Domain<br />Falls LDAP - Bitte BasisDN eingeben<br />Falls AD - Bitte Domain eingeben");

define("LDAPLAN_3", "LDAP Benutzer<br />Vollst&auml;ndiger Kontext des Benutzers, der diese Verzeichnis durchsuchen kann.");

define("LDAPLAN_4", "LDAP Passwort<br />Passwort f�r den LDAP Benutzer.");

define("LDAPLAN_5", "LDAP Version");

define("LDAPLAN_6", "LDAP auth konfigurieren");

?>
