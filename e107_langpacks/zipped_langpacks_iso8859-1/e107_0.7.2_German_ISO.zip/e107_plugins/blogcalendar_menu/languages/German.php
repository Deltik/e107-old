<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| Â©Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+---------------------------------------------------------------+
*/
define("BLOGCAL_L1", "News f&uuml;r ");
define("BLOGCAL_L2", "Archiv");

define("BLOGCAL_D1", "Mo");
define("BLOGCAL_D2", "Di");
define("BLOGCAL_D3", "Mi");
define("BLOGCAL_D4", "Do");
define("BLOGCAL_D5", "Fr");
define("BLOGCAL_D6", "Sa");
define("BLOGCAL_D7", "So");

define("BLOGCAL_M1", "Januar");
define("BLOGCAL_M2", "Februar");
define("BLOGCAL_M3", "M&auml;rz");
define("BLOGCAL_M4", "April");
define("BLOGCAL_M5", "Mai");
define("BLOGCAL_M6", "Juni");
define("BLOGCAL_M7", "Juli");
define("BLOGCAL_M8", "August");
define("BLOGCAL_M9", "September");
define("BLOGCAL_M10", "Oktober");
define("BLOGCAL_M11", "November");
define("BLOGCAL_M12", "Dezember");

define("BLOGCAL_1", "News Eintr&auml;ge");

define("BLOGCAL_CONF1", "Monat/row");
define("BLOGCAL_CONF2", "Zellenabstand");
define("BLOGCAL_CONF3", "Menu&uuml;einstellungen aktualisieren");
define("BLOGCAL_CONF4", "Blochkalender Men&uuml;konfiguration");
define("BLOGCAL_CONF5", "Blockkalender Men&auml;konfiguration gespeichert");

define("BLOGCAL_ARCHIV1", "Archiv ausw&auml;hlen");

?>
