﻿// DE lang variables

tinyMCE.addToLang('flash',{
title : 'Flashfilm  Einfügen/Bearbeiten',
desc : 'Flashfilm  Einfügen/Bearbeiten',
file : 'Flashdatei (.swf)',
size : 'Größe',
list : 'Flashdateien',
props : 'Flasheigenschaften',
general : 'General'
});
