<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2007/02/19 16:56:45 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/phpmailer/language/phpmailer.lang-pl.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/phpmailer/language/phpmailer.lang-en.php rev. 1.2 (27 jun 2005)
+-----------------------------------------------------------------------------+
*/

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Musisz poda� przynajmniej jeden' . 'adres email odbiorcy.';
$PHPMAILER_LANG["mailer_not_supported"] = ' Wybrana metoda wysy�ania poczty nie jest wspierana przez serwer.';
$PHPMAILER_LANG["execute"] = 'Nie mog� wykona�: ';
$PHPMAILER_LANG["instantiate"] = 'Nie mog� wywo�a� funkcj� email().';
$PHPMAILER_LANG["authenticate"] = 'B��d SMTP: Nie mo�na przeprowadzi� autentykacji.';
$PHPMAILER_LANG["from_failed"] = 'Nast�puj�cy adres nadawacy jest niepoprawny: ';
$PHPMAILER_LANG["recipients_failed"] = 'B��d SMTP: Nast�puj�cy adres ' . 'odbiorcy jest niepoprawny: ';
$PHPMAILER_LANG["data_not_accepted"] = 'B��d SMTP: Dane nie zosta�y zaakceptowane.';
$PHPMAILER_LANG["connect_host"] = 'B��d SMTP: Nie mog� nawi�za� po��czenia z hostem SMTP.';
$PHPMAILER_LANG["file_access"] = 'Brak dost�pu do pliku: ';
$PHPMAILER_LANG["file_open"] = 'B��d: Nie mog� otworzy� pliku: ';
$PHPMAILER_LANG["encoding"] = 'Nierozpoznane kodowanie znak�w: ';

?>
