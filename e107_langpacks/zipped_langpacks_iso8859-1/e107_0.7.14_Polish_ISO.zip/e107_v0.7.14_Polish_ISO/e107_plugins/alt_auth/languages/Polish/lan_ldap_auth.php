<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2006/10/19 16:40:25 $
|     $Author: dr_prozac $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/alt_auth/languages/Polish/lan_ldap_auth.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/alt_auth/languages/English/lan_ldap_auth.php rev. 1.4
+-----------------------------------------------------------------------------+
*/
 
define("LDAPLAN_1", "Adres serwera");
define("LDAPLAN_2", "Bazowy DN lub domena<br />Je�li LDAP - wprowad� bazowy DN<br />Je�li AD - wprowad� domen�");
define("LDAPLAN_3", "Przegl�danie LDAP - u�ytkownik<br />Pe�na nazwa u�ytkownika, kt�ry b�dzie w stanie przeszukiwa� katalog.");
define("LDAPLAN_4", "Przegl�danie LDAP - has�o<br />Has�o do przegl�dania u�ytkownik�w LDAP.");
define("LDAPLAN_5", "Wersja LDAP");
define("LDAPLAN_6", "Konfiguracja autoryzacji LDAP");
define("LDAPLAN_7", "eDirectory - filtr wyszukiwania:");
define("LDAPLAN_8", "Zostanie u�yty do zapewnienia, �e nazwa u�ytkownika jest w poprawnym drzewie, <br />np: '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Obecnym filtrem wyszukiwania jest:");
define("LDAPLAN_10", "Ustawienia zosta�y zaktualizowane");
define("LDAPLAN_11", "OSTRZE�ENIE:  Wyst�pi� problem! Modu� LDAP jest obecnie niedostepny, w zwi�zku z czym Twoje ustawienia autentykacji LDAP nie b�d� dzia�a�!"); // It appears as if the ldap module is not currently available, setting your auth method to LDAP will probably not work!
define("LDAPLAN_12", "Typ serwera");
define("LDAPLAN_13", "Aktualizuj ustawienia");
?>
