<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/10/02 14:40:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum_viewforum.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_forum_viewforum.php rev. 1.8
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Forum");

define("LAN_01", "Forum");
define("LAN_02", "Powr�t do g�ry");
define("LAN_03", "Przejd�");
define("LAN_53", "Temat");
define("LAN_54", "Autor");
define("LAN_55", "Posty");
define("LAN_56", "Ods�on");
define("LAN_57", "Ostatni post");
define("LAN_58", "Nie ma jeszcze temat�w na tym forum.");
define("LAN_59", "Na forum mog� si� wypowiada� tylko zarejestrowani u�ytkownicy, je�li posiadasz ju� swoje konto <a href='".e_BASE."login.php'>zaloguj si�</a>, w przeciwnym wypadku <a href='".e_BASE."login.php'>zarejestruj si�</a>.");
define("LAN_79", "Nowe posty");
define("LAN_80", "Brak nowych post�w");
define("LAN_81", "Temat zamkni�ty");
define("LAN_180", "Szukaj");
define("LAN_199", "Posiadasz nieprzeczytane wypowiedzi");
define("LAN_202", "Przyklejony");
define("LAN_203", "Przyklejony [zablokowany]");
define("LAN_204", "<b>Mo�esz</b> rozpoczyna� nowe tematy");
define("LAN_205", "<b>Nie mo�esz</b> rozpoczyna� nowych temat�w");
define("LAN_206", "<b>Mo�esz</b> odpowiada� w tematach");
define("LAN_207", "<b>Nie mo�esz</b> odpowiada� w tematach");
define("LAN_208", "<b>Mo�esz</b> redagowa� swoje posty");
define("LAN_209", "<b>Nie mo�esz</b> redagowa� swoich post�w");
define("LAN_316", "Przejd� do strony: ");
define("LAN_317", "Brak");
define("LAN_321", "Moderatorzy: ");
define("LAN_395", "[popularny]");
define("LAN_396", "Og�oszenie");
	
define("LAN_397", "Obecnie to forum jest przeznaczone tylko do odczytu");
	
define("LAN_398", "Odklej temat");
define("LAN_399", "Zamknij");
define("LAN_400", "Odblokuj temat");
define("LAN_401", "Przyklej");
define("LAN_402", "Przenie� temat");
define("LAN_403", "Przejd� do forum");
define("LAN_404", "Moderatorzy forum");
	
define("LAN_405", "u�ytkownik aktualnie przegl�da to forum");
define("LAN_406", "u�ytkownik�w aktualnie przegl�da to forum");
define("LAN_407", "zarejestrowany");
define("LAN_408", "go��");
define("LAN_409", "zarejestrowanych");
define("LAN_410", "go�ci");
	
//v.616
define("LAN_411", "Wa�ne tematy");
define("LAN_412", "Tematy forum");
define("LAN_431", "Kana�y informacyjne: RSS 0.92");
define("LAN_432", "Kana�y informacyjne: RSS 2.0");
define("LAN_433", "Kana�y informacyjne: RDF");

define("LAN_434", "Czy na pewno chcesz usun�� ten temat oraz tycz�ce si� niego odpowiedzi?");
define("LAN_435", "Usu� temat");

//v.617
define("FORLAN_CLOSE", "Temat zosta� zamkni�ty.");
define("FORLAN_OPEN", "Temat zosta� ponownie otwarty.");
define("FORLAN_STICK", "Temat zosta� przyklejony.");
define("FORLAN_UNSTICK", "Temat zosta� odklejony.");
define("FORLAN_6", "Temat zosta� usuni�ty");
define("FORLAN_7", "odpowiedzi skasowano");
define("FORLAN_8", "tutaj");
define("FORLAN_9", ", aby si� zarejestrowa� lub zaloguj si� za pomoc� Menu Login lub ze strony <a href='".e_BASE."login.php'>Logowanie</a>.");

define("FORLAN_10", "Rozpocznij nowy temat");
define("FORLAN_11", "Nowe posty");
define("FORLAN_12", "Brak nowych post�w");
define("FORLAN_13", "Nowe posty w popularnym temacie");
define("FORLAN_14", "Brak nowych post�w w popularnym temacie");
define("FORLAN_15", "Przyklejony temat");
define("FORLAN_16", "Przyklejony temat [Zamkni�ty]");
define("FORLAN_17", "Og�oszenie");
define("FORLAN_18", "Temat zamkni�ty");
define('FORLAN_19', '[u�ytkownik usuni�ty]');
define('FORLAN_20', 'Subforum');
define('FORLAN_21', 'Tematy');
define('FORLAN_22', 'Ostatni post');
  
?>
