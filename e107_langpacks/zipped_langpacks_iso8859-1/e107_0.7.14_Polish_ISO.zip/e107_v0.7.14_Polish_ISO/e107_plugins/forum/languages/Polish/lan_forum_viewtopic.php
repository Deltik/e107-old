<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2006/11/01 00:11:28 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum_viewtopic.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_forum_viewtopic.php rev. 1.12
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Forum");
	
define("LAN_01", "Forum");
define("LAN_02", "Przejd� do strony");
define("LAN_03", "Przejd�");
define("LAN_04", "Poprzedni");
define("LAN_05", "Nast�pny");
define("LAN_06", "Do��czy�");
define("LAN_07", "Miejscowo��");
define("LAN_08", "Strona WWW");
define("LAN_09", "Wizyt na stronie od czasu rejestracji");
define("LAN_10", "Powr�t do g�ry");
define("LAN_65", "Przejd� do");
define("LAN_66", "Ten temat jest aktualnie zamkni�ty");
define("LAN_67", "post�w");
define("LAN_194", "Go��");
define("LAN_195", "Zarejestrowany");
define("LAN_321", "Moderatorzy: ");
define("LAN_389", "Poprzedni temat");
define("LAN_390", "Kolejny temat");
define("LAN_391", "�led� temat");;
define("LAN_392", "Zako�cz �ledzenie");
define("LAN_393", "Szybka odpowied�");
define("LAN_394", "Podgl�d");
define("LAN_395", "Wy�lij");
define("LAN_396", "Strona WWW");
define("LAN_397", "Email");
define("LAN_398", "Profil");
define("LAN_399", "Wiadomo�� prywatna");
define("LAN_400", "Redaguj");
define("LAN_401", "Cytuj");

define("LAN_402", "Autor");
define("LAN_403", "Odpowiedzi");
define("LAN_404", "Brak wcze�niejszych tematu");
define("LAN_405", "Brak kolejnych tematu");

define("LAN_406", "Moderator: Redaguj");
define("LAN_435", "Moderator: Usu�");
define("LAN_408", "Moderator: Przesu�");
define("LAN_409", "Czy na pewno chcesz usun�� ten temat oraz tycz�ce si� niego odpowiedzi?");
define("LAN_410", "Czy na pewno chcesz usun�� tego posta?");
define("LAN_411", "napisa� ");
	
//v.616
define("LAN_412", "Tytu�");
define("LAN_413", "Raport");
define("LAN_414", "Zg�oszenie wskazanego tematu do moderatora");
define("LAN_415", "Tytu� tematu");
define("LAN_416", "Wejd� do swojego raportu");
define("LAN_417", "Administrator zostanie powiadomiony o tym temacie. Mo�esz wys�a� wiadomo�� wyja�niaj�c�, co wed�ug Ciebie jest nieodpowiednie w zg�aszanej wypowiedzi.");
define("LAN_418", "<b>Nie</b> u�ywaj tej formy kontaktu z administratorem z jakiegokolwiek innego powodu.");
define("LAN_419", "Wy�lij raport");
define("LAN_420", "Kliknij, aby zobaczy� posta");
define("LAN_421", "Temat forum zosta� zg�oszony z");
define("LAN_422", "Ta wypowied� zosta� zg�oszona ze strony" );
define("LAN_423", "Wiadomo�� nie mog�a by� wys�ana.  ");
define("LAN_424", "Wypowied� zosta�a zg�oszona do moderatora.<br />Dzi�kujemy.");
define("LAN_425", "Wiadomo�� od: ");
define("LAN_426", "Zg�oszenie posta w temacie: ");
define("LAN_427", "B��d wysy�ania emaila");
define("LAN_428", "Post zosta� zg�oszony");
define("LAN_429", "Kliknij tutaj, aby powr�ci� do forum");
define("LAN_430", "ankieta");
define("FORLAN_26", "Odpowied� zosta�a usuni�ta");
define("FORLAN_10", "Rozpocz�cie nowego tematu");
define("LAN_29", "Edytowany");

define("LAN_431", "Kana�y informacyjne: RSS 0.92");
define("LAN_432", "Kana�y informacyjne: RSS 2.0");
define("LAN_433", "Kana�y informacyjne: RDF");
	
define("FORLAN_101", "Temat emaila");
define("FORLAN_102", "Drukuj podgl�d");
define("FORLAN_103", "[u�ytkownik usuni�ty]");
define('FORLAN_104', 'Tematu nie odnaleziono');
define("FORLAN_HIDDEN", "Wypowied� ukryta - zaloguj si� i odpowiedz w temacie, aby j� zobaczy�.");

?>
