<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/news_category.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/news_category.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Mo�esz podzieli� aktualno�ci pomi�dzy r�ne kategorie, a odwiedzaj�cym zezwoli� tylko na przegl�danie aktualno�ci ze wskazanych kategorii.<br /><br />Za�aduj ikony aktualno�ci do jednego z dw�ch katalog�w ".e_THEME."-yourtheme-/images/ lub themes/shared/newsicons/.";
$ns -> tablerender("Kategorie aktualno�ci", $text);

?>
