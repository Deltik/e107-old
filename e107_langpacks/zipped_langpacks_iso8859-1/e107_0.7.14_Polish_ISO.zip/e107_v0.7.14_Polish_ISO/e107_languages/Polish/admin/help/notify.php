<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/notify.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/notify.php rev. 1.2
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Powiadomienia email b�d� rozsy�ane, gdy na Twojej stronie zajdzie jakie� �ci�le okre�lone wydarzenie.<br /><br />
Na przyk�ad, ustawienie powiadomienia o <i>Adresach IP zablokowanych w wyniku atak�w typu flood</i> dla grupy <i>Adminstratorzy</i> spowoduje wys�anie emaili do wszystkich administrator�w, kiedy Twojej stronie b�dzie grozi�o zapchanie w wyniku ataku typu flood.<br /><br />
Mo�esz r�wnie�, jako inny przyk�ad, ustawi� powiadomienie o <i>Nowych pozycjach dodanych przez administrator�w</i> dla grupy <i>Zarejestrowani</i>, co spowoduje wys�anie emaili o nowo�ciach dodanych do serwisu do wszystkich u�ytkownik�w serwisu.<br /><br />
Je�li chcesz, aby powiadomienia email by�y wysy�ane na alternatywny adres email - zaznacz opcj� <i>Email</i> i wpisz w pole docelowy adres email.";

$ns -> tablerender("Powiadomienia", $text);

?>
