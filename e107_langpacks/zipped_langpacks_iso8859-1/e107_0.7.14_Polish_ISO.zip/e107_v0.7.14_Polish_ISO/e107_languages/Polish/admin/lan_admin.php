<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.14 $
|     $Date: 2008/08/27 11:05:17 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_admin.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_admin.php rev. 1.60
+-----------------------------------------------------------------------------+
*/

define("ADLAN_0", "Aktualno�ci");
define("ADLAN_1", "Dodawanie/edytowanie/usuwanie aktualno�ci");
//define("ADLAN_2", "Kategorie aktualno�ci");
//define("ADLAN_3", "Dodawanie/edytowanie/usuwanie kategorii aktualno�ci");
define("ADLAN_4", "Preferencje");
define("ADLAN_5", "Edytowanie ustawie� strony");
define("ADLAN_6", "Menu");
define("ADLAN_7", "Zmiana ustawie� wy�wietlanych menu");
define("ADLAN_8", "Administratorzy");
define("ADLAN_9", "Dodawanie/usuwanie administrator�w strony");
define("ADLAN_10", "Has�o administratora");
define("ADLAN_11", "Tutaj mo�esz zmieni� swoje has�o");
//define("ADLAN_12", "Forum");
//define("ADLAN_13", "Dodawanie/edytowanie forum");
//define("ADLAN_14", "Artyku�y");
//define("ADLAN_15", "Dodawanie nowych/edytowanie/usuwanie artyku��w");
//define("ADLAN_16", "Zawarto��");
//define("ADLAN_17", "Dodawanie nowej/edytowanie/usuwanie zawarto�ci stron");
//define("ADLAN_18", "Recenzje");
//define("ADLAN_19", "Dodawanie nowej/edytowanie/usuwanie recenzji");
//define("ADLAN_22", "Kategorie link�w");
//define("ADLAN_23", "Dodawanie/edytowanie/usuwanie kategorii link�w");
define("ADLAN_24", "Download");
define("ADLAN_25", "Zarz�dzanie plikami do pobrania");
//define("ADLAN_26", "Kategorie downloadu");
//define("ADLAN_27", "Dodawanie nowej/edytowanie/usuwanie kategorii plik�w do pobrania");
define("ADLAN_28", "Wiadomo�� powitalna");
define("ADLAN_29", "Ustawienia wiadomo�ci powitalnej");
define("ADLAN_30", "Mened�er plik�w");
define("ADLAN_31", "Zarz�dzanie plikami oraz �adowanie ich na serwer");
//define("ADLAN_32", "Otrzymane aktualno�ci");
//define("ADLAN_33", "Przegl�danie nades�anych wiadomo�ci od u�ytkownik�w");
define("ADLAN_34", "Lista blokowanych");
define("ADLAN_35", "Mo�esz tu blokowa� osoby odwiedzaj�ce Twoj� stron�");
define("ADLAN_36", "U�ytkownicy");
define("ADLAN_37", "Moderacja u�ytkownik�w");
define("ADLAN_38", "Grupy u�ytkownik�w");
define("ADLAN_39", "Tworzenie/edytowanie grup u�ytkownik�w");
define("ADLAN_40", "Konserwacja");
define("ADLAN_41", "Mo�esz tu wy��czy� serwis w celu konserwacji");
define("ADLAN_42", "W�asne menu/strony");
define("ADLAN_43", "Tworzenie w�asnych menu oraz stron serwisu");
define("ADLAN_44", "Baza danych");
define("ADLAN_45", "Narz�dzia bazy danych");
define("ADLAN_46", "Wyloguj");
define("ADLAN_47", "Witaj");
define("ADLAN_48", "Zalogowany");
define("ADLAN_49", "g��wny administrator strony");
//define("ADLAN_50", "uprawnienia");
define("ADLAN_51", "Prosz� si� zalogowa�, aby uzyska� dost�p do strefy administracyjnej");
define("ADLAN_52", "G��wna strona administratora");
define("ADLAN_53", "Wyjd�");
define("ADLAN_54", "Reklamy");
define("ADLAN_55", "Konfiguracja dzia�u reklamy");
//define("ADLAN_56", "Czat");
//define("ADLAN_57", "Konfiguracja czatu");
define("ADLAN_58", "Emotikony");
define("ADLAN_59", "Konfiguracja emotikon");
define("ADLAN_60", "Strona g��wna");
define("ADLAN_61", "Konfiguracja zawarto�ci pierwszej strony");
//define("ADLAN_62", "Wiadomo�ci zdalne");
//define("ADLAN_63", "Konfiguracja wiadomo�ci zdalnych");
//define("ADLAN_64", "Statystyki logowa�");
//define("ADLAN_65", "Statystyki logowa�/licznik etc");
define("ADLAN_66", "Znaczniki meta");
define("ADLAN_67", "Dodawanie/edytowanie znacznik�w meta strony");
define("ADLAN_68", "Informacje PHP");
define("ADLAN_69", "Zestawienie informacji o konfiguracji PHP");
//define("ADLAN_70", "Ankiety");
//define("ADLAN_71", "Dodawanie/edytowanie ankiet");
define("ADLAN_72", "Publiczny upload");
define("ADLAN_73", "Konfiguracja �adowania plik�w na serwer przez u�ytkownik�w");
define("ADLAN_74", "Pami�� podr�czna");
define("ADLAN_75", "Ustawiania statusu pami�ci podr�cznej");
//define("ADLAN_77", "Masz now� wiadomo�� - prosz� tutaj klikn��, aby j� sprawdzi�.");
define("ADLAN_78", "Dodatkowe pola user�w");
define("ADLAN_79", "Edycja dodatkowych p�l u�ytkownik�w");


//define("ADLAN_86", "Niepoprawne has�o ");
//define("ADLAN_87", "Nazwa administratora nie zosta�a znaleziona w bazie danych ");
//define("ADLAN_88", "Logowanie niemo�liwe ");
define("ADLAN_89", "Nazwa administratora ");
define("ADLAN_90", "Has�o administratora ");
define("ADLAN_91", "Zaloguj");
define("ADLAN_92", "Prosz� si� zalogowa�, aby przej�� do panelu administracyjnego ...");
define("ADLAN_93", "Poka� zadania administratora");
//define("ADLAN_94", "Poka� zainstalowane pluginy");
define("ADLAN_95", "Zarz�dzanie pluginami");
//define("ADLAN_96", "Brak");
//define("ADLAN_97", "Kliknij tutaj, aby przej�� do FAQ");
define("ADLAN_98", "Mened�er plugin�w");
define("ADLAN_99", "Instalacja/aktualizacja plugin�w etc");
//define("ADLAN_100", "Uk�ad tematu");
//define("ADLAN_101", "Kreator szablon�w");
define("ADLAN_102", "G��wne has�o administratora nie by�o zmieniane w przeci�gu ostatnich 30 dni - ");
define("ADLAN_103", "Kliknij tutaj, aby zmieni� je teraz");
define("ADLAN_104", "Ochrona");

define("ADLAN_105", "Obrazy");
define("ADLAN_106", "Ustawienia obraz�w");

//define("ADLAN_107", "Nieskontrolowane, nades�ane newsy");
//define("ADLAN_108", "Nieskontrolowane, za�adowane pliki");
//define("ADLAN_109", "Informacje");
define("ADLAN_110", "U�ytkownik�w");
define("ADLAN_111", "Konta bez weryfikacji");
define("ADLAN_112", "Zablokowane konta");
define("ADLAN_113", "Posty na forum");
define("ADLAN_114", "Komentarze");
define("ADLAN_115", "Posty na czacie");
define("ADLAN_116", "Logi administracyjne...");
define("ADLAN_117", "Poka� wszystkie wpisy");
define("ADLAN_118", "Wyczy�� logi");

define("ADLAN_119", "Nieskontrolowane, nades�ane linki");

define("ADLAN_120", "Dost�pna jest aktualizacja bazy danych. Prosz� klikn�� na przycisk, aby j� zainstalowa�...");
define("ADLAN_121", "Instaluj");


define("ADLAN_123", "Nieskontrolowane, nades�ane artyku�y");
define("ADLAN_124", "Nieskontrolowane, nades�ane recenzje");

define("ADLAN_125", "Nieskontrolowane raporty post�w na forum");

define("ADLAN_126", "G��wne opcje");
define("ADLAN_127", "U�ytkownicy");
define("ADLAN_128", "Zawarto��");
define("ADLAN_129", "Komunikacja");
define("ADLAN_130", "Zarz�dzanie plikami");
define("ADLAN_131", "Inne narz�dzia");

define("ADLAN_132", "Opcje j�zykowe");
define("ADLAN_133", "Konfiguracja domy�lnego j�zyka strony");

define("ADLAN_134", "Status");
define("ADLAN_135", "Logi administracyjne");

define("ADLAN_136", "Email");
define("ADLAN_137", "Ustawienia emaila oraz wysy�anie maili");

define("ADLAN_138", "Linki");
define("ADLAN_139", "Dodawanie/edytowanie/usuwanie link�w");

define("ADLAN_140", "Mened�er temat�w");
define("ADLAN_141", "Instalacja/ustawienia temat�w etc");

define("ADLAN_142", "Wyszukiwanie");
define("ADLAN_143", "Konfiguracja wyszukiwania");
define("ADLAN_144", "Aktualnie jeste� w prostym trybie wy�wietlania - prze��cz si� do trybu zaawansowanego");
define("ADLAN_145", "kliknij tutaj");

define("ADLAN_146", "Nieudane logowania");
define("ADLAN_147", "Inspektor plik�w");
define("ADLAN_148", "Skanowanie plik�w strony");

define("ADLAN_149", "Powiadomienia");
define("ADLAN_150", "System powiadomie� email o wydarzeniach w serwisie");

define("ADLAN_151", "Panel");
define("ADLAN_152", "Wpisz kod");
define("ADLAN_153", "Panel administratora");
define('ADLAN_154', "B��d w po��czeniu z Sourceforge. Nie mo�na sprawdzi� dost�pno�ci aktualizacji.");

define('ADLAN_CL_1', 'Ustawienia');
define('ADLAN_CL_2', 'U�ytkownicy');
define('ADLAN_CL_3', 'Zawarto��');
define('ADLAN_CL_4', 'Coms');
define('ADLAN_CL_5', 'Pliki');
define('ADLAN_CL_6', 'Narz�dzia');
define('ADLAN_CL_7', 'Pluginy');
define('ADLAN_CL_8', 'Pomoc');

define("ADLAN_LAT_1", "Ostatnie wydarzenia");

define("ADLAN_LAT_2", "Nades�ane newsy");
define("ADLAN_LAT_3", "Nades�ane artyku�y");
define("ADLAN_LAT_4", "Nades�ane recenzje");
define("ADLAN_LAT_5", "Nades�ane linki");
define("ADLAN_LAT_6", "Raporty na forum");
define("ADLAN_LAT_7", "Za�adowane pliki");
define("ADLAN_LAT_8", "Niesprawdzone wiadomo�ci");

define("ADLAN_ERR_1", "Ostrze�enie!");
define("ADLAN_ERR_2", "Na Twoim serwerze znajduj� si� pliki znane jako exploity. Musz� by� one <b>natychmiast</b> usuni�te. Pliki te s� zwi�zane z poprzedni� wersj� 0.6xx systemu e107. Prosz� usun�� nast�puj�ce katalogi oraz ca�� ich zawarto��:");
define("ADLAN_ERR_3", "W katalogach uploadu znajduje si� jeden lub wi�cej plik�w, kt�re nie wyst�puj� na wykazie dozwolonych typ�w plik�w do nadsy�ania. Wspomniane pliki mog�y by� umieszczone w katalogach przez osob� chc�c� zaatakowa� Twoj� stron� w zwi�zku z czym powinny one by� <b>natychmiast</b> usuni�te. <b>Nie</b> powiniene� otwiera� tych plik�w, jako �e mog� one wykona� jaki� z�o�liwy kod zawarty w nich. Nie otwieraj ich w Twojej przegl�darce internetowej.<br /><br />Je�li rozpoznajesz te pliki jako zaufane, to jest prawdopodobnie tak ze wzgl�du na ostanie zmiany dozwolonych typ�w plik�w, typ pliku, kt�ry dopu�ci�e� nie wyst�puje juz na wykazie dozwolonych typ�w plik�w i w zwi�zku z czym musisz ponownie go doda� do listy (zobacz Panel administracyjny => Publiczny upload). Nie powiniene� zezwoli� na nadsy�anie plik�w takich jak .html, .txt, etc jako �e osoba atakuj�ca mo�e nades�a� pliki tego typu z zawartym w nich niebezpiecznym kodem javascript. Powiniene� r�wnie�, je�li to mo�liwe, nie zezwoli� na nadsy�anie plik�w .php lub innego typu wykonywalnych skrypt�w.<br /><br />Poni�ej znajduje si� lista plik�w, kt�re potencjalnie mog� by� niebezpieczne:");
define("ADLAN_ERR_4", "Znaleziono pliki, kt�re wysz�y z u�ycia"); // 
define("ADLAN_ERR_5", "Dla nast�puj�cych plik�w musi zosta� zmieniona nazwa na");
define("ADLAN_ERR_6", "Nast�pnie kliknij tutaj, aby ponownie przeskanowa� swoje foldery plugin�w.");


// Common Terms
define("LAN_EDIT", "Edytuj");
define("LAN_DELETE", "Usu�");
define("LAN_CREATE", "Utw�rz");
define("LAN_UPDATE", "Aktualizacja");
define("LAN_SAVE", "Zapisz");
define("LAN_SAVED", "Zapisane");
define("LAN_SETSAVED", "Twoje ustawienia zosta�y zapisane");
define("LAN_CONFIRMDEL", "Prosz� potwierdzi� ch�� usuni�cia");
define("LAN_OPTIONS", "Opcje");
define("LAN_PREFS", "Preferencje");
define("LAN_DELETED", "Usuwanie zosta�o pomy�lnie uko�czone");
define("LAN_UPDATED", "Aktualizacja zosta�a pomy�lnie uko�czona");
define("LAN_CREATED", "Utworzono pomy�lnie");
define("LAN_CREATED_FAILED", "Tworzenie nieudane");
define("LAN_DELETED_FAILED", "Usuwanie nieudane");
define("LAN_UPDATED_FAILED", "Aktualizacja nieudana");
define("LAN_NO_CHANGE", "Aktualizacja nie powiod�a si�, poniewa� nie wprowadzono �adnych zmian.");
define("LAN_TRY_AGAIN", "Prosz� spr�bowa� ponownie.");

define("LAN_RESET", "Zresetuj");
define("LAN_CLEAR", "Wyczy��");
define("LAN_OK", "OK");

define("LAN_PRESET", "Wst�pne ustawienia");
define("LAN_PRESET_SAVED", "Wst�pne ustawienia zosta�y zapisane pomy�lnie");

define("LAN_PRESET_DELETED", "Wst�pne ustawienia zosta�y usuni�te pomy�lnie");
define("LAN_PRESET_CONFIRMDEL", "Czy jeste� pewien, �e chcesz usun�� wst�pne ustawienia?");
define("LAN_NOTWRITABLE", " jest niezapisywalny, musisz najpierw ustawi� CHMOD na warto�� 777 dla wskazanego pliku lub folderu.");
define("LAN_DATE", "Data");
define("LAN_TIME", "Czas");
define("LAN_YES", "Tak");
define("LAN_NO", "Nie");
define("LAN_EMPTY", "Nie ma jeszcze wpis�w w bazie danych");
define("LAN_EXISTING", "Istniej�ce wpisy");

define("LAN_CANCEL", "Anuluj");
define("LAN_CONFDELETE", "Potwierd� usuni�cie");
define("LAN_PLUGIN", "Plugin");
define("LAN_ORDER", "Kolejno��");

define("LAN_SELECT", "Wybierz...");
define("LAN_ADMIN", "Administrator");
define("LAN_DISPLAYOPT", "Edytuj opcje wy�wietlania");
define("LAN_GOPAGE", "Id� do strony:");
define("LAN_DATESTAMP", "Data");
define("LAN_OPTIONAL", "opcja");
define("LAN_INACTIVE", "Nieaktywny");

define("LAN_BAN", "Zablokuj");
define("LAN_RATING", "Ocena");

define("LAN_UPLOAD", "Upload");
define("LAN_UPLOAD_IMAGES", "Za�aduj obrazek");
define("LAN_UPLOAD_FILES", "Za�aduj plik");
define("LAN_UPLOAD_ADDFILE", "Dodaj kolejny plik");
define("LAN_UPLOAD_CONFIRM", "Wszystkie niezapisane zmiany wprowadzone na tej stronie zostan� utracone. Kontynuowa�?");
define("LAN_UPLOAD_777", "Wskazany katalog nie istnieje lub jest niezapisywalny, przed �adowanie musisz ustawi� uprawnienia plik�w (CHMOD) na warto�ci 777 dla nast�puj�cych folder�w:");
define("LAN_UPLOAD_SERVEROFF", "Ta opcja jest nieaktywna, jako �e �adowanie plik�w jest wy��czone na Twoim serwerze");

define("LAN_DISABLED", "Wy��czone");
define("LAN_ENABLED", "W��czone");

define("LAN_PRESET_CONFIRMSAVE", "Zapisa� bie��ce warto�ci formularza jako domy�lne dla tej strony?");
define("LAN_CONFIGURE", "Konfiguracja");

define("LAN_BACK", "Powr��");

define("LAN_CREDITS", "Podzi�kowania");
define("LAN_NEWVERSION", "Dost�pna jest nowa wersja");

?>
