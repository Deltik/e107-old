<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2008/08/27 11:05:17 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_cpage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_cpage.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("CUSLAN_1", "Nazwa");
define("CUSLAN_2", "Rodzaj");
define("CUSLAN_3", "Opcje");
define("CUSLAN_4", "Usun�� wybran� stron�?");
define("CUSLAN_5", "Aktualne strony oraz menu");
define("CUSLAN_7", "Nazwa menu");
define("CUSLAN_8", "Tytu�/nag��wek");
define("CUSLAN_9", "Tre��");
define("CUSLAN_10", "Pozw�l na ocen� tej strony");
define("CUSLAN_11", "Aktualne strony");
define("CUSLAN_12", "Utw�rz stron�");
define("CUSLAN_13", "Pozw�l na komentarze");
define("CUSLAN_14", "Zabezpiecz t� stron� has�em. ");
define("CUSLAN_15", "Wpisz has�o do zabezpieczenia tej strony.");
define("CUSLAN_16", "Utw�rz link w menu g��wnym. ");
define("CUSLAN_17", "Wpisz nazw� linku do utworzenia.");
define("CUSLAN_18", "Strona/link widoczny dla");
define("CUSLAN_19", "Aktualizuj stron�");
define("CUSLAN_20", "Utw�rz stron�");
define("CUSLAN_21", "Aktualizuj menu");
define("CUSLAN_22", "Utw�rz menu");
define("CUSLAN_23", "Edytuj stron�");
define("CUSLAN_24", "Utw�rz now� stron�");
define("CUSLAN_25", "Edytuj menu");
define("CUSLAN_26", "Utw�rz nowe menu");
define("CUSLAN_27", "Strona zosta�a zapisana do bazy danych.");
define("CUSLAN_28", "Strona zosta�a usuni�ta");
define("CUSLAN_29", "Lista stron, je�li �adna strona nie zosta�a wybrana");
define("CUSLAN_30", "Czas wyga�ni�cia ciasteczek (w sekundach)");
define("CUSLAN_31", "Utw�rz menu");
define("CUSLAN_32", "Konwertuj stare strony/menu");
define("CUSLAN_33", "Opcje strony");
define("CUSLAN_34", "Zacznij konwersj�");
define("CUSLAN_35", "Zako�czono aktualizacj� w�asnych stron - aktualizacja zako�czona powodzeniem");
define("CUSLAN_36", "Aby ustawi� w�asne preferencje dla ka�dej ze stron, prosz� wr�ci� do strony g��wnej i zredagowa� ka�d� ze stron.");
define("CUSLAN_37", "Zawarto�� strony zosta�a zaktualizowana");
define("CUSLAN_38", "W��czone");
define("CUSLAN_39", "Wy��czone");
define("CUSLAN_40", "Zapisz opcje");

define("CUSLAN_41", "Wy�wietl informacje o autorze oraz dat�");
define("CUSLAN_42", "Nie ma jeszcze zdefiniowanych stron");
define('CUSLAN_43', 'Niezatytu�owane menu: ');
define('CUSLAN_44', 'Niezatytu�owana strona');

?>
