<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_wmessage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_wmessage.php rev. 1.10
+-----------------------------------------------------------------------------+
*/
 
// define("WMGLAN_1", "Wiadomo�� dla go�ci");
// define("WMGLAN_2", "Wiadomos� dla u�ytkownik�w");
// define("WMGLAN_3", "Wiadomo�� dla administrator�w");
// define("WMGLAN_4", "Wy�lij");
// define("WMGLAN_5", "Ustaw wiadomo�� powitaln�");
// define("WMGLAN_6", "Aktywowa�?");
// define("WMGLAN_7", "Ustawienia wiadomo�ci powitalnej zaktualizowane.");

define("WMLAN_00","Wiadomo�ci powitalne");
define("WMLAN_01","Dodaj now� wiadomo��");
define("WMLAN_02","Wiadomo��");
define("WMLAN_03","Widoczno��");
define("WMLAN_04","Tre�� wiadomo�ci");

define("WMLAN_05","Otoczenie");
define("WMLAN_06","Je�li odznaczone, wiadomo�� b�dzie wy�wietlana wewn�trz tabelki");
define("WMLAN_07","Zast�p standardowy system, aby u�y� shortcode {WMESSAGE}:");
// define("WMLAN_08","Preferencje");

define("WMLAN_09","Nie ma jeszcze ustawionych wiadomo�ci powitalnych");
define("WMLAN_10","Nag��wek wiadomo�ci");

?>
