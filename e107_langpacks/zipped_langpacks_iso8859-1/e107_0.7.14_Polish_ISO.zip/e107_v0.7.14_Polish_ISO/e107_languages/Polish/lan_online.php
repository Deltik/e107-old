<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_online.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_online.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
//v.616
define("ONLINE_EL1", "Go�ci: ");
define("ONLINE_EL2", "U�ytkownik�w: ");
define("ONLINE_EL3", "Ma tej stronie: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "U�ytkownicy");
define("ONLINE_EL6", "Najnowszy");
define("ONLINE_EL7", "przegl�da");
define("ONLINE_EL8", "Najwi�cej online: ");
define("ONLINE_EL9", "dnia");
define("ONLINE_EL10", "Nazwa u�ytkownika");
define("ONLINE_EL11", "Przegl�dana strona");
define("ONLINE_EL12", "Odpowiada na");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Temat");
define("ONLINE_EL15", "Strona");
define("CLASSRESTRICTED", "Strona ograniczona dla grupy");
define("ARTICLEPAGE", "Artyku�/Recenzja");
define("CHAT", "Czat");
define("COMMENT", "Komentarze");
define("DOWNLOAD", "Download");
define("EMAIL", "Email");
define("FORUM", "Strona g��wna forum");
define("LINKS", "Linki");
define("NEWS", "Aktualno�ci");
define("OLDPOLLS", "Stare ankiety");
define("POLLCOMMENT", "Ankieta");
define("PRINTPAGE", "Drukuj");
define("LOGIN", "Zalogowany w");
define("SEARCH", "Przeszukuje");
define("STATS", "Statystyki strony");
define("SUBMITNEWS", "Wy�lij newsa");
define("UPLOAD", "Wy�lij plik");
define("USERPAGE", "Profil u�ytkownika");
define("USERSETTINGS", "Ustawienia u�ytkownika");
define("ONLINE", "U�ytkownicy online");
define("LISTNEW", "Lista aktualno�ci");
define("USERPOSTS", "Posty u�ytkownika");
define("SUBCONTENT", "Wy�lij artyku�/recenzj�");
define("TOP", "Najwi�cej napisali/Najch�tniej czytane tematy");
define("ADMINAREA", "Panel administracyjny");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Lista wydarze�");
define("CALENDAR", "Kalendarz wydarze�");
define("FAQ", "Faq");
define("PM", "Wiadomo�� prywatna");
define("SURVEY", "Ankieta");
define("ARTICLE", "Artyku�");
define("CONTENT", "Publikacje");
define("REVIEW", "Recenzja");

?>
