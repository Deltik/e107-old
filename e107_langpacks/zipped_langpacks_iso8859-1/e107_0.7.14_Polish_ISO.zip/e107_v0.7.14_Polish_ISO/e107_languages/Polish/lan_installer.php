<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.9 $
|     $Date: 2008/09/29 08:07:01 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_installer.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_installer.php rev. 1.24
+-----------------------------------------------------------------------------+
*/
 
define("LANINS_001", "Instalacja e107");

define("LANINS_002", "Etap ");
define("LANINS_003", "1");
define("LANINS_004", "Wyb�r j�zyka");
define("LANINS_005", "Prosz� wybra� j�zyk, kt�ry b�dzie u�ywany w dalszym procesie instalacji");
define("LANINS_006", "Ustaw j�zyk");
define("LANINS_007", "4");
define("LANINS_008", "Sprawdzenie wersji PHP, MySQL oraz uprawnie� plik�w");
define("LANINS_009", "Pon�w test uprawnie� plik�w");
define("LANINS_010", "Plik niezapisywalny: ");
define("LANINS_010a", "Folder niezapisywalny: ");
define("LANINS_011", "B��d");
define("LANINS_012", "Prawdopodobnie serwer hostuj�cy nie obs�uguje funkcji MySQL. Mo�liwe, �e rozszerzenie MySQL PHP nie jest zainstalowane lub Twoja instalacja PHP nie zosta�a skompilowane ze wsparciem dla MySQL."); // pomoc dla 012
define("LANINS_013", "Nie mog� ustali� wersji MySQL. To nie jest b��d krytyczny, wi�c prosz� kontynuowa� instalacj�, ale prosz� by� �wiadomym tego, �e system e107 wymaga MySQL w wersji 3.23 lub nowszej, aby funkcjonowa� poprawnie.");
define("LANINS_014", "Uprawnienia plik�w");
define("LANINS_015", "Wersja PHP");
define("LANINS_016", "MySQL");
define("LANINS_017", "OK");
define("LANINS_018", "Upewnij si�, �e na pliki i foldery wskazane powy�ej nada�e� odpowiednie uprawnienia. Atrybuty powinny by� ustawione na warto�� 777. <br />Aby zmieni� uprawnienia plik�w, przejd� do okna klienta FTP, a nast�pnie kliknij prawym przyciskiem myszy na pliku i wybierz CHMOD (<i>Set File Permissions</i>), po czym wpisz tam warto�� 777. Je�eli natomiast wy�wietli si� okno dialogowe z polami do wyboru, to zaznacz wszystkie opcje i potwierd� sw�j wyb�r.<br /><br />Po zmianie uprawnie� kontynuuj instalacj� skryptu, lecz je�li napotkasz na jakie� utrudnienia skontaktuj si� ze swoim administratorem serwera.");
define("LANINS_019", "Wersja PHP zainstalowana na serwerze hostuj�cym nie nadaje si� do uruchamiania skryptu e107. System e107 do poprawnego dzia�ania wymaga PHP od wersji 4.3.0 wzwy�. Zaktualizuj wersj� PHP lub skontaktuj si� z us�ugodawc�, aby go poinformowa�, �e do poprawnego dzia�ania Twojego serwisu wymagana jest nowsza wersja PHP.");
define("LANINS_020", "Zacznij instalacj�");
define("LANINS_021", "2");
define("LANINS_022", "Konfiguracja po��czenia z serwerem MySQL");
define("LANINS_023", "Poni�ej prosz� wpisa� dane niezb�dne do poprawnego po��czenia z baz� danych MySQL.

Je�li masz na serwerze uprawnienia <i>root</i> (g��wnego administratora) lub masz nadane uprawnienia do tworzenia baz danych, mo�esz zaznaczy� pole utworzenia nowej bazy. Je�li nie masz wspomnianych uprawnie�, musisz utworzy� baz� danych w jaki� inny spos�b lub pos�u�y� si� ju� istniej�c� baz�.

Je�li masz tylko jedn� baz� danych u�yj prefiksu, dzi�ki kt�remu inne skrypty b�d� mog�y korzysta� z tej samej bazy.

Je�li nie znasz dok�adnych danych niezb�dnych do po��czenia z Twoim kontem MySQL, skontaktuj si� z administratorem serwera, na kt�rym hostowana b�dzie strona.");
define("LANINS_024", "Host MySQL:");
define("LANINS_025", "U�ytkownik:");
define("LANINS_026", "Has�o:");
define("LANINS_027", "Baza danych:");
define("LANINS_028", "Utw�rz now� baz�");
define("LANINS_029", "Prefiks:");
define("LANINS_030", "Adres serwera MySQL (najcz�ciej localhost), na kt�rym chcesz zainstalowa� system e107. Adres mo�e zawiera� numer portu, np. \"nazwahosta:port\", lub �cie�k� do lokalnych zasob�w serwera, np. \":/�cie�ka/do/zasob�w\".");
define("LANINS_031", "Wpisz nazw� u�ytkownika, kt�r� system e107 b�dzie u�ywa� do ��czenia si� z serwerem MySQL");
define("LANINS_032", "Wpisz has�o u�ytkownika MySQL");
define("LANINS_033", "Wpisz nazw� baza danych MySQL, kt�r� wybra�e� do instalacji skryptu e107. Je�li jeszcze jej nie utworzy�e�, a posiadasz odpowiednie uprawnienia, wpisz sugerowan� nazw� i zaznacz pole obok - baza danych zostanie utworzona automatycznie.");
define("LANINS_034", "Prefiks (przedrostek) do tabel zawartych w bazie danych systemu e107. Jest przydatny, je�eli instalujesz wi�cej ni� jeden skrypt w tej samej bazie.");
define("LANINS_035", "Dalej");
define("LANINS_036", "3");
define("LANINS_037", "Weryfikacja po��czenia z MySQL");
define("LANINS_038", " i tworzenie bazy danych");
define("LANINS_039", "Prosz� upewni� si�, �e wszystkie najwa�niejsze pola zosta�y wype�nione - Host MySQL, u�ytkownik i baza danych s� zawsze wymagane do uzyskania po��czenia z serwerem MySQL)");
define("LANINS_040", "B��d");
define("LANINS_041", "System e107 nie m�g� nawi�za� po��czenia z serwerem MySQL u�ywaj�c podanych informacji. Wr�� do poprzedniej strony i upewnij si�, �e wpisane dane s� poprawne.");
define("LANINS_042", "Po��czenie z serwerem MySQL nawi�zane i sprawdzone.");
define("LANINS_043", "Nie mog� utworzy� bazy danych. Prosz� upewni� si�, �e masz poprawne uprawnienia do tworzenia bazy danych na wskazanym serwerze.");
define("LANINS_044", "Baza danych utworzona pomy�lnie.");
define("LANINS_045", "Prosz� klikn�� na przycisk, aby przej�� do nast�pnego etapu.");
define("LANINS_046", "5");
define("LANINS_047", "Specyfikacja administratora");
define("LANINS_048", "Wr�� do poprzedniego etapu");
define("LANINS_049", "Wpisane has�a nie s� identyczne. Prosz� wr�ci� i spr�bowa� ponownie.");
define("LANINS_050", "Rozszerzenie XML");
define("LANINS_051", "Zainstalowane");
define("LANINS_052", "Niezainstalowane");
define("LANINS_053", "e107 0.7.x wymaga zainstalowanego rozszerzenia PHP XML. Prosz� skontaktowa� si� z administratorem hosta lub przeczyta� wi�cej informacji ");
define("LANINS_054", " przed kontynuacj�");
define("LANINS_055", "Potwierdzenie instalacji");
define("LANINS_056", "6");
define("LANINS_057", " e107 ma teraz wszystkie informacje, kt�re s� konieczne do uko�czenia instalacji.

Prosz� klikn�� na przycisk, aby utworzy� tabele bazy danych i zapisa� wszystkie ustawienia.

");
define("LANINS_058", "7");
define("LANINS_060", "Nie mo�na odczyta� pliku z danymi sql

Prosz� upewni� si�, �e plik <b>core_sql.php</b> znajduje si� w folderze <b>/e107_admin/sql</b>.");
define("LANINS_061", "e107 nie m�g� utworzy� wszystkich wymaganych tabel bazy danych.
Prosz� wyczy�ci� baz� danych i rozwi�za� wszystkie problemy przed ponown� pr�b�.");
define("LANINS_062", "[b]Witaj na swojej nowej stronie internetowej![/b]
System e107 zosta� pomy�lnie zainstalowany i jest gotowy do aktualizacji zawarto�ci strony.<br />Twoja sekcja administracyjna (panel administratora) jest dost�pna [link=e107_admin/admin.php]pod tym linkiem[/link] - kliknij, aby teraz tam przej��. Do logowania u�yj loginu i has�a administratora, kt�re wpisa�e� podczas procesu instalacji.

[b]Wsparcie[/b]
Oficjalna strona e107: [link=http://e107.org]http://e107.org[/link], znajdziesz tutaj FAQ najcz�ciej zadawane pytania) oraz dokumentacj�.
Forum: [link=http://e107.org/e107_plugins/forum/forum.php]http://e107.org/e107_plugins/forum/forum.php[/link]
Spo�eczno� dewelepoer�w wtyczek: [link=http://www.e107coders.org]http://e107coders.org[/link]

[b]Strony polskiego wsparcia[/b]
Serwis e107.org.pl: [link=http://e107.org.pl]http://e107.org.pl[/link] - strona grupy [i]e107pl Dev Team[/i] - newsy, download, forum, dokumentacja e107 itp.
Serwis e107poland.org: [link=http://e107poland.org]http://e107poland.org[/link] - motywy, download, forum i inne.

[b]Download[/b]
Wtyczki: [link=http://plugins.e107.org]http://plugins.e107.org[/link]
Motywy: [link=http://themes.e107.org]http://themes.e107.org[/link]

Dzi�kujemy za korzystanie z e107, mamy nadziej�, �e spe�ni on Twoje potrzeby i b�dziesz zadowolony z jego u�ytkowania.
(Mo�esz usun�� tego newsa za pomoc� panelu administracyjnego.)");

define("LANINS_063", "Witaj w e107");
define("LANINS_069", "e107 zosta� pomy�lnie zainstalowany!

Ze wzgl�du na bezpiecze�stwo przywr�� uprawnienia pliku <b>e107_config.php</b> do warto�ci 644 (CHMOD 644).

Prosz� r�wnie�, po klikni�ciu na poni�szy przycisk, usun�� z serwera plik <i>install.php</i>
");
define("LANINS_070", "e107 nie m�g� zapisa� g��wnego pliku konfiguracyjnego na obecnym serwerze.

Prosz� upewni� si�, �e plik <b>e107_config.php</b> posiada prawid�owe uprawnienia");
define("LANINS_071", "Finalizacja instalacji");

define("LANINS_072", "Login");
define("LANINS_073", "Login administratora, pos�u�y Ci do logowania si� na stron� oraz sekcji Panel administratora. Je�li chcesz mo�esz go r�wnie� u�ywa� jako nazwy administratora.");
define("LANINS_074", "Wy�wietlana nazwa");
define("LANINS_075", "To nazwa, pod kt�r� b�dziesz widoczny na forum, czacie, w komentarzach itp. B�dzie ona r�wnie� wy�wietlana w Twoim profilu. Pozostaw to pole puste, je�li jako nazwy administratora chcesz u�ywa� loginu.");
define("LANINS_076", "Has�o");
define("LANINS_077", "Prosz� wpisa� has�o administratora, kt�rym b�dziesz si� pos�ugiwa� podczas logowania w serwisie.");
define("LANINS_078", "Potwierd�");
define("LANINS_079", "Prosz� powt�rzy� has�o administratora.");
define("LANINS_080", "Email");
define("LANINS_081", "Wpisz sw�j adres email.");

define("LANINS_082", "nazwa@twojastrona.pl");

// Lepsze zg�aszanie listy tworzonych b��d�w
define("LANINS_083", "Zg�oszenie b��du MySQL:");
define("LANINS_084", "Instalator nie m�g� nawi�za� po��czenia z baz� danych");
define("LANINS_085", "Instalator nie m�g� wybra� bazy danych:");

define("LANINS_086", "Pola - nazwa administratora, has�o administratora oraz adres email administratora - s� <b>wymagane</b>. Prosz� powr�ci� do ostatniej strony i upewni� si�, �e informacje zosta�y poprawnie wprowadzone.");

define("LANINS_087", "R�ne");
define("LANINS_088", "Strona g��wna");
define("LANINS_089", "Download");
define("LANINS_090", "U�ytkownicy");
define("LANINS_091", "Dodaj newsa");
define("LANINS_092", "Kontakt");
define("LANINS_093", "Nadaje dost�p do prywatnych menu");
define("LANINS_094", "Przyk�adowa grupa u�ytkownik�w forum prywatnego");
define("LANINS_095", "Sprawdzanie integralno�ci");

define("LANINS_096", 'Ostatnie komentarze');
define("LANINS_097", '[wi�cej ...]');
define("LANINS_098", 'Artyku�y');
define("LANINS_099", 'Strona startowa artyku��w ...');
define("LANINS_100", 'Ostatnie posty na forum');
define("LANINS_101", 'Zapisz ustawienia menu');
define("LANINS_102", 'Data / Czas');
define("LANINS_103", 'Odwiedzin');
define("LANINS_104", 'Odwied� stron� startow� ...');

define("LANINS_105", 'Rozpoczynanie nazwy bazy danych lub prefiksu cyfr�, a nast�pnie liter� \'e\' lub \'E\' jest zabronione');
define("LANINS_106", 'OSTRZE�ENIE - E107 nie mo�e zapisywa� do katalog�w i/lub wylistowa� plik�w. Jeli to nie zatrzyma instalacji e107, b�dzie to oznacza�o, �e niekt�re funkcjonalnoci s� niedost�pne. 
				Musisz zmieni� uprawnienia plik�w w celu u�ycia tej funkcjonalnoci');
define("LANINS_107", '');
define("LANINS_108", '');

?>