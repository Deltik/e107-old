<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| �Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+---------------------------------------------------------------+
*/

define("BLOGCAL_L1", "News del ");
define("BLOGCAL_L2", "Archivio");
	
define("BLOGCAL_D1", "Lu");
define("BLOGCAL_D2", "Ma");
define("BLOGCAL_D3", "Me");
define("BLOGCAL_D4", "Gi");
define("BLOGCAL_D5", "Ve");
define("BLOGCAL_D6", "Sa");
define("BLOGCAL_D7", "Do");
	
define("BLOGCAL_M1", "Gennaio");
define("BLOGCAL_M2", "Febbraio");
define("BLOGCAL_M3", "Marzo");
define("BLOGCAL_M4", "Aprile");
define("BLOGCAL_M5", "Maggio");
define("BLOGCAL_M6", "Giugno");
define("BLOGCAL_M7", "Luglio");
define("BLOGCAL_M8", "Agosto");
define("BLOGCAL_M9", "Settembre");
define("BLOGCAL_M10", "Ottobre");
define("BLOGCAL_M11", "Novembre");
define("BLOGCAL_M12", "Dicembre");
	
define("BLOGCAL_1", "News");
	
define("BLOGCAL_CONF1", "Mesi/riga");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF3", "Aggiorna Impostazioni Men�");
define("BLOGCAL_CONF4", "Configurazione Men� BlogCal");
define("BLOGCAL_CONF5", "Configurazione Men� BlogCal salvata");
	
define("BLOGCAL_ARCHIV1", "Seleziona Archivio");
	
?>
