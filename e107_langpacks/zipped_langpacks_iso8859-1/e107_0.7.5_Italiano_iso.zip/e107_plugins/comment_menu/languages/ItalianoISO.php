<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| �Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
|     Italian Translation: e107 Italian Team http://www.e107it.org
+---------------------------------------------------------------+
*/
define("CM_L1", "Ancora nessun commento.");
define("CM_L2", "");
define("CM_L3", "Titolo");
define("CM_L4", "Numero di commenti da visualizzare");
define("CM_L5", "Numero di caratteri da visualizzare");
define("CM_L6", "Suffisso per commenti troppo lunghi");
define("CM_L7", "Mostrare il titolo originale della news nel men�?");
define("CM_L8", "Configurazione men� nuovi commenti");
define("CM_L9", "Aggiorna");
define("CM_L10", "Configurazione blocco commenti salvata");
	
?>
