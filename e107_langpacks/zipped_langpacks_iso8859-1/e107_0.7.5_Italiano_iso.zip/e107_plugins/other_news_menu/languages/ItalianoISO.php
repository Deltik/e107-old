<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/other_news_menu/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:53:12 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/

define("TD_MENU_L1", "Altre News");
	
?>