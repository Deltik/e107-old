<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/English/English_config.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/06 01:06:09 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/

define("CHBLAN_1", "Impostazioni Chatbox aggiornate.");
define("CHBLAN_2", "Moderata.");
define("CHBLAN_3", "Nessun Messaggio presente.");
define("CHBLAN_4", "Utente");
define("CHBLAN_5", "Ospite");
define("CHBLAN_6", "Sblocca");
define("CHBLAN_7", "Blocca");
define("CHBLAN_8", "Cancella");
define("CHBLAN_9", "Modera Chatbox");
define("CHBLAN_10", "Modera posts");
define("CHBLAN_11", "Messaggi Chatbox da mostrare");
define("CHBLAN_12", "Totale messaggi visualizzati nella chatbox");
define("CHBLAN_13", "Sostituisci links");
define("CHBLAN_14", "Se selezionato, i links presenti nei messaggi verranno sostituiti dal testo inserito nel campo sottostante");
define("CHBLAN_15", "Sostituisci stringa se attivato");
define("CHBLAN_16", "I links verranno sostituiti da questa stringa");
define("CHBLAN_17", "Avvolgimento automatico");
define("CHBLAN_18", "le parole pi� lunghe del n. di caratteri impostato verranno abbreviate");
define("CHBLAN_19", "Aggiorna Impostazioni Chatbox");
define("CHBLAN_20", "Impostazioni Chatbox");
define("CHBLAN_21", "Pulizia");
define("CHBLAN_22", "Cancella i messaggi precedenti ad un certo periodo di tempo");
define("CHBLAN_23", "Cancella i messaggi precedenti a ");

define("CHBLAN_24", "Un giorno");
define("CHBLAN_25", "Una settimana");
define("CHBLAN_26", "Un mese");
define("CHBLAN_27", "- Cancella tutti i messaggi -");
define("CHBLAN_28", "Pulizia Chatbox eseguita.");

define("CHBLAN_29", "Mostra i messaggi chatbox in un pannello scorrevole");
define("CHBLAN_30", "Altezza pannello");
define("CHBLAN_31", "Mostra faccine");
define("CHBLAN_32", "Moderatore");

define("CHBLAN_33", "N. messaggi Utenti ricalcolati");
define("CHBLAN_34", "Ricalcola n. messaggi Utenti");
define("CHBLAN_35", "Ricalcola");

define("CHBLAN_36", "Opzioni Visualizzazione Chatbox");
define("CHBLAN_37", "Normale");
define("CHBLAN_38", "Usa javascript per aggiornare i messaggi dinamicamente (AJAX)");

?>
