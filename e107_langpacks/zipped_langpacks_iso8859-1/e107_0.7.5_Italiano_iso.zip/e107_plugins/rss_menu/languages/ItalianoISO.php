<?php
/*+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/rss_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/10/13 18:55:26 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " possono essere distribuite con sistema RSS.");
define("BACKEND_MENU_L2", "Feed RSS");
define("BACKEND_MENU_L3", "Le news");
define("BACKEND_MENU_L4", "I commenti");
define("BACKEND_MENU_L5", "Le discussioni del Forum");
define("BACKEND_MENU_L6", "I messaggi del Forum");
define("BACKEND_MENU_L7", "I messaggi Chatbox");
define("BACKEND_MENU_L8", "I report bugtracker");
define("BACKEND_MENU_L9", "I downloads");
define("RSS_LAN01", "Abilita feeds separati per ciascuna categoria news?");
define("RSS_LAN02", "Abilita feeds separati per ciascuna categoria download?");
define("RSS_NEWS","News");
define("RSS_COM","Commenti");
define("RSS_ART","Articoli");
define("RSS_REV", "Recensioni");
define("RSS_FT","Discussioni del Forum");
define("RSS_FP","Messaggi del Forum");
define("RSS_FSP","Messaggio specifico del Forum");
define("RSS_BUG","Bugtracker");
define("RSS_FOR","Forum");
define("RSS_DL","Downloads");
?>