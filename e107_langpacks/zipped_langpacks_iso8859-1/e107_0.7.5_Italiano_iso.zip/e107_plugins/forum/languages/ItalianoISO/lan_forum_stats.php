<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/25 11:38:50 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Statistiche Forum");

define("FSLAN_1", "Generale");
define("FSLAN_2", "Forum aperto il");
define("FSLAN_3", "Aperto da");
define("FSLAN_4", "Messaggi totali");
define("FSLAN_5", "Argomenti");
define("FSLAN_6", "Risposte");
define("FSLAN_7", "Discussioni");
define("FSLAN_8", "Dimensioni database (solo tabelle forum)");
define("FSLAN_9", "Media lunghezza righe nella tabella del forum");
define("FSLAN_10", "Discussioni pi� attive");
define("FSLAN_11", "Livello");
define("FSLAN_12", "Argomento");
define("FSLAN_13", "Risposte");
define("FSLAN_14", "Aperto da");
define("FSLAN_15", "Data");
define("FSLAN_16", "Discussioni pi� viste");
define("FSLAN_17", "Viste");
define("FSLAN_18", "Utenti pi� attivi");
define("FSLAN_19", "Nome");
define("FSLAN_20", "Messaggi");
define("FSLAN_21", "Utenti che hanno iniziato pi� discussioni");
define("FSLAN_22", "Utenti con maggior numero di risposte");
define("FSLAN_23", "Statistiche forum");
define("FSLAN_24", "Media di messaggi per giorno");
?>
