<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/24 20:43:34 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','File caricati nel forum');
define('FRMUP_2','File eliminato');
define('FRMUP_3','Errore: impossibile eliminare il file');
define('FRMUP_4','Cancellazione file');
define('FRMUP_5','Nome file');
define('FRMUP_6','Risultato');
define('FRMUP_7','Trovato nella discussione');
define('FRMUP_8','NON TROVATO');
define('FRMUP_9','Nessun file caricato trovato');
define('FRMUP_10','Elimina');
	
?>
