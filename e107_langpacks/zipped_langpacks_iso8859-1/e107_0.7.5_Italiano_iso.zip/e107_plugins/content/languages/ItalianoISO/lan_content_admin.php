<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content_admin.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/01/04 19:53:42 $
|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/

define("CONTENT_PLUGIN_LAN_1", "Gestione Contenuti");
define("CONTENT_PLUGIN_LAN_2", "Una sezione completa per la gestione dei contenuti.");
define("CONTENT_PLUGIN_LAN_3", "Configura gestione contentui");
define("CONTENT_PLUGIN_LAN_4", "Questo plugin � ora pronto per essere usato.");
define("CONTENT_PLUGIN_LAN_5", "Contenuti");
define("CONTENT_PLUGIN_LAN_6", "Struttura Tabelle Plugin Gestione Contenuti Aggiornate");

define("CONTENT_ADMIN_CAT_LAN_0", "Crea categoria");
define("CONTENT_ADMIN_CAT_LAN_1", "Modifica categoria");
define("CONTENT_ADMIN_CAT_LAN_2", "Intestazione");
define("CONTENT_ADMIN_CAT_LAN_3", "Sotto-intestazione");
define("CONTENT_ADMIN_CAT_LAN_4", "Testo");
define("CONTENT_ADMIN_CAT_LAN_5", "Icone");
define("CONTENT_ADMIN_CAT_LAN_6", "Invia");
define("CONTENT_ADMIN_CAT_LAN_7", "Aggiorna");
define("CONTENT_ADMIN_CAT_LAN_8", "Vedi icone");
define("CONTENT_ADMIN_CAT_LAN_9", "Ancora nessuna categoria");
define("CONTENT_ADMIN_CAT_LAN_10", "Categorie contenuti");
define("CONTENT_ADMIN_CAT_LAN_11", "Categoria creata");
define("CONTENT_ADMIN_CAT_LAN_12", "Categoria aggiornata");
define("CONTENT_ADMIN_CAT_LAN_13", "Campo/i richiesto/i non compilati");
define("CONTENT_ADMIN_CAT_LAN_14", "Commenti");
define("CONTENT_ADMIN_CAT_LAN_15", "Valutazione");
define("CONTENT_ADMIN_CAT_LAN_16", "Icone stampa/email");
define("CONTENT_ADMIN_CAT_LAN_17", "Visibilit�");
define("CONTENT_ADMIN_CAT_LAN_18", "Autore");
define("CONTENT_ADMIN_CAT_LAN_19", "Categoria");
define("CONTENT_ADMIN_CAT_LAN_20", "Opzioni");
define("CONTENT_ADMIN_CAT_LAN_21", "Pulisci modulo");
define("CONTENT_ADMIN_CAT_LAN_22", "Opzioni aggiornate");
define("CONTENT_ADMIN_CAT_LAN_23", "Categoria eliminata");
define("CONTENT_ADMIN_CAT_LAN_24", "ID");
define("CONTENT_ADMIN_CAT_LAN_25", "Icone");
define("CONTENT_ADMIN_CAT_LAN_26", "Nuova categoria principale");
define("CONTENT_ADMIN_CAT_LAN_27", "Categoria");
define("CONTENT_ADMIN_CAT_LAN_28", "Assegna un utente dalla finestra di sinistra ala Gestione Contenuti Personali per questa categoria");
define("CONTENT_ADMIN_CAT_LAN_29", "Amministratori - premi per muovere ... ");
define("CONTENT_ADMIN_CAT_LAN_30", "Gestione Contenuti Personali");
define("CONTENT_ADMIN_CAT_LAN_31", "Rimuovi");
define("CONTENT_ADMIN_CAT_LAN_32", "Pulisci Gestione");
define("CONTENT_ADMIN_CAT_LAN_33", "Assegna Gestione Contenuti Personale");
define("CONTENT_ADMIN_CAT_LAN_34", "Amminsistratori assegnati con successo alla categoria");
define("CONTENT_ADMIN_CAT_LAN_35", "Sotto categoria eliminata");
define("CONTENT_ADMIN_CAT_LAN_36", "Analisi: ci sono ancora sotto-caregorie presenti, la categoria NON sar� eliminata. Prima rimuovi tutte le categorie quindi riprova.");
define("CONTENT_ADMIN_CAT_LAN_37", "Analisi: ci sono ancora contenuti presenti, la categoria NON sar� eliminata. Prima rimuovi tutti i contenuti, quindi riprova.");
define("CONTENT_ADMIN_CAT_LAN_38", "Analisi: nessun contenuto trovato");
define("CONTENT_ADMIN_CAT_LAN_39", "Analisi: nessuna sotto-categoria trovata");
define("CONTENT_ADMIN_CAT_LAN_40", "Sotto puoi vedere la lista delle categorie principali e di tutte le sotto-categorie se presenti.<br />");

define("CONTENT_ADMIN_CAT_LAN_41", "La gestione Personalizzata delle Categorie permette di assegnare altri amministratori alle categorie stesse. Con questi privilegi possono essi stessi gestire in piena autonomia le categorie, senza il bisogno di avere il completo controllo amministrativo del Plugin. Dalla normale pagina dei contenuti fuori dall'area di amministrazione essi possono vedere una icona che li reindirizza ai contenuti personalizzati.");
define("CONTENT_ADMIN_CAT_LAN_42", "pre ri-modificare la stessa categoria");

define("CONTENT_ADMIN_CAT_LAN_43", "Premi qui");
define("CONTENT_ADMIN_CAT_LAN_44", "Per aggiungere una nuova categoria in modo pi� veloce");
define("CONTENT_ADMIN_CAT_LAN_45", "Permetti commenti?");
define("CONTENT_ADMIN_CAT_LAN_46", "Permetti valutazioni?");
define("CONTENT_ADMIN_CAT_LAN_47", "Visualizzi icone per stampa/email?");
define("CONTENT_ADMIN_CAT_LAN_48", "Scegli quali utenti vedranno questo contenuto");
define("CONTENT_ADMIN_CAT_LAN_49", "Scegli un'icona per questa categoria");
//define("CONTENT_ADMIN_CAT_LAN_50", "Blocco Menu contenuti creato<br /><br />Perch� hai creato un Categoria Principale un a Blocco Menu � stato generato.<br />Il File del Blocco menu � stato creato nella cartella /menus.<br /><br />Per vedere il blocco menu funzionante attivalo in amminsitrazione: <a href='".e_ADMIN."menus.php'>Menu Blocchi</a>.");
define("CONTENT_ADMIN_CAT_LAN_50", "
Solo se hai creato una nuova Categoria Principale (Parent), un blocco men� sar� creato.<br />
Questo blocco men� sar� creato nella tua cartella /menus.<br />
Per vedere il blocco men� funzionante attivalo in amministrazione: <a href='".e_ADMIN."menus.php'>Men� Blocchi</a>.<br /><br />
");
define("CONTENT_ADMIN_CAT_LAN_51", "Errore; blocco non creato");
define("CONTENT_ADMIN_CAT_LAN_52", "Scegli SEMPRE una categoria prima di compilare altri campi!");
define("CONTENT_ADMIN_CAT_LAN_53", "Gestire un'altra categoria");
define("CONTENT_ADMIN_CAT_LAN_54", "Utente");
define("CONTENT_ADMIN_CAT_LAN_55", "Utenti");
define("CONTENT_ADMIN_CAT_LAN_56", "Oggetto");
define("CONTENT_ADMIN_CAT_LAN_57", "Oggetti");
define("CONTENT_ADMIN_CAT_LAN_58", "Icona categoria caricata con successo<br />
Notizia: devi ancora assegnare l'icona nella area della scelta icone!<br />
e naturalmente dopo aver fatto questo devi ancora salvare il modulo per creare/aggiornare questa categoria");
define("CONTENT_ADMIN_CAT_LAN_59", "Icona categoria non caricata");
define("CONTENT_ADMIN_CAT_LAN_60", "Assegna un'icona");
define("CONTENT_ADMIN_CAT_LAN_61", "Carica una nuova icona");
define("CONTENT_ADMIN_CAT_LAN_62", "Dopo aver caricato una nuova icona delle categorie, puoi assegnare quest'icona nell'area icone sottostante<br />
Se carichi una nuova icona, questa icona verr� ridimensionata a 48 pixels, e addizionalmente una icona a 16 pixels verr� creata<br /><br />");
define("CONTENT_ADMIN_CAT_LAN_63", "Carica icona");



define("CONTENT_ADMIN_ITEM_LAN_0", "Campo/i richiesti non compilati");
define("CONTENT_ADMIN_ITEM_LAN_1", "Contenuto creato");
define("CONTENT_ADMIN_ITEM_LAN_2", "Contenuto aggiornato");
define("CONTENT_ADMIN_ITEM_LAN_3", "Contenuto eliminato");
define("CONTENT_ADMIN_ITEM_LAN_4", "Ancora nessun contenuto");
define("CONTENT_ADMIN_ITEM_LAN_5", "Contenuto esistente");
define("CONTENT_ADMIN_ITEM_LAN_6", "Prima lettera");
define("CONTENT_ADMIN_ITEM_LAN_7", "Seleziona una lettera sotto.");
define("CONTENT_ADMIN_ITEM_LAN_8", "ID");
define("CONTENT_ADMIN_ITEM_LAN_9", "Icona");
define("CONTENT_ADMIN_ITEM_LAN_10", "Autore");
define("CONTENT_ADMIN_ITEM_LAN_11", "Intestazione");
define("CONTENT_ADMIN_ITEM_LAN_12", "Opzioni");
define("CONTENT_ADMIN_ITEM_LAN_13", "Scegli la categoria principale (parent)");
define("CONTENT_ADMIN_ITEM_LAN_14", "Nome");
define("CONTENT_ADMIN_ITEM_LAN_15", "email");
define("CONTENT_ADMIN_ITEM_LAN_16", "Sottointestazione");
define("CONTENT_ADMIN_ITEM_LAN_17", "Sommario");
define("CONTENT_ADMIN_ITEM_LAN_18", "Testo");
define("CONTENT_ADMIN_ITEM_LAN_19", "Carica icona");
define("CONTENT_ADMIN_ITEM_LAN_20", "Icona");
define("CONTENT_ADMIN_ITEM_LAN_21", "Opzione disabilitata controlla che il caricamento file sia abilitato sul tuo server");
define("CONTENT_ADMIN_ITEM_LAN_22", "La");
define("CONTENT_ADMIN_ITEM_LAN_23", "cartella non � scrivibile, assegna CHMOD 777 prima di caricare i files");
define("CONTENT_ADMIN_ITEM_LAN_24", "Allegati");
define("CONTENT_ADMIN_ITEM_LAN_25", "Carica nuova icona");
define("CONTENT_ADMIN_ITEM_LAN_26", "Rimuovi");
define("CONTENT_ADMIN_ITEM_LAN_27", "File presenti");
define("CONTENT_ADMIN_ITEM_LAN_28", "Carica nuovo file");
define("CONTENT_ADMIN_ITEM_LAN_29", "Ancora nessun file");
define("CONTENT_ADMIN_ITEM_LAN_30", "File di contenuto");
define("CONTENT_ADMIN_ITEM_LAN_31", "Immagini");
define("CONTENT_ADMIN_ITEM_LAN_32", "Immagini presenti");
define("CONTENT_ADMIN_ITEM_LAN_33", "Carica nuova immagine");
define("CONTENT_ADMIN_ITEM_LAN_34", "Immagini");
define("CONTENT_ADMIN_ITEM_LAN_35", "Imposta le preferenze per questo contenuto");
define("CONTENT_ADMIN_ITEM_LAN_36", "Commenti");
define("CONTENT_ADMIN_ITEM_LAN_37", "Valutazione");
define("CONTENT_ADMIN_ITEM_LAN_38", "Icone stampa/email");
define("CONTENT_ADMIN_ITEM_LAN_39", "Visibilit�");
define("CONTENT_ADMIN_ITEM_LAN_40", "Punteggio");
define("CONTENT_ADMIN_ITEM_LAN_41", "Seleziona un punteggio ...");
define("CONTENT_ADMIN_ITEM_LAN_42", "Spunta per aggiornare la data di pubblicazione alla data/ora correnti");
define("CONTENT_ADMIN_ITEM_LAN_43", "Post user submitted content item");
define("CONTENT_ADMIN_ITEM_LAN_44", "Crea contenuto");
define("CONTENT_ADMIN_ITEM_LAN_45", "Aggiorna il contenuto");
define("CONTENT_ADMIN_ITEM_LAN_46", "Anteprima");
define("CONTENT_ADMIN_ITEM_LAN_47", "Nuova anteprima");
define("CONTENT_ADMIN_ITEM_LAN_48", "Principale (parent)");
define("CONTENT_ADMIN_ITEM_LAN_49", "Invia contenuto");
define("CONTENT_ADMIN_ITEM_LAN_50", "Nessun contenuto inviato");
define("CONTENT_ADMIN_ITEM_LAN_51", "Dettagli autore");
define("CONTENT_ADMIN_ITEM_LAN_52", "Invia contenuto");
define("CONTENT_ADMIN_ITEM_LAN_53", "Meta keywords");
define("CONTENT_ADMIN_ITEM_LAN_54", "Dati addizionali");
define("CONTENT_ADMIN_ITEM_LAN_55", "Indietro alla pagina <a href='".e_SELF."'>Gestione Principale</a> per gestire altri contentuti.<br />o<br />
Vai alla <a href='".e_PLUGIN."content/content.php'>pagina Contenuti</a> per vederli.");
define("CONTENT_ADMIN_ITEM_LAN_56", "Gestione Contenuti Personale");
define("CONTENT_ADMIN_ITEM_LAN_57", "Categoria");
define("CONTENT_ADMIN_ITEM_LAN_58", "Oggetti");
define("CONTENT_ADMIN_ITEM_LAN_59", "Muovi");
define("CONTENT_ADMIN_ITEM_LAN_60", "Ordinamento");
define("CONTENT_ADMIN_ITEM_LAN_61", "Aggiorna ordinamento");
define("CONTENT_ADMIN_ITEM_LAN_62", "Ordina categorie");
define("CONTENT_ADMIN_ITEM_LAN_63", "Inc");
define("CONTENT_ADMIN_ITEM_LAN_64", "Dec");
define("CONTENT_ADMIN_ITEM_LAN_65", "Ordina contenuti");
define("CONTENT_ADMIN_ITEM_LAN_66", "Sotto vedi le lettere evidenziate delle intestazioni dei contenuti nella categoria.<br />
Premendo una delle lettere vedrai una lista di tutti gli oggetti che iniziano con quella lettera. Puoi anche scegliere il bottone TUTTI per visualizzare tutti i contenuti di questa categoria.");
define("CONTENT_ADMIN_ITEM_LAN_67", "Sotto vedi i contenuti per la categoria selezionata o un combo con una lettera selezionata.<br />
Puoi modificare o eliminare un contenuto premendo l'appropriato bottone sulla destra.");
define("CONTENT_ADMIN_ITEM_LAN_68", "Sotto hai la possibilit� di aggiungere dati personalizzati a questo contenuto. Ogni dato personalizzato deve avere sia un chiave che un valore presente. Puoi specificare la chiave nel campo di sinistra e il corrispondente valore in quello di destra.<br />
(per esmpio, key='fotografia' e il  valore='tutte le foto le ho fatte io'.");
define("CONTENT_ADMIN_ITEM_LAN_69", "Qui puoi caricare icone, allegati e/o immagini che servono al contenuto. Le estensioni ammesse sono : ");
define("CONTENT_ADMIN_ITEM_LAN_70", "Separa ogni parola con una virgola, NESSUNO SPAZIO � consentito !");
define("CONTENT_ADMIN_ITEM_LAN_71", "Non compliare se il contentuo � scritto da te");
define("CONTENT_ADMIN_ITEM_LAN_72", "Definizione dettagli autore");
define("CONTENT_ADMIN_ITEM_LAN_73", "Definisci una data di inizio (non compilare se non serve)");
define("CONTENT_ADMIN_ITEM_LAN_74", "Definisci una data di inizio (non compilare se non serve)");
define("CONTENT_ADMIN_ITEM_LAN_75", "Assegna icona");
define("CONTENT_ADMIN_ITEM_LAN_76", "Assegna allegato");
define("CONTENT_ADMIN_ITEM_LAN_77", "Assegna immagine");
define("CONTENT_ADMIN_ITEM_LAN_78", "Commenti consentiti?");
define("CONTENT_ADMIN_ITEM_LAN_79", "Valutazione consentita?");
define("CONTENT_ADMIN_ITEM_LAN_80", "Visualizzare icone stampa/email?");
define("CONTENT_ADMIN_ITEM_LAN_81", "Scegli quale gruppo di utenti pu� vedere questo contenuto");
define("CONTENT_ADMIN_ITEM_LAN_82", "Definisci un punteggio");
define("CONTENT_ADMIN_ITEM_LAN_83", "Definisci meta keywords");
define("CONTENT_ADMIN_ITEM_LAN_84", "Definisci i campi dato personalizzati (chiave + valore)");
define("CONTENT_ADMIN_ITEM_LAN_85", "Abilitato");
define("CONTENT_ADMIN_ITEM_LAN_86", "Non abilitato");
define("CONTENT_ADMIN_ITEM_LAN_87", "Scegli un'icona per il contenuto");
define("CONTENT_ADMIN_ITEM_LAN_88", "Per creare un contenuto velocemente seleziona la categoria principale");
define("CONTENT_ADMIN_ITEM_LAN_89", "Per modificare un contenuto velocemente seleziona la categoria principale");
define("CONTENT_ADMIN_ITEM_LAN_90", "premi qui");
define("CONTENT_ADMIN_ITEM_LAN_91", "per ri-modificare lo stesso contenuto");
define("CONTENT_ADMIN_ITEM_LAN_92", "Layout");
define("CONTENT_ADMIN_ITEM_LAN_93", "Scegli uno schema di layout");
define("CONTENT_ADMIN_ITEM_LAN_94", "Scegli uno schema di layout");

define("CONTENT_ADMIN_ITEM_LAN_95", "Carica una nuova icona");
define("CONTENT_ADMIN_ITEM_LAN_96", "Scegli un'icona esistente");
define("CONTENT_ADMIN_ITEM_LAN_97", "Dopo aver caricato una nuova icona, puoi assegnare quest'icona nell'area icone sottostante");

define("CONTENT_ADMIN_ITEM_LAN_98", "Carica un nuovo allegato");
define("CONTENT_ADMIN_ITEM_LAN_99", "Scegli un allegato esistente");
define("CONTENT_ADMIN_ITEM_LAN_100", "Dopo aver caricato un nuovo allegato, puoi assegnare quest'allegato nell'area allegati sottostante");

define("CONTENT_ADMIN_ITEM_LAN_101", "Carica una nuova immagine");
define("CONTENT_ADMIN_ITEM_LAN_102", "Scegli un'immagine esistente");
define("CONTENT_ADMIN_ITEM_LAN_103", "Dopo aver caricato un nuova immagine, puoi assegnare questa immagine nell'area immagini sottostante");

define("CONTENT_ADMIN_ITEM_LAN_104", "Carica");
define("CONTENT_ADMIN_ITEM_LAN_105", "Vedi");

define("CONTENT_ADMIN_ITEM_LAN_106", "Icona caricata con successo<br />
Notizia: devi ancora assegnare l'icona nella area della scelta icone!<br />
Naturalmente dopo aver fatto questo devi ancora salvare il tutto per creare/aggiornare questa categoria");
define("CONTENT_ADMIN_ITEM_LAN_107", "Icona non caricata");

define("CONTENT_ADMIN_ITEM_LAN_108", "Allegato caricato con successo<br />
Notizia: devi ancora assegnare l'allegato nella area della scelta allegati!<br />
Naturalmente dopo aver fatto questo devi ancora salvare il tutto per creare/aggiornare questa categoria");
define("CONTENT_ADMIN_ITEM_LAN_109", "Allegato non caricato");

define("CONTENT_ADMIN_ITEM_LAN_110", "Immagine caricata con successo<br />
Notizia: devi ancora assegnare l'immagine nella area della scelta immagini!<br />
e naturalmente dopo aver fatto questo devi ancora inviare il modulo per creare/aggiornare questa categoria");
define("CONTENT_ADMIN_ITEM_LAN_111", "Immagine non caricata");

define("CONTENT_ADMIN_ITEM_LAN_112", "Carica un'icona, un allegato o un'immagine");
define("CONTENT_ADMIN_ITEM_LAN_113", "Scegli il tipo di allegato da caricare prim,a di caricare il file");
define("CONTENT_ADMIN_ITEM_LAN_114", "Icona");
define("CONTENT_ADMIN_ITEM_LAN_115", "Allegato");
define("CONTENT_ADMIN_ITEM_LAN_116", "Immagine");
define("CONTENT_ADMIN_ITEM_LAN_117", "submitted content item posted");
define("CONTENT_ADMIN_ITEM_LAN_118", "No");
define("CONTENT_ADMIN_ITEM_LAN_119", "Assegnato");
define("CONTENT_ADMIN_ITEM_LAN_120", "Layout di default");

define("CONTENT_ADMIN_ITEM_LAN_121", "Ancora nessuna icona caricata");
define("CONTENT_ADMIN_ITEM_LAN_122", "Ancora nessun allegato caricato");
define("CONTENT_ADMIN_ITEM_LAN_123", "Ancora nessuna immagine caricata");
define("CONTENT_ADMIN_ITEM_LAN_124", "per vedere il contenuto modificato ");

define("CONTENT_ADMIN_ORDER_LAN_0", "order is increased");
define("CONTENT_ADMIN_ORDER_LAN_1", "order is decreased");
define("CONTENT_ADMIN_ORDER_LAN_2", "Nuovo ordinamento contenuti salvato");



define("CONTENT_ADMIN_MAIN_LAN_0", "Categorie contenuti esistenti");
define("CONTENT_ADMIN_MAIN_LAN_1", "Ancora nessuna categoria");
define("CONTENT_ADMIN_MAIN_LAN_2", "Categorie principali");
define("CONTENT_ADMIN_MAIN_LAN_3", "Contenuto eliminato");
define("CONTENT_ADMIN_MAIN_LAN_4", "Testo principale (parent)");
define("CONTENT_ADMIN_MAIN_LAN_5", "Icona principale (parent)");
define("CONTENT_ADMIN_MAIN_LAN_6", "");
define("CONTENT_ADMIN_MAIN_LAN_7", "Benvenuto nel Sistema di Gestione Contenuti !");
define("CONTENT_ADMIN_MAIN_LAN_8", "Questa informazione appare perch� la tabella del Plugin Gestione Contenuti non contiene dati (records).");
define("CONTENT_ADMIN_MAIN_LAN_9", "Leggi attentamente le informazioni seguenti e scegli cosa intendi fare.");
define("CONTENT_ADMIN_MAIN_LAN_10", "Puoi gestire i contenuti in questa pagina. Per prima cosa decidere la categoria per i tuoi contenuti. Seleziona una categoria dall'apposito box per iniziare la gestione dei contenuti per quella categoria.");
define("CONTENT_ADMIN_MAIN_LAN_11", "Fino a che le vecchie tabelle dei contenuti contengono dei dati, puoi scegliere una delle seguenti opzioni:");
define("CONTENT_ADMIN_MAIN_LAN_12", "");
define("CONTENT_ADMIN_MAIN_LAN_13", "Puoi creare un nuovo contenuto per questa pagina. Per prima cosa decidi la categoria in cui gestire i contenuti. Premi il bottone indicante le categorie principali (parent) per creare contenuti in quella categoria.");
define("CONTENT_ADMIN_MAIN_LAN_14", "Puoi impostare l'ordine dei contenuti su questa pagina. premi sul bottone dei 'main parents' per iniziare l'ordinamento che preferisci.");
define("CONTENT_ADMIN_MAIN_LAN_15", "In questa pagina puoi gestire le categorie. Scegli la categoria principale premendo il bottone sotto per mostrae una descrizione di categorie e sottocategorie contenute nella categoria principale.");
define("CONTENT_ADMIN_MAIN_LAN_16", "In questa pagina puoi creare una nuova categoria. Per default � mostrato il modulo di creazione delle categorie. Se vuoi creare una sottocategoria premi il bottone sotto  e scegli la categoria principale della sottocategoria che intendi creare.");
define("CONTENT_ADMIN_MAIN_LAN_17", "per favore crea una nuova categoria in <a href='".e_SELF."?type.0.cat.create'>Crea Nuova Categoria</a>");

define("CONTENT_ADMIN_MAIN_LAN_18", "Record convertiti");
define("CONTENT_ADMIN_MAIN_LAN_19", "
Prima cosa da fare � creare un backup delle tabelle dei contenuti cos� come delle tabelle dei commenti e valutazioni.<br />
Usa allo scopo progammi come phpmyadmin.<br />
Dopo aver creato un backup delle vecchie tabelle, puoi far partie la conversione dei records.<br />
Dopo aver convertito i tuoi vecchi contenuti, non dovresti soffermarti ancora a lungo su questa informazione, e essere quindi in grado di gestire le nuove informazioni.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_20", "Inizia con una tabella contenuti vuota");
define("CONTENT_ADMIN_MAIN_LAN_21", "
Se non hai pi� interesse nelle informazioni contentute nelle vecchie tabelle,<br />
e vuoi iniziare con delle nuove tabelle per la nuova verisone del Plugin,<br />
e non vuoi creare un set di categorie di default,<br />
puoi iniziare iniziando una nuova categoria.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_22", "Crea un set di categorie di deafault");
define("CONTENT_ADMIN_MAIN_LAN_23", "
Se vuoi partire con una nuova installazione delle tabelle, puoi creare per prima cosa un set di categorie di default.<br />
Con questo set di default tre categorie principali saranno create, chiamate Content, Review e Article.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_24", "Questa � una nuova installazione / Le vecchi tabelle non contengono records");
define("CONTENT_ADMIN_MAIN_LAN_25", "
Ora le tue vecchie tabelle sono vuote, tu puoi cos� iniziar egestendo nuovi contenuti.<br />
Premendo ol bottone Next (successivo), verr� automaticamente creato uno nuovo set di categorie, chiamate Content, Review e Article.<br />
");
define("CONTENT_ADMIN_MAIN_LAN_26", "Anteprima");
define("CONTENT_ADMIN_MAIN_LAN_27", "Nuova anteprima");
define("CONTENT_ADMIN_MAIN_LAN_28", "Scegli categoria ...");
define("CONTENT_ADMIN_MAIN_LAN_29", "NUOVA CATEGORIA PRINCIPALE");



define("CONTENT_ADMIN_MENU_LAN_0", "Gestione Contenuti");
define("CONTENT_ADMIN_MENU_LAN_1", "Crea Contenuti");
define("CONTENT_ADMIN_MENU_LAN_2", "Gestione Categoria");
define("CONTENT_ADMIN_MENU_LAN_3", "Crea Categoria");
define("CONTENT_ADMIN_MENU_LAN_4", "Invia contenuto");
define("CONTENT_ADMIN_MENU_LAN_5", "Categoria");
define("CONTENT_ADMIN_MENU_LAN_6", "Opzioni");
define("CONTENT_ADMIN_MENU_LAN_7", "Admin: Crea Contenuto");
define("CONTENT_ADMIN_MENU_LAN_8", "Invia oggetto");
define("CONTENT_ADMIN_MENU_LAN_9", "Path e Tema");
define("CONTENT_ADMIN_MENU_LAN_10", "Generale");
define("CONTENT_ADMIN_MENU_LAN_11", "Anteprima Contenuti");
define("CONTENT_ADMIN_MENU_LAN_12", "Pagin Categorie");
define("CONTENT_ADMIN_MENU_LAN_13", "Pagina Contenuti");
define("CONTENT_ADMIN_MENU_LAN_14", "Men�");
define("CONTENT_ADMIN_MENU_LAN_15", "Ordinamento");
define("CONTENT_ADMIN_MENU_LAN_16", "Archivio");
define("CONTENT_ADMIN_MENU_LAN_17", "Gestione Contenuti Personale");
define("CONTENT_ADMIN_MENU_LAN_18", "Pagina Autore");
define("CONTENT_ADMIN_MENU_LAN_19", "Gestione Contentuti");
define("CONTENT_ADMIN_MENU_LAN_20", "Pagina Pi� Valutati");
define("CONTENT_ADMIN_MENU_LAN_21", "Pagine");
define("CONTENT_ADMIN_MENU_LAN_22", "Pagina Maggior Punteggi");



define("CONTENT_ADMIN_JS_LAN_0", "Sei sicuro di eliminare questa categoria?");
define("CONTENT_ADMIN_JS_LAN_1", "Sei sicuro di eliminare questo contenuto?");
define("CONTENT_ADMIN_JS_LAN_2", "Sei sicuro di rimuovere l'immagine corrente ?");
define("CONTENT_ADMIN_JS_LAN_3", "Sei sicuro di rimuovere il file corrente ?");
define("CONTENT_ADMIN_JS_LAN_4", "immagine");
define("CONTENT_ADMIN_JS_LAN_5", "file");
define("CONTENT_ADMIN_JS_LAN_6", "ID");
define("CONTENT_ADMIN_JS_LAN_7", "Sei sicuro di rimuovere l'icona corrente ?");
define("CONTENT_ADMIN_JS_LAN_8", "icona");
define("CONTENT_ADMIN_JS_LAN_9", "AVVISO :\\nSolo le categorie vuote possono essere eliminate.\\nuna categoria � vuota se non contiene sottocategorie e\\nse non contiene nessun contenuto!");
define("CONTENT_ADMIN_JS_LAN_10", "Sei sicuro di voler eliminare questo contentuo inviato senza pubblicarlo?");



define("CONTENT_ADMIN_SUBMIT_LAN_0", "no content categories allow user submission at this point");
define("CONTENT_ADMIN_SUBMIT_LAN_1", "content submit types");
define("CONTENT_ADMIN_SUBMIT_LAN_2", "Grazie, il tuo contenuto � stato inoltrato.");
define("CONTENT_ADMIN_SUBMIT_LAN_3", "Grazie, il tuo contenuto � stato inoltrato e sar� sottoposto quanto prima ad un amministratore.");
define("CONTENT_ADMIN_SUBMIT_LAN_4", "campo/i richiesti non compilati");
define("CONTENT_ADMIN_SUBMIT_LAN_5", "Torna alla pagina di <a href='".e_SELF."'>invio contenuto</a> per sottoporre nuovi oggetti<br />oppure<br />Vai alla <a href='".e_PLUGIN."content/content.php'>pagina principale dei contenuti</a> per visualizzarli.");
define("CONTENT_ADMIN_SUBMIT_LAN_6", "");
define("CONTENT_ADMIN_SUBMIT_LAN_7", "");
define("CONTENT_ADMIN_SUBMIT_LAN_8", "Contenuto inviato eliminato");
define("CONTENT_ADMIN_SUBMIT_LAN_9", "");
define("CONTENT_ADMIN_SUBMIT_LAN_10", "");
define("CONTENT_ADMIN_SUBMIT_LAN_11", "");
define("CONTENT_ADMIN_SUBMIT_LAN_12", "");
define("CONTENT_ADMIN_SUBMIT_LAN_13", "");
define("CONTENT_ADMIN_SUBMIT_LAN_14", "");
define("CONTENT_ADMIN_SUBMIT_LAN_15", "");
define("CONTENT_ADMIN_SUBMIT_LAN_16", "");
define("CONTENT_ADMIN_SUBMIT_LAN_17", "");
define("CONTENT_ADMIN_SUBMIT_LAN_18", "");
define("CONTENT_ADMIN_SUBMIT_LAN_19", "");



define("CONTENT_ADMIN_CONVERSION_LAN_0", "Contenuti");
define("CONTENT_ADMIN_CONVERSION_LAN_1", "Recensioni");
define("CONTENT_ADMIN_CONVERSION_LAN_2", "Articoli");
define("CONTENT_ADMIN_CONVERSION_LAN_3", "Categoria");
define("CONTENT_ADMIN_CONVERSION_LAN_4", "Categorie");
define("CONTENT_ADMIN_CONVERSION_LAN_5", "Pagina");
define("CONTENT_ADMIN_CONVERSION_LAN_6", "Pagine");
define("CONTENT_ADMIN_CONVERSION_LAN_7", "Inserito 'main parent'");
define("CONTENT_ADMIN_CONVERSION_LAN_8", "Preferrenze 'main parent' inserite");
define("CONTENT_ADMIN_CONVERSION_LAN_9", "No");
define("CONTENT_ADMIN_CONVERSION_LAN_10", "Necessita 'main parent'");
define("CONTENT_ADMIN_CONVERSION_LAN_11", "Analisi conversione");
define("CONTENT_ADMIN_CONVERSION_LAN_12", "Righe totali da convertire");
define("CONTENT_ADMIN_CONVERSION_LAN_13", "Totale righe convertite");
define("CONTENT_ADMIN_CONVERSION_LAN_14", "Avverttimenti totali");
define("CONTENT_ADMIN_CONVERSION_LAN_15", "Fallimenti totali");
define("CONTENT_ADMIN_CONVERSION_LAN_16", "Analisi delle vecchie tabelle");
define("CONTENT_ADMIN_CONVERSION_LAN_17", "Totale righe");
define("CONTENT_ADMIN_CONVERSION_LAN_18", "Righe sconosciute");
define("CONTENT_ADMIN_CONVERSION_LAN_19", "Tutte le righe sono 'familiar'");
define("CONTENT_ADMIN_CONVERSION_LAN_20", "Contenuti categoria principale'");
define("CONTENT_ADMIN_CONVERSION_LAN_21", "Recensioni categoria principale");
define("CONTENT_ADMIN_CONVERSION_LAN_22", "Articoli categoria principale");
define("CONTENT_ADMIN_CONVERSION_LAN_23", "insertion failed");
define("CONTENT_ADMIN_CONVERSION_LAN_24", "Nessuna pagina contenuto presente");
define("CONTENT_ADMIN_CONVERSION_LAN_25", "pagine contenuto presenti");
define("CONTENT_ADMIN_CONVERSION_LAN_26", "Inserito");
define("CONTENT_ADMIN_CONVERSION_LAN_27", "Analsisi della conversione");
define("CONTENT_ADMIN_CONVERSION_LAN_28", "Vecchie righe totali");
define("CONTENT_ADMIN_CONVERSION_LAN_29", "Nuove righe totali");
define("CONTENT_ADMIN_CONVERSION_LAN_30", "Fallimenti");
define("CONTENT_ADMIN_CONVERSION_LAN_31", "Avvertimenti");
define("CONTENT_ADMIN_CONVERSION_LAN_32", "Le vecchie categorie non esistono: oggetti aggiunti alle categorie pi� alte");
define("CONTENT_ADMIN_CONVERSION_LAN_33", "le nuove categorie non esistono: oggetti aggiunti alle categorie pi� alte");
define("CONTENT_ADMIN_CONVERSION_LAN_34", "No");
define("CONTENT_ADMIN_CONVERSION_LAN_35", "Category pages present");
define("CONTENT_ADMIN_CONVERSION_LAN_36", "Pages and/or submitted pages present");
define("CONTENT_ADMIN_CONVERSION_LAN_37", "Conversione delle categorie");
define("CONTENT_ADMIN_CONVERSION_LAN_38", "Inserimenti validi");
define("CONTENT_ADMIN_CONVERSION_LAN_39", "Inserimenti falliti");
define("CONTENT_ADMIN_CONVERSION_LAN_40", "Avvertimenti");
define("CONTENT_ADMIN_CONVERSION_LAN_41", "Avvertimenti");
define("CONTENT_ADMIN_CONVERSION_LAN_42", "Tisultato della conversione dalle vecchie tabelle alle nuove");
define("CONTENT_ADMIN_CONVERSION_LAN_43", "Premi il bottone per convertire le vecchie tabelle");
define("CONTENT_ADMIN_CONVERSION_LAN_44", "Le nuove tabelle contengono gi� dati !<br />
Sei sicuro di voler convertire ?<br /><br />
Se sei ancora sicuro di continuare la conversione, i vecchi dati saranno aggiunti a quelli esistenti delle nuove tabelle, senza garanzia sulla perfetta riuscita del processo !");
define("CONTENT_ADMIN_CONVERSION_LAN_45", "Inserimento fallito: main parent non inserita");
define("CONTENT_ADMIN_CONVERSION_LAN_46", "Inizia a gestire il tuo plugin a questo indirizzo: <a href='".e_PLUGIN."content/admin_content_config.php'>Gestione Plugin Contenuti</a> !");
define("CONTENT_ADMIN_CONVERSION_LAN_47", "Conversione completata");
define("CONTENT_ADMIN_CONVERSION_LAN_48", "Premi qui per dettagli");
define("CONTENT_ADMIN_CONVERSION_LAN_49", "Conversione delle pagine");
define("CONTENT_ADMIN_CONVERSION_LAN_50", "Conversione delle main parents");
define("CONTENT_ADMIN_CONVERSION_LAN_51", "Riga sconosciuta");
define("CONTENT_ADMIN_CONVERSION_LAN_52", "Set di default delle categorie pirncipali (parent) creato");
define("CONTENT_ADMIN_CONVERSION_LAN_53", "Categoria Principcale dello stesso nome gi� esistente");
define("CONTENT_ADMIN_CONVERSION_LAN_54", "Crea un set di default delle categorie pirncipali (parent) (chiamate content, review e article)");
define("CONTENT_ADMIN_CONVERSION_LAN_55", "Gestione Plugin Contenuti : opzioni di conversione");
define("CONTENT_ADMIN_CONVERSION_LAN_56", "Premi il bottone per creare una nuova pagina categoria.");
define("CONTENT_ADMIN_CONVERSION_LAN_57", "Scegli categoria principale");
define("CONTENT_ADMIN_CONVERSION_LAN_58", "Upgrade riuscito<br /><br /><b>Avviso:<br />
devi riconfigurare le opzioni per ogni categoria principale<br />
e devi eliminare i menu blocchi che hai creato, quindi ricrearli con le nuove impostazioni che vorrai assegnare alle categorie principali.</b>");

define("CONTENT_ADMIN_CONVERSION_LAN_59", "Tabella converisone");
define("CONTENT_ADMIN_CONVERSION_LAN_60", "Crea defaults");
define("CONTENT_ADMIN_CONVERSION_LAN_61", "Crea nuova categoria");
define("CONTENT_ADMIN_CONVERSION_LAN_62", "Content Management Plugin Version aggiornato alla versione:");
define("CONTENT_ADMIN_CONVERSION_LAN_63", "Aggiornamento");
define("CONTENT_ADMIN_CONVERSION_LAN_64", "");
define("CONTENT_ADMIN_CONVERSION_LAN_65", "");



define("CONTENT_ADMIN_OPT_LAN_MENU_1", "Opzioni:");
define("CONTENT_ADMIN_OPT_LAN_MENU_2", "Pagine:");
define("CONTENT_ADMIN_OPT_LAN_MENU_3", "Admin: Crea Contenuto");
define("CONTENT_ADMIN_OPT_LAN_MENU_4", "Invia Oggetto");
define("CONTENT_ADMIN_OPT_LAN_MENU_5", "Localizzazione cartelle salvataggio e impostazioni del tema");
define("CONTENT_ADMIN_OPT_LAN_MENU_6", "Generale");
define("CONTENT_ADMIN_OPT_LAN_MENU_7", "Gestione Contenuti");
define("CONTENT_ADMIN_OPT_LAN_MENU_8", "Men� Propriet�");
define("CONTENT_ADMIN_OPT_LAN_MENU_9", "Anteprima Contenuti");
define("CONTENT_ADMIN_OPT_LAN_MENU_10", "Pagine Categorie");
define("CONTENT_ADMIN_OPT_LAN_MENU_11", "Pagine Contenuti");
define("CONTENT_ADMIN_OPT_LAN_MENU_12", "Pagina Autore");
define("CONTENT_ADMIN_OPT_LAN_MENU_13", "Archivio");
define("CONTENT_ADMIN_OPT_LAN_MENU_14", "Maggior Valutazione");
define("CONTENT_ADMIN_OPT_LAN_MENU_15", "Maggior Punteggio");
define("CONTENT_ADMIN_OPT_LAN_MENU_16", "tutte le pagine delle categorie (tutte le categorie nella categoria principale)");
define("CONTENT_ADMIN_OPT_LAN_MENU_17", "vedi la pagina categoria (parent item, sottocategorie e contenuti in quella categoria");
define("CONTENT_ADMIN_OPT_LAN_MENU_18", "categorie");
define("CONTENT_ADMIN_OPT_LAN_MENU_19", "Lista contenuti recenti");
define("CONTENT_ADMIN_OPT_LAN_MENU_20", "links alla pagina");

define("CONTENT_ADMIN_OPT_LAN_SECTION_0", "sezioni");
define("CONTENT_ADMIN_OPT_LAN_SECTION_1", "seleziona l'oggetto da visualizzare nel contenuto");
define("CONTENT_ADMIN_OPT_LAN_SECTION_2", "allegati");
define("CONTENT_ADMIN_OPT_LAN_SECTION_3", "immagini");
define("CONTENT_ADMIN_OPT_LAN_SECTION_4", "commenti");
define("CONTENT_ADMIN_OPT_LAN_SECTION_5", "valutazioni");
define("CONTENT_ADMIN_OPT_LAN_SECTION_6", "punteggi");
define("CONTENT_ADMIN_OPT_LAN_SECTION_7", "visibilt�");
define("CONTENT_ADMIN_OPT_LAN_SECTION_8", "meta definition");
define("CONTENT_ADMIN_OPT_LAN_SECTION_9", "schema di layout");
define("CONTENT_ADMIN_OPT_LAN_SECTION_10", "data tags personalizzati");
define("CONTENT_ADMIN_OPT_LAN_SECTION_11", "data tags predefiniti");
define("CONTENT_ADMIN_OPT_LAN_SECTION_12", "sottointestazione");
define("CONTENT_ADMIN_OPT_LAN_SECTION_13", "sommario");
define("CONTENT_ADMIN_OPT_LAN_SECTION_14", "testo (definire numero di parole)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_15", "data");
define("CONTENT_ADMIN_OPT_LAN_SECTION_16", "autore : nome");
define("CONTENT_ADMIN_OPT_LAN_SECTION_17", "autore : email");
define("CONTENT_ADMIN_OPT_LAN_SECTION_18", "autore : link al profilo");
define("CONTENT_ADMIN_OPT_LAN_SECTION_19", "autore : link alla lista autori");
define("CONTENT_ADMIN_OPT_LAN_SECTION_20", "icone email/print/pdf");
define("CONTENT_ADMIN_OPT_LAN_SECTION_21", "prercorso principale");
define("CONTENT_ADMIN_OPT_LAN_SECTION_22", "refer (only if logging enabled)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_23", "numero di oggetti");
define("CONTENT_ADMIN_OPT_LAN_SECTION_24", "ultimo contenuto di ogni autore");
define("CONTENT_ADMIN_OPT_LAN_SECTION_25", "numero di contenuti di ogni autore");
define("CONTENT_ADMIN_OPT_LAN_SECTION_26", "icona modifica per la modifica veloce");
define("CONTENT_ADMIN_OPT_LAN_SECTION_27", "icona");
define("CONTENT_ADMIN_OPT_LAN_SECTION_28", "della categoria");
define("CONTENT_ADMIN_OPT_LAN_SECTION_29", "della lista delle sottocategorie");
define("CONTENT_ADMIN_OPT_LAN_SECTION_30", "abilitato");
define("CONTENT_ADMIN_OPT_LAN_SECTION_31", "non abilitato");



define("CONTENT_PRESET_LAN_0", "errore : campo non compilato");
define("CONTENT_PRESET_LAN_1", "errore : non tutti i campi sono compilati correttamente<br />
tutti i campi devono essere riempiti");
define("CONTENT_PRESET_LAN_2", "");
define("CONTENT_PRESET_LAN_3", "'dimensione' e 'massima dimensione' devono essere valori numerici");
define("CONTENT_PRESET_LAN_4", "'colonne' e 'righe' devono essere valori numerici");
define("CONTENT_PRESET_LAN_5", "devi fornire altre opzioni");
define("CONTENT_PRESET_LAN_6", "'anno da' e 'anno a' devono essere valori numerici");
define("CONTENT_PRESET_LAN_7", "Generatore campi predefiniti");
define("CONTENT_PRESET_LAN_8", "crea un nuovo data tag predefinito di tipo");
define("CONTENT_PRESET_LAN_9", "nome campo");
define("CONTENT_PRESET_LAN_10", "dimensione");
define("CONTENT_PRESET_LAN_11", "lunghezza massima");
define("CONTENT_PRESET_LAN_12", "colonne");
define("CONTENT_PRESET_LAN_13", "righe");
define("CONTENT_PRESET_LAN_14", "anno da");
define("CONTENT_PRESET_LAN_15", "anno a");
define("CONTENT_PRESET_LAN_16", "opzioni");
define("CONTENT_PRESET_LAN_17", "aggiungi pi�");
define("CONTENT_PRESET_LAN_18", "aggiundi predefinito");
define("CONTENT_PRESET_LAN_19", "devi fornire un numero uguale di campi testo e valore");
define("CONTENT_PRESET_LAN_20", "devi fornire un valore per il checkbox");
define("CONTENT_PRESET_LAN_21", "testo");
define("CONTENT_PRESET_LAN_22", "valore");
define("CONTENT_PRESET_LAN_23", "scegli testo");
define("CONTENT_PRESET_LAN_24", "la prima opzione senza valore");
define("CONTENT_PRESET_LAN_25", "aggiungi campo ...");
define("CONTENT_PRESET_LAN_26", "testo");
define("CONTENT_PRESET_LAN_27", "textarea");
define("CONTENT_PRESET_LAN_28", "select");
define("CONTENT_PRESET_LAN_29", "data");
define("CONTENT_PRESET_LAN_30", "checkbox");
define("CONTENT_PRESET_LAN_31", "radio");
define("CONTENT_PRESET_LAN_32", "esempio:");



define("CONTENT_ADMIN_OPT_LAN_0", "opzioni");
define("CONTENT_ADMIN_OPT_LAN_1", "Imposta preferenze di default per tutte le categorie");
define("CONTENT_ADMIN_OPT_LAN_2", "Aggiorna");
define("CONTENT_ADMIN_OPT_LAN_3", "numero di immagini da caricare");
define("CONTENT_ADMIN_OPT_LAN_4", "numero di allegati da caricare");
define("CONTENT_ADMIN_OPT_LAN_5", "numero di data tags personalizzati disponibili");
define("CONTENT_ADMIN_OPT_LAN_6", "data tags predefiniti");
define("CONTENT_ADMIN_OPT_LAN_7", "definire il default per i data tags predefiniti");
//define("CONTENT_ADMIN_OPT_LAN_8", "Here you can provide additional preset data tags. The fields you provide here are the keys of the key=>value data tags. They will have a input element for the value to be set in the admin creation form. You can choose from the pulldown menu which type of element you want the preset data tag to be. Note: these are not part of the amount of custom data tags you have specified above, and will be used additionally.These Preset Tags are very usefull if you want to have a certain custom tag available standard for each new item. for instance, if you always want to be able to define a value for 'photographer' you can create such a preset tag, which will always be displayed for each new item in this main parent.");
define("CONTENT_ADMIN_OPT_LAN_9", "permetti di inviare contenuti ?");
define("CONTENT_ADMIN_OPT_LAN_10", "chi pu� inviare contenuti ?");
define("CONTENT_ADMIN_OPT_LAN_11", "inserimento diretto");
define("CONTENT_ADMIN_OPT_LAN_12", "Se abilitato, un contenuto inviato � aggiunto direttamente al database e sar� immediatamente visibile, diversamente un amministratore dovr� approvare il contenuto.");
define("CONTENT_ADMIN_OPT_LAN_13", "Qui puoi stabilire dove le tue immagini sono o saranno salvate. Usa parentesi graffe ( { } ) per le varibili di sistema dei path di e017 (like ( {e_PLUGIN} or {e_IMAGE} ). Per le icone delle categorie sono necessarie due versioni, un set piccolo e uno grande di icone. Il path TMP (temporaneo) � necessario per caricare, DEVI crearlo !");
define("CONTENT_ADMIN_OPT_LAN_15", "path per il set di icone (grandi)");
define("CONTENT_ADMIN_OPT_LAN_16", "path per il set di icone (piccole)");
define("CONTENT_ADMIN_OPT_LAN_17", "path per le icone dei contenuti");
define("CONTENT_ADMIN_OPT_LAN_18", "path per le immagini dei contenuti");
define("CONTENT_ADMIN_OPT_LAN_19", "path per gli allegati dei contenuti");
define("CONTENT_ADMIN_OPT_LAN_20", "definire il tema da utilizzare per questa categoria principale");
define("CONTENT_ADMIN_OPT_LAN_21", "definire lo schema di default del layout");
define("CONTENT_ADMIN_OPT_LAN_22", "activate logging of refer count");
define("CONTENT_ADMIN_OPT_LAN_23", "mostra un'icona bianca per le icone dei contenuti se non � presente nessuna icona");
define("CONTENT_ADMIN_OPT_LAN_24", "mostra un'icona bianca per le icone delle categorie se non � presente nessuna icona");
define("CONTENT_ADMIN_OPT_LAN_25", "seleziona uno schema di layout");
define("CONTENT_ADMIN_OPT_LAN_26", "mostra il percorso relativo su queste pagine:");
define("CONTENT_ADMIN_OPT_LAN_27", "tutte le categorie");
define("CONTENT_ADMIN_OPT_LAN_28", "categoria singola");
define("CONTENT_ADMIN_OPT_LAN_29", "tutti gli autori");
define("CONTENT_ADMIN_OPT_LAN_30", "autore singolo");
define("CONTENT_ADMIN_OPT_LAN_31", "recenti");
define("CONTENT_ADMIN_OPT_LAN_32", "contenuti");
define("CONTENT_ADMIN_OPT_LAN_33", "pi� valutati");
define("CONTENT_ADMIN_OPT_LAN_34", "archivio");
define("CONTENT_ADMIN_OPT_LAN_35", "punteggio");
define("CONTENT_ADMIN_OPT_LAN_36", "carattere di separazione del percorso relativo");
define("CONTENT_ADMIN_OPT_LAN_37", "definisci chi renderizza le informazioni del percorso relativo");
define("CONTENT_ADMIN_OPT_LAN_38", "temporaneo (tmp)");
define("CONTENT_ADMIN_OPT_LAN_39", "echo");
define("CONTENT_ADMIN_OPT_LAN_40", "usa un men� separato");
define("CONTENT_ADMIN_OPT_LAN_41", "unisci in un men� unico");
define("CONTENT_ADMIN_OPT_LAN_42", "");
define("CONTENT_ADMIN_OPT_LAN_43", "visualizza un combo di navigazione per le seguenti pagine:");
define("CONTENT_ADMIN_OPT_LAN_44", "visualizza il Cerca in queste pagine:");
define("CONTENT_ADMIN_OPT_LAN_45", "");
define("CONTENT_ADMIN_OPT_LAN_46", "visualizza opzioni di ordinamnento in queste pagine:");
define("CONTENT_ADMIN_OPT_LAN_47", "");
define("CONTENT_ADMIN_OPT_LAN_48", "Tipo renderizzazione per navigatore/cerca/ordinamento");
define("CONTENT_ADMIN_OPT_LAN_49", "visualizza il numero limite di contenuti per pagina");
define("CONTENT_ADMIN_OPT_LAN_50", "quanti contenuti devono essere visualizzati ?");
define("CONTENT_ADMIN_OPT_LAN_51", "Scegli un metodo di ordinamento di Default");
define("CONTENT_ADMIN_OPT_LAN_52", "massima dimensione immagine");
define("CONTENT_ADMIN_OPT_LAN_53", "definire come devono essere ridimensionate le immagini caricate");
define("CONTENT_ADMIN_OPT_LAN_54", "se l'altezza o larghezza delle immagini caricate � pi� grande dei valori impostati, l'immagine sar� ridimensionata a quei valori.<br />
il popup delle immagini le visualizzar� con questi valori impostati.");
define("CONTENT_ADMIN_OPT_LAN_55", "dimensione miniatura");
define("CONTENT_ADMIN_OPT_LAN_56", "definire la dimensione delle miniature create dalle immagini caricate");
define("CONTENT_ADMIN_OPT_LAN_57", "se la miniatura risulter� pi� grande, la stessa sar� ridimensionata a questi valori.<br />
La miniatura sar� inoltre visualizzata con questi valori.");
define("CONTENT_ADMIN_OPT_LAN_58", "nassima dimensione icone");
define("CONTENT_ADMIN_OPT_LAN_59", "definire la massima larghezza delle icone in caricamento");
define("CONTENT_ADMIN_OPT_LAN_60", "se l'icona risulter� pi� grande, l'icona sar� ridimensionata a questi valori.<br />
L'icona sar� inoltre visualizzata con questi valori.");
define("CONTENT_ADMIN_OPT_LAN_61", "px");
define("CONTENT_ADMIN_OPT_LAN_62", "scegli il managers per questo gruppo di utenti");
define("CONTENT_ADMIN_OPT_LAN_63", "The userlist in the admin content manager area will consist of only the users in the defined class. You still need to assign users to each category! This class will just narrow down the list of users to choose from");
define("CONTENT_ADMIN_OPT_LAN_64", "visualizza Email di un autore non registrato");
define("CONTENT_ADMIN_OPT_LAN_65", "visualizza indice 'a lettere'");
define("CONTENT_ADMIN_OPT_LAN_66", "LL'indice a lettere � una lista di bottoni con la prima lettera dell'intestazione del contenuto.");
define("CONTENT_ADMIN_OPT_LAN_67", "definisci lo stile della data per le date visualizzate");
define("CONTENT_ADMIN_OPT_LAN_68", "Per maggiori informazioni sul formato date vedi <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime function page in php.net</a>");
define("CONTENT_ADMIN_OPT_LAN_69", "visualizza icone in tutti i contenuti<br />(icone stampa/email/pdf)");
define("CONTENT_ADMIN_OPT_LAN_70", "permetti valutazione su tutti i contenuti");
define("CONTENT_ADMIN_OPT_LAN_71", "permetti commenti a tutti i contenuti");
define("CONTENT_ADMIN_OPT_LAN_72", "");
define("CONTENT_ADMIN_OPT_LAN_73", "Tipo di renderizzazione indice multipagina");
define("CONTENT_ADMIN_OPT_LAN_74", "Se hai un articolo a pi� pagine, puoi mostrare l'indice di queste pagine come un hyperlink normale, oppure visualizzarlo in box di selezione");
define("CONTENT_ADMIN_OPT_LAN_75", "hyperlink");
define("CONTENT_ADMIN_OPT_LAN_76", "box di selezione");
define("CONTENT_ADMIN_OPT_LAN_77", "definire numero di caratteri");
define("CONTENT_ADMIN_OPT_LAN_78", "definire un suffisso");
define("CONTENT_ADMIN_OPT_LAN_79", "lascia bianco per visualizzazione intera");
define("CONTENT_ADMIN_OPT_LAN_80", "lascia bianco per nessuna visualizzazione.");
define("CONTENT_ADMIN_OPT_LAN_81", "definire numero di parole");
define("CONTENT_ADMIN_OPT_LAN_82", "testo");
define("CONTENT_ADMIN_OPT_LAN_83", "aggiungi link al suffisso");
define("CONTENT_ADMIN_OPT_LAN_84", "visualizza oggetto principale (parent)");
define("CONTENT_ADMIN_OPT_LAN_85", "visualizza sottocategoria principale (parent)");
define("CONTENT_ADMIN_OPT_LAN_86", "visualizza oggetti di sottocategorie principali (parent)");
define("CONTENT_ADMIN_OPT_LAN_87", "Se abilitato tutti gli oggetti della categoria selezionata e quelli della categoria sottolineata verranno mostrati.");
define("CONTENT_ADMIN_OPT_LAN_88", "definire ordine di visualizzazione di oggetti parent and child");
define("CONTENT_ADMIN_OPT_LAN_89", "prima parents, quindi oggetti");
define("CONTENT_ADMIN_OPT_LAN_90", "oggetti prima, quindi parents");
define("CONTENT_ADMIN_OPT_LAN_91", "Tipo di renderizzazione per parent, sub e oggetti");
define("CONTENT_ADMIN_OPT_LAN_92", "ognuno in un men� separato");
define("CONTENT_ADMIN_OPT_LAN_93", "titolo");
define("CONTENT_ADMIN_OPT_LAN_94", "aggiungi box di ricerca");
define("CONTENT_ADMIN_OPT_LAN_95", "aggiungi box per sort e ordinamento");
define("CONTENT_ADMIN_OPT_LAN_96", "mostra links navigatore");
define("CONTENT_ADMIN_OPT_LAN_97", "de disabiliatato tutti i link sotto saranno disgregati");
define("CONTENT_ADMIN_OPT_LAN_98", "link : tutte le categorie");
define("CONTENT_ADMIN_OPT_LAN_99", "link : tutti gli autori");
define("CONTENT_ADMIN_OPT_LAN_100", "link : tutti i contenuti");
define("CONTENT_ADMIN_OPT_LAN_101", "link : pi� valutati");
define("CONTENT_ADMIN_OPT_LAN_102", "link : maggior punteggio");
define("CONTENT_ADMIN_OPT_LAN_103", "link : contenuti recenti");
define("CONTENT_ADMIN_OPT_LAN_104", "link : invia contenuto");
define("CONTENT_ADMIN_OPT_LAN_105", "icona : links");
define("CONTENT_ADMIN_OPT_LAN_106", "nesuma (), bullet (), middot (&middot;), white bullet (�), freccia (&raquo;), category_icon()");
define("CONTENT_ADMIN_OPT_LAN_107", "nessuna");
define("CONTENT_ADMIN_OPT_LAN_108", "bullet");
define("CONTENT_ADMIN_OPT_LAN_109", "middot");
define("CONTENT_ADMIN_OPT_LAN_110", "white bullet");
define("CONTENT_ADMIN_OPT_LAN_111", "freccia");
define("CONTENT_ADMIN_OPT_LAN_112", "icona categoria");
define("CONTENT_ADMIN_OPT_LAN_113", "icona contenuti");
define("CONTENT_ADMIN_OPT_LAN_114", "tipo di renderizzazione per i links");
define("CONTENT_ADMIN_OPT_LAN_115", "Titolo per la lista link");
define("CONTENT_ADMIN_OPT_LAN_116", "questo titolo verr� usato solamente se i links sono visualizzati come 'normallinks'.");
define("CONTENT_ADMIN_OPT_LAN_117", "visualizza categorie");
define("CONTENT_ADMIN_OPT_LAN_118", "includi categoria principale");
define("CONTENT_ADMIN_OPT_LAN_119", "Se disabilitato verranno visualizzate solo le sotto categorie incluse nella principale");
define("CONTENT_ADMIN_OPT_LAN_120", "visualizza numero di contenuti in ogni categoria");
define("CONTENT_ADMIN_OPT_LAN_121", "icona: categoria");
define("CONTENT_ADMIN_OPT_LAN_122", "icona: categoria (default)");
define("CONTENT_ADMIN_OPT_LAN_123", "Tipo renderizzazione della lista categorie");
define("CONTENT_ADMIN_OPT_LAN_124", "titolo lista categorie");
define("CONTENT_ADMIN_OPT_LAN_125", "visualizza contenuti recenti");
define("CONTENT_ADMIN_OPT_LAN_126", "visualizza data");
define("CONTENT_ADMIN_OPT_LAN_127", "visualizza autore");
define("CONTENT_ADMIN_OPT_LAN_128", "visualizza sottointestazione");
define("CONTENT_ADMIN_OPT_LAN_129", "sottointestazione : definire numero di parole");
define("CONTENT_ADMIN_OPT_LAN_130", "sottointestazione : definire suffisso");
define("CONTENT_ADMIN_OPT_LAN_131", "quanti contenuti visualizzare?");
define("CONTENT_ADMIN_OPT_LAN_132", "icone per contenuti recenti");
define("CONTENT_ADMIN_OPT_LAN_133", "icona : larghezza");
define("CONTENT_ADMIN_OPT_LAN_134", "se scelto 'icone contenuti', definiscela larghezza delle icone da usare");
define("CONTENT_ADMIN_OPT_LAN_135", "titolo lista contenuti recenti");
define("CONTENT_ADMIN_OPT_LAN_136", "");
define("CONTENT_ADMIN_OPT_LAN_137", "");
define("CONTENT_ADMIN_OPT_LAN_138", "");
define("CONTENT_ADMIN_OPT_LAN_139", "");

?>
