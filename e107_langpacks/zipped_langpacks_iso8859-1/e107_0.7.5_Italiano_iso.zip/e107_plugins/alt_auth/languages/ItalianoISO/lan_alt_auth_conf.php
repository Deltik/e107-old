<?php
define("LAN_ALT_1", "Tipo di autorizzazione corrente");
define("LAN_ALT_2", "Aggiorna Impostazioni");
define("LAN_ALT_3", "Scegli un tipo di Autorizzazione Alternativa");
define("LAN_ALT_4", "Configura i parametri per");
define("LAN_ALT_5", "Configura i paramteri di autorizzazione");
define("LAN_ALT_6", "Connessione fallita");
define("LAN_ALT_7", "If connection to the alternate method fails, how should that be handled?");
define("LAN_ALT_8", "User not found action");
define("LAN_ALT_9", "If username is not found using alternate method, how should that be handled?");

define("LAN_ALT_FALLBACK", "Usa tabelle utenti e107");
define("LAN_ALT_FAIL", "Login Fallito");

?>
