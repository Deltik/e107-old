<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/07 02:54:20 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/

define("TREE_L1", "Configura Tree Men�");
define("TREE_L2", "Aggiorna Impostazioni Tree Men�");
define("TREE_L3", "Configurazione Tree Men� salvata.");
define("TREE_L4", "On");
define("TREE_L5", "Off");
define("TREE_L6", "Classe CSS da usare per link non apribili");
define("TREE_L7", "Classe CSS da usare per Link apribili");
define("TREE_L8", "Classe CSS da usare per links aperti");
define("TREE_L9", "Classe Spazio da usare tra links Principali");

?>