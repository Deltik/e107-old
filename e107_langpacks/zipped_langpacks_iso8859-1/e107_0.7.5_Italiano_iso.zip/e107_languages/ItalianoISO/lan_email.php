<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/07 19:06:54 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Email");

define("LAN_5", "Invia articolo ad un amico");
define("LAN_6", "Invia news ad un amico");
define("LAN_7", "Nome di Login: ");
define("LAN_8", "Commento");
define("LAN_9", "Invia commento");
define("LAN_10", "Email inviata a");
define("LAN_11", "Email inviata");
define("LAN_12", "Errore");
define("LAN_106", "Questo non sembra essere un indirizzo di email valido");
define("LAN_185", "Invia articolo");
define("LAN_186", "Invia News");
define("LAN_187", "Indirizzo Email a cui inviare");
define("LAN_188", "Penso tu possa essere interessato a questa news pubblicata sul sito");
define("LAN_189", "Penso tu possa essere interessato a questo articolo pubblicato sul sito");

define("LAN_email_1", "Da:");
define("LAN_email_2", "Indirizzo IP dell'inviante:");
define("LAN_email_3", "Oggetto inviato da ");
define("LAN_email_4", "Invia Email");
define("LAN_email_5", "Invia oggetto ad un amico");
define("LAN_email_6", "Penso tu possa essere interessato a questo oggetto rintracciato nel sito");
define("LAN_email_7", "invia per email")
?>
