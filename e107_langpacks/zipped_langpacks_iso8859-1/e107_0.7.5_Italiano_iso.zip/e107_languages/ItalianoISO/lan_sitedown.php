<?php
/*+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+*/
define("PAGE_NAME", "Sito temporaneamente chiuso");
define("LAN_00", "� temporaneamente chiuso");
define("LAN_01", "Il sito � temporaneamente chiuso per Manutenzione. Il sito sar� riaperto nel pi� breve tempo possibile - Arrivederci a presto, ci scusiamo per l'inconveniente.");
?>