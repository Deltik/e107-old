<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_links.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Links");

define("LAN_61", "Categorie Link");
define("LAN_62", "Categorie");
define("LAN_63", "Categoria");
define("LAN_64", "in questa categoria");
define("LAN_65", "link");
define("LAN_66", "links");
define("LAN_67", "Mostra tutti i Links");
define("LAN_68", "Edita");
define("LAN_69", "Cancella");
define("LAN_86", "Categoria:");
define("LAN_88", "Referrals:");
define("LAN_89", "Amministratore: ");
define("LAN_90", "Aggiungi un nuovo link in questa categoria");
define("LAN_91", "Aggiungi nuova categoria");

define("LAN_92", "Invia un link");
define("LAN_93", "Dopo che avrai segnalato il tuo link esso verr� sottoposto alla valutazione dell'Amministratore e, se ritenuto valido, verr� pubblicato nella pagina dei Links.");
define("LAN_94", "Nome Link:");
define("LAN_95", "URL Link :");
define("LAN_96", "Descrizione Link :");
define("LAN_97", "URL del pulsante link:");
define("LAN_98", "Invia Link");

define("LAN_99", "Grazie");
define("LAN_100", "Il tuo link � stato salvato e verr� sottoposto alla valutazione dell'Amministratore.");
define("LAN_101", "Clicca qui per segnalare un link");

define("LAN_102", "");
define("LAN_103", "C'�");
define("LAN_104", "Ci sono");
define("LAN_105", "in totale");
define("LAN_106", "I Campi sottolineati sono richiesti.");

define("LAN_Links_1", "Totale links");
define("LAN_Links_2", "Totale links attivati");
define("LAN_LINKS_3", "Anonimo");
?>
