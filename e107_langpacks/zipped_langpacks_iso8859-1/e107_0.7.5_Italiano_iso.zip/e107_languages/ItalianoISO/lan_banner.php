<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner");

define("LAN_16", "Utente: ");
define("LAN_17", "Password: ");
define("LAN_18", "Continua");
define("LAN_19", "Inserisci il tuo login e password per continuare");
define("LAN_20", "Spiacente, impossibile trovare questi dettagli nel database. Contatta l'amministratore per chiarimenti.");
define("LAN_21", "Statistiche Banner");
define("LAN_22", "Cliente");
define("LAN_23", "ID Banner");
define("LAN_24", "Click");
define("LAN_25", "Click %");
define("LAN_26", "Esposizioni");
define("LAN_27", "Esposizioni acquistate");
define("LAN_28", "Esposizioni Rimaste");
define("LAN_29", "Nessun Banner");
define("LAN_30", "Infinito");
define("LAN_31", "Non applicabile");
define("LAN_32", "S�");
define("LAN_33", "No");
define("LAN_34", "Finiti:");
define("LAN_35", "Indirizzo IP Click");
define("LAN_36", "Attivo:");
define("LAN_37", "Inizio:");
define("LAN_38", "Errore");

?>