<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/30 19:36:50 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team ttp://www.e107it.0rg
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Messaggi Utente");

define("UP_LAN_0", "Tutti i messaggi forum di ");
define("UP_LAN_1", "Tutti i commenti di ");
define("UP_LAN_2", "Discussioni");
define("UP_LAN_3", "Viste");
define("UP_LAN_4", "Risposte");
define("UP_LAN_5", "Ultimo messaggio");
define("UP_LAN_6", "Discussioni");
define("UP_LAN_7", "Non ci sono commenti");
define("UP_LAN_8", "Non ci sono messaggi");
define("UP_LAN_9", " on ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Scritto il: ");
define("UP_LAN_12", "Cerca");
define("UP_LAN_13", "Commenti");
define("UP_LAN_14", "Messaggi Forum");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "Indirizzo IP");
