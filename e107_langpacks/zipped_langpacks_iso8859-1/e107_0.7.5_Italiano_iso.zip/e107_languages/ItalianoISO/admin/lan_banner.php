<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banner.php,v $
|     $Revision: 1.10 $
|     $Date: 2005/06/22 22:21:37 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg
+----------------------------------------------------------------------------+
*/
define("BNRLAN_1", "Banner eliminato.");
define("BNRLAN_2", "Conferma eliminazione del banner - una volta eliminato non potr� essere recuperato");
define("BNRLAN_3", "Cancella");
define("BNRLAN_4", "Conferma Eliminazione");
define("BNRLAN_5", "Conferma Eliminazione Banner");
define("BNRLAN_6", "Eliminazione Annullata."); 
define("BNRLAN_7", "Banner Esistenti");
define("BNRLAN_8", "Banner ID");
define("BNRLAN_9", "Cliente");
define("BNRLAN_10", "Click");
define("BNRLAN_11", "Click %");
define("BNRLAN_12", "Esposizioni");
define("BNRLAN_13", "Esposizioni Rimanenti");

define("BNRLAN_15", "Ancora nessun Banner.");
define("BNRLAN_16", "Illimitato");
define("BNRLAN_17", "Nessuno");

define("BNRLAN_21", "Finito");
define("BNRLAN_22", "Aggiorna Banner");
define("BNRLAN_23", "Aggiungi Nuovo Banner");
define("BNRLAN_24", "Campagna");
define("BNRLAN_25", "Scegli campagna esistente");
define("BNRLAN_26", "inserisci nuova campagna");
define("BNRLAN_27", "Cliente");
define("BNRLAN_28", "scegli cliente");
define("BNRLAN_29", "inserisci nuovo");
define("BNRLAN_30", "Login Cliente");
define("BNRLAN_31", "Password Cliente");
define("BNRLAN_32", "Immagine Banner");
define("BNRLAN_33", "Click URL");
define("BNRLAN_34", "Esposizioni acquistate");
define("BNRLAN_35", "illimitato");
define("BNRLAN_36", "Data Inizio");
define("BNRLAN_37", "Data Fine");
define("BNRLAN_38", "bianco = nessun limite");
define("BNRLAN_39", "Attivo");
define("BNRLAN_40", "Aggiorna Banner");
define("BNRLAN_41", "Crea Nuovo Banner");
define("BNRLAN_42", "Sistema Rotazione Banner");
define("BNRLAN_43", "Scegli immagine banner");

define("BNRLAN_45", "Avviato");
define("BNRLAN_46", "Codice");

define("BNRLAN_58", "Home Banner");
define("BNRLAN_59", "Crea nuovo banner");
define("BNRLAN_60", "Campagne");
define("BNRLAN_61", "Men� banner");
define("BNRLAN_62", "Opzioni banner");
define("BNRLAN_63", "Banner Creato");
define("BNRLAN_64", "Banner Aggiornato");

define("BANNER_MENU_L1", "Avviso");
define("BANNER_MENU_L2", "Men� configurazione Banner aggiornato");

//v.617

define("BANNER_MENU_L3", "Titolo");
define("BANNER_MENU_L5", "Configurazione Banner"); 
define("BANNER_MENU_L6", "scegli la campagna da mostrare nel men�");
define("BANNER_MENU_L7", "campagne disponibili");
define("BANNER_MENU_L8", "campagne selezionate");
define("BANNER_MENU_L9", "rimuovi la selezione");
define("BANNER_MENU_L10", "Tipo di Render");
define("BANNER_MENU_L12", "plain");
define("BANNER_MENU_L13", "in captioned box");
define("BANNER_MENU_L18", "Aggiorna Impostazioni Men�");

?>

