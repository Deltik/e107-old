<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_e107_update.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/21 16:15:28 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg	
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Azione");
define("LAN_UPDATE_3", "Non Necessario");
define("LAN_UPDATE_5", "Aggiornamento Disponibile");
define("LAN_UPDATE_6", "Aggiorna Tutto");
define("LAN_UPDATE_7", "Eseguito");
define("LAN_UPDATE_8", "Aggiornato da");
define("LAN_UPDATE_9", "a");
define("LAN_UPDATE_10", "Aggiornamenti disponibili");
define("LAN_UPDATE_11", "da .617 a .7 Aggiornamento Continuato")
?>