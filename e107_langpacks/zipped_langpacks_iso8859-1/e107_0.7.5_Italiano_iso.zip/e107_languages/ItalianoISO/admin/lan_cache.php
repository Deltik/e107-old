<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg	
+----------------------------------------------------------------------------+
*/

define("CACLAN_1", "Impostazione Cache di Sistema");
define("CACLAN_2", "Imposta stato Cache");
define("CACLAN_3", "Sistema Cache");
define("CACLAN_4", "Stato Cache impostata");
define("CACLAN_5", "Svuota Cache");
define("CACLAN_6", "Cache Svuotata");
define("CACLAN_7", "Cache Disabilitata");
define("CACLAN_8", "Dati Cache salvati in MySQL");
define("CACLAN_9", "Dati Cache salvati su file");
define("CACLAN_10", "La cartella della Cache non � scrivibile. Assicurati che i permessi siano settati CHMOD 777");
?>
