<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_menus.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/11/24 15:03:58 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Visibile a tutti");
define("MENLAN_2", "Visibile solo agli Utenti");
define("MENLAN_3", "Visibile solo agli Amministratori");
define("MENLAN_4", "Visibile solo a:");
//define("MENLAN_5", "gruppo");
define("MENLAN_6", "Salva opzioni visibilit�");
define("MENLAN_7", "Configura opzioni visibilit� per");
define("MENLAN_8", "Opzioni visibilit� aggiornate");
define("MENLAN_9", "Installato nuovo Blocco Personalizzato");
define("MENLAN_10", "Installato nuovo Blocco");
define("MENLAN_11", "Blocco cancellato");
define("MENLAN_12", "Attiva questo Blocco - scegli posizione");
define("MENLAN_13", "Attiva in Area");
define("MENLAN_14", "Attiva in Area");
define("MENLAN_15", "Disattiva");
define("MENLAN_16", "Configura");
define("MENLAN_17", "Sposta su");
define("MENLAN_18", "Sposta gi�");
define("MENLAN_19", "Sposta nell'Area");
define("MENLAN_20", "Visibilit�");
//define("MENLAN_21", "Visibile solo agli Ospiti");
define("MENLAN_22", "Blocchi inattivi");
define("MENLAN_23", "Sposta in Basso");
define("MENLAN_24", "Sposta in Alto");
define("MENLAN_25", "Funzione ...");
define("MENLAN_26", "Questo Blocco sar� <strong>VISUALIZZATO</strong> nelle seguenti pagine");
define("MENLAN_27", "Questo Blocco sar�  <strong>NASCOSTO</strong> nelle seguenti pagine");
define("MENLAN_28", "Inserisci una pagina per riga, digitando l'url per riconoscerla in modo corretto");
define("MENLAN_29", "Seleziona Layout");
define("MENLAN_30", "Per vedere i men� e la loro posizione per il layout personalizzato del tema, selezione il layout personalizzato qui:");
define("MENLAN_31", "Layout di Default");
define("MENLAN_32", "Layout Newsheader");
define("MENLAN_33", "Layout Personalizzato");
define("MENLAN_34", "Embedded");
define("MENLAN_35", "Configura i Men�");
define("MENLAN_36", "Scegli i(l) men� da attivare");
define("MENLAN_37", "e dove attivarli.");
define("MENLAN_38", "Tieni premuto CTRL per selezionare pi� men�.");
?>