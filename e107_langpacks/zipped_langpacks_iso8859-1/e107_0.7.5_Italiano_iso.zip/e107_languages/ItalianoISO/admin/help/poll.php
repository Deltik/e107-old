<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Da questa pagina puoi impostare i Sondaggi per il sito.<br /> 
1. Scegli il titolo per tuo sondaggio e le varie opzioni di risposta.<br /> 
2. Seleziona Anteprima per controllare le impostazioni scelte.<br />
3. Al termine premi il tasto 'Invia' per renderlo attivo.<br /><br />
Per visualizzare il Sondaggio, vai alla pagina dei Menu e verifica che il blocco Sondaggio
(poll_menu) sia attivato.";

$ns -> tablerender("Sondaggi", $text);
?>
