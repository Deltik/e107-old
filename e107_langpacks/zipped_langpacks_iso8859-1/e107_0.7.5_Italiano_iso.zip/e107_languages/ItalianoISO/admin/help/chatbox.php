<?php
//|     Italian Translation: 
//|           e107 Italian Team http://www.e107it.org
//|           con la collaborazione di Stefano Vecchi

$text = "Imposta da qui le tue preferenze per la chatbox.<br />Se la casella sostituisci link � selezionata, qualunque link inserito verr� sostituito dal testo inserito nel box di testo. Questo eviter� che link troppo lunghi causino problemi al display. Wordwrap sostituir� il testo pi� lungo di quanto qui specificato.";

$ns -> tablerender("Chatbox", $text);
?>
