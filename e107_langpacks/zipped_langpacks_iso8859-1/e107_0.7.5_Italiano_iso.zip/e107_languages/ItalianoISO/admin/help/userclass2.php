<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org

$caption = "Help Gruppo Utenti";

$text = "Da questa pagina puoi creare i Gruppi Utente, editare o cancellare gruppi esistenti.<br />
Ci� pu� essere utile per riservare alcune parti del tuo sito solo ad alcuni gruppi di utenti.
Per esempio, potresti creare un gruppo denominato TEST, e successivamente creare un Forum 
il cui accesso � riservato solo agli Utenti di tale gruppo.";

$ns -> tablerender($caption, $text);
?>
