<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Se stai facendo un aggiornamento del Sistema oppure hai necessit� che il sito 
sia offline per un breve periodo, seleziona il box 'Attiva flag di Manutenzione'. 
I visitatori verranno reindirizzati ad una pagina che spiegher� che il sito � momentaneamente
chiuso per manutenzione. Quando lo riterrai opportuno, deseleziona il box e il sito torner� 
ad essere normalmente visitabile.";

$ns -> tablerender("Manutenzione", $text);
?>
