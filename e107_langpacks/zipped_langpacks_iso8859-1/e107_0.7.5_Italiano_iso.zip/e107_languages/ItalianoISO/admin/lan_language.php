<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_language.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/15 19:11:12 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00","non pu� essere creato.(gi� esistente)");
define("LANG_LAN_01","eliminato (se esistente) e creato.");
define("LANG_LAN_02","non pu� essere eliminato");
define("LANG_LAN_03","Tabelle");

define("LANG_LAN_05","Non Intallate");
define("LANG_LAN_06", "Crea tabelle");
define("LANG_LAN_07", "Eseguire Drop delle tabelle esitenti?");
define("LANG_LAN_08", "Sovrascrizione delle tabelle esistenti (i dati andranno perduti).");
define("LANG_LAN_10", "Conferma eliminazione");
define("LANG_LAN_11", "Elimina le tabelle non elezionate sopra (se esitono).");
define("LANG_LAN_12", "Abiltita Tabelle Multi-Linguaggio");
define("LANG_LAN_13", "Preferenze Multi-Languaggio");
define("LANG_LAN_14", "Linguaggio di default del sito");
define("LANG_LAN_15", "Spunta per copiare i dati dal linguaggio di default (utile per links, Categorie news etc) ");
define("LANG_LAN_16", "Utilizzo Database Multi-linguaggio"); 
?>
