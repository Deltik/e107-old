<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_wmessage.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Messaggio per Ospiti");
// define("WMGLAN_2", "Messaggio per Utenti");
// define("WMGLAN_3", "Messaggio per Amministratori");
// define("WMGLAN_4", "Invia");
// define("WMGLAN_5", "Imposta Messaggio di benvenuto");
// define("WMGLAN_6", "Attivi?");
// define("WMGLAN_7", "Impostazioni Messaggio di Benvenuto aggiornate.");

define("WMLAN_00","Messaggi di Benvenuto");
define("WMLAN_01","Crea Nuovo Messaggio");
define("WMLAN_02","Messaggio");
define("WMLAN_03","Visibilit�");
define("WMLAN_04","Testo del Messaggio");

define("WMLAN_05","Cornice");
define("WMLAN_06","Se selezionato, il messaggio verr� visualizzato all'interno di una cornice");
define("WMLAN_07","Sostituisci il sistema standard usando {WMESSAGE} shortcode:");
define("WMLAN_08","Preferenze");

define("WMLAN_09","Nessun Messaggio impostato");
define("WMLAN_10","Titolo Messaggio");    

?>
