<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_emoticon.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107it.0rg
+----------------------------------------------------------------------------+
*/

define("EMOLAN_1", "Attivazione Faccine.");
define("EMOLAN_2", "Nome.");
define("EMOLAN_3", "Faccine.");
define("EMOLAN_4", "Attivare le Faccine?");
define("EMOLAN_5", "Immagine");
define("EMOLAN_6", "Codice Faccina");
define("EMOLAN_7", "Separa inserimenti multipli con spazi");
define("EMOLAN_8", "Status");
define("EMOLAN_9", "Opzioni");
define("EMOLAN_10", "Attiva");
define("EMOLAN_11", "Set Attivo");

define("EMOLAN_12", "Modifica / configura questo set");
define("EMOLAN_13", "Set Installato");


?>
