<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_dl_61", "Error de descarga");
define("LAN_dl_62", "No se ha permitido la descarga. Ha sobrepasado el l�mite de la cuota de transferencia");
define("LAN_dl_63", "No tiene los suficientes permisos para descargar el archivo.");
define("LAN_dl_64", "Atr�s");
define("LAN_dl_65", "Fichero no encontrado");
?>