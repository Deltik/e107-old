<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/help/content.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Puede a�adir una p�gina normal a su sitio usando esta caracter�stica.
Se crear� un link a la nueva p�gina en el men� de navegaci�n de su sitio.
Por ejemplo si crea una p�gina nueva con el Nombre del Enlace 'Prueba', un enlace llamado 'Prueba'
aparecer� en su men� de navegaci�n luego de enviar la p�gina nueva.<br />
Si desea que su p�gina de contenidos tenga un t�tulo, introd�zcalo en la caja de Encabezado de P�gina.";
$ns -> tablerender("Ayuda Contenidos", $text);
?>