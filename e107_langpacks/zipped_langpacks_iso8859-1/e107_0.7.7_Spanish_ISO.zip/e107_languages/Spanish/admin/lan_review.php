<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_review.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("REVLAN_1", "Revisi�n a�adida a la base de datos.");
define("REVLAN_2", "Campos en blanco.");
define("REVLAN_3", "Revisi�n actualizada en base de datos.");
define("REVLAN_4", "Revisi�n borrada.");
define("REVLAN_5", "Por favor, marca la casilla de confirmaci�n para borrar esta revisi�n");
define("REVLAN_6", "No hay revisiones a�n.");
define("REVLAN_7", "Revisiones existentes");
define("REVLAN_8", "Editar");
define("REVLAN_9", "Borrar");
define("REVLAN_10", "Confirmar");
define("REVLAN_11", "Abrir editor HTML");
define("REVLAN_12", "Encabezado");
define("REVLAN_13", "Sub-Encabezado");
define("REVLAN_14", "Resumen");
define("REVLAN_15", "Revisi�n");
define("REVLAN_16", "Puntuaci�n");
define("REVLAN_17", "Selecciona puntuaci�n");
define("REVLAN_18", "�Permitir comentarios?");
define("REVLAN_19", "Si");
define("REVLAN_20", "No");
define("REVLAN_21", "Visible a");
define("REVLAN_22", "Actualizar revisi�n");
define("REVLAN_23", "Enviar revisi�n");
define("REVLAN_24", "Revisiones");
define("REVLAN_25", "Categor�a de revisiones guardada");
define("REVLAN_26", "Categor�a de revisiones actualizada");
define("REVLAN_27", "Categor�a borrada");
define("REVLAN_28", "Categor�a");
define("REVLAN_29", "Opciones");
define("REVLAN_30", "Editar");
define("REVLAN_31", "Borrar");
define("REVLAN_32", "No hay categor�as de revisiones");
define("REVLAN_33", "Categor�as de revisiones");
define("REVLAN_34", "Nombre de la Categor�a");
define("REVLAN_35", "Icono de la Categor�a");
define("REVLAN_36", "Ver im�genes");
define("REVLAN_37", "Resumen de la Categor�a");
define("REVLAN_38", "Actualizar categor�a de revisiones");
define("REVLAN_39", "Crear categor�a de revisiones");
define("REVLAN_40", "No hay revisiones");
define("REVLAN_41", "Revisiones");
define("REVLAN_42", "Abrir editor HTML");
define("REVLAN_43", "Categor�a");
define("REVLAN_44", "Nada");
define("REVLAN_45", "P�gina principal de revisiones");
define("REVLAN_46", "Crear nueva revisi�n");
define("REVLAN_47", "Categor�as");
define("REVLAN_48", "Opciones de revisi�n");
define("REVLAN_49", "�Est� seguro de querer borrar esta categor�a?");
define("REVLAN_50", "�Est� seguro de querer borrar esta revisi�n?");
define("REVLAN_51", "Detalles del autor");
define("REVLAN_52", "Deje en blanco si la revisi�n la ha escrito usted");
define("REVLAN_53", "Nombre del autor");
define("REVLAN_54", "Email del autor");
define("REVLAN_55", "Permitir enviar revisiones");
define("REVLAN_56", "Permitir a los invitados enviar revisiones");
define("REVLAN_57", "Clase de envio de revisiones");
define("REVLAN_58", "Seleccione que usuarios podr�n enviar revisiones");
define("REVLAN_59", "Actualizar opciones");
define("REVLAN_60", "Opciones de revisiones");
define("REVLAN_61", "Opciones de revisiones actualizadas");
define("REVLAN_62", "Revisiones enviadas");
define("REVLAN_63", "No hay revisiones enviadas");
define("REVLAN_64", "No se ha proporcionado email");
define("REVLAN_65", "Titular");
define("REVLAN_66", "Enviado");
define("REVLAN_67", "Revisi�n enviada por usuario");
define("REVLAN_68", "Revisi�n enviada por usuario guardada en la base de datos");
define("REVLAN_69", "Limpiar");
define("REVLAN_70", "Rellenar campos de autor");
define("REVLAN_71", "�A�adir iconos email/impresora?");
define("REVLAN_72", "Si");
define("REVLAN_73", "No");
?>