<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_cpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "T�tulo");
define("CUSLAN_2", "Tipo");
define("CUSLAN_3", "Opciones");
define("CUSLAN_4", "�Borrar esta p�gina?");
define("CUSLAN_5", "P�ginas existentes");
define("CUSLAN_7", "Nombre men�");
define("CUSLAN_8", "Texto t�tulo");
define("CUSLAN_9", "Texto");
define("CUSLAN_10", "Permitir valorar p�gina");
define("CUSLAN_11", "Pantalla");
define("CUSLAN_12", "Crear p�gina");
define("CUSLAN_13", "Permitir comentarios");
define("CUSLAN_14", "Contrase�a de la p�gina");
define("CUSLAN_15", "Escriba una contrase�a para proteger la p�gina");
define("CUSLAN_16", "Crear enlace en el men� principal");
define("CUSLAN_17", "Escriba un nombre de enlace a crear");
define("CUSLAN_18", "P�gina visible a");
define("CUSLAN_19", "Actualizar p�gina");
define("CUSLAN_20", "Crear p�gina");
define("CUSLAN_21", "Actualizar men�");
define("CUSLAN_22", "Crear men�");
define("CUSLAN_23", "Editar p�gina");
define("CUSLAN_24", "Crear nueva p�gina");
define("CUSLAN_25", "Editar men�");
define("CUSLAN_26", "Crear nuevo men�");
define("CUSLAN_27", "P�gina guardada en la Base de Datos.");
define("CUSLAN_28", "P�gina borrada");
define("CUSLAN_29", "Lista de p�ginas si no seleccion� una p�gina");
define("CUSLAN_30", "Tiempo de la expiraci�n de la cookie (en segundos)");
define("CUSLAN_31", "Crear men�");
define("CUSLAN_32", "Convertir viejas p�ginas/men�s");
define("CUSLAN_33", "Opciones de p�gina");
define("CUSLAN_34", "Comenzando conversi�n");
define("CUSLAN_35", "Actualizaci�n finalizada en la p�gina personalizada");
define("CUSLAN_36", "Para fijar sus preferencias por cada p�gina, vuelva a la p�gina de trabajo y edite las p�ginas.");
define("CUSLAN_37", "P�gina personalizada actualizada");
define("CUSLAN_38", "On");
define("CUSLAN_39", "Off");
define("CUSLAN_40", "Guardar opciones");
define("CUSLAN_41", "Mostrar informaci�n de autor y fecha");
define("CUSLAN_42", "No hay p�ginas definidas todav�a");

?>