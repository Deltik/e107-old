<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/admin/lan_ugflag.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:49 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Configuraci�n de mantenimiento actualizada");
define("UGFLAN_2", "Activado aviso de mantenimiento");
define("UGFLAN_3", "Actualizar configuraci�n de mantenimiento");
define("UGFLAN_4", "Configuraci�n de Mantenimiento");
define("UGFLAN_5", "Texto a mostrar cuando el sitio est� en mantenimiento");
define("UGFLAN_6", "Deje en blanco para mostrar el mensaje por defecto");
?>