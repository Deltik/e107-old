<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Historia de la noticia borrada.");
define("NWSLAN_2", "Active para borrarlo.");
define("NWSLAN_3", "Sin noticias todav�a.");
define("NWSLAN_4", "Noticias existentes");
define("NWSLAN_5", "Abrir editor HTML");
define("NWSLAN_6", "Categor�a");
define("NWSLAN_7", "Editar");
define("NWSLAN_8", "Eliminar");
define("NWSLAN_9", "Active para confirmar");
define("NWSLAN_10", "Sin categor�as fijadas todav�a.");
define("NWSLAN_11", "A�adir/Editar categor�as");
define("NWSLAN_12", "T�tulo");
define("NWSLAN_13", "Cuerpo");
define("NWSLAN_14", "Ampliado");
define("NWSLAN_15", "Comentarios");
define("NWSLAN_16", "Activado");
define("NWSLAN_17", "Desactivado");
define("NWSLAN_18", "Permitir enviar comentarios a esta noticia");
define("NWSLAN_19", "Activaci�n");
define("NWSLAN_20", "Dejar en blanco para desactivar la auto-activaci�n");
define("NWSLAN_21", "Activar entre");
define("NWSLAN_22", "Ver");
define("NWSLAN_23", "Activo har� que la noticia sea visible solo a usuarios de esa clase");
define("NWSLAN_24", "Volver a previsualizar");
define("NWSLAN_25", "Noticia actualizada en la BD");
define("NWSLAN_26", "Enviar noticia a la BD");
define("NWSLAN_27", "Previsualizar");
define("NWSLAN_28", "Nueva historia");
define("NWSLAN_29", "Envios de noticias");
define("NWSLAN_30", "Mostrar solo el t�tulo");

?>