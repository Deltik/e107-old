<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "Sitio e107");
define("LAN_PREF_2", "Portal de  Gesti�n e107");
define("LAN_PREF_3", "Todas las marcas est�n registradas � a sus respectivos propietarios, y todo el contenido est� soportado bajo el portal de contenidos � e107.<br />e107 es � e107.org 2002-2005 y ha sido distribu�do bajo <a href=\"http://www.gnu.org/\" rel=\"external\">Licencia GNU GPL</a>.");
define("LAN_PREF_4", "censurado");
define("LAN_PREF_5", "Foros");

?>