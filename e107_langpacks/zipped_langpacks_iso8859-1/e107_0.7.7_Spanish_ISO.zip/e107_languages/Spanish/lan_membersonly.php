<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/12 01:23:56 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Solo miembros");
define("LAN_MEMBERS_0", "�rea restringida");
define("LAN_MEMBERS_1", "Este es un �rea restringida");
define("LAN_MEMBERS_2","Para acceder, por favor <a href='".e_LOGIN."'>con�ctese</a>");
define("LAN_MEMBERS_3","o <a href='".e_SIGNUP."'>reg�strese</a> como miembro");
define("LAN_MEMBERS_4","Volver a la p�gina de inicio");

?>