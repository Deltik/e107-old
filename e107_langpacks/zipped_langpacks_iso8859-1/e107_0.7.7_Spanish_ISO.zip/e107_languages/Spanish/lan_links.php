<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_languages/Spanish/lan_links.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/10 19:17:11 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Enlaces");

define("LAN_61", "Categor�as de enlace");
define("LAN_62", "Categor�as");
define("LAN_63", "Categor�a");
define("LAN_64", "En esta categor�a");
define("LAN_65", "Enlace");
define("LAN_66", "Enlaces");
define("LAN_67", "Ver todos los enlaces");
define("LAN_68", "Editar");
define("LAN_69", "Borrar");

define("LAN_86", "Categor�a:");

define("LAN_88", "Referidos:");
define("LAN_89", "Administrador: ");
define("LAN_90", "A�adir un enlace a esta categor�a");
define("LAN_91", "A�adir nueva categor�a");
define("LAN_92", "Enviar un enlace");
define("LAN_93", "Su enlace ser� revisado antes de ser admitido.");
define("LAN_94", "Nombre:");
define("LAN_95", "URL:");
define("LAN_96", "Descripci�n:");
define("LAN_97", "URL al bot�n del enlace:");
define("LAN_98", "Enviar enlace");
define("LAN_99", "Gracias");
define("LAN_100", "Su enlace ha sido guardado y ser� revisado por un administrador.");
define("LAN_101", "Pulse aqu� si desea enviar un enlace.");
define("LAN_102", "Hay");
define("LAN_103", "es");
define("LAN_104", "son");
define("LAN_105", "en total");
define("LAN_106", "Los campos subrayados son obligatorios.");

define("LAN_Links_1", "Total enlaces");
define("LAN_Links_2", "Total enlaces activos");
define("LAN_LINKS_3", "An�nimo");
?>