<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/counter_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "Las visitas del Admin no se contabilizan.");
define("COUNTER_L2", "Esta p�gina hoy ...");
define("COUNTER_L3", "Total");
define("COUNTER_L4", "Esta p�gina siempre ...");
define("COUNTER_L5", "�nica");
define("COUNTER_L6", "Sitio ...");
define("COUNTER_L7", "Contador");
define("COUNTER_L8", "Mensaje del Admin: <b>El registro de estad�sticas est� desactivado.</b><br />Para activarlo, necesita instalar el plugin de registro de estad�sticas desde el <a href='".e_ADMIN."plugin.php'>gestor de plugins</a>, y luego activarlo desde la <a href='".e_PLUGIN."log/admin_config.php'>pantalla de configuraci�n</a>.");
?>