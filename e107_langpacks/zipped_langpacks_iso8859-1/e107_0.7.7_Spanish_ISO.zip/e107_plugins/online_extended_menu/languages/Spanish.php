<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/online_extended_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Invitados: ");
define("ONLINE_EL2", "Miembros: ");
define("ONLINE_EL3", "en esta p�gina: ");
define("ONLINE_EL4", "En linea");
define("ONLINE_EL5", "Miembros");
define("ONLINE_EL6", "�ltimo miembro");
define("ONLINE_EL7", "viendo");
define("ONLINE_EL8", "M�ximo de visitas ");
define("ONLINE_EL9", "el");

define("TRACKING_MESSAGE", "Tracking online de usuario desactivado. Act�velo <a href='".e_ADMIN."users.php?options'>aqu�</a></span><br />");
?>