<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/content/languages/Spanish/lan_content_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/09/18 19:53:16 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Contenidos");
define("CONT_SCH_LAN_2", "Todas las categor�as de contenidos");
define("CONT_SCH_LAN_3", "Enviado en respuesta al elemento");
define("CONT_SCH_LAN_4", "en");
?>