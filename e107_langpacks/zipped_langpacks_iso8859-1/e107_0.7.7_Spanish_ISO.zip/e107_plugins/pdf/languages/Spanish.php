<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_plugins/pdf/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/16 23:45:35 $
|     $Author: natxocc $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Soporte de creaci�n de PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Este plugin esta listo para ser usado.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Preferencias PDF");
define("PDF_LAN_3", "Activado");
define("PDF_LAN_4", "Desactivado");
define("PDF_LAN_5", "Margen de pag. izquierda");
define("PDF_LAN_6", "Margen de pag. derecha");
define("PDF_LAN_7", "Margen de pag. arriba");
define("PDF_LAN_8", "Tipo de fuente");
define("PDF_LAN_9", "Tama�o fuente por def.");
define("PDF_LAN_10", "Tipo fuente del sitio");
define("PDF_LAN_11", "Tama�o fuente pag. url");
define("PDF_LAN_12", "Tama�o fuente n�mero de pag.");
define("PDF_LAN_13", "�Mostrar logo en el pdf?");
define("PDF_LAN_14", "�Mostrar nombre del sitio en el PDF?");
define("PDF_LAN_15", "�Mostrar creador de la p�gina en el PDF?");
define("PDF_LAN_16", "�Mostrar numeros de p�gina en el PDF?");
define("PDF_LAN_17", "Actualizar");
define("PDF_LAN_18", "Prferencias de PDF actualizadas correctamente");
define("PDF_LAN_19", "P�gina");
define("PDF_LAN_20", "Informe error");
?>