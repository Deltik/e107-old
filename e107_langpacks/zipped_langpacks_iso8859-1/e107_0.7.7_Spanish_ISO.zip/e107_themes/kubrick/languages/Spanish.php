<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/kubrick/languages/Spanish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' por <a href='http://e107.org' rel='external'>jalist</a>, Basado en el original theme de Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>).");
define("LAN_THEME_2", "Comentarios desactivados ");
define("LAN_THEME_3", "Comentario(s):");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");


?>