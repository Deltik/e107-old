<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/khatru/languages/Spanish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/11/11 23:57:58 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'khatru' por <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Comentarios desactivados para este art�culo");
define("LAN_THEME_3", "Comentario: ");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");


?>
