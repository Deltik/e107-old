<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/legacy_langpacks/e107_themes/reline/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/11 11:02:28 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "Comentarios desactivados para este elemento");
define("LAN_THEME_2", "Leer/Enviar comentario:");
define("LAN_THEME_3", "Leer el resto...");
define("LAN_THEME_4", "Trackbacks: ");
define("LAN_THEME_5", "Enviado por");
define("LAN_THEME_6", "el");
define("LAN_THEME_7", "Buscar...");
?>