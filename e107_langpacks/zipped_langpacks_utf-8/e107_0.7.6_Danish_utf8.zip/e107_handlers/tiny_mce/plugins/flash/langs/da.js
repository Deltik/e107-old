// DA_DK lang variables

tinyMCE.addToLang('flash',{
title : 'Ins&#230;t/rediger Flash Film',
desc : 'Ins&#230;t/rediger Flash Film',
file : 'Flash-Fil (.swf)',
size : 'St&#248;rrelse',
list : 'Flash filer',
props : 'Flash egenskaber',
general : 'Generelt'
});