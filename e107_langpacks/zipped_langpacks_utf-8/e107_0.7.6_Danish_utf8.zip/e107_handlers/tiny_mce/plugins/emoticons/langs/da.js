// UK lang variables

tinyMCELang['lang_insert_emoticons_title'] = 'Inds&#230;t smiley';
tinyMCELang['lang_emoticons_desc'] = 'Smileys';