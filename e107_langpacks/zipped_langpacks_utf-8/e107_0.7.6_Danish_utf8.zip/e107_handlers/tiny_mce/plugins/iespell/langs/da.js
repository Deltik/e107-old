// UK lang variables

tinyMCE.addToLang('',{
iespell_desc : 'K&#248;r stave kontrol',
iespell_download : "ieSpell ikke fundet. Klik OK for at g&#229; til download siden."
});