<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Danish/lan_forum_stats.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/06 22:12:03 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("e_PAGETITLE", "Forum statistik");

define("FSLAN_1", "Generelt");
define("FSLAN_2", "Forum åben");
define("FSLAN_3", "Åben for");
define("FSLAN_4", "Total poster");
define("FSLAN_5", "Forum emner");
define("FSLAN_6", "Forum svar");
define("FSLAN_7", "Forum trådvisninger");
define("FSLAN_8", "Database størrelse (kun forum tabeller");
define("FSLAN_9", "Gennemsnitkig række længede i forum tabel");
define("FSLAN_10", "Mest aktive emne");
define("FSLAN_11", "Rank");
define("FSLAN_12", "Emne");
define("FSLAN_13", "Svar");
define("FSLAN_14", "Started af");
define("FSLAN_15", "Dato");
define("FSLAN_16", "Mest viste emne");
define("FSLAN_17", "Visninger");
define("FSLAN_18", "Top poster");
define("FSLAN_19", "Navn");
define("FSLAN_20", "Poster");
define("FSLAN_21", "Top emnestarter");
define("FSLAN_22", "Top besvarer");
define("FSLAN_23", "Forum statistik");
define("FSLAN_24", "Gennemsnitlige poster pr dag");

?>