<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Danish/lan_forum_conf.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/23 16:01:00 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "Afstemning slettet.");
define("FORLAN_6", "Tråd slettet");
define("FORLAN_7", "svar slettet");
define("FORLAN_8", "Sletning annulleret.");
define("FORLAN_9", "Tråd flyttet.");
define("FORLAN_10", "Flytning annulleret.");
define("FORLAN_11", "Tilbage til forum");
define("FORLAN_12", "Forum konfiguration");
define("FORLAN_13", "Er du helt sikker på at du vil slette denne afstemning?<br />Engang slettet<b><u>kan den ikke</u></b> genskabes.");
define("FORLAN_14", "Annuller");
define("FORLAN_15", "Bekræft sletning af forum poster");
define("FORLAN_16", "Bekræft sletning af afstemninger");
define("FORLAN_17", "indsendt af");
define("FORLAN_18", "Er du helt sikker på at du vil slette dette forum");
define("FORLAN_19", "thread and it's related posts?");
define("FORLAN_20", "afstemningen vil også blive slettet");
define("FORLAN_21", "Engang slettet ");
define("FORLAN_22", "post?<br />Engang slettet");
define("FORLAN_23", "kan ikke</u></b> genskabes");
define("FORLAN_24", "Flyt tråd til forum");
define("FORLAN_25", "Flyt tråd");
define("FORLAN_26", "Svar slettet");
	
define("FORLAN_27", "flyttet");

define("FORLAN_28", "Ombøb ikke tråd titel");
define("FORLAN_29", "Tilføj");
define("FORLAN_30", "til titel");
define("FORLAN_31", "Omdøb til:");
define("FORLAN_32", "Omdøb tråd egenskaber:");


?>