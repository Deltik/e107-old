<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Danish/lan_newforumposts_menu.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/21 13:41:17 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
	
	
	
	
	
	
	
	
define("NFP_1", "Alle nyeste poster er udenfor din brugergruppe, kan ikke vises.");
define("NFP_2", "Endnu ingen poster");
define("NFP_3", "Ny forum poster menu konfiguration er gemt");
define("NFP_4", "Overskrift");
define("NFP_5", "Hvor mange indlæg skal der vises?");
define("NFP_6", "Hvor mange tegn der skal der vises?");
define("NFP_7", "Erstatnings tekst til at afslutte for lange poster?");
define("NFP_8", "Vis orginale emner i menu?");
define("NFP_9", "Opdater menu indstillinger");
define("NFP_10", "Nye forum indlæg menu konfiguration");
define("NFP_11", "Skrevet af");

?>