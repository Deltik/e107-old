<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/review_menu/languages/Danish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/06 22:12:04 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("LAN_190", "Tilføj anmeldelse");
define("LAN_RVW_1", "Opdater menu indstillinger");
define("LAN_RVW_2", "Anmeldelse menu konfiguration gemt");
define("LAN_RVW_3", "Titel");
define("LAN_RVW_4", "Antal anmeldelser der vises");
define("LAN_RVW_5", "Vis anmeldelse kategorier i menu?");
define("LAN_RVW_6", "Titel for anmeldelse liste side");
define("LAN_RVW_7", "Vis link til at tilføje anmeldelse?");
define("LAN_RVW_8", "Anmeldelse menu konfiguration");
?>