<?
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/usertheme_menu/languages/Danish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/06 22:12:04 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("LAN_350", "Tema indstilling");
define("LAN_351", "Vælg tema");

?>