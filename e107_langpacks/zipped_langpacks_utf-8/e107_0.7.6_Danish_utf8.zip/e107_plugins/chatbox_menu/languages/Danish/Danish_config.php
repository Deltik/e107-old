<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Danish/Danish_config.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/14 16:16:10 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("CHBLAN_1", "Chatboks indstillinger opdateret.");
define("CHBLAN_2", "Modereret.");
define("CHBLAN_3", "Ingen chatboks indlæg endnu.");
define("CHBLAN_4", "Medlem");
define("CHBLAN_5", "Gæst");
define("CHBLAN_6", "fjen blokering");
define("CHBLAN_7", "bloker");
define("CHBLAN_8", "slet");
define("CHBLAN_9", "Moderer chatboks");
define("CHBLAN_10", "Moderer poster");
define("CHBLAN_11", "Chatboks poster til visning");
define("CHBLAN_12", "antal indlæg vist i chatboksen");
define("CHBLAN_13", "Erstat links");
define("CHBLAN_14", "hvis valgt, vil links blive erstattet af teksten skrevet i feltet herunder");
define("CHBLAN_15", "Erstatningstekst hvis aktiveret");
define("CHBLAN_16", "links vil blive erstattet af denne tekst");
define("CHBLAN_17", "Orddeling");
define("CHBLAN_18", "ord der er længere end tallet vil blive delt");
define("CHBLAN_19", "Opdater chatboks indstillinger");
define("CHBLAN_20", "Chatboks indstillinger");
define("CHBLAN_21", "Rensning");
define("CHBLAN_22", "Slet indlæg ældre end en bestemt tids periode");
define("CHBLAN_23", "Slet indlæg ældre end ");

define("CHBLAN_24", "En dag");
define("CHBLAN_25", "En uge");
define("CHBLAN_26", "En måned");
define("CHBLAN_27", "- Slet alle indlæg -");
define("CHBLAN_28", "Chatboks renset.");

define("CHBLAN_29", "Vis chatboks med rullegardin");
define("CHBLAN_30", "Chatboks højde");
define("CHBLAN_31", "Vis smileys");
define("CHBLAN_32", "Bestyrer brugergruppe");

define("CHBLAN_33", "Bruger tælling rekalkuleret");
define("CHBLAN_34", "Rekalkuler bruger post tælling");
define("CHBLAN_35", "Rekalkuler");

define("CHBLAN_36", "Chatboks Fremvisnings egenskaber");
define("CHBLAN_37", "Normal chatboks");
define("CHBLAN_38", "Brug javascript kode til at opdatere poster dynamisk (AJAX)");

?>