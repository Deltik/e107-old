<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:03 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("LWLAN_1", "Felter er tomme.");
define("LWLAN_2", "Linkord gemt.");
define("LWLAN_3", "Linkord opdateret.");
define("LWLAN_4", "Endnu ingen linkord.");
define("LWLAN_5", "Ord");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Indstillinger");
define("LWLAN_9", "ja");
define("LWLAN_10", "nej");
define("LWLAN_11", "Eksisterende linkord");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nej");
define("LWLAN_14", "Indsend Linkord");
define("LWLAN_15", "Opdater linkord");
define("LWLAN_16", "Rediger");
define("LWLAN_17", "Slet");
define("LWLAN_18", "Bekræft sletning af linkord?");
define("LWLAN_19", "Linkord slettet.");
define("LWLAN_20", "Kan ikke finde linkord.");
define("LWLAN_21","Ord til autolink");
define("LWLAN_22","Aktiver?");

define("LWLANINS_1", "Linkord");
define("LWLANINS_2", "Modulet vil linke angivne ord med defineret link");
define("LWLANINS_3", "Konfigurer Linkord");
define("LWLANINS_4", "Konfigurer gennem plugin på admin forsiden");

?>