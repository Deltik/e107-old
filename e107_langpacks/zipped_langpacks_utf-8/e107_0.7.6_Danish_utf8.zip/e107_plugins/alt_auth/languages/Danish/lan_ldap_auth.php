<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/alt_auth/languages/Danish/lan_ldap_auth.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/23 00:02:52 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("LDAPLAN_1", "Server adresse");
define("LDAPLAN_2", "Base DN eller Domæne<br />Hvis LDAP - Skriv BaseDN<br />Hvis AD - Skriv domæne");
define("LDAPLAN_3", "LDAP Gennemser bruger<br />Alle detaljer over bruger der kan søge mappen.");
define("LDAPLAN_4", "LDAP Gennemser kodeord<br />Kodeord for den LDAP Gennemseende bruger.");
define("LDAPLAN_5", "LDAP Version");
define("LDAPLAN_6", "Konfigurer LDAP autorisering");
define("LDAPLAN_7", "eDirectory søge filter:");
define("LDAPLAN_8", "Dette vil blive brugt til at sikre brugernavnet er i det korrekte træ, <br />ie '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Nuværrene søge filter vil være:");
define("LDAPLAN_10", "Indstillinger Opdateret");
define("LDAPLAN_11", "ADVARSEL:  Det lader til at eftersom ldap modulet pt. ikke er tilgængeligt, at sætte din auth metode til LDAP sikkert ikke vil virke!");
define("LDAPLAN_12", "Server Type");
define("LDAPLAN_13", "Opdater indstillinger");
?>