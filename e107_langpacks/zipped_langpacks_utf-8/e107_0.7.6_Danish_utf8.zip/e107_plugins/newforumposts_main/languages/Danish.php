<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newforumposts_main/languages/Danish.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/01/17 17:26:35 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("NFPM_LAN_1", "Indlæg");
define("NFPM_LAN_2", "Startet af");
define("NFPM_LAN_3", "Vist");
define("NFPM_LAN_4", "Svar");
define("NFPM_LAN_5", "Seneste indlæg");
define("NFPM_LAN_6", "Indlæg");
define("NFPM_LAN_7", "af");

define("NFPM_L1", "Plugin'et viser en liste af de seneste forum indlæg på din forside");
define("NFPM_L2", "Seneste forum indlæg"); 
define("NFPM_L3", "For at konfigurere klik på linket i plugin sektionen på admin forsiden");
define("NFPM_L4", "Aktiver i hvilket område?");
define("NFPM_L5", "Inaktiv");
define("NFPM_L6", "Toppen af siden");
define("NFPM_L7", "Bunden af siden");
define("NFPM_L8", "Titel linje");
define("NFPM_L9", "Hvor mange nye indlæg skal der vises");
define("NFPM_L10", "Vis invendig scroll lag?");
define("NFPM_L11", "Lag højde");
define("NFPM_L12", "Nye Forum Indlæg Konfiguration");
define("NFPM_L13", "Opdater Nye Forum Indlæg Indstillinger");
define("NFPM_L14", "Nye Forum Indlæg indstillinger opdateret.");
define("NFPM_L15", "Tjek for at vise seneste forum indlæg.<br />Standard er seneste emner.");
define('NFPM_L16', '[bruger slettet]');


?>