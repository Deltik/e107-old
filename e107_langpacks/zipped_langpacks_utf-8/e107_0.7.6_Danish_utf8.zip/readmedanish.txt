===============================================================
   Danish Language Pack - v4.6.1 - by Jesper � e107.dk
   Language files for the e107 Website System v0.7
   http://e107.org 
   For opdaterede filer og hj�lp bes�g: http://e107.dk
===============================================================

A. Info
B. Installation
C. Opgradering



A. Info
   Sprogpakke til e107 version 0.76 utf-8 kompatibel
   

B. Installation

1. Upload filerne beholdende strukturen og overskriv evt. eksisterende filer

2. G� http://ditdom�ne.dk/e107_admin/admin.php 
   
   V�lg "Language" derefter i rullegardinet ud for "Default Site Language:" v�lg "Danish" og klik "Save"

   f�rdig


C. Opgradering

1. Upload filerne beholdende strukturen


   f�rdig

NB! nogle FTP programmer overskriver ikke eksisterende filer ved overf�rsel af mapper
s� skal du selv overf�re dem til de tilsvarende mapper
