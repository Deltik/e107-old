<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_submitnews.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Indsend nyheder");
define("LAN_7", "Brugernavn: ");
define("LAN_62", "Emne: ");
define("LAN_112", "E-mail-adresse: ");
define("LAN_133", "Mange tak");
define("LAN_134", "Dit indlæg er blevet modtaget og vil snarrest blive gennemlæst og vurderet.");
define("LAN_135", "Nyhed: ");
define("LAN_136", "Send nyhed");
define("NWSLAN_6", "Kategori");
define("NWSLAN_10", "Ingen nyhedskategorier");
define("NWSLAN_11", "Du har ikke adgang til dette område.");
define("NWSLAN_12", "Adgang nægtet.");

define("SUBNEWSLAN_1", "Du skal skrive en titel.");
define("SUBNEWSLAN_2", "Du skal skrive noget tekst i nyheden.");
define("SUBNEWSLAN_3", "Din vedhæftning skal enten være et jpg, gif eller png fil");
define("SUBNEWSLAN_4", "For stor fil");
define("SUBNEWSLAN_5", "Billed fil");
define("SUBNEWSLAN_6", "(jpg, gif or png)");

?>