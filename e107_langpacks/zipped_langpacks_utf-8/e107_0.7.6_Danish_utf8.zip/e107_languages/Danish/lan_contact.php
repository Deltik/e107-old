<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/23 00:02:40 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Kontakt Detaljer");
define("LANCONTACT_02", "Kontakt Formular");
define("LANCONTACT_03", "Skriv dit navn:");
define("LANCONTACT_04", "E-mail adresse:");
define("LANCONTACT_05", "Besked emne:");
define("LANCONTACT_06", "Skriv din besked:");
define("LANCONTACT_07", "Email en kopi af denne besked til din egen adresse ");
define("LANCONTACT_08", "Send");
define("LANCONTACT_09", "Din besked blev sendt.");
define("LANCONTACT_10", "Der var et problem med at sende din besked.");
define("LANCONTACT_11", "Din email adresse lader ikke til at være gyldig.\\nKontroller venligst og prøv igen.");
define("LANCONTACT_12", "Din besked er for kort.");
define("LANCONTACT_13", "Inkluder venligst et emne.");

define("LANCONTACT_14", "Send besked til:");
define("LANCONTACT_15", "Forkert kode skrevet");
define("LANCONTACT_16", "Skriv Kode");





?>