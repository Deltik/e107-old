<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_user.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Medlemmer");

define("LAN_20", "FEJL");
define("LAN_112", "E-mail-adresse: ");
define("LAN_115", "ICQ nummer: ");
define("LAN_116", "AIM adresse: ");
define("LAN_117", "MSN Messenger: ");
define("LAN_118", "Fødselsdag: ");
define("LAN_119", "Sted: ");
define("LAN_120", "Signatur: ");
define("LAN_137", "Ingen oplysninger om bruger, er ikke registret hos");
define("LAN_138", "Registrerede medlemmer: ");
define("LAN_139", "Rækkefølge: ");
define("LAN_140", "Registrerede medlemmer");
define("LAN_141", "Pt. ingen registrerede medlemmer.");
define("LAN_142", "Medlem");
define("LAN_143", "[skjult efter ønske]");
define("LAN_144", "Websted URL: ");
define("LAN_145", "Indmeldt: ");
define("LAN_146", "Antal besøg siden registreringen: ");
define("LAN_147", "Chatboksindlæg: ");
define("LAN_148", "Kommentar: ");
define("LAN_149", "Forumindlæg: ");
define("LAN_308", "Rigtigt navn: ");
define("LAN_400", "Ikke en godkendt bruger.");
define("LAN_401", "ingen information");
define("LAN_402", "Medlemsprofil");
define("LAN_403", "Websted statistik");
define("LAN_404", "Sidst besøgt websted");
define("LAN_405", "dage siden");
define("LAN_406", "Vurdering");
define("LAN_407", "ingen");
define("LAN_408", "intet billede");
define("LAN_409", "points");
define("LAN_410", "Diverse");
define("LAN_411", "Opdater informationer");
define("LAN_412", "Redigere informationer");
define("LAN_413", "slet billede");
define("LAN_414", "forrige medlem");
define("LAN_415", "næste medlem");
define("LAN_416", "Du skal være medlem og logget på for at se denne side");
define("LAN_417", "Hovedadministrator");
define("LAN_418", "Hovedadministrator");
define("LAN_419", "Vis");
define("LAN_420", "Faldende");
define("LAN_421", "Stigende");
define("LAN_422", "Vis");
define("LAN_423", "Brugerkommentarer");
define("LAN_424", "Forumindlæg");
define("LAN_425", "Send privatbesked");
define("LAN_426", "siden");

define("USERLAN_1", "Ligemand bedømmelse");
define("USERLAN_2", "Du har ikke adgang til at se denne side.");

?>