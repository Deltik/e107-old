<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_user_extended.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/05/15 13:50:06 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("UE_LAN_1", "Tekstboks");
define("UE_LAN_2", "Radio knapper");
define("UE_LAN_3", "Rullemenu");
define("UE_LAN_4", "Databasefelt");
define("UE_LAN_5", "Tekstområde");
define("UE_LAN_6", "Heltal");
define("UE_LAN_7", "Dato");
define("UE_LAN_8", "Sprog");

define("UE_LAN_9", "Navn");
define("UE_LAN_10", "Type");
define("UE_LAN_11", "Brug");

define("UE_LAN_HIDE", "Skjul for brugere");

define("UE_LAN_LOCATION", "Sted");
define("UE_LAN_LOCATION_DESC", "Bruger sted");
define("UE_LAN_AIM", "AIM Adresse");
define("UE_LAN_AIM_DESC", "AIM Adresse");
define("UE_LAN_ICQ", "ICQ");
define("UE_LAN_ICQ_DESC", "ICQ Number");
define("UE_LAN_YAHOO", "Yahoo! Adresse");
define("UE_LAN_YAHOO_DESC", "Yahoo! Adresse");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN Adresse");
define("UE_LAN_HOMEPAGE", "Hjemmeside");
define("UE_LAN_HOMEPAGE_DESC", "Bruger hjemmeside (url)");
define("UE_LAN_BIRTHDAY", "Fødselsdag");
define("UE_LAN_BIRTHDAY_DESC", "Fødselsdag");
define("UE_LAN_LANGUAGE", "Sprog");
define("UE_LAN_LANGUAGE_DESC", "Bruger Sprog");
define("UE_LAN_COUNTRY", "Land");
define("UE_LAN_COUNTRY_DESC", "Bruger Land (inkluderer db tabel)");

?>