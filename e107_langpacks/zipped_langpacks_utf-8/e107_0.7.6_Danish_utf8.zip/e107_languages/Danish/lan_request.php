<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/06 22:12:00 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Download fejl");
define("LAN_dl_62", "Du er blevet hindret i at downloade denne fil, du har overskredet din download kvote");
define("LAN_dl_63", "Du har ikke de rette tilladelser til at downloade denne fil.");
define("LAN_dl_64", "Tilbage");
define("LAN_dl_65", "Fil ikke fundet");

?>