<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/link_category.php,v $
|        $Revision: 1.2 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Du kan opdele dine links i forskellige kategorier, dette gør navigation af links siden meget nemmere og forbedrer layoutet.<br /><br />Alle links sat i Main kategorien vil blive vist i hoved menuen.";
$ns -> tablerender("Link Kategori Hjælp", $text);
?>