<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/custommenu.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Fra denne side kan du lave egne menuer med dit eget indhold.<br /><br />
Se venligst <a href='http://docs.e107.org?Custom Pages'>http://docs.e107.org?Custom Pages</a>";

$ns -> tablerender(CUSLAN_18, $text);
?>