<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/filemanager.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Du kan håndtere filerne i din /files mappe fra denne side. Hvis du får en Fejlmeddelelse om tilladelser ved upload da CHMOD 777 den mappe du forsøger at uploade til.";
$ns -> tablerender("Fil Håndtering Hjælp", $text);
?>