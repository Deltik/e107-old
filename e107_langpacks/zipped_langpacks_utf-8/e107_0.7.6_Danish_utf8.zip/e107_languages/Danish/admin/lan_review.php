<?php
/*
+---------------------------------------------------------------+|        e107 website system  Language File|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_review.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:01 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("REVLAN_1", "Anmeldelse tilføjet");
define("REVLAN_2", "Felter er tomme.");
define("REVLAN_3", "Anmeldelse opdateret");
define("REVLAN_4", "Anmeldelse slettet.");
define("REVLAN_5", "Bekræft sletning af anmeldelse");
define("REVLAN_6", "Pt. ingen anmeldelser.");
define("REVLAN_7", "Eksisterende anmeldelser");
define("REVLAN_8", "Rediger");
define("REVLAN_9", "Slet");
define("REVLAN_10", "Bekræft");
define("REVLAN_11", "Åben HTML editor");
define("REVLAN_12", "Overskrift");
define("REVLAN_13", "Underemne");
define("REVLAN_14", "Opsummering");
define("REVLAN_15", "Anmeldelse");
define("REVLAN_16", "Karakter");
define("REVLAN_17", "Giv karakter");
define("REVLAN_18", "Tillad kommentarer?");
define("REVLAN_19", "Til");
define("REVLAN_20", "Fra");
define("REVLAN_21", "Synlig for");
define("REVLAN_22", "Opdater anmeldelse");
define("REVLAN_23", "Opret anmeldelse");
define("REVLAN_24", "Anmeldelse");
define("REVLAN_25", "Anmeldelseskategori gemt");
define("REVLAN_26", "Anmeldelseskategori opdateret");
define("REVLAN_27", "Kategori slettet");
define("REVLAN_28", "Kategori");
define("REVLAN_29", "Indstillinger");
define("REVLAN_30", "Rediger");
define("REVLAN_31", "Slet");
define("REVLAN_32", "Ingen anmeldelseskategori");
define("REVLAN_33", "Eksisterende anmeldelseskategorier");
define("REVLAN_34", "Kategorinavn");
define("REVLAN_35", "Kategoriikon");
define("REVLAN_36", "Vis billeder");
define("REVLAN_37", "Kategori opsummering");
define("REVLAN_38", "Opdater anmeldelsesategori");
define("REVLAN_39", "Opret anmeldelseskategori");
define("REVLAN_40", "Ingen anmeldelser");
define("REVLAN_41", "Eksisterende anmeldelser");
define("REVLAN_42", "Åben HTML editor");
define("REVLAN_43", "Kategori");
define("REVLAN_44", "Ingen");
define("REVLAN_45", "Anmeldelse forside");
define("REVLAN_46", "Opret ny anmeldelse");
define("REVLAN_47", "Kategorier");
define("REVLAN_48", "Indstillinger");
define("REVLAN_49", "Er du sikker på du vil slette denne kategori?");
define("REVLAN_50", "Er du sikker på du vil slette denne anmeldelse?");
define("REVLAN_51", "Forfatter detaljer");
define("REVLAN_52", "Lad være blank hvis den er skrevet at dig");
define("REVLAN_53", "Forfatter navn");
define("REVLAN_54", "Forfatter e-mail-adresse");
define("REVLAN_55", "Tillad anmeldelser tilføjes");
define("REVLAN_56", "Tillad besøgende at tilføje anmeldelser");
define("REVLAN_57", "Tilføj anmeldelsegruppe");
define("REVLAN_58", "Vælg hvilke brugere der kan tilføje anmeldelser");
define("REVLAN_59", "Opdater indstillinger");
define("REVLAN_60", "Indstillinger");
define("REVLAN_61", "Indstillinger opdateret");
define("REVLAN_62", "Tilføjede anmeldelser");
define("REVLAN_63", "Ingen tilføjede anmeldelser");
define("REVLAN_64", "Ingen e-mail-adresse leveret");
define("REVLAN_65", "Anmeldelse overskrift");
define("REVLAN_66", "Indsæt");
define("REVLAN_67", "Indsæt bruger tilføjet artikel");
define("REVLAN_68", "Bruger tilføjet anmeldelse gemt");
define("REVLAN_69", "Nulstil");
define("REVLAN_70", "Udfyld forfatterfelterne");
define("REVLAN_71", "Tilføj e-mail/print ikoner?");
define("REVLAN_72", "Ja");
define("REVLAN_73", "Nej");
?>