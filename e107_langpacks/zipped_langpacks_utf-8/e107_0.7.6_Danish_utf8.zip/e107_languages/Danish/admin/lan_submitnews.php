<?php
/*
+---------------------------------------------------------------+|        e107 website system  Language File|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_submitnews.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:01 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("SUBLAN_1", "Indsendt nyhed slettet.");
define("SUBLAN_2", "Bekræft sletning af nyhedsemnet  kan ikke fortrydes");
define("SUBLAN_3", "Fortryd");
define("SUBLAN_4", "Bekræft sletning");
define("SUBLAN_5", "Godkend sletning af nyhedsemne");
define("SUBLAN_6", "Sletning afbrudt.");
define("SUBLAN_7", "Der er ingen nye brugerindsendte nyheder.");
define("SUBLAN_8", "Der er 1 indsendt nyhed at gennemse.");
define("SUBLAN_9", "Der er");
define("SUBLAN_10", "indsendte nyheder at gennemse");
define("SUBLAN_11", "e-mail-adresse");
define("SUBLAN_12", "den");
define("SUBLAN_13", "Emne");
define("SUBLAN_14", "Valg");
define("SUBLAN_15", "Flyt emne til nyhedssystem");
define("SUBLAN_16", "Marker som uønsket");
define("SUBLAN_17", "Ingen ældre indsendte nyheder");
define("SUBLAN_18", "Ukendt");
define("SUBLAN_19", "Indsendt af");
define("SUBLAN_20", "Ældre indsendte nyheder");
define("SUBLAN_21", "Re-evaluere");
define("SUBLAN_22", "Slet permanent");
define("SUBLAN_23", "Anmeld brugerindsendte nyheder");

?>