<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_e107_update.php,v $
|        $Revision: 1.7 $
|        $Date: 2006/11/23 00:02:41 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Handling");
define("LAN_UPDATE_3", "Ikke nødvendig");

define("LAN_UPDATE_5", "Opdateringer er tilgængelig");
define("LAN_UPDATE_7", "Gennemført");
define("LAN_UPDATE_8", "opdatering fra");
define("LAN_UPDATE_9", "til");
define("LAN_UPDATE_10", "Tilgængelige opdateringer");
define("LAN_UPDATE_11", ".617 to .7 Opdatering Fortsat");
define("LAN_UPDATE_12", "En af dine tabeller indeholder dobbelte poster.");


?>