<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_userinfo.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/09/14 21:32:16 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("USFLAN_1", "Er ikke i stand til at finde skribentens IP adresse  ingen informationer er tilgængelig.");
// define("USFLAN_2", "Fejl");
define("USFLAN_3", "Besked skrevet fra IP adresse");
define("USFLAN_4", "Vært");
define("USFLAN_5", "Flyt denne IP adresse til administreret blokering");
define("USFLAN_6", "Bruger ID");
define("USFLAN_7", "Brugerinformation");

?>