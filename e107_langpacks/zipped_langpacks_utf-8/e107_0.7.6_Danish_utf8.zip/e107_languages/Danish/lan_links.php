<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_links.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/09/14 20:10:33 $
|        $Author: e107dk $

+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Links");
define("LAN_61", "Link Kategorier");
define("LAN_62", "kategorier");
define("LAN_63", "kategori");
define("LAN_64", "i denne kategori");
define("LAN_65", "link");
define("LAN_66", "links");
define("LAN_67", "Vis alle links");
define("LAN_68", "rediger");
define("LAN_69", "slet");
define("LAN_86", "Kategori:");
define("LAN_88", "Klik:");
define("LAN_89", "Admin: ");
define("LAN_90", "tilføj nyt link i denne kategori");
define("LAN_91", "tilføj ny kategori");

define("LAN_92", "Tilføj et link");
define("LAN_93", "Efter dit link er sendt vil det blive bedømt og hvis det er passende vil det blive tilføjet linkssiden.");
define("LAN_94", "Linknavn:");
define("LAN_95", "Link URL:");
define("LAN_96", "Linkbeskrivelse:");
define("LAN_97", "URL til evt. linkknap:");
define("LAN_98", "Tilføj link");

define("LAN_99", "Mange tak");
define("LAN_100", "Dit link er gemt og vil blive gennemgået.");
define("LAN_101", "Tilføj link");

define("LAN_102", "Der");
define("LAN_103", "er");
define("LAN_104", "er");
define("LAN_105", "i alt i");
define("LAN_106", "Understregede felter skal udfyldes.");

define("LAN_Links_1", "links i alt");
define("LAN_Links_2", "aktiverede links i alt");
define("LAN_LINKS_3", "Anonym");

?>