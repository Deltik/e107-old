<?php
/*+---------------------------------------------------------------+|        e107 website system  Language File||        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_stats.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:00 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("PAGE_NAME", "Statistik");
define("LAN_124", "Unikke visninger i alt: ");
define("LAN_125", "Visninger i alt: ");
define("LAN_126", "Unikke fremvisninger pr. side: ");
define("LAN_127", "Fremvisninger i alt pr. side: ");
define("LAN_128", "Browser: ");
define("LAN_129", "Styresystem: ");
define("LAN_130", "Lande/domæner besøg fra: ");
define("LAN_131", "Henvisninger fra: ");
define("LAN_132", "Statistik");
define("LAN_371", "Logging er ikke aktiveret. Gå til administrations siden, klik på Log og marker aktiver Logging/Tæller boksen.");
define("LAN_372", "Funktionerne på denne side er sat ud af drift.");
define("LAN_373", "Pt. ingen statistik.");
define("LAN_374", "Logning begyndt:");
define("LAN_375", "Vis alle");
define("LAN_376", "sidste 10 unikke besøgende");
define("LAN_377", "alle");
define("LAN_378", "top 10");
define("LAN_379", "Skærmopløsning");
define("LAN_418", "Dage siden");
define("LAN_419", "Daglig gennemsnit");
define("LAN_420", "Ugentligt gennemsnit");
define("LAN_421", "Månedligt gennemsnit");
define("LAN_422", "Kan endnu ikke beregnes");

?>