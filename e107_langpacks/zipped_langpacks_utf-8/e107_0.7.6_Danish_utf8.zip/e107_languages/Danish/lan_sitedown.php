<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_sitedown.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Webstedet er midlertidigt lukket");
define("LAN_SITEDOWN_00", "er midlertidigt lukket");
define("LAN_SITEDOWN_01", "Webstedet er midlertidigt lukket ned, grundet vigtig vedligeholdelse. Dette burde ikke vare længe - kom snart igen vi beklager ulejligheden.");

?>