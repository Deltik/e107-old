<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_sitelinks.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Hovedmenu");
define("LAN_SITELINKS_502", "Admin område");

?>