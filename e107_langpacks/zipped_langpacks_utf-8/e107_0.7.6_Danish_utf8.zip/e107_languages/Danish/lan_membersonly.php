<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_membersonly.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/01/17 14:50:45 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Kun medlemmer");

define("LAN_MEMBERS_0", "begrænset område");
define("LAN_MEMBERS_1", "Dette er et begrænset område");
define("LAN_MEMBERS_2", "for at få adgang: <a href='".e_LOGIN."'>log ind</a>r");
define("LAN_MEMBERS_3", "eller <a href='".e_SIGNUP."'>registrer</a> som medlem");
define("LAN_MEMBERS_4", "Klik her for at vende tilbage til forsiden");

?>