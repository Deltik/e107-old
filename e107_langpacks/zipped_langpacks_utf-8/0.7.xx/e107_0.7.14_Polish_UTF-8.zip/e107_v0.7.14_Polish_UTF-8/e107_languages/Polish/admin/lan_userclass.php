<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2008/08/27 11:05:18 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_userclass.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_userclass.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
define("UCSLAN_1", "Wyślij potwierdzenie emailem do");
define("UCSLAN_2", "Uprawnienia zostały zaktualizowane");
define("UCSLAN_3", "Witaj");
define("UCSLAN_4", "Twoje uprawnienia zostały zaktualizowane w serwisie");
define("UCSLAN_5", "Masz teraz dostęp do następujących stref");
define("UCSLAN_6", "Ustaw grupę dla użytkownika");
define("UCSLAN_7", "Ustaw grupę");
define("UCSLAN_8", "Powiadom użytkownika");
define("UCSLAN_9", "Grupy zostały zaktualizowane.");
define("UCSLAN_10", "Pozdrawiam,");
define('UCSLAN_12', 'Tylko uprzywilejowani użytkownicy');

?>