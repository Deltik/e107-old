<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2008/01/08 18:40:59 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/cpage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/cpage.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie możesz tworzyć własne menu oraz własne strony wraz z ich zawartością.<br /><br />";
// $text .= "Proszę zobaczyć <a href='http://e107.org/e107_plugins/docs/docs.php?133'>Używanie narzędzia Własne menu oraz własne strony (po angielsku)</a> dla wyjaśnienia wszystkich funkcji.";

$ns -> tablerender('Własne menu oraz strony', $text);

?>
