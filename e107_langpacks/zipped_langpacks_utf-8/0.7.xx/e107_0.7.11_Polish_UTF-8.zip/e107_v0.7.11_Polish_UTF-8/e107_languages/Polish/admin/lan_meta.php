<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_meta.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_meta.php rev. 1.5
+-----------------------------------------------------------------------------+
*/
 
define("METLAN_1", "Znaczniki meta zostały zaktualizowane w bazie danych");
define("METLAN_2", "Dodatkowe znaczniki meta");
define("METLAN_3", "Dodaj znaczniki meta");
define("METLAN_4", "Zaktualizowano znaczniki");
define("METLAN_5", "tutaj zamieść opis strony");
define("METLAN_6", "tutaj możesz wpisać słowa kluczowe, oddziel je przecinkami");
define("METLAN_7", "tutaj możesz wpisać informacje o prawach autorskich");
define("METLAN_8", "Znaczniki meta");

define("METLAN_9", "Opis");
define("METLAN_10", "Słowa kluczowe");
define("METLAN_11", "Prawa autorskie");
define("METLAN_12", "Używaj tytułu oraz streszczenia aktualności jako opisu dla znacznika meta na stronie aktualności.");
define("METLAN_13", "Autor");

?>
