<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ONLINE_L1", "Gasten: ");
define("ONLINE_L2", "Leden: ");
define("ONLINE_L3", "Op deze pagina: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Leden");
define("ONLINE_L6", "Nieuwste");
define("TRACKING_MESSAGE", "Het volgen van de gebruikers Online is nu gedeactiveerd, activeer de functie <a href='".e_ADMIN."users.php?options'>hier</a></span><br />");
?>