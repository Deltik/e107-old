<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Dutch_formal/lan_forum_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:45:09 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("FOR_FP_1", "Forum");

?>