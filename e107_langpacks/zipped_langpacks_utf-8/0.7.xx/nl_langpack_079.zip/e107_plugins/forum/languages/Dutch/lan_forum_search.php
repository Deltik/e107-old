<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Dutch/lan_forum_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/19 06:36:34 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Selecteer forum");
define("FOR_SCH_LAN_3", "Alle forums");
define("FOR_SCH_LAN_4", "Hele bericht");
define("FOR_SCH_LAN_5", "Als deel van discussie");

?>