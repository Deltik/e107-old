<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/lastseen/languages/Dutch_formal.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:45:28 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LSP_LAN_1", "Laatst gezien");


?>