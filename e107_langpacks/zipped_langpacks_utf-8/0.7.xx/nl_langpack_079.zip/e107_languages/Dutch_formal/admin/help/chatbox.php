<?php

if (!defined('e107_INIT')) { exit; }


$text = "Stel hier de chatbox voorkeuren in.";

$ns -> tablerender("Chatbox", $text);
?>