<?php

if (!defined('e107_INIT')) { exit; }

$caption = "Startpagina Hulp";
$text = "In dit scherm kunt u de startpagina van uw site inrichten. Standaard wordt het nieuws getoond.";
$ns -> tablerender($caption, $text);
?>