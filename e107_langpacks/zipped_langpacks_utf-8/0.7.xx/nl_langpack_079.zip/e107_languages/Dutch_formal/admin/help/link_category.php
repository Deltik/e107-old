<?php

if (!defined('e107_INIT')) { exit; }

$text = "U kunt de links onderverdelen in categorieën, dat maakt uw site overzichtelijker.<br /><br />Links binnen de categorie Main, worden getoond in het hoofdmenu.";
$ns -> tablerender("Link Categorie Hulp", $text);
?>