<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch_formal/admin/lan_credits.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:43:45 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Verantwoording");
define("CRELAN_2", "Hier een overzicht van de software / componenten van derden die in e107 worden toegepast. Het e107 ontwikkelteam wil de ontwikkelaars van de volgende componenten hartelijk danken voor de toestemming om hun code met e107 te distribueren en voor het onder de GPL licentie publiceren van hun software.");
define("CRELAN_7", "versie");

// define("CRELAN_3", "Bron");
// define("CRELAN_4", "Beschrijving");
// define("CRELAN_5", "Website");
// define("CRELAN_6", "Toestemming");
define("PAGE_NAME", "e107 verantwoording");
define("CRELAN_3", "alle rechten voorbehouden");
define("CRELAN_4", "Toon e107 Dev Team");
define("CRELAN_5", "Toon scripts van derden");
define("CRELAN_6", "e107 v0.7 is gebracht door  ...");
define("CRELAN_8", "toestemming verleend");
define("CRELAN_9", "Licentie");
define("CRELAN_10", "MagpieRSS biedt een op XML gebaseerde (expat) RSS parser in PHP.");
define("CRELAN_11", "PclZip library biedt compressie en extractie functies voor de op het Zip formaat archiefbestanden (WinZip, PKZIP).");
define("CRELAN_12", "PclTar biedt de mogelijkheid om een lijst bestanden of mappen met of zonder compressie te archiveren. De met PclTar gemaakt archiefbestanden zijn te lezen door de meeste gzip/tar programma's en met het Windows WinZip programma.");
define("CRELAN_13", "TinyMCE is een platform onafhankelijke web gebaseerde Javascript HTML WYSIWYG editor component, die als Open Source onder de LGPL is gepubliceerd door Moxiecode Systems AB. Het heeft de mogelijkheid om HTML TEXTAREA velden of andere HTML objecten te converteren naar editors.");
define("CRELAN_14", "Pictogrammen gebruikt in e107");
define("CRELAN_15", "Functierijke e-mail transfer classe voor PHP");
define("CRELAN_16", "Menu systeem gebruikt in het Jayya theme");
define("CRELAN_17", "Popup kalender component");
define("CRELAN_18", "PDF ondersteuning");
define("CRELAN_19", "UTF-8 PDF ondersteuning");
define("CRELAN_20", ""); // asperon
define("CRELAN_21", "Always a pressure..err..pleasure!"); // CaMer0n
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\""); // jalist
define("CRELAN_23", ""); // lisa
define("CRELAN_24", ""); // McFly
define("CRELAN_25", ""); // que
define("CRELAN_26", ""); // streaky
define("CRELAN_27", "\"Wot? No tea?? 0_0\""); // SweetAs
define("CRELAN_28", ""); // MrPete


?>