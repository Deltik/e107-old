<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch_formal/lan_user_select.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:43:30 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Selecteer gebruiker");
define("US_LAN_2", "Selecteer ledenklasse");
define("US_LAN_3", "Alle gebruikers");
define("US_LAN_4", "Zoek gebruikersnaam");
define("US_LAN_5", "Gebruiker(s) gevonden");
define("US_LAN_6", "Zoek");
?>