<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch_formal/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/03/02 18:43:29 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "stem");
define("RATELAN_1", "stemmen");
define("RATELAN_2", "hoe beoordeelt u dit onderwerp?");
define("RATELAN_3", "bedankt voor uw stem");
define("RATELAN_4", "niet beoordeeld");
define("RATELAN_5", "Waardering");
?>