<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/28 20:35:48 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "stem");
define("RATELAN_1", "stemmen");
define("RATELAN_2", "hoe beoordeel je dit onderwerp?");
define("RATELAN_3", "bedankt voor je stem");
define("RATELAN_4", "niet beoordeeld");
define("RATELAN_5", "Waardering");
?>