<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch/admin/lan_message.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/12 22:15:56 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Ontvangen berichten");
define("MESSLAN_2", "Verwijder bericht");
define("MESSLAN_3", "Bericht verwijderd.");
define("MESSLAN_4", "Verwijder alle berichten");
define("MESSLAN_5", "Bevestigen");
define("MESSLAN_6", "Alle berichten verwijderd.");
define("MESSLAN_7", "Geen berichten.");
define("MESSLAN_8", "Berichtsoort");
define("MESSLAN_9", "Gemeld op");

define("MESSLAN_10", "Aangemeld door");
define("MESSLAN_11", "opent in nieuw venster");
define("MESSLAN_12", "Bericht");
define("MESSLAN_13", "Link");


?>