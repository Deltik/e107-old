<?php

define("CACLAN_1", "Activeer cache systeem");
define("CACLAN_2", "Instellen cache");
define("CACLAN_3", "Cache Systeem");
define("CACLAN_4", "Cache functie ingesteld");
define("CACLAN_5", "Cache leegmaken");
define("CACLAN_6", "Cache leeg gemaakt");
define("CACLAN_7", "Cache gedeactiveerd");
define("CACLAN_9", "Cache gegevens bewaard in bestand");
define("CACLAN_10", "De cache directorie is niet beschrijfbaar. Zorg ervoor dat de directorie permissies op CHMOD 0777 staan");

?>