<?php

if (!defined('e107_INIT')) { exit; }

$caption = "Startpagina Hulp";
$text = "In dit scherm kun je de startpagina van je site inrichten. Standaard wordt het nieuws getoond.";
$ns -> tablerender($caption, $text);
?>