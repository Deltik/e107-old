<?php

if (!defined('e107_INIT')) { exit; }

$caption = "Gebruikersklasse Hulp";
$text = "Je kunt op deze pagina gebruikersgroepen (klassen) aanmaken, bewerken of verwijderen.<br />Dit is nuttig om bepaalde onderdelen van je site af te schermen van de reguliere gebruikers. Je kunt bijvoorbeeld een TEST-klasse maken en daarna een forum maken waarvoor alleen gebruikers die lid zijn van de TEST-klasse toegang krijgen.<br /> Door het gebruik van Klassen kun je een Alleen-voor-leden onderdeel van je site maken..";
$ns -> tablerender($caption, $text);
?>