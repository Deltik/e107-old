// UK lang variables

tinyMCE.addToLang('flash',{
title : 'Вмъкване / редакция на Flash филм',
desc : 'Вмъкване / редакция на Flash филм',
file : 'Flash файл (.swf)',
size : 'Размер',
list : 'Flash файлове',
props : 'Flash опции',
general : 'Основни'
});
