// UK lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Стартирай проверка на текста',
iespell_download : "ieSpell не е намерен. Натисни OK за отиване на страницата за теглене."
});

