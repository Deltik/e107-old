<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Bulgarian/lan_newforumposts_menu.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/04 15:49:47 $
|     $Author: mcfly_e107 $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/

define("NFP_1", "Всички последни отговора са извън вашият потребителски клас. Невъзможно е да бъдат показани.");
define("NFP_2", "Все още няма съобщения");
define("NFP_3", "Настройката на меню Ново от Форума са запазени");
define("NFP_4", "Обяснение");
define("NFP_5", "Номер на съобщенията за показване?");
define("NFP_6", "Брой знаци за показване?");
define("NFP_7", "Постфикс за дълги съобщения?");
define("NFP_8", "Показване на заглавите на темата в менюто?");
define("NFP_9", "Обнови настройките");
define("NFP_10", "Настройка на меню Ново от Форума");
define("NFP_11", "Публикувано от: ");

?>
