<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Bulgarian/lan_forum_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/16 05:25:35 $
|     $Author: sweetas $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Форум");
define("FOR_SCH_LAN_2", "Избери Форум");
define("FOR_SCH_LAN_3", "Всички Форуми");
define("FOR_SCH_LAN_4", "Цялото съобщение");
define("FOR_SCH_LAN_5", "Като част от тема");

?>