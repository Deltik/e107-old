<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/admin/Bulgarian.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:52:39 $
|     $Author: streaky $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/

define("CLOCK_AD_L1", "Настройките на меню Часовник са запазени");
define("CLOCK_AD_L2", "Заглавие");
define("CLOCK_AD_L3", "Обнови менюто Часовник");
define("CLOCK_AD_L4", "Настройките на меню Часовник");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Ако е отметнато времето ще бъде показвано в US формат (0-12 AM/PM формат). Неотметнато ще се ползва 'военен' формат (0-24 формат)");
define("CLOCK_AD_L7", "Префикс за датата");
define("CLOCK_AD_L8", "Ако езикът ви изисква кратка дума преди датата (Например 'le' за френски или 'den' за немски...), използвай това поле. В противен случай остави празно.");
define("CLOCK_AD_L9", "Суфикс 1");
define("CLOCK_AD_L10", "Суфикс 2");
define("CLOCK_AD_L11", "Суфикс 3");
define("CLOCK_AD_L12", "Суфикс 4 и повече more");
define("CLOCK_AD_L13", "Ако езикът ви изисква дума след числата за датата, попълнете тези полета само със суфикса (Например: 'ви' за 1, 'ри' за 2, 'ти' за 3 и повече за българските потребители). Ако не е необходимо оставете празно.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>