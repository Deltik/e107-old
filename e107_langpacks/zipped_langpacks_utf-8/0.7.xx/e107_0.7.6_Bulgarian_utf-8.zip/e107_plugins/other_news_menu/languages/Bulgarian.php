<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/other_news_menu/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:53:12 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
	
define("TD_MENU_L1", "Други новини");
	
?>