<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Регистрация на потребител");

define("NT_LAN_UV_1", "Регистрацията е потвърдена");
define("NT_LAN_UV_2", "Потребителско ID: ");
define("NT_LAN_UV_3", "Име за вход на потребителя: ");
define("NT_LAN_UV_4", "Потребителско IP: ");

define("NT_LAN_LI_1", "Логнат Потребител");

define("NT_LAN_LO_1", "Потребител - Изход");
define("NT_LAN_LO_2", " излезе  от сайта");

define("NT_LAN_FL_1", "Забрана поради Flood");
define("NT_LAN_FL_2", "Забрана на IP адрес за flooding");

define("NT_LAN_SN_1", "Записана е новина");

define("NT_LAN_NU_1", "Актуализирано");

define("NT_LAN_ND_1", "Изтрита новина");
define("NT_LAN_ND_2", "ID на изтритата новина");

?>
