<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_top.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Най-активни във форума");
define("TOP_LAN_1", "Име");
define("TOP_LAN_2", "Публикации");
define("TOP_LAN_3", "Най-активни - коментари");
define("TOP_LAN_4", "Коментари");
define("TOP_LAN_5", "Най-активни - чат");
define("TOP_LAN_6", "Рейтинг за сайта");

//v.616
define("LAN_1", "Тема");
define("LAN_2", "Потребител");
define("LAN_3", "Прегледи");
define("LAN_4", "Отговори");
define("LAN_5", "Последни съобщения");
define("LAN_6", "Теми");
define("LAN_7", "Най-популярни теми");
define("LAN_8", "Най-активни потребители");


?>