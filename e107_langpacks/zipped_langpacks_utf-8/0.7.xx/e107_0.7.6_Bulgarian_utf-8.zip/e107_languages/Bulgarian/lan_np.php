<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_np.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("NP_1", "Предишна страница");
define("NP_2", "Следваща страница");
define("NP_3", "Отиди на страница");

?>