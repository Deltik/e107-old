<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_mail_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Генерирано от e107 уебсайт система");
define("LANMAILH_2", "Това е multi-part съобщение в MIME формат.");
define("LANMAILH_3", " е неправилно форматирано");
define("LANMAILH_4", "Сървърът отказа адреса");
define("LANMAILH_5", "Няма отговор от сървъра");
define("LANMAILH_6", "Не мога да открия E-Mail сървър.");
define("LANMAILH_7", " изглежда е валиден.");


?>