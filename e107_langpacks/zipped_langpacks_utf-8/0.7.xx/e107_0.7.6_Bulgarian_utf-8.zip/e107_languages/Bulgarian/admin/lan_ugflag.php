<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/01/24 16:35:23 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "maintenance setting updated");
define("UGFLAN_2", "Activate maintenance flag");
define("UGFLAN_3", "Update Maintenance Setting");
define("UGFLAN_4", "Maintenance Setting");

define("UGFLAN_5", "Text to display when site down");
define("UGFLAN_6", "Leave blank to display default message");

?>