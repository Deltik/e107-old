<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/15 14:12:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_1", "Уведомяване");
define("NT_LAN_2", "Получаване на имейли за уведомяване при");
define("NT_LAN_3", "Изключено");
define("NT_LAN_4", "Главни администратори");
define("NT_LAN_5", "Клас");
define("NT_LAN_6", "Имейл");

define("NU_LAN_1", "Потребители");
define("NU_LAN_2", "Регистрация на потребител");
define("NU_LAN_3", "Порвърждение на регистрацията на потребител");
define("NU_LAN_4", "Логване на потребител");
define("NU_LAN_5", "Излизане на потребител");

define("NS_LAN_1", "Сигурност");
define("NS_LAN_2", "Блокиране на IP");

define("NN_LAN_1", "Новини");
define("NN_LAN_2", "Нова добавена новина");
define("NN_LAN_3", "Новина публикувана от админ");
define("NN_LAN_4", "Новина редактирана от админ");
define("NN_LAN_5", "Новина изтрита от админ");

define("NF_LAN_1", "File Events");
define("NF_LAN_2", "Файлове качени от потребител");

?>
