<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_modcomment.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/15 15:48:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Редактирано.");
define("MDCLAN_2", "Няма коментари");
define("MDCLAN_3", "Потребител");
define("MDCLAN_4", "Гост");
define("MDCLAN_5", "махни блокирането");
define("MDCLAN_6", "блокиране");

define("MDCLAN_8", "Редактиране на коментари");
define("MDCLAN_9", "Внимание! Изтриването на коментара ще изтрие и всички отговори към него!");

define("MDCLAN_10", "опции");
define("MDCLAN_11", "коментар");
define("MDCLAN_12", "коментари");
define("MDCLAN_13", "блокиран");
define("MDCLAN_14", "заключи коментарите");
define("MDCLAN_15", "оптваряне");
define("MDCLAN_16", "заключен");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>
