<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_cache.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/14 16:35:23 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Статус на кеша");
define("CACLAN_2", "Определете статуса на кеша");
define("CACLAN_3", "Кешираща система");
define("CACLAN_4", "Статус на кеш");
define("CACLAN_5", "Изчистване на кеша");
define("CACLAN_6", "Кеша е изчистен");

define("CACLAN_7", "Кеширането е спряно");
// define("CACLAN_8", "Cache data saved to MySQL");
define("CACLAN_9", "Кешираните данни са запазени във файл");
define("CACLAN_10", "Директорията кадете се съхраняват кешираните данни няма права за писане. Моля променете тази директория със следните права: CHMOD 0777");
?>
