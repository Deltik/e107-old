<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/14 16:43:23 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "Настройките на входната страница са запазени.");
define("FRTLAN_2", "Изберете входната страница за");
define("FRTLAN_6", "Линкове");
// define("FRTLAN_7", "Content Page");
define("FRTLAN_12", "Обновяване на настройките");
define("FRTLAN_13", "Настройки на входната страница");
define("FRTLAN_15", "Друго (напишете url):");
define("FRTLAN_16", "грешка: no content main parent selected");
define("FRTLAN_17", "грешка: no content sub category selected");
define("FRTLAN_18", "грешка: no content item selected");
define("FRTLAN_19", "content main parent");
define("FRTLAN_20", "content category");
define("FRTLAN_21", "content item");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "всички");
define("FRTLAN_27", "Гости");
define("FRTLAN_28", "Региистрирани потребители");
define("FRTLAN_29", "Администратори");
define("FRTLAN_31", "Всички потребители");
define("FRTLAN_32", "Клас потребители");
define("FRTLAN_33", "Текущи настройки");
define("FRTLAN_34", "Страница");

?>
