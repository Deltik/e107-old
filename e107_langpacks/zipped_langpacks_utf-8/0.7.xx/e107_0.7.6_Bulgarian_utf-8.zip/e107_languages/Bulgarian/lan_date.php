<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_date.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "година");
define("LANDT_02", "месец");
define("LANDT_03", "седмица");
define("LANDT_04", "ден");
define("LANDT_05", "час");
define("LANDT_06", "минута");
define("LANDT_07", "секунда");
define("LANDT_01s", "години");
define("LANDT_02s", "месеца");
define("LANDT_03s", "седмици");
define("LANDT_04s", "дни");
define("LANDT_05s", "часа");
define("LANDT_06s", "минути");
define("LANDT_07s", "секунди");

define("LANDT_08", "мин");
define("LANDT_08s", "мин");
define("LANDT_09", "сек");
define("LANDT_09s", "сек");
define("LANDT_AGO", "по-рано");


?>