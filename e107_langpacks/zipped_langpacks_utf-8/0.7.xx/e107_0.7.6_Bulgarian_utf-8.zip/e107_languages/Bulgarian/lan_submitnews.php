<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_submitnews.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Добавяне на новини");
define("LAN_7", "Потребителско име: ");
define("LAN_62", "Тема: ");
define("LAN_112", "Имейл Адрес: ");
define("LAN_133", "Благодарим ви");
define("LAN_134", "Вашата публикация е записана и ще бъде прегледана от администратор на сайта в най-скоро време.");
define("LAN_135", "Новина: ");
define("LAN_136", "Добави новина");
define("NWSLAN_6", "Категория");
define("NWSLAN_10", "Няма Създадени Категории");
define("NWSLAN_11", "Нямате достъп до тази секция.");
define("NWSLAN_12", "Достъпът е отказан.");

define("SUBNEWSLAN_1", "Трябва да въведете заглавие.\\n");
define("SUBNEWSLAN_2", "Трябва да въведете текст за новината.\\n");
define("SUBNEWSLAN_3", "Вашия прикачен файл може да бъде jpg, gif или png");
define("SUBNEWSLAN_4", "Файлът е прекалено голям");
define("SUBNEWSLAN_5", "Файл Картинка");
define("SUBNEWSLAN_6", "(jpg, gif или png)");

?>