<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Грешка при сваляне на файл");
define("LAN_dl_62", "Свалянето на този файл беше прекъснато - надвишихте вашата квота за сваляне.");
define("LAN_dl_63", "Нямате права за сваляне на този файл.");
define("LAN_dl_64", "Обратно");
define("LAN_dl_65", "Файлът не е намерен");

?>