<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_meta.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags updated in 資料庫");
define("METLAN_2", "Enter additional meta-tags");
define("METLAN_3", "Enter new meta tag 設定");
define("METLAN_4", "Updated");
define("METLAN_5", "type your description here");
define("METLAN_6", "type, a, list, of, your, keywords, here");
define("METLAN_7", "type your copyright 資訊 here");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "Description");
define("METLAN_10", "Keywords");
define("METLAN_11", "Copyright");

?>