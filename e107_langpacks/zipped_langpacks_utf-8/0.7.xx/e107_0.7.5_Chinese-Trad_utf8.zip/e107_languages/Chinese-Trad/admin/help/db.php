<?php
$text = "This collection of 工具 allows you to manage your 資料庫.";
$ns -> tablerender("資料庫 工具", $text);
?>