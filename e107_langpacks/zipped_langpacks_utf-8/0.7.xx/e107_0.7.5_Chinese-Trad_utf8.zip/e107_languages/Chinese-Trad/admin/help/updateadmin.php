<?php
$text = "Update your 密碼 here.";
$ns -> tablerender("Update 設定 Help", $text);
?>