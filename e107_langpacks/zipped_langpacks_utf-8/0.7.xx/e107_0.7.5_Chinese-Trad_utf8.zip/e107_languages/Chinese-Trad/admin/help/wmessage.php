<?php
$text = "This page allows you to set a message that will appear at the top of your front page all the time it's activated. You can set a different message for 訪客, 註冊ed/logged-in 會員 and 管理員s.";
$ns -> tablerender("WMessage Help", $text);
?>
