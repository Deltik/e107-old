<?php
$text = "You can seperate your news items into different 分區, and allow 訪客 to display only the news items in those 分區. <br /><br />Upload your news icon images either ".e_THEME."-yourtheme-/images/ or themes/shared/newsicons/.";
$ns -> tablerender("News 分區 Help", $text);
?>