<?php
$text = "If your MySql server version supports it you can switch 
to the MySql sort method which is faster than the PHP sort method. See preferences.<br /><br />";
$ns -> tablerender("搜尋 Help", $text);
?>