<?php
$text = "From this screen you can create custom menus or custom pages with your own content in them.<br /><br />
Please see <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a> for an explanation of all the features.";

$ns -> tablerender(CUSLAN_18, $text);
?>