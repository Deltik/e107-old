<?php
$caption = "網站管理說明";
$text = "使用此頁面來新增, 或刪除管理員. 僅管理員擁有權限進入此頁面.";
$ns -> tablerender($caption, $text);
?>