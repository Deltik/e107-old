<?php
$text = "You are able to manage the files in your /files directory from this page. If you are getting 錯誤 message about 權限 when uploading 請 CHMOD the directory you are atempting to upload into to 777.";
$ns -> tablerender("檔案管理 Help", $text);
?>