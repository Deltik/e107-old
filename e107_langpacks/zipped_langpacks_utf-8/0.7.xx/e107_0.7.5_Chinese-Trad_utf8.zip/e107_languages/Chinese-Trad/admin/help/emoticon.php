<?php

$text = "With emoticons activated, standard smiley text strings will be replaced by their 
respective emoticon images throughout the content in your site.";

$ns -> tablerender("Emoticon Help", $text);
?>