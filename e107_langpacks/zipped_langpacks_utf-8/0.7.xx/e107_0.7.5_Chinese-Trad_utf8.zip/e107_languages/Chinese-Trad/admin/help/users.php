﻿<?php
$text = "This page allows you to moderate your 註冊ed 會員. You can update their 設定, give them 管理員 status and set their user class among other things.";
$ns -> tablerender("Users Help", $text);
unset($text);
?>