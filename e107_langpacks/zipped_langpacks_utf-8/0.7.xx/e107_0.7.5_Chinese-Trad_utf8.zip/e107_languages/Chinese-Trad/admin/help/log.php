<?php
$text = "Activate site stats logging from this page. If you are short of server space tick the do主要的 only box as referer logging, this will only log the do主要的 as opposed to the whole url, ie 'jalist.com' instead of 'http://jalist.com/links.php' ";
$ns -> tablerender("Logging Help", $text);
?>