<?php
$text = "From here you can allow / disallow the ability for users to upload files and manage those files that have been uploaded.";
$ns -> tablerender("Public 上傳 Help", $text);
?>