<?php
$text = "Use this page to configure your mail 設定 for site-wide mailing functions. The mail out form also allows you to send out a mail-shot to all your 會員s.";
$ns -> tablerender("Mail Help", $text);
?>