<?php
$text = "Enter all your site links here. Links added here will be shown in your 主要的 navigation menu, for other links please use the Links Page plugin.
<br />
";
$ns -> tablerender("Links Help", $text);
?>