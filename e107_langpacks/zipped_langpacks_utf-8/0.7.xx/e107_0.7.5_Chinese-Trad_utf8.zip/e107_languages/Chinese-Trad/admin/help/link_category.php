<?php
$text = "You can seperate your links into different 分區, this makes navigating the 主要的 Links page much easier and improves layout.<br /><br />Any link entered under the 主要的 分區 will be displayed in your 主要的 navigation menu.";
$ns -> tablerender("Link 分區 Help", $text);
?>