<?php
$text = " This page displays all your servers PHP configuration 設定. ";
$ns -> tablerender("PHP 資訊 Help", $text);
?>