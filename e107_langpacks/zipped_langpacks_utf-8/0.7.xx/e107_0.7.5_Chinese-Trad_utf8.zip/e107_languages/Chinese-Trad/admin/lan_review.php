<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_review.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("REVLAN_1", "回顧新增到資料庫.");
define("REVLAN_2", "Fields left blank.");
define("REVLAN_3", "Review updated in 資料庫.");
define("REVLAN_4", "Review 刪除d.");
define("REVLAN_5", "請 tick the confirm box to 刪除 this review");
define("REVLAN_6", "No reviews yet.");
define("REVLAN_7", "Existing Reviews");
define("REVLAN_8", "編輯");
define("REVLAN_9", "刪除");
define("REVLAN_10", "tick to confirm");
define("REVLAN_11", "Open HTML 編輯or");
define("REVLAN_12", "Heading");
define("REVLAN_13", "Sub-Heading");
define("REVLAN_14", "Summary");
define("REVLAN_15", "Review");
define("REVLAN_16", "Rating");
define("REVLAN_17", "請 select rating");
define("REVLAN_18", "允許評論?");
define("REVLAN_19", "On");
define("REVLAN_20", "Off");
define("REVLAN_21", "Visible to");
define("REVLAN_22", "Update Review");
define("REVLAN_23", "Submit Review");
define("REVLAN_24", "Reviews");




define("REVLAN_25", "Review 分區 已儲存的");
define("REVLAN_26", "Review 分區 Updated");
define("REVLAN_27", "分區 刪除d");
define("REVLAN_28", "分區");
define("REVLAN_29", "Options");
define("REVLAN_30", "編輯");
define("REVLAN_31", "刪除");
define("REVLAN_32", "No review 分區");
define("REVLAN_33", "Existing Review 分區");
define("REVLAN_34", "分區 Name");
define("REVLAN_35", "分區 Icon");
define("REVLAN_36", "View Images");
define("REVLAN_37", "分區 Summary");
define("REVLAN_38", "Update Review 分區");
define("REVLAN_39", "Create Review 分區");
define("REVLAN_40", "No reviews");
define("REVLAN_41", "Existing Reviews");
define("REVLAN_42", "Open HTML 編輯or");
define("REVLAN_43", "分區");
define("REVLAN_44", "None");
define("REVLAN_45", "Review Front Page");
define("REVLAN_46", "Create new Review");
define("REVLAN_47", "分區");
define("REVLAN_48", "Review Options");
define("REVLAN_49", "Are you sure you want to 刪除 this 分區?");
define("REVLAN_50", "Are you sure you want to 刪除 this review?");
define("REVLAN_51", "Author Details");
define("REVLAN_52", "leave if review written by you");
define("REVLAN_53", "author name");
define("REVLAN_54", "author email address");

define("REVLAN_55", "Allow reviews to be submitted");
define("REVLAN_56", "Allow 訪客 to submit reviews to your site");
define("REVLAN_57", "Submit review class");
define("REVLAN_58", "Select which 會員s can submit reviews");
define("REVLAN_59", "Update Options");
define("REVLAN_60", "Review Options");
define("REVLAN_61", "Review options updated");

define("REVLAN_62", "已送出的Reviews");
define("REVLAN_63", "No 已送出的reviews");
define("REVLAN_64", "No email address supplied");
define("REVLAN_65", "Review Heading");
define("REVLAN_66", "Post");
define("REVLAN_67", "Post 會員 已送出的Article");
define("REVLAN_68", "會員 已送出的review 已儲存的 in 資料庫");

define("REVLAN_69", "Clear Form");
define("REVLAN_70", "Click here to fill author fields");
define("REVLAN_71", "Add email/print icons?");
define("REVLAN_72", "Yes");
define("REVLAN_73", "No");
?>