<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Sending notification email to");
define("UCSLAN_2", "Updated Privileges");
define("UCSLAN_3", "Dear");
define("UCSLAN_4", "Your privileges have been updated at");
define("UCSLAN_5", "You now have access to the 下列的 area(s)");
define("UCSLAN_6", "Set class for 會員");
define("UCSLAN_7", "Set Classes");
define("UCSLAN_8", "Notify 會員");
define("UCSLAN_9", "Classes Updated.");
define("UCSLAN_10", "Regards,");

?>