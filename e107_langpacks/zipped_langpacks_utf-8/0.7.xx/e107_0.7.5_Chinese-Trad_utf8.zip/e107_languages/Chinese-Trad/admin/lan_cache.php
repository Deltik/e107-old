<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_cache.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "快取系統狀態");
define("CACLAN_2", "設定快取狀態");
define("CACLAN_3", "快取系統");
define("CACLAN_4", "快取狀態設定");
define("CACLAN_5", "清空快取");
define("CACLAN_6", "快取已清空");

define("CACLAN_7", "取消快取");
// define("CACLAN_8", "Cache data 已儲存的 to MySQL");
define("CACLAN_9", "快取資料已儲存於磁碟檔案");
define("CACLAN_10", "該cache 目錄無法寫入. 請確認該目錄設定為 CHMOD 0777");
?>