<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_banlist.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "封鎖已移除的.");
define("BANLAN_2", "沒有封鎖的.");
define("BANLAN_3", "現有的封鎖");
define("BANLAN_4", "移除封鎖");
define("BANLAN_5", "輸入 IP, email, 或主機");
define("BANLAN_7", "理由");
define("BANLAN_8", "封鎖會員");
define("BANLAN_9", "封鎖網站中的會員");
define("BANLAN_10", "IP / Email / 理由");
define("BANLAN_11", "自動封鎖: 登入失敗過十次");

?>