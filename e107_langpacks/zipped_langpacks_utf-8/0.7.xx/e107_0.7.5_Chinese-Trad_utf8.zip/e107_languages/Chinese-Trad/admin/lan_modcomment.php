<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_modcomment.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "已編輯.");
define("MDCLAN_2", "該項目沒有評論");
define("MDCLAN_3", "會員");
define("MDCLAN_4", "訪客");
define("MDCLAN_5", "取消封鎖");
define("MDCLAN_6", "封鎖");

define("MDCLAN_8", "編輯評論");
define("MDCLAN_9", "警告! 刪除主要評論將會刪除所有回覆!");

define("MDCLAN_10", "選項");
define("MDCLAN_11", "評論");
define("MDCLAN_12", "評論");
define("MDCLAN_13", "已封鎖");
define("MDCLAN_14", "鎖住評論");
define("MDCLAN_15", "開啟");
define("MDCLAN_16", "鎖住");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>