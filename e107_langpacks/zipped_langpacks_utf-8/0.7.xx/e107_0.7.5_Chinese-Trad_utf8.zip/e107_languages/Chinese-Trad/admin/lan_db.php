<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_db.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "核心設定備份於資料庫.");
define("DBLAN_2", "點選按鈕儲存備份於您的 e107 資料庫");
define("DBLAN_3", "備份SQL 資料庫");
define("DBLAN_4", "點選按鈕確認 e107 資料庫的有效資料");
define("DBLAN_5", "確認資料庫有效性");
define("DBLAN_6", "點選按鈕進行 e107 資料庫優化");
define("DBLAN_7", "優化 SQL 資料庫");
define("DBLAN_8", "點選按鈕備份您的核心設定");
define("DBLAN_9", "備份核心設定");
define("DBLAN_10", "資料庫工具");
define("DBLAN_11", "mySQL 資料庫");
define("DBLAN_12", "已優化");
define("DBLAN_13", "返回");
define("DBLAN_14", "執行");
define("DBLAN_15", "點選按鈕確認任何資料庫的更新");
define("DBLAN_16", "確認更新");

?>