<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "主要的tenance setting updated");
define("UGFLAN_2", "Activate 主要的tenance flag");
define("UGFLAN_3", "Update 主要的tenance Setting");
define("UGFLAN_4", "主要的tenance Setting");

define("UGFLAN_5", "Text to display when site down");
define("UGFLAN_6", "Leave blank to display default message");

?>