<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("SEALAN_1", "搜尋 Configuration");
define("SEALAN_2", "Number of characters displayed in 搜尋 result summary:");
define("SEALAN_3", "搜尋 sort method:");
define("SEALAN_6", "評論");
define("SEALAN_7", "註冊ed 會員");
define("SEALAN_10", "Display relevance value:");
define("SEALAN_11", "Allow 會員 to select 搜尋able areas:");
define("SEALAN_12", "Restrict time allowed between 搜尋es (max 5 mins):");
define("SEALAN_13", "Restrict to one 搜尋 every");
define("SEALAN_14", "seconds");
define("SEALAN_15", "搜尋 page accessible to 會員 class");
define("SEALAN_16", "On");
define("SEALAN_17", "Off");
define("SEALAN_18", "搜尋able 評論 Areas (when 評論 搜尋 is activated)");
define("SEALAN_19", "Allow 會員s to 搜尋 more than one area at a time:");
define("SEALAN_20", "General 設定");
define("SEALAN_21", "搜尋able Areas");
define("SEALAN_22", "Default");
define("SEALAN_23", "Alternative:");
define("SEALAN_24", "Type");
define("SEALAN_25", "會員 Class");
define("SEALAN_26", "Pre-Title Text");
define("SEALAN_30", "Highlight keywords on referred too page:");
define("SEALAN_31", "PHP limited to");
define("SEALAN_32", "results (leave blank for no limit)");
define("SEALAN_33", "Could not switch to MySql sort method as this requires at least version 4.0.1 of MySql.");
define("SEALAN_34", "Your version is currently");
define("SEALAN_35", "搜尋able areas selection method:");
define("SEALAN_36", "Dropdown");
define("SEALAN_37", "Checkbox");
define("SEALAN_38", "Radio");
define("SEALAN_39", "Custom Pages");

define("LAN_98", "News");
define("LAN_197", "下載");
define("LAN_418", "Custom Pages");

define("SEALAN_40", "搜尋 Options");
define("SEALAN_41", "主要的 Page");
define("SEALAN_42", "Preferences");

define("SEALAN_43", "編輯 搜尋 設定 for");
define("SEALAN_44", "會員 class allowed to 搜尋 this area");
define("SEALAN_45", "Number of results displayed per page");
define("SEALAN_46", "Number of characters in 搜尋 result summary");


?>