<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_e107_update.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "行動");
define("LAN_UPDATE_3", "尚未需要");

define("LAN_UPDATE_5", "有效的更新");
define("LAN_UPDATE_7", "已實施");
define("LAN_UPDATE_8", "更新於");
define("LAN_UPDATE_9", "到");
define("LAN_UPDATE_10", "有效的更新");

?>