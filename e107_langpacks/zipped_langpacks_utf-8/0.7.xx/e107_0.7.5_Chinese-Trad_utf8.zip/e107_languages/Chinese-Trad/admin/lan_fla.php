<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_fla.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "登入失敗紀錄");
define("FLALAN_2", "目前沒有登入失敗紀錄");
define("FLALAN_3", "已刪除紀錄");
define("FLALAN_4", "會員嘗試使用錯誤的會員名稱/密碼");
define("FLALAN_5", "已封鎖的 IP ");
define("FLALAN_6", "日期");
define("FLALAN_7", "資料");
define("FLALAN_8", "IP 位址/ 主機");
define("FLALAN_9", "選項");
define("FLALAN_10", "刪除 / 封鎖已確認");
define("FLALAN_11", "確認刪除全部確認盒");
define("FLALAN_12", "取消選取所有的刪除確認盒");
define("FLALAN_13", "選取所有的封鎖的確認盒");
define("FLALAN_14", "取消選取所有的封鎖的確認盒");
define("FLALAN_15", "下列的 IP address(es) 已經被自動封鎖 - 會員嘗試登入發生錯誤過多次");
define("FLALAN_16", "刪除該自動封鎖名單");
define("FLALAN_17", "已刪除自動封鎖名單");

?>