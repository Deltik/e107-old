<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_wmessage.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "訊息瀏覽於訪客");
// define("WMGLAN_2", "訊息瀏覽於會員");
// define("WMGLAN_3", "訊息瀏覽於管理員");
// define("WMGLAN_4", "送出");
// define("WMGLAN_5", "設定歡迎訊息");
// define("WMGLAN_6", "啟動?");
// define("WMGLAN_7", "歡迎訊息 設定已更新.");

define("WMLAN_00","歡迎訊息");
define("WMLAN_01","新增訊息");
define("WMLAN_02","訊息");
define("WMLAN_03","瀏覽權限");
define("WMLAN_04","訊息文字");

define("WMLAN_05","關閉");
define("WMLAN_06","選擇後, 該訊息將會顯示於內部方塊");
define("WMLAN_07","撤除基本系統設定使用 {WMESSAGE} 簡短編碼:");
// define("WMLAN_08","基本設定");

define("WMLAN_09","目前沒有歡迎訊息");

?>