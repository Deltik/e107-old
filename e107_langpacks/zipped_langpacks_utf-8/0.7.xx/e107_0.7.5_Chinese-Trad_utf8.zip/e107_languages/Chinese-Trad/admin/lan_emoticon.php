<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_emoticon.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "表情圖案啟動");
define("EMOLAN_2", "名稱");
define("EMOLAN_3", "表情");
define("EMOLAN_4", "啟動表情圖案?");

define("EMOLAN_5", "圖案");
define("EMOLAN_6", "表情圖案編碼");
define("EMOLAN_7", "利用空白鍵作間隔");

define("EMOLAN_8", "狀態");
define("EMOLAN_9", "選項");
define("EMOLAN_10", "啟動");
define("EMOLAN_11", "啟動包裝'");

define("EMOLAN_12", "編輯 / 設定該包裝");
define("EMOLAN_13", "已安裝的包裝");

define("EMOLAN_14", "儲存設定");
define("EMOLAN_15", "編輯 / 設定表情圖案");
define("EMOLAN_16", "已儲存的表情圖案");
define("EMOLAN_2", "名稱");
define("EMOLAN_2", "名稱");
define("EMOLAN_2", "名稱");
define("EMOLAN_2", "名稱");
define("EMOLAN_2", "名稱");
define("EMOLAN_2", "名稱");

?>