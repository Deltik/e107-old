<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_lancheck.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Select Language to verify");
define("LAN_CHECK_2", "Begin Verify");
define("LAN_CHECK_3", "Verification of");
define("LAN_CHECK_4", "File missing!");
define("LAN_CHECK_5", "Phrase missing!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "phrase");

define("LAN_CHECK_8", "A file is missing...");
define("LAN_CHECK_9", " files are missing...");
define("LAN_CHECK_10", "Critical 錯誤: ");
define("LAN_CHECK_11", "No file missing !");
define("LAN_CHECK_12", "A file is wrong...");
define("LAN_CHECK_13", " files are wrong...");
define("LAN_CHECK_14", "All existing files are valid !");

?>
