<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Received messages");
define("MESSLAN_2", "刪除 Message");
define("MESSLAN_3", "Message 刪除d.");
define("MESSLAN_4", "刪除 All Messages");
define("MESSLAN_5", "Confirm");
define("MESSLAN_6", "All messages 刪除d.");
define("MESSLAN_7", "No messages.");
define("MESSLAN_8", "Message type");
define("MESSLAN_9", "Reported on");

define("MESSLAN_10", "已送出的by");
define("MESSLAN_11", "opens in new window");
define("MESSLAN_12", "Message");
define("MESSLAN_13", "Link");


?>