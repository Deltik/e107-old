<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_image.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("IMALAN_1", "開啟圖片發表");
define("IMALAN_2", "顯示圖片, 他將會採用網站寬度 (評論, 確認盒...等等)");
define("IMALAN_3", "重設大小模式");
define("IMALAN_4", "變更圖片大小模式, either GD1/2 library, or ImageMagick");
define("IMALAN_5", " ImageMagick路徑 (if selected)");
define("IMALAN_6", "Full path to ImageMagick Convert utility");
define("IMALAN_7", "圖片設定");
define("IMALAN_8", "更新圖片設定");
define("IMALAN_9", "圖片設定以更新");
define("IMALAN_10", "發表圖片權限");
define("IMALAN_11", "Restrict 會員s who can post images (if已開啟 above)");
define("IMALAN_12", "關閉圖片模式");
define("IMALAN_13", "What to do with posted images if image posting is disabled");
define("IMALAN_14", "顯示圖片連結");
define("IMALAN_15", "不顯示");
define("IMALAN_16", "顯示已上傳頭像");
define("IMALAN_17", "Click here");
define("IMALAN_18", "Uploaded images");

define("IMALAN_21", "Used by");
define("IMALAN_22", "Image not in use");
define("IMALAN_23", "Avatar");
define("IMALAN_24", "Photograph");
define("IMALAN_25", "Click here to 刪除 all unused images");
define("IMALAN_26", "image(s) 刪除d");

define("IMALAN_28", "刪除d");
define("IMALAN_29", "No images");
define("IMALAN_30", "Everyone (public)");
define("IMALAN_31", "訪客 only");
define("IMALAN_32", "會員 only");
define("IMALAN_33", "Admin only");
define("IMALAN_34", "開啟 Sleight");
define("IMALAN_35", "Fixes transparent PNG-24's with alpha transparency in IE 5 / 6 (Applies Sitewide)");

?>