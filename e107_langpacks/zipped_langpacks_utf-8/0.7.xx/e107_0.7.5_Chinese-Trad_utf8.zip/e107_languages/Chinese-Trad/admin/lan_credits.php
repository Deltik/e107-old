<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_credits.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "贊助");
define("CRELAN_2", "這裡有使用e107的第三方軟體 / 資源. e107 開發團隊私底下感謝下列的人士提供他們自己寫的程式給 e107, 並釋出他們的軟體於 GPL 版權底下.");
// define("CRELAN_3", "資源");
// define("CRELAN_4", "描述");
// define("CRELAN_5", "網站");
// define("CRELAN_6", "Permission");
define("CRELAN_7", "版本");



?>