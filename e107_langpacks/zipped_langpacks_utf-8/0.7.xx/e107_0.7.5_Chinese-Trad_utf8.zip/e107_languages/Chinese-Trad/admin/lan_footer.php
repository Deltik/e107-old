<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_footer.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "網站");
define("FOOTLAN_2", "主要管理員");
define("FOOTLAN_3", "版本");
define("FOOTLAN_4", "建構於");
define("FOOTLAN_5", "風格");
define("FOOTLAN_6", "");
define("FOOTLAN_7", "資訊");
define("FOOTLAN_8", "安裝日期");
define("FOOTLAN_9", "伺服器");
define("FOOTLAN_10", "主機");
define("FOOTLAN_11", "PHP 版本");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "網站資訊");
define("FOOTLAN_14", "網站文件");
define("FOOTLAN_15", "文件");
define("FOOTLAN_16", "資料庫");
define("FOOTLAN_17", "編碼");

?>