<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_header.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "管理員導覽");
define("LAN_head_2", "您的伺服器不允許 HTTP 檔案上傳，所以他不會允許您的會員上傳 頭像或是檔案. 請重新設定php.ini 裡的 file_upload 並重新啟動. 如果您沒有權限編輯 php.ini 請聯絡您的主機商.");
define("LAN_head_3", "Your server is running with a basedir restriction in effect. This disallows usage of any file outside of your home directory and as such could affect certain scripts such as the filemanager.");

define("LAN_head_4", "系統區域");

define("LAN_head_5", "系統管理台顯示語言: ");
define("LAN_head_6", "外掛 資訊");

?>
