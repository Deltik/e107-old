<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_mailout.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "Save Changes");
define("PRFLAN_63", "Send test email");
define("PRFLAN_64", "Clicking button will send test email to 主要的 admin email address");
define("PRFLAN_65", "Click to send email to");
define("PRFLAN_66", "Test email from");
define("PRFLAN_67", "This is a test email, it appears that your email 設定 are working ok!\n\nRegards\nfrom the e107 網站 system.");
define("PRFLAN_68", "The email could not be sent. It appears that your server is not correctly configured to send emails, 請 try again using SMTP, or contact your hosts and ask them to check their sendmail / email server 設定.");
define("PRFLAN_69", "The email has been successfully sent, 請 check your inbox.");
define("PRFLAN_70", "Emailing method");
define("PRFLAN_71", "If unsure, leave as php");
define("PRFLAN_72", "SMTP Server");
define("PRFLAN_73", "SMTP 會員名稱");
define("PRFLAN_74", "SMTP 密碼");
define("PRFLAN_75", "The email could not be sent. 請 review your SMTP 設定, or disable SMTP and try again.");

define("MAILAN_01","From Name");
define("MAILAN_02","From Email");
define("MAILAN_03","To");
define("MAILAN_04","Cc");
define("MAILAN_05","Bcc");
define("MAILAN_06","Subject");
define("MAILAN_07","Attachment");
define("MAILAN_08","Send Email");
define("MAILAN_09","Use Theme Style");
define("MAILAN_10","會員 Subscribed");
define("MAILAN_11","Insert Variables");
define("MAILAN_12","All 會員");
define("MAILAN_13","All Unverified 會員 ");
define("MAILAN_14","It is recommended that you 開啟 SMTP for sending large numbers of emails - set in preferences below.");
define("MAILAN_15","Mail-Out");

define("MAILAN_16","會員名稱");
define("MAILAN_17","signup link");
define("MAILAN_18","會員 id");
define("MAILAN_19","There is no email address for site-admin. 請 check your preferences and try again.");
define("MAILAN_20","Sendmail-path");
define("MAILAN_21","Mass-Mail Entries");
define("MAILAN_22","There are currently no 已儲存的 entries");
define("MAILAN_23","會員class: ");
define("MAILAN_24", "email(s) are ready to be sent");
?>