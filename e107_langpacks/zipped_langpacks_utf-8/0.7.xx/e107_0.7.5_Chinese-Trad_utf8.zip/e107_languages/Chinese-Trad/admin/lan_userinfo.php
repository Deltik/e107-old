<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_userinfo.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "無法找到發表人 IP 位址 - 目前沒有相關資訊.");
// define("USFLAN_2", "錯誤");
define("USFLAN_3", "訊息發表來自於 IP ");
define("USFLAN_4", "主機");
define("USFLAN_5", "點選這裡將 IP 位址轉到控制台封鎖頁面");
define("USFLAN_6", "會員ID");
define("USFLAN_7", "會員資訊");

?>