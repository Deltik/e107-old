<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_language.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00","could not be created.(already exists)");
define("LANG_LAN_01","was 刪除d(if existing) and created.");
define("LANG_LAN_02","couldn't be 刪除d");
define("LANG_LAN_03","Tables");

define("LANG_LAN_05","Not Installed");
define("LANG_LAN_06", "Create tables");
define("LANG_LAN_07", "Drop existing tables?");
define("LANG_LAN_08", "Replace existing tables (data will be lost).");
define("LANG_LAN_10", "Confirm 刪除");
define("LANG_LAN_11", "刪除 unchecked tables above (if they exist).");
define("LANG_LAN_12", "開啟 Multi-Language Tables");
define("LANG_LAN_13", "Multi-Language Preferences");
define("LANG_LAN_14", "Default Site Language");
define("LANG_LAN_15", "Tick to copy data from the default language.(useful for links, news-分區 etc) ");


?>