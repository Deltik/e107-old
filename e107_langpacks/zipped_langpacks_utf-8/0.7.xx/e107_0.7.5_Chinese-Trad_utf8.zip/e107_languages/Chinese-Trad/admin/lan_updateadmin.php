<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "錯誤 - 請 re-submit");
define("UDALAN_2", "設定 updated");
define("UDALAN_3", "設定 Updated for");
define("UDALAN_4", "Name");
define("UDALAN_5", "密碼");
define("UDALAN_6", "Re-type 密碼");
define("UDALAN_7", "Change 密碼");
define("UDALAN_8", "密碼 Update for");

?>