<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/admin/lan_menus.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:33 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "全部會員和訪客");
define("MENLAN_2", "僅限於會員");
define("MENLAN_3", "僅限於管理員");
define("MENLAN_4", "僅限於:");
// define("MENLAN_5", "class");
define("MENLAN_6", "儲存權限選項");
define("MENLAN_7", "Configure visibility options for");
define("MENLAN_8", "權限選項更新");
define("MENLAN_9", "自訂選單已安裝");
define("MENLAN_10", "新選單已安裝");
define("MENLAN_11", "選單移除");
define("MENLAN_12", "啟動: 選擇區域");
define("MENLAN_13", "啟動該區域");
define("MENLAN_14", "區域");
define("MENLAN_15", "取消啟動");
define("MENLAN_16", "設定");
define("MENLAN_17", "向上移動");
define("MENLAN_18", "向下移動");
define("MENLAN_19", "移動到該區域");
define("MENLAN_20", "權限");

// define("MENLAN_21", "Visible to 訪客 only");
define("MENLAN_22", "為啟動選單");

define("MENLAN_23", "移到最下面");
define("MENLAN_24", "移到最上面");
define("MENLAN_25", "Function ...");

define("MENLAN_26", "該選單將會 <strong>顯示</strong> 於下列頁面");
define("MENLAN_27", "該選單將會 <strong>隱藏</strong> 於下列頁面");
define("MENLAN_28", "Enter one page per line, enter enough of the url to distinguish it properly");

define("MENLAN_29", "選擇外觀風格");
define("MENLAN_30", "To see the menu areas and their positions for custom layouts, select the custom layout here:");
define("MENLAN_31", "預設外觀風格");
define("MENLAN_32", "Newsheader Layout");
define("MENLAN_33", "自訂外觀");
define("MENLAN_34", "Embedded");
define("MENLAN_35", "Configure Menus");
define("MENLAN_36", "Choose the menu(s) to activate");
define("MENLAN_37", "then choose where to active them.");
define("MENLAN_38", "Hold down CTRL to select multiple menus.");


?>