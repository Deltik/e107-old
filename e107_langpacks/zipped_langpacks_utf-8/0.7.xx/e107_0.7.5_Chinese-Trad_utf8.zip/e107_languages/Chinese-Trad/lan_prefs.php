<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 web網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_prefs.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 網站製作");
define("LAN_PREF_2", "e107 網站系統");
define("LAN_PREF_3", "所有的商標 c 為原擁有者所有, 所有網站元件內容由 c e107 網站製作.<br />e107 是 c e107.org 2002-2005 版權為 <a href=\"http://www.gnu.org/\" rel=\"external\">GNU GPL 條款</a>.");
define("LAN_PREF_4", "censored");
define("LAN_PREF_5", "討論區");

?>