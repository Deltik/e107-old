<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "會員註冊");

define("NT_LAN_UV_1", "會員註冊認可");
define("NT_LAN_UV_2", "會員 session 字串");

define("NT_LAN_LI_1", "會員登入");

define("NT_LAN_LO_1", "會員登出");
define("NT_LAN_LO_2", " 登出網站");

define("NT_LAN_FL_1", "連續發表封鎖");
define("NT_LAN_FL_2", "IP 封鎖於連續發表");

define("NT_LAN_SN_1", "已送出新聞項目");

define("NT_LAN_NU_1", "已更新");

define("NT_LAN_ND_1", "已刪除新聞項目");
define("NT_LAN_ND_2", "已刪除新聞項目 id");

?>