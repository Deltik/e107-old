﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/Chinese-Trad.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'zhtw');
define("CORE_LC", 'zhtw');
define("CORE_LC2", 'gb');
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","錯誤訊息 : 風格已遺失.\\n\\n變更風格於您的一般設定中 (管理控制台) 或上傳相關風格檔案於伺服器中.");

//v.616
define("CORE_LAN2"," \\1 已寫下:");// "\\1" represents the username.
define("CORE_LAN3","附加檔案功能關閉");
?>