<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "投票");
define("RATELAN_1", "投票");
define("RATELAN_2", "您要參與投票嗎?");
define("RATELAN_3", "感謝您的投票");
define("RATELAN_4", "尚未閱讀");
define("RATELAN_5", "投票");

?>