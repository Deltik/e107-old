<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 web網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_equery_secure.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "您將會受限於管理方式, 有可能資料庫修改發生錯誤");
define("EQSEC_LAN2", "請確認該行動:");
define("EQSEC_LAN3", "目前沒有提出");
define("EQSEC_LAN4", "行動來自於:");
define("EQSEC_LAN5", "執行給:");
define("EQSEC_LAN6", "確認執行");
define("EQSEC_LAN7", "或取消");
?>