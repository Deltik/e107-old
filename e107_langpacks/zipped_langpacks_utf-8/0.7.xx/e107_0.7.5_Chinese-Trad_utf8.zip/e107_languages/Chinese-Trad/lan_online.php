<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "訪客: ");
define("ONLINE_EL2", "會員: ");
define("ONLINE_EL3", "於此頁面: ");
define("ONLINE_EL4", "線上");
define("ONLINE_EL5", "會員");
define("ONLINE_EL6", "最新註冊會員");
define("ONLINE_EL7", "瀏覽中");
define("ONLINE_EL8", "最多線上會員: ");
define("ONLINE_EL9", "於");
define("ONLINE_EL10", "會員名稱");
define("ONLINE_EL11", "瀏覽頁面");
define("ONLINE_EL12", "回覆於");
define("ONLINE_EL13", "版面");
define("ONLINE_EL14", "主題");
define("ONLINE_EL15", "頁面");
define("CLASSRESTRICTED", "Class Restricted Page");
define("ARTICLEPAGE", "文章/回顧");
define("CHAT", "Chat");
define("COMMENT", "評論");
define("DOWNLOAD", "下載");
define("EMAIL", "email.php");
define("FORUM", "討論區首頁");
define("LINKS", "連結");
define("NEWS", "新聞");
define("OLDPOLLS", "Old Polls");
define("POLLCOMMENT", "Poll");
define("PRINTPAGE", "列印");
define("LOGIN", "登入");
define("SEARCH", "搜尋中");
define("STATS", "網站統計");
define("SUBMITNEWS", "提供新聞");
define("UPLOAD", "上船");
define("USERPAGE", "個人資訊");
define("USERSETTINGS", "個人設定");
define("ONLINE", "觀看線上會員");
define("LISTNEW", "List New Items");
define("USERPOSTS", "會員發表");
define("SUBCONTENT", "Submit Article/Review");
define("TOP", "Top Posters/Most Active Threads");
define("ADMINAREA", "管理控制台");
define("BUGTRACKER", "錯誤追蹤");
define("EVENT", "事件清單");
define("CALENDAR", "事件行事曆");
define("FAQ", "Faq");
define("PM", "私人訊息");
define("SURVEY", "Survey");
define("ARTICLE", "Article");
define("CONTENT", "Content Page");
define("REVIEW", "Review");

?>