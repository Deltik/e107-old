<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_newspost.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "已刪除新聞故事.");
define("NWSLAN_2", "請勾選確認盒以便於刪除該新聞項目.");
define("NWSLAN_3", "目前沒有新聞項目.");
define("NWSLAN_4", "已存在的新聞");
define("NWSLAN_5", "開啟 HTML 編輯器");
define("NWSLAN_6", "分區");
define("NWSLAN_7", "編輯");
define("NWSLAN_8", "刪除");
define("NWSLAN_9", "勾選確認");
define("NWSLAN_10", "目前沒有分區.");
define("NWSLAN_11", "新增編輯分區");
define("NWSLAN_12", "標題");
define("NWSLAN_13", "內容");
define("NWSLAN_14", "延伸資訊");
define("NWSLAN_15", "評論");
define("NWSLAN_16", "開啟");
define("NWSLAN_17", "關閉");
define("NWSLAN_18", "允許新聞項目評論");
define("NWSLAN_19", "啟動狀態");
define("NWSLAN_20", "取消自動啟動請留空白");
define("NWSLAN_21", "啟動於");
define("NWSLAN_22", "瀏覽權限");
define("NWSLAN_23", "勾選可以瀏覽新聞項目會員等級");
define("NWSLAN_24", "再次預覽");
define("NWSLAN_25", "更新新聞（於資料庫中）");
define("NWSLAN_26", "發表新聞（於資料庫中）");
define("NWSLAN_27", "預覽");
define("NWSLAN_28", "新聞故事");
define("NWSLAN_29", "新聞發表");

define("NWSLAN_30", "僅顯示標題");

?>