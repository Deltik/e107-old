<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 web網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_membersonly.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "僅限於會員");

define("LAN_MEMBERS_0", "認證區域");
define("LAN_MEMBERS_1", "這是一個認證區域");
define("LAN_MEMBERS_2","僅接受會員 <a href='login.php'>登入</a> 或");
define("LAN_MEMBERS_3","註冊會員");
define("LAN_MEMBERS_4","點選這裡回到前一頁");

?>