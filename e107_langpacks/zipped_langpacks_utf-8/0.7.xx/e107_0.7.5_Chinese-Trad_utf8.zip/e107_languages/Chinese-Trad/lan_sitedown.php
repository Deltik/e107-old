<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "網站暫時關閉");
define("LAN_00", "暫時關閉");
define("LAN_01", "我們暫時關閉網站以便於作部份維修更新. 這不會花太多時間 - 請稍後回來確認, 很抱歉照成您的不便.");
?>