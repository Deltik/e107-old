﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_subcontent.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "感謝您, your article has been saved and will be reviewed by a site administrator in due course.");
define("ARLAN_1", "欄位保留空白.");
define("ARLAN_2", "感謝您, your review has been saved and will be reviewed by a site administrator in due course.");
define("ARLAN_15", "送出文章");
define("ARLAN_17", "標題");
define("ARLAN_18", "子標題");
define("ARLAN_19", "Summary");
define("ARLAN_20", "文章");
define("ARLAN_21", "允許評論?");
define("ARLAN_22", "開啟");
define("ARLAN_23", "關閉");
define("ARLAN_24", "Add email/print icons?");
define("ARLAN_25", "是");
define("ARLAN_26", "不");
define("ARLAN_27", "送出文章");
define("ARLAN_28", "預覽");
define("ARLAN_55", "瀏覽權限");
define("ARLAN_73", "開啟 HTML 編輯器");
define("ARLAN_74", "分區");
define("ARLAN_75", "沒有");
define("ARLAN_82", "作者資訊");
define("ARLAN_84", "作者名稱");
define("ARLAN_85", "作者電子信箱");
define("ARLAN_86", "回顧");
define("ARLAN_87", "投票");
define("ARLAN_88", "Please select rating");
define("ARLAN_89", "送出回顧");

define("ARLAN_90", "Fields left blank, please press the back button in your browser and confirm all fields are filled in.");
define("ARLAN_91", "再次預覽");
define("ARLAN_92", "請輸入帳號跟電子信箱");


define("ARLAN_93", "文章");
define("ARLAN_94", "回顧");
define("ARLAN_95", "目前暫停會員提供文章");
define("ARLAN_96", "目前暫停會員提供回顧");
define("ARLAN_97", "You do not have enough privileges to Submit Articles");
define("ARLAN_98", "You do not have enough privileges to Submit Reviews");


define("ARLAN_99", "您想要提供甚麼資訊?");
define("ARLAN_100", "新聞");
define("ARLAN_101", "事件");
define("ARLAN_102", "文章");
define("ARLAN_103", "回顧");
define("ARLAN_104", "連結");
define("ARLAN_105", "下載");
define("ARLAN_106", "送出項目");

?>