<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "提供新聞");
define("LAN_7", "登入名稱: ");
define("LAN_62", "主題: ");
define("LAN_112", "Email信箱: ");
define("LAN_133", "感謝您");
define("LAN_134", "您的項目已送出，管理員將會儘快處理.");
define("LAN_135", "新聞項目: ");
define("LAN_136", "提供新聞項目");
define("NWSLAN_6", "C分區");
define("NWSLAN_10", "目前沒有新聞分區");
define("NWSLAN_11", "您無法進入此區域.");
define("NWSLAN_12", "禁止進入.");

define("SUBNEWSLAN_1", "您必須輸入標題.\\n");
define("SUBNEWSLAN_2", "您必須輸入文字於內容中.\\n");
define("SUBNEWSLAN_3", "您的附加檔案必須為jpg, gif 或 png 檔案格式");
define("SUBNEWSLAN_4", "檔案太大");
define("SUBNEWSLAN_5", "圖片檔案");
define("SUBNEWSLAN_6", "(jpg, gif or png)");

?>