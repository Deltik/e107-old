<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 web網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_print.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "友善列印");

define("LAN_86", "分區:");
define("LAN_87", "於");
define("LAN_94", "發表於");
define("LAN_135", "新聞項目: ");
define("LAN_303", "該新聞項目來自於 ");
define("LAN_304", "標題: ");
define("LAN_305", "子標題: ");
define("LAN_306", "來自於: ");
define("LAN_307", "列印該頁面");

?>