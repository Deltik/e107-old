<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_user_extended.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "文字盒");
define("UE_LAN_2", "Radio 按鈕");
define("UE_LAN_3", "下拉選單");
define("UE_LAN_4", "DB Table 欄位");
define("UE_LAN_5", "文字區域");
define("UE_LAN_6", "整數");
define("UE_LAN_7", "日期");
define("UE_LAN_8", "語言");

define("UE_LAN_9", "名稱");
define("UE_LAN_10", "類型");
define("UE_LAN_11", "使用");

define("UE_LAN_HIDE", "隱藏來自會員");

define("UE_LAN_LOCATION", "來自於");
define("UE_LAN_LOCATION_DESC", "會員地區所屬");
define("UE_LAN_AIM", "AIM 即時通");
define("UE_LAN_AIM_DESC", "AIM 即時通");
define("UE_LAN_ICQ", "ICQ 即時通");
define("UE_LAN_ICQ_DESC", "ICQ 即時通");
define("UE_LAN_YAHOO", "Yahoo! 即時通");
define("UE_LAN_YAHOO_DESC", "Yahoo! 即時通");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN 即時通");
define("UE_LAN_HOMEPAGE", "網站首頁");
define("UE_LAN_HOMEPAGE_DESC", "會員首頁（網址）");
define("UE_LAN_BIRTHDAY", "生日");
define("UE_LAN_BIRTHDAY_DESC", "生日");

?>