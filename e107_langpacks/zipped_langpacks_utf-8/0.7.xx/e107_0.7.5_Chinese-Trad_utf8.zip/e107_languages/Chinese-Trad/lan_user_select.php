<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_user_select.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "選擇會員");
define("US_LAN_2", "選擇會員等級");
define("US_LAN_3", "所有會員");
define("US_LAN_4", "尋找會員");
define("US_LAN_5", "已找到會員");
define("US_LAN_6", "搜尋");
?>