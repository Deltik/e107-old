<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 web網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_np.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("NP_1", "前一頁");
define("NP_2", "後一頁");
define("NP_3", "前往頁面");

?>