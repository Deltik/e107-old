<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 web網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_email.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Email");

define("LAN_5", "寄此文章給朋友");
define("LAN_6", "寄此新聞項目給朋友");
define("LAN_7", "登入名稱: ");
define("LAN_8", "評論");
define("LAN_9", "抱歉 - 無法寄出信件");
define("LAN_10", "信件寄給");
define("LAN_11", "信件寄給");
define("LAN_12", "錯誤");
define("LAN_106", "此為無效的電子信箱");
define("LAN_185", "寄出文章");
define("LAN_186", "寄出新聞項目");
define("LAN_187", "寄出Email信箱位址 ");
define("LAN_188", "我想您可能有興趣知道該故事來自於");
define("LAN_189", "我想您可能有興趣知道該文章來自於");

define("LAN_email_1", "來自於:");
define("LAN_email_2", "寄信人的IP :");
define("LAN_email_3", "已寄送的項目來自於 ");
define("LAN_email_4", "寄出信件");
define("LAN_email_5", "寄出項目給朋友");
define("LAN_email_6", "我想您可能有興趣知道該項目來自於");


?>