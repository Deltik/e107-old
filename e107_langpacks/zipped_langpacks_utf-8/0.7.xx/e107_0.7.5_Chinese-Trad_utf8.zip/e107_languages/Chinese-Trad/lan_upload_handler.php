<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_upload_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "檔案類型");
define("LANUPLOAD_2", "是不被允許將會被刪除.");
define("LANUPLOAD_3", "上傳成功");
define("LANUPLOAD_4", "相關的資料夾或是相關權限未不可寫入. (chmod 777)");
define("LANUPLOAD_5", "檔案大於php.ini的 upload_max_filesize 設定大小 .");
define("LANUPLOAD_6", "上傳檔案超過e MAX_FILE_SIZE 設定.");
define("LANUPLOAD_7", "已上傳檔案僅有部份成功.");
define("LANUPLOAD_8", "沒有任何檔案已上傳.");
define("LANUPLOAD_9", "已上傳檔案大小為 0 bytes");
define("LANUPLOAD_10", "上傳失敗 [Duplicate filename] - 檔案名稱已存在.");
define("LANUPLOAD_11", "檔案未上傳. 檔案名稱: ");
define("LANUPLOAD_12", "錯誤");

?>