<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 web網站 system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_request.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:31 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "下載錯誤");
define("LAN_dl_62", "您已經保護該檔案, 您超過檔案流量了");
define("LAN_dl_63", "您沒有相關的權限來下載該檔案.");
define("LAN_dl_64", "返回");
define("LAN_dl_65", "沒有找到該檔案");

?>