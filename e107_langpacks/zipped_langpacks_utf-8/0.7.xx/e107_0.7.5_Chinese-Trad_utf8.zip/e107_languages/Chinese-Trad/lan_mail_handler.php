<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Trad/lan_mail_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:12:30 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "產生於 e107 網站系統");
define("LANMAILH_2", "此格式為多部份訊息（ MIME 格式）.");
define("LANMAILH_3", " 不是一般的模式");
define("LANMAILH_4", "伺服器拒絕該網址");
define("LANMAILH_5", "伺服器沒有回應");
define("LANMAILH_6", "無發找到 E-Mail 伺服器.");
define("LANMAILH_7", " 似乎為有效的.");


?>