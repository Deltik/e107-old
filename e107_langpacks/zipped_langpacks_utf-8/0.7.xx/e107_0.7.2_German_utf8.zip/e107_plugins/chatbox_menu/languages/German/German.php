<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Â©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/German.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:52:37 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
	
define("CHATBOX_L1", "Dieser Eintrag kann nicht akzeptiert werden, bis dieser Benutzername registriert ist - falls es Ihr Benutzername ist, loggen Sie sich bitte ein um schreiben zu können.");
define("CHATBOX_L2", "Chatbox");
define("CHATBOX_L3", "Sie müssen eingelogged sein um Kommentare auf dieser Seite schreiben zu können - bitte loggen Sie sich entweder ein oder registrieren Sie sich <a href='".e_BASE."signup.php'>hier</a>");
define("CHATBOX_L4", "Abschicken");
define("CHATBOX_L5", "Zurücksetzen");
define("CHATBOX_L6", "[vom Admin geblockt]");
define("CHATBOX_L7", "Blocken aufheben");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Block");
define("CHATBOX_L10", "Löschen");
define("CHATBOX_L11", "Keine Nachrichten bis jetzt.");
define("CHATBOX_L12", "Alle Einträge ansehen");
define("CHATBOX_L13", "Chatbox moderieren");
define("CHATBOX_L14", "Smilies");
define("CHATBOX_L15", "Der Eintrag ist zu lang, oder es wurde ein leerer Eintrag getätigt.");
define("CHATBOX_L16", "Unbekannt");
define("CHATBOX_L17", "Doppelter Eintrag");
define("CHATBOX_L18", "Chatbox Nachricht moderiert");
define("CHATBOX_L19", "Sie können nur alle ".FLOODTIMEOUT." Sekunden eine Nachricht eingeben");
define("CHATBOX_L20", "Chatbox (Alle Einträge)");
define("CHATBOX_L21", "Chat Einträge");
define("CHATBOX_L22", "am");
define("CHATBOX_L23", "Fehler!");
define("CHATBOX_L24", "Sie haben nicht die erforderlichen Rechte, diese Seite anzusehen.");
define("CHATBOX_L25", "[ dieser Eintrag wurde vonm Admin geblockt ]");



define("NT_LAN_CB_1", "Chatbox Ereignisse");
define("NT_LAN_CB_2", "Nachricht gepostet");
define("NT_LAN_CB_3", "Geschrieben von");
define("NT_LAN_CB_4", "IP Adresse");
define("NT_LAN_CB_5", "Nachricht");
define("NT_LAN_CB_6", "Chatbox Nachricht gepostet");

	
?>
