<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	Â©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
|   $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+---------------------------------------------------------------+
*/

define("CM_L1", "Keine Kommentare bis jetzt.");
define("CM_L2", "");
define("CM_L3", "Überschrift");
define("CM_L4", "Anzahl der Kommentare die angezeigt werden sollen?");
define("CM_L5", "Anzahl der Zeichen die angezeigt werden sollen?");
define("CM_L6", "Postfix für zu lange Kommentare?");
define("CM_L7", "Den orginalen Newstitel im Menü anzeigen?");
define("CM_L8", "Neue Kommentare Menü Konfiguration");
define("CM_L9", "Menüeinstellungen aktualisiert");
define("CM_L10", "Kommentarmenü Konfiguration gespeichert");


?>
