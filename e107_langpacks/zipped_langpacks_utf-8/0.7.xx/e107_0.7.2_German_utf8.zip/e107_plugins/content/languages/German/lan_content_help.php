<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content_help.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/05/14 16:46:43 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("CONTENT_ADMIN_HELP_ORDER_1", "
<i>Diese Seite zeigt alle bestehenden Kategorien und Unerkategorien.</i><br /><br />
<b>Ausführliche Liste</b><br />Sie sehen die Kategorie Id und den Kategorie Namen. Ausserdem sehen Sie verschiedene Optionen, die Sortierung der Kategorien zu managen.<br />
<br />
<b>Erklärung der Icons</b><br />
".CONTENT_ICON_ORDERALL." Managed die globale Sortierung der Inhaltseinträge unabhängig von Kategorien.<br />
".CONTENT_ICON_ORDERCAT." Managed die Sortierung der Inhaltseinträge in der speziellen Kategorie.<br />
<img src='".e_IMAGE."admin_images/up.png' alt='' /> Der -Nachoben-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach oben zu verschieben.<br />
<img src='".e_IMAGE."admin_images/down.png' alt='' /> Der -Nachunten-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach unten zu verschieben.<br />
<br />
<b>Sortierung</b><br />Hier können sie manuell die Sortierung der Kategorien inerhalb der Hauptkategorien vornehmen. Hierzu müssen Sie den Wert in den Auswahlboxen ändern und dann den Aktualisierungsbutton klicken, um die Neue Sortierung abzuspeichern.<br />
");
define("CONTENT_ADMIN_HELP_ORDER_2", "
<i>Diese Seite zeigt alle Inhaltseinträge der Kategorie , die Sie ausgewählt haben.</i><br /><br />
<b>Ausführliche Liste</b><br />Sie sehen die Inhalts Id, den Inhalts Autor und die Inhaltsüberschrift. Ausserdem sehen Sie verschiedene Optionen, die Sortierung der Inhaltseinträge zu managen.<br />
<br />
<b>Erklärung der Icons</b><br />
<img src='".e_IMAGE."admin_images/up.png' alt='' /> Der -Nachoben-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach oben zu verschieben.<br />
<img src='".e_IMAGE."admin_images/down.png' alt='' /> Der -Nachunten-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach unten zu verschieben.<br />
<br />
<b>Sortierung</b><br />Hier können sie manuell die Sortierung der Kategorien inerhalb der Hauptkategorien vornehmen. Hierzu müssen Sie den Wert in den Auswahlboxen ändern und dann den Aktualisierungsbutton klicken, um die Neue Sortierung abzuspeichern.<br />
");
define("CONTENT_ADMIN_HELP_ORDER_3", "
<i>Diese Seite zeigt alle Inhaltseinträge der Haupt-Kategorie , die Sie ausgewählt haben.</i><br /><br />
<b>Ausführliche Liste</b><br />Sie sehen die Inhalts Id, den Inhalts Autor und die Inhaltsüberschrift. Ausserdem sehen Sie verschiedene Optionen, die Sortierung der Inhaltseinträge zu managen.<br />
<br />
<b>Erklärung der Icons</b><br />
<img src='".e_IMAGE."admin_images/up.png' alt='' /> Der -Nachoben-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach oben zu verschieben.<br />
<img src='".e_IMAGE."admin_images/down.png' alt='' /> Der -Nachunten-Button- erlaubt es Ihnen einen Inhaltseintrag in der Sortierung eins nach unten zu verschieben.<br />
<br />
<b>Sortierung</b><br />Hier können sie manuell die Sortierung der Kategorien inerhalb der Hauptkategorien vornehmen. Hierzu müssen Sie den Wert in den Auswahlboxen ändern und dann den Aktualisierungsbutton klicken, um die Neue Sortierung abzuspeichern.<br />
");



define("CONTENT_ADMIN_HELP_SUBMIT_1", "
<i>Auf dieser Seite sehen Sie eine Liste aller Inhaltseinträge, die durch User übermittelt wurden.</i><br /><br />
<b>Ausführliche Liste</b><br />Sie sehen eine Liste dieser Inhaltseinträge mit deren Id, Icon, Hauptkategorie, Überschrift [Unter-Überschrift], Autor und Optionen.<br /><br />
<b>Optionen</b><br />Sie können mit den angezeigten Buttons Inhaltseinträge vornehmen oder löschen.
");



define("CONTENT_ADMIN_HELP_CAT_1", "
<i>Diese Seite zeigt alle verfügbaren Haupt- und Unterkategorien.</i><br /><br />
<b>Ausführliche Liste</b><br />Sie sehen einen Liste aller Unterkategorien mit deren Id, Icon, Autor, Kategorie [Unterüberschrift] und Optionen.<br />
<br />
<b>Erklärung der Icons</b><br />
".CONTENT_ICON_EDIT." : für alle Kategorien können Sie diesen Button klicken um Sie zu bearbeiten.<br />
".CONTENT_ICON_DELETE." : für alle Kategorien können Sie diesen Button klicken um sie zu löschen.<br />
".CONTENT_ICON_OPTIONS." : für alle Hauptkategorien (oben auf der Liste) können Sie diesen Button klicken um Optionen zu setzen und bearbeiten.<br />
");
define("CONTENT_ADMIN_HELP_CAT_2", "
".CONTENT_ICON_CONTENTMANAGER_SMALL." : (Nur für den Seitenadmin) für jede Unterkategorie können Sie diesen Button klicken um den persönlichen Inhaltsmanager für andere Admins zu managen.<br />
<br />
<b>Persönlicher Inhaltsmanager</b><br />Sie können verschiedenen Kategorien Admins zuweisen. Dadurch können diese Admins, ihre persönlichen Inhaltseinträge dieser Kategorie ausserhalb der Administrationsseite managen (content_manager.php).
");
define("CONTENT_ADMIN_HELP_CAT_3", "
<i>Diese Seite erlaubt Ihnen, neue Kategorien zu erstellen</i><br /><br />
IMMER ZUERST EINEN HAUPTKATEGORIE WÄHLEN, BEVOR SIE DIE ANDEREN FELDER AUSFÜLLEN !<br /><br />
Dies muss getan werden, da Kategorievoreinstellungen im System geladen werden müssen.
");
define("CONTENT_ADMIN_HELP_CAT_4", "
<i>Diese Seite zeigt das Kategoriebearbeitungsformular.</i><br /><br />
<b>Kategoriebearbeitungsformular</b><br />Sie können nun alle Informationen für diese (Unter)Kategorien bearbeiten und die Änderungen übermitteln.
");
define("CONTENT_ADMIN_HELP_CAT_5", "
");
define("CONTENT_ADMIN_HELP_CAT_6", "
<i>Diese Seite zeigt die Optionen, die Sie für diese Hauptkategorie setzen können. Für jede Hauptkategorie können eigene spezifische Optionen gesetzt werden.</i><br /><br />
<b>Gesetzte Werte</b><br />Gesetzt ist, dass ale Werte präsent sind und in den Voreinstellungen aktualisiert, wenn Sie diese Seite ansehen, sie können aber jedwede Änderungen vornehmen und Ihren Bedürfnissen anpassen.<br /><br />
<b>Teilung in acht Bereiche</b><br />Die Optionen sind in acht Hauptbereiche unterteilt. Die verschiedEnen Bereiche sehen Sie im rechten Menü.<br /><br />
<b>Erstellen</b><br />in diesem Bereich können Sie Optionen festlegen für die Erstellung von Inhaltseinträgen auf den Adminseiten.<br /><br />
<b>Übermitteln</b><br />in diesem Bereich können Sie die Optionen für das Übermittlungsformular der Inhaltseinträge festlegen.<br /><br />
<b>Pfad und Theme</b><br />in diese Bereich können Sie ein Theme für diese Hauptkategorie setzen, und Pfade angeben, wo Sie die Bilder zu dieser Hauptkategorie abgespeichert haben.<br /><br /><b>general</b><br />in this section you can specify general options to use throughout all the content pages.<br /><br />
<b>Auflistung der Seiten</b><br />in diesem Bereich können Sie Optionsseiten anlegen, wo Inhaltseinträge gelisted werden.<br /><br />
<b>Kategorie Seiten</b><br />in diesem Bereich können Sie festlegen, wie die Kategorieseiten angezeigt werden sollen.<br /><br />
<b>Inhalts Seiten</b><br />in diesem Bereich können Sie festlegen, wie die Inhaltsseiten angezeigt werden sollen.<br /><br />
<b>Menü</b><br />In diesem Bereich können Sie Optionen für die Menüs in dieser Hauptkategorie setzen.<br /><br />
");
define("CONTENT_ADMIN_HELP_CAT_7", "
<i>Auf dieser Seite können Sie den ausgewählten Kategorien, die sie geklickt haben, Admins zuweisen</i><br /><br />
Weisen Sie die Admins von der linken Spalte zu, indem Sie auf deren Namen klicken. Sie sehen dann die Namen der Admins auf die rechte Seite wechseln.
");

define("CONTENT_ADMIN_HELP_ITEMCREATE_1", "
<b>Kategorie</b><br />Bitte wählen Sie eine Kategorie aus der Auswahlbox, in der Sie einen Inhaltseintrag vornehmen wollen.<br />
");
define("CONTENT_ADMIN_HELP_ITEMCREATE_2", "
Immer zuerst eine Kategorie auswählen, bevor Sie andere Felder ausfüllen !<br />
dies ist nötig, da jede Hauptkategorie (und Unterkategorie in ihr) eigene Voreinstellungen haben können.<br /><br />
<b>Erstellungsformular</b><br />Sie können nun alle Informationen für diesen Inhaltseintrag festlegen und übermitteln.<br /><br />
Es sei nochmals daran erinnert, dass jede Hauptkategorie ihre eigenen Voreinstellungen haben kann, wodurch sie mehr Felder zur Verf&uum;gung haben können.
");


define("CONTENT_ADMIN_HELP_ITEM_1", "
<i>Falls Sie bis jetzt keine Hauptkategorien angelegt haben, gehen Sie bitte auf die <a href='".e_SELF."?type.0.cat.create'>Neue Kategorie erstellen</a> Seite.</i><br /><br />
<b>Kategorie</b><br />Wählen Sie eine Kategorie aus dem  Pull-Down Menü um Inhalt für diese Kategorie zu managen.<br /><br />
Die Hauptkategorien werden fettgedruckt angezeigt und haben das (ALL) extenstion nach ihnen angezeigt. Eines dieser ausgewählt, wird alle Einträge dieser Hauptkategorie anzeigen.<br /><br />
Für jede Hauptkategorie werden alle Unterkategorien angezeigt inclusive der Überkategorie (sie werden alle in Plain Text angezeigt). Wenn Sie eine dieser Kategorien auswählen werden nur Einträge dieser Kategorie angezeigt.
");
define("CONTENT_ADMIN_HELP_ITEM_2", "
<b>Erste Buchstaben</b><br />Falls mehrere Inhaltseinträge mit Anfangsbuchstaben der Inhaltsüberschriften vorhanden sind, sehen Sie verschiedene Buttons um Inhaltseinträge auszuwählen mit demselben Anfangsbuchstaben. Wenn Sie den 'alle' Button auswählen, werden alle Inhaltseinträge dieser Kategorie angezeigt.<br /><br />
<b>Ausführliche Liste</b><br />Sie sehen eine Liste aller Inhaltseinträge mit deren Id, Icon, Autor, Überschrift [Unter-Überschrift] und Optionen.<br /><br />
<b>Erklärung der Icons</b><br />
".CONTENT_ICON_EDIT." : Inhaltseintrag bearbeiten.<br />
".CONTENT_ICON_DELETE." : Inhaltseintrag löschen.<br />
");


define("CONTENT_ADMIN_HELP_ITEMEDIT_1", "
<b>Bearbeitungsformular</b><br />Sie können hier alle Informationen zu dem Inhaltseintrag bearbeiten und die Änderungen übermitteln.<br /><br />
falls Sie die Kategorie dieses Inhaltseintrags einer anderen Hauptkategorie zuweisen wollen, müssten Sie eventuel den Newseintrag nochmals bearbeiten, nach der Kategorieverschiebung.<br />Da sie die Hauptkategorie gewechselt haben und somit andere Voreinstellungen gegeben sein können.
");

define("CONTENT_ADMIN_HELP_1", "Inhalts Management Hilfe Bereich");


define("CONTENT_ADMIN_HELP_ITEM_LETTERS", "Unten sehen Sie die verfuuml;gbaren Buchstaben der Inhaltsüberschriften der Inhaltseintäge dieser Kategorie.<br />By clicking on one of the letters you will see a list of all items starting with the selected letter. You can also choose the ALL button to display all items in this category.");


?>
