<?php

define("LAN_ALT_1", "Bestehender Authorisationstypus");

define("LAN_ALT_2", "Einstellungen aktualisieren");

define("LAN_ALT_3", "Alternativen Authorisationstypus wählen");

define("LAN_ALT_4", "Parameter konfigurieren für");

define("LAN_ALT_5", "Authorisationsparameter konfigurieren");

define("LAN_ALT_6", "Fehlerhafter Verbindungsversuch");

define("LAN_ALT_7", "Wie sollte damit umgegangen werden wenn eine Verbindung über die alternative Methode fehlschlägt?");

define("LAN_ALT_8", "Aktion Benutzer nicht gefunden");

define("LAN_ALT_9", "Wie sollte damit umgegangen werden, wenn ein Benutzer nicht gefunden wird bei Verwendung der alternitiven Methode?");



define("LAN_ALT_FALLBACK", "e107 Benutzertabellen benutzen");

define("LAN_ALT_FAIL", "Fehlerhaftes Login");



?>
