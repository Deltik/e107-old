<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/e107v4a/languages/German.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/03/21 10:50:01 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Lese/Schreibe Kommentare: ");
define("LAN_THEME_2", "Kommentare sind abgeschalten");
define("LAN_THEME_3", "Weiterlesen...");
define("LAN_THEME_4", "Geschrieben von");
define("LAN_THEME_5", "am");
define("LAN_THEME_6", "e107.v4 theme von <a href='http://e107.org' rel='external'>jalist</a>");

?>
