<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_subcontent.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/09 03:32:07 $
|     $Author: chavo $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "Danke, Ihr Artikel wurde gespeichert und wird von einem Seiten Administrator baldmöglichst überprüft.");
define("ARLAN_1", "Es wurden Felder frei gelassen.");
define("ARLAN_2", "Danke, Ihr Bericht wurde gespeichert und wird von einem Seiten Administrator baldmöglichst überprüft.");
define("ARLAN_15", "Übermittle Artikel");
define("ARLAN_17", "Überschrift");
define("ARLAN_18", "Unter-Überschrift");
define("ARLAN_19", "Zusammenfassung");
define("ARLAN_20", "Artikel");
define("ARLAN_21", "Erlaube Kommentare?");
define("ARLAN_22", "an");
define("ARLAN_23", "aus");
define("ARLAN_24", "Email hinzufügen/Icons drucken?");
define("ARLAN_25", "Ja");
define("ARLAN_26", "Nein");
define("ARLAN_27", "Übermittle Artikel");
define("ARLAN_28", "Voransicht");
define("ARLAN_55", "Sichtbar für");
define("ARLAN_73", "Öffne den Html-Editor");
define("ARLAN_74", "Kategorie");
define("ARLAN_75", "Keine");
define("ARLAN_82", "Autor Details");
define("ARLAN_84", "Autor Name");
define("ARLAN_85", "Autor Email Adresse");
define("ARLAN_86", "Bericht");
define("ARLAN_87", "Beurteilung");
define("ARLAN_88", "Bitte wählen Sie eine Beurteilung");
define("ARLAN_89", "Übermittle Bericht");

define("ARLAN_90", "Sie haben erforderliche Felder frei gelassen, bitte benutzen Sie den Zurück-Button in Ihrem Browser und überprüfen Sie Ihre Angaben.");
define("ARLAN_91", "Erneute Voransicht");
define("ARLAN_92", "Bitte geben Sie Ihren Namen/Email-Adresse an.");

define("ARLAN_93", "Artikel");
define("ARLAN_94", "Bericht");
define("ARLAN_95", "Das Über,itteln von Artikeln durch Benutzer ist momentan nicht möglich");
define("ARLAN_96", "Das Über,itteln von Berichten durch Benutzer ist momentan nicht möglich");
define("ARLAN_97", "Sie haben nicht die nötigen Rechte um Artikel zu schreiben");
define("ARLAN_98", "Sie haben nicht die nötigen Rechte um Berichte zu schreiben");

define("ARLAN_99", "Was möchten Sie übermitteln?");
define("ARLAN_100", "News");
define("ARLAN_101", " Ereignis");
define("ARLAN_102", "Artikel");
define("ARLAN_103", "Bericht");
define("ARLAN_104", "Link");
define("ARLAN_105", "Download");
define("ARLAN_106", "Eintrag übermitteln");
?>
