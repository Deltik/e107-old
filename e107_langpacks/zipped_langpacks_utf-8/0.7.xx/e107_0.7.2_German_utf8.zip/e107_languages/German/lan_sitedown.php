<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define
define("PAGE_NAME", "Vorübergehend geschlossen ");
define("LAN_00", "ist vorübergehend geschlossen");
define("LAN_01", "Diese Seite wurde vorübergehend geschlossen, um wichtige Wartungsarbeiten durchzuführen. Das sollte nicht lange dauern. Bitte kommen Sie bald wieder. Wir bitten um Entschuldigung für diesen Umstand.");


?>
