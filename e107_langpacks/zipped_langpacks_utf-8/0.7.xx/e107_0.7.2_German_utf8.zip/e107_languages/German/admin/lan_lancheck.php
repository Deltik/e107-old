<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/10 21:31:57 $
|     $Author: loloirie $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Sprache auswählen um zu überprüfen");
define("LAN_CHECK_2", "Überprüfung starten");
define("LAN_CHECK_3", "Überprüfung abschalten");
define("LAN_CHECK_4", "Dateien fehlen!");
define("LAN_CHECK_5", "Phrasen fehlen!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "Phrase");

define("LAN_CHECK_8", "Eine Datei fehlt...");
define("LAN_CHECK_9", " Dateien fehlen...");
define("LAN_CHECK_10", "Kritischer Fehler: ");
define("LAN_CHECK_11", "Keine Dateien fehlen !");
define("LAN_CHECK_12", "Eine Datei ist fehlerhaft...");
define("LAN_CHECK_13", " Dateien sind fehlerhaft...");
define("LAN_CHECK_14", "Alle bestehenden Datein sind gültig !");

?>
