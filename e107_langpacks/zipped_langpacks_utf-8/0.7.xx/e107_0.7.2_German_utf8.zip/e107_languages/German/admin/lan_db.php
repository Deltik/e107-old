<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_db.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:04 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Grundeinstellungen in der Datenbank gesichert.");
define("DBLAN_2", "Klicken Sie den Button um Ihre e107 Datenbank zu sichern.");
define("DBLAN_3", "Sicherung der SQL Datenbank");
define("DBLAN_4", "Klicken Sie den Button um die Gültigkeit Ihrer e107 Datenbank zu prüfen.");
define("DBLAN_5", "Gültigkeit der Datenbank überprüfen");
define("DBLAN_6", "Klicken Sie den Button um Ihre e107 Datenbank zu optimieren.");
define("DBLAN_7", "SQL Datenbank optimieren");
define("DBLAN_8", "Klicken Sie den Button um Ihre Grundeinstellungen zu sichern.");
define("DBLAN_9", "Grundeinstellungen sichern");
define("DBLAN_10", "Datenbank Werkzeuge");
define("DBLAN_11", "mySQL Datenbank");
define("DBLAN_12", "optimiert");
define("DBLAN_13", "Zurück");
define("DBLAN_14", "Fertig");
define("DBLAN_15", "Klicken Sie hier um zu prüfen ob Datenbankupdates verfügbar sind.");
define("DBLAN_16", "Nach Updates suchen.");

?>
