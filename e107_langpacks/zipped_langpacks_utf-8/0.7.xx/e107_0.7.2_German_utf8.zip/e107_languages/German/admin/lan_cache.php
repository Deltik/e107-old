<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Aktiviere das Cache System");
define("CACLAN_2", "Setze den Cache Status");
define("CACLAN_3", "Cache System");
define("CACLAN_4", "Cache Status gesetzt");
define("CACLAN_5", "Cache leeren");
define("CACLAN_6", "Cache geleert");

define("CACLAN_7", "Cache abgestellt");
//define("CACLAN_8", "Cache Daten über MySQL gespeichert");
define("CACLAN_9", "Cache Daten als Datei auf Festplatte speichern");
define("CACLAN_10", "Das Cache Verzeichnis ist nicht beschreibbar. Bitte vergewissern Sie sich, dass dieses Verzeichnis auf CHMOD 0777 gesetzt ist");

?>
