<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_content.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:04 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("CNTLAN_1", "Felder frei gelassen.");
define("CNTLAN_2", "Inhalt in der Datenbank aktualisiert.");
define("CNTLAN_3", "Bitte markieren Sie die Box um diese Seite zu löschen");
define("CNTLAN_4", "Keine Inhaltsseiten.");
define("CNTLAN_5", "Existierende Inhaltsseiten");
define("CNTLAN_6", "Bearbeiten");
define("CNTLAN_7", "Löschen");
define("CNTLAN_8", "Markiere um zu bestätigen");
define("CNTLAN_9", "HTML Editor öffnen");
define("CNTLAN_10", "Link Name");
define("CNTLAN_11", "Seitenüberschrift");
define("CNTLAN_12", "Inhalt");
define("CNTLAN_13", "Kommentare erlauben");
define("CNTLAN_14", "An");
define("CNTLAN_15", "Aus");
define("CNTLAN_16", "Inhaltsseite aktualisieren");
define("CNTLAN_17", "Inhaltsseite erstellen");
define("CNTLAN_18", "Inhaltsseiten");
define("CNTLAN_19", "Sichtbar für");
define("CNTLAN_20", "Inhaltsseite gelöscht.");
define("CNTLAN_21", "Auto-Zeilenumbrüche");
define("CNTLAN_22", "( Falls Sie html-code schreiben, sollten Sie hier auf -off- stellen )");
define("CNTLAN_23", "Die Inhaltsseite wurde ohne Link hinzugeügt - um die Seite zu verlinken, benutzen Sie bitte folgenden Link");
define("CNTLAN_24", "Die Inhaltsseite wurde hinzugefügt und ein Link in der Hauptnavigation erstellt");
define("CNTLAN_25", "Titel");
define("CNTLAN_26", "Optionen");
define("CNTLAN_27", "Sind Sie sicher diese Inhaltseite löschen zu wollen?");
define("CNTLAN_28", "Titel");
define("CNTLAN_29", "Optionen");
define("CNTLAN_30", "Sind Sie sicher diese Inhaltsseite löschen zu wollen?");


?>
