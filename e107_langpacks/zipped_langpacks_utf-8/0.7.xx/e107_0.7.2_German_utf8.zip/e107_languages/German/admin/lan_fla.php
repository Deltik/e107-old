<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_fla.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/04/10 12:44:17 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Fehlerhafte Loginversuche");
define("FLALAN_2", "Es wurden keine fehlerhaften Loginversuche gelogged");
define("FLALAN_3", "Versuch gelöscht");
define("BANLAN_4", "Verbannung aufheben");
define("BANLAN_5", "Geben Sie IP, E-mail AdressE, oder Host ein");

define("BANLAN_7", "Grund");
define("BANLAN_8", "User verbannen");
define("BANLAN_9", "User von der Seite verbannen");
define("BANLAN_10", "IP / E-mail / Grund");
define("FLALAN_11", "markiere alle lösche Checkboxes");
define("FLALAN_12", "markiere nicht alle lösche Checkboxes");
define("FLALAN_13", "markiere all banne Checkboxes");
define("FLALAN_14", "markiere nicht alle banne Checkboxes");
define("FLALAN_15", "Die folgende IP Adresse(n) sind auto - gebannt , Benutzer hatte mehr als 10 fehlerhafte Loginversuche");
define("FLALAN_16", "Diese Auto-Verbannungs-Liste löschen");
define("FLALAN_17", "Auto-Verbannungsliste gelöscht");


?>
