<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_meta.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta Tags in Datenbank aktualisiert");
define("METLAN_2", "Meta Tags eingeben");
define("METLAN_3", "Eingabe neuer Meta Tag Einstellungen");
define("METLAN_4", "Aktualisiert");
define("METLAN_5", "Beschreibung hier eingeben");
define("METLAN_6", "tippen, sie, eine, Liste, ihrer, Keywords, hier");
define("METLAN_7", "schreiben Sie hier die Copyrighthinweise");
define("METLAN_8", "Meta Tags");

?>
