<?php
$text = "Geben Sie Ihre Seitenlinks hier ein. Hier eingetragene Links, werden im Hauptnavigationsmenü angezeigt. Für andere Links nutzen Sie bitte das Links Page Plugin.
<br />
<br />
Der Submenügenerator ist nur für e107 DHTML-Menüs sinnvoll. (TreeMenu, UltraTreeMenu, eDynamicMenu, ypSlideMenu...)";
$ns -> tablerender("Links Hilfe", $text);
?>
