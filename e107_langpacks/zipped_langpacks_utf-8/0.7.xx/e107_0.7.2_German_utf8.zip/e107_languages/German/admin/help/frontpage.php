<?php
$caption = "Erste Seite Hilfe";
$text = "Über dieses Menü können Sie die Eingangs- bzw. Startseite Ihres Internet-Auftritts bestimmen. Die Standardeinstellung ist 'news.php'. Sie können diese Einstellung auch nutzen für einen sog. Splashscreen. Das ist eine Seite, die nur bei dem ersten Besuch der Seite eines 'neuen' Nutzers erscheint.";
$ns -> tablerender($caption, $text);
?>
