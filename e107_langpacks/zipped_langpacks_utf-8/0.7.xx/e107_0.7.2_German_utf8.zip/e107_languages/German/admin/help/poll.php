<?php
$text = "Umfragen und Abstimmungen können Sie über dieses Menü steuern. Schreiben Sie den Titel der Umfrage und aktivieren die Optionen und verfassen die Fragen. Üer die Voransicht sehen Sie das Aussehen Ihrer Kundenbefragung. Dann aktivieren Sie die Aktion<br /><br />
Um die Umfragen auch sichtbar zu machen, müssen Sie ImMenü die Umfrage aktivieren 'aktiviere Umfrage'.";
$ns -> tablerender("Meinungsumfragen, Abstimmungen", $text);
?>
