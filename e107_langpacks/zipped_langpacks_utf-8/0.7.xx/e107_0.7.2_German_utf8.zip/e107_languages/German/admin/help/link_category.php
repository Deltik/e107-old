<?php
$text = "Sie können Ihre Links in unterschiedliche Kategorien aufteilen. Dadurch wird die Navigation auf Ihrer Seite einfacher und verbessert Ihr Layout.br /><br /> Jeder Link, den Sie in die Kategorie 'Main'einstellen wird in Ihrem Hauptnavigationsmenü angezeigt.";
$ns -> tablerender("Link Kategorie Hilfe", $text);
?>
