<?php
$text = "Sie können eine Nachricht erstellen, die solange erscheint, bis Sie die Checkbox deaktivieren. Diese Nachrichten können Sie für Gäste, Mitglieder und Administratoren eingeben. Die Nachrichten können Sie jederzeit über dieses Menü ändern";
$ns -> tablerender("Begrü&szlig;ungstext - Hilfe", $text);
?>
