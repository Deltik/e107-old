<?php
$text = "Sie können andere Webseiten abfragen und analysieren adere Seiten Datenbanken 'RSS' News Einspeisungen und lassen diese auf Ihrer Seite anzeigen. <br /> Geben Sie hierzu den vollen Pfad (URL) zur datenabnk an, zB http://e107.org/news.xml. Sie können einen Pfad für ein Bild angeben, wenn Sie das Original nich mögen bzw. keines definiert ist. Sie haben die Option die Datenbank (Backend) abzuschalten, falls Wartungsarbeiten anfallen.<br /><br /> Um die Überschriften auf Ihrer Homeoage zu aktivieren stellen Sie sicher, dass das Überschriften anzeigen (headlines_menu) auf der Admin Seite Menüs aktiviert ist.";

$ns -> tablerender("Überschriften", $text);
?>
