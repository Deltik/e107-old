<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_comment.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/05/06 10:57:19 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Kommentare");
define("LAN_0", "[blockiert vom Administrator]");
define("LAN_1", "Blockierung aufheben");
define("LAN_2", "Blockieren");
define("LAN_3", "Löschen");
define("LAN_4", "Info");
define("LAN_5", "Kommentare ...");
define("LAN_6", "Sie müssen angemeldet sein um auf dieser Seite Einträge machen zu können - bitte melden Sie sich an, oder wenn Sie noch nicht registriert sind, klicken Sie hier ");
define("LAN_7", "Hauptseiten Administrator");
define("LAN_8", "Kommentar");
define("LAN_9", "Kommentar senden");
define("LAN_10", "Administrator");
define("LAN_11", " Ihr Kommentar konnte nicht in die Datenbank eingetragen werden - bitte versuchen Sie es erneut ohne Sonderzeichen.");
define("LAN_16", "Benutzername: ");
define("LAN_99", "Kommentare");
define("LAN_100", "News");
define("LAN_101", "Umfragen");
define("LAN_102", "Antworten: ");
define("LAN_103", "Artikel");
define("LAN_104", "Bericht");
define("LAN_105", "Inhalt");
define("LAN_145", "Registriert: ");
define("LAN_194", "Gast");
define("LAN_195", "Registrierte Mitglieder");
define("LAN_310", "Dieser Eintrag kann nicht akzeptiert werden bis der Benutzername registriert ist - sollte es Ihr Benutzername sein, melden Sie sich bitte erst an.");
define("LAN_312", "Doppelter Eintrag - Nicht akzeptabel.");
define("LAN_313", "Ort");
define("LAN_314", "moderiere Kommentare");
define("COMLAN_1", "hier");
define("COMLAN_2", "registrieren");
define("COMLAN_3", "Fehler!");
define("COMLAN_4", 'Betreff');
define("COMLAN_5", 'Re:');
define("COMLAN_6", 'Darauf antworten');
define("COMLAN_7", 'Bewertung');
define("COMLAN_8", 'Kommentare sind gelocked');

define("LAN_315", "Trackbacks");
define("LAN_316", "Keine Trackbacks für diesen Newseintrag definiert.");
define("LAN_317", "Trackbacks moderieren");

define("LAN_318", "Kommentare bearbeiten");
define("LAN_319", "bearbeited");
define("LAN_320", "Kommentar aktualisieren");

?>
