<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: lisa_ $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner"); 

define("LAN_16", "Benutzername: ");
define("LAN_17", "Passwort: ");
define("LAN_18", "Weiter");
define("LAN_19", "Bitte geben Sie Benutzernamen und Passwort ein");
define("LAN_20", "Die Details können nicht in der Datenbank gefunden werden. Bitte wenden Sie sich an Ihren Website Administrator.");
define("LAN_21", "Banner Statistiken");
define("LAN_22", "Kunde");
define("LAN_23", "Banner ID");
define("LAN_24", "Klickraten");
define("LAN_25", "Click %");
define("LAN_26", "Einblendungen");
define("LAN_27", "Bestellte Einblendungen");
define("LAN_28", "Verbleibende Eiblendungen");
define("LAN_29", "Keine Banner");
define("LAN_30", "Unbegrenzt");
define("LAN_31", "Trifft nicht zu");
define("LAN_32", "Ja");
define("LAN_33", "Nein");
define("LAN_34", "Ende");
define("LAN_35", "Klickraten IP Adressen");
define("LAN_36", "Aktiv:");
define("LAN_37", "Start:");
define("LAN_38", "Fehler");

?>
