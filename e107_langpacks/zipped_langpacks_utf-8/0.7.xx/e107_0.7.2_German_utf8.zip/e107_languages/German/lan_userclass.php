<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/05/13 01:03:35 $
|     $Author: mcfly_e107 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Jederman (öffentlich)");
define("UC_LAN_1", "Nur für Gäste");
define("UC_LAN_2", "Keiner (inactiv)");
define("UC_LAN_3", "Nur für Mitglieder");
define("UC_LAN_4", "Nur lesen");
define("UC_LAN_5", "Nur für Admin");
?>
