<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/10 10:21:43 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Bewertung");

define("RATELAN_0", "Abstimmung");
define("RATELAN_1", "Abstimmungen");
define("RATELAN_2", "Wie würden Sie diesen Eintrag bewerten?");
define("RATELAN_3", "Danke für Ihre Abstimmung");
define("RATELAN_4", "Nicht bewertet");
define("RATELAN_5", "Bewerte");


?>
