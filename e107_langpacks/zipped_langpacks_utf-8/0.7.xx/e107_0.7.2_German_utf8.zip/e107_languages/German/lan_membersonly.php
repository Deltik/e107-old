<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_membersonly.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/07 10:28:47 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Nur für Mitglieder"); 

define("LAN_MEMBERS_0", "nur für Mitglieder zugänglicher Bereich");
define("LAN_MEMBERS_1", "Dies ist ein für Mitglieder beschränkter Bereich);
define("LAN_MEMBERS_2","um Zugriff zu erlangen <a href='".e_LOGIN."'>loggen Sie sich bitte ein</a>");
define("LAN_MEMBERS_3","oder <a href='".e_SIGNUP."'>register</a> Sie sich als Mitglied");
define("LAN_MEMBERS_4","Klicken sie hier um zur ersten Seite zurückzukehren");

?>
