<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_user_extended.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/04/25 12:13:26 $
|     $Author: mcfly_e107 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Text Box");
define("UE_LAN_2", "Radio Buttons");
define("UE_LAN_3", "Drop-Down Menü");
define("UE_LAN_4", "DB Tabellen Feld");
define("UE_LAN_5", "Textbereich");
define("UE_LAN_6", "Integer");
define("UE_LAN_7", "Datum");
define("UE_LAN_8", "Sprache");
define("UE_LAN_9", "Name");
define("UE_LAN_10", "Typ");
define("UE_LAN_11", "Benutzung");

define("UE_LAN_HIDE", "Für User verstecken");
define("UE_LAN_LOCATION", "Wohnort");
define("UE_LAN_LOCATION_DESC", "Benutzer Wohnort");
define("UE_LAN_AIM", "AIM");
define("UE_LAN_AIM_DESC", "AIM Adresse");
define("UE_LAN_ICQ", "ICQ");
define("UE_LAN_ICQ_DESC", "ICQ Nummer");
define("UE_LAN_YAHOO", "Yahoo!");
define("UE_LAN_YAHOO_DESC", "Yahoo! Adresse");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN Adresse");
define("UE_LAN_HOMEPAGE", "Homepage");
define("UE_LAN_HOMEPAGE_DESC", "Benutzer Homepage (Url)");
define("UE_LAN_BIRTHDAY", "Geburtstag");
define("UE_LAN_BIRTHDAY_DESC", "Geburtstag");

?>
