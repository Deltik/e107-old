<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: mrpete $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Druckerfreundlich");

define("LAN_86", "Kategorie:");
define("LAN_87", "von ");
define("LAN_94", "Eintrag von");
define("LAN_135", "News: ");
define("LAN_303", "Diese News sind von ");
define("LAN_304", "Artikel Titel: ");
define("LAN_305", "Untertitel: ");
define("LAN_306", "Dieser Artikel ist von ");
define("LAN_307", "Diese Seite drucken");

?>
