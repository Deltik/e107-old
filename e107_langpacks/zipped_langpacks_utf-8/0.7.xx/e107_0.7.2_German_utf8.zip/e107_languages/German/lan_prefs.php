<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/25 12:10:32 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 Powered Website");
define("LAN_PREF_2", "e107 Webseiten System");
define("LAN_PREF_3", "Diese Seite ist getragen von <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, veröffentlicht unter den Bedingungen von <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL License.");
define("LAN_PREF_4", "zensiert");
define("LAN_PREF_5", "Foren");

?>
