<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_request.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/03/10 11:12:35 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Download Fehler");
define("LAN_dl_62", "Sie können diese Datei nicht downloaden, da Sie das Download limit erreicht haben");
define("LAN_dl_63", "Sie haben keine Berechtigung diese Datei herunterzuladen.");
define("LAN_dl_64", "Zurück");
define("LAN_dl_65", "Datei nicht gefunden");

?>
