<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/07 19:06:54 $
|     $Author: mcfly_e107 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "E-Mail"); 

define("LAN_5", "E-Mail Artikel an einen Freund");
define("LAN_6", "E-Mail News an einen Freund");
define("LAN_7", "Benutzername: ");
define("LAN_8", "Kommentar");
define("LAN_9", "Sorry - E-Mail kann nicht gesendet werden");
define("LAN_10", "Mail versandt an");
define("LAN_11", "E-Mail versandt");
define("LAN_12", "Fehler");
define("LAN_106", "Dieses scheint keine gültige E-Mail Adresse zu sein");
define("LAN_185", "Artikel senden");
define("LAN_186", "News senden");
define("LAN_187", "E-Mail Adresse des Empfängers");
define("LAN_188", "Ich dachte diese News könnten Sie interessieren");
define("LAN_189", "Ich dachte dieser Artikel könnte für Sie von Interesse sein");

define("LAN_email_1", "Von:");
define("LAN_email_2", "IP Adresse des Absenders:");
define("LAN_email_3", "News von ");
define("LAN_email_4", "Email senden");
define("LAN_email_5", "Email Eintrag für einem Freund");
define("LAN_email_6", "Ich denke dieser Eintrag könnte von Interesse sein von");

?>
