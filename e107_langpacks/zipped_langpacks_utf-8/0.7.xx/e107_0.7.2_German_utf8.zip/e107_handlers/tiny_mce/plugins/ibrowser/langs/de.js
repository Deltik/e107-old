﻿// UK lang variables

tinyMCELang['lang_ibrowser_title'] = 'Bild einfügen/bearbeiten';
tinyMCELang['lang_ibrowser_desc'] = 'Bild einfügen/bearbeiten';
tinyMCELang['lang_ibrowser_library'] = 'Bibliothek';
tinyMCELang['lang_ibrowser_preview'] = 'Vorschau';
tinyMCELang['lang_ibrowser_img_sel'] = 'Bildauswahl';
tinyMCELang['lang_ibrowser_img_info'] = 'Bildinformationen';
tinyMCELang['lang_ibrowser_img_upload'] = 'Bild hochladen';
tinyMCELang['lang_ibrowser_images'] = 'Bilder';
tinyMCELang['lang_ibrowser_src'] = 'Quelle';
tinyMCELang['lang_ibrowser_alt'] = 'Beschreibung';
tinyMCELang['lang_ibrowser_size'] = 'Größe';
tinyMCELang['lang_ibrowser_align'] = 'Textausrichtung';
tinyMCELang['lang_ibrowser_height'] = 'Höhe';
tinyMCELang['lang_ibrowser_width'] = 'Breite';
tinyMCELang['lang_ibrowser_reset'] = 'Bildgröße zurücksetzen';
tinyMCELang['lang_ibrowser_border'] = 'Rand';
tinyMCELang['lang_ibrowser_hspace'] = 'HAbstand';
tinyMCELang['lang_ibrowser_vspace'] = 'VAbstand';
tinyMCELang['lang_ibrowser_select'] = 'Speichern';
tinyMCELang['lang_ibrowser_delete'] = 'Löschen';
tinyMCELang['lang_ibrowser_cancel'] = 'Abbrechen';
tinyMCELang['lang_ibrowser_uploadtxt'] = 'Datei';
tinyMCELang['lang_ibrowser_uploadbt'] = 'Hochladen';
// error messages
tinyMCELang['lang_ibrowser_error'] = 'Error';
tinyMCELang['lang_ibrowser_errornoimg'] = 'Bitte wähle ein Bild';
tinyMCELang['lang_ibrowser_errornodir'] = 'Bibiliothek existiert nicht';
tinyMCELang['lang_ibrowser_errorupload'] = 'Es ist ein Fehler beim Upload aufgetreten.\nBitter versuch es später nochmal';
tinyMCELang['lang_ibrowser_errortype'] = 'Falscher Bildtype';
tinyMCELang['lang_ibrowser_errordelete'] = 'Löschen fehlgeschlagen';
tinyMCELang['lang_ibrowser_confirmdelete'] = 'Klick OK zum löschen des Bildes!';
tinyMCELang['lang_ibrowser_error_width_nan'] = 'Breite ist keine Zahl!';
tinyMCELang['lang_ibrowser_error_height_nan'] = 'Höhe ist keine Zahl!';
tinyMCELang['lang_ibrowser_error_border_nan'] = 'Rand ist keine Zahl!';
tinyMCELang['lang_ibrowser_error_hspace_nan'] = 'Horizontalerabstand ist keine Zahl!';
tinyMCELang['lang_ibrowser_error_vspace_nan'] = 'Vertikalerabstand ist eine Zahl!';	