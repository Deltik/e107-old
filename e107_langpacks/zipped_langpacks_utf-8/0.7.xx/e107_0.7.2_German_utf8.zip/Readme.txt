/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language Files.
|     $Developement: DevTeam http://e107.org
|     $German Revision: 1.0 beta $
|     $Date: 2005/09/30 10:08:27 $
|     $Author: judy323, http://www.cms-myway.com, e107de.org
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ ISO encoded $
|     $ utf-8 encoded $
+----------------------------------------------------------------------------+
*/

INHALT:


utf-8 (utf-8 codierte Sprachfiles)


VERSION: 
e107v0.7 (only)


ANMERKUNG:

Da mit e107v0.7  die Software multilinguale Optionen hat, 
gibt es zwei verschiedene Sprachpakete.

Bitte genau lesen welches Sprachpaket f�r Sie zutrifft und welches Sie dann installieren sollten.


Generell gilt utf-8 Sprachpaket ist NICHT f�r Upgrades gedacht, sprich wenn Sie eine bereits bestehende e107 Software installiert haben
und auf 0.7 upgraden wollen, bitte das ISO-Paket verwenden.
Sollten Sie jedoch eine bereits bestehende e107 Software auf 0.7 upgraden wollen und multilingual w�nschen, m�ssten Sie utf-8 verwenden.
Dabei muss Ihnen bewusst sein, das nach dem Upgrade, bestehender Inhalt (bezieht sich vorallem auf deutsche Umlaute, �,�,�)
nicht richtig dargestellt wird, da es keine M�glichkeit gibt, momentan,  Datenbanken nach utf-8 zu konvertieren. 
Sie haben aber die M�glichkeit, h�ndisch, alle Eintr�ge die Codiert dargestellt werden , z.B. in News, forum usw. manuell zu �ndern.

Sollten Sie e107 Neuinstallieren, m�ssen Sie utf-8 codierte Files verwenden.



Installation:

Die Installation ist denkbar einfach.
F�r beide Pakete gilt: einfach unter Beibehaltung der Verzeichnisstruktur bestehende Ordner Via ftp �berschrieben.

e107_admin/language.php dann :

f�r iso: 

Gesetzte Sprache der Seite: German ausw�hlen

f�r utf-8:

Sprache:
German erstellen (multilinguale Tabellen erstellen)
-> auf German- erstellen klicken und dann ausw�hlen welche Tabellen sie multilingual erstellen wollen.
Gesetzte Sprache der Seite: German ausw�hlen


Wichtig:

Bitte Backup vorher von Datenbank und ftp-Files machen.

F�r Anmerkungen, Verbesserungsvorschl�ge, Kritik usw bitte e-mail an admin@cms-myway.com