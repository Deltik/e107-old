<?php

define("LAN_ALT_1", "Jelenlegi engedélyezés típus");
define("LAN_ALT_2", "Beállítások frissítése");
define("LAN_ALT_3", "Válassz Alternatív hitelesítés típust");
define("LAN_ALT_4", "Paraméterek beállítása a következő részére");
define("LAN_ALT_5", "Engedélyezés paramétereinek beállítása");
define("LAN_ALT_6", "Kapcsolat nem lehetséges");
define("LAN_ALT_7", "Ha a kapcsolat az alternatív módszerhez nem lehetséges, akkor hogyan legyen alkalmazva?");
define("LAN_ALT_8", "Felhasználó nem található");
define("LAN_ALT_9", "Ha a Felhasználónév nem található az alternatív módszerhez, akkor hogyan legyen alkalmazva?");

define("LAN_ALT_FALLBACK", "Használd az e107 user táblát");
define("LAN_ALT_FAIL", "Hibás bejelentkezés");



?>
