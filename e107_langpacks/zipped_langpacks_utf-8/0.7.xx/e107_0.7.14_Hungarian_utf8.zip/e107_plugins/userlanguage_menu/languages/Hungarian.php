<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.5 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UTHEME_MENU_L1", "Nyelv beállítása");
define("UTHEME_MENU_L2", "Nyelv kiválasztása");
define("UTHEME_MENU_L3", "táblák");
?>