<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("e_PAGETITLE", "Fórum statisztikák");

define("FSLAN_1", "Általános");
define("FSLAN_2", "Fórum megnyitva");
define("FSLAN_3", "Működési idő");
define("FSLAN_4", "Összes üzenet");
define("FSLAN_5", "Fórum téma");
define("FSLAN_6", "Fórum válasz");
define("FSLAN_7", "Fórum téma megtekintés");
define("FSLAN_8", "Adatbázis méret (csak fórum táblák)");
define("FSLAN_9", "Átlagos sorhosszúság a fórum táblában");
define("FSLAN_10", "Legaktívabb témák");
define("FSLAN_11", "Rang");
define("FSLAN_12", "Téma");
define("FSLAN_13", "Válasz");
define("FSLAN_14", "Indította");
define("FSLAN_15", "Dátum");
define("FSLAN_16", "Legolvasottabb témák");
define("FSLAN_17", "Olvasás");
define("FSLAN_18", "Legtöbbet írók");
define("FSLAN_19", "Név");
define("FSLAN_20", "Üzenet");
define("FSLAN_21", "Legtöbb témát nyitók");
define("FSLAN_22", "Legtöbb választ írók");
define("FSLAN_23", "Fórum statisztikák");
define("FSLAN_24", "Napi üzenet átlag");

?>
