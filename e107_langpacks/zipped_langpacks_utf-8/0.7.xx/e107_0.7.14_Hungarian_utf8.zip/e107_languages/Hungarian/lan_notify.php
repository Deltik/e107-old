<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NT_LAN_US_1", "Felhasználói regisztráció");

define("NT_LAN_UV_1", "Felhasználói regisztráció ellenörzése");
define("NT_LAN_UV_2", "Felhasználó ID: ");
define("NT_LAN_UV_3", "Felhasználó Bejelentkező Név: ");
define("NT_LAN_UV_4", "Felhasználó IP: ");


define("NT_LAN_LI_1", "Felhasználó bejelentkezett");

define("NT_LAN_LO_1", "Felhasználó kijelentkezett");
define("NT_LAN_LO_2", " kijelentkezett az oldalról");

define("NT_LAN_FL_1", "Kitiltás");
define("NT_LAN_FL_2", "Kitiltott IP címe");

define("NT_LAN_SN_1", "Beküldött hír");

define("NT_LAN_NU_1", "Frissítve");

define("NT_LAN_ND_1", "Hír törölve");
define("NT_LAN_ND_2", "Törölt hír id");

?>