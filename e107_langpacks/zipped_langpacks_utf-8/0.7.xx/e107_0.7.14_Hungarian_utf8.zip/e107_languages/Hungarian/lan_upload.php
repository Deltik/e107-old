<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Feltöltés");

define('LAN_UL_001','Érvénytelen email cím');
define('LAN_UL_002', 'Nincs jogosultságod file feltöltésre erre a szerverre.');	// LAN_403

define('LAN_UL_020', 'Hiba');
define('LAN_UL_021', 'Feltöltés sikertelen');

define("LAN_61", "Neved: ");
define("LAN_112", "E-mail címed: ");
define("LAN_144", "Weboldal URL címe: ");
define("LAN_402", "A feltöltéshez regisztrálnod kell.");
define("LAN_404", "Köszönjük. A feltöltött fájlt az adminisztrátor ellenőrizni fogja, ha megfelel a követelményeknek, akkor kirakja az oldalra.");
// define("LAN_405", "A fájl meghaladta a maximális méretet, ezért törlésre került.");
define("LAN_406", "Figyelem");
define("LAN_407", "Bármely más típusú fájl azonnali törlésre kerül.");
define("LAN_408", "Az aláhúzott");
define("LAN_409", "Fájl neve");
define("LAN_410", "Verzió");
define("LAN_411", "Fájl");
define("LAN_412", "Képernyőkép");
define("LAN_413", "Leírás");
define("LAN_414", "Demó");
define("LAN_415", "Add meg az oldal URL címét, ahol a demó elérhető");
define("LAN_416", "Feltöltés");
define("LAN_417", "Fájl feltöltése");
define("LAN_418", "Maximális fájlméret: ");
define("DOWLAN_11", "Kategória");
define("LAN_419", "Engedélyezett fájltípusok:");
define("LAN_420", "mezők kitöltése kötelező");
?>
