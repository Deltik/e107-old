<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("US_LAN_1", "Felhasználó kiválasztása");
define("US_LAN_2", "Felhasználó csoport kiválasztása");
define("US_LAN_3", "Összes felhasználó");
define("US_LAN_4", "Felhasználónév keresése");
define("US_LAN_5", "Felhasználót talált");
define("US_LAN_6", "Keresés");
?>