<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NT_LAN_1", "Értesítés");
define("NT_LAN_2", "Email értesítés bekapcsolása");
define("NT_LAN_3", "Ki");
define("NT_LAN_4", "Fő Admin");
define("NT_LAN_5", "Csoport");
define("NT_LAN_6", "Email");

define("NU_LAN_1", "Esemény");
define("NU_LAN_2", "Aláírás");
define("NU_LAN_3", "Felhasználói hozzáférés megerősítése");
define("NU_LAN_4", "Bejelentkezés");
define("NU_LAN_5", "Kijelentkezés");

define("NS_LAN_1", "Biztonsági Esemény");
define("NS_LAN_2", "Kitiltott IP");

define("NN_LAN_1", "Hír események");
define("NN_LAN_2", "Hírt beküldte");
define("NN_LAN_3", "Hírt beküldte Admin");
define("NN_LAN_4", "Hírt szerkesztette Admin");
define("NN_LAN_5", "Hírt törölte Admin");

define("NF_LAN_1", "File Események");
define("NF_LAN_2", "Felhasználó által feltöltött file");

?>
