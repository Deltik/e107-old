<?php
$caption = "Emotikonok súgó";
$text = "Beállíthatod, hogy a karakteres emotikonokat grafikus megfelelőikkel cserélje le a rendszer.<br /><br />
A lista bármikor frissíthető, bővíthető, az új emotikon képeket a(z) ".$IMAGES_DIRECTORY."emoticons könyvtárba kell feltöltened.";

$ns -> tablerender($caption, $text);
?>
