<?php
$caption = "Linkek súgó";
$text = "Írd be ide az oldalad összes főmenü linkjét. A többi linkhez használd a Links page plugint. 
<br />";
$ns -> tablerender($caption, $text);
?>
