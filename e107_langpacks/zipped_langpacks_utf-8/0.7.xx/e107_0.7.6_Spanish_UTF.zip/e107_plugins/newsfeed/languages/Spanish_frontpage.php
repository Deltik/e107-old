<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsfeed/languages/Spanish_frontpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "NewsFeeds");
define("NWSF_FP_2", "Página principal");

?>