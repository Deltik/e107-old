<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Spanish/lan_content_frontpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("CONT_FP_1", "Categoría de contenido");
define("CONT_FP_2", "Página principal");

?>