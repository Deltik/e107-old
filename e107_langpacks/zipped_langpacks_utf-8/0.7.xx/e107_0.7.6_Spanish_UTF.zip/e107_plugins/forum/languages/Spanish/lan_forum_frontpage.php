<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Spanish/lan_forum_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/03 22:34:18 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("FOR_FP_1", "Foro");

?>