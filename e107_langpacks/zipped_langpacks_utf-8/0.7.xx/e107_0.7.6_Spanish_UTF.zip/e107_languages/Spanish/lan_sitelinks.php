<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_sitelinks.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/06/17 10:47:07 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Menú Principal");
define("LAN_SITELINKS_502", "Administración");
?>