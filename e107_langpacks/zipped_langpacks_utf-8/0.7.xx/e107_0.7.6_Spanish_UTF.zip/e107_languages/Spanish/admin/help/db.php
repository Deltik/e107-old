<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/db.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Esta colección de herramientas le permitirán manejar su base de datos.";
$ns -> tablerender("Herramientas de la base de datos", $text);
?>