<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_user_select.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/19 00:30:15 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Selecciona usuario");
define("US_LAN_2", "Seleccionar clase de usuario");
define("US_LAN_3", "Todos los usuarios");
define("US_LAN_4", "Buscar usuario");
define("US_LAN_5", "Usuario(s) encontrado(s)");
define("US_LAN_6", "Buscar");
?>