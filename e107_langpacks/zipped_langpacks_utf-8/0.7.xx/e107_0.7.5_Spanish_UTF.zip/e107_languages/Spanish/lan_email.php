<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_email.php,v $
|     $Revision: 1.13 $
|     $Date: 2006/03/23 22:06:16 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Email");
define("LAN_5", "Enviar artículo a un amigo");
define("LAN_6", "Enviar noticia a un amigo");
define("LAN_7", "Nombre : ");
define("LAN_8", "Comentario");
define("LAN_9", "Lo sentimos - no se pudo enviar el email");
define("LAN_10", "Email enviado a");
define("LAN_11", "Email enviado");
define("LAN_12", "Error");

define("LAN_106", "Esta no parece una dirección de email válida");

define("LAN_185", "Enviar artículo");
define("LAN_186", "Enviar noticia");
define("LAN_187", "Email del destinatario");
define("LAN_188", "Espero que le guste esta noticia de");
define("LAN_189", "Espero que le guste este artículo de");

define("LAN_email_1", "Desde:");
define("LAN_email_2", "Dirección IP del remitente:");
define("LAN_email_3", "Noticia desde ");
define("LAN_email_4", "Enviar email");
define("LAN_email_5", "Email a un amigo");
define("LAN_email_6", "Creo que estaría interesado de este email de ");
define("LAN_email_7", "Enviar mail a alguien");
?>