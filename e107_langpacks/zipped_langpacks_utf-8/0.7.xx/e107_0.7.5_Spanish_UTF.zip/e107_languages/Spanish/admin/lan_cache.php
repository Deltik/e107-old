<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_cache.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "¿Activar Caché");
define("CACLAN_2", "Cambiar estado de la caché");
define("CACLAN_3", "Sistema de Caché");
define("CACLAN_4", "Estado de Caché cambiado");
define("CACLAN_5", "Vaciar Caché");
define("CACLAN_6", "Caché vaciada");
define("CACLAN_7", "Caché desactivada");
//define("CACLAN_8", "Guardar Caché en MySQL");
define("CACLAN_9", "Guardar Caché en archivo");
define("CACLAN_10", "La carpeta caché [e107_files\cache] no tiene permisos de escritura. Asegúrese de cambiar el directorio con CHMOD 777");
?>