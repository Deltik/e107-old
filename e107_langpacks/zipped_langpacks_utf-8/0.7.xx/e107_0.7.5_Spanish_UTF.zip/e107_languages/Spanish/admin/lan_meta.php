<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_meta.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta-tags actualizados en la base de datos");
define("METLAN_2", "Añadir Meta-tags adicionales");
define("METLAN_3", "Nueva configuración de Meta-tags");
define("METLAN_4", "Actualizado");
define("METLAN_5", "Escriba aquí su descripción");
define("METLAN_6", "Escriba, una, lista, de, sus, palabras, clave, aquí");
define("METLAN_7", "Escriba la información de Copyright aquí");
define("METLAN_8", "Meta-Tags");
define("METLAN_9", "Descripción");
define("METLAN_10", "Palabras Clave");
define("METLAN_11", "Copyright");
?>