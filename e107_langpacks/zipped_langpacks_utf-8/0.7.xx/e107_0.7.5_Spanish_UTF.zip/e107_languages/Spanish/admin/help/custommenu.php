<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/custommenu.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Desde esta página puede crear menús o páginas a medida con su propio contenido.<br /><br />
Mire en <a href='http://e107.org/e107_plugins/docs/doc.php'>http://e107.org/e107_plugins/docs/doc.php/http://e107.org/e107_plugins/docs/doc.php/Using107--->Content--->Using Custom Pages and Custom Menus </a>";

$ns -> tablerender(CUSLAN_18, $text);
?>