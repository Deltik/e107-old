<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/rss_menu/languages/Spanish.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/01/19 00:30:15 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " pueden ser sindicalizadas usando RSS.");
define("BACKEND_MENU_L2", "RSS Feeds");
define("BACKEND_MENU_L3", "Nuestras noticias");
define("BACKEND_MENU_L4", "Nuestros comentarios");
define("BACKEND_MENU_L5", "Nuestros temas de foros");
define("BACKEND_MENU_L6", "Nuestros envíos al foro");
define("BACKEND_MENU_L7", "Nuestros mensajes de chat");
define("BACKEND_MENU_L8", "Nuestros informes de bugs");
define("BACKEND_MENU_L9", "Nuestras descargas");

define("RSS_LAN01", "¿Activar Feeds separados para cada categoría de noticias?");
define("RSS_LAN02", "¿Activar Feeds separados para cada categoría de descargas?");

define("RSS_NEWS","Noticias"); 
define("RSS_COM","Comentarios"); 
define("RSS_ART","Artículos"); 
define("RSS_REV", "Anñalisis"); 
define("RSS_FT","Temas del foro"); 
define("RSS_FP","Envíos del foro"); 
define("RSS_FSP","Envío fijo del foro"); 
define("RSS_BUG","Bugtracker"); 
define("RSS_FOR","Foro"); 
define("RSS_DL","Descargas"); 

?>