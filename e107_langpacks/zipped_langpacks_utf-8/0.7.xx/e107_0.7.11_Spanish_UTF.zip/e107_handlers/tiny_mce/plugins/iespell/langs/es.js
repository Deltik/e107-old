/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/iespell/langs/es.js,v $
|     $Revision: 1.4 $
|     $Date: 2006/05/16 19:52:10 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('',{
iespell_desc : 'Ejecutar corrector ortográfico',
iespell_download : "ieSpell no detectado. Haga click en OK para ir a la página de descarga."
});

