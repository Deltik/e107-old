<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/cpage.php,v $
|     $Revision: 1.9 $
|     $Date: 2007/11/24 16:41:36 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Desde esta pantalla puede crear menus o páginas personalizada con su propio contenido dentro.<br /><br />";
//$text="Mire en <a href='http://e107.org/e107_plugins/docs/doc.php'>http://e107.org/e107_plugins/docs/doc.php/Using107--->Content--->Using Custom Pages and Custom Menus</a> para una explicación de sus características.";
$ns -> tablerender('Ayuda de páginas y menús personalizados', $text);
?>