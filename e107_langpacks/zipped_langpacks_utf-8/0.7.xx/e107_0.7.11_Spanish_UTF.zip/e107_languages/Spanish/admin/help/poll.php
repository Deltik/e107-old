<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/poll.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Puede configurar encuestas desde esta página,
solo escriba en el título y opciones de la encuesta,
previsualice y si está conforme marque la casilla para activar.<br /><br />
Para ver la votación, vaya a su página de menús y verifique que el menú de encuestas está activado.";

$ns -> tablerender("Encuestas", $text);
?>