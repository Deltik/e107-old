<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/image.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Desde aquí puede permitir / denegar a los usuarios enviar imágenes en el sitio, fijar método de cambiar tamaño y ver avatares transferidos.";
$ns -> tablerender("Ayuda de imágenes", $text);
?>