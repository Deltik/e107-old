<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_db_verify.php,v $
|     $Revision: 1.9 $
|     $Date: 2007/07/14 06:02:13 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Imposible leer fichero de datos sql<br /><br />Por favor, asegúrese de que el fichero <b>core_sql.php</b> existe en el directorio<b>/admin/sql</b>.");
define("DBLAN_2", "Verificando todo");
define("DBLAN_3", "para versión");
define("DBLAN_4", "Tabla");
define("DBLAN_5", "Campo");
define("DBLAN_6", "Estado");
define("DBLAN_7", "Notas");
define("DBLAN_8", "Mal resultado");
define("DBLAN_9", "Actualmente");
define("DBLAN_10", "Debería ser");
define("DBLAN_11", "Campo perdido");
define("DBLAN_12", "¡Campo Extra!");
define("DBLAN_13", "¡Tabla perdida!");
define("DBLAN_14", "Elegir tabla(s) a validar");
define("DBLAN_15", "Comenzar verificación");
define("DBLAN_16", "SQL Verificación - Versión");
define("DBLAN_17", "Volver");
define("DBLAN_18", "Tablas");
define("DBLAN_19", "Intento de reparación");
define("DBLAN_20", "Intentando reparar tablas");
define("DBLAN_21", "Reparar elementos seleccionados");
define("DBLAN_22", " no es leíble");
?>