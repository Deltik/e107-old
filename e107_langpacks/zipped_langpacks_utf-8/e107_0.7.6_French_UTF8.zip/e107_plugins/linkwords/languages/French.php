<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/French.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/22 12:14:47 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LWLAN_1", "Champ(s) resté(s) en blanc.");
define("LWLAN_2", "Mot-Lien sauvegardé.");
define("LWLAN_3", "Mot-Lien mis à jour.");
define("LWLAN_4", "Pas de Mot-Lien de défini pour l'instant.");
define("LWLAN_5", "Mot");
define("LWLAN_6", "Lien");
define("LWLAN_7", "Activer?");
define("LWLAN_8", "Options");
define("LWLAN_9", "Oui");
define("LWLAN_10", "Nom");
define("LWLAN_11", "Mot-Lien Existants");
define("LWLAN_12", "Oui");
define("LWLAN_13", "Non");
define("LWLAN_14", "Soumettre le Mot-Lien");
define("LWLAN_15", "Mettre à jour le Mot-Lien");
define("LWLAN_16", "Éditer");
define("LWLAN_17", "Suprimer");
define("LWLAN_18", "Êtes vous sûr de vouloir supprimer ce Mot-Lien?");
define("LWLAN_19", "Mot-Lien supprimé.");
define("LWLAN_20", "Impossible de trouver l'entrée de ce Mot-Lien .");
define("LWLAN_21", "Mots comme Lien Automatique");
define("LWLAN_22", "Activé?");
define("LWLANINS_1", "Mots-Lien");
define("LWLANINS_2", "Cette extension permet d'attribuer à des mots spécifiques un lien défini et donc d'en faire des liens");
define("LWLANINS_3", "Configurer LinkWords");
define("LWLANINS_4", "Pour configurer, veuillez cliquer sur le lien dans la section des extensions de la page accueil d'admin");


?>