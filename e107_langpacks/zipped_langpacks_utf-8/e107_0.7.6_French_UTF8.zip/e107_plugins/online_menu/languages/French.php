<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_menu/languages/French.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/27 14:43:47 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("ONLINE_L1", "Visiteurs: ");
  define("ONLINE_L2", "Utilisateurs: ");
  define("ONLINE_L3", "Sur cette page: ");
  define("ONLINE_L4", "En ligne");
  define("ONLINE_L5", "Utilisateurs");
  define("ONLINE_L6", " le plus récent");
  define("TRACKING_MESSAGE", "Le Traçeur d'Utilisateur en ligne est en ce moment désactivé, activez le <a href='".e_ADMIN."users.php?options'>ici</a></span><br />");
  ?>
