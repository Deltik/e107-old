<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/alt_auth/languages/French/lan_alt_auth_conf.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/22 12:13:53 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LAN_ALT_1", "Type d&#39;identification courant");
define("LAN_ALT_2", "Mettre à jour les réglages");
define("LAN_ALT_3", "Choisir un autre type d&#39;identification");
define("LAN_ALT_4", "Configurer les paramètres pour");
define("LAN_ALT_5", "Configurer les paramètres d&#39;identification");
define("LAN_ALT_6", "Action si échec de connexion");
define("LAN_ALT_7", "Si la connexion échoue en employant le méthode alternative, comment réagir à cela?");
define("LAN_ALT_8", "Action si l&#39;utilisateur n&#39;est pas trouvé");
define("LAN_ALT_9", "Si l&#39;identifiant (username) n'est pas trouvé en employant le méthode alternative, comment réagir à cela?");
define("LAN_ALT_FALLBACK", "Utiliser la table e107 user");
define("LAN_ALT_FAIL", "Échec de l&#39;enregistrement");


?>