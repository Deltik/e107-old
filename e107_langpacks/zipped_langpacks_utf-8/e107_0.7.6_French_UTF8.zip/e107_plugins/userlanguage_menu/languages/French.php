<?php
/*
+---------------------------------------------------------------+
|        e107 website system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/userlanguage_menu/languages/French.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/22 12:16:15 $
|        $Author: daddycool78 $
+---------------------------------------------------------------+
*/

define("UTHEME_MENU_L1", "Choisir le langage");
define("UTHEME_MENU_L2", "Sélectionner le langage");
define("UTHEME_MENU_L3", "tables");


?>