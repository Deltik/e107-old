<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_wmessage.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("WMGLAN_1", "Message pour les visiteurs");
  define("WMGLAN_2", "Message pour les utilisateurs");
  define("WMGLAN_3", "Message pour les administrateurs");
  define("WMGLAN_4", "Proposer");
  define("WMGLAN_5", "Configurer les messages de bienvenue");
  define("WMGLAN_6", "Activer ?");
  define("WMGLAN_7", "Les paramètres des messages de bienvenus ont été Mis à jour.");

  define("WMLAN_00","Messages de Bienvenue");
  define("WMLAN_01","Créer un nouveau message");
  define("WMLAN_02","Message");
  define("WMLAN_03","Visible par");
  define("WMLAN_04","Texte du Message");
  define("WMLAN_05","Message Enclos");
  define("WMLAN_06","Si vous cochez, Le message sera affiché à l'intérieur d'une boîte");
  define("WMLAN_07","Ignorez le standard du système pour utiliser {WMESSAGE} shortcode de votre thème:");
  define("WMLAN_08","Préférences");
  define("WMLAN_09","Pas de message de bienvenue installé pour le moment");
  define("WMLAN_10","Légende du Message");
  ?>
