<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_updateadmin.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/11/22 12:13:44 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("UDALAN_1", "Erreur - veuillez recommencer");
define("UDALAN_2", "Paramètres Mis à jour");
define("UDALAN_3", "Paramètres Mis à jour de");
define("UDALAN_4", "Identifiant");
define("UDALAN_5", "Mot de passe");
define("UDALAN_6", "Retaper le mot de passe");
define("UDALAN_7", "Changer de mot de passe");
define("UDALAN_8", "Mise à jour du mot de passe de");


?>