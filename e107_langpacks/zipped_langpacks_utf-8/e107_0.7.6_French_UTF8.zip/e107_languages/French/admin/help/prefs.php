<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Vos préférences vous permettent de spécifier tous les paramètres importants sur votre site, du nom de site à la description de la protection contre le flood (inondation) ou encore au filtrage des injures.";
  $ns -> tablerender("Aide Préférences ", $text);
  ?>
