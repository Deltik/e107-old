<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/users.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Cette page permet de modérer les utilisateurs enregistrés. Vous pouvez modifier leurs paramètres, leur donner le statut d'administrateur, les intégrer dans un groupe ...";
  $ns -> tablerender("Aide Utilisateurs", $text);
  unset($text);
  ?>