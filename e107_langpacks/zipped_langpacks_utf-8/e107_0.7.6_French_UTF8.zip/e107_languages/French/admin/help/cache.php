<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/cache.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $caption = "Aide Système Cache";
  $text = "Si le cache est activé, la fluidité de votre site va augmenter sensiblement et réduire le nombre de requêtes SQL vers la base de données.<br /><br /><strong>IMPORTANT : Si vous êtes en train de modifier le théme, désactivez le cache sinon aucune modification ne sera visible.</strong>";
  $ns -> tablerender($caption, $text);
  ?>
