<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_userinfo.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("USFLAN_1", "Impossible de trouver l'Ip de cette personne - aucune information n'est disponible.");
  //  define("USFLAN_2", "Erreur");
  define("USFLAN_3", "Messages postés depuis l'adresse IP");
  define("USFLAN_4", "Hôte");
  define("USFLAN_5", "Cliquer ici pour transférer l'adresse IP vers la page des Bans");
  define("USFLAN_6", "ID de l'utilisateur");
  define("USFLAN_7", "Informations sur l'utilisateur");
  ?>