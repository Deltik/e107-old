<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_lancheck.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/22 12:13:44 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Vérifier le fichiers du langage");
define("LAN_CHECK_2", "Commencer la vérification");
define("LAN_CHECK_3", "Vérification de");
define("LAN_CHECK_4", "Fichier manquant !");
define("LAN_CHECK_5", "<strong>!!! Phrase manquante !!!</strong>");
define("LAN_CHECK_7", "phrase");
define("LAN_CHECK_8", "un fichier est manquant...");
define("LAN_CHECK_9", " fichiers manquants...");
define("LAN_CHECK_10", "Erreur critque: ");
define("LAN_CHECK_11", "Pas de fichier manquant !");
define("LAN_CHECK_12", "Ce fichier est non valide...");
define("LAN_CHECK_13", " Fichiers non valides...");
define("LAN_CHECK_14", "Tous les Fichiers sont valides  !");
define("LAN_CHECK_15", "Caractère illégaux trouvés devant '&lt;?php'");
define("LAN_CHECK_16", "Fichier original");
define("LAN_CHECK_17", "Un problème d'écriture est survenu lors de la tentative d'enregistrement du fichier.");
define("LAN_CHECK_18", "Les fichiers de langage au format standard ne sont PAS disponible pour cet extension/thème.");
define("LAN_CHECK_19", "Caractères non-UTF-8 trouvé !");


?>