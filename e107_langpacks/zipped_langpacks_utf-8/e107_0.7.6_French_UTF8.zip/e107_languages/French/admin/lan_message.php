<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_message.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("MESSLAN_1", "Messages Reçus");
  define("MESSLAN_2", "Supprimer le Message");
  define("MESSLAN_3", "Message supprimé.");
  define("MESSLAN_4", "Supprimer tous les Messages");
  define("MESSLAN_5", "Confirmer");
  define("MESSLAN_6", "Tous les Messages ont été supprimés.");
  define("MESSLAN_7", "Pas de Messages.");
  define("MESSLAN_8", "Type de Message");
  define("MESSLAN_9", "Fait en rapport");
  define("MESSLAN_10", "Proposé par");
  define("MESSLAN_11", "Ouvrir dans une nouvelle fenêtre");
  define("MESSLAN_12", "Message");
  define("MESSLAN_13", "Lien");
  ?>
