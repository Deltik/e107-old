<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_links.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Liens");
  define("LAN_61", "Catégories de liens");
  define("LAN_62", "catégories");
  define("LAN_63", "catégorie");
  define("LAN_64", "dans cette catégorie");
  define("LAN_65", "lien");
  define("LAN_66", "liens");
  define("LAN_67", "Voir tous les liens");
  define("LAN_68", "éditer");
  define("LAN_69", "supprimer");
  define("LAN_86", "Catégorie:");
  define("LAN_88", "Référence :");
  define("LAN_89", "Admin : ");
  define("LAN_90", "ajouter un nouveau lien dans cette catégorie");
  define("LAN_91", "ajouter une nouvelle catégorie");
  define("LAN_92", "Proposer un lien");
  define("LAN_93", "Après avoir proposé votre lien, il sera vérifié par un administrateur et ajouté dans les liens du site. L'administrateur est en droit de refuser votre proposition de lien si il ne répond pas à ses attentes.");
  define("LAN_94", "Nom du Lien:");
  define("LAN_95", "URL du lien (adresse):");
  define("LAN_96", "Description du lien:");
  define("LAN_97", "Bouton pour lien URL:");
  define("LAN_98", "Proposer un lien");
  define("LAN_99", "Merci");
  define("LAN_100", "Votre lien a été enregistré et sera examiné par un administrateur.");
  define("LAN_101", "Veuillez cliquer ici pour proposer un lien");
  define("LAN_102", "Il y");
  define("LAN_103", "a");
  define("LAN_104", "a");
  define("LAN_105", "au total dans");
  define("LAN_106", "Les champs soulignés sont obligatoires.");
  define("LAN_Links_1", "Nombre total de liens");
  define("LAN_Links_2", "Nombre total de liens activés");
  define("LAN_LINKS_3", "Anonyme");
  ?>
