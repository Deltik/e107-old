<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_userclass.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("UC_LAN_0", "Tout le monde (public)");
  define("UC_LAN_1", "Visiteurs seulement");
  define("UC_LAN_2", "Personne (inactif)");
  define("UC_LAN_3", "Utilisateurs seulement");
  define("UC_LAN_4", "Lecture seule");
  define("UC_LAN_5", "Administrateurs");
define("UC_LAN_6", "Administrateur principal");
  ?>
