<?php
/**
* PHPMailer language file.
* English Version
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'คุณต้องกรอกข้อมูลอย่างน้อย 1 อย่าง' . 'ชื่อที่อยู่ผู้รับอีเมล.';
$PHPMAILER_LANG["mailer_not_supported"] = ' ตัวส่งอีเมลไม่สนับสนุน/ทำงาน.';
$PHPMAILER_LANG["execute"] = 'เปิดใช้ไม่ได้: ';
$PHPMAILER_LANG["instantiate"] = 'ไม่สามารถใช้งานระบบส่งอีเมลได้.';
$PHPMAILER_LANG["authenticate"] = 'SMTP ผิดพลาด : ไม่สามารถรับรองสิทธิ์ได้.';
$PHPMAILER_LANG["from_failed"] = 'รายชื่อที่อยู่ที่ล้มเหลวคือ: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP ผิดพลาด : รายชื่อผู้รับต่อไปนี้ ' . 'ลัมเหลว: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP ผิดพลาด : ข้อมูลที่ไม่ยอมรับ.';
$PHPMAILER_LANG["connect_host"] = 'SMTP ผิดพลาด : ไม่สามารถเชื่อมต่อเข้า SMTP host ได้.';
$PHPMAILER_LANG["file_access"] = 'ไม่สามารถเปิดไฟล์ได้: ';
$PHPMAILER_LANG["file_open"] = 'ไฟล์เสียหาย: ไม่สามารถเปิดไฟล์: ';
$PHPMAILER_LANG["encoding"] = 'ถอดรหัสไม่ได้: ';
?>