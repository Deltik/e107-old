<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ฉSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_menu/languages/English.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/10/13 13:12:13 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร 
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translator/Developer : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/

define("ONLINE_L1", "บุคคลทั่วไป: ");
define("ONLINE_L2", "สมาชิก: ");
define("ONLINE_L3", "ในหน้านี้: ");
define("ONLINE_L4", "ผู้ที่กำลังใช้งานขณะนี้");
define("ONLINE_L5", "สมาชิก");
define("ONLINE_L6", "ล่าสุด");
define("TRACKING_MESSAGE", "การติดตามผู้ใช้งานระบบยังไม่เปิดใช้งาน กรุณาเปิดโดยคลิก<a href='".e_ADMIN."users.php?options'>ที่นี่</a><br />");
?>