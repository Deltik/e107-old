<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ฉSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/review_menu/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:53:17 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
	
define("LAN_190", "ส่งบทวิจารณ์");
define("LAN_RVW_1", "ปรับปรุงการตั้งค่าเมนู");
define("LAN_RVW_2", "บันทึกการตั้งค่าเมนูบทวิจารณ์แล้ว");
define("LAN_RVW_3", "คำอธิบาย");
define("LAN_RVW_4", "จำนวนบทวิจารณ์ที่จะแสดง");
define("LAN_RVW_5", "แสดงประเภทบทวิจารณ์ในเมนู?");
define("LAN_RVW_6", "ชื่อหน้าของรายการบทวิจารณ์");
define("LAN_RVW_7", "แสดงการเชื่อมโยงส่งบทวิจารณ์Show link to submit review?");
define("LAN_RVW_8", "การตั้งค่าเมนูบทวิจารณ์");
?>