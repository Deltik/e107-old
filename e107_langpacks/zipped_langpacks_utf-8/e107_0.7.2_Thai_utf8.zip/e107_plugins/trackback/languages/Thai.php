<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ฉSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/22 18:20:52 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "ตั้งค่าการติดตามที่มา");
define("TRACKBACK_L2", "การเลือกเปิดโปรแกรมเสริมระบบนี้ ก็เพื่อเป็นระบบติดตามที่ตั้งของผู้ส่งกระทู้เข้ามา.");
define("TRACKBACK_L3", "ได้ติดตั้งระบบติดตาม และใช้งานได้แล้ว.");
define("TRACKBACK_L4", "บันทึกการตั้งค่าการติดตาม แล้ว.");
define("TRACKBACK_L5", "เปิด");
define("TRACKBACK_L6", "ปิด");
define("TRACKBACK_L7", "เปิดระบบการติดตาม");
define("TRACKBACK_L8", "ที่อยู่URLของการติดตาม ");
define("TRACKBACK_L9", "บันทึกการตั้งค่า");
define("TRACKBACK_L10", "การตั้งค่าการติดตาม ");
define("TRACKBACK_L11", "ติดตามที่อยู่ของกระทู้นี้:");

define("TRACKBACK_L12", "ไม่ีมีการติดตามของรายการนี้");
define("TRACKBACK_L13", "ตรวจสอบที่มาของเว็ป");
define("TRACKBACK_L14", "ลบ");
define("TRACKBACK_L15", "ลบการติดตาม แล้ว.");

?>