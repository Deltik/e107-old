<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ฉSteve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
	
define("BLOGCAL_L1", "เนื้อหาสาระของปี ");
define("BLOGCAL_L2", "รวมข่าวสารย้อนหลัง");
	
define("BLOGCAL_D1", "จ");
define("BLOGCAL_D2", "อ");
define("BLOGCAL_D3", "พ");
define("BLOGCAL_D4", "พฤ");
define("BLOGCAL_D5", "ศ");
define("BLOGCAL_D6", "ส");
define("BLOGCAL_D7", "อา");
	
define("BLOGCAL_M1", "เดืิอนมกราคม");
define("BLOGCAL_M2", "เดืิอนกุมภาพันธ์");
define("BLOGCAL_M3", "เดืิอนมีนาคม");
define("BLOGCAL_M4", "เดืิอนเมษายน");
define("BLOGCAL_M5", "เดืิอนพฤษภาคม");
define("BLOGCAL_M6", "เดืิอนมิถุนายน");
define("BLOGCAL_M7", "เดืิอนกรกฎาคม");
define("BLOGCAL_M8", "เดืิอนสิงหาคม");
define("BLOGCAL_M9", "เดืิอนกันยายน");
define("BLOGCAL_M10", "เดืิอนตุลาคม");
define("BLOGCAL_M11", "เดืิอนพฤศจิกายน");
define("BLOGCAL_M12", "เดืิอนธันวาคม");
	
define("BLOGCAL_1", "รายการเนื้อหาสาระ");
	
define("BLOGCAL_CONF1", "เดือน/แถว");
define("BLOGCAL_CONF2", "ระยะห่างแต่ละเซล");
define("BLOGCAL_CONF3", "ปรับปรุงการตั้งค่าเมนู");
define("BLOGCAL_CONF4", "ตั้งค่าเมนูบล็อกปฏิทิน");
define("BLOGCAL_CONF5", "บันทึกการตั้งค่าเมนูบล็อกปฏิทินแล้ว");
	
define("BLOGCAL_ARCHIV1", "เลือกเนื้อหาสาระย้อนหลัง");
	
?>