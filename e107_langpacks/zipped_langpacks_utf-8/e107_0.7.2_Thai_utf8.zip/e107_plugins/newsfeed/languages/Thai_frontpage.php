<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsfeed/languages/English_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/07 20:56:04 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "ข่าวป้อน");
define("NWSF_FP_2", "หน้าหลัก");

?>