<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ฉSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/featurebox/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/04/01 11:03:59 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/

define("FBLAN_01", "กล่องแนะนำสาระที่น่าสนใจ");
define("FBLAN_02", "โปรแกรมเสริมนี้เป็นการอนุญาตให้คุณกำหนดคุณลักษณะดีหรือเด่น น่าสนใจ ชอบ ไม่ชอบ หรือมีข้อแนะนำในรายการข่าวสาร ใช้แสดงประกอบเป็นแบบสุ่มหมุนเวียนมาแสดงโดยอัตโนมัติ");
define("FBLAN_03", "ตั้งค่ากล่องแสดงคุณลักษณะ");
define("FBLAN_04", "Feature Box plugin has been successfully installed. To add messages and configure, return to the main admin page and click on the feature box icon in the plugin section.");
define("FBLAN_05", "No feature box messages defined yet");
define("FBLAN_06", "ข้อความในกล่องแสดงคุณลักษณะ");
define("FBLAN_07", "ชื่อเรื่อง / คำอธิบาย");
define("FBLAN_08", "ข้อความ");
define("FBLAN_09", "การมองเห็นข้อความ");
define("FBLAN_10", "แนะนำสาระที่น่าสนใจCreate Feature Box Message");
define("FBLAN_11", "Update Feature Box Message");
define("FBLAN_12", "โหมด");
define("FBLAN_13", "Randomly revolve messages");
define("FBLAN_14", "แสดงข้อความนี้เท่านั้น");
define("FBLAN_15", "Message added to database.");
define("FBLAN_16", "Message updated in database.");
define("FBLAN_17", "กรอกข้อมูลไม่ครบ");
define("FBLAN_18", "Feature Box Message deleted");
define("FBLAN_19", "เลือกค่า");
define("FBLAN_20", "แก้ไข");
define("FBLAN_21", "ลบ");
define("FBLAN_22", "การแสดงผล");
define("FBLAN_23", "In theme box");
define("FBLAN_24", "Plain");
define("FBLAN_25", "ต้นแบบ");
define("FBLAN_26", "you can use a different template for each message, add templates to e107_plugins/featurebox/templates/ folder");

?>