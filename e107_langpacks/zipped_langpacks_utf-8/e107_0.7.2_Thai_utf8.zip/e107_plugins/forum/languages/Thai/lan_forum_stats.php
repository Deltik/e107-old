<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/25 11:38:50 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "สถิติกระทู้");

define("FSLAN_1", "ทั่วไป");
define("FSLAN_2", "กระทู้ที่เปิดแล้ว");
define("FSLAN_3", "เปิดไปที่");
define("FSLAN_4", "จำนวนโพส");
define("FSLAN_5", "หัวข้อกระทู้");
define("FSLAN_6", "ตอบกระทู้");
define("FSLAN_7", "Forum thread views");
define("FSLAN_8", "Database size (forum tables only)");
define("FSLAN_9", "Average row length in forum table");
define("FSLAN_10", "Most active topics");
define("FSLAN_11", "Rank");
define("FSLAN_12", "หัวข้อ");
define("FSLAN_13", "ตอบ");
define("FSLAN_14", "เริ่มโดย");
define("FSLAN_15", "วันที่");
define("FSLAN_16", "กระทู้ที่ดูมากที่สุด");
define("FSLAN_17", "เยี่ยมชม");
define("FSLAN_18", "ผู้โพสมากที่สุุด");
define("FSLAN_19", "ชื่อ");
define("FSLAN_20", "Posts");
define("FSLAN_21", "Top topic starters");
define("FSLAN_22", "ผู้ตอบมากที่สุด");
define("FSLAN_23", "สถิติกระทู้");
define("FSLAN_24", "จำนวนการโพสต่อวัน");

?>