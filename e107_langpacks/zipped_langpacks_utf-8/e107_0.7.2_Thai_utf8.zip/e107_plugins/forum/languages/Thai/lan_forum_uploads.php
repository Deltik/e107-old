<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/24 20:43:34 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','ไฟล์ที่อัพโหลดในกระทู้');
define('FRMUP_2','ไฟล์ที่ลบออกไปแล้ว');
define('FRMUP_3','Error: Unable to delete file');
define('FRMUP_4','ไฟล์ที่ทำการลบออก');
define('FRMUP_5','ชื่อไฟล์');
define('FRMUP_6','Result ผล');
define('FRMUP_7','Found in thread');
define('FRMUP_8','ไม่พบ');
define('FRMUP_9','ไม่พบไฟล์ที่ส่งขึ้น');
define('FRMUP_10','ลบ');
	
?>