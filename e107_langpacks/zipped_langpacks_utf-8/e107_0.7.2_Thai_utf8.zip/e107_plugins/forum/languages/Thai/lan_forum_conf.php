<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_conf.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/07 03:28:40 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "โพลถูกลบออก.");
define("FORLAN_6", "Thread deleted");
define("FORLAN_7", "replies deleted");
define("FORLAN_8", "การลบได้ถูกยกเลิก.");
define("FORLAN_9", "Thread moved.");
define("FORLAN_10", "การย้ายถูกยกเลิก.");
define("FORLAN_11", "กลับไปยังกระทู้");
define("FORLAN_12", "Forum Configuration");
define("FORLAN_13", "Are you absolutely certain you want to delete this poll?<br />Once deleted it <b><u>cannot</u></b> be retreived.");
define("FORLAN_14", "ยกเลิก");
define("FORLAN_15", "Confirm Delete Forum Post");
define("FORLAN_16", "ยืนยันที่จะลบโพล");
define("FORLAN_17", "โพสโดย");
define("FORLAN_18", "คุณแน่ใจว่าจะลบกระทู้อย่างแน่นอน");
define("FORLAN_19", "thread and it's related posts?");
define("FORLAN_20", "the poll will also be deleted");
define("FORLAN_21", "Once deleted they");
define("FORLAN_22", "post?<br />Once deleted it");
define("FORLAN_23", "ไม่สามารถ</u></b> นำกลับมาได้");
define("FORLAN_24", "Move thread  to forum");
define("FORLAN_25", "Move Thread");
define("FORLAN_26", "Reply deleted");
	
define("FORLAN_27", "ย้าย");

define("FORLAN_28", "Do not rename thread title");
define("FORLAN_29", "เพิ่ม");
define("FORLAN_30", "to title");
define("FORLAN_31", "เปลี่ยนชื่อเป็น:");
define("FORLAN_32", "Rename thread options:");

	
?>