<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/16 05:25:35 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "การอภิปราย");
define("FOR_SCH_LAN_2", "เลือกกระทู้ั");
define("FOR_SCH_LAN_3", "ทุกกระทู้");
define("FOR_SCH_LAN_4", "Whole post");
define("FOR_SCH_LAN_5", "As part of thread");

?>