<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ฉSteve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
	
define("CM_L1", "ยังไม่มีความเห็น.");
define("CM_L2", "");
define("CM_L3", "คำอธิบาย");
define("CM_L4", "จำนวนความเห็นที่จะแสดง?");
define("CM_L5", "จำนวนตัวอักษรที่จะแสดง?");
define("CM_L6", "Postfix หากมีการแสดงความเห็นยาว?");
define("CM_L7", "แสดงชื่อข่าวสารเดิมในเมนูหรือไม่?");
define("CM_L8", "การตั้งค่าเมนูแสดงความเห็นใหม่");
define("CM_L9", "ปรับปรุงการตั้งค่าเมนู");
define("CM_L10", "บันทึกการตั้งค่าเมนูแสดงความเห็นแล้ว");
	
	
?>