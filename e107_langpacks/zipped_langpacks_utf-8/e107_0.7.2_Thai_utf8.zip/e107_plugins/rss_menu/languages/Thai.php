<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/rss_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/10/13 18:55:26 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", " สามารถใช้งานการส่งข่าวโดยใช้ RSS feeds.ได้");
define("BACKEND_MENU_L2", "ข่าวป้อน RSS ");

define("BACKEND_MENU_L3", "ข่าวสารของเรา");
define("BACKEND_MENU_L4", "ความเห็นของเรา");
define("BACKEND_MENU_L5", "การส่งกระทู้อภิปรายของเรา");
define("BACKEND_MENU_L6", "การตอบกระทู้อภิปรายของเรา");

define("BACKEND_MENU_L7", "การส่งข้อความในกล่องสนทนาของเรา");
define("BACKEND_MENU_L8", "รายงานความผิดพลาดของเรา");
define("BACKEND_MENU_L9", "การโอนไฟล์ลง ของเรา");

define("RSS_LAN01", "สามารถแยกป้อนข่าวในแต่ละประเภทข่าวได้หรือไม่?");
define("RSS_LAN02", "สามารถแยกป้อนในแต่ละประเภทการโอนไฟล์ลงได้หรือไม่?");

define("RSS_NEWS","ข่าวสาร");
define("RSS_COM","ความคิดเห็น"); 
define("RSS_ART","บทความ");
define("RSS_REV", "บทสรุป");
define("RSS_FT","การตั้งกระทู้");
define("RSS_FP","การส่งกระทู้");
define("RSS_FSP","อภิปรายที่เจาะจงส่ง");
define("RSS_BUG","ติดตามความผิดพลาด");
define("RSS_FOR","อภิปราย");
define("RSS_DL","โอนไฟล์ลง");
?>