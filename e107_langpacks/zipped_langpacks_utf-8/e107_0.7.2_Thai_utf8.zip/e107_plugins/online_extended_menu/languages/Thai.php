<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ฉSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_extended_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/05 22:44:37 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
	
define("ONLINE_EL1", "บุคคลทั่วไป: ");
define("ONLINE_EL2", "สมาชิก: ");
define("ONLINE_EL3", "ในหน้านี้: ");
define("ONLINE_EL4", "ผู้ที่กำลังเข้าใช้ระบบ");
define("ONLINE_EL5", "สมาชิกทั้งหมด");
define("ONLINE_EL6", "สมาชิกคนล่าสุด");
define("ONLINE_EL7", "กำลังดู");
	
define("ONLINE_EL8", "เข้ามาแล้ว: ");
define("ONLINE_EL9", "เมื่อ");

define("TRACKING_MESSAGE", "ระบบการติดตามผู้ใช้ยังไม่เปิดใช้งาน กรุณาเปิดใช้งานโดยคลิก <a href='".e_ADMIN."users.php?options'>ที่นี่</a></span><br />");

?>