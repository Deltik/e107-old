<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ฉSteve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', 'บันทึกการตั้งค่าบล๊อคเมนูนาฬิกาแล้ว');
define('CLOCK_MENU_L2', 'คำอธิบาย');
define('CLOCK_MENU_L3', 'ปรับปรุงการตั้งค่าบล๊อคเมนู');
define('CLOCK_MENU_L4', 'ตั้งค่าบล๊อคเมนูนาฬิกา');
define('CLOCK_MENU_L5', 'วันจันทร์ที่');
define('CLOCK_MENU_L6', 'วันอังคารที่');
define('CLOCK_MENU_L7', 'วันพุธที่');
define('CLOCK_MENU_L8', 'วันพฤหัสบดีที่');
define('CLOCK_MENU_L9', 'วันศุกร์ที่');
define('CLOCK_MENU_L10', 'วันเสาร์ที่');
define('CLOCK_MENU_L11', 'วันอาทิตยที่');
define('CLOCK_MENU_L12', 'เดือนมกราคม');
define('CLOCK_MENU_L13', 'เดือนกุมภาพันธ์');
define('CLOCK_MENU_L14', 'เดือนมีนาคม');
define('CLOCK_MENU_L15', 'เดือนเมษายน');
define('CLOCK_MENU_L16', 'เดือนพฤษภาคม');
define('CLOCK_MENU_L17', 'เดือนมิถุนายน');
define('CLOCK_MENU_L18', 'เดือนกรกฎาคม');
define('CLOCK_MENU_L19', 'เดือนสิงหาคม');
define('CLOCK_MENU_L20', 'เดือนกันยายน');
define('CLOCK_MENU_L21', 'เดือนตุลาคม');
define('CLOCK_MENU_L22', 'เดือนพฤศจิกายน');
define('CLOCK_MENU_L23', 'เดือนธันวาคม');
define('CLOCK_MENU_L24', '');
?>