<?php
// Thai - utf-8. ldap_auth.

define("LDAPLAN_1", "ที่อยู่ของแม่ข่ายบริการ");
define("LDAPLAN_2", "ภายใต้ DN หรือ Domain<br />หากเป็น LDAP - ให้ใส่ BaseDN<br />หากเป็น AD - ให้ใส่ชื่อ domain");
define("LDAPLAN_3", "ชื่อผู้เข้าใช้ LDAP <br />Full context of the user who is able to search the directory.");
define("LDAPLAN_4", "รหัสผ่านเข้าใช้ LDAP <br />Password for the LDAP Browsing user.");
define("LDAPLAN_5", "LDAP เวอร์ชั่น");
define("LDAPLAN_6", "ตั้งค่าสิทธิ์ของ LDAP");
?>
