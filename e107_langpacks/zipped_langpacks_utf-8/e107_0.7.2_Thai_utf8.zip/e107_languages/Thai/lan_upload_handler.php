<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/05 06:58:21 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("LANUPLOAD_1", "ชนิดของไฟล์");
define("LANUPLOAD_2", "ไม่สามารถส่งไฟล์ขึ้นได้และไฟล์จะถูกลบ.");
define("LANUPLOAD_3", "ส่งไฟล์ขึ้นสำเร็จ");
define("LANUPLOAD_4", "ไม่มีแฟ้มปลายทางหรือมีแต่ไม่อนุญาตให้เขียนไฟล์ให้เปลี่ยนโหมดไฟล์เป็นโหมด 777หรืออนุญาตให้เขียนไฟล์ลงได้");
define("LANUPLOAD_5", "ขนาดไฟล์มีขนาดเกินกว่าที่ระบบแม่ข่ายกำหนดไว้ในไฟล์ php.ini.");
define("LANUPLOAD_6", "ไฟล์ที่ส่งขึ้นมีขนาดเกินกว่าที่คำสั่ง MAX_FILE_SIZE ของรูปแบบไฟล์ html.");
define("LANUPLOAD_7", "สามารถส่งไฟล์ขึ้นได้เพียงบางส่วนเท่าั้นั้น.");
define("LANUPLOAD_8", "ไม่มีไฟล์ที่จะทำการส่งขึ้น.");
define("LANUPLOAD_9", "ขนาดของไฟล์ีีที่ส่งไฟล์ขึ้นคือ 0 bytes");
define("LANUPLOAD_10", "การส่งไฟล์ขึ้นล้มเหลว เพราะมีไฟล์ชื่อนี้อยู่แล้ว.");
define("LANUPLOAD_11", "ไม่สามารถส่งไฟล์ขึ้นได้. คือไฟล์ชื่อ: ");
define("LANUPLOAD_12", "ผิดพลาด");

?>