<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: mrpete $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("PAGE_NAME", "พิมพ์ง่าย");

define("LAN_86", "ประเภท:");
define("LAN_87", "โดย ");
define("LAN_94", "ส่งโดย");
define("LAN_135", "ข่าว: ");
define("LAN_303", "ข่าวสารนี้มาจาก ");
define("LAN_304", "ชื่อเรื่อง: ");
define("LAN_305", "หัวเรื่องรอง: ");
define("LAN_306", "มาจาก: ");
define("LAN_307", "สั่งพิมพ์หน้านี้");

?>