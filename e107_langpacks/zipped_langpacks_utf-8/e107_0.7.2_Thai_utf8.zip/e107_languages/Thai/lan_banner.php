<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("PAGE_NAME", "ป้ายโฆษณา");

define("LAN_16", "ชื่อผู้ใช้: ");
define("LAN_17", "รหัสผ่าน: ");
define("LAN_18", "ต่อไป");
define("LAN_19", "กรุณาแจ้งชื่อลูกค้าและรหัสผ่านเพื่อเข้าสู่ระบบขั้นต่อไป");
define("LAN_20", "ขออภัย ไม่พบรายละเอียดในฐานข้อมูล กรุณาติดต่อผู้จัดการระบบเพื่อขอทราบรายละเอียด");
define("LAN_21", "สถิติของป้าย");
define("LAN_22", "ลูกค้า");
define("LAN_23", "รหัสป้าย");
define("LAN_24", "คลิกเข้าดู");
define("LAN_25", "% คลิก");
define("LAN_26", "จำนวนคลิก");
define("LAN_27", "จำนวนคลิกที่กำหนดไว้");
define("LAN_28", "จำนวนคลิกที่คงเหลือ");
define("LAN_29", "ไม่มีป้ายโฆษณา");
define("LAN_30", "ไม่จำกัด");
define("LAN_31", "ยังไม่ใช้");
define("LAN_32", "ใช่");
define("LAN_33", "ไม่");
define("LAN_34", "จนถึง:");
define("LAN_35", "คลิกมาจากหมายเลข IP");
define("LAN_36", "กำลังใช้:");
define("LAN_37", "เริ่ม:");
define("LAN_38", "ผิดพลาด");

?>