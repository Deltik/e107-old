<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/23 23:10:14 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/

define("NT_LAN_US_1", "สมาชิกที่ลงทะเบียน");

define("NT_LAN_UV_1", "สมาชิกที่ลงทะเบียนถูกต้องแล้ว");
define("NT_LAN_UV_2", "ส่วนของการสืบค้นสมาชิก");

define("NT_LAN_LI_1", "สมาชิกที่เข้าระบบ");

define("NT_LAN_LO_1", "สมาชิกที่ออกจากระบบ");
define("NT_LAN_LO_2", " ออกจากเว็ป");

define("NT_LAN_FL_1", "ห้ามเกิน");
define("NT_LAN_FL_2", "IP address ที่ถูกห้ามเพราะทำเกินกว่าที่กำหนด");

define("NT_LAN_SN_1", "รายการข่าวป้อน");

define("NT_LAN_NU_1", "ปรับปรุงแล้ว");

define("NT_LAN_ND_1", "ลบรายการข่าว");
define("NT_LAN_ND_2", "ลบรหัสรายการข่าว");

?>