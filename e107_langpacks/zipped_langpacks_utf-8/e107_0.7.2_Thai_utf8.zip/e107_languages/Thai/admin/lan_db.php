<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("DBLAN_1", "สำรองการตั้งค่าของระบบหลัก(core)ในฐานข้อมูลแล้ว");
define("DBLAN_2", "คลิกเพื่อบันทึกการสำรองฐานข้อมูลของระบบe107 ");
define("DBLAN_3", "สำรอง-จัดเก็บฐานข้อมูลSQL ");
define("DBLAN_4", "ตรวจสอบความถูกต้องของฐานข้อมูล e107 ");
define("DBLAN_5", "ตรวจสอบความถูกต้องของฐานข้อมูล");
define("DBLAN_6", "คลิกเพื่อปรับฐานข้อมูลระบบe107ใหม่");
define("DBLAN_7", "ปรับฐานข้อมูลSQL ใหม่");
define("DBLAN_8", "คลิกเพื่อสำรองการตั้งค่าระบบหลัก");
define("DBLAN_9", "สำรองระบบหลัก(core)");
define("DBLAN_10", "การใช้ฐานข้อมูล:");
define("DBLAN_11", "ฐานข้อมูล mySQL");
define("DBLAN_12", "ปรับใหม่");
define("DBLAN_13", "ย้อนกลับ");
define("DBLAN_14", "เรียบร้อย");
define("DBLAN_15", "คลิกปุ่มเพื่อตรวจสอบการปรับปรุงฐานข้อมูลใหม่");
define("DBLAN_16", "ตรวจสอบเพื่อการปรับปรุงเป็นรุ่นใหม่");

?>