<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_users_extended.php,v $
|     $Revision: 1.14 $
|     $Date: 2006/01/15 01:08:04 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("EXTLAN_1", "ชื่อข้อมูลเพิ่ม");
define("EXTLAN_2", "ทดสอบ");
define("EXTLAN_3", "ค่า");
define("EXTLAN_4", "Req'd");
define("EXTLAN_5", "ให้ใช้งานได้");
define("EXTLAN_6", "ให้เข้าอ่านได้");
define("EXTLAN_7", "ให้เข้าเขียนได้");
define("EXTLAN_8", "ปฏิบัติ");
define("EXTLAN_9", "เพิ่มเติมส่วนขยายเขตฐานข้อมูลสมาชิก");

define("EXTLAN_10", "ชื่อเขตข้อมูลเพิ่ม");
define("EXTLAN_11", "ชื่อของข้อมูลที่เก็บในตารางจะต้องไม่เหมือนกัน");
define("EXTLAN_12", "เขตข้อมูลที่เป็นข้อความ");
define("EXTLAN_13", "เป็นชื่อของเขตข้อมูลที่จะแสดงในหน้าที่เห็น");
define("EXTLAN_14", "ชนิดเขตข้อมูล");
define("EXTLAN_15", "เขตข้อมูลรวมข้อความ");
define("EXTLAN_16", "ค่าเริ่มต้น");
define("EXTLAN_17", "Enter each possible value on each line <br /> For DB table see help.");
define("EXTLAN_18", "ต้องการ");
define("EXTLAN_19", "Users will be required to enter a value in this field when updating their settings.");
define("EXTLAN_20", "Determines which users this field will apply to.");
define("EXTLAN_21", "This will determine who will see this field in their usersettings.");
define("EXTLAN_22", "This will determine who can see the value in the user page <br />NOTE: Setting this to 'Read Only' will make it visible to Admin and the member only.");
define("EXTLAN_23", "เพิ่มเขตข้อมูลขยาย");
define("EXTLAN_24", "ปรับปรุงเขตข้อมูลขยาย");
define("EXTLAN_25", "เลื่อนลง");
define("EXTLAN_26", "เลื่อนขึ้น");
define("EXTLAN_27", "ยืนยันการลบ");
define("EXTLAN_28", "ยังไม่มีการกำหนดเขตข้อมูลขยาย");
define("EXTLAN_29", "บันทึกเขตข้อมูลส่วนขยายของสมาชิกให้แล้ว.");
define("EXTLAN_30", "ลบเขตข้อมูลส่วนขยายของสมาชิกให้แล้ว");
// define("EXTLAN_31", "ส่วนขยายเขตเมนู");
// define("EXTLAN_32", "ส่วนขยายหน้าแรก");
define("EXTLAN_33", "ยกเลิกการแก้ไข");
define("EXTLAN_34", "ส่วนขยายเขตฐานข้อมูลสมาชิก");
define("EXTLAN_35", "ประเภททั้งหมด");
define("EXTLAN_36", "ยังไม่มีการกำหนดประเภท");
define("EXTLAN_37", "ยังไม่มีการนิยามประเภททั้งหมด");
define("EXTLAN_38", "ชื่อประเภท");
define("EXTLAN_39", "เพิ่มประเภท");
define("EXTLAN_40", "สร้างประเภทแล้ว");
define("EXTLAN_41", "ลบประเภทแล้ว");
define("EXTLAN_42", "ปรับปรุงประเภท");
define("EXTLAN_43", "ปรับปรุงประเภทแล้ว");
define("EXTLAN_44", "ประเภท");
define("EXTLAN_45", "เพิ่มเขตข้อมูลใหม่");
define("EXTLAN_46", "ช่วยเหลือ");
define("EXTLAN_47", "เพิ่มพารามิเตอร์ใหม่");
define("EXTLAN_48", "เพิ่มค่าใหม่");
define("EXTLAN_49", "อนุญาตให้สมาชิกซ่อน");
define("EXTLAN_50", "Setting this to yes will allow the user to hide this value from non-admins");
define("EXTLAN_51", "Any valid w3c parameter may be entered here<br />ie <i><b>class='tbox' size='40' maxlength='80'</i></b>");
define("EXTLAN_52", "regex validation code");
define("EXTLAN_53", "Enter the regex code that will need to be matched to make it a valid entry <br />**regex delimiters are required**");
define("EXTLAN_54", "regex failure text");
define("EXTLAN_55", "Enter the error message that will be shown if the regex validation fails.");
define("EXTLAN_56", "เขตข้อมูลที่มีอยู่เดิม");
define("EXTLAN_57", "เปิดใช้");
define("EXTLAN_58", "ยังไม่เปิด");
define("EXTLAN_59", "ใช้งาน");
define("EXTLAN_60", "ไม่ใช้งาน");
define("EXTLAN_61", "ไม่มี");

define("EXTLAN_62", "ตาราง");
define("EXTLAN_63", "รหัสเขตข้อมูล");
define("EXTLAN_64", "แสดงค่า");

define("EXTLAN_65", "ไม่ - จะไม่แสดงในหน้าลงทะเบียน");
define("EXTLAN_66", "ใช่ - จะแสดงในหน้าลงทะเบียน");
define("EXTLAN_67", "ไม่ - แสดงในหน้าลงทะเบียน");


//textbox
define("EXTLAN_HELP_1", "<b><i>Parameters:</i></b><br />size - size of field<br />maxlength - max length of field<br /><br />class - css class of field<br />style - css style string<br /><br />regex - regex valiation code<br />regexfail - validation fail text");
//radio buttons
define("EXTLAN_HELP_2", "This will be the radio buttons help text");
//dropdown
define("EXTLAN_HELP_3", "This will be the dropdown help text");
//db field
define("EXTLAN_HELP_4", "<b><i>Values:</i></b><br />There should be three values given ALWAYS:<br /><ol><li>dbtable</li><li>field containing id</li><li>field containing value</li></ol><br />");
//textarea
define("EXTLAN_HELP_5", "This will be the Textarea help text");
//integer
define("EXTLAN_HELP_6", "This will be the Integer help text");
//date
define("EXTLAN_HELP_7", "This will be the date help text");

?>