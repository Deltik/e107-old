<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_mailout.php,v $
|     $Revision: 1.10 $
|     $Date: 2005/10/31 18:12:11 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("PRFLAN_52", "บันทึกการเปลี่ยนแปลง");
define("PRFLAN_63", "ทดสอบส่งอีเมล");
define("PRFLAN_64", "การคลิกที่ปุ่ม จะเป็นการทดสอบการส่งอีเมลจากระบบไปหาผู้จัดการระบบหลัก");
define("PRFLAN_65", "คลิกส่งอีเมลไปที่");
define("PRFLAN_66", "ทดสอบส่งอีเมลจาก");
define("PRFLAN_67", "นี่เป็นการทดสอบการส่งอีเมล, หากได้รับอีเมลนี้ก็แสดงว่า การตั้งค่าระบบการส่งอีเมลสามารถใช้งานได้!\n\nด้วยความนับถือ\nจากระบบบริหารจัดการเว็ปไซท์ e107");
define("PRFLAN_68", "ไม่สามารถส่งอีเมลให้ได้ เพราะคุณยังไม่ได้ตั้งค่าการส่งอีเมลของระบบที่ถูกต้อง กรุณาไปตั้งค่าSMTP ก่อน, หรือสอบถามผู้ให้บริการก่อนว่า ต้องกำหนดตั้งค่าแม่ข่ายระบบการรับ-ส่งอีเมลอย่างไรบ้าง");
define("PRFLAN_69", "ได้ส่งอีเมลไปให้เรียบร้อยแล้ว กรุณาเปิดอ่านอีเมลของคุณ.");
define("PRFLAN_70", "วิธีการส่งอีเมล");
define("PRFLAN_71", "หากไม่แน่ใจ, ให้ใช้ค่า php");
define("PRFLAN_72", "SMTP Server");
define("PRFLAN_73", "SMTP Username");
define("PRFLAN_74", "SMTP Password");
define("PRFLAN_75", "ไม่สามารถส่งอีเมลได้. กรุณาตรวจสอบการตั้งค่าของSMTP , หรือไม่ได้เปิด SMTP แล้วทดสอบส่งใหม่.");

define("MAILAN_01","จากชื่อ");
define("MAILAN_02","จากอีเมล");
define("MAILAN_03","ถึง");
define("MAILAN_04","สำเนาถึง");
define("MAILAN_05","สำเนาซ่อนถึง");
define("MAILAN_06","เรื่อง");
define("MAILAN_07","แนบไฟล์");
define("MAILAN_08","ส่งอีเมล");
define("MAILAN_09","ใช้รูปแบบกราฟิก");
define("MAILAN_10","ผู้ที่สมัครสมาชิกไว้");
define("MAILAN_11","ใส่ค่าตัวแปร");
define("MAILAN_12","สมาชิกในระบบทั้งหมด");
define("MAILAN_13","สมาชิกที่ยังไม่ตอบรับ ");
define("MAILAN_14","แนะนำให้เปิดใช้งาน SMTP เพื่อสามารถส่งอีเมลได้เป็นจำนวนมาก ดโยเลือกตั้งค่าที่ต้องการข้างล่างนี้.");
define("MAILAN_15","ส่งอีเมลจากระบบ");

define("MAILAN_16","ชื่อสมาชิก");
define("MAILAN_17","เชื่อมโยง");
define("MAILAN_18","รหัสสมาชิก");
define("MAILAN_19","ไม่มีชื่อที่อยู่อีเมลของผู้จัดการระบบหลักของเว็ปไซท์ กรุณาเข้าไปแก้ไขในส่วนของการตั้งค่าเว็ปไซทก่อน์ แล้วมาลองใหม่.");
define("MAILAN_20","เส้นทางส่งอีเมล");
define("MAILAN_21","Mass-Mail ที่เข้ามา");
define("MAILAN_22","ยังไม่ได้บันทึกรายการ");
define("MAILAN_23","ระดับสมาชิก: ");
define("MAILAN_24", "อีเมล(ทั้งหมด)พร้อมที่จะส่ง");
?>