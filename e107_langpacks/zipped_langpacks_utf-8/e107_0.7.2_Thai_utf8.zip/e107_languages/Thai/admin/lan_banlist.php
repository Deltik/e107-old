<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/17 06:49:46 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("BANLAN_1", "ยกเลิกคำสั่งห้าม.");
define("BANLAN_2", "ไม่มีชื่อที่ถูกห้าม.");
define("BANLAN_3", "รายชื่อผู้ที่ถูกห้ามใช้");
define("BANLAN_4", "ถอนคำสั่งห้าม");
define("BANLAN_5", "หมายเลข IP/ชื่ออีเมล/เว็ปไซท์");
define("BANLAN_7", "ด้วยเหตุผล");
define("BANLAN_8", "ห้ามเข้าใช้เว็ป");
define("BANLAN_9", "ห้ามผู้ใช้จากรายการต่อไปนี้");
define("BANLAN_10", "หมายเลข IP / อีเมล / ด้วยเหตุผล");
define("BANLAN_11", "ถูกสั่งห้ามอัตโนมัติ:หากเข้าสู่ระบบไม่ผ่านเกินกว่า 10 ครั้ง");

?>