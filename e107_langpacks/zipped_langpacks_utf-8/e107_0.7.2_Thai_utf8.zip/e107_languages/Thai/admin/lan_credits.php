<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_credits.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/10 15:40:55 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("CRELAN_1", "เครดิต");
define("CRELAN_2", "Here is a list of third-party software / resources used in e107. The e107 development team would like to personally thank the developers of the following for allowing us to redistribute their code with e107, and for releasing their software under the GPL licence. </br><b>www.tinnabutr.com : Thai developer");
// define("CRELAN_3", "แหล่ง/ที่มา");
// define("CRELAN_4", "คำอธิบาย");
// define("CRELAN_5", "เว็ปไซท์");
// define("CRELAN_6", "สิทธิอนุญาต");
define("CRELAN_7", "เวอร์ชั่น");



?>