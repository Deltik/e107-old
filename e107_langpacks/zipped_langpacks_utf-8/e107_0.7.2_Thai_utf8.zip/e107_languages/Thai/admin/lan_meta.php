<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/09/06 19:34:04 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("METLAN_1", "ได้ปรับปรุง Meta tags ลงในฐานข้อมูลแล้ว");
define("METLAN_2", "พิมพ์ข้อความของmeta-tags");
define("METLAN_3", "ตั้งค่า meta tag ใหม่");
define("METLAN_4", "แก้ไขแล้ว");
define("METLAN_5", "ให้พิมพ์คำอธิบายเว็ปไซท์ที่นี่");
define("METLAN_6", "พิมพ์คำสำคัญค้นหาที่นี่ แยกคำด้วยเครื่องหมายคอมม่า(,)");
define("METLAN_7", "พิมพ์ข้อมูลลิขสิทธิ์ที่นี่");
define("METLAN_8", "Meta Tags(ข้อมูลเพื่อการสืบค้นหาเว็ปไซท์ของคุณทางอินเตอร์เน็ต");

define("METLAN_9", "คำอธิบาย");
define("METLAN_10", "คำสำคัญค้น");
define("METLAN_11", "ลิขสิทธิ์");

?>