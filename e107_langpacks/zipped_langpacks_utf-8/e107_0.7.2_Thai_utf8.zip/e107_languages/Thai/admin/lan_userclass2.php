<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("UCSLAN_1", "ลบสมาชิกทั้งหมดในระดับสมาชิกนี้แล้ว.");
define("UCSLAN_2", "ปรับปรุงระดับสมาชิกทั้งหมดแล้ว.");
define("UCSLAN_3", "ลบระดับสมาชิกให้แล้ว.");
define("UCSLAN_4", "กรุณาคลิกในช่องเพื่อยืนยันการลบระดับสมาชิกนี้");
define("UCSLAN_5", "ปรับปรุงระดับสมาชิกให้แล้ว.");
define("UCSLAN_6", "บันทึกระดับสมาชิกในฐานข้อมูล.");
define("UCSLAN_7", "ยังไม่มีการจัดระดับชั้นของสมาชิก.");
define("UCSLAN_8", "ระดับสมาชิกที่ตั้งแล้ว");

// define("UCSLAN_9", "แก้ไข");
// define("UCSLAN_10", "ลบ");
define("UCSLAN_11", "คลิกเพื่อยืนยัน");
define("UCSLAN_12", "ชื่อระดับสมาชิก");
define("UCSLAN_13", "คำอธิบายระดับสมาชิก");
define("UCSLAN_14", "ปรับระดับสมาชิก");
define("UCSLAN_15", "สร้างระดับสมาชิกใหม่");
define("UCSLAN_16", "ให้เป็นสมาชิกระดับ");
define("UCSLAN_17", "เอาออก");
define("UCSLAN_18", "ลบระดับ");
define("UCSLAN_19", "ให้เป็นสมาชิกของ");
define("UCSLAN_20", "ระดับ");
define("UCSLAN_21", "การตั้งค่าระดับสมาชิก");

define("UCSLAN_22", "สมาชิก - คลิกเพื่อเอาออก ...");
define("UCSLAN_23", "สมาชิกในระดับนี้คือ ...");

define("UCSLAN_24", "ผู้ที่สามารถจัดระดับสมาชิกคือ");


?>