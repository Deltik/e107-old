<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db_verify.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 18:29:48 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("DBLAN_1", "ไม่สามารถอ่านไฟล์ข้อมูลsql <br /><br />โปรดแน่ใจว่าไฟล์<b>core_sql.php</b> มีอยู่ใน <b>/admin/sql</b> แฟ้ม.");
define("DBLAN_2", "ตรวจทั้งหมด");

define("DBLAN_4", "ตาราง");
define("DBLAN_5", "เขตข้อมูล");
define("DBLAN_6", "สถานะ");
define("DBLAN_7", "บันทึก");
define("DBLAN_8", "ไม่ตรง");
define("DBLAN_9", "ปัจจุบัน");
define("DBLAN_10", "ควรจะ");
define("DBLAN_11", "ไม่มีเขตข้อมูล");
define("DBLAN_12", "เขตข้อมูลพิเศษ!");
define("DBLAN_13", "ตารางหายไป!");
define("DBLAN_14", "เลือกตารางที่จะตรวจสอบ");
define("DBLAN_15", "เริ่มตรวจสอบ");
define("DBLAN_16", "ตรวจสอบ SQL");
define("DBLAN_17", "กลับ");
define("DBLAN_18", "ตาราง");
define("DBLAN_19", "ต้องการซ่อมแซม");
define("DBLAN_20", "ต้องการซ่อมแซมตาราง");
define("DBLAN_21", "ซ่อมแซมรายการที่เลือก");
?>