<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_emoticon.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("EMOLAN_1", "การใช้งานสัญรูปอารมณ์");
define("EMOLAN_2", "ชื่อไฟล์");
define("EMOLAN_3", "สัญรูปอารมณ์");
define("EMOLAN_4", "คลิกเปิด-ปิดการใช้งานสัญรูปอารมณ์");

define("EMOLAN_5", "ภาพ");
define("EMOLAN_6", "รหัสสัญรูปอารมณ์");
define("EMOLAN_7", "แยกคำ้โดยการเว้นวรรค");

define("EMOLAN_8", "สถานะระบบ");
define("EMOLAN_9", "เลือกค่า");
define("EMOLAN_10", "เปิดใช้งาน");
define("EMOLAN_11", "ชุดสัญรูปอารมณ์ที่ให้ใช้'");

define("EMOLAN_12", "แก้ไข / ตั้งค่าชุดสัญรูปอารมณ์นี้");
define("EMOLAN_13", "ติดตั้งชุดรวม");

define("EMOLAN_14", "บันทึกการตั้งค่า");
define("EMOLAN_15", "แก้ไข / ตั้งค่าสัญรูปอารมณ์");
define("EMOLAN_16", "บันทึกการตั้งค่าสัญรูปอารมณ์แล้ว");
define("EMOLAN_2", "ชื่อ");
define("EMOLAN_2", "ชื่อ");
define("EMOLAN_2", "ชื่อ");
define("EMOLAN_2", "ชื่อ");
define("EMOLAN_2", "ชื่อ");
define("EMOLAN_2", "ชื่อ");

?>