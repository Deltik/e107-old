<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/10 21:31:57 $
|     $Author: loloirie $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("LAN_CHECK_1", "เลือกภาษาที่จะตรวจสอบ");
define("LAN_CHECK_2", "เริ่มตรวจสอบ");
define("LAN_CHECK_3", "การตรวจสอบของ");
define("LAN_CHECK_4", "ไฟล์ที่หายไป!");
define("LAN_CHECK_5", "ข้อความที่หายไป!");
define("LAN_CHECK_6", "ตกลง");
define("LAN_CHECK_7", "ข้อความ");

define("LAN_CHECK_8", "คือไฟล์ที่หายไป...");
define("LAN_CHECK_9", " ไฟล์ทั้งหมดที่หายไป...");
define("LAN_CHECK_10", "เกิดความผิดพลาดขั้นวิกฤติ: ");
define("LAN_CHECK_11", "ไม่มีไฟล์หาย !");
define("LAN_CHECK_12", "คือไฟล์ที่ผิด...");
define("LAN_CHECK_13", " ไฟล์ทั้งหมดที่ผิด...");
define("LAN_CHECK_14", "ไฟล์ทั้งหมดที่สมบูรณ์!");

?>
