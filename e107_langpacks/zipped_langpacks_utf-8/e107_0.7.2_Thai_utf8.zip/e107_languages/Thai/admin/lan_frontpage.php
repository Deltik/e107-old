<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/02 06:14:20 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/

define("FRTLAN_1", "ปรับปรุงการตั้งค่าหน้าแรกแล้ว.");
define("FRTLAN_2", "จัดหน้าแรกของ");
define("FRTLAN_6", "การเชื่อมโยง");
// define("FRTLAN_7", "หน้าเนื้อหา");
define("FRTLAN_12", "ปรับปรุงการตั้งค่าหน้าแรก");
define("FRTLAN_13", "การตั้งค่าหน้าแรก");
define("FRTLAN_15", "อื่นๆ (ใส่ url):");
define("FRTLAN_16", "ผิดพลาด: ไม่มีการเลือกประเภทกลุ่มเนื้อหาหลัก");
define("FRTLAN_17", "ผิดพลาด: ไม่มีการเลือกประเภทกลุ่มเนื้อหาย่อย");
define("FRTLAN_18", "ผิดพลาด: ไม่มีการเลือกรายการเนื้อหา");
define("FRTLAN_19", "กลุ่มเนื้อหาหลัก");
define("FRTLAN_20", "ประเภทเนื้อหา");
define("FRTLAN_21", "รายการเนื้อหา");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "สมาชิกทั้งหมด");
define("FRTLAN_27", "บุคคลทั่วไป");
define("FRTLAN_28", "สมาชิก");
define("FRTLAN_29", "ผู้จัดการระบบทั้งหมด");
define("FRTLAN_31", "สมาชิกทั้งหมด");
define("FRTLAN_32", "ระดับสมาชิก");
define("FRTLAN_33", "การตั้งค่าปัจจุบัน");
define("FRTLAN_34", "หน้า");

?>