<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_footer.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("FOOTLAN_1", "ชื่อเว็ปไซท์");
define("FOOTLAN_2", "ผู้บริหารระบบหลัก");
define("FOOTLAN_3", "เวอร์ชั่น");
define("FOOTLAN_4", "รุ่น");
define("FOOTLAN_5", "ชื่อชุดรูปแบบกราฟิก");
define("FOOTLAN_6", "ออกแบบโดย");
define("FOOTLAN_7", "ข้อมูลระบบของเว็ปไซท์");
define("FOOTLAN_8", "วันที่ติดตั้งระบบ");
define("FOOTLAN_9", "โปรแกรมบริการเว็ปของเครื่องแม่ข่าย");
define("FOOTLAN_10", "เก็บเว็ปไฟล์ไว้ที่");
define("FOOTLAN_11", "PHPเวอร์ชั่น");
define("FOOTLAN_12", "ใช้ฐานข้อมูลmySQLเวอร์ชั่น");
define("FOOTLAN_13", "ข้อมูลเว็ปไซท์");
define("FOOTLAN_14", "เอกสารแนะนำ");
define("FOOTLAN_15", "เอกสารแนะนำ");
define("FOOTLAN_16", "ชื่อฐานข้อมูล");
define("FOOTLAN_17", "รูปแบบตัวอักษร");

?>