<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_links.php,v $
|     $Revision: 1.13 $
|     $Date: 2005/11/23 18:08:28 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("LCLAN_1", "บันทึกการเลือกกำหนดค่าไว้เรียบร้อยแล้ว");
define("LCLAN_2", "บันทึกเมนูการเชื่อมโยงเข้าฐานข้อมูล.");
define("LCLAN_3", "ปรับปรุงเมนูการเชื่อมโยงในฐานข้อมูลแล้ว.");
// define("LCLAN_4", "ลบการเชื่อมโยงแล้ว.");
define("LCLAN_6", "ปรับลำดับแล้ว.");
define("LCLAN_8", "เมนูการเชื่อมโยงที่มี");
define("LCLAN_12", "รูปแบบแสดงผลเมนูการเชื่อมโยง");
define("LCLAN_15", "ชื่อเมนูการเชื่อมโยง");
define("LCLAN_16", "ชื่อที่อยู่ของURL");
define("LCLAN_17", "คำอธิบาย");
define("LCLAN_18", "ใช้สัญรูป");
define("LCLAN_19", "การแสดงผลของหน้าที่เชื่อมโยง");
define("LCLAN_20", "เปิดในกรอบวินโดวส์เดิม");
define("LCLAN_23", "เปิดเป็นกรอบวินโดวส์ใหม่");
define("LCLAN_24", "เปิดเป็นกรอบวินโดวส์ใหม่ขนาด 600x400 Pixels");
define("LCLAN_25", "ระดับสมาชิกที่อนุญาตให้ดู");
define("LCLAN_26", "การคลิกถูกในช่อง จะเป็นการกำหนดแสดงให้เห็นเฉพาะกับกลุ่มสมาชิกที่เลือกระบุไว้");
define("LCLAN_27", "ปรับปรุงเมนูการเชื่อมโยง");
define("LCLAN_28", "เพิ่มเมนูการเชื่อมโยง");
define("LCLAN_29", "เพิ่มเมนูการเชื่อมโยงใหม่");
define("LCLAN_30", "เลื่อนขึ้น");
define("LCLAN_31", "เลื่อนลง");
define("LCLAN_39", "เลือกสัญรูปที่มีในระบบ");
define("LCLAN_53", "เชื่อมโยง");
define("LCLAN_54", "ลบแล้ว");
define("LCLAN_58", "คุณแน่ใจที่จะเมนูการเชื่อมโยงนี้?");
define("LCLAN_61", "ไม่มีรายการเชื่อมโยง");
define("LCLAN_62", "รายการเชื่อมโยงของเว็ปไซท์");
define("LCLAN_63", "เพิ่มเมนูการเชื่อมโยง");
define("LCLAN_68", "เลือกค่าของเมนูการเชื่อมโยง");
define("LCLAN_78", "แสดงคำอธิบายเป็น Screen-Tip");
define("LCLAN_79", "คำอธิบายจะแสดงขึ้นมาเมื่อนำเม้าส์ชี้ที่เมนูการเชื่อมโยง");
define("LCLAN_80", "เปิดใช้เมนูย่อย");
define("LCLAN_81", "เมนูย่อยจะแสดงหลังจากที่คลิกที่เมนูหลักแล้ว(Link parent is disabled)");
define("LCLAN_83", "ตัวสร้างเมนูย่อย");
define("LCLAN_88", "เลือกตั้งค่าเมนูรายการเชื่อมโยงหน้าแรกของเว็ปไซท์");
define("LCLAN_89", "ภาพ");
define("LCLAN_90", "ชื่อเมนูเชื่อมโยง");
define("LCLAN_91", "ย้าย");
define("LCLAN_95", "ระดับสมาชิกที่ดูได้");

define("LCLAN_96", "แสดงในรูปแบบกราฟิกเป็น");


define("LINKLAN_1", "เปิดเป็นกรอบวินโดวส์ใหม่ขนาด 800x600 Pixels");
define("LINKLAN_2", "ในหมวดรายการ");
define("LINKLAN_3", "เป็นรายการใหม่");
define("LINKLAN_4", "จัดหมวดหมู่การเชื่อมโยง");
define("LINKLAN_5", "จัดเป็นเมนูย่อยในการเชื่อมโยง");
define("LINKLAN_6", "จัดการเชื่อมโยงในหมวดของ:");
define("LINKLAN_7", "เป็นเมนูย่อยในรายการของ...");
define("LINKLAN_8", "ประเภทข่าวสารทั้งหมด");
define("LINKLAN_9", "ประเภทการโอนไฟล์ลงทั้งหมด");
define("LINKLAN_10", "สร้างเมนูย่อยเพิ่มเข้าในหมวดนี้");

?>