<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/22 17:08:01 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("CUSLAN_1", "ชื่อ");
define("CUSLAN_2", "รูปแบบ");
define("CUSLAN_3", "เลือกค่า");
define("CUSLAN_4", "ลบหน้านี้?");
define("CUSLAN_5", "หน้าเอกสารที่มี");
define("CUSLAN_7", "ชื่อเมนู");
define("CUSLAN_8", "ชื่อเรื่อง / คำอธิบาย");
define("CUSLAN_9", "เนื้อหา");
define("CUSLAN_10", "การให้คะแนน");
define("CUSLAN_11", "หน้าแรก");
define("CUSLAN_12", "เพิ่มหน้าใหม่");
define("CUSLAN_13", "การแสดงความเห็น");
define("CUSLAN_14", "รหัสผ่านเข้าอ่าน");
define("CUSLAN_15", "ตั้งรหัสผ่านเข้าอ่าน");
define("CUSLAN_16", "การเชื่อมโยง");
define("CUSLAN_17", "ใส่ชื่อการเชื่อมโยง(URL)");
define("CUSLAN_18", "ผู้มีสิทธิ์เข้าอ่านเอกสาร");
define("CUSLAN_19", "ปรับปรุงหน้าเอกสาร");
define("CUSLAN_20", "สร้างหน้าเอกสาร");
define("CUSLAN_21", "ปรับปรุงเมนู");
define("CUSLAN_22", "สร้างเมนู");
define("CUSLAN_23", "แก้ไขหน้าเอกสาร");
define("CUSLAN_24", "สร้างหน้าเอกสารใหม่");
define("CUSLAN_25", "แก้ไขเมนู");
define("CUSLAN_26", "สร้างเมนูใหม่");
define("CUSLAN_27", "บันทึกหน้าเอกสารลงฐานข้อมูลแล้ว.");
define("CUSLAN_28", "ลบหน้าเอกสารแล้ว");
define("CUSLAN_29", "หน้าแสดงรายการเอกสาร ถ้าหากไม่มีการเลือก. ");
define("CUSLAN_30", "กำหนดหมดเวลาสำหรับCookies (เป็นวินาที)");
define("CUSLAN_31", "สร้างเมนู");
define("CUSLAN_32", "เปลี่ยนกลับหน้า/เมนูเดิม");
define("CUSLAN_33", "เลือกกำหนดค่าหน้าเอกสาร");
define("CUSLAN_34", "เิริ่มการเปลี่ยนกลับ");
define("CUSLAN_35", "หน้าเอกสารที่สร้างไว้ ได้ปรับปรุงใหม่แล้ว");
define("CUSLAN_36", "การแก้ไข การเลือกตั้งค่าที่ชอบเองในแต่ละหน้านั้น ให้ไปกำหนดได้จากหน้าแรกของการจัดการหน้าเอกสาร");
define("CUSLAN_37", "ปรับปรุงการสร้างหน้าเอกสารเอง");
define("CUSLAN_38", "เปิด");
define("CUSLAN_39", "ปิด");
define("CUSLAN_40", "บันทึกการเลือกค่า");

define("CUSLAN_41", "แสดงเจ้าของ:วันเวลา");
define("CUSLAN_42", "ยังไม่มีการกำหนดหน้า");

?>