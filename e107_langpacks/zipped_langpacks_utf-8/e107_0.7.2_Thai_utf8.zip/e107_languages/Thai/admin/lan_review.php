<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_review.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("REVLAN_1", "เพิ่มบทสรุปในฐานข้อมูลแล้ว.");
define("REVLAN_2", "กรอกข้อมูลไม่ครบ.");
define("REVLAN_3", "ปรับปรุงบทสรุปในฐานข้อมูล.");
define("REVLAN_4", "ลบบทสรุปแล้ว.");
define("REVLAN_5", "กรุณาคลิกในช่องเพื่อยืนยันการลบบทสรุป");
define("REVLAN_6", "ยังไม่มีบทสรุป");
define("REVLAN_7", "บทสรุปที่มี");
define("REVLAN_8", "แก้ไข");
define("REVLAN_9", "ลบ");
define("REVLAN_10", "คลิกเพื่อยืนยัน");
define("REVLAN_11", "เปิด HTML Editor");
define("REVLAN_12", "หัวเรื่อง");
define("REVLAN_13", "หัวเรื่องรอง");
define("REVLAN_14", "สรุปย่อ");
define("REVLAN_15", "บทสรุป");
define("REVLAN_16", "คะแนน");
define("REVLAN_17", "กรุณาเลือกให้คะแนน");
define("REVLAN_18", "อนุญาตให้แสดงความเห็นหรือไม่?");
define("REVLAN_19", "เปิด");
define("REVLAN_20", "ปิด");
define("REVLAN_21", "ให้เห็นกับ");
define("REVLAN_22", "ปรับปรุงบทสรุป");
define("REVLAN_23", "ส่งบทสรุป");
define("REVLAN_24", "บทสรุปทั้งหมด");




define("REVLAN_25", "บันทึกประเภทการบทสรุปแล้ว");
define("REVLAN_26", "ปรับปรุงประเภทการบทสรุปแล้ว");
define("REVLAN_27", "ลบประเภทแล้ว");
define("REVLAN_28", "ประเภท");
define("REVLAN_29", "เลือกคำสั่ง");
define("REVLAN_30", "แก้ไข");
define("REVLAN_31", "ลบ");
define("REVLAN_32", "ไม่มีประเภทบทสรุป");
define("REVLAN_33", "ประเภทบทสรุปที่มี");
define("REVLAN_34", "ชื่อประเภท");
define("REVLAN_35", "สัญรูปประเภท");
define("REVLAN_36", "ดูภาพ");
define("REVLAN_37", "ย่อสรุปประเภท");
define("REVLAN_38", "ปรับปรุงประเภทบทสรุป");
define("REVLAN_39", "สร้างประเภทบทสรุป");
define("REVLAN_40", "ไม่มีบทสรุป");
define("REVLAN_41", "บทสรุปที่มี");
define("REVLAN_42", "เปิด HTML Editor");
define("REVLAN_43", "ประเภท");
define("REVLAN_44", "ไม่มี");
define("REVLAN_45", "หน้าแรกของบทสรุป");
define("REVLAN_46", "สร้างบทสรุปใหม่");
define("REVLAN_47", "ประเภททั้งหมด");
define("REVLAN_48", "เลือกค่าบทสรุป");
define("REVLAN_49", "คุณแน่ใจว่าต้องการที่จะลบประเภทนี้หรือไม่?");
define("REVLAN_50", "คุณแน่ใจว่าจะลบบทสรุปหรือไม่?");
define("REVLAN_51", "ข้อมูลผู้เขียน");
define("REVLAN_52", "ว่างไว้หากคุณเป็นผู้เขียนบทสรุปเอง");
define("REVLAN_53", "ชื่อผู้เขียน");
define("REVLAN_54", "ชื่อที่อยู่อีเมลผู้เขียน");

define("REVLAN_55", "การอนุญาตรับส่งบทสรุป);
define("REVLAN_56", "อนุญาตให้บุคคลทั่วไปส่งบทสรุปเข้าร่วมได้หรือไม่");
define("REVLAN_57", "ระดับสมาชิกที่สามารถส่งบทสรุปได้");
define("REVLAN_58", "เลือกว่าจะกำหนดให้สมาชิกกลุ่มใดส่งบทสรุปเข้าร่วมได้");
define("REVLAN_59", "ปรับปรุงการเลือกค่า");
define("REVLAN_60", "ตั้งค่าบทสรุป");
define("REVLAN_61", "เลือกตั้งค่าให้กับบทสรุปแล้วบทสรุป");

define("REVLAN_62", "บทสรุปที่ส่งเข้า");
define("REVLAN_63", "ยังไม่มีบทสรุปที่ส่งเข้า");
define("REVLAN_64", "ยังไม่กรอกชื่อที่อยู่อีเมล");
define("REVLAN_65", "หัวข้อบทสรุป");
define("REVLAN_66", "ส่ง");
define("REVLAN_67", "Post User Submitted Article");
define("REVLAN_68", "บันทึกบทสรุปของสมาชิกเข้าฐานข้อมูล");

define("REVLAN_69", "ล้างแบบฟอร์ม");
define("REVLAN_70", "คลิกที่นี่เพื่อกรอกข้อมูลผู้เขียน");
define("REVLAN_71", "เพิ่มสัญรูป email/print หรือไม่?");
define("REVLAN_72", "ใช่");
define("REVLAN_73", "ไม่");
?>