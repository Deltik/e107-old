<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("MESSLAN_1", "ข้อความที่ได้รับ");
define("MESSLAN_2", "ลบข้อความ");
define("MESSLAN_3", "ลบข้อความแล้ว.");
define("MESSLAN_4", "ลบข้อความทั้งหมด");
define("MESSLAN_5", "ยืนยัน");
define("MESSLAN_6", "ลบข้อความทั้งหมดแล้ว.");
define("MESSLAN_7", "ไม่มีข้อความ.");
define("MESSLAN_8", "รูปแบบข้อความ");
define("MESSLAN_9", "รายงานเมื่อ");

define("MESSLAN_10", "ส่งจาก");
define("MESSLAN_11", "เปิดเป็นวินโดวส์ใหม่");
define("MESSLAN_12", "ข้อความ");
define("MESSLAN_13", "การเชื่อมโยง");


?>