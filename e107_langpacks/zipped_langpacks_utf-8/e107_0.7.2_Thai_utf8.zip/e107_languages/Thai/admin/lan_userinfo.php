<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("USFLAN_1", "ไม่สามารถพบหมายเลขไอพีของผู้ส่ง ไม่มีข้อมูล.");
// define("USFLAN_2", "ผิดพลาด");
define("USFLAN_3", "ส่งข้อมูลจาก IP address");
define("USFLAN_4", "Host");
define("USFLAN_5", "คลิกที่นี่เพื่อโอนย้ายหมายเลขไอพี ไปที่หน้าสั่งห้ามใช้");
define("USFLAN_6", "รหัสสมาชิก");
define("USFLAN_7", "ข้อมูลสมาชิก");

?>