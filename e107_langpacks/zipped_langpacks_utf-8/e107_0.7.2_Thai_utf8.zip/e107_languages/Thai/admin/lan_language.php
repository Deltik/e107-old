<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_language.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/15 19:11:12 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/

define("LANG_LAN_00","สร้างไม่ได้.(มีอยู่แล้ว)");
define("LANG_LAN_01","ลบไปแล้ว(หากมี) และสร้างให้ใหม่แล้ว.");
define("LANG_LAN_02","ไม่สามารถลบได้");
define("LANG_LAN_03","ตาราง");

define("LANG_LAN_05","ไม่ได้ติดตั้ง");
define("LANG_LAN_06", "สร้างตาราง");
define("LANG_LAN_07", "ทิ้งตรารางเดิมที่มีอยู่หรือไม่?");
define("LANG_LAN_08", "บันทึกทับตารางเดิมที่มีอยู่ก่อน (ข้อมูลเดิมจะหายไป).");
define("LANG_LAN_10", "ยืนยันการลบ");
define("LANG_LAN_11", "ลบตารางที่ไม่เช็ครายการข้างบนไว้(หากมีอยู่ ).");
define("LANG_LAN_12", "สามารถใช้ตารางหลายภาษาได้");
define("LANG_LAN_13", "ตั้งค่าใช้งานหลายภาษา");
define("LANG_LAN_14", "ภาษาเริ่มต้นของระบบ");
define("LANG_LAN_15", "คลิกถูกเพื่อสำเนาข้อมูลจากภาษาที่เป็นค่าเริ่มต้น.(useful for links, news-categories etc) ");


?>