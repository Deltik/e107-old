<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("MDCLAN_1", "ตรวจสอบ.");
define("MDCLAN_2", "ยังไม่มีความเห็น");
define("MDCLAN_3", "สมาชิก");
define("MDCLAN_4", "แขกรับเชิญ");
define("MDCLAN_5", "ไม่ห้าม");
define("MDCLAN_6", "ห้าม");

define("MDCLAN_8", "ตรวจสอบความเห็น");
define("MDCLAN_9", "คำเตือน! การลบรายการแสดงความคิดเห็นที่ตั้งเป็นหลัก จะเป็นการลบความคิดเห็นเห็นในกลุ่มที่ตอบออกไปด้วย!");

define("MDCLAN_10", "เลือกค่า");
define("MDCLAN_11", "ความเห็น");
define("MDCLAN_12", "ความเห็นทั้งหมด");
define("MDCLAN_13", "ปิดแล้ว");
define("MDCLAN_14", "ปิดความเห็น");
define("MDCLAN_15", "เปิด");
define("MDCLAN_16", "ปิดแล้ว");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>