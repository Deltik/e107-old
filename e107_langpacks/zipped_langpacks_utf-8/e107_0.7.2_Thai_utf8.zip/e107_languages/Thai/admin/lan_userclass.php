<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/03 15:57:25 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/

define("UCSLAN_1", "ส่งอีเมลแจ้งเตือนไปถึง");
define("UCSLAN_2", "ปรับปรุงสิทธิ์");
define("UCSLAN_3", "ถึงคุณ");
define("UCSLAN_4", "สิทธิของคุณได้รับการปรับให้แล้วใน");
define("UCSLAN_5", "คุณสามารถเข้าใช้งานได้ในเขตพื้นที่ดังต่อไปนี้คือ");
define("UCSLAN_6", "จัดระดับให้สมาชิก");
define("UCSLAN_7", "จัดระดับสมาชิกทั้งหมด");
define("UCSLAN_8", "แจ้งสมาชิก");
define("UCSLAN_9", "ปรับปรุงระดับสมาชิกทั้งหมดแล้ว.");
define("UCSLAN_10", "ด้วยความนับถือ,");

?>