<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_fla.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/17 07:51:40 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("FLALAN_1", "ไม่สามารถเข้าสู่ระบบได้");
define("FLALAN_2", "ยังไม่มีการบันทึกการเข้าระบบที่ล้มเหลว");
define("FLALAN_3", "พยายามที่จะลบ");
define("FLALAN_4", "มีสมาชิกที่พยายามเข้าระบบด้วยชื่อและรหัสผ่านที่ไม่ถูกต้อง");
define("FLALAN_5", "IP(s) ที่ถูกห้ามใช้");
define("FLALAN_6", "วันที่");
define("FLALAN_7", "ข้อมูล");
define("FLALAN_8", "IP address/ Host");
define("FLALAN_9", "เลือกค่า");
define("FLALAN_10", "ตรวจสอบ/ลบ /รายการที่ถูกห้ามห้าม");
define("FLALAN_11", "เลือกรายการลบทุกกล่องรายการ");
define("FLALAN_12", "ไม่เลือกรายการลบทุกกล่องรายการ");
define("FLALAN_13", "เลือกรายการห้ามทุกกล่องรายการ");
define("FLALAN_14", "ไม่เลือกรายการห้ามทุกกล่องรายการ");
define("FLALAN_15", "หมายเลข IP address ที่ถูกห้ามโดยอัตโนมัติ เพราะมีผู้พยายามเข้าระบบที่ผิดพลาด ตามที่กำหนดไว้ไม่เกิน10 ครั้ง");
define("FLALAN_16", "ลบรายชื่อที่ถูกห้ามใช้โดยอัตโนมัติ");
define("FLALAN_17", "ลบรายชื่อที่ถูกห้ามใช้โดยอัตโนมัติแล้ว");

?>