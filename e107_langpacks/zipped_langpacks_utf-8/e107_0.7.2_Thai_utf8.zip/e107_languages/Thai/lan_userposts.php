<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/30 19:36:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("PAGE_NAME", "กระทู้ของสมาชิก");

define("UP_LAN_0", "การส่งกระทู้อภิปรายทั้งหมดของ ");
define("UP_LAN_1", "ความเห็นทั้งหมดของ");
define("UP_LAN_2", "ตั้งกระทู้");
define("UP_LAN_3", "เข้าดู");
define("UP_LAN_4", "ตอบกลับ");
define("UP_LAN_5", "ส่งล่าสุด");
define("UP_LAN_6", "กระทู้ที่ตั้งทั้งหมด");
define("UP_LAN_7", "ไม่มีความเห็น");
define("UP_LAN_8", "ไม่มีกระทู้");
define("UP_LAN_9", " ใน ");
define("UP_LAN_10", "ตอบ");
define("UP_LAN_11", "ส่งใน");
define("UP_LAN_12", "สืบค้น");
define("UP_LAN_13", "ความเห็น");
define("UP_LAN_14", "ส่งอภิปราย");
define("UP_LAN_15", "ตอบ");
define("UP_LAN_16", "หมายเลข IP ");
?>