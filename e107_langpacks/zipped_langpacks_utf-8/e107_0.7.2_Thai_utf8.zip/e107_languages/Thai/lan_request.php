<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/09 15:38:12 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/

define("LAN_dl_61", "ไม่สามารถโอนไฟล์ลงได้");
define("LAN_dl_62", "ไฟล์นี้ถูกป้องกันไม่ให้โหลดได้้");
define("LAN_dl_63", "คุณไม่มีสิทธิ์ในการโหลดไฟล์นี้ได้.");
define("LAN_dl_64", "กลับ");
define("LAN_dl_65", "ไม่พบไฟล์");

?>