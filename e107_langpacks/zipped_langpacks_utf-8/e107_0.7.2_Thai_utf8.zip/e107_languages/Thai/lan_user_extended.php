<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user_extended.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/28 16:22:00 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
แปลเป็นภาษาไทยโดย ผศ.ประชิด ทิณบุตร เมื่อวันที่ 18 มีนาคม 2549  
อาจารย์ประจำโปรแกรมวิชาศิลปกรรม มหาวิทยาลัยราชภัฏจันทรเกษม ถนนรัชดาภิเษก เขตจตุจักร กทม 10900
Thai Translation : Assistant Professor Prachid Tinnabutr : 
Date:18-March 2006 .
Personal Address : 144/157 Moo 1 ,Changwatana Rd.Pakkret District ,Nonthaburi Province,Thailand,11120 Tel/Fax:(66)0 962 9505 prachid@tinnabutr.com,prachid@wittycomputer.com ,Mobile Phone : (66)0 9667 0091
URL : http://www.tinnabutr.com, http://www.wittycomputer.com
*/
define("UE_LAN_1", "กล่องข้อความ");
define("UE_LAN_2", "ปุ่มRadio");
define("UE_LAN_3", "เมนูDrop-Down");
define("UE_LAN_4", "เขตตารางฐานข้อมูล");
define("UE_LAN_5", "เขตพิมพ์ข้อความ");
define("UE_LAN_6", "เขตข้อมูลตัวเลขจำนวนเต็ม");
define("UE_LAN_7", "วันที่");
define("UE_LAN_8", "ภาษา");

define("UE_LAN_9", "ชื่อเขตข้อมูล");
define("UE_LAN_10", "ชนิดของข้อมูล");
define("UE_LAN_11", "ชื่อแสดงให้ใช้");

define("UE_LAN_HIDE", "ซ่อนโดยผู้ใช้");

define("UE_LAN_LOCATION", "สถานที่");
define("UE_LAN_LOCATION_DESC", "ที่อยู่");
define("UE_LAN_AIM", "AIM Address");
define("UE_LAN_AIM_DESC", "ที่อยู่AIM");
define("UE_LAN_ICQ", "หมายเลข ICQ");
define("UE_LAN_ICQ_DESC", "หมายเลขICQ");
define("UE_LAN_YAHOO", "ชื่อที่อยู่อีเมลYahoo!");
define("UE_LAN_YAHOO_DESC", "ชื่อที่อยู่อีเมลYahoo!");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "ที่อยู่ MSN");
define("UE_LAN_HOMEPAGE", "โฮมเพจ");
define("UE_LAN_HOMEPAGE_DESC", "โฮมเพจของสมาชิก(url)");
define("UE_LAN_BIRTHDAY", "วันเกิด");
define("UE_LAN_BIRTHDAY_DESC", "วันเกิด");

?>