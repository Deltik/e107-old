<?php
  define("NWSF_FP_1", "Ressources d'Actualit�s");
  define("NWSF_FP_2", "Page principale");
  ?>
