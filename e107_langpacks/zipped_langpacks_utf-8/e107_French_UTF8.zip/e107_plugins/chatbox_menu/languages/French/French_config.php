﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/French/French_config.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:27 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("CHBLAN_1", "Paramètres Chatbox  mis à jour.");
  define("CHBLAN_2", "Moderée.");
  define("CHBLAN_3", "Pas de Messages postés pour le moment.");
  define("CHBLAN_4", "Membre");
  define("CHBLAN_5", "Invité");
  define("CHBLAN_6", "débloquer");
  define("CHBLAN_7", "bloquer");
  define("CHBLAN_8", "Supprimé");
  define("CHBLAN_9", "Modérer la Chatbox");
  define("CHBLAN_10", "Modérer les messages");
  define("CHBLAN_11", "Message Chatbox  à afficher");
  define("CHBLAN_12", "Nombres des messages affichés dans la chatbox");
  define("CHBLAN_13", "Remplacez les liens");
  define("CHBLAN_14", "si coché, les liens postées seront remplacées par le texte entré dans la boîte ci-dessous");
  define("CHBLAN_15", "Remplacez la phrase si activé");
  define("CHBLAN_16", "Les liens seront remplacées par cette phrase");
  define("CHBLAN_17", "Compteur Wrappeur ");
  define("CHBLAN_18", "Les mots long du nombre que vous mettrez ici seront wrapper");
  define("CHBLAN_19", "Mettre à jour les Paramètres Chatbox ");
  define("CHBLAN_20", "Paramètres Chatbox ");
  define("CHBLAN_21", "Purger");
  define("CHBLAN_22", "Supprimer les messages vieux de plus d'une période de temps");
  define("CHBLAN_23", "Supprimer les messages vieux de plus ");
  define("CHBLAN_24", "Un jour");
  define("CHBLAN_25", "Une semaine");
  define("CHBLAN_26", "Un mois");
  define("CHBLAN_27", "- supprimer tous les messages -");
  define("CHBLAN_28", "Chatbox épurée.");
  define("CHBLAN_29", "Afficher la chatbox à l'intérieur d'une fenêtre déroulante");
  define("CHBLAN_30", "Hauteur de la fenêtre");
  define("CHBLAN_31", "Afficher émoticons");
  define("CHBLAN_32", "Groupe d'utilisateur Modérateur");
  define("CHBLAN_33", "Comptes Utilisateur recalculés");
  define("CHBLAN_34", "Recalculer les comptes messages Utilisateur");
  define("CHBLAN_35", "Recalculer");
  define("CHBLAN_36", "Options Affichage Chatbox");
  define("CHBLAN_37", "Chatbox Normale");
  define("CHBLAN_38", "Utilisez le code javascript pour mettre è jour des messages dynamiquement (AJAX)");
  ?>
