﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/French/lan_content_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:28 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("CONT_SCH_LAN_1", "Contenus");
  define("CONT_SCH_LAN_2", "Toutes les catégories de Contenu ");
  define("CONT_SCH_LAN_3", "Publié en réponse à un contenu");
  ?>
