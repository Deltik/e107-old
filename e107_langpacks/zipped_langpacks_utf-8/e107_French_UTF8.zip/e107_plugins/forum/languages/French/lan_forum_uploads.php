﻿<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/French/lan_forum_uploads.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:27 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Fichiers Uploadés du Forum");
  define("FRMUP_1","Fichiers uploadés sur le forum");
  define("FRMUP_2","Fichier supprimé");
  define("FRMUP_3","Erreur: Impossible de supprimé le fichier");
  define("FRMUP_4","Suppréssion de fichier");
  define("FRMUP_5","Nom de fichier");
  define("FRMUP_6","Résultat");
  define("FRMUP_7","Trouvé dans le sujet");
  define("FRMUP_8","NON TROUVÉ");
  define("FRMUP_9","Aucun fichier uploadé");
  define("FRMUP_10","Supprimer");
  ?>
