﻿<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/French/lan_forum_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:27 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("FOR_SCH_LAN_1", "Forum");
  define("FOR_SCH_LAN_2", "Selectioner un forum");
  define("FOR_SCH_LAN_3", "Tous les forums");
  define("FOR_SCH_LAN_4", "Message entier");
  define("FOR_SCH_LAN_5", "En tant que partie d'un message");
  ?>
