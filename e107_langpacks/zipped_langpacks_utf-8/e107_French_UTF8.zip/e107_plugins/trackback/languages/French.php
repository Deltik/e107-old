<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/trackback/languages/French.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/27 14:43:47 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("TRACKBACK_L1", "Configurer le Trackback");
  define("TRACKBACK_L2", "Cette extension vous permet d'utiliser le trackback dans les ".GLOBAL_LAN_NEWS_1."s publiées.");
  define("TRACKBACK_L3", "Suivi des retours est maintenant installé et fonctionne.");
  define("TRACKBACK_L4", "Paramètres Trackback sauvegardés.");
  define("TRACKBACK_L5", "Activer");
  define("TRACKBACK_L6", "Desactiver");
  define("TRACKBACK_L7", "Activer la Trackback");
  define("TRACKBACK_L8", "Text d'URL Trackback");
  define("TRACKBACK_L9", "Sauvegarder les paramètres");
  define("TRACKBACK_L10", "Paramètres Trackback");
  define("TRACKBACK_L11", "Adresse Trackback pour ce message:");
  define("TRACKBACK_L12", "Pas de trackback pour cette ".GLOBAL_LAN_NEWS_1."");
  define("TRACKBACK_L13", "Modérer le Trackback");
  define("TRACKBACK_L14", "Suprimer");
  define("TRACKBACK_L15", "Trackback Suprimmé.");
  ?>
