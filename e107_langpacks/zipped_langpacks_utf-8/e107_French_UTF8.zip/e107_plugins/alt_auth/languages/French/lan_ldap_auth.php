<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/alt_auth/languages/French/lan_ldap_auth.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/10/27 20:09:26 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LDAPLAN_1", "Adresse du serveur");
  define("LDAPLAN_2", "Base DN or Domain<br />Si LDAP - Enter BaseDN<br />If AD - Enter domain");
  define("LDAPLAN_3", "Utilisateur LDAP<br />Nom (full context) de l'utilisateur autorisé à scaner le directory.");
  define("LDAPLAN_4", "Mot de passe LDAP<br />Mot de passe pour l'utilisateur.");
  define("LDAPLAN_5", "Version LDAP");
  define("LDAPLAN_6", "Configurer LDAP auth");

define("LDAPLAN_7", "Filtre de recherche eDirectory :");
define("LDAPLAN_8", "Ceci sera utilisé pour s'assurer que l'identifiant (username) est dans la bonne arborescence, <br />ie '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Filtre de recherche courant sera :");

define("LDAPLAN_10", "Réglages mis à jour");
define("LDAPLAN_11", "ATTENTION: Il semble que le module ldap n'est pas disponible, régler la méthode d'authentification sur LDAP ne fonctionnera probablement pas!");
define("LDAPLAN_12", "Type de serveur");
define("LDAPLAN_13", "Mettre à jour les réglages");
define("LDAPLAN_14", "Retourner aux réglages principaux de alt_auth");

  ?>
