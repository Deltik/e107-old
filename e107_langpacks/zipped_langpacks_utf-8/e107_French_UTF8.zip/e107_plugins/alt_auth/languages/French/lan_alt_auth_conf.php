﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/alt_auth/languages/French/lan_alt_auth_conf.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:28 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_ALT_1", "Type d'identification courant");
  define("LAN_ALT_2", "Mettre à jour les réglages");
  define("LAN_ALT_3", "Choisir un autre type d'identification");
  define("LAN_ALT_4", "Configurer les paramètres pour");
  define("LAN_ALT_5", "Configurer les paramètres d'identification");
  define("LAN_ALT_6", "Action si échec de connexion");
  define("LAN_ALT_7", "Si la connexion échoue en employant le méthode alternative, comment réagir à cela?");
  define("LAN_ALT_8", "Action si l'utilisateur n'est pas trouvé");
  define("LAN_ALT_9", "Si le nom d'utilisateur (username) n'est pas trouvé en employant le méthode alternative, comment réagir à cela?");
  
  define("LAN_ALT_FALLBACK", "Utiliser la table e107 user");
  
  define("LAN_ALT_FAIL", "Échec de l'enregistrement");
  ?>
