<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/counter_menu/languages/French.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("COUNTER_L1", "Les visites de l'admin sont comptées");
  define("COUNTER_L2", "Cette page aujourd'hui ...");
  define("COUNTER_L3", "total");
  define("COUNTER_L4", "Depuis toujours ...");
  define("COUNTER_L5", "unique");
  define("COUNTER_L6", "Site ...");
  define("COUNTER_L7", "Compteur");
  define("COUNTER_L8", "Message Admin: <strong>Le compteur est désactivé.</strong><br />Pour l'activer, vous devez installer l'extension Compteur de Statistiques depuis <a href='".e_ADMIN."extension.php'>le gestionnaire des extensions</a>, ensuite activez le depuis <a href='".e_PLUGIN."log/admin_config.php'>l'écran de configuration</a>.");
  ?>
