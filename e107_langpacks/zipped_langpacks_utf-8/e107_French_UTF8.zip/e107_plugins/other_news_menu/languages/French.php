<?php
  define("TD_MENU_L1", "Autres ".GLOBAL_LAN_NEWS_2."s");
  ?>
