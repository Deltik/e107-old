<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/pdf/languages/French.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/27 14:43:47 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PDF_PLUGIN_LAN_1", "PDF");
  define("PDF_PLUGIN_LAN_2", "Aide création PDF");
  define("PDF_PLUGIN_LAN_3", "PDF");
  define("PDF_PLUGIN_LAN_4", "Cette extension est maintenant prête à être utilisée.");
  
  define("PDF_LAN_1", "PDF");
  define("PDF_LAN_2", "Préférences PDF");
  define("PDF_LAN_3", "Activé");
  define("PDF_LAN_4", "Désactivé");
  define("PDF_LAN_5", "Marge de la page à  gauche");
  define("PDF_LAN_6", "Marge de la page à  droite");
  define("PDF_LAN_7", "Marge de la page en haut ");
  define("PDF_LAN_8", "Police family");
  define("PDF_LAN_9", "Taille de la police par défaut");
  define("PDF_LAN_10", "Taille de la police du Nom du site");
  define("PDF_LAN_11", "Taille de la police de l'url de la page");
  define("PDF_LAN_12", "Taille de la police du numéro de la page");
  define("PDF_LAN_13", "Afficher le logo sur le pdf?");
  define("PDF_LAN_14", "Afficher le nom du site sur le pdf?");
  define("PDF_LAN_15", "Afficher l'url de la page créatrice sur le pdf?");
  define("PDF_LAN_16", "Afficher numéros de page sur le pdf?");
  define("PDF_LAN_17", "Mettre à jour");
  define("PDF_LAN_18", "Préférences PDF mises à jour avec succès");
  define("PDF_LAN_19", "Page");
  define("PDF_LAN_20", "Rapporter les erreurs");
  ?>
