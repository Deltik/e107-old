<?php
  define("UTHEME_MENU_L1", "Choisir le langage");
  define("UTHEME_MENU_L2", "Sélectionner le langage");
  ?>
