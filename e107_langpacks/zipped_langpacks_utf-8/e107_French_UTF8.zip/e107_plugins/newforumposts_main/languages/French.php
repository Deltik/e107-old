<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newforumposts_main/languages/French.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:46 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("NFPM_LAN_1", "Sujet");
  define("NFPM_LAN_2", "Auteur");
  define("NFPM_LAN_3", "Vues");
  define("NFPM_LAN_4", "Réponses");
  define("NFPM_LAN_5", "Dernier message");
  define("NFPM_LAN_6", "Sujets");
  define("NFPM_LAN_7", "de");
  
  define("NFPM_L1", "Cette extension affiche sur votre page d'accueil la liste des nouveaux messages publiés dans vos forums."); #added by Juan 
  define("NFPM_L2", "New Forum Posts");  
  define("NFPM_L3", "Pour configurer l'extension, veuillez cliquer sur le lien correspondant dans la section extensions de l'écran administration."); #added by Juan 
  define("NFPM_L4", "Activer dans quel espace?");
  define("NFPM_L5", "Désactiver");
  define("NFPM_L6", "En tête de page");
  define("NFPM_L7", "En bas de page");
  define("NFPM_L8", "Légende");
  define("NFPM_L9", "Nombre de nouveaux posts à afficher?");
  define("NFPM_L10", "Afficher dans un menu déroulant?");
  define("NFPM_L11", "Hauteur du menu");
  define("NFPM_L12", "Paramètres de l'extension New Forum Posts");
  define("NFPM_L13", "Mise à jour des paramètres New Forum Posts");
  define("NFPM_L14", "Les paramètres de l'extension New Forum Posts ont été mis à jour.");
  define("NFPM_L15", "Cocher pour afficher les nouveaux messages du forum.<br />Nouveaux sujets affichés par défaut.");
  define("NFPM_L16", '[utilisateur supprimé]');
  ?>
