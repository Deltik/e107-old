﻿<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_menu/languages/French.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:27 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("ONLINE_L1", "Invités: ");
  define("ONLINE_L2", "Membres: ");
  define("ONLINE_L3", "Sur cette page: ");
  define("ONLINE_L4", "En ligne");
  define("ONLINE_L5", "Membres");
  define("ONLINE_L6", " le plus récent");
  define("TRACKING_MESSAGE", "Le Traçeur d'Utilisateur en ligne est en ce moment désactivé, activez le <a href='".e_ADMIN."users.php?options'>ici</a></span><br />");
  ?>
