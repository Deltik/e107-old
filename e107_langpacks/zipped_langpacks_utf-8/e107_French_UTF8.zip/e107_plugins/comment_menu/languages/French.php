﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/comment_menu/languages/French.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:28 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("CM_L1", "Pas de commentaires.");
  define("CM_L2", "");
  define("CM_L3", "Légende");
  define("CM_L4", "Nombre de commentaires à afficher?");
  define("CM_L5", "Nombre de caractères à afficher?");
  define("CM_L6", "Suffixe pour les commentaires trop longs?");
  define("CM_L7", "Afficher le titre original de l'actualité dans le menu?");
  define("CM_L8", "Configuration du menu Nouveaux Commentaires");
  define("CM_L9", "Mis à jour des paramètres du menu");
  define("CM_L10", "Configuration du menu Nouveaux Commentaires sauvegardée");
  ?>
