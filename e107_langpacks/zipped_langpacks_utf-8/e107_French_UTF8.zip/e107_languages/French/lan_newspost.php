<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_newspost.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("NWSLAN_1", "".GLOBAL_LAN_NEWS_2."s supprimées.");
  define("NWSLAN_2", "Veuillez cocher la case de confirmation pour supprimer cette ".GLOBAL_LAN_NEWS_1.".");
  define("NWSLAN_3", "Aucune ".GLOBAL_LAN_NEWS_1." pour le moment.");
  define("NWSLAN_4", "".GLOBAL_LAN_NEWS_2."s existantes");
  define("NWSLAN_5", "Ouvrir l'éditeur HTML");
  define("NWSLAN_6", "Catégorie");
  define("NWSLAN_7", "éditer");
  define("NWSLAN_8", "Supprimer");
  define("NWSLAN_9", "cocher pour confirmer");
  define("NWSLAN_10", "Aucune catégorie configurée pour le moment.");
  define("NWSLAN_11", "Ajouter/éditer des Catégories");
  define("NWSLAN_12", "Titre");
  define("NWSLAN_13", "Corps");
  define("NWSLAN_14", "Suite");
  define("NWSLAN_15", "Autoriser les commentaires");
  define("NWSLAN_16", "Oui");
  define("NWSLAN_17", "Non");
  define("NWSLAN_18", "Autoriser les commentaires pour cette ".GLOBAL_LAN_NEWS_1."");
  define("NWSLAN_19", "Activation");
  define("NWSLAN_20", "Laisser le formulaire vide pour ne pas mettre de limite de temps");
  define("NWSLAN_21", "Activer entre le");
  define("NWSLAN_22", "Visibilité");
  define("NWSLAN_23", "Si cochée, l'".GLOBAL_LAN_NEWS_1." ne sera lisible que par les utilisateurs de ce groupe");
  define("NWSLAN_24", "Aperçu");
  define("NWSLAN_25", "Mettre à jour");
  define("NWSLAN_26", "Poster l'".GLOBAL_LAN_NEWS_2."");
  define("NWSLAN_27", "Aperçu");
  define("NWSLAN_28", "Créer une ".GLOBAL_LAN_NEWS_1."");
  define("NWSLAN_29", "Poster une ".GLOBAL_LAN_NEWS_1."");
  define("NWSLAN_30", "Afficher seulement le Titre de l'".GLOBAL_LAN_NEWS_2."");
  ?>