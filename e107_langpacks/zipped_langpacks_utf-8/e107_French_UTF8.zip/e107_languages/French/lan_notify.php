<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("NT_LAN_US_1", "Inscription d'un utilisateur ");
  
  define("NT_LAN_UV_1", "Inscription d'un utilisateur vérifiée");
  define("NT_LAN_UV_2", "Utilisateurs session string");
  
  define("NT_LAN_LI_1", "Utilisateur connecté");
  
  define("NT_LAN_LO_1", "Utilisateur déconnecté");
  define("NT_LAN_LO_2", " déconnecté du site");
  
  define("NT_LAN_FL_1", "Exclusion pour cause de flood");
  define("NT_LAN_FL_2", "Adresse IP exclue pour cause de flood");
  
  define("NT_LAN_SN_1", "Actualité proposée");
  
  define("NT_LAN_NU_1", "Mis à jour");
  
  define("NT_LAN_ND_1", "Actualité supprimée");
  define("NT_LAN_ND_2", "Identifiant de l'actualité supprimée");
  ?>
