<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_prefs.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_PREF_1", "e107 générateur de site web");
  define("LAN_PREF_2", "e107 portail web");
  define("LAN_PREF_3", "Ce site est généré par <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, Qui est sorti conformément à la licence <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL.");
  define("LAN_PREF_4", "censuré");
  define("LAN_PREF_5", "Forums");
  define("LAN_PREF_6","lamb");//$pref['sitetheme'] = "lamb";
  define("LAN_PREF_7","jayya");//$pref['admintheme'] = "jayya";
  define("LAN_PREF_8", "%A %d %B %Y - %H:%M:%S"); //$pref['longdate']   "%A %d %B %Y - %H:%M:%S");
  define("LAN_PREF_9", "%d %b : %H:%M"); //$pref['shortdate'] // "%d %b : %H:%M");
  define("LAN_PREF_10", "%a %d %b %Y, %I:%M%p"); //$pref['forumdate'] //"%a %b %d %Y, %I:%M%p");
  define("LAN_PREF_11", "French"); //$pref['sitelanguage'] //"English");
  ?>
