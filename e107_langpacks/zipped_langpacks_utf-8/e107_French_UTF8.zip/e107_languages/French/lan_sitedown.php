<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_sitedown.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Site temporairement fermé");
  define("LAN_SITEDOWN_00", "est temporairement fermé");
  define("LAN_SITEDOWN_01", "Nous avons fermé temporairement le site pour cause de maintenance. Cela ne devrait pas être trop long - veuillez revenir plus tard, veuillez nous excuser pour la gène occasionnée.");
  ?>
