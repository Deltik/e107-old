<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_comment.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/19 00:53:55 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Commentaires");
  define("LAN_0", "[bloqué par un admin]");
  define("LAN_1", "Débloquer");
  define("LAN_2", "Bloquer");
  define("LAN_3", "Supprimer");
  define("LAN_4", "Infos");
  define("LAN_5", "Commentaires ...");
  define("LAN_6", "Vous devez être identifié pour poster un commentaire sur ce site - merci de vous identifier </br> ou de cliquer");
  define("LAN_7", "Admin principal");
  define("LAN_8", "Commentaire");
  define("LAN_9", "Envoyer le commentaire");
  define("LAN_10", "Administrateur");
  define("LAN_11", "Impossible d'enregistrer votre commentaire dans la base de données - merci de retaper votre </br> commentaire en supprimant les caractères spéciaux.");
  define("LAN_16", "Nom : ");
  define("LAN_99", "Commentaires");
  define("LAN_100", "Actualité");
  define("LAN_101", "Sondages");
  define("LAN_102", "Réponse à : ");
  define("LAN_103", "Article");
  define("LAN_104", "Chronique");
  define("LAN_105", "Contenu");
  define("LAN_145", "Enregistré : ");
  define("LAN_194", "Invité");
  define("LAN_195", "Membre enregistré");
  define("LAN_310", "Impossible d'accepter ce commentaire car ce nom d'utilisateur est enregistré - si c'est </br>votre nom d'utilisateur, merci de vous enregistrer pour poster.");
  define("LAN_312", "Message dupliqué - impossible d'accepter.");
  define("LAN_313", "Emplacement");
  define("LAN_314", "Modérer les commentaires");
  define("COMLAN_1", "ici");
  define("COMLAN_2", "pour vous incrire.");
  define("COMLAN_3", "Erreur !");
  define("COMLAN_4", "Sujet");
  define("COMLAN_5", "Re:");
  //v.7.0
  define("COMLAN_6", 'Répondre à ceci');
  define("COMLAN_7", "Évaluation");
  define("COMLAN_8", "les commentaires sont fermés");
  define("LAN_315", "Références externes à votre contenu (Trackbacks)");
  define("LAN_316", "Pas de références externes à votre contenu (Trackback) pour cet apport d'actualité.");
  define("LAN_317", "Modérer les références externes à votre contenu (Trackbacks)");
  define("LAN_318", "Éditer le commentaire");
  define("LAN_319", "Édité");
  define("LAN_320", "Mise à jour du commentaire");
  ?>
