<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_print.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/27 20:07:21 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Impression d'une page"); }
  define("LAN_PRINT_86", "Catégorie ");
  define("LAN_PRINT_87", "par ");
  define("LAN_PRINT_94", "Posté par");
  define("LAN_PRINT_135", "".GLOBAL_LAN_NEWS_2."");
  define("LAN_PRINT_303", "Cette ".GLOBAL_LAN_NEWS_1." a été imprimée depuis le site ");
  define("LAN_PRINT_304", "Titre de l'article : ");
  define("LAN_PRINT_305", "Sous-titre : ");
  define("LAN_PRINT_306", "Cet article a été imprimé depuis le site ");
  define("LAN_PRINT_307", "Imprimer cette page");
  define("LAN_PRINT_1", "version imprimable");
  ?>
