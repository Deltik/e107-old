<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_email.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/27 20:07:21 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Courriel"); }
   define("LAN_EMAIL_1", "De :");
   define("LAN_EMAIL_2", "Adresse IP de l'expéditeur :");
   define("LAN_EMAIL_3", "Item envoyée de ");
   define("LAN_EMAIL_4", "Envoyé par Courriel");
   define("LAN_EMAIL_5", "Envoyer à un ami");
   define("LAN_EMAIL_6", "Je pense que tu devrais être intéressé par cette item de");
   define("LAN_EMAIL_7", "Envoyer par courriel");
   define("LAN_EMAIL_8", "Commentaire");
   define("LAN_EMAIL_9", "Désolé - impossible d'envoyer le courriel");
   define("LAN_EMAIL_10", "Courriel envoyé à ");
   define("LAN_EMAIL_11", "Courriel envoyé");
   define("LAN_EMAIL_12", "Erreur");
   define("LAN_EMAIL_13", "Envoyer cet article à un(e) ami(e)");
   define("LAN_EMAIL_14", "Envoyer cette ".GLOBAL_LAN_NEWS_1." à un(e) ami(e)");
   define("LAN_EMAIL_15", "Identifiant : ");
   define("LAN_EMAIL_106", "L'adresse courriel semble être invalide");
   define("LAN_EMAIL_185", "Envoyer l'article");
   define("LAN_EMAIL_186", "Envoyer l'".GLOBAL_LAN_NEWS_1."");
   define("LAN_EMAIL_187", "Courriel du destinataire");
   define("LAN_EMAIL_188", "J'ai pensé que tu pourrais être intéressé par cette ".GLOBAL_LAN_NEWS_1." de");
   define("LAN_EMAIL_189", "J'ai pensé que tu pourrais être intéressé par cet article de");
define("LAN_EMAIL_190", "Entrez le code visible");
   ?>
