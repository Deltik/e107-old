<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_banner.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Bannière"); 
  
  define("BANNERLAN_16", "Nom d'utilisateur : ");
  define("BANNERLAN_17", "Mot de passe : ");
  define("BANNERLAN_18", "Continuer");
  define("BANNERLAN_19", "Merci d'entrer le nom d'utilisateur et le mot de passe de votre client pour continuer");
  define("BANNERLAN_20", "Désolé, impossible de trouver ces informations dans la base de données. Merci de contacter l'administrateur principal pour plus d'informations.");
  define("BANNERLAN_21", "Statistiques des bannières");
  define("BANNERLAN_22", "Client");
  define("BANNERLAN_23", "IDentifiant de la bannière");
  define("BANNERLAN_24", "Nombre de Clics");
  define("BANNERLAN_25", "% de Clics");
  define("BANNERLAN_26", "Affichages");
  define("BANNERLAN_27", "Affichages achetés");
  define("BANNERLAN_28", "Affichages restant");
  define("BANNERLAN_29", "Pas de bannières");
  define("BANNERLAN_30", "Illimité");
  define("BANNERLAN_31", "Non applicable");
  define("BANNERLAN_32", "Oui");
  define("BANNERLAN_33", "Non");
  define("BANNERLAN_34", "Fin");
  define("BANNERLAN_35", "Nombre de Clics par adresses IP");
  define("BANNERLAN_36", "Active:");
  define("BANNERLAN_37", "Début:");
  //v.7.0
  define("BANNERLAN_38", "Erreur");
  ?>
