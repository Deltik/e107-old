<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_banner.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Bannière"); 
  
  define("LAN_16", "Nom d'utilisateur : ");
  define("LAN_17", "Mot de passe : ");
  define("LAN_18", "Continuer");
  define("LAN_19", "Merci d'entrer le nom d'utilisateur et le mot de passe de votre client pour continuer");
  define("LAN_20", "Désolé, impossible de trouver ces informations dans la base de données. Merci de contacter l'administrateur principal pour plus d'informations.");
  define("LAN_21", "Statistiques des bannières");
  define("LAN_22", "Client");
  define("LAN_23", "IDentifiant de la bannière");
  define("LAN_24", "Nombre de Clics");
  define("LAN_25", "% de Clics");
  define("LAN_26", "Affichages");
  define("LAN_27", "Affichages achetés");
  define("LAN_28", "Affichages restant");
  define("LAN_29", "Pas de bannières");
  define("LAN_30", "Illimité");
  define("LAN_31", "Non applicable");
  define("LAN_32", "Oui");
  define("LAN_33", "Non");
  define("LAN_34", "Fin");
  define("LAN_35", "Nombre de Clics par adresses IP");
  define("LAN_36", "Active:");
  define("LAN_37", "Début:");
  //v.7.0
  define("LAN_38", "Erreur");
  ?>
