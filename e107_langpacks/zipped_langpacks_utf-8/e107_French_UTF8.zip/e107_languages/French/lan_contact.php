<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/10 03:15:42 $
|     $Author: daddycool78 $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Contact);
define("LANCONTACT_02", "Formulaire Contact");
define("LANCONTACT_03", "Entrez votre nom:");
define("LANCONTACT_04", "Email:");
define("LANCONTACT_05", "Sujet du message:");
define("LANCONTACT_06", "Votre message:");
define("LANCONTACT_07", "Recevoir une copie du mail à votre adresse ");
define("LANCONTACT_08", "Envoyer");
define("LANCONTACT_09", "Message envoyé.");
define("LANCONTACT_10", "Erreur, votre message n'a pas pu nous parvenir.");
define("LANCONTACT_11", "Votre adresse email ne semble pas être valide.\\nVeuillez vérifier et recommencer.");
define("LANCONTACT_12", "Message trop court.");
define("LANCONTACT_13", "Aucun sujet !? Veuillez le présicer."); 

?>
