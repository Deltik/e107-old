<?php
  define("LAN_183", "Navigation Principale");
  define("LAN_502", "Administration");
  ?>
