<?php
  define("LAN_EP_1", "Envoyer par courriel"); //"email to someone"
  define("LAN_EP_2", "Format imprimable");   //"printer friendly "
  ?>
