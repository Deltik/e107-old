<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_news.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "".GLOBAL_LAN_NEWS_2."s");
  define("LAN_NEWS_1", "".GLOBAL_LAN_NEWS_2." réservée uniquement aux utilisateurs du site");
  define("LAN_NEWS_2", "Vous n'êtes pas autorisé à voir cette ".GLOBAL_LAN_NEWS_1."");
  //define("LAN_NEWS_3", "Veuillez supprimer le fichier install.php de votre serveur");
  //define("LAN_NEWS_4", "Si vous ne le faites pas, il y aura une faille potentielle de sécurité sur votre site");
  define("LAN_NEWS_5", "<strong>Erreur!</strong> N'a pu mettre à jour l'".GLOBAL_LAN_NEWS_1." dans la base de données !</strong>");
  define("LAN_NEWS_6", "".GLOBAL_LAN_NEWS_2." insérée dans la base de données");
  define("LAN_NEWS_7", "<strong>Erreur!</strong> N'a pu insérer l'".GLOBAL_LAN_NEWS_1." dans la base de données !</strong>");
  define("LAN_NEWS_8", "".GLOBAL_LAN_NEWS_2." insérée dans la base de données de toutes les langues. ID:");
  define("LAN_NEWS_9", "Seul le Titre s'affiche - <strong>Seul le titre de l'".GLOBAL_LAN_NEWS_1." sera affiché</strong><br />");
  define("LAN_NEWS_10", "La proposition d'".GLOBAL_LAN_NEWS_1."s est <strong>désactivé</strong>. (Elle ne sera pas disponible pour vos visiteurs). ");
  define("LAN_NEWS_11", "La proposition d'".GLOBAL_LAN_NEWS_1."s est <strong>activé</strong>. (Elle sera disponible pour vos visiteurs). ");
  define("LAN_NEWS_12", "Les commentaires sont <strong>activés</strong>. ");
  define("LAN_NEWS_13", "Les commentaires sont <strong>désactivés</strong>. ");
  define("LAN_NEWS_14", "<br />Période d'activation: ");
  define("LAN_NEWS_15", "Longueur du corps: ");
  define("LAN_NEWS_16", "b. Longueur de l'extension: ");
  define("LAN_NEWS_17", "b.");
  define("LAN_NEWS_18", "Info:");
  define("LAN_NEWS_19", "Maintenant");
  define("LAN_NEWS_20", "".GLOBAL_LAN_NEWS_2." mise à jour en base de données pour les langues suivantes: ");
  define("LAN_NEWS_21", "".GLOBAL_LAN_NEWS_2." mise à jour en base de données.");
  //   define("LAN_NEWS_22", "Aller à la page:");
  define("LAN_NEWS_23", "Catégories d'".GLOBAL_LAN_NEWS_1."s ");
  define("LAN_NEWS_24", "Créer un pdf pour cette ".GLOBAL_LAN_NEWS_1."");
  define("LAN_NEWS_82", "".GLOBAL_LAN_NEWS_2."s - Catégorie");
  define("LAN_NEWS_83", "Aucune ".GLOBAL_LAN_NEWS_1." pour le moment - veuillez revenir plus tard.");
  define("LAN_NEWS_84", "".GLOBAL_LAN_NEWS_2."s");
  define("LAN_NEWS_99", "Commentaires");
  define("LAN_NEWS_100", "Autorisés");
  define("LAN_NEWS_307", "Nombre total d'".GLOBAL_LAN_NEWS_2."s dans cette catégorie : ");
  define("LAN_NEWS_462", "Pas d'".GLOBAL_LAN_NEWS_1."s pour le mois spécifié");
  ?>