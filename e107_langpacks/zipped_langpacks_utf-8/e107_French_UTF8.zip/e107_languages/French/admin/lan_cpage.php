<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_cpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("CUSLAN_0", "Aide Menu/Page Personalisé");
  define("CUSLAN_1", "Titre");
  define("CUSLAN_2", "Type");
  define("CUSLAN_3", "Options");
  define("CUSLAN_4", "Supprimer cette page?");
  define("CUSLAN_5", "Pages existantes");
  define("CUSLAN_7", "Nom de menu");
  define("CUSLAN_8", "Titre / Légende");
  define("CUSLAN_9", "Texte");
  define("CUSLAN_10", "Autoriser l'évaluation de la page");
  define("CUSLAN_11", "Page d'accueil");
  define("CUSLAN_12", "Créer une page");
  define("CUSLAN_13", "Autoriser les commentaires");
  define("CUSLAN_14", "Page securisé par mot de passe");
  define("CUSLAN_15", "Entrer un mot de passe pour sécuriser votre page");
  define("CUSLAN_16", "Créer un lien dans le menu principal");
  define("CUSLAN_17", "Entrer un nom de lien à créer");
  define("CUSLAN_18", "Page / lien visible par");
  define("CUSLAN_19", "Mettre à jour la Page");
  define("CUSLAN_20", "Créer la Page");
  define("CUSLAN_21", "Mettre à jour le Menu");
  define("CUSLAN_22", "Créer un Menu");
  define("CUSLAN_23", "Éditer la page");
  define("CUSLAN_24", "Créer une nouvelle page");
  define("CUSLAN_25", "Éditer le menu");
  define("CUSLAN_26", "Créer un nouveau menu");
  define("CUSLAN_27", "Page sauvegardée en base de données.");
  define("CUSLAN_28", "Page supprimée");
  define("CUSLAN_29", "Liste de page si aucune page n'est sélectionnée");
  define("CUSLAN_30", "Délais d'expiration du cookie (en secondes)");
  define("CUSLAN_31", "Créer un menu");
  define("CUSLAN_32", "Convertion de pages/menus anciens");
  define("CUSLAN_33", "Page Options");
  define("CUSLAN_34", "Commencer la conversion");
  define("CUSLAN_35", "Mettre à jour la Page Personnalisée finalisée - mise à jour ");
  define("CUSLAN_36", "Établissez vos préférences pour chaque page, retournez s'il vous plaît à la première page et éditez les pages.");
  define("CUSLAN_37", "Mise à jour de Page Personnalisée");
  define("CUSLAN_38", "Oui");
  define("CUSLAN_39", "Non");
  define("CUSLAN_40", "Sauvegarder les Options");
  define("CUSLAN_41", "Afficher l'auteur et la date de l'information ");
  define("CUSLAN_42", "Pas de page définie pour le moment");
  ?>
