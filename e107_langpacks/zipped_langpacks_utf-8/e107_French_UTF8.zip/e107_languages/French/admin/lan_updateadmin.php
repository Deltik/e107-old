<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_updateadmin.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("UDALAN_1", "Erreur - veuillez recommencer");
  define("UDALAN_2", "Paramètres Mis à jour");
  define("UDALAN_3", "Paramètres Mis à jour de");
  define("UDALAN_4", "Nom");
  define("UDALAN_5", "Mot de passe");
  define("UDALAN_6", "Retaper le mot de passe");
  define("UDALAN_7", "Changer de mot de passe");
  define("UDALAN_8", "Mot de passe Mis à jour de");
  ?>
