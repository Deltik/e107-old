<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_credits.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("CRELAN_1", "Crédits");
  define("CRELAN_2", "Ci-après une liste de logiciel de tiers / des ressources utilisées dans e107. L équipe de développement e107 voudrait personnellement remercier les développeurs de nous permettre de redistribuer leur code avec e107 et ainsi de publier leur logiciel conformément à la licence de GPL.");
  //  define("CRELAN_3", "Resource");
  //  define("CRELAN_4", "Description");
  //  define("CRELAN_5", "Site Web");
  //  define("CRELAN_6", "Permission");
  define("CRELAN_7", "Version");
  ?>
