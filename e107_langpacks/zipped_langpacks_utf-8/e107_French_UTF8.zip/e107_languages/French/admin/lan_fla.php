<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_fla.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("FLALAN_1", "Échecs d'essais de connexions");
  define("FLALAN_2", "Aucun échec d'essai de connexion n'a été noté");
  define("FLALAN_3", "Tentative supprimée");
  define("FLALAN_4", "Utilisateur ayant essayé de se connecter avec username/password éronné");
  define("FLALAN_5", "IP(s) Exclus");
  define("FLALAN_6", "Date");
  define("FLALAN_7", "Donnés");
  define("FLALAN_8", "Adresse IP/ Hébergeur");
  define("FLALAN_9", "Options");
  define("FLALAN_10", "Suprimer/Bannir des entrées");
  define("FLALAN_11", "sélectionner toutes les cases à supprimer");
  define("FLALAN_12", "déselectionner toutes les cases à supprimer");
  define("FLALAN_13", "sélectionner toutes les cases d'exclus");
  define("FLALAN_14", "déselectionner toutes les cases d'exclus");
  define("FLALAN_15", "L'adresse(s) IP suivante(s) a (ont) été automatiquement exclus - l'utilisation ayant fait plus de 10 tentatives de connexions qui ont échouées");
  define("FLALAN_16", "Supprimer cette liste d'exclus automatique");
  define("FLALAN_17", "liste d'exclus automatique supprimée");
  ?>
