<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_modcomment.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("MDCLAN_1", "Modéré.");
  define("MDCLAN_2", "Aucun commentaire pour cette ".GLOBAL_LAN_NEWS_1."");
  define("MDCLAN_3", "Utilisateur");
  define("MDCLAN_4", "Visiteur");
  define("MDCLAN_5", "débloquer");
  define("MDCLAN_6", "bloquer");
  define("MDCLAN_8", "Modérer les commentaires");
  define("MDCLAN_9", "Attention ! La suppression d'une catégorie de commentaires, supprimera tous les commentaires !");
  define("MDCLAN_10", "option");
  define("MDCLAN_11", "commentaire");
  define("MDCLAN_12", "commentaires");
  define("MDCLAN_13", "Bloqué(s)");
  define("MDCLAN_14", "Activer les commentaires ");
  define("MDCLAN_15", "Oui");
  define("MDCLAN_16", "Non");
  //  define("MDCLAN_17", "");
  //  define("MDCLAN_18", "");
  //  define("MDCLAN_19", "");
  //  define("MDCLAN_20", "");
  ?>
