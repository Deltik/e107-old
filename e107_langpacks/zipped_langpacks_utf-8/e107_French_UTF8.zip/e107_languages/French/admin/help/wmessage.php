<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/wmessage.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Cette page vous permet de rédiger un message de bienvenue, ou un message informatif qui se placera en haut de votre page d&apos;accueil.
  Le message peut être différent pour les invités, les membres et les administrateurs.";
  $ns -> tablerender("Aide sur WMessage", $text);
  ?>
