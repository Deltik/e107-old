<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/newspost.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "<strong>Général</strong><br />
  L'actualité sera affichée sur la page principale, la suite sera lisible après avoir cliqué sur le lien 'Lire la suite'.
  <br />
  <br />
  <strong>Titre Seulement</strong>
  <br />
  Choisissez cela pour ne montrer que le titre sur la page d'accueil (sous forme de lien pour voir l'Actualité complète).
  <br /><br />
  <strong>Activation</strong>
  <br />
  Si vous configurez une date de début et/ou une date de fin, l'actualité ne sera affichée qu'entre ces 2 dates.
  ";
  $ns -> tablerender('Aide Actus', $text);
  ?>
