<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/users_extended.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Les champs étendus de profil vous permettent d'ajouter des compléments d'informations que les utilisateurs peuvent préciser dans leur profil.";
  $ns -> tablerender(" Aide des profil étendus", $text);
  ?>
