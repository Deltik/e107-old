<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/link_category.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Vous pouvez séparer vos liens en différentes catégories, cela rendra la navigation plus simple et améliorera la mise en page.<br /><br />Chaque lien ajouté dans la catégorie principale sera affiché dans le menu principal.";
  $ns -> tablerender("Catégories de liens", $text);
  ?>
