<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/search.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Si votre version de serveur MySql le permet vous pouvez commuter vers la méthode de tri de MySql qui est plus rapide que la méthode de tride PHP. Voir les préférences.<br /><br />";
  $ns -> tablerender ("Aide sur la Recherche", $text);
  ?>
