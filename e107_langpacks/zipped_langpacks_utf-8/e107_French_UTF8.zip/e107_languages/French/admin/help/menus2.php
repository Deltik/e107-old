<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/menus2.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text .= "Vous pouvez choisir où et dans quel ordre seront affichés vos menus par rapport aux autres. Utilisez les flêches pour déplacer les menus vers le haut ou vers le bas jusqu';à que vous soyez satisfait de leur placement.<br />Les menus au milieu de la page sont désactivés, vous pouvez les activer en choisissant l'endroit où les mettre.";
  $ns -> tablerender(Aide, $text);
  ?>
