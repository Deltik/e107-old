<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/download.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Envoyez vos fichiers dans le dossier ".e_FILE."downloads , vos images dans le dossier ".e_FILE."downloadimages et vos vignettes dans le dossier ".e_FILE.".
  <br /><br />
  Pour proposer un téléchargement, créez d'abord une catégorie, puis créez une sous-catégorie, vous pourrez finalement rendre le téléchargement disponible en le plaçant dans cette sous-catégorie.";
  $ns -> tablerender("Aide", $text);
  ?>
