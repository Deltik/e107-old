<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/content.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Vous pouvez ajouter une simple page à votre site en utilisant cette fonctionnalité. Un lien vers la nouvelle page sera créé dans le menu principal. Par exemple, si vous créez une nouvelle page avec le nom 'Test', un lien appelé 'Test' apparaîtra dans la liste des liens.<br />
  Si vous voulez que votre page ait une barre de titre, entrez le titre dans le champ 'Titre de la page'.";
  $ns -> tablerender("Aide", $text);
  ?>
