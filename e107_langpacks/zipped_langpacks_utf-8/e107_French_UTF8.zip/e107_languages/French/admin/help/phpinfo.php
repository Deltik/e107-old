<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/phpinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = " Cette page affiche tous vos paramètres de configuration des serveurs PHP. ";
  $ns -> tablerender("Aide PHP Info", $text);
  ?>
