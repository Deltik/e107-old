<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/userclass2.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $caption = "Aide Groupe d'utilisateur";
  $text = "Vous pouvez créer/éditer/supprimer des groupes à partir de cette page.<br />C'est utile pour restrindre les utilisateurs à certaines parties de votre site. Par exemple, vous pouvez créer un groupe appelé TEST, puis créer un forum qui n'autorise que les utilisateurs du groupe TEST à y accéder.";
  $ns -> tablerender($caption, $text);
  ?>