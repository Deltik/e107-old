<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $caption = "Aide Maintenance";
  $text = "Si vous mettez à jour e107 ou si vous voulez que votre site soit indisponible pour quelque temps, cochez la case et vos visiteurs seront redirigés vers une page qui explique pourquoi votre site est indisponible. Cochez la case de nouveau si vous voulez revenir à une situation normale.";
  $ns -> tablerender($caption, $text);
  ?>
