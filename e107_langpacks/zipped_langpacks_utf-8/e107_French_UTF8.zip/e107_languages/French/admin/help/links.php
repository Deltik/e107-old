<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/links.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $caption = "Aide Liens";
  $text = "Entrer tous les liens internes au site ici.<br /> Pour les liens principaux du site (ceux affichés dans votre barre de navigation, ou menu principal) sélectionner la catégorie 'Principale', Tous les autres seront affichés dans la page Liens (Links). Vous pouvez séparer ces liens en différentes catégories.
  <br />
  <br />
  Le générateur de sous-menus est à utiliser seulement pour les menus DHTML e107  (TreeMenu, UltraTreeMenu, eDynamicMenu, ypSlideMenu...).pour les autres liens svp utiliser l'extension Links Page.
  <br />
  <br />
  Vous pouvez séparer les liens en différentes catégories, ceci rend la navigation sur la page Liens (Links) plus commode et améliore la lisibilité.<br /><br />Tous lien entré sous  la catégorie Principale (Main) sera affiché dans le menu de navigation principal.";
  $ns -> tablerender($caption, $text);
  ?>
