<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/administrator.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  if (!defined('e107_INIT')) { exit; }
  $caption = "Aide Administrateurs";
  $text = "Utilisez cette page pour entrer un nouvel administrateur, ou en supprimer.<br /> L'administrateur n'aura le droit d'accéder qu'aux fonctionnalités cochées<br /><br />
  Pour créer un nouvel administrateur, accédez à la page de configution admin et mettez à jour l'utilisateur existant en lui conférant le status admin.";
  $ns -> tablerender($caption, $text);
  ?>
