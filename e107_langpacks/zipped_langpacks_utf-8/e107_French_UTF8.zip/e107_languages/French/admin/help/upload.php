<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/upload.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Ici vous pouvez autoriser/refuser que les utilisateurs téléchargent des fichiers et de contrôler les téléchargements de fichiers.";
  $ns -> tablerender("Aide Téléchargement Publique", $text);
  ?>
