<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/filemanager.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Vous êtes autorisé à gérer les fichiers dans le dossier /e107_files à partir de cette page. Si vous obtenez des erreurs au sujet de permissions, veuillez mettre un CHMOD de 777 sur le dossier oû vous voulez envoyer le fichier.";
  $ns -> tablerender("Gestionnaire de fichiers", $text);
  ?>
