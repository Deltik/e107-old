<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/image.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "De cette page, vous pouvez autoriser/refuser que les utilisateurs puissent poster des images sur le site, vous avez aussi la possibilité de visualiser les avatars envoyés.";
  $ns -> tablerender("Aide Images", $text);
  ?>
