<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/theme.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  $text = "Le gestionnaire de thème vous permet d'établir un thème public pour votre site et un thème pour la zone d'administration.";
  $ns -> tablerender("Aide Gestionnaire de thème", $text);
  ?>
