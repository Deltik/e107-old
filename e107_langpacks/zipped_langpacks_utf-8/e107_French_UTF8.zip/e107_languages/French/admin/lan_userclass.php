﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("UCSLAN_1", "Envoyer une alerte par courriel à");
  define("UCSLAN_2", "Privilèges mis à jour");//part of user message ligne 80
  define("UCSLAN_3", "Cher");//part of user message ligne 80
  define("UCSLAN_4", "Vos privillèges ont été Mis à jour à");//part of user message ligne 80
  define("UCSLAN_5", "Désormais vous avez accès au(x) espaces(s) suivant(s)");//part of user message ligne 80
  define("UCSLAN_6", "Configurer l'appartenance au(x) groupe(s) de l'utilisateur");
  define("UCSLAN_7", "Enregistrer Appartenance Groupes");//ligne 105
  define("UCSLAN_8", "Avertir l'utilisateur"); //ligne 105
  define("UCSLAN_9", "Groupe Mis à jour");//ligne 105
  define("UCSLAN_10", "Cordialement");//part of user message ligne 80
  ?>
