<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_cache.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("CACLAN_1", "Statut du système Cache");
  define("CACLAN_2", "Mettre à jour");
  define("CACLAN_3", "Système Cache");
  define("CACLAN_4", "Statut du cache Mis à jour");
  define("CACLAN_5", "Vider le cache");
  define("CACLAN_6", "Le cache a été vidé");
  define("CACLAN_7", "Désactiver le système cache");
  define("CACLAN_8", "Sauvegarder le cache dans la base MySQL");
  define("CACLAN_9", "Sauvegarder le cache dans un fichier du disque dur");
  define("CACLAN_10", "Le répertoire du cache est non-inscriptible. Veuillez vous assurer que le répertoire est en CHMOD 777");
  ?>
