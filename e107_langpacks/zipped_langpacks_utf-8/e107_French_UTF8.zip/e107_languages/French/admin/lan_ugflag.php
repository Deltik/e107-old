<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_ugflag.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("UGFLAN_1", "Paramètres de maintenance mises à jour");
  define("UGFLAN_2", "Activer la maintenance du site");
  define("UGFLAN_3", "Mettre à jour");
  define("UGFLAN_4", "Paramètres de Maintenance");
  define("UGFLAN_5", "Texte à  afficher lorsque le site est en maintenance");
  define("UGFLAN_6", "Laisser vide pour afficher le message par défaut");
  ?>
