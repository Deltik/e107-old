<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_admin_log.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/12 08:48:19 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Journal d'Admin");
define("LAN_ADMINLOG_1", "Date");
define("LAN_ADMINLOG_2", "Titre");
define("LAN_ADMINLOG_3", "Description");
define("LAN_ADMINLOG_4", "IP utilisateur");
define("LAN_ADMINLOG_5", "ID utilisateur");
define("LAN_ADMINLOG_6", "Icône informative");
define("LAN_ADMINLOG_7", "Message Informatif");
define("LAN_ADMINLOG_8", "Icône d'avertissement");
define("LAN_ADMINLOG_9", "Message d'avertissement");
define("LAN_ADMINLOG_10", "Icône d'alerte");
define("LAN_ADMINLOG_11", "Message d'alerte");
define("LAN_ADMINLOG_12", "Icône d'erreur fatale");
define("LAN_ADMINLOG_13", "Message d'erreur fatale");
?>
