<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("FRTLAN_1", "Les paramètres de la page d'accueil ont été mis à jour.");
  define("FRTLAN_2", "Page d'accueil pour");
  define("FRTLAN_6", "Liens");
  //  define("FRTLAN_7", "Page de Contenu");
  define("FRTLAN_12", "Mettre à jour les paramètres");
  define("FRTLAN_13", "Paramètres de la page d'accueil");
  define("FRTLAN_15", "Autre (entrer l'url):");
  define("FRTLAN_16", "erreur: pas de catégorie principale de Page Contenus  ");
  define("FRTLAN_17", "erreur: pas de sous catégorie de page contenus sélectionnée");
  define("FRTLAN_18", "erreur: pas de page contenus sélectionnée");
  define("FRTLAN_19", "Catégorie principale de Pages Contenus ");
  define("FRTLAN_20", "Catégorie Page Contenus");
  define("FRTLAN_21", "Page Contenus");
  define("FRTLAN_26", "tous les utilisateurs");
  define("FRTLAN_27", "Invités");
  define("FRTLAN_28", "Membres");
  define("FRTLAN_29", "Administrateurs");
  define("FRTLAN_31", "Tous les utilisateurs");
  define("FRTLAN_32", "Groupe d'utilisateurs");
  define("FRTLAN_33", "Paramètres en cours");
  define("FRTLAN_34", "Page d'accueil");
  ?>
