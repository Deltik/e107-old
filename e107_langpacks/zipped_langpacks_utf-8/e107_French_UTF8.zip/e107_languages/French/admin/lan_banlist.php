<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_banlist.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("BANLAN_1", "Bannissement supprimé.");
  define("BANLAN_2", "Aucun bannissement.");
  define("BANLAN_3", "Bannissements existants");
  define("BANLAN_4", "Supprimer un bannissement");
  define("BANLAN_5", "Entrer l'adresse IP, le Courriel ou l'adresse de l'Hébergeur");
  define("BANLAN_6", "Bannir par adresse électronique"); 
  define("BANLAN_7", "Raison");
  define("BANLAN_8", "Bannir l&#39;utilisateur");
  define("BANLAN_9", "Bannir les utilisateurs du site");
  define("BANLAN_10", "IP / Courriel / Raison");
  define("BANLAN_11", "Bannissement-Automatique: Plus de 10 essais de connexion infructueux");
  ?>
