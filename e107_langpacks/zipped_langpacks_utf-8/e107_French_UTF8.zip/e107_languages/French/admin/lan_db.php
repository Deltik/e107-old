﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_db.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("DBLAN_1", "Les paramètres de configuration de votre site ont été sauvegardés dans la base de données.");
  define("DBLAN_2", "Cliquer sur ce bouton pour faire une sauvegarde de votre base de données e107");
  define("DBLAN_3", "Sauvegarde SQL");
  define("DBLAN_4", "Cliquer sur ce bouton pour vérifier la validité de votre base de données e107");
  define("DBLAN_5", "Vérifier la validité");
  define("DBLAN_6", "Cliquer sur ce bouton pour optimiser votre base de données e107");
  define("DBLAN_7", "Optimiser la base SQL");
  define("DBLAN_8", "Cliquer sur ce bouton pour faire une sauvegarde des paramètres de configuration de votre site");
  define("DBLAN_9", "Sauvegarder les paramètres");
  define("DBLAN_10", "Utilitaires de la base de données");
  define("DBLAN_11", "La base de données mySQL");
  define("DBLAN_12", "a été optimisée");
  define("DBLAN_13", "Revenir en arrière");
  define("DBLAN_14", "Fait");
  define("DBLAN_15", "Cliquer sur ce bouton pour vérifier si une ou plusieurs mise(s) à jour de votre base de données est/sont disponible(s)");
  define("DBLAN_16", "Vérifier");
  ?>
