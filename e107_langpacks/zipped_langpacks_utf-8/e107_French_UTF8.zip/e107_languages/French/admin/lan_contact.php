<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LANCONTACT_01", "Détails du contact");
define("LANCONTACT_02", "Formulaire de contact");
define("LANCONTACT_03", "Entrez votre nom:");
define("LANCONTACT_04", "Addresse courriel:");
define("LANCONTACT_05", "Sujet du message:");
define("LANCONTACT_06", "Entrez votre message:");
define("LANCONTACT_07", "Envoyez une copie de ce message à votre propre adresse ");
define("LANCONTACT_08", "Envoyer");
define("LANCONTACT_09", "Votre message à été envoyé.");
define("LANCONTACT_10", "Il y a eu un problème lors de l'envoi de votre message.");
define("LANCONTACT_11", "Votre adresse courriel ne semble pas valide.\\n Veuillez la vérifier et essayer à nouveau.");
define("LANCONTACT_12", "Votre message est trop court.");
define("LANCONTACT_13", "Veuillez inclure un sujet à votre message."); 
?>
