<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_language.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/27 20:07:21 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LANG_LAN_00", "ne peuvent pas être créé (elles existent déjà )");
  define("LANG_LAN_01", "a été supprimée (si existante) et recréée");
  define("LANG_LAN_02", "n'a pas pu être supprimée");
  define("LANG_LAN_03", "Tables");
  
  define("LANG_LAN_05", "Non Installées");
  define("LANG_LAN_06", "Créer les tables");
  define("LANG_LAN_07", "Supprimer les tables existantes?");
  define("LANG_LAN_08", "Remplacer les tables existantes? (Les données seront perdues).");
  define("LANG_LAN_10", "Confirmer Suppression");
  define("LANG_LAN_11", "Supprimer les tables non cochées ci-dessus (si elles existent).");
  define("LANG_LAN_12", "Installer les tables multi-langages");
  define("LANG_LAN_13", "Préférences multi-langages");
  define("LANG_LAN_14", "Langage du site par défaut");
  define("LANG_LAN_15", "Cocher pour copier les données de la langue par défaut. (Utile pour les liens, catégories d'".GLOBAL_LAN_NEWS_1.", etc)");
  define("LANG_LAN_16", "Usage de la base de données multi-langages");  //Multi-language Database Usage
define("LANG_LAN_17", "Langage par défaut - Aucunes tables supplémentaires ne sont requises.");
define("LANG_LAN_18", "Utiliser le Sous-domaine Fixé pour déterminer le langage :");
define("LANG_LAN_19", "ex. fr.mydomain.com pour régler le langage en French.");
define("LANG_LAN_20", "Entrez le nom principal du site pour activer. ex. mydomain.com");
define("LANG_LAN_21", "Outils Langage");
  ?>
