<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_e107_update.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_UPDATE_2", "Action");
  define("LAN_UPDATE_3", "Non nécessaire");
  define("LAN_UPDATE_5", "mise à jour disponible");
  //  define("LAN_UPDATE_6", "Mettre tout à jour");
  define("LAN_UPDATE_7", "Exécutée");
  define("LAN_UPDATE_8", "Mise à jour de la");
  define("LAN_UPDATE_9", "à");
  define("LAN_UPDATE_10", "Mises à jour disponibles");
  define("LAN_UPDATE_11", ".617 à .7 Mise à jour poursuivie ");
define("LAN_UPDATE_12", "Une de vos tables contient des entrées dupliquées.");
  ?>
