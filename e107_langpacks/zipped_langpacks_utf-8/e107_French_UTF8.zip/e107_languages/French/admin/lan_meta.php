<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_meta.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("METLAN_1", "Les Méta-tags ont été Mis à jour dans la base de données");
  define("METLAN_2", "Entrer les méta-tags");
  define("METLAN_3", "Entrer les nouveaux méta-tags");
  define("METLAN_4", "Mis à jour");
  define("METLAN_5", "Taper votre description ici");
  define("METLAN_6", "taper, une, liste, de, mots, clés, ici");
  define("METLAN_7", "taper les infos de droits d'auteur ici");
  define("METLAN_8", "Méta Tags");
  define("METLAN_9", "Description");
  define("METLAN_10", "Mots clés");
  define("METLAN_11", "Copyright");
  ?>
