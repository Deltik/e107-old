<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/27 14:43:42 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("LAN_CHECK_1", "Sélectionner le langage à vérifier");
  define("LAN_CHECK_2", "Commencer la vérification");
  define("LAN_CHECK_3", "Vérification de");
  define("LAN_CHECK_4", "Fichier manquant !");
  define("LAN_CHECK_5", "<strong>!!! Phrase manquante !!!</strong>");
  define("LAN_CHECK_6", "OK");
  define("LAN_CHECK_7", "phrase");
  define("LAN_CHECK_8", "un fichier est manquant...");
  define("LAN_CHECK_9", " fichiers manquants...");
  define("LAN_CHECK_10", "Erreur critque: ");
  define("LAN_CHECK_11", "Pas de fichier manquant !");
  define("LAN_CHECK_12", "Ce fichier est non valide...");
  define("LAN_CHECK_13", " Fichiers non valides...");
  define("LAN_CHECK_14", "Tous les Fichiers sont valides  !");
  ?>
