<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_user_extended.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("UE_LAN_1", "Boîte de texte");
  define("UE_LAN_2", "Bouton Radio");
  define("UE_LAN_3", "Liste déroulante");
  define("UE_LAN_4", "Champ de table BdD");
  define("UE_LAN_5", "Zone de texte");
  define("UE_LAN_6", "Nombre entier");
  define("UE_LAN_7", "Date");
  define("UE_LAN_8", "Langage");
  define("UE_LAN_9", "Nom");
  define("UE_LAN_10", "Type");
  define("UE_LAN_11", "Utilise");
  define("UE_LAN_HIDE", "Cacher aux membres");
  define("UE_LAN_LOCATION", "Résidence");
  define("UE_LAN_LOCATION_DESC", "Résidence du membre");
  define("UE_LAN_AIM", "AIM");
  define("UE_LAN_AIM_DESC", "Adresse AIM");
  define("UE_LAN_ICQ", "ICQ");
  define("UE_LAN_ICQ_DESC", "Numéro ICQ");
  define("UE_LAN_YAHOO", "Yahoo!");
  define("UE_LAN_YAHOO_DESC", "Adresse Yahoo!");
  define("UE_LAN_MSN", "MSN");
  define("UE_LAN_MSN_DESC", "Adresse MSN");
  define("UE_LAN_HOMEPAGE", "Votre site Web");
  define("UE_LAN_HOMEPAGE_DESC", "URL du site web du membre");
  define("UE_LAN_BIRTHDAY", "Anniversaire");
  define("UE_LAN_BIRTHDAY_DESC", "Date de Naissance");
  ?>
