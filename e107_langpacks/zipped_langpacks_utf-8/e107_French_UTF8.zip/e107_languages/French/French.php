<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/French.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/04/19 03:22:16 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  setlocale(LC_ALL, 'fr_FR.utf8', 'french');
  define("CORE_LC", 'fr');
  define("CORE_LC2", 'fr');
  // define("TEXTDIRECTION","rtl");
  define("CHARSET", "utf-8");
  define("CORE_LAN1","Erreur : le thème requis est manquant.\\n\\nChangez le thème utilisé dans les préférences (administration) ou uploadez les fichiers du thème actuel sur le serveur.");
  //v.616
  define("CORE_LAN2"," \\1 inscrit:"); // "\\1" représente le nom d'utilisateur.
  define("CORE_LAN3","fichier attaché désactivé");
  //v0.7+
  define("CORE_LAN4", "Veuillez effacer le fichier install.php de votre serveur");
  define("CORE_LAN5", "si vous ne le faites pas, il y aura un risque de sécurité potentiel pour votre site web");
  ?>
