<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_membersonly.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Membres seulement"); 
  
  define("LAN_MEMBERS_0", "Zone d'accès restreinte, ");
  define("LAN_MEMBERS_1", "Ceci est une zone d'accès restreinte");
  define("LAN_MEMBERS_2","Pour y avoir accès  <a href='login.php'>connectez-vous </a> ou");
  define("LAN_MEMBERS_3","Enregistrez-vous comme un membre");
  define("LAN_MEMBERS_4","Cliquer ici pour revenir à la page principale");
  ?>
