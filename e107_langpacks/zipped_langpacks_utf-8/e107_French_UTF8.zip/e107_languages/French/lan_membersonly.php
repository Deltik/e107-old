<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_membersonly.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/27 14:43:41 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("PAGE_NAME", "Utilisateurs seulement");

  define("LAN_MEMBERS_0", "Zone d'accès restreinte ");
  define("LAN_MEMBERS_1", "Ceci est une zone d'accès restreinte");
  define("LAN_MEMBERS_2","Veuillez <a href='".e_LOGIN."'>vous connecter</a> pour obtenir l'accès");
  define("LAN_MEMBERS_3","ou <a href='".e_SIGNUP."'>enregistrez-vous</a> en tant que nouvel utilisateur");
  define("LAN_MEMBERS_4","Cliquer ici pour revenir à la page principale");
  ?>
