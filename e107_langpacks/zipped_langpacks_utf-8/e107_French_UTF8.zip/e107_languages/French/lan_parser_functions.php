<?php
  define("LAN_GUEST", "Visiteur"); 
  ?>
