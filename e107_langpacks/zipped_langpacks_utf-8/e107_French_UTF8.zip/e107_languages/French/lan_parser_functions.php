<?php
  define("LAN_GUEST", "Visiteur"); 
define("LAN_WROTE", "a écrit"); // as in John wrote.."  ";
  ?>
