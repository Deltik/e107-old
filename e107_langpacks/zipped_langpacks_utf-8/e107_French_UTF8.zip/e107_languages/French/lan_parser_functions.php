<?php
  define("LAN_GUEST", "Invité"); 
  ?>
