<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_rate.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/08 19:49:11 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
  define("RATELAN_0", "vote");
  define("RATELAN_1", "votes");
  define("RATELAN_2", "Comment évaluez-vous cet item?");
  define("RATELAN_3", "Merci pour votre évaluation");
  define("RATELAN_4", "non évalué");
  define("RATELAN_5", "Évaluer");
  ?>
