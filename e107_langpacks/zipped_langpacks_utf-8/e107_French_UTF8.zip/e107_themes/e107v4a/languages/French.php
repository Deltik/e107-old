<?php
  define("LAN_THEME_1", "Lire/poster Commentaires: ");
  define("LAN_THEME_2", "Commentaires désactivés");
  define("LAN_THEME_3", "Suite...");
  define("LAN_THEME_4", "Posté par ");
  define("LAN_THEME_5", "dans");
  define("LAN_THEME_6", "e107.v4 theme par <a href='http://e107.org' rel='external'>jalist</a>");
  ?>
