﻿<?php
  define("LAN_THEME_1", "'vekna blue' par <a href='http://e107.org' rel='external'>jalist</a>, basé sur, et avec permission de Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
  define("LAN_THEME_2", "Lire/poster Commentaires: ");
  define("LAN_THEME_3", "Commentaires désactivés");
  define("LAN_THEME_4", "Suite...");
  define("LAN_THEME_5", "Trackbacks: ");
  ?>
