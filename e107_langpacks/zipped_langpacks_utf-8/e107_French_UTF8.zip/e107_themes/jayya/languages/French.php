<?php
  define("LAN_THEME_1", "Commentaires désactivés");
  define("LAN_THEME_2", "Lire/poster Commentaires: ");
  define("LAN_THEME_3", "Suite...");
  define("LAN_THEME_4", "Trackbacks: ");
  define("LAN_THEME_5", "Posté par ");
  define("LAN_THEME_6", "");
  ?>
