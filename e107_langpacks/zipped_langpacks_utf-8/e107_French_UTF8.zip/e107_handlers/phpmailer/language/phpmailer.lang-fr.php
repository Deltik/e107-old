﻿<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/phpmailer/language/phpmailer.lang-fr.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/08 19:49:28 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG["provide_address"] = 'Vous devez proposer au moins ' . 'une addresse courriel.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailer non supporté.';
$PHPMAILER_LANG["execute"] = 'Ne peut pas executer: ';
$PHPMAILER_LANG["instantiate"] = 'Ne peut executer la fonction mail.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Erreur: Identification impossible.';
$PHPMAILER_LANG["from_failed"] = 'L\'adresse \'From\' est manquante: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Erreur: Les headers suivants manquent: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Erreur: Code non accepté.';
$PHPMAILER_LANG["connect_host"] = 'SMTP Erreur: Connexion impossible au serveur SMTP.';
$PHPMAILER_LANG["file_access"] = 'Impossible d\'accéder au fichier: ';
$PHPMAILER_LANG["file_open"] = 'FErreur: Impossible d\'ouvrir le fichier: ';
$PHPMAILER_LANG["encoding"] = 'Encodage inconnu: ';
  ?>
