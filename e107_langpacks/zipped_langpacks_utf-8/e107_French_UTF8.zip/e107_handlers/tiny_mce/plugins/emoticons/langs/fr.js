// Variable lang Fr

tinyMCELang['lang_insert_emotions_title'] = 'Ins&eacute;rer un smiley';
tinyMCELang['lang_emotions_desc'] = 'Smileys';

