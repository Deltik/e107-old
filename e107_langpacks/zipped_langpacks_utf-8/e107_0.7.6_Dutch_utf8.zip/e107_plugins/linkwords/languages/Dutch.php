<?php
	
define("LWLAN_1", "Veld(en) niet ingevuld.");
define("LWLAN_2", "Linkwoord opgeslagen.");
define("LWLAN_3", "Linkwoord bijgewerkt.");
define("LWLAN_4", "Nog geen linkwoorden gedefinieerd.");
define("LWLAN_5", "Woord");
define("LWLAN_6", "Link");
define("LWLAN_7", "Actief?");
define("LWLAN_8", "Opties");
define("LWLAN_9", "ja");
define("LWLAN_10", "nee");
define("LWLAN_11", "Aanwezige linkwoorden");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nee");
define("LWLAN_14", "Aanmelden linkwoord");
define("LWLAN_15", "Bijwerken linkwoord");
define("LWLAN_16", "Bewerken");
define("LWLAN_17", "Verwijderen");
define("LWLAN_18", "Weet je zeker dat je dit linkwoord wilt verwijderen?");
define("LWLAN_19", "Linkwoord verwijderd.");
define("LWLAN_20", "Kan linkwoord niet vinden.");
define("LWLAN_21","Woord om te autolinken");
define("LWLAN_22","Activeren?");
define("LWLANINS_1", "Linkwoorden");
define("LWLANINS_2", "Deze plugin maakt hyperlinks van aangegeven woorden");
define("LWLANINS_3", "Configureren LinkWoord");
define("LWLANINS_4", "Klik op de link in de pluginbeheer sectie om deze functie te configureren");

?>