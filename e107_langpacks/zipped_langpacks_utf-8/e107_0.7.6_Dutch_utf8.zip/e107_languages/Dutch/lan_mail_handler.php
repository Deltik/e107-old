<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        lan_mail_handler.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 13th Sep 2004
+---------------------------------------------------------------+
*/

define("LANMAILH_1", "Gecreëerd door het e107 website systeem");
define("LANMAILH_2", "Dit is een multi-part bericht in MIME formaat.");
define("LANMAILH_3", " is niet juist geformatteerd");
define("LANMAILH_4", "Door server geweigerd adres");
define("LANMAILH_5", "Geen antwoord van server");
define("LANMAILH_6", "Kan E-Mail server niet vinden.");
define("LANMAILH_7", " lijkt geldig.");


?>