<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        lan_userclass.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 14th Sep 2004
+---------------------------------------------------------------+
*/

define("UC_LAN_0", "Iedereen (openbaar)");
define("UC_LAN_1", "Alleen voor gasten");
define("UC_LAN_2", "Niemand (inactief)");
define("UC_LAN_3", "Alleen voor leden");
define("UC_LAN_4", "Alleen voor lezen");
define("UC_LAN_5", "Alleen voor beheer");
define("UC_LAN_6", "Hoofdbeheerder");

?>