<?php

if (!defined('e107_INIT')) { exit; }

$text = "De Voorkeuren functie laat je alle belangrijke instellingen van je site vastleggen. Dat varieert van bijvoorbeeld van de naam van je site tot de beveiligingsfuncties en het ongewenste woorden filter.";
$ns -> tablerender("Voorkeurenhulp", $text);
?>