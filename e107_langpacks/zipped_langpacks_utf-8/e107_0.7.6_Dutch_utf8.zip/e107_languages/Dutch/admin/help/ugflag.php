<?php

if (!defined('e107_INIT')) { exit; }

$text = "Als je e107 upgrade, of als je site even uit de lucht moet, kruis dan de onderhoudsvlag aan en je bezoekers worden geleid naar een pagina waarin wordt uitgelegd dat de site even uit de lucht is voor onderhoudswerkzaamheden. Als je klaar bent, kruis het vakje uit om de site weer beschikbaar te stellen.";

$ns -> tablerender("Onderhoud hulp", $text);
?>