<?php

if (!defined('e107_INIT')) { exit; }

$text = "Het instellen van een nieuwe taal geeft je de mogelijkheid om alle content op je site ook in die taal aan te bieden.";
$ns -> tablerender("Taalhulp", $text);
?>