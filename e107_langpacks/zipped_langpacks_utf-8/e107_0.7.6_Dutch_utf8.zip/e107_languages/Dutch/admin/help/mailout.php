<?php

if (!defined('e107_INIT')) { exit; }

$text = "Gebruik deze pagina om de algemene mailinstellingen voor je site regelen. Je kunt met het formulier ook direct een mailing naar al je leden te verzorgen.";
$ns -> tablerender("Mail help", $text);
?>