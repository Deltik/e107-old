<?php

if (!defined('e107_INIT')) { exit; }

$text = "Wijzig hier je naam, e-mailadres en wachtwoord.";
$ns -> tablerender("Bijwerken instellingen Hulp", $text);
?>