<?php

if (!defined('e107_INIT')) { exit; }

$caption = "Menu Hulp";
$text .= "Je kunt hiermee bepalen waar en in welke volgorde je menublokken worden getoond. Gebruik de pijltjes om de menu's op en neer te verplaatsen totdat je tevreden bent met de plek.<br />
De menu's midden in het scherm zijn niet geactiveerd, je kunt ze activeren door een menuzone te selecteren.
";

$ns -> tablerender("Menu Hulp", $text);
?>