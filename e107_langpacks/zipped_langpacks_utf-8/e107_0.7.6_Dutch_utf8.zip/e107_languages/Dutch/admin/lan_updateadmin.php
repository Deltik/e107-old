<?php

define("UDALAN_1", "Fout - voer nogmaals op");
define("UDALAN_2", "Instellingen bijgewerkt");
define("UDALAN_3", "Instellingen bijgewerkt voor");
define("UDALAN_4", "Naam");
define("UDALAN_5", "Wachtwoord");
define("UDALAN_6", "Nogmaals wachtwoord");
define("UDALAN_7", "Wijzig wachtwoord");
define("UDALAN_8", "Wachtwoord wijzigen voor");

?>