<?php

define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Hoofdbeheerder");
define("FOOTLAN_3", "Versie");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Theme");
define("FOOTLAN_6", "door");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installatiedatum");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "systeem");
define("FOOTLAN_11", "PHP Versie");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Site Info");
define("FOOTLAN_14", "Toon Docs");
define("FOOTLAN_15", "Documentatie");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Charset");
?>
