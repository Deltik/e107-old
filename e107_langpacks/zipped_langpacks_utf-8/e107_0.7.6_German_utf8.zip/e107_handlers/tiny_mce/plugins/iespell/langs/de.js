﻿// DE lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Rechtschreibprüfung starten.',
iespell_download : "ieSpell wurde nicht gefunden. Klick auf OK zum anzeigen der Downloadseite."
});

