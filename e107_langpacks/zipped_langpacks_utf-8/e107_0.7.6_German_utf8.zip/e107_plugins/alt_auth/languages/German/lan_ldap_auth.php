<?php
define("LDAPLAN_1", "Server Adresse");
define("LDAPLAN_2", "Basis DN oder Domain<br />Falls LDAP - Bitte BasisDN eingeben<br />Falls AD - Bitte Domain eingeben");
define("LDAPLAN_3", "LDAP Benutzer<br />Vollständiger Kontext des Benutzers, der diese Verzeichnis durchsuchen kann.");
define("LDAPLAN_4", "LDAP Passwort<br />Passwort für den LDAP Benutzer.");
define("LDAPLAN_5", "LDAP Version");
define("LDAPLAN_6", "LDAP auth konfigurieren");

define("LDAPLAN_7", "eDirectory Suchfilter:");
define("LDAPLAN_8", "Dies dient dazu um sicher zu gehen dass der Benutzername in der richtigen Baumstruktur ist, <br />z.B '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Der momentane Suchfilter wird sein:");

define("LDAPLAN_10", "Einstellungen aktualisiert");
define("LDAPLAN_11", "WARNUNG: Das ldap Module scheint momentan nicht verfügbar zu sein. Es kann sein das deswegen die Umstellung auf LDAP nicht funktionieren wird!");
define("LDAPLAN_12", "Server Typ");
define("LDAPLAN_13", "Einstellungen aktualisieren");

?>
