<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/German/lan_forum_conf.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:52:49 $
|     $Author: streaky $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("FORLAN_5", "Umfrage gelöscht.");
define("FORLAN_6", "Thread gelöscht");
define("FORLAN_7", "Antworten gelöscht");
define("FORLAN_8", "Löschen aufgehoben.");
define("FORLAN_9", "Thread verschoben.");
define("FORLAN_10", "Verschieben aufgehoben");
define("FORLAN_11", "Zurück zu den Foren");
define("FORLAN_12", "Forum Konfiguration");
define("FORLAN_13", "Sind Sie absolut sicher diese Umfrage löschen zu wollen?<br />Einmal gelöscht <b><u>kann sie nicht wieder</u></b> hergestellt werden");
define("FORLAN_14", "Aufheben");
define("FORLAN_15", "Bestätigung den Foreneintrag löschen zu wollen");
define("FORLAN_16", "Bestätigung die Umfrage löschen zu wollen");
define("FORLAN_17", "geschrieben von");
define("FORLAN_18", "Sind Sie absolut sicher diesen Foren-Thread löschen zu wollen");
define("FORLAN_19", "und die zugehörigen Einträge?");
define("FORLAN_20", "Die Umfrage wird dann auch gelöscht");
define("FORLAN_21", "einmal gelöscht");
define("FORLAN_22", "Eintrag?<br /> Einaml gelöscht");
define("FORLAN_23", "<b><u>kann es nicht wieder</u></b> hergestellt werden.");
define("FORLAN_24", "Verschiebe den Thread zum Forum");
define("FORLAN_25", "Verschiebe den Thread");
define("FORLAN_26", "Antwort gelöscht");
define("FORLAN_27", "verschoben");

define("FORLAN_28", "Threadnamen nicht umbenennen");
define("FORLAN_29", "Hinzufügen");
define("FORLAN_30", "zum Titel");
define("FORLAN_31", "Umbenennen nach:");
define("FORLAN_32", "Threadoptionen umbenennen:");


?>
