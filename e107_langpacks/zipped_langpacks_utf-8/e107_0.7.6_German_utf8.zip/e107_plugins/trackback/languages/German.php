<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/German.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/22 18:20:52 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "Trackback konfigurieren");
define("TRACKBACK_L2", "Dieses Plugin erlaubt Ihnen Trackback in Ihren Newsposts zu verwenden.");
define("TRACKBACK_L3", "Trackback ist installiert und freigeschalten.");
define("TRACKBACK_L4", "Trackback Einstellunhen gespeichert.");
define("TRACKBACK_L5", "An");
define("TRACKBACK_L6", "Aus");
define("TRACKBACK_L7", "Trackback aktivieren");
define("TRACKBACK_L8", "Trackback URL Text");
define("TRACKBACK_L9", "Einstellungen speichern");
define("TRACKBACK_L10", "Trackback Einstellungen");
define("TRACKBACK_L11", "Trackback Adresse fr diesen Eintrag:");

define("TRACKBACK_L12", "Keine Trackbacks fr diesen Eintrag");
define("TRACKBACK_L13", "Trackbacks moderieren");
define("TRACKBACK_L14", "Lschen");
define("TRACKBACK_L15", "Trackbacks gelscht.");

?>
