<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsfeed/languages/English_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/07 20:56:04 $
|     $Author: sweetas $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "News Einspeisungen");
define("NWSF_FP_2", "Hauptseite");

?>
