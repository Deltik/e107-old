<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsletter/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/05/25 17:23:35 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.vom (http://www.cms-myway.com)
+----------------------------------------------------------------------------+
*/

define("NLLAN_MENU_CAPTION", "Newsletter");

define("NLLAN_01", "Newsletter");
define("NLLAN_02", "Ein einfacher Weg um Newsletter zu konfigurieren und zu senden");
define("NLLAN_03", "Newsletters konfigurieren");
define("NLLAN_04", "Das Newsletter Plugin wurde erfolgreich installiert. Um es zu konfigurieren, gehen Sie bitte auf die Administrations Hauptseite und klicken Sie auf Newsletter.");
define("NLLAN_05", "Keine Newsletter bis jetzt angelegt");

define("NLLAN_06", "Name");
define("NLLAN_07", "Abonnenten");
define("NLLAN_08", "Optionen");
define("NLLAN_09", "Sind Sie sicher diesen Newsletter löschen zu wollen?");
define("NLLAN_10", "Bestehende Newsletter");

define("NLLAN_11", "Keine Newsletter Sendungen bis jetzt");
define("NLLAN_12", "Sendungen");
define("NLLAN_13", "[ Haupt ID ] Betreff/Titel");
define("NLLAN_14", "Gesendet?");
define("NLLAN_15", "Optionen");
define("NLLAN_16", "Ja");
define("NLLAN_17", "Nicht gesendet - klicken Sie hier um zu verschicken");
define("NLLAN_18", "Sind Sie sicher diese Sendung verschicken zu wollen?");
define("NLLAN_19", "Sind Sie sicher diese Newsletter Sendung löschen zu wollen?");
define("NLLAN_20", "Bestehende Sendungen");
define("NLLAN_21", "Titel");
define("NLLAN_22", "Beschreibung");
define("NLLAN_23", "Kopf");
define("NLLAN_24", "Fuss");
define("NLLAN_25", "Newsletter aktualisieren");
define("NLLAN_26", "Newsletter erstellen");
define("NLLAN_27", "Newsletter in Datenbank aktualisiert.");
define("NLLAN_28", "Newsletter erstellt und in Datenbank gespeichert.");
define("NLLAN_29", "Keine Newsletter bis jetzt erstellt.");
define("NLLAN_30", "Newsletter");
define("NLLAN_31", "Betreff / Titel");
define("NLLAN_32", "Issue Number");
define("NLLAN_33", "Text");
define("NLLAN_34", "Sendung aktualisieren");
define("NLLAN_35", "Sendung erstellen");
define("NLLAN_36", "Newsletter Sendung aktualisieren");
define("NLLAN_37", "Newsletter Sendung erstellen");
define("NLLAN_38", "Newsletter in Datenbank aktualisiert.");
define("NLLAN_39", "Newsletter Sendung in Datenbank gespeichert - um sie zu verschicken, klicken Sie bitte den 'Verschicke Sendung' Button im Optionsmenü.");
define("NLLAN_40", "Versendung komplett - Sendung verschickt an ");

define("NLLAN_41", " Anmeldung(en).");
define("NLLAN_42", "Newsletter gelöscht.");
define("NLLAN_43", "Newsletter issue deleted.");

define("NLLAN_44", "Newsletter Erste Seite");
define("NLLAN_45", "Newsletter erstellen");
define("NLLAN_46", "Sendung erstellen");
define("NLLAN_47", "Newsletter Optionen");

define("NLLAN_48", "Sie haben sich für diesen Newsletter angemeldet - falls Sie sich abmelden wollen, klicken Sie folgenden Button.");
define("NLLAN_49", "Sind Sie sicher sich von diesem Newsletter abmelden zu wollen?");
define("NLLAN_50", "Klicken Sie den Button um sich anzumelden ( Ihre Anmeldeadresse ist");
define("NLLAN_51", "Abmelden");
define("NLLAN_52", "Anmelden");
define("NLLAN_53", "Sind Sie sicher, sich für diesen Newsletter anmelden zu wollen?");
define("NLLAN_54", "wird gesendet");




?>
