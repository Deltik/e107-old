<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_equery_secure.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("EQSEC_LAN1", "Sie wurden zu einer Administrationsfunktion weitergeleitet. Mögliche Ursache könnte eine Veränderung in der Datenbank sein.");
define("EQSEC_LAN2", "Bitte bestätigen Sie diese Aktion:");
define("EQSEC_LAN3", "Kein Referer");
define("EQSEC_LAN4", "Aktion von");
define("EQSEC_LAN5", "Aktion zu");
define("EQSEC_LAN6", "Aktion bestätigen");
define("EQSEC_LAN7", "Oder löschen");


?>
