<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/03 15:57:25 $
|     $Author: mcfly_e107 $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Schicke E-Mail Benachrichtigung an");
define("UCSLAN_2", "Privilegien aktualisiert");
define("UCSLAN_3", "Hallo ");
define("UCSLAN_4", "Ihre Privilegien wurden aktualisiert");
define("UCSLAN_5", "Sie haben nun Zugriff auf die folgenden Bereiche");
define("UCSLAN_6", "Klasse für Benutzer festlegen");
define("UCSLAN_7", "Klassen festlegen");
define("UCSLAN_8", "Benutzer benachrichtigen");
define("UCSLAN_9", "Klassen aktualisiert.");
define("UCSLAN_10", "Glückwunsch");

?>
