<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_menus.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/04/05 07:13:47 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("MENLAN_1", "Sichtbar für alle");
define("MENLAN_2", "Nur sichtbar für Mitglieder");
define("MENLAN_3", "Nur sichtbar für Administratoren");
define("MENLAN_4", "Nur sichtbar für Benutzer in ");
//define("MENLAN_5", "Klasse");
define("MENLAN_6", "Menü-Klasse aktualisieren");
define("MENLAN_7", "Klasse einstellen für");
define("MENLAN_8", "Klasse aktualisiert");
define("MENLAN_9", "Neues Spezialmenü installiert");
define("MENLAN_10", "Neues Menü installiert");
define("MENLAN_11", "Menü entfernt");
define("MENLAN_12", "Dieses Menü aktivieren - bitte wählen Sie einen Ort");
define("MENLAN_13", "Aktivieren im Bereich");
define("MENLAN_14", "Bereich");
define("MENLAN_15", "Deaktivieren");
define("MENLAN_16", "Konfigurieren");
define("MENLAN_17", "Nach oben");
define("MENLAN_18", "Nach unten");
define("MENLAN_19", "Verschieben zum Bereich");
define("MENLAN_20", "Sichtbarkeit");
//define("MENLAN_21", "Nur für Gäste sichtbar");
define("MENLAN_22", "Inaktive Menus");
define("MENLAN_23", "Verschiebe nach unten");
define("MENLAN_24", "Verschiebe nach oben");
define("MENLAN_25", "Funktion ...");
define("MENLAN_26", "Diese Menü wird <strong>angezeigt</strong> auf den folgenden Seiten.");
define("MENLAN_27", "Diese Menü wird <strong>versteckt</strong> auf den folgenden Seiten.");
define("MENLAN_28", "Geben Sie eine Seite pro Zeile ein. Achten Sie darauf die Url ausreichend/stimmig einzugeben für Funktionsgarantie.");

define("MENLAN_29", "Layout wählen");
define("MENLAN_30", "Um die Menü-Bereiche und deren Positionen für Benutzer-Layouts zu sehen, wählen Sie das Benutzer-Layout hier:");
define("MENLAN_31", "Gesetztes Layout");
define("MENLAN_32", "Newskopf Layout");
define("MENLAN_33", "Benutzer Layout");
define("MENLAN_34", "Eingebettet");
define("MENLAN_35", "Menüs konfigurieren");
define("MENLAN_36", "Wählen Sie das Menü um es zu aktivieren");
define("MENLAN_37", "danach wählen Sie bitte den Ort wo das Menü erscheinen soll.");
define("MENLAN_38", "AltGr gedrückt halten um mehrere Menüs zu wählen.");


?>
