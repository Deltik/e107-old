<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_image.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 19:14:19 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("IMALAN_1", "Erlaube Bilder zu posten");
define("IMALAN_2", "Zeige Bilder an, - dies wird sich auf die komplette Seite auswirken (Kommentare, Chatbox etc)");
define("IMALAN_3", "Bild Komprimierungs Modus");
define("IMALAN_4", "Methode wie die Bilder komprimiert werden, entweder GD1/2 Library, oder ImageMagick");
define("IMALAN_5", "Pfad zu ImageMagick (falls ausgewählt)");
define("IMALAN_6", "Absoluter Pfad zum ImageMagick Komprimierungs Tool");
define("IMALAN_7", "Bild Einstellungen");
define("IMALAN_8", "Aktualisiere Bild Einstellungen");
define("IMALAN_9", "Bild Angaben aktualisiert");
define("IMALAN_10", "Bild Posting User-Klassen");
define("IMALAN_11", "Erlaube es nur bestimmten Usern Bilder zu posten (falls oben erlaubt)");
define("IMALAN_12", "Unerlaubte Bild Methode");
define("IMALAN_13", "Zeigt was mit Bildern gemacht werden soll wenn Bild Posting nicht erlaubt ist");
define("IMALAN_14", "Zeige Bild URL");
define("IMALAN_15", "Zeige nichts");
define("IMALAN_16", "Zeige hochgeladene Avatare");
define("IMALAN_17", "Hier klicken");
define("IMALAN_18", "Hochgeladene Bilder");

define("IMALAN_21", "Gebraucht von");
define("IMALAN_22", "Bild ist nicht in Gebrauch");
define("IMALAN_23", "Avatar");
define("IMALAN_24", "Foto");
define("IMALAN_25", "Klicke hier um alle nicht in Gebrauch befindlichen Bilder zu löschen");
define("IMALAN_26", "gelöschte Bilder");

define("IMALAN_28", "gelöscht");
define("IMALAN_29", "Keine Bilder");
define("IMALAN_30", "Jederman (öffentlich)");
define("IMALAN_31", "Nur Gäste");
define("IMALAN_32", "Nur Mitglieder");
define("IMALAN_33", "Nur Admin");
define("IMALAN_34", "Sleight freischalten");
define("IMALAN_35", "TransparentE PNG-24's werden gefixt mit Alpha Transparenz im IE 5 / 6 (Wirkt sich auf der ganzen Seite aus)");

define("IMALAN_36", "Avatargrösse und Zugriff validieren");
define("IMALAN_37", "Avatar Validierung");
define("IMALAN_38", "Maximal erlaubte Breite");
define("IMALAN_39", "Maximal erlaubte Höhe");
define("IMALAN_40", "zu breit");
define("IMALAN_41", "zu hoch");
define("IMALAN_42", "Nicht gefunden");
define("IMALAN_43", "Hochgeladenen Avatar löschen");
define("IMALAN_44", "Externe Referenz löschen");
define("IMALAN_45", "Nicht gefunden");
define("IMALAN_46", "Zu gross");
define("IMALAN_47", "Alle hochgeladenen Avatare");
define("IMALAN_48", "Alle externen Avatare");
define("IMALAN_49", "Benutzer mit Avataren");
define("IMALAN_50", "Insgesamt");
define("IMALAN_51", "Avatar für ");

?>
