<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_db_verify.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 18:29:48 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/

define("DBLAN_1", "Die SQL Datei kann nicht gelesen werden<br /><br />Bitte stellen Sie sicher dass; die Datei <b>core_sql.php</b> in dem  <b>/admin/sql</b> Verzeichnis existiert.");
define("DBLAN_2", "Alles überprüfen");

define("DBLAN_4", "Tabelle");
define("DBLAN_5", "Feld");
define("DBLAN_6", "Status");
define("DBLAN_7", "Anmerkungen");
define("DBLAN_8", "Falsche Zuordnung");
define("DBLAN_9", "Momentan");
define("DBLAN_10", "sollte sein");
define("DBLAN_11", "fehlendes Feld");
define("DBLAN_12", "Extra Feld!");
define("DBLAN_13", "Tabelle fehlt!");
define("DBLAN_14", "Zu prüfende(n) Tabelle(n) auswählen");
define("DBLAN_15", "Überprüfung starten");
define("DBLAN_16", "SQL Überprüfung - Version");
define("DBLAN_17", "Zurück");
define("DBLAN_18", "Tabellen");
define("DBLAN_19", "Versuch zu korrigieren");
define("DBLAN_20", "Versuch Tabellen zu korrigieren");
define("DBLAN_21", "Korrigiere ausgewähle Items");


?>
