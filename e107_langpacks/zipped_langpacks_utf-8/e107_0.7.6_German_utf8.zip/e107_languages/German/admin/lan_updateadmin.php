<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Fehler - bitte erneut übertragen");
define("UDALAN_2", "Einstellungen aktualisiert");
define("UDALAN_3", "Einstellungen aktualisiert für");
define("UDALAN_4", "Name");
define("UDALAN_5", "Passwort");
define("UDALAN_6", "Passwort wiederholen");
define("UDALAN_7", "Passwort ändern");
define("UDALAN_8", "Passwort Aktualisierung für");

?>
