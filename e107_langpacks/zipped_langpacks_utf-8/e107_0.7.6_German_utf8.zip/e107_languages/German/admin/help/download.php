<?php
$text = "Bitte laden Sie die Dateien zum Download in den Ordner ".e_FILE."downloads und die Bilder zum Download in den Ordner ".e_FILE."downloadimages und die Vorschaubilder (Thumbnails) in den Ordner ".e_FILE."downloadthumbs.
<br /><br />
Um ein Download einzustellen, m&ussen Sie zuerst eine Hauptkategorie erstellen, zB Fotos. Dann erstellen Sie eine oder meherer Unterkategorien, wie zB JPEG-Bilder, TIFF-Bilder usw. In diese Unterkategorien können Sie dann über 'Download erstellen' Ihre Downloads zur Verfügung stellen.";
$ns -> tablerender("Download Hilfe", $text);
?>
