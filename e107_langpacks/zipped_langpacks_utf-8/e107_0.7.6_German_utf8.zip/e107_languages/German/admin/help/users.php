<?php
$text = "Hier moderieren Sie die registrierten Benutzer. Sie Können ihre Einstellungen aktualisieren, ihnen Admin rechte zuteilen, und Ihre Benutzerklassen bearbeiten.
";
$ns -> tablerender("Benutzer Hilfe", $text);
unset($text);
?>
