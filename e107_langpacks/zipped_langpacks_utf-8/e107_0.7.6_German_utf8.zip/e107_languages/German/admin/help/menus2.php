<?php
$caption = "Menü Hilfe";
$text .= "Sie können über diesen Schirm Ort und Reihenfolge Ihrer anzuzeigenden Menüs arrangieren. Benutzen Sie die Pfeile, um die Menüs auf- und abwärts zu bewegen, solange, bis Sie mit der Einstellung zufrieden sind.
<br />
Die Menü Elemente in der Mitte des Bildschirms sind deaktiviert! Sie aktivieren diese, indem Sie die Platzierung wählen (zB Beriech 1, 2, 3 usw.).";

$ns -> tablerender("Menus Hilfe", $text);
?>
