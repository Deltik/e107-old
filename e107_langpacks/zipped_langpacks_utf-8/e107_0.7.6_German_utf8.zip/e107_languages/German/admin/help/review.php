<?php
$text = "Berichet sind vergleichbar mit Artikeln, sie werden aber in einem eigenen Menüelement erfasst.<br />
Für einen mehrseitigen Bericht geben Sie für einen Seitenumbruch das Tag '[newpage]' ein. Sie können ebefalls Berichtkategorien festelgen. Vergleichn Sie dazu die Hinweise unter Artikel Hilfe.";
$ns -> tablerender("Berichte Hilfe", $text);
?>
