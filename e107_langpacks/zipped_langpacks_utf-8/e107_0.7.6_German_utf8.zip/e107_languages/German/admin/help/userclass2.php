<?php
$caption = "Benutzerklassen Hilfe";
$text = "Sie önnen Benutzerklassen editieren, erstellen und Louml;schen. <br /> Dieser Bereich ist hilfreich für die Zugangsbeschräkung für bestimmte Nutzzer Ihrer Website. Hilfreich ist es, wenn Sie eine Klasse ADMIN anlegen. Diese Klasse können Sie dann nur für sich freischalten. Das ist hilfreich, wenn Sie Berichte, news, Artikel oder Content erstellen und das Layout auf der Seite im Original sehen wollen oder, wenn Sie Ihre Artikel über einen längeren Zeitraum bearbeiten.<br /><br />
Das Gleiche machen Sie dann für die Nutzer, die Sie in bestimmte Bereich lassne möchten. Bitte achten Sie darauf, dass Sie den Klassen auch die benutzer zuweisen. <br /><br />
TIPP:<br />
Löschen Sie möglichst NIE eine ganze Klasse, wenn Sie nicht ABSOLUT sicher sind! Es gibt KEINE Möglichkeit einmal gelöschte Klassen wieder herzustellen!";
$ns -> tablerender($caption, $text);
?>
