<?php
$caption = "Hauptseiten Administrator - Hilfe";
$text = "Benutzen Sie diese Seite, um neue Administratoren anzulegen, zu ändern oder zu löschen. Der Administrator hat nur zu denen von Ihnen zugeteilten Rechten bzw. Menüs zugang. Aktivieren Sie dazu die entsprechende Checkbox.";
$ns -> tablerender($caption, $text);
?>
