<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/admin/lan_emoticon.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/05/14 02:39:38 $
|     $Author: sweetas $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Smilie Aktivierung");
define("EMOLAN_2", "Name");
define("EMOLAN_3", "Smilies");
define("EMOLAN_4", "Smilies aktivieren?");

define("EMOLAN_5", "Bild");
define("EMOLAN_6", "Smilie Code");
define("EMOLAN_7", "Mehrfache Eingaben mit Leerstellen trennen");

define("EMOLAN_8", "Status");
define("EMOLAN_9", "Optionen");
define("EMOLAN_10", "Aktiv");
define("EMOLAN_11", "Packung aktivieren'");

define("EMOLAN_12", "Diese Packung Bearbeiten / Konfigurieren");
define("EMOLAN_13", "Installierte Packungen");

define("EMOLAN_14", "Konfiguration speichern");
define("EMOLAN_15", "Bearbeite / Konfiguriere Smilies");
define("EMOLAN_16", "Smilie Konfiguration gespeichert");
define("EMOLAN_17", "Sie verwenden im Moment ein Smiliepaket welches Leerzeichen beinhaltet, die nicht erlaubt sind !");
define("EMOLAN_18", "Korrigieren Sie bitte unten aufgeführte Liste, sodass keine Leerstellen mehr vorhanden sind:");
define("EMOLAN_19", "Name");
define("EMOLAN_20", "Ort");
define("EMOLAN_21", "Fehler");
//define("EMOLAN_2", "Name");

?>
