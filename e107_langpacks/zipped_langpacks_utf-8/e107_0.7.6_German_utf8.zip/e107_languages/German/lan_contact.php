<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/24 21:42:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Kontakt Details");
define("LANCONTACT_02", "Kontaktformular");
define("LANCONTACT_03", "Benutzername:");
define("LANCONTACT_04", "E-mail Adresse:");
define("LANCONTACT_05", "Betreff:");
define("LANCONTACT_06", "Nachricht:");
define("LANCONTACT_07", "Eine Kopie der Nachricht an Ihre E-Mail senden lassen ");
define("LANCONTACT_08", "Senden");
define("LANCONTACT_09", "Ihre Nachricht wurde versand.");
define("LANCONTACT_10", "Es gab ein Problem beim versenden Ihrer Nachricht.");
define("LANCONTACT_11", "Ihre E-Mail Adresse scheint nicht gültig zu sein.\\nBitte überprüfen Sie diese und versuchen es erneut.");
define("LANCONTACT_12", "Ihre Nachricht ist zu kurz.");
define("LANCONTACT_13", "Bitte fügen Sie einen Betreff ein."); 
define("LANCONTACT_14", "Nachricht senden an:");
define("LANCONTACT_15", "Falscher Code eingegeben");
define("LANCONTACT_16", "Code eingeben");



?>
