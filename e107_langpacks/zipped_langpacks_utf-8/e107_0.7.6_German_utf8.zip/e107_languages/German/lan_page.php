<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/28 23:02:59 $
|     $Author: whoisrich $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Seitenauflistung ist abgestellt");
define("LAN_PAGE_2", "Es gibt keine Seiten");
define("LAN_PAGE_3", "Angeforderte Seite besteht nicht");
define("LAN_PAGE_4", "Bewerten Sie diese Seite");
define("LAN_PAGE_5", "Danke für das Bewerten dieser Seite");
define("LAN_PAGE_6", "Sie haben keine Berechtigung diese Seite anzusehen");
define("LAN_PAGE_7", "Falsches Passwort");
define("LAN_PAGE_8", "Passwortgeschützte Seite");
define("LAN_PAGE_9", "Passwort");
define("LAN_PAGE_10", "Übermitteln");
define("LAN_PAGE_11", "Seiten Auflistung");
define("LAN_PAGE_12", "Ungültige Seite");
define("LAN_PAGE_13", "Seite");
?>
