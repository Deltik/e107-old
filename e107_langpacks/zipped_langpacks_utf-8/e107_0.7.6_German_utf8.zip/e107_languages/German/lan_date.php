<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/German/lan_date.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/09 12:59:25 $
|     $Author: stevedunstan $
|     $translated by: admin@cms-myway.com (http://www.cms-myway.com) $
|     $ UTF-8 encoded $
+----------------------------------------------------------------------------+
*/


define("LANDT_01", "Jahr");
define("LANDT_02", "Monat");
define("LANDT_03", "Woche");
define("LANDT_04", "Tag");
define("LANDT_05", "Stunde");
define("LANDT_06", "Minute");
define("LANDT_07", "Sekunde");
define("LANDT_01s", "Jahre");
define("LANDT_02s", "Monate");
define("LANDT_03s", "Wochen");
define("LANDT_04s", "Tage");
define("LANDT_05s", "Stunden");
define("LANDT_06s", "Minuten");
define("LANDT_07s", "Sekunden");
define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "sek");
define("LANDT_09s", "seks");
define("LANDT_AGO", "her");


?>
