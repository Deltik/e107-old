<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LANUPLOAD_1", "A fájltípus");
define("LANUPLOAD_2", "nem engedélyezett, törölve lett.");
define("LANUPLOAD_3", "Sikeresen feltöltve");
define("LANUPLOAD_4", "A célkönyvtár nem létezik, vagy nem írható.");
define("LANUPLOAD_5", "A file túllépte a php.ini -ben meghatározott maximális méretet.");
define("LANUPLOAD_6", "A file túllépte a HTML formulában meghatározott maximális méretet.");
define("LANUPLOAD_7", "A file csak részben lett feltöltve.");
define("LANUPLOAD_8", "Nem lett semmi feltöltve.");
define("LANUPLOAD_9", "Feltöltött fileméret: 0 byte");
define("LANUPLOAD_10", "A feltöltés nem sikerült [Duplikált fájlnév] - Már van ilyen nevű fájl.");
define("LANUPLOAD_11", "A fájl nem lett feltöltve. Fájlnév: ");
define("LANUPLOAD_12", "Hiba");

?>