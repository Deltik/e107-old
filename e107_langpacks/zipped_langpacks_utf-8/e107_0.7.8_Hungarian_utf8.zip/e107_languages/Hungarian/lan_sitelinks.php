<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_SITELINKS_183", "Főmenü");
define("LAN_SITELINKS_502", "Admin terület");

?>
