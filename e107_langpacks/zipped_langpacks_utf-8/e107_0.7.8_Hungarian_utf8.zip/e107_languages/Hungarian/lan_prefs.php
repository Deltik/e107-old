<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_PREF_1", "e107 alapú weboldal");

define("LAN_PREF_2", "e107 portál rendszer");

define("LAN_PREF_3", "Ez az oldal <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107 portál</a> rendszert használ, és a <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL licensz alatt lett kiadva</a>.");

define("LAN_PREF_4", "cenzúrázva");

define("LAN_PREF_5", "Fórumok");

?>