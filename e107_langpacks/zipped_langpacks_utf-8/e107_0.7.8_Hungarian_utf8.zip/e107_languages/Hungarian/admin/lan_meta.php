<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("METLAN_1", "Meta tag-ek frissítve");
define("METLAN_2", "Meta tag-ek");
define("METLAN_3", "Beállítások mentése");
define("METLAN_4", "Frissítve");
define("METLAN_5", "Az oldal leírását");
define("METLAN_6", "Add, meg, a, kulcsszavak, listáját, kulcsszó, vessző, szóköz, formában");
define("METLAN_7", "Copyright információk");
define("METLAN_8", "Meta Tag-ek");

define("METLAN_9", "Leírás");
define("METLAN_10", "Kulcsszavak");
define("METLAN_11", "Szerzői jog");
define("METLAN_12", "Használd a Hírek címét és az összegzést meta-leírásként a hírek oldalon.");
define("METLAN_13", "Szerző");
?>
