<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_head_1", "Admin Navigáció");
define("LAN_head_2", "A szervered nem engedi a HTTP alapú filefeltöltést, ennélfogva felhasználóid nem tudnak avatart/fájlokat feltölteni. Ezen állapot megszüntetéséhez engedélyezd a file_uploads opciót a php.ini -ben és indítsd újra a szervert. Ha nincs jogosultságod a php.ini eléréséhez, lépj kapcsolatba a szerver adminisztrátorával.");
define("LAN_head_3", "A szerver basedir korlátozással fut. Emiatt nem tudsz elérni semmilyen fájlt a saját könyvtárodon kívül. Ez bezavarhat néhány olyan szkriptnek, mint a fájlkezelő.");

define("LAN_head_4", "Admin terület");

define("LAN_head_5", "az adminterület nyelve: ");
define("LAN_head_6", "Plugin info");

?>