<?php
$caption = "Szavazások súgó";
$text = "Itt a szavazás beállítására van lehetőség. Add meg a kérdést, válaszokat, majd aktiváld a szavazást, ha az előnézet során elégedett voltál az eredménnyel.<br /><br /><b>Vigyázz! Az előnézetben lévő 'Mehet' gomb nem aktív, a szavazás rögzítéséhez görgesd lejjebb az oldalt, és ott a 'Szavazás felvétele' gombbal tudod rögzíteni az új szavazást.</b><br />
Hogy a szavazás látható legyen, ellenőrizd, hogy be van-e kapcsolva a szavazás megjelenítése a Menü alpont alatt.";

$ns -> tablerender($caption, $text);
?>
