<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Hungarian Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hungarian/admin/lan_footer.php,v $
|     $Revision: 1.5 $
|     $Date: 2007/02/17 00:27:27 $
|     $Author: e107hun-lac $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Weboldal");
define("FOOTLAN_2", "Fő admin");
define("FOOTLAN_3", "Verzió");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Theme");
define("FOOTLAN_6", "-");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Telepítés dátuma");
define("FOOTLAN_9", "Szerver");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "PHP verzió");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Weboldal Info");
define("FOOTLAN_14", "Dokumentáció megtekintése");
define("FOOTLAN_15", "Dokumentáció");
define("FOOTLAN_16", "Adatbázis");
define("FOOTLAN_17", "Karakterkészlet");
define("FOOTLAN_18", "Oldal Theme");
?>
