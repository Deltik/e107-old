<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Hungarian Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hungarian/admin/lan_banlist.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/29 22:34:00 $
|     $Author: e107hun-lac $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Kitiltás kikapcsolva.");
define("BANLAN_2", "Nincs kitiltás.");
define("BANLAN_3", "Érvényben lévő kitiltások");
define("BANLAN_4", "Kitiltás törlése");
define("BANLAN_5", "Add meg az IP címet, az e-mail címet vagy a host-ot");
define("BANLAN_7", "Indoklás");
define("BANLAN_8", "IP cím kitiltása");
define("BANLAN_9", "Felhasználók kitiltása az oldalról email, IP cím, vagy hoszt megadásával");
define("BANLAN_10", "IP / E-mail cím / Indok");
define("BANLAN_11", "Automatikus-Kitiltás: Több, mint 10 hibás bejelentkezési kisérlet");
define("BANLAN_12", "Megjegyzés: A DNS megváltoztatása jelenleg letiltva, a host alapján történő kitiltáshoz engedélyezni kell. Az IP és email alapján történő kitiltás még normálisan műkődik.");
define("BANLAN_13", "Megjegyzés: Felhasználó a felhasználónév általi kitiltását a Felhasználók adminisztrációs felületén tudod megtenni: ");
?>
