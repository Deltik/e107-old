<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FRTLAN_1", "Kezdőlap beállításai frissítve");
define("FRTLAN_2", "Megjelenítendő");
define("FRTLAN_6", "Linkek");
//define("FRTLAN_7", "Tartalom oldal");
define("FRTLAN_12", "Beállítások mentése");
define("FRTLAN_13", "Kezdőlap beállításai");
define("FRTLAN_15", "Egyéb (írd be az url-t):");
define("FRTLAN_16", "hiba: nincs tartalom főkategória kiválasztva");
define("FRTLAN_17", "hiba: nincs tartalom alkategória kiválasztva");
define("FRTLAN_18", "hiba: nincs tartalom kiválasztva");
define("FRTLAN_19", "tartalom főkategória");
define("FRTLAN_20", "tartalom alkategória");
define("FRTLAN_21", "tartalom");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Mindenki");
define("FRTLAN_27", "Vendégek");
define("FRTLAN_28", "Tagok");
define("FRTLAN_29", "Adminok");
define("FRTLAN_31", "Mindenki (publikus)");
define("FRTLAN_32", "Felhasználói csoport");
define("FRTLAN_33", "Érvényes beállítások");
define("FRTLAN_34", "Oldal");
?>