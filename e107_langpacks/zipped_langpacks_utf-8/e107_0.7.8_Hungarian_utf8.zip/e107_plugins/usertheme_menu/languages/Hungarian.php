<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_350", "Téma beállítása");
define("LAN_351", "Téma kiválasztása");

?>