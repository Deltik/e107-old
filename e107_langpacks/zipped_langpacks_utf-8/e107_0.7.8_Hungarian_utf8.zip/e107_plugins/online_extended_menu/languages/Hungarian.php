<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Hungarian Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_extended_menu/languages/Hungarian.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/02/17 00:27:27 $
|     $Author: e107hun-lac $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "vendég: ");
define("ONLINE_EL2", "tag: ");
define("ONLINE_EL3", "Ezen az oldalon: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Tagok");
define("ONLINE_EL6", "Legújabb tag");
define("ONLINE_EL7", "olvassa");

define("ONLINE_EL8", "legtöbb ");
define("ONLINE_EL9", "-");

define("ONLINE_TRACKING_MESSAGE", "Online felhasználók követése jelenleg kikapcsolva, ezt engedélyezheted [link=".e_ADMIN."users.php?options]itt[/link][br]");

?>
