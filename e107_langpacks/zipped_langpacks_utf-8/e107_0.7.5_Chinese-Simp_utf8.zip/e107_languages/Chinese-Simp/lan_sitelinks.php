<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_sitelinks.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("LAN_183", "主菜单");
define("LAN_502", "管理页面");

?>