<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Simp/lan_userposts.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:23:44 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "用户帖子");

define("UP_LAN_0", "所有论坛帖子来自");
define("UP_LAN_1", "所有评论来自");
define("UP_LAN_2", "主题");
define("UP_LAN_3", "查看");
define("UP_LAN_4", "回复");
define("UP_LAN_5", "最后发表");
define("UP_LAN_6", "线索");
define("UP_LAN_7", "没有评论");
define("UP_LAN_8", "没有帖子");
define("UP_LAN_9", "在");
define("UP_LAN_10", "回复");
define("UP_LAN_11", "发表于");
define("UP_LAN_12", "搜索");
define("UP_LAN_13", "评论");
define("UP_LAN_14", "论坛帖子");
define("UP_LAN_15", "回复");
define("UP_LAN_16", "IP地址");

?>