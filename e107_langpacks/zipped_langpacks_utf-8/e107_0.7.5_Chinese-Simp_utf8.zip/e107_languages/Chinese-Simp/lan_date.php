<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_date.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/24 11:23:45 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "年");
define("LANDT_02", "月");
define("LANDT_03", "周");
define("LANDT_04", "日");
define("LANDT_05", "小时");
define("LANDT_06", "分钟");
define("LANDT_07", "秒");
define("LANDT_01s", "年");
define("LANDT_02s", "月");
define("LANDT_03s", "周");
define("LANDT_04s", "日");
define("LANDT_05s", "小时");
define("LANDT_06s", "分钟");
define("LANDT_07s", "秒");

define("LANDT_08", "分钟");
define("LANDT_08s", "分钟");
define("LANDT_09", "秒");
define("LANDT_09s", "秒");
define("LANDT_AGO", "之前");


?>