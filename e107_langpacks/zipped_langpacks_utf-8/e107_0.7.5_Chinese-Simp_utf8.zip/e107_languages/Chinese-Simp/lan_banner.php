<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "广告");

define("LAN_16", "用户名: ");
define("LAN_17", "密码: ");
define("LAN_18", "继续");
define("LAN_19", "请输入您的客户帐号和密码");
define("LAN_20", "抱歉，没有找到相应资料。请联系网站管理员。");
define("LAN_21", "广告统计");
define("LAN_22", "客户");
define("LAN_23", "广告ID");
define("LAN_24", "点击次数");
define("LAN_25", "点击 %");
define("LAN_26", "显示次数");
define("LAN_27", "购买的显示次数");
define("LAN_28", "剩余显示次数");
define("LAN_29", "没有广告");
define("LAN_30", "没有限制");
define("LAN_31", "没有");
define("LAN_32", "是");
define("LAN_33", "否");
define("LAN_34", "结束日期:");
define("LAN_35", "点击IP地址");
define("LAN_36", "激活:");
define("LAN_37", "开始日期:");
define("LAN_38", "错误");

?>