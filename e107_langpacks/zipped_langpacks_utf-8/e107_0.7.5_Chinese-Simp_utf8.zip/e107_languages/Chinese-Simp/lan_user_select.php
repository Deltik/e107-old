<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File. - Chinese Simplified
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Simp/lan_user_select.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:23:44 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "选择用户");
define("US_LAN_2", "选择用户级别");
define("US_LAN_3", "所有用户");
define("US_LAN_4", "查找用户名");
define("US_LAN_5", "找到用户");
define("US_LAN_6", "搜索");
?>