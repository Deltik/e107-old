<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/28 23:02:59 $
|     $Author: whoisrich $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "页面列表关闭");
define("LAN_PAGE_2", "没有页面");
define("LAN_PAGE_3", "请求的页面不存在");
define("LAN_PAGE_4", "评价本页面");
define("LAN_PAGE_5", "谢谢您评价本页面");
define("LAN_PAGE_6", "您没有权限查看该页面");
define("LAN_PAGE_7", "密码不正确");
define("LAN_PAGE_8", "密码保护页面");
define("LAN_PAGE_9", "密码");
define("LAN_PAGE_10", "提交");
define("LAN_PAGE_11", "页面列表");

?>