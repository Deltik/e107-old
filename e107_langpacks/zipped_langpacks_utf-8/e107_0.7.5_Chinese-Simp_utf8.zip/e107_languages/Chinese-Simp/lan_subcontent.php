<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_subcontent.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/09 03:32:07 $
|     $Author: chavo $
+----------------------------------------------------------------------------+
*/
define("ARLAN_0", "多谢，您的文章已保存，管理员将作相应审核。");
define("ARLAN_1", "字段为空。");
define("ARLAN_2", "多谢，您的评论已保存，管理员将作相应审核。");
define("ARLAN_15", "提交文章");
define("ARLAN_17", "标题");
define("ARLAN_18", "子标题");
define("ARLAN_19", "摘要");
define("ARLAN_20", "文章");
define("ARLAN_21", "允许评论?");
define("ARLAN_22", "打开");
define("ARLAN_23", "关闭");
define("ARLAN_24", "添加邮件/打印图标?");
define("ARLAN_25", "是");
define("ARLAN_26", "否");
define("ARLAN_27", "提交文章");
define("ARLAN_28", "预览");
define("ARLAN_55", "可见");
define("ARLAN_73", "打开HTML编辑器");
define("ARLAN_74", "分类");
define("ARLAN_75", "无");
define("ARLAN_82", "作者资料");
define("ARLAN_84", "作者姓名");
define("ARLAN_85", "作者电子邮件");
define("ARLAN_86", "评论");
define("ARLAN_87", "评价");
define("ARLAN_88", "请选择等级");
define("ARLAN_89", "提交评论");

define("ARLAN_90", "字段为空，请按浏览器返回按钮并确认所有字段都已填写。");
define("ARLAN_91", "重新预览");
define("ARLAN_92", "请输入您的姓名/电子邮件");


define("ARLAN_93", "文章");
define("ARLAN_94", "评论");
define("ARLAN_95", "目前用户不能提交文章");
define("ARLAN_96", "目前用户不能发表评论");
define("ARLAN_97", "您没有发表文章的权限");
define("ARLAN_98", "您没有发表评论的权限");


define("ARLAN_99", "您要提交什么?");
define("ARLAN_100", "新闻");
define("ARLAN_101", " 事件");
define("ARLAN_102", "文章");
define("ARLAN_103", "评论");
define("ARLAN_104", "链接");
define("ARLAN_105", "下载");
define("ARLAN_106", "提交项目");

?>