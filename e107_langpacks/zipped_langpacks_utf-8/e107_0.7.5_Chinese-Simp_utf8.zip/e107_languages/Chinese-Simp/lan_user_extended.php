<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File. - Chinese Simplified
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Simp/lan_user_extended.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:23:44 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "文本框");
define("UE_LAN_2", "单选按钮");
define("UE_LAN_3", "下拉菜单");
define("UE_LAN_4", "数据表字段");
define("UE_LAN_5", "文本区域");
define("UE_LAN_6", "整数");
define("UE_LAN_7", "日期");
define("UE_LAN_8", "语言");

define("UE_LAN_9", "名称");
define("UE_LAN_10", "类型");
define("UE_LAN_11", "使用");

define("UE_LAN_HIDE", "用户不可见");

define("UE_LAN_LOCATION", "位置");
define("UE_LAN_LOCATION_DESC", "用户位置");
define("UE_LAN_AIM", "AIM");
define("UE_LAN_AIM_DESC", "AIM");
define("UE_LAN_ICQ", "ICQ");
define("UE_LAN_ICQ_DESC", "ICQ");
define("UE_LAN_YAHOO", "Yahoo!");
define("UE_LAN_YAHOO_DESC", "Yahoo!");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN");
define("UE_LAN_HOMEPAGE", "主页");
define("UE_LAN_HOMEPAGE_DESC", "用户主页(url)");
define("UE_LAN_BIRTHDAY", "生日");
define("UE_LAN_BIRTHDAY_DESC", "生日");
define("UE_LAN_LANGUAGE", "语言");
define("UE_LAN_LANGUAGE_DESC", "用户语言");
define("UE_LAN_COUNTRY", "国家");
define("UE_LAN_COUNTRY_DESC", "用户国家(包括数据表)");

?>