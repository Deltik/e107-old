<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.   - Chinese Simplified
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Simp/lan_comment.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:23:44 $
|     $Author: e107.cn $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "评论");

define("LAN_0", "[被管理员锁定]");
define("LAN_1", "解锁");
define("LAN_2", "锁定");
define("LAN_3", "删除");
define("LAN_4", "信息");
define("LAN_5", "评论 ...");
define("LAN_6", "登入后才能发表评论 - 请登入或者点击注册");
define("LAN_7", "网站管理员");
define("LAN_8", "评论");
define("LAN_9", "提交评论");
define("LAN_10", "管理员");
define("LAN_11", "无法将您的评论写入数据库 - 请删除非标准的字符后重新输入。");
define("LAN_16", "用户名: ");
define("LAN_99", "评论");
define("LAN_100", "新闻");
define("LAN_101", "投票");
define("LAN_102", "回复: ");
define("LAN_103", "文章");
define("LAN_104", "评论");
define("LAN_105", "内容");
define("LAN_145", "已注册: ");
define("LAN_194", "访客");
define("LAN_195", "已注册会员");
define("LAN_310", "该用户名已被注册，如果这是你的用户名，请登入。");
define("LAN_312", "重复发贴 - 不能接受。") ;
define("LAN_313", "来自");
define("LAN_314", "修改评论");
define("COMLAN_1", "这里");
define("COMLAN_2", "注册");
define("COMLAN_3", "错误!");
define("COMLAN_4", '主题');
define("COMLAN_5", '回复:');
define("COMLAN_6", '回复该贴');
define("COMLAN_7", '评级');
define("COMLAN_8", '评论被锁定');

define("LAN_315", "引用地址");
define("LAN_316", "本贴没有引用地址。");
define("LAN_317", "修改引用地址");

define("LAN_318", "编辑评论");
define("LAN_319", "已编辑");
define("LAN_320", "更新评论");

?>