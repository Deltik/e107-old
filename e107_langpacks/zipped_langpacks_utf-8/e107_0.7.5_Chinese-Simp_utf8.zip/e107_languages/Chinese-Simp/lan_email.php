<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_email.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/17 23:49:04 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "电子邮件");

define("LAN_5", "转发该文章给朋友");
define("LAN_6", "转发新闻给朋友");
define("LAN_7", "登录名: ");
define("LAN_8", "评论");
define("LAN_9", "抱歉 - 无法发送邮件");
define("LAN_10", "邮件发到");
define("LAN_11", "邮件已发出");
define("LAN_12", "错误");
define("LAN_106", "电子邮件地址不对");
define("LAN_185", "发送文章");
define("LAN_186", "发送新闻");
define("LAN_187", "电子邮件地址");
define("LAN_188", "我想您对这个新闻有兴趣，来自");
define("LAN_189", "我想您对这篇文章有兴趣，来自");

define("LAN_email_1", "来自:");
define("LAN_email_2", "发送人IP地址:");
define("LAN_email_3", "邮件来自 ");
define("LAN_email_4", "发送邮件");
define("LAN_email_5", "发送邮件给朋友");
define("LAN_email_6", "我想您对这个有兴趣，来自");
define("LAN_email_7", "发送邮件给某人");

?>