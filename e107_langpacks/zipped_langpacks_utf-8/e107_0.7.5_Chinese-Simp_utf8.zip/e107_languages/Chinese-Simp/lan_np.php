<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_np.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("NP_1", "前一页");
define("NP_2", "下一页");
define("NP_3", "转到页面");

?>