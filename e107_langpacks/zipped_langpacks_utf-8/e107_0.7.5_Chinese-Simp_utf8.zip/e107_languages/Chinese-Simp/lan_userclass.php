<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File. - Chinese Simplified
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Simp/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:23:44 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "所有人");
define("UC_LAN_1", "访客");
define("UC_LAN_2", "无");
define("UC_LAN_3", "会员");
define("UC_LAN_4", "只读");
define("UC_LAN_5", "管理员");
?>