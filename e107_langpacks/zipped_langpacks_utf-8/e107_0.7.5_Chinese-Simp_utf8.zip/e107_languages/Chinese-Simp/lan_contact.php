<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "关于我们");
define("LANCONTACT_02", "联系表单");
define("LANCONTACT_03", "您的姓名:");
define("LANCONTACT_04", "电子邮件:");
define("LANCONTACT_05", "标题:");
define("LANCONTACT_06", "内容:");
define("LANCONTACT_07", "发送复制消息到您的邮箱");
define("LANCONTACT_08", "发送");
define("LANCONTACT_09", "您的消息已发出。");
define("LANCONTACT_10", "发送消息时出错。");
define("LANCONTACT_11", "您的电子邮件地址不正确。\\n请检查后再试。");
define("LANCONTACT_12", "您的消息太短。");
define("LANCONTACT_13", "请输入消息标题。"); 

?>