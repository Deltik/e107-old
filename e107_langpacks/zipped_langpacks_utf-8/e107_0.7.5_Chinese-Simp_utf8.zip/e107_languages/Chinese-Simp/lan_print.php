<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_print.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/17 23:49:04 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "打印页面");

define("LAN_86", "分类:");
define("LAN_87", "由");
define("LAN_94", "作者");
define("LAN_135", "新闻: ");
define("LAN_303", "本新闻来自");
define("LAN_304", "标题: ");
define("LAN_305", "副标题: ");
define("LAN_306", "来自: ");
define("LAN_307", "打印本页");

define("LAN_PRINT_1", "打印页面");


?>