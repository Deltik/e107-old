<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 11:45:50 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "投票");
define("RATELAN_1", "投票");
define("RATELAN_2", "您对该项目的评价为?");
define("RATELAN_3", "谢谢您的投票");
define("RATELAN_4", "尚未评价");
define("RATELAN_5", "评价");

?>