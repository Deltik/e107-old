<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_mail_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Powered By e107");
define("LANMAILH_2", "这是MIME格式的multi-part信息。");
define("LANMAILH_3", "格式不对");
define("LANMAILH_4", "服务器拒绝地址");
define("LANMAILH_5", "服务器没有响应");
define("LANMAILH_6", "没有找到邮件服务器。");
define("LANMAILH_7", "正确。");

?>