<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_review.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("REVLAN_1", "评论添加到数据库。");
define("REVLAN_2", "字段留空。");
define("REVLAN_3", "评论已更新。");
define("REVLAN_4", "评论已删除。");
define("REVLAN_5", "请选择确认框删除该评论");
define("REVLAN_6", "还没有评论。");
define("REVLAN_7", "已有评论");
define("REVLAN_8", "修改");
define("REVLAN_9", "删除");
define("REVLAN_10", "选择确认");
define("REVLAN_11", "打开HTML编辑器");
define("REVLAN_12", "标题");
define("REVLAN_13", "子标题");
define("REVLAN_14", "概要");
define("REVLAN_15", "评论");
define("REVLAN_16", "评价");
define("REVLAN_17", "请选择评价");
define("REVLAN_18", "允许评论?");
define("REVLAN_19", "打开");
define("REVLAN_20", "关闭");
define("REVLAN_21", "可见");
define("REVLAN_22", "更新评论");
define("REVLAN_23", "发表评论");
define("REVLAN_24", "评论");




define("REVLAN_25", "评论分类已保存");
define("REVLAN_26", "评论分类已更新");
define("REVLAN_27", "分类已删除");
define("REVLAN_28", "分类");
define("REVLAN_29", "选项");
define("REVLAN_30", "修改");
define("REVLAN_31", "删除");
define("REVLAN_32", "没有评论分类");
define("REVLAN_33", "现有评论分类");
define("REVLAN_34", "分类名称");
define("REVLAN_35", "分类图标");
define("REVLAN_36", "查看图像");
define("REVLAN_37", "分类说明");
define("REVLAN_38", "更新评论分类");
define("REVLAN_39", "创建评论分类");
define("REVLAN_40", "没有评论");
define("REVLAN_41", "现有评论");
define("REVLAN_42", "打开HTML编辑器");
define("REVLAN_43", "分类");
define("REVLAN_44", "无");
define("REVLAN_45", "评论首页");
define("REVLAN_46", "创建新的评论");
define("REVLAN_47", "分类");
define("REVLAN_48", "评论选项");
define("REVLAN_49", "您确认要删除该分类吗?");
define("REVLAN_50", "您确认要删除该评论吗?");
define("REVLAN_51", "作者介绍");
define("REVLAN_52", "如果是自己留空");
define("REVLAN_53", "作者姓名");
define("REVLAN_54", "作者电子邮件");

define("REVLAN_55", "允许发表评论");
define("REVLAN_56", "允许访客发表评论");
define("REVLAN_57", "发表评论组群");
define("REVLAN_58", "选择哪些用户能发表评论");
define("REVLAN_59", "更新选项");
define("REVLAN_60", "评论选项");
define("REVLAN_61", "评论选项已更新");

define("REVLAN_62", "发表评论");
define("REVLAN_63", "没有提交的评论");
define("REVLAN_64", "没有提供电子邮件地址");
define("REVLAN_65", "评论标题");
define("REVLAN_66", "发表");
define("REVLAN_67", "发表用户提交文章");
define("REVLAN_68", "用户提交的评论保存到数据库");

define("REVLAN_69", "清空表单");
define("REVLAN_70", "点击这里填写作者栏目");
define("REVLAN_71", "添加电子邮件/打印图标?");
define("REVLAN_72", "是");
define("REVLAN_73", "否");
?>