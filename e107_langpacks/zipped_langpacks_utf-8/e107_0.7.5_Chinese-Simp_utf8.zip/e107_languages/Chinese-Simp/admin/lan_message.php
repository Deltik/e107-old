<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "接收的消息");
define("MESSLAN_2", "删除消息");
define("MESSLAN_3", "消息已删除。");
define("MESSLAN_4", "删除所有消息");
define("MESSLAN_5", "确认");
define("MESSLAN_6", "所有消息已删除");
define("MESSLAN_7", "没有消息。");
define("MESSLAN_8", "消息类型");
define("MESSLAN_9", "日期");

define("MESSLAN_10", "提交人");
define("MESSLAN_11", "在新窗口打开");
define("MESSLAN_12", "消息");
define("MESSLAN_13", "链接");


?>