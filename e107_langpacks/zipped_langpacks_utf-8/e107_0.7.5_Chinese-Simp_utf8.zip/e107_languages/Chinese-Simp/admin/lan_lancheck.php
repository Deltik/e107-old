<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/10 21:31:57 $
|     $Author: loloirie $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "选择语言检查");
define("LAN_CHECK_2", "开始检查");
define("LAN_CHECK_3", "检查");
define("LAN_CHECK_4", "缺少文件!");
define("LAN_CHECK_5", "缺少语句!");
define("LAN_CHECK_6", "OK");
define("LAN_CHECK_7", "语句");

define("LAN_CHECK_8", "缺少一个文件...");
define("LAN_CHECK_9", "个文件缺少...");
define("LAN_CHECK_10", "严重错误: ");
define("LAN_CHECK_11", "没有缺少文件!");
define("LAN_CHECK_12", "一个文件错误...");
define("LAN_CHECK_13", "个文件错误...");
define("LAN_CHECK_14", "所有文件都正确!");

?>