<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/administrator.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/09 17:02:46 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "网站管理员帮助";
$text = "使用本页修改参数，或删除网站管理员。网站管理员仅能存取指定的项目。<br /><br />
要新增管理员，进入用户设置页面，更新现有用户为管理员。";
$ns -> tablerender($caption, $text);
?>