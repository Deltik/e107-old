<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/02 06:14:20 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "首页设置已更新。");
define("FRTLAN_2", "设置首页给");
define("FRTLAN_6", "链接");
// define("FRTLAN_7", "Content Page");
define("FRTLAN_12", "更新首页设置");
define("FRTLAN_13", "首页设置");
define("FRTLAN_15", "其它(输入url):");
define("FRTLAN_16", "错误: 没有选择内容主目录");
define("FRTLAN_17", "错误: 没有选择内容子分类");
define("FRTLAN_18", "错误: 没有选择内容项目");
define("FRTLAN_19", "内容主目录");
define("FRTLAN_20", "内容分类");
define("FRTLAN_21", "内容项目");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "所有用户");
define("FRTLAN_27", "访客");
define("FRTLAN_28", "会员");
define("FRTLAN_29", "管理员");
define("FRTLAN_31", "所有用户");
define("FRTLAN_32", "用户等级");
define("FRTLAN_33", "当前设置");
define("FRTLAN_34", "页面");

?>