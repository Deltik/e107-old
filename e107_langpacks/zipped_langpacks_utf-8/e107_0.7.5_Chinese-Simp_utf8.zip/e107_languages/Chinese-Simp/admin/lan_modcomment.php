<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "已修改。");
define("MDCLAN_2", "该项目没有评论");
define("MDCLAN_3", "会员");
define("MDCLAN_4", "访客");
define("MDCLAN_5", "解锁");
define("MDCLAN_6", "锁定");

define("MDCLAN_8", "修改评论");
define("MDCLAN_9", "警告! 删除上级评论 将删除所有回复!");

define("MDCLAN_10", "选项");
define("MDCLAN_11", "评论");
define("MDCLAN_12", "评论");
define("MDCLAN_13", "锁定");
define("MDCLAN_14", "锁定评论");
define("MDCLAN_15", "打开");
define("MDCLAN_16", "锁定");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>