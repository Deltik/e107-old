<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_language.php,v $
|     $Revision: 1.9 $
|     $Date: 2006/04/17 14:52:38 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00","无法创建。(已存在)");
define("LANG_LAN_01","已删除(如已存在) 并重建。");
define("LANG_LAN_02","无法删除");
define("LANG_LAN_03","数据表");

define("LANG_LAN_05","没有安装");
define("LANG_LAN_06", "创建数据表");
define("LANG_LAN_07", "删除现有数据表?");
define("LANG_LAN_08", "更新已有数据表(数据将丢失)。");
define("LANG_LAN_10", "确认删除");
define("LANG_LAN_11", "删除上面没有选中的数据表(如已存在)。");
define("LANG_LAN_12", "打开多语言数据表");
define("LANG_LAN_13", "语言选择");
define("LANG_LAN_14", "网站缺省语言");
define("LANG_LAN_15", "选择以从缺省语言中复制数据。(对链接、新闻分类等有用) ");
define("LANG_LAN_16", "多语言数据库使用"); 

?>