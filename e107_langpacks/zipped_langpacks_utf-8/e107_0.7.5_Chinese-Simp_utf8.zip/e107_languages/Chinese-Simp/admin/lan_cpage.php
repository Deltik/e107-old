<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/22 17:08:01 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "标题");
define("CUSLAN_2", "类型");
define("CUSLAN_3", "选项");
define("CUSLAN_4", "删除该页面?");
define("CUSLAN_5", "现有页面");
define("CUSLAN_7", "菜单名称");
define("CUSLAN_8", "标题/说明");
define("CUSLAN_9", "文字");
define("CUSLAN_10", "允许对页面评价");
define("CUSLAN_11", "首页");
define("CUSLAN_12", "新建页面");
define("CUSLAN_13", "允许评论");
define("CUSLAN_14", "密码保护的页面");
define("CUSLAN_15", "输入保护页面的密码");
define("CUSLAN_16", "再主菜单中创建链接");
define("CUSLAN_17", "输入链接名称");
define("CUSLAN_18", "页面/链接可见等级");
define("CUSLAN_19", "更新页面");
define("CUSLAN_20", "新建页面");
define("CUSLAN_21", "更新菜单");
define("CUSLAN_22", "创建菜单");
define("CUSLAN_23", "修改页面");
define("CUSLAN_24", "新增页面");
define("CUSLAN_25", "修改菜单");
define("CUSLAN_26", "新增菜单");
define("CUSLAN_27", "页面保存到数据库。");
define("CUSLAN_28", "页面已删除");
define("CUSLAN_29", "没有选择页面时列出的页面");
define("CUSLAN_30", "cookie有效期(秒)");
define("CUSLAN_31", "新建菜单");
define("CUSLAN_32", "转换以前的页面/菜单");
define("CUSLAN_33", "页面选项");
define("CUSLAN_34", "开始转换");
define("CUSLAN_35", "完成定制页面更新 - 已更新");
define("CUSLAN_36", "要设置每个页面的参数，请返回首页修改页面。");
define("CUSLAN_37", "定制页面更新");
define("CUSLAN_38", "打开");
define("CUSLAN_39", "关闭");
define("CUSLAN_40", "保存选项");

define("CUSLAN_41", "显示作者和日期信");
define("CUSLAN_42", "还没有定义页面");

?>