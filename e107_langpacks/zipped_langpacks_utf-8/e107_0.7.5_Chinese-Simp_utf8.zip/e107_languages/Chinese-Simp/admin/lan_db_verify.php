<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db_verify.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 18:29:48 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "无法读取sql数据文件<br /><br />请确认文件<b>core_sql.php</b>位于<b>/admin/sql</b>目录中。");
define("DBLAN_2", "正在检查全部");

define("DBLAN_4", "数据表");
define("DBLAN_5", "字段");
define("DBLAN_6", "状态");
define("DBLAN_7", "说明");
define("DBLAN_8", "不匹配");
define("DBLAN_9", "目前");
define("DBLAN_10", "要");
define("DBLAN_11", "个字段不存在");
define("DBLAN_12", "个多余字段!");
define("DBLAN_13", "个数据表不存在!");
define("DBLAN_14", "选择要检查的数据表");
define("DBLAN_15", "开始检查");
define("DBLAN_16", "SQL检查");
define("DBLAN_17", "返回");
define("DBLAN_18", "数据表");
define("DBLAN_19", "尝试修复");
define("DBLAN_20", "尝试修复数据表");
define("DBLAN_21", "修复选择的项目");
?>