<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_emoticon.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "允许使用表情");
define("EMOLAN_2", "名称");
define("EMOLAN_3", "表情");
define("EMOLAN_4", "激活表情?");

define("EMOLAN_5", "图像");
define("EMOLAN_6", "代码");
define("EMOLAN_7", "用空格分开");

define("EMOLAN_8", "状态");
define("EMOLAN_9", "选项");
define("EMOLAN_10", "激活");
define("EMOLAN_11", "激活压缩包'");

define("EMOLAN_12", "修改/设置压缩包");
define("EMOLAN_13", "安装压缩包");

define("EMOLAN_14", "保存设置");
define("EMOLAN_15", "修改/设置表情");
define("EMOLAN_16", "表情设置已保存");
define("EMOLAN_2", "名称");
define("EMOLAN_2", "名称");
define("EMOLAN_2", "名称");
define("EMOLAN_2", "名称");
define("EMOLAN_2", "名称");
define("EMOLAN_2", "名称");

?>