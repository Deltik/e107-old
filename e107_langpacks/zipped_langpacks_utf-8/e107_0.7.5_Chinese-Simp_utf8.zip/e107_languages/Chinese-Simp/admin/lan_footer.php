<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_footer.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "网站");
define("FOOTLAN_2", "管理员");
define("FOOTLAN_3", "版本");
define("FOOTLAN_4", "补丁");
define("FOOTLAN_5", "风格");
define("FOOTLAN_6", "制作");
define("FOOTLAN_7", "信息");
define("FOOTLAN_8", "安装日期 date");
define("FOOTLAN_9", "服务器");
define("FOOTLAN_10", "主机");
define("FOOTLAN_11", "PHP版本");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "网址信息");
define("FOOTLAN_14", "显示文档");
define("FOOTLAN_15", "文档资料");
define("FOOTLAN_16", "数据库");
define("FOOTLAN_17", "字符集");

?>