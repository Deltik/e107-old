<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "缓存系统状态");
define("CACLAN_2", "设置缓存状态");
define("CACLAN_3", "缓存系统");
define("CACLAN_4", "缓存状态设置");
define("CACLAN_5", "清空缓存");
define("CACLAN_6", "缓存已清空");

define("CACLAN_7", "关闭缓存");
// define("CACLAN_8", "Cache data saved to MySQL");
define("CACLAN_9", "保存缓存数据到文件");
define("CACLAN_10", "缓存目录不可写，请确保目录设置为CHMOD 0777");
?>