<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "无法找到服务器IP地址 - 没有可用信息。");
// define("USFLAN_2", "Error");
define("USFLAN_3", "信息来自IP地址");
define("USFLAN_4", "主机");
define("USFLAN_5", "点击这里添加IP地址到黑名单");
define("USFLAN_6", "用户ID");
define("USFLAN_7", "用户信息");

?>