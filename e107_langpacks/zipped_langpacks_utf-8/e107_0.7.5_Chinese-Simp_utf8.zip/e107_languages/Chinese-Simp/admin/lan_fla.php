<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_fla.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/17 07:51:40 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "不成功登录日志");
define("FLALAN_2", "没有不成功登录的记录");
define("FLALAN_3", "尝试删除");
define("FLALAN_4", "用户尝试使用不正确的用户名/密码登录");
define("FLALAN_5", "IP被屏蔽");
define("FLALAN_6", "日期");
define("FLALAN_7", "数据");
define("FLALAN_8", "IP地址/主机");
define("FLALAN_9", "选项");
define("FLALAN_10", "删除/屏蔽选择项目");
define("FLALAN_11", "选择所有删除方框");
define("FLALAN_12", "不选所有删除方框");
define("FLALAN_13", "选择所有屏蔽方框");
define("FLALAN_14", "不选所有屏蔽方框");
define("FLALAN_15", "以下IP地址被自动屏蔽 - 用户登录失败超过10次");
define("FLALAN_16", "删除该制动屏蔽列表");
define("FLALAN_17", "自动屏蔽列表已删除");

?>