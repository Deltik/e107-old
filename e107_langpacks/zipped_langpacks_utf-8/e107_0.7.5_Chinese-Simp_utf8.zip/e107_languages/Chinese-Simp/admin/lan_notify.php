<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/05/29 18:19:25 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_1", "邮件通知");
define("NT_LAN_2", "接收邮件通知选项");
define("NT_LAN_3", "关闭");
define("NT_LAN_4", "主管理员");
define("NT_LAN_5", "等级");
define("NT_LAN_6", "电子邮件");

define("NU_LAN_1", "用户事件");
define("NU_LAN_2", "用户注册");
define("NU_LAN_3", "用户帐户验证");
define("NU_LAN_4", "用户登入");
define("NU_LAN_5", "用户登出");

define("NS_LAN_1", "安全事件");
define("NS_LAN_2", "屏蔽IP地址");

define("NN_LAN_1", "新闻事件");
define("NN_LAN_2", "用户提交的新闻");
define("NN_LAN_3", "管理员提交的新闻");
define("NN_LAN_4", "管理员修改的新闻");
define("NN_LAN_5", "管理员删除的新闻");

?>