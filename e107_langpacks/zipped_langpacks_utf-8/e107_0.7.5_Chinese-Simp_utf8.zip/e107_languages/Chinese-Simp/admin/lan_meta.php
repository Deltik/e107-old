<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/09/06 19:34:04 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta标签在数据库中已更新");
define("METLAN_2", "输入附加的meta标签");
define("METLAN_3", "输入新的meta标签设置");
define("METLAN_4", "已更新");
define("METLAN_5", "在这里输入描述");
define("METLAN_6", "在, 这里, 输入, 关键字, 列表");
define("METLAN_7", "在这里输入您的版权信息");
define("METLAN_8", "Meta标签");

define("METLAN_9", "描述");
define("METLAN_10", "关键字");
define("METLAN_11", "版权");

?>