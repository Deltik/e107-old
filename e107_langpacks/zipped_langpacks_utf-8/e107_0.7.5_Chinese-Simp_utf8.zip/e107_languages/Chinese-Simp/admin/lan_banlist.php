<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/17 06:49:46 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "黑名单已删除。");
define("BANLAN_2", "没有黑名单。");
define("BANLAN_3", "现有黑名单");
define("BANLAN_4", "删除黑名单");
define("BANLAN_5", "输入IP、电子邮件、或主机");
define("BANLAN_7", "原因");
define("BANLAN_8", "屏蔽用户");
define("BANLAN_9", "屏蔽用户访问本站");
define("BANLAN_10", "IP/电子邮件/原因");
define("BANLAN_11", "自动屏蔽: 登入失败超过10次");

?>