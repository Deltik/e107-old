<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/03 15:57:25 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "发送通知邮件到");
define("UCSLAN_2", "权限更新通知");
define("UCSLAN_3", "尊敬的");
define("UCSLAN_4", "您的权限已更新 － ");
define("UCSLAN_5", "您现在拥有以下权限");
define("UCSLAN_6", "设置用户组群");
define("UCSLAN_7", "设置组群");
define("UCSLAN_8", "通知用户");
define("UCSLAN_9", "组群已更新。");
define("UCSLAN_10", "谢谢！");

?>