<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "从等级中删除所有用户。");
define("UCSLAN_2", "等级用户已更新。");
define("UCSLAN_3", "等级已删除。");
define("UCSLAN_4", "请选择确认框删除该用户等级");
define("UCSLAN_5", "等级已更新。");
define("UCSLAN_6", "等级已保存到数据库。");
define("UCSLAN_7", "还没有用户等级。");
define("UCSLAN_8", "已有等级");

// define("UCSLAN_9", "Edit");
// define("UCSLAN_10", "Delete");
define("UCSLAN_11", "选择以确认");
define("UCSLAN_12", "等级名称");
define("UCSLAN_13", "等级描述");
define("UCSLAN_14", "更新用户等级");
define("UCSLAN_15", "新建等级");
define("UCSLAN_16", "指定用户到等级");
define("UCSLAN_17", "删除");
define("UCSLAN_18", "清除等级");
define("UCSLAN_19", "指定用户到");
define("UCSLAN_20", "等级");
define("UCSLAN_21", "用户等级设置");

define("UCSLAN_22", "用户 - 点击移动 ...");
define("UCSLAN_23", "在该等级中的用户 ...");

define("UCSLAN_24", "管理等级的用户");


?>