<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_e107_update.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/21 16:15:28 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "操作");
define("LAN_UPDATE_3", "不需要");

define("LAN_UPDATE_5", "有更新");
define("LAN_UPDATE_7", "执行");
define("LAN_UPDATE_8", "更新来自");
define("LAN_UPDATE_9", "到");
define("LAN_UPDATE_10", "可用更新");
define("LAN_UPDATE_11", ".617 到 .7 继续更新");

?>