<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/24 16:29:02 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "系统设置备份到数据库中。");
define("DBLAN_2", "点击按钮保存您的e107数据库备份");
define("DBLAN_3", "备份SQL数据库");
define("DBLAN_4", "点击按钮检查您的e107数据库");
define("DBLAN_5", "检查数据库完整性");
define("DBLAN_6", "点击按钮优化您的e107数据库");
define("DBLAN_7", "优化SQL数据库");
define("DBLAN_8", "点击按钮备份您的系统设置");
define("DBLAN_9", "备份系统");
define("DBLAN_10", "数据库工具");
define("DBLAN_11", "MySQL数据库");
define("DBLAN_12", "已优化");
define("DBLAN_13", "返回");
define("DBLAN_14", "完成");
define("DBLAN_15", "点击按钮检测是否有数据库更新");
define("DBLAN_16", "检测更新");

?>