<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_credits.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/10 15:40:55 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "鸣谢");
define("CRELAN_2", "这里是e107中使用的第三方软件列表/资源。e107开发小组衷心感谢以下为e107提供接口的开发人员，以及感谢他们采用GPL软件许可。");
// define("CRELAN_3", "Resource");
// define("CRELAN_4", "Description");
// define("CRELAN_5", "Website");
// define("CRELAN_6", "Permission");
define("CRELAN_7", "版本");



?>