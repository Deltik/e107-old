<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_header.php,v $
|     $Revision: 1.3 $
|     $Date: 2004/10/25 16:11:40 $
|     $Author: loloirie $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "管理导航");
define("LAN_head_2", "您的服务器不允许HTTP文件商场，所以您的用户无法上传头像/文件等。要使用该功能，在php.ini文件中设置file_uploads为On并重启服务器。如果您没有权限修改php.ini，请联系主机商。");
define("LAN_head_3", "您的服务器使用目录重定向，因此无法存取任何空间目录以外的文件，可能影响文件管理等脚本。");

define("LAN_head_4", "管理页面");

define("LAN_head_5", "管理页面的语言: ");
define("LAN_head_6", "插件信息");

?>