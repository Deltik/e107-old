<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "维护设置更新");
define("UGFLAN_2", "激活维护标记");
define("UGFLAN_3", "更新维护设置");
define("UGFLAN_4", "维护设置");

define("UGFLAN_5", "网站关闭时显示的文字");
define("UGFLAN_6", "留空显示缺省信息");

?>