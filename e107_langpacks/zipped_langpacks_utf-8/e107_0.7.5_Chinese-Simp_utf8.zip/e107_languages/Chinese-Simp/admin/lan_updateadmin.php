<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "错误 - 请重新提交");
define("UDALAN_2", "设置更新");
define("UDALAN_3", "设置更新");
define("UDALAN_4", "姓名");
define("UDALAN_5", "密码");
define("UDALAN_6", "重复密码");
define("UDALAN_7", "修改密码");
define("UDALAN_8", "密码更新");

?>