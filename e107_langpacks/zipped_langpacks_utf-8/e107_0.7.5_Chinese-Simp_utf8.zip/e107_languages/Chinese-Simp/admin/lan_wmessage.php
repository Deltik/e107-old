<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/admin/lan_wmessage.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/04/22 19:30:47 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Message for Guests");
// define("WMGLAN_2", "Message for Members");
// define("WMGLAN_3", "Message for Administrators");
// define("WMGLAN_4", "Submit");
// define("WMGLAN_5", "Set Welcome Message");
// define("WMGLAN_6", "Activate?");
// define("WMGLAN_7", "Welcome message settings updated.");

define("WMLAN_00","欢迎信息");
define("WMLAN_01","添加欢迎信息");
define("WMLAN_02","内容");
define("WMLAN_03","可见组群");
define("WMLAN_04","内容");

define("WMLAN_05","嵌入显示");
define("WMLAN_06","如果选择，内容将显示在方框中");
define("WMLAN_07","覆盖标准系统，使用{WMESSAGE}");
// define("WMLAN_08","Preferences");

define("WMLAN_09","还没输入欢迎信息");
define("WMLAN_10","标题");    

?>