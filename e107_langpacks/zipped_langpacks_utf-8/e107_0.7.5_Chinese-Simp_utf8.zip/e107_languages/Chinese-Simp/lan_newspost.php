<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/15 01:08:03 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "新闻已删除。");
define("NWSLAN_2", "请选择确认方框删除该新闻。");
define("NWSLAN_3", "没有新闻。");
define("NWSLAN_4", "现有新闻");
define("NWSLAN_5", "打开HTML编辑器");
define("NWSLAN_6", "分类");
define("NWSLAN_7", "编辑");
define("NWSLAN_8", "删除");
define("NWSLAN_9", "选择确认");
define("NWSLAN_10", "还没有设置分类。");
define("NWSLAN_11", "添加/编辑分类");
define("NWSLAN_12", "标题");
define("NWSLAN_13", "内容");
define("NWSLAN_14", "详细");
define("NWSLAN_15", "评论");
define("NWSLAN_16", "激活");
define("NWSLAN_17", "未激活");
define("NWSLAN_18", "允许给本新闻增加评论");
define("NWSLAN_19", "激活");
define("NWSLAN_20", "留空关闭自动激活");
define("NWSLAN_21", "激活区间");
define("NWSLAN_22", "可见性");
define("NWSLAN_23", "选择该项将使本新闻仅对该类用户可见");
define("NWSLAN_24", "再次预览");
define("NWSLAN_25", "更新新闻");
define("NWSLAN_26", "发表新闻");
define("NWSLAN_27", "预览");
define("NWSLAN_28", "新增新闻");
define("NWSLAN_29", "发表新闻");

define("NWSLAN_30", "仅显示标题");

?>