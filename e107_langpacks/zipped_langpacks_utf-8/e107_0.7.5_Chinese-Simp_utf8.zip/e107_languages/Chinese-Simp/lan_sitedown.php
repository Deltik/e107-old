<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "网站暂时关闭");
define("LAN_00", "暂时关闭");
define("LAN_01", "本站正在维护中，暂时关闭。不会太久 - 请稍后再访问，谢谢支持。");
?>