<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/05 06:58:21 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "文件类型");
define("LANUPLOAD_2", "不允许，已经删除。");
define("LANUPLOAD_3", "上传成功。");
define("LANUPLOAD_4", "目标目录不存在或不可写。(chmod 777)");
define("LANUPLOAD_5", "上传的文件大小超过php.ini中upload_max_filesize的设置");
define("LANUPLOAD_6", "上传文件大小超过html表单中设置的MAX_FILE_SIZE。");
define("LANUPLOAD_7", "仅上传文件的一部分。");
define("LANUPLOAD_8", "没有上传文件。");
define("LANUPLOAD_9", "上传文件大小为0字节");
define("LANUPLOAD_10", "上传失败 [文件名重复] - 已存在同名文件。");
define("LANUPLOAD_11", "文件没有上传。文件名: ");
define("LANUPLOAD_12", "错误");

?>