<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/11 01:43:42 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "用户注册");

define("NT_LAN_UV_1", "已验证用户");
define("NT_LAN_UV_2", "用户ID: ");
define("NT_LAN_UV_3", "用户登录名: ");
define("NT_LAN_UV_4", "用户IP: ");


define("NT_LAN_LI_1", "登入用户");

define("NT_LAN_LO_1", "登出用户");
define("NT_LAN_LO_2", "登出网站");

define("NT_LAN_FL_1", "屏蔽Flood");
define("NT_LAN_FL_2", "已屏蔽的IP地址");

define("NT_LAN_SN_1", "新闻已提交");

define("NT_LAN_NU_1", "更新");

define("NT_LAN_ND_1", "新闻已删除");
define("NT_LAN_ND_2", "删除新闻编号");

?>