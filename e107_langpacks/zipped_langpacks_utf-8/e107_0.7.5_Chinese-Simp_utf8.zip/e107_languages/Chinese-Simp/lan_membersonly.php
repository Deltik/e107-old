<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/06 18:11:26 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "会员专用");

define("LAN_MEMBERS_0", "会员栏目");
define("LAN_MEMBERS_1", "会员栏目");
define("LAN_MEMBERS_2","请<a href='".e_LOGIN."'>登录</a>后访问");
define("LAN_MEMBERS_3","或者<a href='".e_SIGNUP."'>注册</a>成为会员");
define("LAN_MEMBERS_4","点击这里返回首页");

?>