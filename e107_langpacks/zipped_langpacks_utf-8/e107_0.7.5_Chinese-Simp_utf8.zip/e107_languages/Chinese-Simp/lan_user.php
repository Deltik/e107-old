<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/04/06 03:53:00 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "会员");

define("LAN_20", "错误");
define("LAN_112", "电子邮件");
define("LAN_115", "ICQ");
define("LAN_116", "AIM");
define("LAN_117", "MSN");
define("LAN_118", "生日");
define("LAN_119", "来自");
define("LAN_120", "签名");
define("LAN_137", "没有该用户资料，未注册");
define("LAN_138", "注册会员: ");
define("LAN_139", "顺序: ");
define("LAN_140", "注册会员");
define("LAN_141", "没有注册会员。");
define("LAN_142", "会员");
define("LAN_143", "[要求隐藏]");
define("LAN_144", "网址");
define("LAN_145", "加入");
define("LAN_146", "访问次数");
define("LAN_147", "聊天记录");
define("LAN_148", "评论次数");
define("LAN_149", "论坛帖子");
define("LAN_308", "真实姓名");
define("LAN_400", "不是合法用户。");
define("LAN_401", "没有信息");
define("LAN_402", "会员资料");
define("LAN_403", "网站统计");
define("LAN_404", "最后访问");
define("LAN_405", "天之前");
define("LAN_406", "评价");
define("LAN_407", "无");
define("LAN_408", "没有照片");
define("LAN_409", "点数");
define("LAN_410", "其它");
define("LAN_411", "点击这里更新您的资料");
define("LAN_412", "点击这里修改该用户资料");
define("LAN_413", "删除照片");
define("LAN_414", "前一个会员");
define("LAN_415", "后一个回去");
define("LAN_416", "登录后查看该页面");
define("LAN_417", "主要网站管理员");
define("LAN_418", "网站管理员");
define("LAN_419", "显示");
define("LAN_420", "降序");
define("LAN_421", "升序");
define("LAN_422", "转到");
define("LAN_423", "点击这里查看用户评论");
define("LAN_424", "点击这里查看论坛帖子");
define("LAN_425", "发送私人消息");
define("LAN_426", "之前");

define("USERLAN_1", "单一评价");

?>