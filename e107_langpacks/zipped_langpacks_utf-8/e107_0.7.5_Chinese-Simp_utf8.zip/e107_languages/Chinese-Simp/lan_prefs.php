<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_prefs.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/04 23:13:42 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107制作");
define("LAN_PREF_2", "e107网站系统");
define("LAN_PREF_3", "本建站系统<a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>，采用的是<a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a>GPL开源许可。");
define("LAN_PREF_4", "已审核");
define("LAN_PREF_5", "论坛");

?>