<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "发贴最多会员");
define("TOP_LAN_1", "用户名");
define("TOP_LAN_2", "帖子");
define("TOP_LAN_3", "最多评论次数");
define("TOP_LAN_4", "评论");
define("TOP_LAN_5", "最多聊天发言");
define("TOP_LAN_6", "网站评价");

//v.616
define("LAN_1", "主题");
define("LAN_2", "发贴");
define("LAN_3", "查看");
define("LAN_4", "回复");
define("LAN_5", "最后回复");
define("LAN_6", "主题");
define("LAN_7", "最活跃主题");
define("LAN_8", "发贴最多");


?>