<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Simp/Chinese-Simp.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:23:44 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'zhcn');
setlocale(LC_TIME, 'zh_CN.utf-8');
define("CORE_LC", 'zh');
define("CORE_LC2", 'cn');
// define("原文方向","rtl");
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","错误：缺少布景。\\n\\n在参数中修改布景(管理页面)或者上传当前布景文件到服务器。");

//v.616
define("CORE_LAN2"," \\1 写道:");// "\\1" 表示用户名
define("CORE_LAN3","不允许附件");

//v0.7+
define("CORE_LAN4", "请从服务器上删除install.php ");
define("CORE_LAN5", "如果不删除对网站有潜在的安全风险");

?>