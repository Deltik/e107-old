<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Chinese-Simp/Chinese-Simp.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/09/16 15:23:44 $
|     $Author: e107.cn $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'zhcn');
define("CORE_LC", 'zh');
define("CORE_LC2", 'cn');
// define("原文方向","rtl");
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","错误：缺主题。\\n\\n在参数中改变用过的主题(管理员区)或者在服务器上上传当前主题的文件。");

//v.616
define("CORE_LAN2"," \\1 wrote:");// "\\1" 表示用户名
define("CORE_LAN3","不允许附件");

//v0.7+
define("CORE_LAN4", "请从服务器上删除install.php ");
define("CORE_LAN5", "如果不删除将有潜在的安全风险");

?>