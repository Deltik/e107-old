<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "提交文件");

define("LAN_20", "错误");
define("LAN_61", "您的姓名: ");
define("LAN_112", "电子邮件: ");
define("LAN_144", "网址: ");
define("LAN_402", "注册为会员后才能上传文件。");
define("LAN_403", "您没有上传文件的权限。");
define("LAN_404", "谢谢。您上传的文件通过管理员的审核后，将发布再网站上。");
define("LAN_405", "文件超过指定大小 - 已删除。");
define("LAN_406", "请注意");
define("LAN_407", "上传其它文件类型将立刻删除。");
define("LAN_408", "下划线");
define("LAN_409", "文件名");
define("LAN_410", "版本");
define("LAN_411", "文件");
define("LAN_412", "缩略图");
define("LAN_413", "描述");
define("LAN_414", "演示版本");
define("LAN_415", "请输入网址");
define("LAN_416", "上传");
define("LAN_417", "提交文件");
define("LAN_418", "允许文件大小: ");
define("DOWLAN_11", "分类");
define("LAN_419", "允许的文件类型");
define("LAN_420", "为必填字段");



?>