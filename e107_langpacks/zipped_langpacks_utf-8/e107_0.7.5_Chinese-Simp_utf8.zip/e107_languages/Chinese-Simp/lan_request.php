<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_request.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/09 15:38:12 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "下载错误");
define("LAN_dl_62", "您无法下载该文件，已经超出下载限制");
define("LAN_dl_63", "您没有下载该文件的权限。");
define("LAN_dl_64", "返回");
define("LAN_dl_65", "文件没找到");

?>