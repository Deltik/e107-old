<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_equery_secure.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "转向管理页面，可能是因为修改了数据库");
define("EQSEC_LAN2", "请确认本操作:");
define("EQSEC_LAN3", "没有来源");
define("EQSEC_LAN4", "操作来自:");
define("EQSEC_LAN5", "操作转向:");
define("EQSEC_LAN6", "确认操作");
define("EQSEC_LAN7", "或取消");
?>