<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Chinese-Simp/lan_links.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: www.e107.cn $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "友情链接");

define("LAN_61", "链接分类");
define("LAN_62", "分类");
define("LAN_63", "分类");
define("LAN_64", "在本分类中");
define("LAN_65", "链接");
define("LAN_66", "链接");
define("LAN_67", "显示所有链接");
define("LAN_68", "编辑");
define("LAN_69", "删除");
define("LAN_86", "分类:");
define("LAN_88", "来源:");
define("LAN_89", "管理员: ");
define("LAN_90", "在本分类中添加链接");
define("LAN_91", "添加分类");

define("LAN_92", "提交链接");
define("LAN_93", "提交链接且管理员审核通过后，该链接将显示在链接主页面。");
define("LAN_94", "链接名称:");
define("LAN_95", "链接URL:");
define("LAN_96", "链接描述:");
define("LAN_97", "链接按钮URL:");
define("LAN_98", "提交链接");

define("LAN_99", "谢谢");
define("LAN_100", "您的链接已保存，管理员会及时审核。");
define("LAN_101", "请点击这里提交链接");

define("LAN_102", "总共");
define("LAN_103", "有");
define("LAN_104", "有");
define("LAN_105", "位于");
define("LAN_106", "下划线字段为必填字段。");

define("LAN_Links_1", "链接总数");
define("LAN_Links_2", "激活链接总数");
define("LAN_LINKS_3", "匿名");
?>