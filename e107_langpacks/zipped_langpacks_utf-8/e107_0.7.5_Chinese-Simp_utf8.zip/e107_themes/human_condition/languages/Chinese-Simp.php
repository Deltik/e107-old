<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/human_condition/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/03/21 11:13:49 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' by <a href='http://e107.org' rel='external'>jalist</a>, 基于Wordpress布景，<a href='http://wordpress.org'>http://wordpress.org</a>。");
define("LAN_THEME_2", "该项目的评论已关闭");
define("LAN_THEME_3", "评论: ");
define("LAN_THEME_4", "查看更多 ...");
define("LAN_THEME_5", "引用: ");
define("LAN_THEME_6", "Comment by");


?>
