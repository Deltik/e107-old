<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_extended_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/05 22:44:37 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
	
define("ONLINE_EL1", "访客人数: ");
define("ONLINE_EL2", "会员人数: ");
define("ONLINE_EL3", "该页面: ");
define("ONLINE_EL4", "在线信息");
define("ONLINE_EL5", "会员总数");
define("ONLINE_EL6", "最新会员");
define("ONLINE_EL7", "查看");
	
define("ONLINE_EL8", "最多在线人数: ");
define("ONLINE_EL9", "<br />出现在");

define("TRACKING_MESSAGE", "用户在线信息目前处于关闭状态，请在<a href='".e_ADMIN."users.php?options'>这里</a>打开</span><br />");

?>