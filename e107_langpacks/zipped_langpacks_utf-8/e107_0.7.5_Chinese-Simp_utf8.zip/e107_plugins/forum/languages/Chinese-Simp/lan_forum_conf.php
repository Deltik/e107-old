<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_conf.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/02/07 03:28:40 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("FORLAN_5", "投票已删除。");
define("FORLAN_6", "主题已删除");
define("FORLAN_7", "回复已删除");
define("FORLAN_8", "删除取消。");
define("FORLAN_9", "主题已移动。");
define("FORLAN_10", "移动取消。");
define("FORLAN_11", "返回论坛");
define("FORLAN_12", "论坛设置");
define("FORLAN_13", "您确认要删除该投票吗?<br />一旦删除，将<b><u>无法</u></b>恢复。");
define("FORLAN_14", "取消");
define("FORLAN_15", "确认删除论坛帖子");
define("FORLAN_16", "确认删除投票");
define("FORLAN_17", "发贴");
define("FORLAN_18", "您确认要删除该论坛吗");
define("FORLAN_19", "主题和相关帖子?");
define("FORLAN_20", "投票也将被删除");
define("FORLAN_21", "一旦删除将");
define("FORLAN_22", "发表?<br />一旦删除");
define("FORLAN_23", "无法</u></b>恢复");
define("FORLAN_24", "移动主题到论坛");
define("FORLAN_25", "移动主题");
define("FORLAN_26", "回复已删除");
	
define("FORLAN_27", "已移动");

define("FORLAN_28", "不要修改主题标题");
define("FORLAN_29", "添加");
define("FORLAN_30", "到标题");
define("FORLAN_31", "改名为:");
define("FORLAN_32", "改名主题选项:");

	
?>