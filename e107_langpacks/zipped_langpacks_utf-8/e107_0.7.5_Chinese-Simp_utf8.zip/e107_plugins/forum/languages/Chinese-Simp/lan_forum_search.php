<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/16 05:25:35 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "论坛");
define("FOR_SCH_LAN_2", "选择论坛");
define("FOR_SCH_LAN_3", "所有论坛");
define("FOR_SCH_LAN_4", "全部帖子");
define("FOR_SCH_LAN_5", "部分主题");

?>