<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/01 22:59:32 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("FOR_FP_1", "论坛");

?>