<?php
	
define("LAN_350", "设置布景");
define("LAN_351", "选择布景");
	
?>