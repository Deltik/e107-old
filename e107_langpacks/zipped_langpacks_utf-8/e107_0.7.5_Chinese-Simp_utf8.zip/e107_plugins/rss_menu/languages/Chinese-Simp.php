<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/rss_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/10/13 18:55:26 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("BACKEND_MENU_L1", "的RSS Feeds");
define("BACKEND_MENU_L2", "RSS Feeds");

define("BACKEND_MENU_L3", "新闻");
define("BACKEND_MENU_L4", "评论");
define("BACKEND_MENU_L5", "论坛主题");
define("BACKEND_MENU_L6", "论坛帖子");

define("BACKEND_MENU_L7", "聊天室发言");
define("BACKEND_MENU_L8", "错误跟踪报告");
define("BACKEND_MENU_L9", "下载");

define("RSS_LAN01", "每个新闻分类增加单独的Feeds?");
define("RSS_LAN02", "每个下载分类增加单独的Feeds?");

define("RSS_NEWS","新闻");
define("RSS_COM","评论"); 
define("RSS_ART","文章");
define("RSS_REV", "评论");
define("RSS_FT","论坛主题");
define("RSS_FP","论坛帖子");
define("RSS_FSP","论坛特定帖子");
define("RSS_BUG","错误跟踪");
define("RSS_FOR","论坛");
define("RSS_DL","下载");
?>