<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/07 02:54:20 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("TREE_L1", "配置主菜单");
define("TREE_L2", "更新主菜单设置");
define("TREE_L3", "主菜单设置已保存。");
define("TREE_L4", "打开");
define("TREE_L5", "关闭");
define("TREE_L6", "用于不能打开的链接的CSS类");
define("TREE_L7", "用于可以打开的链接CSS类");
define("TREE_L8", "用于已打开链接的CSS类");
define("TREE_L9", "主要链接之间使用空类");

?>