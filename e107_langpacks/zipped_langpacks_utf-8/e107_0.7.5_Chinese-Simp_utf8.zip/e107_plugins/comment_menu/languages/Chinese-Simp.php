<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
	
define("CM_L1", "还没有评论。");
define("CM_L2", "");
define("CM_L3", "标题");
define("CM_L4", "显示的评论?");
define("CM_L5", "显示的字数?");
define("CM_L6", "太长评论的后缀?");
define("CM_L7", "在菜单中显示原来的新闻标题?");
define("CM_L8", "新的评论菜单设置");
define("CM_L9", "更新菜单设置");
define("CM_L10", "评论菜单设置已保存");
	
	
?>