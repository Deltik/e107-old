<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/human_condition/languages/Spanish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/03 22:41:15 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' por <a href='http://e107.org' rel='external'>jalist</a>, basado en el theme wordpress, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Comentarios desactivados ");
define("LAN_THEME_3", "Comentario(s):");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Comentario de");


?>