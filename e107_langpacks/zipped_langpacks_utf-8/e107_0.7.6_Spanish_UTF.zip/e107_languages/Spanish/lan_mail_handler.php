<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_mail_handler.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Producido por e107 website system");
define("LANMAILH_2", "Este es un mensaje multi-part en formato MIME.");
define("LANMAILH_3", " no esta formateado apropiadamente");
define("LANMAILH_4", "Mensaje rechazado por el servidor");
define("LANMAILH_5", "No hay respuesta del servidor");
define("LANMAILH_6", "No se puede encontrar servidor E-Mail.");
define("LANMAILH_7", " parece ser válido.");
define("LANMAILH_8", "");
define("LANMAILH_9", "");

?>