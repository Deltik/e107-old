<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_credits.php,v $
|     $Revision: 1.9 $
|     $Date: 2006/11/11 11:05:45 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Créditos e107");
define("CRELAN_1", "Créditos");
define("CRELAN_2", "Debajo está una lista de recursos y software de terceras personas para e107. Agradecemos su colaboración así como el permitir usar su software bajo licencia GPL");
define("CRELAN_3", "Todos los derechos reservados");
define("CRELAN_4", "Mostrar equipo e107");
define("CRELAN_5", "Mostrar script de terceros");
define("CRELAN_6", "e107 ha sido realizado por...");
define("CRELAN_7", "Versión");
define("CRELAN_8", "permiso concedido"); 
define("CRELAN_9", "Licenciaa"); 
// third party scripts 
define("CRELAN_10", "MagpieRSS proporciona XML-based (expat) RSS parser en PHP."); 
define("CRELAN_11", "PclZip ofrece compresión y extracción en archivos Zip"); 
define("CRELAN_12", "PclTar ofrece archivar una lista de archivos o directorios con o sin compresión. Los archivos creados por PclTar son leíbles por cualquier aplicación gzip/tar."); 
define("CRELAN_13", "TinyMCE es una plataforma web independiente basado en Javascript proporcionando un editor WYSIWYG por Moxiecode Systems AB. Tiene la propiedad de convertir codigo html en texto perfectamente leíble."); 
define("CRELAN_14", "Iconos usedos en e107"); 
define("CRELAN_15", "Clase de transferencia de mail de PHP"); 
define("CRELAN_16", "Sistema de menús en el tema Jayya"); 
define("CRELAN_17", "Calendario Popup calendar"); 
define("CRELAN_18", "Soporte PDF"); 
define("CRELAN_19", "Soporte UTF-8 PDF"); 
// end third party scripts 

// dev team 
define("CRELAN_20", ""); // asperon 
define("CRELAN_21", "Always a pressure..err..pleasure!"); // CaMer0n 
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\""); // jalist 
define("CRELAN_23", ""); // lisa 
define("CRELAN_24", ""); // McFly 
define("CRELAN_25", ""); // que 
define("CRELAN_26", ""); // streaky 
define("CRELAN_27", "\"Wot? No tea?? 0_0\""); // SweetAs 
define("CRELAN_28", ""); // MrPete  
// end dev team 
?>