<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_header.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Menú Admin.");
define("LAN_head_2", "Su servidor no admite la transferencia de archivos via HTTP, los usuarios no podrán transferir sus avatares/archivos etc. Para corregir esto cambie file_uploads a On en su php.ini y reinicie el servidor. Si usted no tiene acceso al servidor póngase en contacto con su proovedor de hosting.");
define("LAN_head_3", "Su servidor está ejecutando una restricción en el directorio principal. Esto no permitirá el uso de algunos archivos fuera de su carpeta principal y afectará a determinados Scripts como el gestor de ficheros.");
define("LAN_head_4", "Area Admin.");
define("LAN_head_5", "Idioma mostrado en el área del Admin: ");
define("LAN_head_6", "Info de plugins");
?>