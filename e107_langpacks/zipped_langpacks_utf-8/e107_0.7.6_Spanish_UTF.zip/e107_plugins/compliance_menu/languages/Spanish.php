<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/compliance_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/03 22:34:18 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("COMPLIANCE_L1", "Compatibilidad W3C");
?>