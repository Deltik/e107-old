<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/other_news_menu/languages/Spanish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/03 22:34:18 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("TD_MENU_L1", "Otras noticias");

?>