<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_user.php,v $
|     $Revision: 1.12 $
|     $Date: 2006/08/12 17:23:20 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Miembros");

define("LAN_20", "Error");

define("LAN_112", "Dirección email: ");

define("LAN_115", "Número ICQ: ");
define("LAN_116", "Dirección AIM: ");
define("LAN_117", "MSN Messenger: ");
define("LAN_118", "Cumpleaños: ");
define("LAN_119", "Localización: ");
define("LAN_120", "Firma: ");

define("LAN_137", "No hay información para este usuario, no está registrado en");
define("LAN_138", "Miembros: ");
define("LAN_139", "Ordenar: ");
define("LAN_140", "Miembros");
define("LAN_141", "No hay miembros registrados en este momento.");
define("LAN_142", "Miembro");
define("LAN_143", "[oculta]");
define("LAN_144", "Sitio Web: ");
define("LAN_145", "Registrado: ");
define("LAN_146", "Visitas desde su registro: ");
define("LAN_147", "Envios al Chatbox: ");
define("LAN_148", "Comentarios enviados: ");
define("LAN_149", "Mensajes en el foro: ");

define("LAN_308", "Nombre Real: ");

define("LAN_400", "Este no es un usuario válido.");
define("LAN_401", "No hay información");
define("LAN_402", "Perfil del miembro");
define("LAN_403", "Estadísticas del sitio");
define("LAN_404", "Última visita al sitio");
define("LAN_405", "días");
define("LAN_406", "Puntuación");
define("LAN_407", "nada");
define("LAN_408", "Sin Foto");
define("LAN_409", "puntos");
define("LAN_410", "Miscelánea");
define("LAN_411", "Pulse aquí para actualizar su información");
define("LAN_412", "Pulse aquí para editar la información de este usuario");
define("LAN_413", "Borrar foto");
define("LAN_414", "Miembro anterior");
define("LAN_415", "Miembro siguiente");
define("LAN_416", "Debe iniciar sesión para acceder a esta página");
define("LAN_417", "Administrador principal");
define("LAN_418", "Administrador");
define("LAN_419", "Ver");
define("LAN_420", "Descendente");
define("LAN_421", "Ascendente");
define("LAN_422", "Ir");
define("LAN_423", "Ver los comentarios de este usuario");
define("LAN_424", "Ver los mensajes en los foros de este usuario");
define("LAN_425", "Enviar Mensaje Privado a");
define("LAN_426", "");

define("USERLAN_1", "Valoración del Peer");
define("USERLAN_2", "No tiene permisos para ver esta página.");
?>