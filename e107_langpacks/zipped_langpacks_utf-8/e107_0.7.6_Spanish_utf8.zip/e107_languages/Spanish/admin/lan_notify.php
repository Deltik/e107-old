<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_notify.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Notificaciones");
define("NT_LAN_2", "Recibir notificación email ON");
define("NT_LAN_3", "OFF");
define("NT_LAN_4", "Admin Jefe");
define("NT_LAN_5", "Clase");
define("NT_LAN_6", "Email");

define("NU_LAN_1", "Eventos de usuario");
define("NU_LAN_2", "Altas de usuario");
define("NU_LAN_3", "Verificación de cuenta de usuario");
define("NU_LAN_4", "Conexión de usuario");
define("NU_LAN_5", "Desconexión de usuario");

define("NS_LAN_1", "Eventos de seguridad");
define("NS_LAN_2", "IP expulsada por flooding");

define("NN_LAN_1", "Eventos de noticias");
define("NN_LAN_2", "Nuevos elementos enviados por usuarios");
define("NN_LAN_3", "Nuevos eleventos enviados por Admin");
define("NN_LAN_4", "Nuevos elementos editados por Admin");
define("NN_LAN_5", "Nuevos elementos eliminados por Admin");

?>