<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_userinfo.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "No se puede encontrar dirección IP de usuario - no hay información disponible.");
//define("USFLAN_2", "Error");
define("USFLAN_3", "Mensajes enviados desde direción IP");
define("USFLAN_4", "Alojado");
define("USFLAN_5", "Pulse aquí para transferir dirección IP a página de prohibición de la Administración");
define("USFLAN_6", "ID de usuario");
define("USFLAN_7", "Información de usuario");

?>