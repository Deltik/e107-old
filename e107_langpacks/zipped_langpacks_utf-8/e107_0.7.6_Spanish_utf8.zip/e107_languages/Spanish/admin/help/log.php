<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/log.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Activa las estadísticas del sitio desde esta página.
Si tienes poco espacio en el servidor marca la casilla de dominio como referencia de inicio de sesión,
esto solo indicará el dominio en lugar de todo el url, ejemplo 'e107.org' en lugar de 'http://e107.org/portal' ";
$ns -> tablerender("Ayuda de Inicio de sesión", $text);
?>