<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_credits.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("CRELAN_1", "Créditos");
define("CRELAN_2", "Debajo está una lista de recursos y software de terceras personas para e107. Agradecemos su colaboración así como el permitir usar su software bajo licencia GPL");
//define("CRELAN_3", "Origen");
//define("CRELAN_4", "Descripción");
//define("CRELAN_5", "Web");
//define("CRELAN_6", "Permiso");
define("CRELAN_7", "Versión");
?>