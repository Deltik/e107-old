<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_userclass.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Enviando notificación por email a");
define("UCSLAN_2", "Actualizar privilegios");
define("UCSLAN_3", "Estimado");
define("UCSLAN_4", "Tus privilegios han sido actualizados a");
define("UCSLAN_5", "Ahora tiene acceso en la(s) siguiente(s) área(s)");
define("UCSLAN_6", "Cambiar Clase para usuario");
define("UCSLAN_7", "Cambiar clase");
define("UCSLAN_8", "Notificar usuario");
define("UCSLAN_9", "Clases actualizadas");
define("UCSLAN_10", "Atentamente");

?>