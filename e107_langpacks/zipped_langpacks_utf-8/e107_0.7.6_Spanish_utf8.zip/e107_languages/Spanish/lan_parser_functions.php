<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_parser_functions.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/29 12:57:42 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Invitado");
define("LAN_WROTE", "escribi�"); // as in John wrote.."  ";
?>