<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_contact.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/30 11:24:30 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Detalles del contacto");
define("LANCONTACT_02", "Formulario del contacto");
define("LANCONTACT_03", "Escriba su nombre:");
define("LANCONTACT_04", "Direccion correo:");
define("LANCONTACT_05", "Asunto del mensaje:");
define("LANCONTACT_06", "Escriba el mensaje:");
define("LANCONTACT_07", "Enviar una copia del correo a su dirección ");
define("LANCONTACT_08", "Enviar");
define("LANCONTACT_09", "Su mensaje fué enviado.");
define("LANCONTACT_10", "Hubo un problema al enviar su mensaje.");
define("LANCONTACT_11", "Su dirección de correo no parece válida.\\nPor favor, compruébela de nuevo.");
define("LANCONTACT_12", "Su mensaje es demasiado corto.");
define("LANCONTACT_13", "Por favor, incluya un asunto."); 
?>