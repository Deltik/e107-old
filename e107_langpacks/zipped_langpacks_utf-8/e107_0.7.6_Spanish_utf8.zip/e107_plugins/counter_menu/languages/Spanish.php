<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/counter_menu/languages/Spanish.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "Las visitas del Admin no se contabilizan.");
define("COUNTER_L2", "Esta página hoy ...");
define("COUNTER_L3", "Total");
define("COUNTER_L4", "Esta página siempre ...");
define("COUNTER_L5", "única");
define("COUNTER_L6", "Sitio ...");
define("COUNTER_L7", "Contador");
define("COUNTER_L8", "Mensaje del Admin: <b>El registro de estadísticas está desactivado.</b><br />Para activarlo, necesita instalar el plugin de registro de estadísticas desde el <a href='".e_ADMIN."plugin.php'>gestor de plugins</a>, y luego activarlo desde la <a href='".e_PLUGIN."log/admin_config.php'>pantalla de configuración</a>.");
?>