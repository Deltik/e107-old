<?php
define("LDAPLAN_1", "Dirección del servidor");
define("LDAPLAN_2", "Base DN o Dominio<br />If LDAP - Escriba BaseDN<br />If AD - Escriba Dominio");
define("LDAPLAN_3", "LDAP mostrar usuarios<br />Contenido de texto del usuario que será capaz de buscar en el directorio.");
define("LDAPLAN_4", "LDAP mostrar contraseña<br />Contraseña para el usuario LDAP.");
define("LDAPLAN_5", "Versión LDAP ");
define("LDAPLAN_6", "Configure LDAP aut.");
?>
