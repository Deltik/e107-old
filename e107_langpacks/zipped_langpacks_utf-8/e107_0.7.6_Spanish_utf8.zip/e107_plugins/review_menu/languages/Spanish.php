<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/review_menu/languages/Spanish.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_190", "Enviar Revisión");
define("LAN_RVW_1", "Actualizar configuración");
define("LAN_RVW_2", "Configuración guardada");
define("LAN_RVW_3", "Título");
define("LAN_RVW_4", "Nº de revisiones");
define("LAN_RVW_5", "¿Mostrar categorias en menú?");
define("LAN_RVW_6", "Título lista de revisiones");
define("LAN_RVW_7", "¿Mostrar enlace a enviar revisión?");
define("LAN_RVW_8", "Configuración");
?>