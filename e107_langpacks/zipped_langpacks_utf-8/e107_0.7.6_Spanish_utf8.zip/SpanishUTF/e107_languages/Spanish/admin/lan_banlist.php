<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_banlist.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Expulsión eliminada.");
define("BANLAN_2", "No hay expulsados.");
define("BANLAN_3", "Expulsados existentes");
define("BANLAN_4", "Eliminar expulsión");
define("BANLAN_5", "Expulsar por IP, email o host");

define("BANLAN_7", "Razón");
define("BANLAN_8", "Expulsar Usuario");
define("BANLAN_9", "Expulsar usuarios del sitio");
define("BANLAN_10", "IP / Email / Razón");
define("BANLAN_11", "Auto-expulsión: Más de 10 intentos de conexión fallidos");

?>