<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_membersonly.php,v $
|     $Revision: 1.8 $
|     $Date: 2006/01/12 01:23:56 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Solo miembros");
define("LAN_MEMBERS_0", "Área restringida");
define("LAN_MEMBERS_1", "Este es un área restringida");
define("LAN_MEMBERS_2","Para acceder, por favor <a href='".e_LOGIN."'>conéctese</a>");
define("LAN_MEMBERS_3","o <a href='".e_SIGNUP."'>regístrese</a> como miembro");
define("LAN_MEMBERS_4","Volver a la página de inicio");

?>