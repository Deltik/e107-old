/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_handlers/tiny_mce/plugins/flash/langs/es.js,v $
|     $Revision: 1.4 $
|     $Date: 2006/05/16 19:52:10 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/

tinyMCE.addToLang('flash',{
title : 'Insertar / editar Flash',
desc : 'Insertar / editar Flash',
file : 'Archivo (.swf)',
size : 'Tamaño',
list : 'Archivos',
props : 'Propiedades',
general : 'General'
});
