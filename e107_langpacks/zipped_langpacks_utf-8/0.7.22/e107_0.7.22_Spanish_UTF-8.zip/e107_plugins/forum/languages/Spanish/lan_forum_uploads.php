<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Transferencias del foro");

define("FRMUP_1","Archivos transferidos al foro");
define("FRMUP_2","Archivo eliminado");
define("FRMUP_3","Error: Imposible eliminar archivo");
define("FRMUP_4","Eliminación del archivo");
define("FRMUP_5","Nombre del archivo");
define("FRMUP_6","Resultado");
define("FRMUP_7","Encontrado en el tema");
define("FRMUP_8","NO ENCONTRADO");
define("FRMUP_9","No se han encontrado archivos transferidos");
define("FRMUP_10","Eliminar");
?>