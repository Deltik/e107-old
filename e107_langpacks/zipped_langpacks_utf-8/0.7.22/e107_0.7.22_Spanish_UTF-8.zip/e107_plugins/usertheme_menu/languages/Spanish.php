<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define('LAN_UMENU_THEME_1', 'Set Tema');
define('LAN_UMENU_THEME_2', 'Seleccionar Tema ');
define('LAN_UMENU_THEME_3', 'los usuarios:');
define('LAN_UMENU_THEME_4', 'Activar los temas que los usuarios pueden seleccionar');
define('LAN_UMENU_THEME_5', 'Actualizar');
define('LAN_UMENU_THEME_6', 'Temas disponibles para los usuarios');
define('LAN_UMENU_THEME_7', 'clase, que puede seleccionar los temas');
?>