<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("LDAPLAN_1", "Dirección del servidor");
define("LDAPLAN_2", "Base DN o Dominio<br />If LDAP - Escriba BaseDN<br />If AD - Escriba Dominio");
define("LDAPLAN_3", "LDAP mostrar usuarios<br />Contenido de texto del usuario que será capaz de buscar en el directorio.");
define("LDAPLAN_4", "LDAP mostrar contraseña<br />Contraseña para el usuario LDAP.");
define("LDAPLAN_5", "Versión LDAP");
define("LDAPLAN_6", "Configurar LDAP aut.");
define("LDAPLAN_7", "Filtro de búsqueda de sDirectory:"); 
define("LDAPLAN_8", "Se utilizará para asegurar que el usuario esta en el árbol correcto, <br />pe '(objectclass=inetOrgPerson)'"); 
define("LDAPLAN_9", "El filtro actual de búsqueda será:");
define("LDAPLAN_10", "Ajustes actualizados"); 
define("LDAPLAN_11", "ATENCION:  ¡Parece que el modulo ldap no está disponible, fijando el método de autentificación a LDAP no podría funcionar!"); 
define("LDAPLAN_12", "Tipo de servidor"); 
define("LDAPLAN_13", "Actualizar ajustes");
?>
