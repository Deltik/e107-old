<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("OTHERDB_LAN_1", "Tipo de base de datos:");
define("OTHERDB_LAN_2", "Servidor:");
define("OTHERDB_LAN_3", "Usuario:");
define("OTHERDB_LAN_4", "Contraseña:");
define("OTHERDB_LAN_5", "Base de datos");
define("OTHERDB_LAN_6", "Tabla");
define("OTHERDB_LAN_7", "Campo usuario");
define("OTHERDB_LAN_8", "Campo contraseña:");
define("OTHERDB_LAN_9", "Método contraseña:");
define("OTHERDB_LAN_10", "Configurar otrabd aut");
define("OTHERDB_LAN_11", "** Los siguientes campos no son obligatorios si usa la base de datos de e107");

?>
