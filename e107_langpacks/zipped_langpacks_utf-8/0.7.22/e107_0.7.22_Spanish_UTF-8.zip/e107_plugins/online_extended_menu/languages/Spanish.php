<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Invitados: ");
define("ONLINE_EL2", "Miembros: ");
define("ONLINE_EL3", "en esta página: ");
define("ONLINE_EL4", "En linea");
define("ONLINE_EL5", "Miembros");
define("ONLINE_EL6", "Último miembro");
define("ONLINE_EL7", "viendo");
define("ONLINE_EL8", "Máximo de visitas ");
define("ONLINE_EL9", "el");

define("ONLINE_TRACKING_MESSAGE", "El tracking del usuario conectado está desactivado, por favor actívelo [link=".e_ADMIN."users.php?options]aquí[/link][br]");
?>