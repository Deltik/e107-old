<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("LAN_190", "Enviar Revisión");
define("LAN_RVW_1", "Actualizar configuración");
define("LAN_RVW_2", "Configuración guardada");
define("LAN_RVW_3", "Título");
define("LAN_RVW_4", "Nº de revisiones");
define("LAN_RVW_5", "¿Mostrar categorias en menú?");
define("LAN_RVW_6", "Título lista de revisiones");
define("LAN_RVW_7", "¿Mostrar enlace a enviar revisión?");
define("LAN_RVW_8", "Configuración");
?>