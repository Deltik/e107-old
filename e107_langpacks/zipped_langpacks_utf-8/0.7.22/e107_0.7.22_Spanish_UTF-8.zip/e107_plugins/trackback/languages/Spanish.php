<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("TRACKBACK_L1", "Configurar Trackback");
define("TRACKBACK_L2", "Este plugin te permite usar trackback en los nuevos envíos.");
define("TRACKBACK_L3", "Trackback está instalado y activado.");
define("TRACKBACK_L4", "Configuración del trackback guardada.");
define("TRACKBACK_L5", "On");
define("TRACKBACK_L6", "Off");
define("TRACKBACK_L7", "Activar trackback");
define("TRACKBACK_L8", "Trackback URL texto");
define("TRACKBACK_L9", "Guardar configuración");
define("TRACKBACK_L10", "Trackback configuración");
define("TRACKBACK_L11", "Trackback dirección para este envío:");
define("TRACKBACK_L12", "No hay trackbakcs para este artículo");
define("TRACKBACK_L13", "Moderar trackbacks");
define("TRACKBACK_L14", "Eliminar");
define("TRACKBACK_L15", "Trackback/s eliminado/s.");
?>