<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'lamb' por <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Comentarios desactivados ");
define("LAN_THEME_3", "Comentario(s):");
define("LAN_THEME_4", "Leer el resto ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", 'en');

?>