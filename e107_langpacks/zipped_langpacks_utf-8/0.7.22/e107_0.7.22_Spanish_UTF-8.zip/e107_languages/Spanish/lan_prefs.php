<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "Sitio e107");
define("LAN_PREF_2", "Portal de  Gestión e107");
define("LAN_PREF_3", "Todas las marcas están registradas © a sus respectivos propietarios, y todo el contenido está soportado bajo el portal de contenidos © e107.<br />e107 es © e107.org 2002-2005 y ha sido distribuído bajo <a href=\"http://www.gnu.org/\" rel=\"external\">Licencia GNU GPL</a>.");
define("LAN_PREF_4", "censurado");
define("LAN_PREF_5", "Foros");

?>