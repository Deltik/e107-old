<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Top usuarios");
define("TOP_LAN_0", "Top foros");
define("TOP_LAN_1", "Usuario");
define("TOP_LAN_2", "Mensajes");
define("TOP_LAN_3", "Top comentarios");
define("TOP_LAN_4", "Comentarios");
define("TOP_LAN_5", "Top chatbox");
define("TOP_LAN_6", "Puntuación del sitio");
//v.616
define("LAN_1", "Tema");
define("LAN_2", "Autor");
define("LAN_3", "Vistas");
define("LAN_4", "Respuestas");
define("LAN_5", "Último");
define("LAN_6", "Temas");
define("LAN_7", "Temas más activos");
define("LAN_8", "Top Autores");
?>