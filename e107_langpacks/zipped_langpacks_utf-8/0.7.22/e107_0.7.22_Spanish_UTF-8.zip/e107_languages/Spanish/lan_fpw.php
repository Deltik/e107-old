<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME","Restablecer la contraseña");
define("LAN_02","Lo siento, no puede enviar correo electrónico - por favor, póngase en contacto con el administrador del sitio principal.");
define("LAN_03","Restablecer la contraseña");
define("LAN_05","Para restablecer su contraseña por favor ingrese la siguiente información");
define("LAN_06","Tentativa de restablecimiento de contraseña");
define("LAN_07","Alguien con una dirección IP");
define("LAN_08","intento de restablecer la contraseña de administrador principal.");
define("LAN_09","Cambiar contraseña");
define("LAN_112","Dirección de correo electrónico utilizaste al registrarte");
define("LAN_156","Enviar");
define("LAN_213","Ese nombre de usuario / dirección de correo electrónico no se encuentra en la base de datos.");
define("LAN_214","No se puede restablecer la contraseña");
define("LAN_216","Para validar la nueva contraseña por favor vaya a la siguiente dirección URL ...");
define("LAN_217","Tu nueva contraseña es ahora validado, ahora puede ingresar con su nueva contraseña.");
define("LAN_218","Tu nombre de usuario es:");
define("LAN_219","La contraseña asociada a esa dirección de correo electrónico ya se ha puesto a cero y no se puede restablecer de nuevo. Póngase en contacto con el administrador del sitio para más detalles.");
define("LAN_FPW1","Usuario");
define("LAN_FPW2","Introduzca el código");
define("LAN_FPW3","código es incorrecta");
define("LAN_FPW4","A petición ya ha sido enviada para restablecer la contraseña, si usted no recibe el correo electrónico, póngase en contacto con el administrador del sitio para obtener ayuda.");
define("LAN_FPW5","La solicitud para restablecer su contraseña de");
define("LAN_FPW6","Un correo electrónico ha sido enviado a usted con un enlace que le permitirá restablecer su contraseña.");
define("LAN_FPW7","Esto no es un enlace válido para restablecer la contraseña. <br /> Por favor, póngase en contacto con el administrador del sitio para más detalles.");
define("LAN_FPW8","Su contraseña ha cambiado con éxito.");
define("LAN_FPW9","La nueva contraseña es:");
define("LAN_FPW10","Si");
define("LAN_FPW11","iniciar sesión ahora");
define("LAN_FPW12","e inmediatamente cambiar su contraseña, por razones de seguridad.");
define("LAN_FPW13","por favor, siga las instrucciones en el correo electrónico para validar la contraseña.");
define("LAN_FPW14","ha sido presentada por alguien con la IP de");
define("LAN_FPW15","Esto no significa que su contraseña ha sido restablecida. Usted debe ir a la dirección abajo indicada para completar el proceso de restablecimiento.");
define("LAN_FPW16","Si usted no ha solicitado que su restablecimiento de contraseña y no desea cambiarla, simplemente puede ignorar este mensaje");
define("LAN_FPW17","El enlace será válido durante 48 horas.");
?>