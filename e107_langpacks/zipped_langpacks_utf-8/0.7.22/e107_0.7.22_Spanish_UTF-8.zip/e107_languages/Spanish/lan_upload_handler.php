<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "El tipo de archivo");
define("LANUPLOAD_2", "no está permitido y ha sido borrado.");
define("LANUPLOAD_3", "Transferencia completada");
define("LANUPLOAD_4", "La carpeta de destino no existe o no tiene permisos de escritura.(chmod 777)");
define("LANUPLOAD_5", "La transferencia excede el tamaño máximo permitido definido en php.ini.");
define("LANUPLOAD_6", "La transferencia excede el tamaño máximo permitido definido por el administrador.");
define("LANUPLOAD_7", "La transferencia se ha completado parcialmente.");
define("LANUPLOAD_8", "No se realizó la transferencia.");
define("LANUPLOAD_9", "El tamaño de la transferencia es de 0 bytes");
define("LANUPLOAD_10", "Falló la transferencia [Archivo duplicado] - existe un archivo con el mismo nombre.");
define("LANUPLOAD_11", "El archivo no pudo ser transferido. Archivo: ");
define("LANUPLOAD_12", "Error");
define("LANUPLOAD_13", "Falta la carpeta temporal"); 
define("LANUPLOAD_14", "Fallo en la escritura de archivo"); 
define("LANUPLOAD_15", "Transferencia no permitida"); 
define("LANUPLOAD_16", "Error desconocido"); 
define("LANUPLOAD_17", "Nombre inválido para el archivo transferido"); 
define("LANUPLOAD_18", "El archivo trasnferido excede los límites permitidos."); 
define("LANUPLOAD_19", "Demasiados archivos trasnferidos - eliminados los excesos."); 


?>