<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Todos (público)");
define("UC_LAN_1", "Invitados");
define("UC_LAN_2", "Nadie (inactivo)");
define("UC_LAN_3", "Miembros");
define("UC_LAN_4", "Solo Lectura");
define("UC_LAN_5", "Administrador");
define("UC_LAN_6", "Admin Principal");
?>