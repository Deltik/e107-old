<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Vista de impresión"); }


define("LAN_PRINT_86", "Categoría:");
define("LAN_PRINT_87", "por ");
define("LAN_PRINT_94", "Enviada por");
define("LAN_PRINT_135", "Noticias: ");
define("LAN_PRINT_303", "Esta noticia proviene de ");
define("LAN_PRINT_304", "Título del artículo: ");
define("LAN_PRINT_305", "Encabezado: ");
define("LAN_PRINT_306", "Este artículo es de ");
define("LAN_PRINT_307", "Imprimir esta página");
define("LAN_PRINT_1", "modo impresión");
?>