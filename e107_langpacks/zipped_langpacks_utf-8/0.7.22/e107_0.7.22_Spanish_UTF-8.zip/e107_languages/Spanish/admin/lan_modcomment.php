<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("MDCLAN_1", "Moderado.");
define("MDCLAN_2", "No hay comentarios");
define("MDCLAN_3", "Miembro");
define("MDCLAN_4", "Invitado");
define("MDCLAN_5", "Desbloquear");
define("MDCLAN_6", "Bloquear");
define("MDCLAN_8", "Moderar comentarios");
define("MDCLAN_9", "¡Cuidado! Borrando el comentario raíz borrará todas sus respuestas!");
define("MDCLAN_10", "Opciones");
define("MDCLAN_11", "Comentario");
define("MDCLAN_12", "Comentarios");
define("MDCLAN_13", "Bloqueado");
define("MDCLAN_14", "Bloquear comentarios");
define("MDCLAN_15", "Abiertos");
define("MDCLAN_16", "Cerrados");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");
?>