<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("UGFLAN_1", "Configuración de mantenimiento actualizada");
define("UGFLAN_2", "Activado aviso de mantenimiento");
define("UGFLAN_3", "Actualizar configuración de mantenimiento");
define("UGFLAN_4", "Configuración de Mantenimiento");
define("UGFLAN_5", "Texto a mostrar cuando el sitio esté en mantenimiento");
define("UGFLAN_6", "Deje en blanco para mostrar el mensaje por defecto");
define('UGFLAN_8', "Acceso solo para administradores");
define('UGFLAN_9', "Acceso solo para administradores principales");
?>