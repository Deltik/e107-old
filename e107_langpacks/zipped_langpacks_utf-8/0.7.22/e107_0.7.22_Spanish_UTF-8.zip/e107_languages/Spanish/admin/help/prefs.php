<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Sus preferencias le permiten especificar los ajustes importantes de su sitio, desde el nombre del sitio, protección flood y filtros.";
$ns -> tablerender("Ayuda preferencias", $text);
?>