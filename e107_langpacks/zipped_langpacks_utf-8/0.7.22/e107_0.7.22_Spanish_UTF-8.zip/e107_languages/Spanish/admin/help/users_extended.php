<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = " Los campos extendidos de usuario le permiten añadir tipos adicionales de datos que estarán disponibles en el perfil del usuario.";
$ns -> tablerender(" Ayuda de campos extendidos de usuarios", $text);
?>