<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Use esta página para configurar sus ajustes de email de sus funciones de envíos del sitio. El formulario de envío de correos también le permite enviar un mensaje instantáneo a todos sus usuarios.";
$ns -> tablerender("Ayuda Mail", $text);
?>