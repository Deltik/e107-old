<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Desde esta pantalla puede crear menus o páginas personalizada con su propio contenido dentro.<br /><br />";
//$text="Mire en <a href='http://e107.org/e107_plugins/docs/doc.php'>http://e107.org/e107_plugins/docs/doc.php/Using107--->Content--->Using Custom Pages and Custom Menus</a> para una explicación de sus características.";
$ns -> tablerender('Ayuda de páginas y menús personalizados', $text);
?>