<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("CACLAN_1", "¿Activar Caché");
define("CACLAN_2", "Cambiar estado de la caché");
define("CACLAN_3", "Sistema de Caché");
define("CACLAN_4", "Estado de Caché cambiado");
define("CACLAN_5", "Vaciar Caché");
define("CACLAN_6", "Caché vaciada");
define("CACLAN_7", "Caché desactivada");
//define("CACLAN_8", "Guardar Caché en MySQL");
define("CACLAN_9", "Guardar Caché en archivo");
define("CACLAN_10", "La carpeta caché [e107_files\cache] no tiene permisos de escritura. Asegúrese de cambiar el directorio con CHMOD 777");
?>