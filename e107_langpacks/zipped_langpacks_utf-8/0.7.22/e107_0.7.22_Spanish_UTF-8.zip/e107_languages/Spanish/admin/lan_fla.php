<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Fallo en los intentos de conexión");
define("FLALAN_2", "No se han registrado fallos de conexión");
define("FLALAN_3", "Intento(s) eliminado(s)");
define("FLALAN_4", "Un usuario intentó conectar con un nombre o contraseña incorrectas");
define("FLALAN_5", "IP(s) expulsado(s)");
define("FLALAN_6", "Fecha");
define("FLALAN_7", "Datos");
define("FLALAN_8", "IP dirección / Servidor");
define("FLALAN_9", "Opciones");
define("FLALAN_10", "Eliminar / expulsar entradas marcadas");
define("FLALAN_11", "Marca todas la cajas de eliminación");
define("FLALAN_12", "Desmarca todas las cajas de eliminación");
define("FLALAN_13", "Marca todas las cajas de expulsión");
define("FLALAN_14", "Desmarca todas las cajas de expulsión");
define("FLALAN_15", "La(s) siguiente(s) IP(s) han sido autoexpulsadas - El usuario intentó la conexión más de 10 veces");
define("FLALAN_16", "Eliminar esta lista de auto-expulsados");
define("FLALAN_17", "Lista de auto-expulsados eliminada");
?>