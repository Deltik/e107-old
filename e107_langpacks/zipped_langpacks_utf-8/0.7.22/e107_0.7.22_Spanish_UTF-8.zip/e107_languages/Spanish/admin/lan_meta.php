<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("METLAN_1", "Meta-tags actualizados en la base de datos");
define("METLAN_2", "Añadir Meta-tags adicionales");
define("METLAN_3", "Nueva configuración de Meta-tags");
define("METLAN_4", "Actualizado");
define("METLAN_5", "Escriba aquí su descripción");
define("METLAN_6", "Escriba, una, lista, de, sus, palabras, clave, aquí");
define("METLAN_7", "Escriba la información de Copyright aquí");
define("METLAN_8", "Meta-Tags");
define("METLAN_9", "Descripción");
define("METLAN_10", "Palabras Clave");
define("METLAN_11", "Copyright");
define("METLAN_12", "Use título y sumario de noticias como descripción meta en las nuevas páginas."); 
define("METLAN_13", "Autor"); 
?>