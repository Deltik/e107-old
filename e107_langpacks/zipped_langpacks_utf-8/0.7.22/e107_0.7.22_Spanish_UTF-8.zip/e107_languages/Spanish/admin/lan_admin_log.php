<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Registro del Admin");
define("LAN_ADMINLOG_1", "Fecha");
define("LAN_ADMINLOG_2", "Título");
define("LAN_ADMINLOG_3", "Descripción");
define("LAN_ADMINLOG_4", "Usuario IP");
define("LAN_ADMINLOG_5", "Usuario ID");
define("LAN_ADMINLOG_6", "Icono informativo");
define("LAN_ADMINLOG_7", "Mensaje informativo");
define("LAN_ADMINLOG_8", "Icono aviso");
define("LAN_ADMINLOG_9", "Mensaje aviso");
define("LAN_ADMINLOG_10", "Icono de alarma");
define("LAN_ADMINLOG_11", "Mensaje de alarma");
define("LAN_ADMINLOG_12", "Icono Fatídico");
define("LAN_ADMINLOG_13", "Mensaje de error fatídico");

?>