<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Solo miembros");
define("LAN_MEMBERS_0", "Área restringida");
define("LAN_MEMBERS_1", "Este es un área restringida");
define("LAN_MEMBERS_2","Para acceder, por favor <a href='".e_LOGIN."'>conéctese</a>");
define("LAN_MEMBERS_3","o <a href='".e_SIGNUP."'>regístrese</a> como miembro");
define("LAN_MEMBERS_4","Volver a la página de inicio");


?>