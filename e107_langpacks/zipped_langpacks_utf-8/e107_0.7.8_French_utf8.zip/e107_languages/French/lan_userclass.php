<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_userclass.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("UC_LAN_0", "Tout le monde (public)");
define("UC_LAN_1", "Visiteurs seulement");
define("UC_LAN_2", "Personne (inactif)");
define("UC_LAN_3", "Utilisateurs seulement");
define("UC_LAN_4", "Lecture seule");
define("UC_LAN_5", "Administrateurs seulement");
define("UC_LAN_6", "Admin(s) principal(aux)");
?>
