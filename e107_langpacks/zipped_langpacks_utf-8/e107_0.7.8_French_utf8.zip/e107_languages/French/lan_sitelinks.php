<?php
define("LAN_SITELINKS_183", "Navigation Principale");
define("LAN_SITELINKS_502", "Administration");
?>
