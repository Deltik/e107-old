<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_userinfo.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/12/04 21:32:33 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("USFLAN_1", "Impossible de trouver l'Ip de cette personne - aucune information n'est disponible.");
//define("USFLAN_2", "Erreur");
define("USFLAN_3", "Messages postés depuis l'adresse IP");
define("USFLAN_4", "Hôte");
define("USFLAN_5", "Cliquer ici pour transférer l'adresse IP dans la liste de bannissements");
define("USFLAN_6", "ID de l'utilisateur");
define("USFLAN_7", "Informations sur l'utilisateur");
?>