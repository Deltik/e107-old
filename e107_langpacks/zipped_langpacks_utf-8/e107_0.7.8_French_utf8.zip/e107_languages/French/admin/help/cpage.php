<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/help/cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Depuis de cette page vous pouvez créer des menus et/ou des pages personnifiés en y insérant votre propre contenu.<br/><br/>";
$text .= "Consulter <a href='http://wiki.e107.org/?title=Using_Custom_Pages_and_Custom_Menus' target='_blank'>la doc</a><strong>en anglais</strong> pour de plus amples explications des possibilités";
$ns -> tablerender(CUSLAN_18, $text);
?>
