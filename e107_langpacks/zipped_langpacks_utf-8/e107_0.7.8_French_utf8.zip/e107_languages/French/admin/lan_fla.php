<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/admin/lan_fla.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/04 21:32:32 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("FLALAN_1", "Échecs d'essais de connexions");
define("FLALAN_2", "Aucun échec d'essai de connexion n'a été noté");
define("FLALAN_3", "Tentative supprimée");
define("FLALAN_4", "Utilisateur ayant essayé de se connecter avec un identifiant/mot de passe éronné");
define("FLALAN_5", "IP(s) bannie(s)");
define("FLALAN_6", "Date");
define("FLALAN_7", "Données");
define("FLALAN_8", "Adresse IP / Hébergeur");
define("FLALAN_9", "Options");
define("FLALAN_10", "Supprimer/Bannir des entrées");
define("FLALAN_11", "sélectionner toutes les cases à supprimer");
define("FLALAN_12", "désélectionner toutes les cases à supprimer");
define("FLALAN_13", "sélectionner toutes les cases d'exclus");
define("FLALAN_14", "désélectionner toutes les cases d'exclus");
define("FLALAN_15", "L'adresse(s) IP suivante(s) a/ont été automatiquement bannie(s). L'utilisateur ayant fait plus de 10 tentatives de connexions qui ont échouées");
define("FLALAN_16", "Supprimer cette liste des bannis automatiquement");
define("FLALAN_17", "liste des bannis automatiquement supprimée");
?>
