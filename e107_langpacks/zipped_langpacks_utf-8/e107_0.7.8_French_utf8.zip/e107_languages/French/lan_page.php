<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_page.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/04 21:32:30 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("LAN_PAGE_1", "La liste des pages n'est pas activée");
define("LAN_PAGE_2", "Il n'y a pas de pages");
define("LAN_PAGE_3", "La page demandée n'existe pas");
define("LAN_PAGE_4", "Evaluer cette page");
define("LAN_PAGE_5", "Merci d'avoir évaluer cette page");
define("LAN_PAGE_6", "Vous n'avez pas la permission d'accéder à cette page");
define("LAN_PAGE_7", "Mot de passe incorrect");
define("LAN_PAGE_8", "Page protégée par un mot de passe");
define("LAN_PAGE_9", "Mot de passe");
define("LAN_PAGE_10", "Proposer");
define("LAN_PAGE_11", "Liste des pages");
define("LAN_PAGE_12", "Page non valide");
define("LAN_PAGE_13", "Page");


?>