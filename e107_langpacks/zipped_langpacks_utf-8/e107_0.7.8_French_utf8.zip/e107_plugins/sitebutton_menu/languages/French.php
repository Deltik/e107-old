<?php
define("SITEBUTTON_MENU_L1", "Un lien vers votre site");
?>
