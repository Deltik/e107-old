<?php
define("NWSF_FP_1", "Ressources d".GLOBAL_LAN_D_PREFIX_NEWS.GLOBAL_LAN_NEWS_4."");
define("NWSF_FP_2", "Page principale");
?>
