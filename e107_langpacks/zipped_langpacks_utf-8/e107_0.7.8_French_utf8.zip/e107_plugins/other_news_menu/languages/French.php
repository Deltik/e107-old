<?php
define("TD_MENU_L1", "Autres ".GLOBAL_LAN_NEWS_4."");
define("TD_MENU_L2", "Autres ".GLOBAL_LAN_NEWS_4."");
?>
