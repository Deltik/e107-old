<?php
define("OTHERDB_LAN_1", "Type de base de données :");
define("OTHERDB_LAN_2", "Serveur:");
define("OTHERDB_LAN_3", "Identifiant:");
define("OTHERDB_LAN_4", "Mot de passe:");
define("OTHERDB_LAN_5", "Base de données (schéma)");
define("OTHERDB_LAN_6", "Table");
define("OTHERDB_LAN_7", "Champ de l'Identifiant :");
define("OTHERDB_LAN_8", "Champ du mot de passe:");
define("OTHERDB_LAN_9", "Méthode du mot de passe :");
define("OTHERDB_LAN_10", "Configurer l'authentification pour d'autres bases de données");
define("OTHERDB_LAN_11", "** Les champs suivants ne sont pas requis si vous employez une base de données e107");

?>
