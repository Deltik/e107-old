<?php 
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). Licence GNU/GPL
| Traducteurs: communauté francophone e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/online_extended_menu/languages/French.php,v $
|     $Revision: 1.7 $
|     $Date: 2007/02/27 01:57:59 $
|     $Author: daddycool78 $
+---------------------------------------------------------------+
*/
define("ONLINE_EL1", "Invit&eacute;s : "); //ne pas changer cette syntaxe ascii!
define("ONLINE_EL2", "Utilisateurs : ");
define("ONLINE_EL3", "Sur cette page : ");
define("ONLINE_EL4", "En ligne");
define("ONLINE_EL5", "Utilisateurs");
define("ONLINE_EL6", "Dernier utilisateur");
define("ONLINE_EL7", "sur");
define("ONLINE_EL8", "Record :");
define("ONLINE_EL9", "le");
define("ONLINE_TRACKING_MESSAGE", "Le traçeur d'utilisateur en ligne est en ce moment désactivé, activez le [link=".e_ADMIN."users.php?options]ici[/link][br]");
?>
