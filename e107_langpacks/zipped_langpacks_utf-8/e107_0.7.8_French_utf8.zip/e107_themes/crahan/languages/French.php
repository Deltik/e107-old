<?php
define("LAN_THEME_1", "'CraHan' par <a href='http://e107.org' rel='external'>jalist</a>, basé sur le thème de CraHan <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Commentaires désactivés");
define("LAN_THEME_3", "commentaire(s): ");
define("LAN_THEME_4", "Suite...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Commentaire de");
?>
