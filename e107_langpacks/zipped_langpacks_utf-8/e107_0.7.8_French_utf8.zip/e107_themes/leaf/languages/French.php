<?php
define("LAN_THEME_1", "Commentaire(s) ");
define("LAN_THEME_2", "Commentaires désactivés");
define("LAN_THEME_3", "commentaires ");
define("LAN_THEME_4", "Suite...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Commentaire par");
define("LAN_THEME_7", "".GLOBAL_LAN_NEWS_2."");
?>
