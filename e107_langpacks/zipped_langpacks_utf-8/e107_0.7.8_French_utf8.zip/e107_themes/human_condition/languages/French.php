<?php
define("LAN_THEME_1", "'Human Condition' par <a href='http://e107.org' rel='external'>jalist</a>, basé sur le thème Wordpress, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Commentaires désactivés");
define("LAN_THEME_3", "commentaires: ");
define("LAN_THEME_4", "Suite...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Commentaire par");
?>
