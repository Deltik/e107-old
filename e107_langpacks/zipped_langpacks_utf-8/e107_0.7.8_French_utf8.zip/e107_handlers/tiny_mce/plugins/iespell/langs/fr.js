// French lang variables by Laurent Dran
// Modifié par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
iespell_desc : 'Lancer le vérificateur d\'orthographe',
iespell_download : 'Le dictionnaire ieSpell n\'a pas été trouvé.\n\nCliquez sur OK pour vous rendre sur le site de téléchargement.'
});
