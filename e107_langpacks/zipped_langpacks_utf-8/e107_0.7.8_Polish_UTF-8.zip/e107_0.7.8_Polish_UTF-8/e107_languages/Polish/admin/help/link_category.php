<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 14:46:53 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/link_category.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/link_category.php rev. 1.3
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie możesz podzielić swoje linki na różne kategorie, takie działanie uprości nawigację po głównej stronie linków i poprawi cały układ strony.<br /><br />Jakikolwiek link wprowadzony poniżej głównej kategorii będzie wyświetlany w Twoim głównym menu nawigacyjnym.";
$ns -> tablerender("Kategorie linków", $text);

?>
