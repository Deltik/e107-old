<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Pouze pro členy");

define("LAN_MEMBERS_0", "oblast s omezeným vstupem");
define("LAN_MEMBERS_1", "Toto je oblast s omezeným vstupem");
define("LAN_MEMBERS_2","pro přístup se buď <a href='login.php'>přihlašte</a> nebo");
define("LAN_MEMBERS_3","se registrujte");
define("LAN_MEMBERS_4","Klikni zde pro návrat na hlavní stranu");

?>