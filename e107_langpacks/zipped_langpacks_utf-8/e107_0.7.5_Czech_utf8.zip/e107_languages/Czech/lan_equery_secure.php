<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "Nyní používáte administrátorské funkce, které mohou měnit databázi.");
define("EQSEC_LAN2", "Potvrďte prosím tuto akci:");
define("EQSEC_LAN3", "Nikdo neodkazuje (referer)");
define("EQSEC_LAN4", "Akce od:");
define("EQSEC_LAN5", "Akce do:");
define("EQSEC_LAN6", "Potvrdit akci");
define("EQSEC_LAN7", "Nebo zrušit");
?>