<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Vytvořeno systémem pro správu webu e107");
define("LANMAILH_2", "Zpráva je složena z více částí v MIME formátu");
define("LANMAILH_3", " není konkrétně zformátováno");
define("LANMAILH_4", "Server odmítl adresu");
define("LANMAILH_5", "Žádná odezva od serveru");
define("LANMAILH_6", "Nemohu najít emailový server.");
define("LANMAILH_7", " se zdá být v pořádku.");


?>