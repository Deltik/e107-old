<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vhodné pro tisk");
define("LAN_86", "Kategorie:");
define("LAN_87", "od ");
define("LAN_94", "Poslal");
define("LAN_135", "Novinka: ");
define("LAN_303", "Novinka je od ");
define("LAN_304", "Název: ");
define("LAN_305", "Podtitul: ");
define("LAN_306", "Toto je z: ");
define("LAN_307", "Vytisknout tuto stranu");
define("LAN_PRINT_1", "vhodné pro tisk");


?>