<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Diskuse");
define("LAN_30", "Vítejte");
define("LAN_31", "Žádné nové příspěvky");
define("LAN_32", "Máme zde jeden nový příspěvek");
define("LAN_33", "Máme zde");
define("LAN_34", "nových příspěvků (nové příspěvky)");
define("LAN_35", "od Vaší poslední návštěvy.");
define("LAN_36", "Naposledy jste u nás byl");
define("LAN_37", "Teď je");
define("LAN_38", ", a celkově to je");
define("LAN_41", "Nejnovější člen:");
define("LAN_42", "Registrovaných členů:");
define("LAN_44", "Diskusi může použít neregistrovaný uživatel, ale upozorňuji, že Vaše IP adresa je zaznamenána do deníku (logu), pokud vložíte příspěvek.<br />Přístup ke všem funkcím, které tato diskuse nabízí, zajistí jedině");
define("LAN_45", "Diskusi mohou použít pouze regostrovaná a přihlášení uživatelé, klikněte ");
define("LAN_46", "Diskuse");
define("LAN_47", "Vlákno");
define("LAN_48", "Odpovědi");
define("LAN_49", "Poslední příspěvek");
define("LAN_51", "Zatím tu není žádná diskuse, omrkněte to později.");
define("LAN_52", "V této sekci není žádná diskuse, omrkněte to později.");
define("LAN_79", "Nové příspěvky");
define("LAN_80", "Žádné nové příspěvky");
define("LAN_81", "Uzavřené vákno");
define("LAN_100", "články");
define("LAN_180", "Hledat");
define("LAN_191", "Informace");
define("LAN_192", "Uživatelé diskuse vložili již celkově");
define("LAN_196", "Přečetl  jste");
define("LAN_197", "z těchto příspěvků.");
define("LAN_198", "Všechny nové příspěvky jsou již přečtené.");
define("LAN_199", "Označit všechny příspěvky jako přečtené");
define("LAN_204", "<b>Můžete</b> založit nové diskusní vlákno");
define("LAN_205", "<b>Nemůžete</b> založit nové diskusní vlákno");
define("LAN_206", "<b>Můžete</b> odpovídat.");
define("LAN_207", "<b>Nemůžete</b> odpovídat.");
define("LAN_208", "<b>Můžete</b> upravovat Vaše příspěvky");
define("LAN_209", "<b>Nemůžete</b> upravovat Vaše příspěvky");
define("LAN_392", "ukončit sledování tohoto vlákna");
define("LAN_393", "Seznam sledovaných vláken");
define("LAN_394", "Uzavřená diskuse");
define("LAN_397", "Sledované vlákno");
define("LAN_398", "Zavřeno");
define("LAN_399", "Omezeno");
define("LAN_400", "Diskusi mohou prohlížet pouze registrovaní uživatelé");
define("LAN_401", "Pouze pro členy");
define("LAN_402", "Diskuse pouze pro čtení");
define("LAN_403", "Žádné příspěvky");
define("LAN_404", "příspěvky");
define("LAN_405", "pouze ke čtení");
define("LAN_406", "Tato diskuse je pouze pro správce");
define("LAN_407", "Tato diskuse je pouze pro členy");
define("LAN_408", "Tato diskuse je pouze ke čtení");
define("LAN_409", "Diskuse vyhrazena pouze určité skupině uživatelů");
define("LAN_410", "Vítáme hosta");
define("LAN_411", "vláko");
define("LAN_412", "odpověď");
define("LAN_413", "vlákna");
define("LAN_414", "odpovědi");
define("LAN_415", "uživatel si právě prohlíží diskuse");
define("LAN_416", "uživatelů si právě prohlíží diskuse");
define("LAN_417", "člen");
define("LAN_418", "host");
define("LAN_419", "členové");
define("LAN_420", "hosté");
define("LAN_421", "Zobrazit nové příspěvky");
define("LAN_422", "Nové příspěvky od Vaší poslední návštěvy");
define("LAN_423", "Zaslal(a)");
define("LAN_424", "Nová vlákna diskuse");
define("LAN_425", "Odp:");
define("LAN_426", "Přítomni jsou:");
define("LAN_427", "Zobrazit seznam s detaily");
define("LAN_428", "Odp:");
define("LAN_429", "Nejaktivnější pisatelé");
define("LAN_430", "Vlákno s nejvíce příspěvky");
define("LAN_431", "Moje příspěvky");
define("LAN_432", "Moje nastavení");
define("LAN_433", "Pravidla diskuse");
define("LAN_434", "Návrat na diskuse");
define("LAN_435", "Můj profil");
define("LAN_436", "(otevře se do nového okna)");
define("LAN_437", "registrace");
define("LAN_438", "a přihlašte se.");
define("LAN_439", "tady");
define("LAN_440", "přejít na registrační stranu.");


?>