<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("INSLAN1", "Krok instalace");
define("INSLAN2", "PHP / kontrola verze MySQL / kontrola práv přístupu");
define("INSLAN3", "Verze PHP");
define("INSLAN4", "Chyba");
define("INSLAN5", "Provozujete verzi php, která není kompatibilní s e107");
define("INSLAN6", "Skript při běhu zhavaroval");
define("INSLAN7", "Posunout");
define("INSLAN8", "verze MySQL");
define("INSLAN9", "e107 se nepodařilo zjistit verzi MySQL");
define("INSLAN10", "Práva přístupu");
define("INSLAN11", "nemá povolení k zápisu");
define("INSLAN12", "adresář nemá povolení k zápisu");
define("INSLAN13", "Ujistěte se, že vypsané soubory mají korektně nastavená pravá přístupu k souborům <br />na serveru. Práva by měla být nastavena na 777. <br />K nastavení práv použijte nastavení práva k souborům ve Vašem klientovi FTP (obvykle chmod).<br /><br />Test zopakujte, pokud práva změníte.");
define("INSLAN14", "Instaluji e107");
define("INSLAN15", "Fatální chyba");
define("INSLAN16", "Ačkoli se nepodařilo zjistit stav serveru MySQL, <br />můžeme pokračovat dalším krokem.");
define("INSLAN17", "Pokračovat");
define("INSLAN18", "Otestovat práva přístupu k souborům");
define("INSLAN19", "Všechny testy serveru proběhly úspěšně. Klikněte na tlačítko 'Pokračovat dalším krokem'");
define("INSLAN20", "informace o MySQL");
define("INSLAN21", "Zde vložte údaje o databázi MySQL<br />Pokud máte práva uživatele<b>root</b>, lze vytvořit databázi - zaškrtněte políčko k vytvoření db. <br /> Pokud ne, vytvořte databázi jinak nebo použijte existující.<br /> Máte-li k dispozici pouze jednu databázi, použijte prefix, aby mohly i ostatní skripty tuto jedinou databázi sdílet.<br /> Pokud neznáte detaily nastavení pro MySQL, kontaktujte správce systému.");
define("INSLAN22", "server MysSQL");
define("INSLAN23", "uživatelské jméno MySQL");
define("INSLAN24", "heslo MySQL");
define("INSLAN25", "jméno databáze MySQL");
define("INSLAN26", "prefix pro tabulky db");
define("INSLAN27", "Chyba");
define("INSLAN28", "Objevila se chyba");
define("INSLAN29", "Některé nezbytné údaje jste nevyplnil. Překontrolujte znovu údaje pro MySQL a doplňte je.");
define("INSLAN30", "e107 nemůže navázat spojení s databázovým serverem MySQL s využitím informací, které jste zadal.<br /> Vraťte se na předchozí stranu a ujistěte se, že je vše nastaveno správně.");
define("INSLAN31", "kontrola MySQL");
define("INSLAN32", "Spojení se serverem MySQL navázáno a ověřeno.");
define("INSLAN33", "Zkouším vytvořit databázi");
define("INSLAN34", "Nelze vytvořit databázi. Ujistěte se, že máte dostatečná práva databázi vytvořit.");
define("INSLAN35", "Databáze je vytvořena.");
define("INSLAN36", "Klikněte na tlačítko, ať se hnem dál.");
define("INSLAN37", "Zpět na poslední stránku");
define("INSLAN38", "Informace správce (administrátora)");
define("INSLAN39", "Vložte údaje pro hlavního správce webu jako uživatelské jméno, heslo a emailovou adresu.<br /> Údaje budou použity k autorizaci vstupu do oblasti pro správce vašeho webu.<br />Ujistěte se, že jste si správně poznamenali, jaké údaje pro správce zde nastavíte. <br />Tyto údaje nelze již zpětně zjistit.");
define("INSLAN40", "Jméno správce");
define("INSLAN41", "Heslo");
define("INSLAN42", "Potvrzení hesla");
define("INSLAN43", "E-mailová adresa správce");
define("INSLAN44", "Některé položky jste opomněl(a) vyplnit, doplňte je prosím.");
define("INSLAN45", "Zadaná hesla jsou různá, vložte je prosím znovu.");
define("INSLAN46", "nevypadá jako platná e.mailová adresa, vložte ji prosím znovu.");
define("INSLAN47", "Vše nastaveno!");
define("INSLAN48", "e107 má nyní všechny informace, které potřebuje k dokončení instalace.<br /> Klikněte na tlačítko a e107 vytvoří tabulky databáze a uloží veškerá nastavení systému.");
define("INSLAN49", "e107 nemůže uložit hlavní konfigurační soubor na server<br /> Ujistěte se, že soubor <b>e107_config.php</b> má správně nastavená práva přístupu");
define("INSLAN50", "Instalace je dokončena!");
define("INSLAN51", "Vše hotovo");
define("INSLAN52", "e107 je nyní správně nainstalované!<br /> Z důvodu bezpečnosti byste měl(a) nastavit práva<br /> pro soubor <b>e107_config.php</b> na 644.<br /> Smažte také soubor install.php ze serveru hned po tom co klikente na tlačítko níže.");
define("INSLAN53", "Klikněte zde a budete přeneseni na Váš zbrusu nový web!");
define("INSLAN54", "Nelze přečíst datový soubor pro sql<br /><br />Ujistěte se, že soubor <b>core_sql.php</b> existuje a je v adresáři <b>/e107_admin/sql</b>.");
define("INSLAN55", "e107 nemohlo vytvořit všechny nezbytné databázové tabulky<br /> Vyčistěte prosím databázi a odstraňte všechny problémy před tím, než to zkusíme znovu.");
define("INSLAN56", "Vítejte na Vašem zbrusu novém webu!");
define("INSLAN57", "e107 je korektně nainstalované a je připraveno se naplnit obsahem :-)");
define("INSLAN58", "zde najdete dokumentaci a FAQ");
define("INSLAN59", "Díky, že jste si vybrali e107. Doufáme, že naplní Vaše očekávání. <br /> (tuto zprávu lze smazat v sekci správce)");
define("INSLAN60", "zaškrtněte pro vytvoření");
define("INSLAN61", "složka");
define("INSLAN62", "nebo");
define("INSLAN63", "chyba přístupových práv");
define("INSLAN64", "Tento soubor byl vygenerován instalačním skriptem.");
define("INSLAN65", "e107 vyžaduje minimálně verzi 4.1.0");
define("INSLAN66", "Pokud používáte lokální sevrer na svém počítači, je třeba nahrát novou");
define("INSLAN67", "verzi PHP, než budeme pokračovat. Podívejte se na");
define("INSLAN68", "instrukce. Pokud jste");
define("INSLAN69", "zkoušel(a) instalovat e107 na hostingu, je nutné kontaktovat");
define("INSLAN70", "správce serveru, aby nahrál novou verzi PHP.");
define("INSLAN71", "Po instalaci nové verze PHP pusťte znovu tento skript.");
define("INSLAN72", "To může znamenat, že MySQL není nainstalováno anebo není pouze spuštěno, nebo");
define("INSLAN73", "máte verzi, která špatně reportuje své");
define("INSLAN74", "číslo verze (o v5.x se ví, že tento problém občas má). Pokud další krok instalace");
define("INSLAN75", "neproběhne, překontrolujte stav Vaší databáze MySQL.");
define("INSLAN76", "Sekce správce je");
define("INSLAN77", "umístěna zde");
define("INSLAN78", "Klikněte zde a podíváme se do ní. Budete se muset přihlásit uživatelským jménem a heslem, které jste vložil při instalaci.");


?>