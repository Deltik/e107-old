<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Detaily kontaktu");
define("LANCONTACT_02", "Kontaktní formulář");
define("LANCONTACT_03", "Zadejte své jméno:");
define("LANCONTACT_04", "E-mailová adresa:");
define("LANCONTACT_05", "Název zprávy:");
define("LANCONTACT_06", "Zde vložte zprávu:");
define("LANCONTACT_07", "Zaslat kopii zprávy emailem na mou adresu");
define("LANCONTACT_08", "Odeslat");
define("LANCONTACT_09", "Zpráva byla odeslána.");
define("LANCONTACT_10", "Při odesílání se objevila chyba");
define("LANCONTACT_11", "Vaše e-mailová adresa není správná.\n Překontrolujte ji prosím.");
define("LANCONTACT_12", "Zpráva je příliš krátká.");
define("LANCONTACT_13", "Zadejte Název zprávy.");


?>