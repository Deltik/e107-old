<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Všichni (veřejnost)");
define("UC_LAN_1", "Hosté");
define("UC_LAN_2", "Nikdo (neaktivní)");
define("UC_LAN_3", "Členové");
define("UC_LAN_4", "Pouze pro čtení");
define("UC_LAN_5", "Správce");
?>