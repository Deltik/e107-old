<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Mapa webu");
define("LANSM_1", "Mapa webu");
define("LANSM_2", "Domovská stránka");
define("LANSM_3", "(index)");
define("LANSM_4", "Obsah");
define("LANSM_5", "Novinky");
define("LANSM_6", "(kategorie novinek)");
define("LANSM_7", "Zobrazit/skrýt celou mapu webu");
define("LANSM_8", "Odkazy");
define("LANSM_9", "(kategorie odkazů)");
define("LANSM_10", "Diskuse");
define("LANSM_11", "(seznam diskusí)");
define("LANSM_12", "Ke stažení");
define("LANSM_13", "(kategorie souborů ke stažení)");
define("LANSM_14", "Články");
define("LANSM_15", "(kategorie článků)");
define("LANSM_16", "Recenze");
define("LANSM_17", "(kategorie recenzí)");
define("LANSM_18", "Úvodní stránka");
define("LANSM_19", "Členové");
define("LANSM_20", "Statistiky");
define("LANSM_21", "Nastavení uživatele");
define("LANSM_22", "Profil");
define("LANSM_23", "Kategorie:");
define("LANSM_24", "Hlavní rysy");
define("LANSM_25", "Rozšíření");
define("LANSM_26", "Zprávy z kecálka");
define("LANSM_27", "Titulky novinek");
define("LANSM_28", "Starší ankety");
define("LANSM_29", "Obsah");
define("LANSM_30", "(seznam stran)");
define("LANSM_31", "nebo klikni na");
define("LANSM_32", "Seznam registrovaných uživatelů");
define("LANSM_33", "(statistiky webu)");
define("LANSM_34", "(informace o uživateli)");
define("LANSM_35", "(informace o nstavení uživatele)");
define("LANSM_36", "(další strany)");
define("LANSM_37", "Podkategorie:");
define("LANSM_38", "Strany");
define("LANSM_39", "(vláken/odpovědí)");
define("LANSM_40", "Nezažazeno");
define("LANSM_41", "rozbalit/skrýt podkategorii");
define("LANSM_42", "Pokec");
define("LANSM_43", "(všechny příspěvky kecálka)");
define("LANSM_44", "Další strany");
define("LANSM_45", "K zápisu");
define("LANSM_46", "Zapomenuté heslo?");
define("LANSM_47", "Hledej");
define("LANSM_48", "Zaslat novinku");
define("LANSM_49", "Zaslat materiál");
define("LANSM_50", "Nejlepší přispěvatelé");
define("LANSM_51", "Zaslat odkaz");
define("LANSM_52", "Příspěvky uživatele");
define("LANSM_53", "(prohlédnout příspěvky uživatele)");


?>