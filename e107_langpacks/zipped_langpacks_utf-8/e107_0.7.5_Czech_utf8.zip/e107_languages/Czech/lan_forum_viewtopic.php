<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Diskuse");
define("LAN_01", "Diskuse");
define("LAN_02", "Přejít na stranu");
define("LAN_03", "Jdeme");
define("LAN_04", "předchozí");
define("LAN_05", "další");
define("LAN_06", "spojené");
define("LAN_07", "Působiště");
define("LAN_08", "Webová stránka");
define("LAN_09", "Návštěvy od registrace");
define("LAN_10", "Zpět nahoru");
define("LAN_65", "Přeskočit");
define("LAN_66", "Toto téma (vlákno) je uzavřené");
define("LAN_67", "příspěvky");
define("LAN_194", "Host");
define("LAN_195", "Registrovaný uživatel");
define("LAN_321", "Správci diskuse:");
define("LAN_389", "Předchozí téma (vlákno)");
define("LAN_390", "Další téma (vlákno)");
define("LAN_391", "hlídat toto vlákno");
define("LAN_392", "ukončit hlídání tohoto vlákna");
define("LAN_393", "Rychlá odpověď");
define("LAN_394", "Náhled");
define("LAN_395", "Odpověď na téma");
define("LAN_396", "Webová stránka");
define("LAN_397", "E-mail");
define("LAN_398", "Profil");
define("LAN_399", "Privátní zpráva");
define("LAN_400", "Upravit");
define("LAN_401", "Komentovat");
define("LAN_402", "Autor");
define("LAN_403", "Příspěvek");
define("LAN_404", "Není žádné předchozí vlákno");
define("LAN_405", "Není již další vlákno");
define("LAN_406", "Správce diskuse: Upravit");
define("LAN_407", "Správce diskuse: Smazat");
define("LAN_408", "SPrávce diskuse: Přesunout");
define("LAN_409", "Jste si jist(a), že chcete smazat celé toto téma včetně všech příspěvků?");
define("LAN_410", "Opraqvdu mám smazat tuto odpověď?");
define("LAN_411", "zaslal(a)");
define("LAN_412", "Titulek");
define("LAN_413", "Zpráva / report");
define("LAN_414", "Oznámit toto téma správci");
define("LAN_415", "Název vlákna (tématu)");
define("LAN_416", "Vložte Vaše oznámení");
define("LAN_417", "Správce bude na tuto diskusi upozorněn. Můžete mu zaslat zprávu s vysvětlením, o co jde.");
define("LAN_418", "<b>Nepoužívejte</b> tuto diskusi pro kontakt se správcem z nějakého jiného důvodu.");
define("LAN_419", "Zaslat report");
define("LAN_420", "Kliknutím zobrazíte příspěvek");
define("LAN_421", "Vlákno diskuse - zpráva od");
define("LAN_422", "Tento příspěvek byl oznámen z ");
define("LAN_423", "Zprávu nelze odeslat");
define("LAN_424", "Příspěvek byl oznámen správci.<br /> Díky.");
define("LAN_425", "Zpráva od:");
define("LAN_426", "Oznamuji příspěvek z tématu:");
define("LAN_427", "Chyba při zaslání emailu");
define("LAN_428", "Příspěvek byl oznámen");
define("LAN_429", "Návrat do diskuse");
define("LAN_430", "anketa");
define("FORLAN_26", "Odpověď smazána");


?>