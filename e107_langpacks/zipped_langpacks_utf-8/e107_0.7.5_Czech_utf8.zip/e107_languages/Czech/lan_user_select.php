<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Vyberte uživatele");
define("US_LAN_2", "Vyberte třídu uživatele");
define("US_LAN_3", "Všichni uživatelé");
define("US_LAN_4", "Hledat uživatelské jméno");
define("US_LAN_5", "Nalezen(í) uživatel(é)");
define("US_LAN_6", "Hledej");
?>