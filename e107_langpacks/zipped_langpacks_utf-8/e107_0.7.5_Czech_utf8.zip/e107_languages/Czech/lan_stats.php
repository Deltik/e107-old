<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Statistiky");
define("LAN_124", "Celkový počet unikátních zobrazení:");
define("LAN_125", "Celkový počet zorbazení:");
define("LAN_126", "Unikátní zobrazení podle stránek:");
define("LAN_127", "Celkem zobrazení podle stránek:");
define("LAN_128", "Prohlížeč:");
define("LAN_129", "Operační systém:");
define("LAN_130", "Ze kterých zemí/domén se k nám přišli podívat:");
define("LAN_131", "Odkazovače:");
define("LAN_132", "Statistiky webu");
define("LAN_371", "Záznamy do deníku (log) nejsou aktivovány. Zapnout záznamy lze v sekci správce. Klikněte na Zapisovač (Logger) a zaškrtněte Aktivovat Záznamy/Počítání.");
define("LAN_372", "Vlastnosti této stránky jsou vypnuté.");
define("LAN_373", "Zatím žádné statistiky.");
define("LAN_374", "Záznamy jsou vedeny od:");
define("LAN_375", "Zobrazit vše");
define("LAN_376", "Posledních 10 unikátních návštěvníků");
define("LAN_377", "vše");
define("LAN_378", "top 10");
define("LAN_379", "Rozlišení obrazovky");
define("LAN_418", "dnů nazpět.");
define("LAN_419", "Denní průměr");
define("LAN_420", "Týdenní průměr");
define("LAN_421", "Měsíční průměr");
define("LAN_422", "Zatím nelze spočítat");


?>