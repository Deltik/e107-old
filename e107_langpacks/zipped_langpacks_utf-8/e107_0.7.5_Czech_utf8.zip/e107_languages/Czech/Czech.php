﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'cs_CZ');
define("CORE_LC", 'cs');
define("CORE_LC2", 'CZ');
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","Chyba : chybí téma.\\n\\nVyberte si jiné téma ve svém nastavení (oblast správce) nebo nahrajte soubory pro aktuální téma na server.");

//v.616
define("CORE_LAN2"," \\1 napsal(a):");// "\\1" represents the username.
define("CORE_LAN3","přílohy jsou vypnuté");
?>