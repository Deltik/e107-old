<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Kecálek");
define("LAN_11", "Kecálek (všechny příspěvky)");
define("LAN_12", "Příspěvky do kecálka");
define("LAN_13", "zapnuto");
define("LAN_14", "Chyba!");
define("LAN_15", "Nemáte právo zobrazit tuto stranu.");
define("LAN_16", "[ tento příspěvek byl správcem zablokován ]");


?>