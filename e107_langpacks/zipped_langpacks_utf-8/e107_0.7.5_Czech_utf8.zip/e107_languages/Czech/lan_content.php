<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Článek/recenze");
define("LAN_1", "Článek");
define("LAN_2", "Recenze");
define("LAN_3", "Kategorie");
define("LAN_25", "předchozí strana");
define("LAN_26", "další strana");
define("LAN_27", "Zobrazit recenze této kategorie");
define("LAN_28", "Zpět na hlavní stranu recenzí");
define("LAN_29", "moderovat komentáře");
define("LAN_30", "Zpět na hlavní stranu recenzí");
define("LAN_31", "Nic jsem nenašel");
define("LAN_32", "Nejnovější recenze");
define("LAN_33", "recenze");
define("LAN_34", "recenze");
define("LAN_35", "Kategorie recenzí");
define("LAN_36", "Zobrazit články této kategorie");
define("LAN_37", "Zpět na hlavní stránu článků");
define("LAN_38", "hlasovat");
define("LAN_39", "hlasů");
define("LAN_40", "Ja byste ohodnotil tento článek?");
define("LAN_41", "Díky za hodnocení");
define("LAN_42", "Hodnocení");
define("LAN_43", " ");
define("LAN_44", "na");
define("LAN_45", "Kategorie neobsahuje články");
define("LAN_46", "Archív");
define("LAN_47", "Nejnovější články");
define("LAN_48", "články");
define("LAN_49", "článek");
define("LAN_50", "Kategorie článků");
define("LAN_51", "Článek nelze zobrazit.");
define("LAN_52", "Chyba");
define("LAN_53", "Recenzi nelze zobrazit.");
define("LAN_54", "Stránku nelze zobrazit.");
define("LAN_55", "Zatím žádná recenze.");
define("LAN_56", "Zatím žádný článek.");
define("LAN_57", "Články");
define("LAN_58", "Recenze");
define("LAN_59", "Zobrazení");
define("LAN_60", "Obsah");
define("LAN_61", "Nezařazeno");
define("LAN_62", "Archív");
define("LAN_63", "strana");
define("LAN_64", "Článek je hodnocen:");
define("LAN_65", "nehodnoceno");


?>