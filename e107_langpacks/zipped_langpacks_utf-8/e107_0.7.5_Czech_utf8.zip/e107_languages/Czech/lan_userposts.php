<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Příspěvky uživatelů");

define("UP_LAN_0", "Všechny příspěvky v diskuzích pro ");
define("UP_LAN_1", "Všechny komentáře pro ");
define("UP_LAN_2", "Vlákno");
define("UP_LAN_3", "Zobrazení");
define("UP_LAN_4", "Odpovědi");
define("UP_LAN_5", "Poslední příspěvek");
define("UP_LAN_6", "Vlákna");
define("UP_LAN_7", "Žádné komentáře");
define("UP_LAN_8", "Žádné příspěvky");
define("UP_LAN_9", " v/na ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Zásláno v/na");
define("UP_LAN_12", "Hledej");
define("UP_LAN_13", "Komentáře");
define("UP_LAN_14", "Příspěvky v diskuzi");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP adresa");
?>