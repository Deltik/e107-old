<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Web je momentálně mimo provoz");
define("LAN_00", "je momentálně mimo provoz");
define("LAN_01", "Musíme něco naprosto bezodkladného vyřešit a proto jsme na několik málo kvadriliónů pikosekund nuceni uzavřít tento web. Určitě to zabere jen pár chvil. Mrkněte sem brzo znovu.");
?>