<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "provozováno na systému e107");
define("LAN_PREF_2", "e107 Website System");
define("LAN_PREF_3", "Tento web běží na systému<a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, který je poskytován dle podmínek licence <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL.");
define("LAN_PREF_4", "cenzurováno");
define("LAN_PREF_5", "Diskuse");

?>