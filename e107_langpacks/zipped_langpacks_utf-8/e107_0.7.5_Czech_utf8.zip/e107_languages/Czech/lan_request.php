<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("LAN_dl_61", "Chyba stahování (download)");
define("LAN_dl_62", "Soubor nemůžete stáhnout, neboť jste překročil přidělený limit");
define("LAN_dl_63", "Ke stažení tohoto souboru nemáte dostatečná práva.");
define("LAN_dl_64", "Zpět");
define("LAN_dl_65", "Soubor nebyl nalezen");

?>