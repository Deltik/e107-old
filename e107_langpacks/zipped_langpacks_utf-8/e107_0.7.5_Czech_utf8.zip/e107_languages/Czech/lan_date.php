<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "rok");
define("LANDT_02", "měsíc");
define("LANDT_03", "týden");
define("LANDT_04", "den");
define("LANDT_05", "hodina");
define("LANDT_06", "minuta");
define("LANDT_07", "vteřina");
define("LANDT_01s", "roky");
define("LANDT_02s", "měsíce");
define("LANDT_03s", "týdny");
define("LANDT_04s", "dny");
define("LANDT_05s", "hodiny");
define("LANDT_06s", "minuty");
define("LANDT_07s", "vteřiny");

define("LANDT_08", "min");
define("LANDT_08s", "min");
define("LANDT_09", "sek");
define("LANDT_09s", "sek");
define("LANDT_AGO", "zpátky");


?>