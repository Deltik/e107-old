<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Diskuse");
define("LAN_01", "Diskuse");
define("LAN_02", "Zpět nahoru");
define("LAN_03", "Jdeme na to");
define("LAN_53", "Vlákno");
define("LAN_54", "Začal:");
define("LAN_55", "Odpovědi");
define("LAN_56", "Zobrazení");
define("LAN_57", "Nejnovější");
define("LAN_58", "V této diskusi zatím nejsou definována témata.");
define("LAN_59", "Ke vkládání příspěvků do diskuse je potřeba, abyste byli registrováni a přihlášeni. Klikněte na registraci nebo se přihlašte.");
define("LAN_79", "Nové příspěvky");
define("LAN_80", "Žádné nové příspěvky");
define("LAN_81", "Uzavřené téme (vlákno)");
define("LAN_180", "Vyhledávání");
define("LAN_202", "Přišpendlené");
define("LAN_203", "Přišpendlené/uzavřené");
define("LAN_204", "<b>Můžete</b> založit nové téma (vlákno)");
define("LAN_205", "<b>Nemůžete</b> zakládat nová témata (vlákna)");
define("LAN_206", "<b>Můžete</b> vkládat své příspěvky");
define("LAN_207", "<b>Nemůžete</b> vkládat příspěvky");
define("LAN_208", "<b>Můžete</b> upravovat své příspěvky");
define("LAN_209", "<b>Nemůžete</b> upravovat své příspěvky");
define("LAN_316", "Přejít na stranu");
define("LAN_317", "Nic");
define("LAN_321", "Správci diskuse:");
define("LAN_395", "[populární]");
define("LAN_396", "Oznámení");
define("LAN_397", "Diskuse je pouze ke čtení");
define("LAN_398", "Odšpendlit téma (vlákno) diskuse");
define("LAN_399", "Uzamknout vlákno diskuse");
define("LAN_400", "Odemknout vlákno");
define("LAN_401", "Přišpendlit vlákno");
define("LAN_402", "Přesunout téma (vlákno) diskuse");
define("LAN_403", "Přejít na diskusi");
define("LAN_404", "O toto fórum se stará");
define("LAN_405", "uživatel si právě prohlíží tuto diskusi");
define("LAN_406", "uživatelé(ů) si právě prohlíží tuto diskusi");
define("LAN_407", "člen");
define("LAN_408", "host");
define("LAN_409", "členové");
define("LAN_410", "hosté");
define("LAN_411", "Důležitá témata");
define("LAN_412", "Témata diskuse");
define("FORLAN_CLOSE", "Téma je uzavřené.");
define("FORLAN_OPEN", "Téma bylo znovu otevřeno.");
define("FORLAN_STICK", "Téma bylo přišpendleno.");
define("FORLAN_UNSTICK", "Odšpendlené téma.");
define("FORLAN_6", "Smazané vlákno");
define("FORLAN_7", "odpovědi byly smazány");
define("FORLAN_8", "zde");
define("FORLAN_9", "k registraci či přihlášení");
define("FORLAN_10", "Založit nové téma (vlákno)");
define("FORLAN_11", "Nové příspěvky");
define("FORLAN_12", "Žádné nové příspěvky");
define("FORLAN_13", "Nové příspěvky v populárním tématu");
define("FORLAN_14", "Žádné nové příspěvky v populárním tématu");
define("FORLAN_15", "Přišpendlené téma");
define("FORLAN_16", "Uzavřené přišpendlené téma");
define("FORLAN_17", "Vlákno pro oznámení");
define("FORLAN_18", "Uzavřené vlákno (téma)");


?>