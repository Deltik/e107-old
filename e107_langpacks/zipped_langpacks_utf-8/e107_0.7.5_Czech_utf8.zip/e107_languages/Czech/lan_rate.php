<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "hodnocení");
define("RATELAN_1", "hodnocení");
define("RATELAN_2", "jak byste ohodnotil tuto položku?");
define("RATELAN_3", "díky za Váš hlas");
define("RATELAN_4", "zatím nehodnoceno");
define("RATELAN_5", "Hodnotit");

?>