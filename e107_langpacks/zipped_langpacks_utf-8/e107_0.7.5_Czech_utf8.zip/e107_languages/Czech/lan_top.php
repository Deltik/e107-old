<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Nejaktivnější přispěvatelé diskusí");
define("TOP_LAN_1", "Uživatel");
define("TOP_LAN_2", "Počet příspěvků");
define("TOP_LAN_3", "Nejaktivnější komentátoři");
define("TOP_LAN_4", "Komentářů");
define("TOP_LAN_5", "Nejaktivnější chataři");
define("TOP_LAN_6", "Hodnocení webu");

//v.616
define("LAN_1", "Vlákno");
define("LAN_2", "Zaslal");
define("LAN_3", "Zobrazení");
define("LAN_4", "Odpovědi");
define("LAN_5", "Poslední zaslané");
define("LAN_6", "Vlákna");
define("LAN_7", "Nejaktivnější vlákno");
define("LAN_8", "Nejaktivnější přispěvatelé");


?>