<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     Czech Language Pack for e107 Version 0.7
|     Copyright (c) 2006 - translation by Tomas Liska (fox),
|                        - czech language correction by Mirek Dvorak
|     e107 czech support: http://www.fox1.cz
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Diskuse");
define("LAN_01", "Diskuse");
define("LAN_02", "Odpovídám na:");
define("LAN_03", "Nové vlákno");
define("LAN_1", "Normální");
define("LAN_2", "Přilepené");
define("LAN_3", "Oznámení");
define("LAN_4", "Vytvořit anketu");
define("LAN_5", "Anketní otázka:");
define("LAN_6", "Přidat další možnost");
define("LAN_7", "Možnost hlasování:");
define("LAN_8", "Povolit hlasovat všem");
define("LAN_9", "Povolit hlasovat pouze členům");
define("LAN_10", "Přihlásit");
define("LAN_11", "Zapamatovat");
define("LAN_16", "Uživatel:");
define("LAN_17", "Heslo:");
define("LAN_20", "Chyba");
define("LAN_27", "Některé položky jste zapomněl(a) vyplnit.");
define("LAN_28", "Nic jsi neposlal");
define("LAN_29", "Upraveno");
define("LAN_45", "Do těchto diskusí mohou přispívat pouze registrovaní a přihlášení uživatelé, klikni ");
define("LAN_60", "Založit nové vlákno");
define("LAN_61", "Vaše jméno:");
define("LAN_62", "Nadpis:");
define("LAN_63", "Příspěvek:");
define("LAN_64", "Odeslat nové vlákno");
define("LAN_73", "Odpověď:");
define("LAN_74", "Odpovědět na toto vlákno");
define("LAN_77", "Upravit vlákno");
define("LAN_78", "Upravit odpověď");
define("LAN_94", "Zaslal(a)");
define("LAN_95", "Neautorizováno");
define("LAN_96", "Nemůžete upravovat tento příspěvek diskuse.");
define("LAN_100", "Téma vlákna");
define("LAN_101", "Nejnovější");
define("LAN_102", "odpovědi");
define("LAN_103", "Prohlédnout celé vlákno (otevře se do nového okna)");
define("LAN_133", "Díky");
define("LAN_174", "K zápisu");
define("LAN_175", "Přihlášení");
define("LAN_212", "Zapomněl(a) jsi heslo?");
define("LAN_310", "Nelze přijmout příspěvek pod tímto jménem, neboť se jedná o registrované jméno. Pokud je Vaše, přihlašte se.");
define("LAN_311", "Anonym");
define("LAN_322", "Zasláno:");
define("LAN_323", "Náhled");
define("LAN_324", "Váš příspěvek je zařazenen do diskuse.");
define("LAN_325", "Zobrazit Váš příspěvek");
define("LAN_326", "Vrátit se do diskuse");
define("LAN_327", "Náhled");
define("LAN_380", "Zaškrtněte políčko pokud si přejete dostat e-mail s oznámením, že v tomto vlákně někdo vložil odpověď.");
define("LAN_381", "Odpověď v diskusi od");
define("LAN_382", "Zasláno:");
define("LAN_383", "Klikněte na odkaz a zobrazí se celá diskuse");
define("LAN_384", "Odpověď v diskusi v");
define("LAN_385", "Příspěvek");
define("LAN_386", "Pokud nechcete přidat do Vašeho vlákna příspěvek, ponechte políčka nevyplněná.");
define("LAN_387", "Jedem...");
define("LAN_388", "Zpět nahoru");
define("LAN_389", "Duplicitní příspěvek, přesměrování...");
define("LAN_390", "Přiložit soubor / obrázek");
define("LAN_391", "Možnost");
define("LAN_392", "Přikládaný soubor");
define("LAN_393", "<b>Povšimněte si prosím</b><br />Povolené typy souborů jsou:");
define("LAN_394", "Jiné typy souborů než povolené budou rovnou smazány");
define("LAN_395", "Maximální povolená velikost souboru");
define("LAN_396", "bajtů");
define("LAN_397", "Vlákno je zamčené.");
define("LAN_398", "Diskuse je pouze ke čtení");
define("LAN_399", "Do této diskuse nemůžete přispívat.");
define("LAN_400", "vložit vlákno jako");
define("LAN_401", "Skok");
define("LAN_402", "anketa");
define("LAN_403", "oznámení");
define("LAN_404", "přišpendlené");
define("LAN_405", "Diskuse");
define("LAN_406", "Odp:");
define("LAN_407", "Přesměrování");
define("LAN_408", "Pokud Váš prohlížeč nepodporuje meta príkaz přesmerování, klikněte ");
define("LAN_409", "ZDE");
define("LAN_410", "a budete přesměrováni");
define("LAN_411", "zde");
define("LAN_412", "na stránku s registrací.");


?>