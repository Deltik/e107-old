<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:04 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_top.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_top.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("TOP_LAN_0", "Najwięcej postów na forum");
define("TOP_LAN_1", "Użytkownik");
define("TOP_LAN_2", "Postów");
define("TOP_LAN_3", "Najwięcej komentarzy");
define("TOP_LAN_4", "Komentarze");
define("TOP_LAN_5", "Najwięcej postów na czacie");
define("TOP_LAN_6", "Ranga na stronie");

//v.616
define("LAN_1", "Temat");
define("LAN_2", "Autor");
define("LAN_3", "Odsłon");
define("LAN_4", "Posty");
define("LAN_5", "Ostatni post");
define("LAN_6", "Tematy");
define("LAN_7", "Aktywne tematy");
define("LAN_8", "Najwięcej napisali");

?>
