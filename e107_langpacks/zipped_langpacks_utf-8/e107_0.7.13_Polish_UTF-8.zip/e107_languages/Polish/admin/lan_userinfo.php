<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 22:38:19 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_userinfo.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_userinfo.php rev. 1.
+-----------------------------------------------------------------------------+
*/
 
define("USFLAN_1", "Nie mogę znaleźć adresu IP nadawcy - brak dostępnych informacji.");
// define("USFLAN_2", "Błąd");
define("USFLAN_3", "Wiadomości zostały nadesłane z adresu IP");
define("USFLAN_4", "Nazwa hosta");
define("USFLAN_5", "Kliknij tutaj, aby przetransferować adres IP do listy blokowanych");
define("USFLAN_6", "ID użytkownika");
define("USFLAN_7", "Informacje o użytkowniku");

?>
