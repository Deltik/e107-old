<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2006/08/27 22:38:19 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_updateadmin.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_updateadmin.php rev. 1.
+-----------------------------------------------------------------------------+
*/
 
define("UDALAN_1", "Błąd - proszę ponowić wysyłanie");
define("UDALAN_2", "Ustawienia zostały zaktualizowane");
define("UDALAN_3", "Ustawienia zostały zaktualizowane dla");
define("UDALAN_4", "Nazwa");
define("UDALAN_5", "Hasło");
define("UDALAN_6", "Powtórz hasło");
define("UDALAN_7", "Zmień hasło");
define("UDALAN_8", "Aktualizacja hasła dla");

?>
