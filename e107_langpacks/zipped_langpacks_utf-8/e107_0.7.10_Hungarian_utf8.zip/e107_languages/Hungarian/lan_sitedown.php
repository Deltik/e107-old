<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Az oldal átmenetileg zárva");
define("LAN_SITEDOWN_00", "átmenetileg zárva");
define("LAN_SITEDOWN_01", "Karbantartás miatt az oldalt átmenetileg lezártuk. Nem tart sokáig - látogass vissza hamarosan, elnézést kérünk a kellemetlenségért.");
?>
