<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NP_1", "Előző oldal");
define("NP_2", "Következő oldal");
define("NP_3", "Oldal:");

?>
