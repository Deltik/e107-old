<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LANDT_01", "év");
define("LANDT_02", "hónap");
define("LANDT_03", "hét");
define("LANDT_04", "nap");
define("LANDT_05", "óra");
define("LANDT_06", "perc");
define("LANDT_07", "másodperc");
define("LANDT_01s", "év");
define("LANDT_02s", "hónap");
define("LANDT_03s", "hét");
define("LANDT_04s", "nap");
define("LANDT_05s", "óra");
define("LANDT_06s", "perc");
define("LANDT_07s", "másodperc");

define("LANDT_08", "perc");
define("LANDT_08s", "perc");
define("LANDT_09", "mp");
define("LANDT_09s", "mp");
define("LANDT_AGO", "ezelőtt");

?>
