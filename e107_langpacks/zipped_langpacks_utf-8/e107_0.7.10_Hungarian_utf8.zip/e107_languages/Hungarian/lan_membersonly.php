<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Csak tagoknak");

define("LAN_MEMBERS_0", "Korlátozott terület");
define("LAN_MEMBERS_1", "Ez egy korlátozott terület,");
define("LAN_MEMBERS_2", "A hozzáféréshez <a href='".e_LOGIN."'>jelentkezz be</a>");
define("LAN_MEMBERS_3", "vagy <a href='".e_SIGNUP."'>regisztrálj</a> az oldalon!");
define("LAN_MEMBERS_4", "Kérlek menj vissza a főoldalra!");

?>
