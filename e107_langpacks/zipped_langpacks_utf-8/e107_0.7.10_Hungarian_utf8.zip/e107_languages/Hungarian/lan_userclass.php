<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UC_LAN_0", "Mindenki (Publikus)");
define("UC_LAN_1", "Csak Vendégek");
define("UC_LAN_2", "Senki (inaktív)");
define("UC_LAN_3", "Csak tagok");
define("UC_LAN_4", "Csak olvasási jog");
define("UC_LAN_5", "Csak adminok");
define("UC_LAN_6", "Csak Főadmin");
?>
