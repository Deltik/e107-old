<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Nyomtatóbarát változat");}

define("LAN_PRINT_86", "Kategória:");
define("LAN_PRINT_87", "Írta: ");
define("LAN_PRINT_94", "Küldte:");
define("LAN_PRINT_135", "Hír: ");
define("LAN_PRINT_303", "Ezen hír származási helye: ");
define("LAN_PRINT_304", "Cím: ");
define("LAN_PRINT_305", "Alcím: ");
define("LAN_PRINT_306", "A cikk származási helye: ");
define("LAN_PRINT_307", "Oldal nyomtatása");

define("LAN_PRINT_1", "Nyomtatóbarát változat");

?>
