<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UE_LAN_1", "Szövegmező");
define("UE_LAN_2", "Rádiógombok");
define("UE_LAN_3", "Lenyíló menü");
define("UE_LAN_4", "Adatbázis tábla mező");
define("UE_LAN_5", "Szövegmező");
define("UE_LAN_6", "Egész");
define("UE_LAN_7", "Dátum");
define("UE_LAN_8", "Nyelv");

define("UE_LAN_9", "Név");
define("UE_LAN_10", "Típus");
define("UE_LAN_11", "Használat");

define("UE_LAN_HIDE", "Elrejtés");

define("UE_LAN_LOCATION", "Lakóhely");
define("UE_LAN_LOCATION_DESC", "Felhasználó lakóhelye");
define("UE_LAN_AIM", "AIM cím");
define("UE_LAN_AIM_DESC", "AIM cím");
define("UE_LAN_ICQ", "ICQ szám");
define("UE_LAN_ICQ_DESC", "ICQ szám");
define("UE_LAN_YAHOO", "Yahoo! cím");
define("UE_LAN_YAHOO_DESC", "Yahoo! cím");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN cím");
define("UE_LAN_HOMEPAGE", "Weboldal");
define("UE_LAN_HOMEPAGE_DESC", "Felhasználó weboldala (url)");
define("UE_LAN_BIRTHDAY", "Születésnap");
define("UE_LAN_BIRTHDAY_DESC", "Születésnap");
define("UE_LAN_LANGUAGE", "Nyelv");
define("UE_LAN_LANGUAGE_DESC", "Felhasználó Nyelv");
define("UE_LAN_COUNTRY", "Ország");
define("UE_LAN_COUNTRY_DESC", "Felhasználó Ország (includes db table)");

define("LAN_UE_FAIL_HOMEPAGE", "Érvénytelen bejegyzés a weboldal beállításokhoz");
?>
