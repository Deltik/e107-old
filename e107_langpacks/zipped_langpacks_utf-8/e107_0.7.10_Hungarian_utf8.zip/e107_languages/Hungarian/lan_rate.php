<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("RATELAN_0", "szavazat");
define("RATELAN_1", "szavazat");
define("RATELAN_2", "Hogyan értékeled?");
define("RATELAN_3", "Köszönjük szavazatodat!");
define("RATELAN_4", "nincs értékelés");
define("RATELAN_5", "Értékelés");


?>
