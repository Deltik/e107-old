<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_CHECK_1", "Válassz nyelvet az ellenőrzéshez");
define("LAN_CHECK_2", "Ellenőrzés indítása");
define("LAN_CHECK_3", "Ellenőrzés");
define("LAN_CHECK_4", "Hiányzó file!");
define("LAN_CHECK_5", "Hiányzó kifejezés!");

define("LAN_CHECK_7", "kifejezés");

define("LAN_CHECK_8", "A fájl hiányzik...");
define("LAN_CHECK_9", " hiányzó fájl...");
define("LAN_CHECK_10", "Kritikus hiba: ");
define("LAN_CHECK_11", "Nincs hiányzó fájl!");
define("LAN_CHECK_12", "Egy fájl hibás...");
define("LAN_CHECK_13", " fájl hibás...");
define("LAN_CHECK_14", "Minden file jó!");

define("LAN_CHECK_15", "Illegális karakterek a '&lt;?php' előtt");
define("LAN_CHECK_16", "Eredeti File");
define("LAN_CHECK_17", "Egy írási probléma keletkezett a file mentése során.");
define("LAN_CHECK_18", "Szabvány formában a nyelvi file nem engedélyezett ehhez a plugin-hoz/theme-hez.");
define("LAN_CHECK_19", "Nem-UTF-8 karakterek!");
?>
