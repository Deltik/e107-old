<?php
$caption = "Letöltések súgó";
$text = "Töltsd fel a fájlokat a(z) ".$FILES_DIRECTORY."downloads könyvtárba, a képeket a(z) ".$FILES_DIRECTORY."downloadimages könyvtárba és a thumbnail képeket a(z) ".$FILES_DIRECTORY."downloadthumbs könyvtárba.
<br /><br />
Letöltés felvételéhez, először hozz létre egy kezdőt, majd ez alatt készíts egy kategóriát, és ezek után tudsz felvinni letöltést.";
$ns -> tablerender($caption, $text);
?>
