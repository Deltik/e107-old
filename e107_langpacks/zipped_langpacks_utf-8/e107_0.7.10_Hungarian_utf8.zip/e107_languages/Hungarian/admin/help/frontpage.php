<?php
$caption = "Kezdőlap súgó";
$text = "Kiválaszthatod, hogy mi jelenjen meg a főoldalon. Ez alapértelmezésben a hírek. Beállíthatod ún. 'splashscreen'-nek is, ami csak a felhasználó első látogatásakor jelenik meg.";
$ns -> tablerender($caption, $text);
?>
