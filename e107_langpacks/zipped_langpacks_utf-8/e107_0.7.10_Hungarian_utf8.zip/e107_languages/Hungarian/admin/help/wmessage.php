<?php
$caption = "Üdvözlő üzenet súgó";
$text = "Üdvözlő üzenetet állíthatsz be, mely ha aktív, mindig az oldal tetején, a hírek fölött jelenik meg. Különböző üzeneteket adhatsz meg a vendégeknek, tagoknak, adminoknak.";
$ns -> tablerender($caption, $text);
?>
