<?php
$caption = "Felhasználó csoportok súgó";
$text = "Új  csoportokat hozhatsz itt létre, illetve módosíthatod/törölheted a meglévőket.<br />Ez hasznos, ha a felhasználók egy csoportját az oldal egy részére akarod korlátozni. Például létrehozhatsz egy TESZT nevű csoportot, majd egy fórumot, ahol beállítod, hogy csak a TESZT nevű csoport tagjai érhessék el.";
//$text .="<br /> Ezen módszerrel könnyen létrehozható egy CSAK TAGOKNAK részleg az oldalon belül.";
$ns -> tablerender($caption, $text);
?>
