<?php
$caption = "Meta tag-ek súgó";
$text = "Meta tag-ek beállítása a keresőrobotok részére.";
$ns -> tablerender($caption, $text);
?>
