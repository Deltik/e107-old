<?php
$caption = "Admin jelszó módosítása súgó";
$text = "Itt frissítheted a jelszavad. Ha a legutóbbi jelszómódosításod óta 30 nap eltelt, a rendszer figyelmeztetni fog a jelszócserére.";
$ns -> tablerender($caption, $text);
?>
