<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("MESSLAN_1", "Fogadott üzenet");
define("MESSLAN_2", "Üzenet törlése");
define("MESSLAN_3", "Üzenet törölve.");
define("MESSLAN_4", "Összes üzenet törlése");
define("MESSLAN_5", "Megerősítés");
define("MESSLAN_6", "Összes üzenet törölve.");
define("MESSLAN_7", "Nincs üzenet.");
define("MESSLAN_8", "Üzenet típusa");
define("MESSLAN_9", "Küldés ideje");

define("MESSLAN_10", "Küldő");
define("MESSLAN_11", "megnyitás új ablakban");
define("MESSLAN_12", "Üzenet");
define("MESSLAN_13", "Link");
?>
