<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 1.8 $
|     $Date: 2007/02/11 10:33:58 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Kitiltás kikapcsolva.");
define("BANLAN_2", "Nincs kitiltás.");
define("BANLAN_3", "Érvényben lévő kitiltások");
define("BANLAN_4", "Kitiltás törlése");
define("BANLAN_5", "Add meg az IP címet, az e-mail címet vagy a host-ot");
define("BANLAN_7", "Indoklás");
define("BANLAN_8", "Felhasználó kitiltása");
define("BANLAN_9", "Felhasználók kitiltása Email, IP vagy kiszolgálócím alapján");
define("BANLAN_10", "IP / E-mail cím / Indok");
define("BANLAN_11", "Automatikus-Kitiltás: Több, mint 10 hibás bejelentkezési kisérlet");
define("BANLAN_12", "Megjegyzés: A DNS megváltoztatása jelenleg letiltva, a host alapján történő kitiltáshoz engedélyezni kell. Az IP és email alapján történő kitiltás még normálisan műkődik.");
define("BANLAN_13", "Megjegyzés: Egy felhasználó kitiltásához a felhasználónév alapján, lépj a felhasználók admin felületre: ");

?>
