<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UCSLAN_1", "Összes felhasználó törölve a csoportból");
define("UCSLAN_2", "Csoport frissítve.");
define("UCSLAN_3", "Csoport törölve");
define("UCSLAN_4", "Csoport törlésének megerősítéséhez pipáld ki a dobozt");
define("UCSLAN_5", "Csoport frissítve.");
define("UCSLAN_6", "Csoport elmentve");
define("UCSLAN_7", "Nincsenek csoportok");
define("UCSLAN_8", "Meglévő csoportok");

//define("UCSLAN_9", "Módosítás");
//define("UCSLAN_10", "Törlés");
define("UCSLAN_11", "Megerősítés");
define("UCSLAN_12", "Csoport név");
define("UCSLAN_13", "Csoport leírás");
define("UCSLAN_14", "Csoport frissítése");
define("UCSLAN_15", "Új csoport létrehozása");
define("UCSLAN_16", "Felhasználó besorolása a csoportba");
define("UCSLAN_17", "Eltávolítás");
define("UCSLAN_18", "Csoport ürítése");
define("UCSLAN_19", "Felhasználó(k) besorolása a(z)");
define("UCSLAN_20", "csoportba");
define("UCSLAN_21", "Csoport beállítások");

define("UCSLAN_22", "Felhasználók - klikk a mozgatáshoz");
define("UCSLAN_23", "Felhasználók a csoportban");

define("UCSLAN_24", "Kik módosíthatják a csoportot");

?>