<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Felhasználói hozzászólások/üzenetek");

define("UP_LAN_0", "összes fórum üzenete ");
define("UP_LAN_1", "összes hozzászólása ");
define("UP_LAN_2", "Téma");
define("UP_LAN_3", "Megnézem");
define("UP_LAN_4", "Másolatok");
define("UP_LAN_5", "Utolsó üzenete");
define("UP_LAN_6", "Témák");
define("UP_LAN_7", "Nincs hozzászólás");
define("UP_LAN_8", "Nincs fórumüzenet");
define("UP_LAN_9", " - ");
define("UP_LAN_10", "Válasz");
define("UP_LAN_11", "Írta: ");
define("UP_LAN_12", "Keresés");
define("UP_LAN_13", "hozzászólás");
define("UP_LAN_14", "fórumüzenet");
define("UP_LAN_15", "Válasz");
define("UP_LAN_16", "IP cím");
?>
