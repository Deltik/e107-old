<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NWSLAN_1", "Hír törölve.");
define("NWSLAN_2", "Jelöld be a megerősítő box-ot a hír törléséhez.");
define("NWSLAN_3", "Nincsenek hírek.");
define("NWSLAN_4", "Jelenlegi hírek");
define("NWSLAN_5", "HTML szerkesztő megnyitása");
define("NWSLAN_6", "Kategória");
define("NWSLAN_7", "Szerkesztés");
define("NWSLAN_8", "Törlés");
define("NWSLAN_9", "jelöld be a megerősítéshez");
define("NWSLAN_10", "Nincsenek kategóriák beállítva.");
define("NWSLAN_11", "Kategóriák hozzáadása/módosítása");
define("NWSLAN_12", "Cím");
define("NWSLAN_13", "Törzs");
define("NWSLAN_14", "Bővített");
define("NWSLAN_15", "Hozzászólások");
define("NWSLAN_16", "Engedélyezve");
define("NWSLAN_17", "Letiltva");
define("NWSLAN_18", "Hozzászólások engedélyezése ehhez a hírhez");
define("NWSLAN_19", "Aktiválás");
define("NWSLAN_20", "Hagyd üresen az automatikus aktiválás letiltásához");
define("NWSLAN_21", "Aktív időszak");
define("NWSLAN_22", "Elérhetőség");
define("NWSLAN_23", "Ha bejelölöd, csak az ebbe a csoportba tartozó tagok látják");
define("NWSLAN_24", "Ismételt előnézet");
define("NWSLAN_25", "Hír frissítése");
define("NWSLAN_26", "Hír beküldése");
define("NWSLAN_27", "Előnézet");
define("NWSLAN_28", "Új történet");
define("NWSLAN_29", "Hír beküldése");

define("NWSLAN_30", "Csak a cím mutatása");

?>
