<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("PAGE_NAME", "Linkek");

define("LAN_61", "Link kategóriák");
define("LAN_62", "kategóriában");
define("LAN_63", "kategóriában");
define("LAN_64", "ebben a kategóriában");
define("LAN_65", "link");
define("LAN_66", "link");
define("LAN_67", "Összes link megjelenítése");
define("LAN_68", "Szerkesztés");
define("LAN_69", "Törlés");
define("LAN_86", "Kategória:");
define("LAN_88", "Hivatkozások:");
define("LAN_89", "Admin: ");
define("LAN_90", "Új link hozzáadása a kategóriához");
define("LAN_91", "Új kategória létrehozása");

define("LAN_92", "Link beküldése");
define("LAN_93", "A beküldött linket az admin megvizsgálja, ha megfelel a követelményeknek, bekerül a linkek közé.");
define("LAN_94", "Link neve:");
define("LAN_95", "Link URL-je:");
define("LAN_96", "Link leírása:");
define("LAN_97", "URL a link gombhoz:");
define("LAN_98", "Link beküldése");

define("LAN_99", "Köszönjük");
define("LAN_100", "A link elmentve, az admin meg fogja vizsgálni.");
define("LAN_101", "Link beküldése");

define("LAN_102", "Itt");
define("LAN_103", "van");
define("LAN_104", "van");
define("LAN_105", "összesen");
define("LAN_106", "Az aláhúzott mezők kötelezők.");

define("LAN_Links_1", "Összes link");
define("LAN_Links_2", "Összes aktivált link");
define("LAN_LINKS_3", "Anonymous");
?>
