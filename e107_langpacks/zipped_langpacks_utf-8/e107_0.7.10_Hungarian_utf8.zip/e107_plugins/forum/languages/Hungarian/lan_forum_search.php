<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.3 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FOR_SCH_LAN_1", "Fórum");
define("FOR_SCH_LAN_2", "Fórum kiválasztása");
define("FOR_SCH_LAN_3", "Összes fórum");
define("FOR_SCH_LAN_4", "Teljes üzenet");
define("FOR_SCH_LAN_5", "Mint a téma része");
?>
