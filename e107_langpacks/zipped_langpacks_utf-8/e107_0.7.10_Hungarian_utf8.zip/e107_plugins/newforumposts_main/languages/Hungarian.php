<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("NFPM_LAN_1", "Téma");
define("NFPM_LAN_2", "Beküldő");
define("NFPM_LAN_3", "Megtekintések");
define("NFPM_LAN_4", "Válaszok");
define("NFPM_LAN_5", "Utolsó üzenet");
define("NFPM_LAN_6", "Témák");
define("NFPM_LAN_7", "Írta: ");

define("NFPM_L1", "Ez a plugin megjeleníti az új fórumüzenetek listáját a főoldalon");
define("NFPM_L2", "Legutóbbi fórumüzenetek");
define("NFPM_L3", "A beállításokat elvégezheted az Admin részlegben");
define("NFPM_L4", "Hol legyen bekapcsolva?");
define("NFPM_L5", "Kikapcsolt");
define("NFPM_L6", "Lap teteje");
define("NFPM_L7", "Lap alja");
define("NFPM_L8", "Fejléc");
define("NFPM_L9", "Megjelenítendő hozzászólások száma");
define("NFPM_L10", "Megjelenítés görgethető rétegen?");
define("NFPM_L11", "Réteg magassága");
define("NFPM_L12", "Új fórum hozzászólások beállítása");
define("NFPM_L13", "Beállítások frissítése");
define("NFPM_L14", "Beállítások frissítve.");
define("NFPM_L15", "Utolsó hozzászólások megjelenítése.<br />Alapértelmezett: utolsó témák megjelenítése.");
define('NFPM_L16', '[felhasználó törölve]');

?>
