<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_190", "Reviews");
define("LAN_RVW_1", "Bijwerken menu configuratie");
define("LAN_RVW_2", "Reviews menu configuratie opgeslagen");
define("LAN_RVW_3", "Koptekst");
define("LAN_RVW_4", "Aantal te tonen reviews");
define("LAN_RVW_5", "Toon review categorieën in menu?");
define("LAN_RVW_6", "Titel voor review overzichtspagina");
define("LAN_RVW_7", "Toon link om een review aan te melden?");
define("LAN_RVW_8", "Review menu configuratie");

?>