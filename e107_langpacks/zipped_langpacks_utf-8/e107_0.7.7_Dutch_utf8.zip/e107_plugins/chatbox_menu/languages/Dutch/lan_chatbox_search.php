<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Dutch/lan_chatbox_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/03 05:59:15 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");

?>