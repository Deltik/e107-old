<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CM_L1", "Nog geen reacties.");
define("CM_L2", "");
define("CM_L3", "Titelbalk");
define("CM_L4", "Aantal te tonen reacties?");
define("CM_L5", "Aantal te tonen tekens?");
define("CM_L6", "Postfix voor te lange reacties?");
define("CM_L7", "Tonen originele nieuwstitel in menu?");
define("CM_L8", "Nieuwe reacties menu configuratie");
define("CM_L9", "Bijwerken menu instellingen");
define("CM_L10", "Reacties menu configuratie opgeslagen");
define("CM_L11", "op");
define("CM_L12", "Over:")
define("CM_L13", "Geplaatst door");
?>