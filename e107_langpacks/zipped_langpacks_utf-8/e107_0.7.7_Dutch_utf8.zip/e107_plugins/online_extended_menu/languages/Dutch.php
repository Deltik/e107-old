<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("TRACKING_MESSAGE", "Het volgen van gebruikers is niet geactiveerd, dat kun je <a href='".e_ADMIN."users.php?options'>hier</a> doen</span><br />");
define("ONLINE_EL1", "Gasten: ");
define("ONLINE_EL2", "Leden: ");
define("ONLINE_EL3", "Op deze pagina: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Leden");
define("ONLINE_EL6", "Nieuwste lid");
define("ONLINE_EL7", "bekijkt");
define("ONLINE_EL8", "Max. gelijk online: ");
define("ONLINE_EL9", "op");
?>