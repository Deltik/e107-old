<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/leaf/languages/Dutch.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/09/09 13:58:25 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Reactie(s) ");
define("LAN_THEME_2", "Reageren op dit onderwerp niet mogelijk");
define("LAN_THEME_3", "reactie(s) ");
define("LAN_THEME_4", "Lees verder ...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "Reactie door");


?>
