<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        lan_subcontent.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 14th Sep 2004
+---------------------------------------------------------------+
*/

define("ARLAN_0", "Hartelijk dank, je artikel is opgeslagen en zal zo snel mogelijk worden beoordeeld door een beheerder.");
define("ARLAN_1", "Veld(en) niet ingevuld.");
define("ARLAN_2", "Hartelijk dank, je review is opgeslagen en zal zo snel mogelijk worden beoordeeld door een beheerder.");
define("ARLAN_15", "Aanmelden artikel");
define("ARLAN_17", "Kop");
define("ARLAN_18", "Onderkop");
define("ARLAN_19", "Samenvatting");
define("ARLAN_20", "Artikel");
define("ARLAN_21", "Reageren toestaan?");
define("ARLAN_22", "Aan");
define("ARLAN_23", "Uit");
define("ARLAN_24", "Toevoegen e-mail/afdruk pictogrammen?");
define("ARLAN_25", "Ja");
define("ARLAN_26", "Nee");
define("ARLAN_27", "Aanmelden artikel");
define("ARLAN_28", "Bekijk");
define("ARLAN_55", "Zichtbaar voor");
define("ARLAN_73", "Open HTML Editor");
define("ARLAN_74", "Categorie");
define("ARLAN_75", "Geen");
define("ARLAN_82", "Auteursgegevens");
define("ARLAN_84", "naam auteur");
define("ARLAN_85", "e-mailadres auteur");
define("ARLAN_86", "Review");
define("ARLAN_87", "Waardering");
define("ARLAN_88", "Kies de score");
define("ARLAN_89", "Aanmelden review");
define("ARLAN_90", "Veld(en) niet ingevuld, druk op de terug knop in de browser en bevestig dat alle velden zijn ingevuld.");
define("ARLAN_91", "Bekijk nogmaals");
define("ARLAN_92", "Geef je naam en e-mailadres op");
define("ARLAN_93", "artikel");
define("ARLAN_94", "review");
define("ARLAN_95", "Aanmelden van artikelen is nu niet mogelijk");
define("ARLAN_96", "Aanmelden van reviews is nu niet mogelijk");
define("ARLAN_97", "Je hebt niet de juiste rechten om artikelen aan te melden");
define("ARLAN_98", "Je hebt niet de juiste rechten om reviews aan te melden");
define("ARLAN_99", "Wat wil je aanmelden?");
define("ARLAN_100", "Nieuws");
define("ARLAN_101", "Gebeurtenis");
define("ARLAN_102", "Artikel");
define("ARLAN_103", "Review");
define("ARLAN_104", "Link");
define("ARLAN_105", "Download");
define("ARLAN_106", "Aanmelden");

?>