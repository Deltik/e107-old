<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_db_verify.php Dutch-utf language file
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("DBLAN_1", "Het sql definitiebestand is niet te lezen&lt;br /&gt;&lt;br /&gt;Let erop dat het bestand &lt;b&gt;core_sql.php&lt;/b&gt; aanwezig is in de directory &lt;b&gt;/admin/sql&lt;/b&gt;.");
define("DBLAN_2", "Alles verifieëren");
define("DBLAN_4", "Tabel");
define("DBLAN_5", "Veld");
define("DBLAN_6", "Status");
define("DBLAN_7", "Opmerkingen");
define("DBLAN_8", "Afwijking");
define("DBLAN_9", "Huidige");
define("DBLAN_10", "moet zijn");
define("DBLAN_11", "Ontbrekend veld");
define("DBLAN_12", "Extra veld!");
define("DBLAN_13", "Ontbrekende tabel!");
define("DBLAN_14", "Kies de te verifieëren tabel(len)");
define("DBLAN_15", "Start verificatie");
define("DBLAN_16", "SQL verificatie - versie");
define("DBLAN_17", "Terug");
define("DBLAN_18", "tabellen");
define("DBLAN_19", "Herstelpoging");
define("DBLAN_20", "Poging tot herstellen van tabellen");
define("DBLAN_21", "Herstellen geselecteerde onderdelen");

?>