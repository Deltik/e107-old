<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_filemanager.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 18th Sep 2004
+---------------------------------------------------------------+
*/

define("FMLAN_1", "Ge-upload");
define("FMLAN_2", "naar");
define("FMLAN_3", "directorie");
define("FMLAN_4", "Het ge-uploade bestand is groter dan de waarde maximum upload_max_filesize in php.ini.");
define("FMLAN_12", "bestand");
define("FMLAN_13", "bestanden");
define("FMLAN_14", "directory");
define("FMLAN_15", "directories");
define("FMLAN_16", "Hoofddirectorie");
define("FMLAN_17", "Naam");
define("FMLAN_18", "Grootte");
define("FMLAN_19", "Laatst gewijzigd");
define("FMLAN_21", "Upload bestanden naar deze map");
define("FMLAN_22", "Upload");
define("FMLAN_26", "Verwijderd");
define("FMLAN_27", "succesvol");
define("FMLAN_28", "Kan niet verwijderen");
define("FMLAN_29", "Pad");
define("FMLAN_30", "Niveau omhoog");
define("FMLAN_31", "map");
define("FMLAN_32", "Kies directory");
define("FMLAN_33", "Selecteer");
define("FMLAN_34", "Directory keuze");
define("FMLAN_35", "Bestandsdirectory");
define("FMLAN_36", "Maatwerkmenu's directory");
define("FMLAN_37", "Maatwerkpagina's directory");
define("FMLAN_38", "Bestand succesvol verplaatst naar");
define("FMLAN_39", "Kon bestand niet verplaatsen naar");
define("FMLAN_40", "Nieuwsafbeeldingen directory");
define("FMLAN_43", "Verwijder geselecteerde bestanden");
define("FMLAN_46", "Bevestig dat je de geselecteerde bestanden wilt VERWIJDEREN.");
define("FMLAN_47", "Leden uploads"); 
define("FMLAN_48", "Verplaatst selectie naar");
define("FMLAN_49", "Bevestig dat je de geselecteerde bestanden wilt verplaatsen.");
define("FMLAN_50", "Verplaatsen");

?>