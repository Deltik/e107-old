<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_emoticon.php Dutch-utf language file
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("EMOLAN_1", "Smiley instellingen bijgewerkt.");
define("EMOLAN_2", "Smiley toegevoegd.");
define("EMOLAN_3", "Smiley verwijderd.");
define("EMOLAN_4", "Activeren Smileys?");
define("EMOLAN_5", "Afbeelding");
define("EMOLAN_6", "Smiley Code");
define("EMOLAN_7", "meerdere mogelijkheden scheiden met spaties");
define("EMOLAN_8", "Smiley code");
define("EMOLAN_9", "Smiley afbeelding");
define("EMOLAN_10", "Toevoegen nieuwe smiley");
define("EMOLAN_11", "Smiley instellingen");
define("EMOLAN_12", "Bekijken");
define("EMOLAN_13", "Verwijderen");
define("EMOLAN_14", "Bewaren configuratie");
define("EMOLAN_15", "Bewerken/configureren smileys");
define("EMOLAN_16", "Smiley configuratie opgeslagen");
define("EMOLAN_17", "Er is een emoticon pack met spaties aanwezig, die zijn niet toegestaan !");
define("EMOLAN_18", "hernoem de onderstaande objecten, zodat ze geen spaties bevatten:");
define("EMOLAN_19", "Naam");
define("EMOLAN_20", "Locatie");
define("EMOLAN_21", "Fout");
?>