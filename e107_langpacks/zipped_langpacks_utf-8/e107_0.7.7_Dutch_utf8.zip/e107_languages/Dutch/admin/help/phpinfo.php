<?php

if (!defined('e107_INIT')) { exit; }

$text = " Deze pagina toont alle PHP configuratie instellingen van je server. ";
$ns -> tablerender("PHP Info Hulp", $text);
?>