<?php

if (!defined('e107_INIT')) { exit; }

$text = " Uitgebreide gebruikervelden maken het mogelijk om aanvullende soorten gegevens op te geven die de leden in hun gebruikersprofielen kunnen vastleggen.";
$ns -> tablerender(" Uitgebreide gebruikersvelden hulp", $text);
?>