<?php

if (!defined('e107_INIT')) { exit; }

$text = "De meta tags die je hier opgeeft worden op de juiste plaats naar het scherm gestuurd.";

$ns -> tablerender("Meta Tags", $text);
?>