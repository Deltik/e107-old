<?php

if (!defined('e107_INIT')) { exit; }

$text = "Hiervandaan kun je instellen of gebruikers al dan niet de mogelijkheid hebben om afbeeldingen op de site te plaatsen, je kunt de verschalingsmethode kiezen en de geuploade avatars bekijken.";
$ns -> tablerender("Afbeeldingenhulp", $text);
?>