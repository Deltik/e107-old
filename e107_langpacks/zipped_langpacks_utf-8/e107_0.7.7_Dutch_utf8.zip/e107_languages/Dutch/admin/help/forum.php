<?php

if (!defined('e107_INIT')) { exit; }

$caption = "Forum Hulp";
$text = "<b>Algemeen</b><br />
Gebruik dit scherm om forums te maken of bewerken<br />
<br />
<b>Hoofdonderwerpen/Forums</b><br />
Een hoofdonderwerp is de onderverdeling in onderwerpen waaronder de forums worden gegroepeerd. Dit verbetert het overzicht binnen je forums, waardoor bezoekers eerder de weg vinden.
<br /><br />
<b>Toegankelijkheid</b>
<br />
Je kunt forums openstellen voor bepaalde groepen gebruikers. Als je eenmaal de 'Klasse' van de bezoekers hebt ingesteld, kun je 
de gebruikersklasse die toegang mag hebben selecteren. Je kunt hoofdonderwerpen en forums zo afschermen.
<br /><br />
<b>Moderators</b>
<br />
Kruis de namen van de getoonde beheerder aan om ze moderator van een forum te maken. De beheerder moet wel eerst moderator rechten hebben gekregen in het Beheerdersscherm.
";
$ns -> tablerender($caption, $text);
unset($text);
?>