<?php

if (!defined('e107_INIT')) { exit; }

$text = "Stel hier de chatbox voorkeuren in.<br />Als de Vervang vakje is aangekruist, worden de ingevoerde links vervangen door de opgegeven tekst. Hierdoor wordt voorkomen dat eventueel de weergave wordt verminkt. Woordomslag slaat de tekst automatisch om als de tekst langer is dan de opgegeven waarde.";

$ns -> tablerender("Chatbox", $text);
?>