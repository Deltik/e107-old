<?php

if (!defined('e107_INIT')) { exit; }

$text = "Reviews zijn vergelijkbaar met artikelen, maar ze worden in een eigen menublok getoond.";
$ns -> tablerender("Review Hulp", $text);
?>