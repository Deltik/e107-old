<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_userclass.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 10th Sep 2004
+---------------------------------------------------------------+
*/

define("UCSLAN_1", "Stuur e-mail melding aan");
define("UCSLAN_2", "Autorisaties bijgewerkt");
define("UCSLAN_3", "Beste");
define("UCSLAN_4", "je autorisaties zijn bijgewerkt op");
define("UCSLAN_5", "Je hebt nu toegang tot de volgende functie(s)");
define("UCSLAN_6", "Instellen klasse voor lid");
define("UCSLAN_7", "Instellen klassen");
define("UCSLAN_8", "Melden aan lid");
define("UCSLAN_8", "Klassen bijgewerkt");
define("UCSLAN_9", "Groeten");
define("UCSLAN_10", "Groeten,");

?>