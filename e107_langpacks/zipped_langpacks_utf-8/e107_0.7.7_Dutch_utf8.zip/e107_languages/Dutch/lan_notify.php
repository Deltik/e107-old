<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Dutch/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/07/30 21:20:47 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Inlog");

define("NT_LAN_UV_1", "Aanmelding gebruiker geverifieerd");
define("NT_LAN_UV_2", "Tekst gebruikerssessie");
define("NT_LAN_UV_3", "Inlognaam gebruiker: ");
define("NT_LAN_UV_4", "Ip adres gebruiker: ");

define("NT_LAN_LI_1", "Gebruiker ingelogd");
define("NT_LAN_LO_1", "Gebruiker uitgelogd");
define("NT_LAN_LO_2", " uitgelogd");
define("NT_LAN_FL_1", "Flood Blokkade");
define("NT_LAN_FL_2", "IP adres geblokkeerd wegens flooding");

define("NT_LAN_SN_1", "Nieuwsbericht aangemeld");

define("NT_LAN_NU_1", "Bijgewerkt");

define("NT_LAN_ND_1", "Nieuwsbericht verwijderd");
define("NT_LAN_ND_2", "Nieuwsbericht id verwijderd");

?>