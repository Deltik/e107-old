<?php

define("NWSLAN_1", "Nieuwsbericht verwijderd.");
define("NWSLAN_2", "Aankruisen om het verwijderen van dit nieuwsbericht te bevestigen.");
define("NWSLAN_3", "Nog geen nieuwsberichten.");
define("NWSLAN_4", "Aanwezige nieuwsberichten");
define("NWSLAN_5", "Open HTML Editor");
define("NWSLAN_6", "Categorie");
define("NWSLAN_7", "Bewerken");
define("NWSLAN_8", "Verwijderen");
define("NWSLAN_9", "aankruisen om te bevestigen");
define("NWSLAN_10", "Nog geen categorieën ingesteld.");
define("NWSLAN_11", "Toevoegen/bewerken categorieën");
define("NWSLAN_12", "Titel");
define("NWSLAN_13", "Tekst");
define("NWSLAN_14", "Uitgebreid");
define("NWSLAN_15", "Reacties");
define("NWSLAN_16", "Geactiveerd");
define("NWSLAN_17", "Gedeactiveerd");
define("NWSLAN_18", "Toestaan om te reageren op dit bericht");
define("NWSLAN_19", "Activeren");
define("NWSLAN_20", "Niet invullen om auto-activatie uit te zetten");
define("NWSLAN_21", "Activeren tussen");
define("NWSLAN_22", "Zichtbaarheid");
define("NWSLAN_23", "Aankruisen maakt dit bericht alleen zichtbaar voor gebruikers in deze klasse");
define("NWSLAN_24", "Bekijk nogmaals");
define("NWSLAN_25", "Nieuws bijwerken in de database");
define("NWSLAN_26", "Plaats nieuws in de database");
define("NWSLAN_27", "Bekijk");
define("NWSLAN_28", "Nieuw bericht");
define("NWSLAN_29", "Nieuwsbericht");

define("NWSLAN_30", "Toon alleen de titel");

?>