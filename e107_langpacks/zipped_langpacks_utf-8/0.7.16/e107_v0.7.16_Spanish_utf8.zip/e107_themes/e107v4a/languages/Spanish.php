<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Leer/enviar comentario: ");
define("LAN_THEME_2", "Comentarios desactivados ");
define("LAN_THEME_3", "Leer el resto...");
define("LAN_THEME_4", "Enviado por");
define("LAN_THEME_5", "on");
define("LAN_THEME_6", "e107.v4 theme de <a href='http://e107.org' rel='external'>jalist</a>");

?>