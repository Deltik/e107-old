﻿<?php

$lang_ibrowser_title = 'Insertar / Editar Imagen ';
$lang_ibrowser_desc = 'Insertar / Editar Imagen ';
$lang_ibrowser_library = 'Biblioteca';
$lang_ibrowser_preview  = 'Vista Previa';
$lang_ibrowser_img_sel = 'Selección de la imagen';
$lang_ibrowser_img_info = 'Imagen de la información ';
$lang_ibrowser_img_upload = 'Cargar la imagen';
$lang_ibrowser_images  = 'Images';
$lang_ibrowser_src = 'Fuente';
$lang_ibrowser_alt = 'Descripción';
$lang_ibrowser_size = 'Tamaño';
$lang_ibrowser_align = 'Flujo de texto';
$lang_ibrowser_height = 'Altura';
$lang_ibrowser_width = 'Ancho';
$lang_ibrowser_reset = 'Dimensiones Reset';
$lang_ibrowser_border = 'Border';
$lang_ibrowser_hspace = 'Esp.Horiz';
$lang_ibrowser_vspace = 'Esp.Vert';
$lang_ibrowser_select  = 'Guardar';
$lang_ibrowser_delete = 'Borrar';
$lang_ibrowser_cancel = 'Cancelar';
$lang_ibrowser_uploadtxt = 'Archivo';
$lang_ibrowser_uploadbt = 'Subir';
$lang_ibrowser_marginl = 'margin-left ';
$lang_ibrowser_marginr = 'margin-right ';
$lang_ibrowser_margint = 'margin-top ';
$lang_ibrowser_marginb = 'margin-bottom ';
$lang_insert_image_align_default = 'Default';
$lang_insert_image_align_left = 'Izquierda';
$lang_insert_image_align_right = 'right';

// Mensajes de error
$lang_ibrowser_error  = 'Error';
$lang_ibrowser_errornoimg = 'Por favor seleccione una imagen';
$lang_ibrowser_errornodir = '\ t existen físicamente';
$lang_ibrowser_errorupload = 'Se produjo un error durante la manipulación de la carga de archivos. \ n Por favor, inténtelo de nuevo más tarde';
$lang_ibrowser_errortype = 'Wrong tipo de archivo de imagen';
$lang_ibrowser_errordelete = 'Eliminar no';
$lang_ibrowser_confirmdelete = 'Haga clic en Aceptar para eliminar la imagen';
$lang_ibrowser_error_width_nan = 'Ancho no es un número! ';
$lang_ibrowser_error_height_nan = 'La altura no es un número! ';
$lang_ibrowser_error_border_nan = 'las fronteras no es un número! ';
$lang_ibrowser_error_hspace_nan = 'Espacio horizontal no es un número! ';
$lang_ibrowser_error_vspace_nan = 'espacio vertical no es un número! '; 

?>