<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Invitados: ");
define("ONLINE_L2", "Miembros: ");
define("ONLINE_L3", "En esta página: ");
define("ONLINE_L4", "En linea");
define("ONLINE_L5", "Miembros");
define("ONLINE_L6", "Último");

define("TRACKING_MESSAGE", "El tracking de usuario online está actualmente desactivado, por favor actívelo [link=".e_ADMIN."users.php?options]aquí[/link][br]");
?>