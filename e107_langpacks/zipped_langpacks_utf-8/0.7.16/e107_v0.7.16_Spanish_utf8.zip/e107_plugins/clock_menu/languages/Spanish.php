<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define('CLOCK_MENU_L1','Configuración guardada');
define('CLOCK_MENU_L2','Título');
define('CLOCK_MENU_L3','Actualizar configuración');
define('CLOCK_MENU_L4','Configuración');
define('CLOCK_MENU_L5', 'Lunes,');
define('CLOCK_MENU_L6', 'Martes,');
define('CLOCK_MENU_L7', 'Miércoles,');
define('CLOCK_MENU_L8', 'Jueves,');
define('CLOCK_MENU_L9', 'Viernes,');
define('CLOCK_MENU_L10', 'Sábado,');
define('CLOCK_MENU_L11', 'Domingo,');
define('CLOCK_MENU_L12', 'Enero');
define('CLOCK_MENU_L13', 'Febrero');
define('CLOCK_MENU_L14', 'Marzo');
define('CLOCK_MENU_L15', 'Abril');
define('CLOCK_MENU_L16', 'Mayo');
define('CLOCK_MENU_L17', 'Junio');
define('CLOCK_MENU_L18', 'Julio');
define('CLOCK_MENU_L19', 'Agosto');
define('CLOCK_MENU_L20', 'Septiembre');
define('CLOCK_MENU_L21', 'Octubre');
define('CLOCK_MENU_L22', 'Noviembre');
define('CLOCK_MENU_L23', 'Diciembre');
define('CLOCK_MENU_L24', '');

?>