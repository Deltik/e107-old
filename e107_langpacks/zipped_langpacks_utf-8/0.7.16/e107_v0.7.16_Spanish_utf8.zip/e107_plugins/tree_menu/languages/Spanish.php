<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Configurar árbol de menú");
define("TREE_L2", "Actualizar opciones del árbol de menú");
define("TREE_L3", "Configuración guardada.");
define("TREE_L4", "On");
define("TREE_L5", "Off");
define("TREE_L6", "Clase CSS para usar en enlaces sin poder abrir");
define("TREE_L7", "Clase CSS para usar en enlaces normales");
define("TREE_L8", "Clase CSS para usar en enlaces abiertos");
define("TREE_L9", "Use la clase spacer entre los enlaces principales");

?>