<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("LOGIN_MENU_L1", "Usuario: ");
define("LOGIN_MENU_L2", "Contraseña: ");
define("LOGIN_MENU_L3", "Registro");
define("LOGIN_MENU_L4", "¿Olvidó su contraseña?");
define("LOGIN_MENU_L5", "Bienvenido");
define("LOGIN_MENU_L6", "Recordarme");
define("LOGIN_MENU_L7", "No se reconoce el ID único de usuario (posiblemente la cookie esté dañada).<br />Por favor <a href=\"index.php?logout\">pulse aquí</a> para borrar la cookie.");
define("LOGIN_MENU_L8", "Salir");
define("LOGIN_MENU_L9", "Error iniciando sesión");
define("LOGIN_MENU_L10", "Está activado el mantenimiento - los visitantes están siendo redirigidos a la página sitedown.php. para volver al estado normal entre en  admin/maintenance.");
define("LOGIN_MENU_L11", "Administrador");
define("LOGIN_MENU_L12", "Configuración");
define("LOGIN_MENU_L13", "Perfil");
define("LOGIN_MENU_L14", "Noticia");
define("LOGIN_MENU_L15", "Noticias");
define("LOGIN_MENU_L16", "Mensaje en chatbox");
define("LOGIN_MENU_L17", "Mensajes en chatbox");
define("LOGIN_MENU_L18", "Comentario");
define("LOGIN_MENU_L19", "Comentarios");
define("LOGIN_MENU_L20", "Mensaje en foros");
define("LOGIN_MENU_L21", "Mensajes en foros");
define("LOGIN_MENU_L22", "Nuevo miembro");
define("LOGIN_MENU_L23", "Nuevos miembros");
define("LOGIN_MENU_L24", "Ver la lista de novedades");
define("LOGIN_MENU_L25", "Novedades desde su última visita");
define("LOGIN_MENU_L26", "0");
define("LOGIN_MENU_L27", "y");
define("LOGIN_MENU_L28", "Entrar");
define("LOGIN_MENU_L29", "Nuevo artículo");
define("LOGIN_MENU_L30", "Artículos nuevos");
// New config options
define('LOGIN_MENU_L31', 'Mostrar nuevos envíos de noticias');
define('LOGIN_MENU_L32', 'Mostrar nuevos envíos de artículos');
define('LOGIN_MENU_L33', 'Mostrar nuevos envíos del chat');
define('LOGIN_MENU_L34', 'Mostrar nuevos comentarios');
define('LOGIN_MENU_L35', 'Mostrar nuevos envíos del foro');
define('LOGIN_MENU_L36', 'Mostrar nuevos miembros');

define('LOGIN_MENU_L39', 'Salir ADM');
define("LOGIN_MENU_L40", "Re-Enviar activación Email");
define("LOGIN_MENU_L41", "Ajuste del menú de acceso");
?>