<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Contenidos");
define("CONT_SCH_LAN_2", "Todas las categorías de contenidos");
define("CONT_SCH_LAN_3", "Enviado en respuesta al elemento");
define("CONT_SCH_LAN_4", "en");
?>