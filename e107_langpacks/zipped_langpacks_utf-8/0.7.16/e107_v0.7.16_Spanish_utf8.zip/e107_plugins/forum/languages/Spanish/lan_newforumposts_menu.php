<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Todos los últimos envíos estan fuera de su clase de usuario. Imposible mostrar.");
define("NFP_2", "Sin envíos todavía");
define("NFP_3", "Configuración de nuevos envíos del foro guardada");
define("NFP_4", "Título");
define("NFP_5", "¿Número de mensajes a mostrar?");
define("NFP_6", "¿Número de carácteres a mostrar?");
define("NFP_7", "¿Fijar envíos muy largos?");
define("NFP_8", "¿Mostrar temas originales en el menú?");
define("NFP_9", "Actualizar parámetros del menú");
define("NFP_10", "Configuración del menú de nuevos envíos del foro");
define("NFP_11", "Enviado por");
define("NFP_12", "Antiguedad de los envíos mostrados"); 
define("NFP_13", "Use cero para un sitio tranquilo; fijando un valor en días reducirá el tiempo de la dase de datos en un sitio ocupado"); 
?>