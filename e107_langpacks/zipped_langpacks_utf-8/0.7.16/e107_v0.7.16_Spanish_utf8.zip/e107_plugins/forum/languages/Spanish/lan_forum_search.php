<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Foro");
define("FOR_SCH_LAN_2", "Seleccionar foro");
define("FOR_SCH_LAN_3", "Todos los foros");
define("FOR_SCH_LAN_4", "Todo el mensaje");
define("FOR_SCH_LAN_5", "Como parte de un tema");
?>