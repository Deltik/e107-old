<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("UTHEME_MENU_L1", "Elegir Idioma");
define("UTHEME_MENU_L2", "Seleccione Idioma");
define("UTHEME_MENU_L3", "Tablas");
?>