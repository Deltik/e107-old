<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Soporte de creación de PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Este plugin esta listo para ser usado.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Preferencias PDF");
define("PDF_LAN_3", "Activado");
define("PDF_LAN_4", "Desactivado");
define("PDF_LAN_5", "Margen de pag. izquierda");
define("PDF_LAN_6", "Margen de pag. derecha");
define("PDF_LAN_7", "Margen de pag. arriba");
define("PDF_LAN_8", "Tipo de fuente");
define("PDF_LAN_9", "Tamaño fuente por def.");
define("PDF_LAN_10", "Tipo fuente del sitio");
define("PDF_LAN_11", "Tamaño fuente pag. url");
define("PDF_LAN_12", "Tamaño fuente número de pag.");
define("PDF_LAN_13", "¿Mostrar logo en el pdf?");
define("PDF_LAN_14", "¿Mostrar nombre del sitio en el PDF?");
define("PDF_LAN_15", "¿Mostrar creador de la página en el PDF?");
define("PDF_LAN_16", "¿Mostrar numeros de página en el PDF?");
define("PDF_LAN_17", "Actualizar");
define("PDF_LAN_18", "Prferencias de PDF actualizadas correctamente");
define("PDF_LAN_19", "Página");
define("PDF_LAN_20", "Informe error");
?>