<?php
/*
+ ----------------------------------------------------------------------------+
|     Sitio web e107 - Archivos del lenguaje.
|
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Publicidad");
define("BANNER_MENU_L2", "Configuración del menú anuncio guardada");
//v.617
define("BANNER_MENU_L3", "Título");
define("BANNER_MENU_L4", "Campaña");
define("BANNER_MENU_L5", "Configuración del menú del Anuncio");
define("BANNER_MENU_L6", "Seleccionar campañas para mostrar en el menú");
define("BANNER_MENU_L7", "Campañas disponibles");
define("BANNER_MENU_L8", "Campañas seleccionadas");
define("BANNER_MENU_L9", "Eliminar selección");
define("BANNER_MENU_L10", "¿Como deben ser mostradas las campañas seleccionadas?");
define("BANNER_MENU_L11", "Escoja tipo de renderizado ...");
define("BANNER_MENU_L12", "Una campaña en un solo menú");
define("BANNER_MENU_L13", "Todas las campañas en un solo menú");
define("BANNER_MENU_L14", "Todas las campañas en menús separados");
define("BANNER_MENU_L15", "¿Cuantos anuncios deben mostrarse?");
define("BANNER_MENU_L16", "Este parámetro solo debe ser usado con las opciones 2 y 3.<br />Si hay menos anuncios se usará la mayor cantidad disponible.");
define("BANNER_MENU_L17", "Ponga cantidad ...");
define("BANNER_MENU_L18", "Actualizar parámetros de menú");

?>