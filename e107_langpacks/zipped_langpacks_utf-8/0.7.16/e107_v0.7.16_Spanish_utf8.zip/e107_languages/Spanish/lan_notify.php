<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Conexión de usuario");
define("NT_LAN_UV_1", "Verificación de la conexión de usuario");
define("NT_LAN_UV_2", "Usuario ID: "); 
define("NT_LAN_UV_3", "suario nombre conexión: "); 
define("NT_LAN_UV_4", "Usuario IP: "); 
define("NT_LAN_LI_1", "Usuario conectado");
define("NT_LAN_LO_1", "Usuario desconectado");
define("NT_LAN_LO_2", " desconectado del sitio");
define("NT_LAN_FL_1", "Expulsión flood");
define("NT_LAN_FL_2", "Expulsiones IP por flooding");
define("NT_LAN_SN_1", "Elementos de noticias enviados");
define("NT_LAN_NU_1", "Actualizado");
define("NT_LAN_ND_1", "Elementos de noticias eliminados");
define("NT_LAN_ND_2", "Elementos de noticias eliminados por ID");

?>