<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
//v.616
define("ONLINE_EL1", "Visitas: ");
define("ONLINE_EL2", "Miembros: ");
define("ONLINE_EL3", "En esta página: ");
define("ONLINE_EL4", "En linea");
define("ONLINE_EL5", "Miembros");
define("ONLINE_EL6", "Nuevo miembro");
define("ONLINE_EL7", "viendo");
define("ONLINE_EL8", "Máximo en linea: ");
define("ONLINE_EL9", "el");
define("ONLINE_EL10", "Nombre");
define("ONLINE_EL11", "Viendo página");
define("ONLINE_EL12", "Respondiendo a");
define("ONLINE_EL13", "Foro");
define("ONLINE_EL14", "Tema");
define("ONLINE_EL15", "Página");
define("CLASSRESTRICTED", "Página restringida");
define("ARTICLEPAGE", "Artículo/Revisión");
define("CHAT", "Chat");
define("COMMENT", "Comentarios");
define("DOWNLOAD", "Descargas");
define("EMAIL", "email.php");
define("FORUM", "Foro Principal");
define("LINKS", "Enlaces");
define("NEWS", "Noticias");
define("OLDPOLLS", "Encuestas antiguas");
define("POLLCOMMENT", "Encuesta");
define("PRINTPAGE", "Imprimir");
define("LOGIN", "Entrando en");
define("SEARCH", "Buscando");
define("STATS", "Estadísticas");
define("SUBMITNEWS", "Enviar Noticia");
define("UPLOAD", "Transferencias");
define("USERPAGE", "Perfiles de usuario");
define("USERSETTINGS", "Configuraciones de usuario");
define("ONLINE", "Usuarios en linea");
define("LISTNEW", "Lista de novedades");
define("USERPOSTS", "Mensajes de usuario");
define("SUBCONTENT", "Enviar Artículo/Revisión");
define("TOP", "Top Usuarios/Temas más activos");
define("ADMINAREA", "Área de Admin.");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Lista de eventos");
define("CALENDAR", "Calendario de eventos");
define("FAQ", "Faq");
define("PM", "Mensajería privada");
define("SURVEY", "Survey");
define("ARTICLE", "Artículo");
define("CONTENT", "Página de contenido");
define("REVIEW", "Revisión");

?>