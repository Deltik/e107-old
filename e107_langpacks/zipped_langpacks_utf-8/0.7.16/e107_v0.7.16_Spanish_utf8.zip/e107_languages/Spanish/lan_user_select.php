<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Selecciona usuario");
define("US_LAN_2", "Seleccionar clase de usuario");
define("US_LAN_3", "Todos los usuarios");
define("US_LAN_4", "Buscar usuario");
define("US_LAN_5", "Usuario(s) encontrado(s)");
define("US_LAN_6", "Buscar");
?>