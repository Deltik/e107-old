<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("RATELAN_0", "Voto");
define("RATELAN_1", "Votos");
define("RATELAN_2", "¿Como valora este elemento?");
define("RATELAN_3", "Gracias por su voto");
define("RATELAN_4", "Sin valorar");
define("RATELAN_5", "Valorar");

?>