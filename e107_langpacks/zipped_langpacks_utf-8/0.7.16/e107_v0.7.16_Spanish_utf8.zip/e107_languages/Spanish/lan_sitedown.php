<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sitio cerrado temporalmente");
define("LAN_SITEDOWN_00", "<b>- Temporalmente cerrado -</b><br /><br />Hemos cerrado temporalmente nuestro portal para realizar un mantenimiento del mismo e implementar nuevas utilidades. Este proceso durará pocas horas - Le rogamos nos disculpe por los inconvenientes que este proceso le pueda causar..");
define("LAN_SITEDOWN_01", "Este sitio está cerrado temporalmente por mantenimiento. El sitio estará disponible lo antes posible, por favor disculpe las molestias.");
?>
