<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Listado de página desactivado");
define("LAN_PAGE_2", "No hay páginas");
define("LAN_PAGE_3", "La página solicitada no existe");
define("LAN_PAGE_4", "Valorar esta página");
define("LAN_PAGE_5", "Gracias por valorar esta página");
define("LAN_PAGE_6", "No tiene permisos para ver esta página");
define("LAN_PAGE_7", "Contraseña incorrecta");
define("LAN_PAGE_8", "Página con contraseña protegida");
define("LAN_PAGE_9", "Contraseña");
define("LAN_PAGE_10", "Enviar");
define("LAN_PAGE_11", "Lista de página");
define("LAN_PAGE_12", "Página inválida");
define("LAN_PAGE_13", "Página");

?>