<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Caja de texto");
define("UE_LAN_2", "Botones seleccionables");
define("UE_LAN_3", "Lista desplegable");
define("UE_LAN_4", "Campo de tabla de BD");
define("UE_LAN_5", "Área de texto");
define("UE_LAN_6", "Entero");
define("UE_LAN_7", "Fecha");
define("UE_LAN_8", "Idioma");
define("UE_LAN_9", "Nombre");
define("UE_LAN_10", "Tipo");
define("UE_LAN_11", "Descripción");
define("UE_LAN_HIDE", "Oculto de los usuarios");
define("UE_LAN_LOCATION", "Zona");
define("UE_LAN_LOCATION_DESC", "Zona del usuario");
define("UE_LAN_AIM", "AIM");
define("UE_LAN_AIM_DESC", "Dirección AIM");
define("UE_LAN_ICQ", "ICQ");
define("UE_LAN_ICQ_DESC", "Número ICQ");
define("UE_LAN_YAHOO", "Yahoo!");
define("UE_LAN_YAHOO_DESC", "Dirección Yahoo");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "Dirección MSN");
define("UE_LAN_HOMEPAGE", "Página Web");
define("UE_LAN_HOMEPAGE_DESC", "Página web del usuario (url)");
define("UE_LAN_BIRTHDAY", "Cumpleaños");
define("UE_LAN_BIRTHDAY_DESC", "Fecha de cumpleaños");
define("UE_LAN_LANGUAGE", "Idioma"); 
define("UE_LAN_LANGUAGE_DESC", "Idioma del usuario"); 
define("UE_LAN_COUNTRY", "Pais"); 
define("UE_LAN_COUNTRY_DESC", "Pais del usuario (incluye tabla db)"); 
define("LAN_UE_FAIL_HOMEPAGE", "Entrada inválida para fijar en la página principal");
?>