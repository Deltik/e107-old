<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Producido por e107 website system");
define("LANMAILH_2", "Este es un mensaje multi-part en formato MIME.");
define("LANMAILH_3", " no esta formateado apropiadamente");
define("LANMAILH_4", "Mensaje rechazado por el servidor");
define("LANMAILH_5", "No hay respuesta del servidor");
define("LANMAILH_6", "No se puede encontrar servidor E-Mail.");
define("LANMAILH_7", " parece ser válido.");


?>