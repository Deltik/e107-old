<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Enviar Noticia");
define("LAN_7", "Nombre de usuario: ");
define("LAN_62", "Asunto: ");
define("LAN_112", "Email: ");
define("LAN_133", "Gracias");
define("LAN_134", "Su envio ha sido realizado. Será revisado por uno de los administradores del sitio.");
define("LAN_135", "Noticia: ");
define("LAN_136", "Enviar Noticia");
define("NWSLAN_6", "Categoría");
define("NWSLAN_10", "No hay categorias");
define("NWSLAN_11", "No tiene acceso a este área.");
define("NWSLAN_12", "Acceso denegado.");
define("SUBNEWSLAN_1", "Debe incluir un título.\\n");
define("SUBNEWSLAN_2", "Debe incluir algún texto en la noticia.\\n");
define("SUBNEWSLAN_3", "El archivo adjunto debe ser jpg, gif ó png");
define("SUBNEWSLAN_4", "Archivo demasiado grande");
define("SUBNEWSLAN_5", "Imagen");
define("SUBNEWSLAN_6", "(jpg, gif ó png)");
define('SUBNEWSLAN_7', 'Usted debe dar su nombre y dirección de correo electrónico');
define('SUBNEWSLAN_8', 'Error al cargar la imagen');
?>