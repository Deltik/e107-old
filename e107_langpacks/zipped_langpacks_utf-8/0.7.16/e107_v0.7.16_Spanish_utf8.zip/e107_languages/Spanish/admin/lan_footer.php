<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Sitio");
define("FOOTLAN_2", "Administrador");
define("FOOTLAN_3", "Versión");
define("FOOTLAN_4", "Revisión");
define("FOOTLAN_5", "Tema de Admin");
define("FOOTLAN_6", "Por");
define("FOOTLAN_7", "Info.");
define("FOOTLAN_8", "Fecha instalación");
define("FOOTLAN_9", "Servidor");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "Versión PHP");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Info. Sitio");
define("FOOTLAN_14", "Ver Documentos");
define("FOOTLAN_15", "Documentación");
define("FOOTLAN_16", "Base de datos");
define("FOOTLAN_17", "Juego de carácteres");
define("FOOTLAN_18", "Tema del sitio");
?>