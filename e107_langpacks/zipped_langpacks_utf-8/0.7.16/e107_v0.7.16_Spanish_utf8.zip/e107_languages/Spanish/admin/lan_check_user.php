<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/

define('LAN_CKUSER_01','base de datos de usuario Check');
define('LAN_CKUSER_02','Este buscará varios problemas potenciales con su base de datos de usuario');
define('LAN_CKUSER_03','Si usted tiene un montón de usuarios, puede llevar algún tiempo.');
define('LAN_CKUSER_04','Continuar');
define('LAN_CKUSER_05','Verificar los nombres de inicio de sesión duplicada');
define('LAN_CKUSER_06','Seleccione las funciones para llevar a cabo');
define('LAN_CKUSER_07','Duplicar nombres de usuario encontrado');
define('LAN_CKUSER_08','No duplicados encontrados');
define('LAN_CKUSER_09','Nombre de usuario');
define('LAN_CKUSER_10','ID de usuario');
define('LAN_CKUSER_11','Nombre para mostrar');
define('LAN_CKUSER_12','Check for duplicar direcciones de correo electrónico');
define('LAN_CKUSER_13','Duplicar las direcciones de correo electrónico encontrado');
define('LAN_CKUSER_14','Dirección de correo');
define('LAN_CKUSER_15','No se han encontrado duplicados.');
define('LAN_CKUSER_16','Encuentra registros donde el nombre de usuario es de otra persona.');
define('LAN_CKUSER_17','Conflicto entre nombre de usuario y nombre de la cuenta de usuario.');
define('LAN_CKUSER_18','Usuario A');
define('LAN_CKUSER_19','Usuario B');
define('LAN_CKUSER_20','');

?>