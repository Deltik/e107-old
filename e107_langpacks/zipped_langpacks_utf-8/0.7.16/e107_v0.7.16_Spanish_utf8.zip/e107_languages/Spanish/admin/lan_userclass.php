<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Enviando notificación por email a");
define("UCSLAN_2", "Actualizar privilegios");
define("UCSLAN_3", "Estimado");
define("UCSLAN_4", "Tus privilegios han sido actualizados a");
define("UCSLAN_5", "Ahora tiene acceso en la(s) siguiente(s) área(s)");
define("UCSLAN_6", "Cambiar Clase para usuario");
define("UCSLAN_7", "Cambiar clase");
define("UCSLAN_8", "Notificar usuario");
define("UCSLAN_9", "Clases actualizadas");
define("UCSLAN_10", "Atentamente");
define('UCSLAN_12', 'Solo miembros con privilegios');
?>