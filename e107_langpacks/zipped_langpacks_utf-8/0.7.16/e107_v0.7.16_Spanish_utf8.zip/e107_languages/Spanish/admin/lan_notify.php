<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Notificaciones");
define("NT_LAN_2", "Recibir notificación email ON");
define("NT_LAN_3", "OFF");
define("NT_LAN_4", "Admin Jefe");
define("NT_LAN_5", "Clase");
define("NT_LAN_6", "Email");

define("NU_LAN_1", "Eventos de usuario");
define("NU_LAN_2", "Altas de usuario");
define("NU_LAN_3", "Verificación de cuenta de usuario");
define("NU_LAN_4", "Conexión de usuario");
define("NU_LAN_5", "Desconexión de usuario");

define("NS_LAN_1", "Eventos de seguridad");
define("NS_LAN_2", "IP expulsada por flooding");

define("NN_LAN_1", "Eventos de noticias");
define("NN_LAN_2", "Nuevos elementos enviados por usuarios");
define("NN_LAN_3", "Nuevos eleventos enviados por Admin");
define("NN_LAN_4", "Nuevos elementos editados por Admin");
define("NN_LAN_5", "Nuevos elementos eliminados por Admin");

define("NF_LAN_1", "Eventos de archivo");
define("NF_LAN_2", "Archivo transferido por el usuario");
?>