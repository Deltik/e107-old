<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Visible para todos");
define("MENLAN_2", "Visible solo para miembros");
define("MENLAN_3", "Visible solo para administradores");
define("MENLAN_4", "Solo visible para clase");
//define("MENLAN_5", "");
define("MENLAN_6", "Actualizar clase para el menú");
define("MENLAN_7", "Configuración de clase para");
define("MENLAN_8", "Clases actualizadas");
define("MENLAN_9", "Nuevo menú de cliente instalado");
define("MENLAN_10", "Nuevo menú instalado");
define("MENLAN_11", "Menú retirado");
define("MENLAN_12", "Activar este menú");
define("MENLAN_13", "Activar en área");
define("MENLAN_14", "Área");
define("MENLAN_15", "Desactivar");
define("MENLAN_16", "Configurar");
define("MENLAN_17", "Mover arriba");
define("MENLAN_18", "Mover abajo");
define("MENLAN_19", "Mover al área");
define("MENLAN_20", "Visible");
//define("MENLAN_21", "Visible solo para Visitas");
define("MENLAN_22", "Menús inactivos");
define("MENLAN_23", "Mover al último");
define("MENLAN_24", "Mover al primero");
define("MENLAN_25", "Función ...");
define("MENLAN_26", "Este menú solo se <strong>MOSTRARÁ</strong> en las siguientes páginas");
define("MENLAN_27", "Este menú solo se <strong>OCULTARÁ</strong> en las siguientes páginas");
define("MENLAN_28", "Escriba una página por línea, escriba la URL completa para identificarla");
define("MENLAN_29", "Seleccionar plantilla");
define("MENLAN_30", "Para ver áreas de menú y sus posiciones en las plantillas personalizadas, seleccione su plantilla personalizada aquí:");
define("MENLAN_31", "Plantilla predeterminada");
define("MENLAN_32", "Plantilla cabecera de noticias");
define("MENLAN_33", "Plantilla personalizada");
define("MENLAN_34", "Integrado");
define("MENLAN_35", "Configurar Menús");
define("MENLAN_36", "Escoja el/los menú/s a activar");
define("MENLAN_37", "y donde activarlos.");
define("MENLAN_38", "Mantenga la tecla CRTL para seleccionar múltiples menús.");
?>