<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Mensajes recibidos");
define("MESSLAN_2", "Eliminar mensaje");
define("MESSLAN_3", "Mensaje borrado.");
define("MESSLAN_4", "Borrar todos los mensajes");
define("MESSLAN_5", "Confirmar");
define("MESSLAN_6", "Todos los mensajes borrados.");
define("MESSLAN_7", "Sin mensajes.");
define("MESSLAN_8", "Tipo de mensaje");
define("MESSLAN_9", "Informe");
define("MESSLAN_10", "Enviado por");
define("MESSLAN_11", "Abrir en nueva ventana");
define("MESSLAN_12", "Mensaje");
define("MESSLAN_13", "Enlace");
?>