<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Activación de Emoticono.");
define("EMOLAN_2", "Nombre");
define("EMOLAN_3", "Emoticonos");
define("EMOLAN_4", "¿Activar emoticonos?");
define("EMOLAN_5", "Imagen");
define("EMOLAN_6", "Código emoticono");
define("EMOLAN_7", "Separar múltiples entradas con espacios");
define("EMOLAN_8", "Estado");
define("EMOLAN_9", "Opciones");
define("EMOLAN_10", "Activo");
define("EMOLAN_11", "Activar pack");
define("EMOLAN_12", "Editar / configurar este pack");
define("EMOLAN_13", "Packs instalados");
define("EMOLAN_14", "Guardar configuración");
define("EMOLAN_15", "Editar / configurar Emoticonos");
define("EMOLAN_16", "Configuración de emoticono guardada");
define("EMOLAN_17", "¡Tiene un pack de emoticonos que contiene espacios en el nombre, lo cual no está permitido !"); 
define("EMOLAN_18", "por favor, renombre las instancias listadas debajo para que no contengan espacios:"); 
define("EMOLAN_19", "Nombre"); 
define("EMOLAN_20", "Lugar"); 
define("EMOLAN_21", "Error"); 
define("EMOLAN_22", "Name");
define("EMOLAN_23", "Encontrado nuevo pack xml:"); 
define("EMOLAN_24", "Encontrado nuevo pack php:");
define("EMOLAN_25", "Instalando nuevos emoticonos PHP: "); 
define("EMOLAN_26", "Re-escanear pack"); 
define("EMOLAN_27", "Error ocurrido procesando el pack: "); 
define("EMOLAN_28", "Generar XML"); 
define("EMOLAN_29", "Archivo XML generado: ");
define("EMOLAN_30", "Error escribiendo el archivo XML: ");
?>