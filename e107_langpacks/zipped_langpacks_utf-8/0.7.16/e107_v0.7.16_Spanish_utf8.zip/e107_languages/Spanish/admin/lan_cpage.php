<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Título");
define("CUSLAN_2", "Tipo");
define("CUSLAN_3", "Opciones");
define("CUSLAN_4", "¿Borrar esta página?");
define("CUSLAN_5", "Páginas existentes");
define("CUSLAN_7", "Nombre menú");
define("CUSLAN_8", "Texto título");
define("CUSLAN_9", "Texto");
define("CUSLAN_10", "Permitir valorar página");
define("CUSLAN_11", "Pantalla");
define("CUSLAN_12", "Crear página");
define("CUSLAN_13", "Permitir comentarios");
define("CUSLAN_14", "Contraseña de la página");
define("CUSLAN_15", "Escriba una contraseña para proteger la página");
define("CUSLAN_16", "Crear enlace en el menú principal");
define("CUSLAN_17", "Escriba un nombre de enlace a crear");
define("CUSLAN_18", "Página visible a");
define("CUSLAN_19", "Actualizar página");
define("CUSLAN_20", "Crear página");
define("CUSLAN_21", "Actualizar menú");
define("CUSLAN_22", "Crear menú");
define("CUSLAN_23", "Editar página");
define("CUSLAN_24", "Crear nueva página");
define("CUSLAN_25", "Editar menú");
define("CUSLAN_26", "Crear nuevo menú");
define("CUSLAN_27", "Página guardada en la Base de Datos.");
define("CUSLAN_28", "Página borrada");
define("CUSLAN_29", "Lista de páginas si no seleccionó una página");
define("CUSLAN_30", "Tiempo de la expiración de la cookie (en segundos)");
define("CUSLAN_31", "Crear menú");
define("CUSLAN_32", "Convertir viejas páginas/menús");
define("CUSLAN_33", "Opciones de página");
define("CUSLAN_34", "Comenzando conversión");
define("CUSLAN_35", "Actualización finalizada en la página personalizada");
define("CUSLAN_36", "Para fijar sus preferencias por cada página, vuelva a la página de trabajo y edite las páginas.");
define("CUSLAN_37", "Página personalizada actualizada");
define("CUSLAN_38", "On");
define("CUSLAN_39", "Off");
define("CUSLAN_40", "Guardar opciones");
define("CUSLAN_41", "Mostrar información de autor y fecha");
define("CUSLAN_42", "No hay páginas definidas todavía");
define('CUSLAN_43', 'menú sin titulo: ');
define('CUSLAN_44', 'página sin titulo');
?>