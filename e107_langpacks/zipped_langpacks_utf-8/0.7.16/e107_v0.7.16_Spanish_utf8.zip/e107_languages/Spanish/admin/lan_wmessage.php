<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
//define("WMGLAN_1", "Mensaje para invitados");
//define("WMGLAN_2", "Mensaje para miembros");
//define("WMGLAN_3", "Mensaje para Administradores");
//define("WMGLAN_4", "Enviar");
//define("WMGLAN_5", "Poner mensaje de bienvenida");
//define("WMGLAN_6", "¿Activar?");
//define("WMGLAN_7", "Ajustes de mensajes de bienvenida actualizado.");

define("WMLAN_00","Mensajes de bienvenida");
define("WMLAN_01","Crear nuevo mensaje");
define("WMLAN_02","Mensaje");
define("WMLAN_03","Ver");
define("WMLAN_04","Texto de mensaje");
define("WMLAN_05","Encerrado");
define("WMLAN_06","<b>On:</b> El mensaje se renderizará en la caja");
define("WMLAN_07","Invalidar el método abreviado {WMESSAGE}:");
//define("WMLAN_08","Preferencias");
define("WMLAN_09","No hay mensajes de bienvenida");
define("WMLAN_10","Texto del mensaje");   
?>