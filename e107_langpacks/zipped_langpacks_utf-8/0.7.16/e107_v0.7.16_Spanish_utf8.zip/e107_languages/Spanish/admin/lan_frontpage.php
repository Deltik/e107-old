<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Actualizados los ajustes de la página.");
define("FRTLAN_2", "Mostrar");
define("FRTLAN_6", "Enlaces");
//define("FRTLAN_7", "Página de contenidos");
define("FRTLAN_12", "Actualizar parámetros de la página");
define("FRTLAN_13", "Parámetros de la página");
define("FRTLAN_15", "Otro (escribe url):");
define("FRTLAN_16", "Error: no hay contenido principal seleccionado");
define("FRTLAN_17", "Error: no hay subcategoría de contenido seleccionado");
define("FRTLAN_18", "Error: no hay ningún contenido seleccionado");
define("FRTLAN_19", "Contenido principal");
define("FRTLAN_20", "Categoría de contenido");
define("FRTLAN_21", "Contenido");
//define("FRTLAN_22", "");
//define("FRTLAN_23", "");
//define("FRTLAN_24", "");
//define("FRTLAN_25", "");
define("FRTLAN_26", "Todos los usuarios");
define("FRTLAN_27", "Invitados");
define("FRTLAN_28", "Miembros");
define("FRTLAN_29", "Administradores");
define("FRTLAN_31", "Todos los usuarios");
define("FRTLAN_32", "Clase de usuario");
define("FRTLAN_33", "Parámetros actuales");
define("FRTLAN_34", "Página");
?>