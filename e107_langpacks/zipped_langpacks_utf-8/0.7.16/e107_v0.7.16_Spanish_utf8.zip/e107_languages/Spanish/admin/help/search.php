<?php
/*
+ ----------------------------------------------------------------------------+
|     $Sitio web e107 - Archivos del lenguaje $
|     $Versión: 0.7.16 $
|     $Date: 2009/09/16 17:51:27 $
|     $Author: E107 <www.e107.org> $
|     $Traductor: Josico <www.e107.es> $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Si su versión de servidor MySQL lo soporta usted puede cambiar método corto de MySql  que es más rápido que el método corto de PHP.<br />Ver Preferencias<br />Si su sitio incluye idiomas ideográficos como el Chino o Japonés debe usar el método corto de PHP y desactivar la coincidencia total de la palabra.";
$ns -> tablerender("Ayuda búsquedas", $text);
?>