<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_themes/vekna_blue/languages/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:04 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/


define("LAN_THEME_1", "'vekna blue' af <a href='http://e107.org' rel='external'>jalist</a>, baseret på, og med tilladelse fra Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Læs/Skriv Kommentar: ");
define("LAN_THEME_3", "Kommentarer er slået fra på dette emne");
define("LAN_THEME_4", "Læs resten...");
define("LAN_THEME_5", "Trackbacks: ");

?>