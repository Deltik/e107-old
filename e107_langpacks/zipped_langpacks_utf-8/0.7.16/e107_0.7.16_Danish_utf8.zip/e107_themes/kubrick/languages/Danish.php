<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_themes/kubrick/languages/Danish.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/09/11 17:50:45 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("LAN_THEME_1", "'kubrick' af <a href='http://e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>,Baseret på original tema af Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>).");
define("LAN_THEME_2", "Kommentarer er slået fra på dette emne");
define("LAN_THEME_3", "kommentar: ");
define("LAN_THEME_4", "Læs resten...");
define("LAN_THEME_5", "Trackbacks: ");


?>