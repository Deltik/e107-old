<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_themes/newsroom/languages/Danish.php,v $
|        $Revision: 1.0 $
|        $Date: 2007/04/28 21:39:09 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("LAN_THEME_1", "Kommentarer");
define("LAN_THEME_2", "Kommentarer slået fra");
define("LAN_THEME_3", "HELE NYHEDEN");
define("LAN_THEME_4", "Skrevet");
?>