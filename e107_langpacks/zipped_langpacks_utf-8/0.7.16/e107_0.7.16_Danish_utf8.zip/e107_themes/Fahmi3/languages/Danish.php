<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/interfectus/languages/Danish.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/03/03 19:59:26 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

/////////////////////////-Danish language-////////////////
// Translatet by SteppeR								//
//														//
// Homepage   - http://steppers.dk						//
//														//
// email - Stepper@steppers.dk							//
//														//
//														//
//////////////////////////////////////////////////////////

define("LAN_THEME_1", "'Acrylic' by <a href='http://profiles.friendster.com/31005538' rel='external'>fahmi</a>");
define("LAN_THEME_2", "Læs/Skriv kommentar: ");
define("LAN_THEME_3", "Kommetar er slået fra");
define("LAN_THEME_4", "Forsæt...");
define("LAN_THEME_5", "Trackbacks: ");

?>