<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/usertheme_menu/languages/Danish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/06 22:12:04 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define('LAN_UMENU_THEME_1', 'Indstil Tema');
define('LAN_UMENU_THEME_2', 'Vælg Tema');
define('LAN_UMENU_THEME_3', 'brugere:');
define('LAN_UMENU_THEME_4', 'Aktiver de temaer brugerne må vælge');
define('LAN_UMENU_THEME_5', 'Opdater');
define('LAN_UMENU_THEME_6', 'Temaer tilgængelig for brugerne');
define('LAN_UMENU_THEME_7', 'Gruppe der kan vælge temaer');

?>