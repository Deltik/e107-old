<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:03 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("LWLAN_1", "Felter er tomme.");
define("LWLAN_2", "Linkord gemt.");
define("LWLAN_3", "Linkord opdateret.");
define("LWLAN_4", "Endnu ingen linkord.");
define("LWLAN_5", "Ord");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Indstillinger");
define("LWLAN_9", "ja");
define("LWLAN_10", "nej");
define("LWLAN_11", "Eksisterende linkord");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nej");
define("LWLAN_14", "Indsend Linkord");
define("LWLAN_15", "Opdater linkord");
define("LWLAN_16", "Rediger");
define("LWLAN_17", "Slet");
define("LWLAN_18", "Bekræft sletning af linkord?");
define("LWLAN_19", "Linkord slettet.");
define("LWLAN_20", "Kan ikke finde linkord.");
define("LWLAN_21", "Ord til autolink");
define("LWLAN_22", "Aktiver?");
define("LWLAN_23", "Linkord Administration");
define("LWLAN_24", "Håndter Ord");
define("LWLAN_25", "Egenskaber");
define("LWLAN_26", "Områder hvor linkord skal benyttes");
define("LWLAN_27", "Dette er 'indholdet' af den viste tekst");
define("LWLAN_28", "Sider hvor linkord ikke skal benyttes");
define("LWLAN_29", "Samme format som menu synligheds kontrol. En match pr linje. Specificer en delvis eller complet URL. Slutter med '!' for precis match af slut delen af linket");
define("LWLAN_30", "Gem indstillinger");
define("LWLAN_31", "Tilføj/rediger linkord");
define("LWLAN_32", "Linkord Egenskaber");
define("LWLAN_33", 'Titel områder');
define("LWLAN_34", 'Emne opsummering');
define("LWLAN_35", 'Indhold tekst');
define("LWLAN_36", 'Beskrivelser (links osv)');
define("LWLAN_37", 'Standard områder');
define("LWLAN_38", 'Klikbare links');
define("LWLAN_39", 'Ubehandlet tekst');
define("LWLAN_40", 'Bruger-tilføjede titler (eks. forum)');
define("LWLAN_41", 'Bruger-tilføjet brødtekst (eks. forum)');


define("LWLANINS_1", "Linkord");
define("LWLANINS_2", "Modulet vil linke angivne ord med defineret link");
define("LWLANINS_3", "Konfigurer Linkord");
define("LWLANINS_4", "Konfigurer gennem plugin på admin forsiden");

?>