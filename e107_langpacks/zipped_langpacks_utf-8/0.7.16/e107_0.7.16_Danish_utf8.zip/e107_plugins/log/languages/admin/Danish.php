<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system  Language File
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/log/languages/admin/Danish.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/23 00:04:09 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/







	
define("ADSTAT_ON", "Til");
define("ADSTAT_OFF", "Fra");
define("ADSTAT_L1", "Statistik plugin logger alle besøg på webstedet, og danner en detaljeret statistik på grundlag af de indsamlede informationer.");
define("ADSTAT_L2", "Statistik plugin er installeret. Aktiver på indstillingssiden.<br /><b> e107_plugins/log/logs folderen skal have 777 tilladelser (chmod 777)</b>");
define("ADSTAT_L3", "Statistik logning");
define("ADSTAT_L4", "Aktiver statistik logning");
define("ADSTAT_L5", "Statistik typer");
define("ADSTAT_L6", "Netlæsere");
define("ADSTAT_L7", "Operativsystemer");
define("ADSTAT_L8", "Skærmopløsninf/farver");
define("ADSTAT_L9", "Lande/domæner besøg fra");
define("ADSTAT_L10", "Henvisninger");
define("ADSTAT_L11", "Søge forespørgelser");
define("ADSTAT_L12", "Nulstil statistik");
define("ADSTAT_L13", "sletter statistik - forsigtig!");
define("ADSTAT_L14", "Sidetælning");
define("ADSTAT_L15", "Opdater indstillinger");
define("ADSTAT_L16", "Indstillinger");
define("ADSTAT_L17", "Indstillinger opdateret");
define("ADSTAT_L18", "Tillad adgang til hovedstatistik siden til ...");
define("ADSTAT_L19", "Seneste besøgende");
define("ADSTAT_L20", "Tæl administrator besøg");
define("ADSTAT_L21", "Max antal poster på statistiksiden");
define("ADSTAT_L22", "Kør opdatering");
define("ADSTAT_L23", "logs fra en tiligere version af e107 er fundet, opdater dem her");
define("ADSTAT_L24", "Gå til opdatering");
define("ADSTAT_L25", "Valgte statistikker nulstilles");
define("ADSTAT_L26", "Fjern side poster");
define("ADSTAT_L27", "hvis statistikken har ukorrekte sider kan de fjernes her");
define("ADSTAT_L28", "Åben side");
define("ADSTAT_L29", "Side Navn");
define("ADSTAT_L30", "Marker for at fjerne");
define("ADSTAT_L31", "Fjern valgte sider");
define("ADSTAT_L32", "Side Trim");
define("ADSTAT_L33", "Konfigurer Statistik Logføring");
define("ADSTAT_L34", "Site Statistik");

define('ADSTAT_L38', "Du skal gøre e107_plugins/log/logs mappen skrivbar");	// Constant compatible with 0.8


?>