<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	�Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/






define("ONLINE_L1", "Gæster: ");
define("ONLINE_L2", "Medlemmer: ");
define("ONLINE_L3", "På denne side: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Medlemmer");
define("ONLINE_L6", "Nyeste");
define("TRACKING_MESSAGE", "Online bruger sporing er pt. slået fra, slå det venligst til [link=".e_ADMIN."users.php?options]her[/link][br]");
?>