<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/login_menu/languages/Danish.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:04:18 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("LOGIN_MENU_L1", "Brugernavn: ");
define("LOGIN_MENU_L2", "Kodeord: ");
define("LOGIN_MENU_L3", "Tilmelding");
define("LOGIN_MENU_L4", "Glemt kodeord?");
define("LOGIN_MENU_L5", "Velkommen");
define("LOGIN_MENU_L6", "Husk mig");
define("LOGIN_MENU_L7", "Unik bruger ID er ikke genkendt (muligvis ødelagt cookie).<br />Prøv at <a href=\"".e_BASE."index.php?logout\">klik her</a> destruere cookien.");
define("LOGIN_MENU_L8", "Logud");
define("LOGIN_MENU_L9", "Login Fejl");
define("LOGIN_MENU_L10", "Siden vises som værende ude af drift - dette betyder at besøgende bliver henvist til sitedown.php. For at nulstille denne henvisning gå til admin/Vedligeholdelse.");
define("LOGIN_MENU_L11", "Admin");
define("LOGIN_MENU_L12", "Indstillinger");
define("LOGIN_MENU_L13", "Profil");
define("LOGIN_MENU_L14", "nyhed");
define("LOGIN_MENU_L15", "nyheder");
define("LOGIN_MENU_L16", "tagwall indlæg");
define("LOGIN_MENU_L17", "tagwall indlæg");
define("LOGIN_MENU_L18", "kommentar");
define("LOGIN_MENU_L19", "kommentarer");
define("LOGIN_MENU_L20", "forum indlæg");
define("LOGIN_MENU_L21", "forum indlæg");
define("LOGIN_MENU_L22", "nyt site medlem");
define("LOGIN_MENU_L23", "nye site medlemmer");
define("LOGIN_MENU_L24", "Klik her for se en liste over nyhederne");
define("LOGIN_MENU_L25", "Siden dit sidste besøg har der været");
define("LOGIN_MENU_L26", "nul");
define("LOGIN_MENU_L27", "og");
define("LOGIN_MENU_L28", "Login");

define("LOGIN_MENU_L29", "ny artikel");
define("LOGIN_MENU_L30", "nye artikler");

// Nye konfig muligheder
define('LOGIN_MENU_L31', 'Vis Nye Nyheder');
define('LOGIN_MENU_L32', 'Vis Nye Artikler');
define('LOGIN_MENU_L33', 'Vis Nye Chatbox Indlæg');
define('LOGIN_MENU_L34', 'Vis Nye Kommentarer');
define('LOGIN_MENU_L35', 'Vis Nye Forum Indlæg');
define('LOGIN_MENU_L36', 'Vis Nye Medlemmer');


define('LOGIN_MENU_L39', 'Forlad Admin');
define("LOGIN_MENU_L40", "Gensend Aktiverings Email");
define("LOGIN_MENU_L41", "Login Menu Indstillinger");

?>