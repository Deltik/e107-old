<?php
define("OTHERDB_LAN_1", "Database Type:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Brugernavn:");
define("OTHERDB_LAN_4", "Kodeord:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Tabel");
define("OTHERDB_LAN_7", "Brugernavn Felt:");
define("OTHERDB_LAN_8", "Kodeord Felt:");
define("OTHERDB_LAN_9", "Kodeord Metode:");
define("OTHERDB_LAN_10", "Configurer otherdb auth");
define("OTHERDB_LAN_11", "** De flg. felter er ikke krævede hvis der bruges en e107 database");

?>