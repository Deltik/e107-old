<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/banner_menu/languages/Danish.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/07/06 22:12:01 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Reklame");
define("BANNER_MENU_L2", "Banner menu konfiguration gemt");

//v.617
define("BANNER_MENU_L3", "Titel");
define("BANNER_MENU_L4", "Kampagne");
define("BANNER_MENU_L5", "Banner menu konfiguration");
define("BANNER_MENU_L6", "vælg kampagner der skal vises i menu");
define("BANNER_MENU_L7", "tilgængelige kampagner");
define("BANNER_MENU_L8", "valgte kampagner");
define("BANNER_MENU_L9", "fjern valg");
define("BANNER_MENU_L10", "hvordan bør de valgte kampagner vises ?");
define("BANNER_MENU_L11", "vælg fremvisnings type ...");
define("BANNER_MENU_L12", "en kampagne i en enkelt menu");
define("BANNER_MENU_L13", "alle valgte kampagner i en enkelt menu");
define("BANNER_MENU_L14", "alle valgte kampagner i forskellige menuer");
define("BANNER_MENU_L15", "hvor mange bannere skal der vises ?");
define("BANNER_MENU_L16", "denne indstilling vil kun blive brugt med mulighederne 2 og 3.<br />hvis færre bannere er til stede vil det maksimalt tilgængelige antal blive brugt.");
define("BANNER_MENU_L17", "indstil antal ...");
define("BANNER_MENU_L18", "Opdater menu indstillinger");
	
?>