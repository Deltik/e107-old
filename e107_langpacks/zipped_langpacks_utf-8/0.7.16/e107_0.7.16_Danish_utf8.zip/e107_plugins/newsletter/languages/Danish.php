<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsletter/languages/Danish.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/23 00:04:32 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("NLLAN_MENU_CAPTION", "Nyhedsbrev");

define("NLLAN_01", "Nyhedsbrev");
define("NLLAN_02", "En hurtig og nem måde at lave og sende nyhedsbreve");
define("NLLAN_03", "Konfigurer nyhedsbreve");
define("NLLAN_04", "Plugin nyhedsbrev er installeret. Konfigurer ved at gå til admin forsiden og kilkke på 'Nyhedsbrev' i Plugins sektionen.");
define("NLLAN_05", "endnu ingen nyhedsbreve");

define("NLLAN_06", "Navn");
define("NLLAN_07", "Abonenter");
define("NLLAN_08", "Indstillinger");
define("NLLAN_09", "Er du sikker på at du vil slette nyhedsbrev?");
define("NLLAN_10", "Eksisterende nyhedsbreve");

define("NLLAN_11", "Endnu ingen nyhedsbreve");
define("NLLAN_12", "Udgaver");
define("NLLAN_13", "[ Forælder ID ] emne/titel");
define("NLLAN_14", "Sendt?");
define("NLLAN_15", "Indstillinger");
define("NLLAN_16", "ja");
define("NLLAN_17", "Ikke sendt - klik for at sende");
define("NLLAN_18", "Sikker du vil sende udgave til abonnenter?");
define("NLLAN_19", "Sikker du vil slette nyhedsbrev udgave?");
define("NLLAN_20", "Eksisterende udgaver");
define("NLLAN_21", "Titel");
define("NLLAN_22", "Beskrivelse");
define("NLLAN_23", "Hoved");
define("NLLAN_24", "Fod");
define("NLLAN_25", "Opdater nyhedsbrev");
define("NLLAN_26", "Opret nyhedsbrev");
define("NLLAN_27", "Nyhedsbrev er opdateret.");
define("NLLAN_28", "Nyhedsbrev oprettet og gemt.");
define("NLLAN_29", "Endnu ingen nyhedsbreve.");
define("NLLAN_30", "Nyhedsbrev");
define("NLLAN_31", "Emne/titel");
define("NLLAN_32", "Udgave nummer");
define("NLLAN_33", "Tekst");
define("NLLAN_34", "Opdater Mailing");
define("NLLAN_35", "Opret Mailing");
define("NLLAN_36", "Opdater nyhedsbrev udgave");
define("NLLAN_37", "Opret nyhedsbrev udgave");
define("NLLAN_38", "Nyhedsbrev opdater.");
define("NLLAN_39", "Nyhedsbrev udgave gemt - klik på 'Udgave Nummer' knappen i indstillinger og send.");
define("NLLAN_40", "Udsendelse færdig - udgave sendt til ");

define("NLLAN_41", " abonnent(er).");
define("NLLAN_42", "Nyhedsbrev slettet.");
define("NLLAN_43", "Nyhedsbrev udgave slettet.");

define("NLLAN_44", "Nyhedsbrev forside");
define("NLLAN_45", "Opret nyhedsbrev");
define("NLLAN_46", "Opret mailing");
define("NLLAN_47", "Nyhedsbrev indstillinger");

define("NLLAN_48", "du abonnerer på dette nyhedsbrev - klik på knappen nedenunder og afmeld.");
define("NLLAN_49", "Sikker på at du afmelde dette nyhedsbrev?");
define("NLLAN_50", "Klik på knappen for at tilmelde ( din abonnere addresse er");
define("NLLAN_51", "Afmeld");
define("NLLAN_52", "Tilmeld");
define("NLLAN_53", "Sikker på at du vil tilmelde dig nyhedsbrev?");

define("NLLAN_54", "Sender");

define("NLLAN_55", "ID");
define("NLLAN_56", "Nyhedsbrev ID ikke tilgængelig");
define("NLLAN_57", "Retur til forrige side");
define("NLLAN_58", "Fejl");
define("NLLAN_59", "Navn");
define("NLLAN_60", "Email");
define("NLLAN_61", "Handlinger");
define("NLLAN_62", "Bruger er bannet! (eller ikke fuldt ud tilmeldt)");
define("NLLAN_63", "Abonnenter i alt");
define("NLLAN_64", "Returner til Nyhedsbrev forside");
define("NLLAN_65", "Abonnenter oversigt nyhedsbrev ID");

?>