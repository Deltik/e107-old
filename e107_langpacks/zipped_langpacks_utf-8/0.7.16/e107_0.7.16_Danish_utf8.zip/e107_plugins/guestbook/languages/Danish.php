<?php

/////////////////////////-Danish language-////////////////
// Translatet by SteppeR								//
//														//
// Homepage   - http://steppers.dk						//
//														//
// email - Stepper@steppers.dk							//
//														//
//														//
//////////////////////////////////////////////////////////

define("PAGE_NAME", $pref['guestbook_title']);

define(GB_LAN_SIGN,"Skriv i gæstebogen");
define(GB_LAN_NOTICE,"- HTML er ikke tilladt<br />- Email adresser er muligvis ikke synlige<br />- Det er tilladt at rediger ".$pref['guestbook_edittime']." minuter i alt.");
define(GB_LAN_NAME,"Navn");
define(GB_LAN_EMAIL,"Email");
define(GB_LAN_WEBSITE,"Hjemmeside");
define(GB_LAN_COMMENT,"Kommentar");
define(GB_LAN_EMOTES,"Smilies");
define(GB_LAN_SUBMIT,"Tilføj");
define(GB_LAN_SECURE, "Vær venlig at skrive teksten fra billedet");
define(GB_LAN_WRONGCODE,"Du skrev desværre forkert. Prøv igen");

define(GB_LAN_UPDATED,"Tilføjelse updateret");
define(GB_LAN_THANKYOU,"Mange tak for din kommentar i min gæstebog");
define(GB_LAN_REPEAT,"Du har allerede skrevet i min gæstebog");
define(GB_LAN_CONFIRM,"Vær venlig at bekræfte");
define(GB_LAN_PERMISSION,"Du har ikke tilladelse");
define(GB_LAN_NOHTML,"Desværre. HTML er ikke tilladt");
define(GB_LAN_NOLINKS,"Desværre. Links er ikke tilladt");
define(GB_LAN_GOBACK,"Gå tilbage");

define(GB_LAN_EDIT,"Rediger");
define(GB_LAN_DELETE,"Slet");
define(GB_LAN_PROFILE,"Profile");

define(GB_LAN_ADM_PAGING,"Antal tråde på vær side");
define(GB_LAN_ADM_TITLE,"Gæstebog´s Title");
define(GB_LAN_ADM_TABLE,"Omslut stil i tema tabel");
define(GB_LAN_ADM_BBCODE,"Aktiver BBCode og fremvis værktøjslinje");
define(GB_LAN_ADM_REPEAT,"Block gentagende posteringer fra samme IP");
define(GB_LAN_ADM_NOLINKS,"Tillad ikke links i gæstebogen");
define(GB_LAN_ADM_HIDEURL,"Vis hjemmesider kun for medlemmerne");
define(GB_LAN_ADM_HIDEPROFILE,"Vis profiler kun for medlemmerne");
define(GB_LAN_ADM_SUBMIT,"Updater indstillinger");
define(GB_LAN_ADM_UPDATED,"Indstillinger updateret");
define(GB_LAN_ADM_SECURECODE,"Sikker billede godkendelse");
define(GB_LAN_ADM_EDITTIME,"redigerings tiden [min]");
define(GB_LAN_ADM_MODERATOR_CLASS,"Moderator klasse");

?>
