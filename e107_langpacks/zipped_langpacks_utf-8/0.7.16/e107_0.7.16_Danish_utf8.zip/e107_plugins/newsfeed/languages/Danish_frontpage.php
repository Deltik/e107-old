<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsfeed/languages/Danish_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/11 15:36:18 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "Nyheds Feeds");
define("NWSF_FP_2", "hovedside");

?>