<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Danish/lan_content_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/23 00:03:31 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Indhold");
define("CONT_SCH_LAN_2", "Alle Indholds Kategorier");
define("CONT_SCH_LAN_3", "Skrevet som svar til emne");
define("CONT_SCH_LAN_4", "i");

?>