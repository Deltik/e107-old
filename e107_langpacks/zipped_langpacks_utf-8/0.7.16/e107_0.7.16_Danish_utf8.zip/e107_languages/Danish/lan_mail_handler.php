<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_mail_handler.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/09/14 20:10:33 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("LANMAILH_1", "Produceret af e107 CMS systemet");
define("LANMAILH_2", "Dette er en multi-part besked i MIME format.");
define("LANMAILH_3", " er ikke rigtig formateret");
define("LANMAILH_4", "Server afvist adresse");
define("LANMAILH_5", "Intet svar fra server");
define("LANMAILH_6", "Kan ikke finde e-mail server.");
define("LANMAILH_7", " lader til at være gyldig.");


?>