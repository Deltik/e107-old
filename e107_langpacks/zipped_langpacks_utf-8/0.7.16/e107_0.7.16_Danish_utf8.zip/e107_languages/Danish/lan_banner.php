<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_banner.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/10/03 15:30:54 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Bannerreklamer");

define("BANNERLAN_16", "Brugernavn: ");
define("BANNERLAN_17", "Adgangskode: ");
define("BANNERLAN_18", "Fortsæt");
define("BANNERLAN_19", "Indtast klient brugernavn og adgangskode og fortsæt");
define("BANNERLAN_20", "Beklager, det er ikke muligt at finde dine oplysninger. Kontakt administrator for yderligere hjælp.");
define("BANNERLAN_21", "Bannerstatistik");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "Banner ID");
define("BANNERLAN_24", "Gennemgående hits");
define("BANNERLAN_25", "Hits %");
define("BANNERLAN_26", "Antal");
define("BANNERLAN_27", "Købt antal");
define("BANNERLAN_28", "Resterende tilbage");
define("BANNERLAN_29", "Intet banner");
define("BANNERLAN_30", "Ubegrænset");
define("BANNERLAN_31", "Ikke anvendelig");
define("BANNERLAN_32", "Ja");
define("BANNERLAN_33", "Nej");
define("BANNERLAN_34", "Slutter");
define("BANNERLAN_35", "Gennemgående hits IP adresser");
define("BANNERLAN_36", "Aktiv:");
define("BANNERLAN_37", "Starter:");
define("BANNERLAN_38", "Fejl");

?>