<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_upload.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/01/29 15:18:30 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Upload");

define('LAN_UL_001','Ugyldig email adresse');
define('LAN_UL_002', 'Du har ikke tilladelse til at uploade på denne server.');	// LAN_403

define('LAN_UL_020', 'Fejl');
define('LAN_UL_021', 'Upload Fejl');

define('LAN_UL_032', 'Du skal vælge en kategori');
define('LAN_UL_033', 'Du skal skrive en gyldig email adresse');
define('LAN_UL_034', 'Du skal angive et filnavn');
define('LAN_UL_035', 'Du skal skrive en beskrivelse');
define('LAN_UL_036', 'Du skal angive en fil til upload');
define('LAN_UL_037', 'Du skal angive en kategori');
define('LAN_UL_038', '');

define("LAN_61", "Dit navn: ");
define("LAN_112", "E-mail-adresse: ");
define("LAN_144", "Websted URL: ");
define("LAN_402", "For at kunne uploade til denne server, skal du være  medlem .");
define("LAN_404", "Mange tak. uploadet vil blive vurderet og hvis det godkendes blive vist på siden her.");
//define("LAN_405", "Filen overskrider den maksimalt tilladte størrelse - slettet.");
define("LAN_406", "Bemærk ");
define("LAN_407", "Enhver anden filtype vil blive afvist omgående.");
define("LAN_408", "Understregede");
define("LAN_409", "Navnet på filen");
define("LAN_410", "Version");
define("LAN_411", "Filer");
define("LAN_412", "Skærmbillede");
define("LAN_413", "Beskrivelse");
define("LAN_414", "Evt. fungerende demo");
define("LAN_415", "skriv URL til siden hvor en demo kan ses");
define("LAN_416", "Tilføj og upload");
define("LAN_417", "uploadet fil");
define("LAN_418", "Maksimum filstørrelse: ");
define("DOWLAN_11", "Kategori");
define("LAN_419", "Tilladte filtyper");
define("LAN_420", "felter er krævet");



?>