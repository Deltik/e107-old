<?php
/*+---------------------------------------------------------------+|        e107 website system  Language File||        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_np.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:00 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("NP_1", "Forrige side");
define("NP_2", "Næste side");
define("NP_3", "Gå til side");

?>