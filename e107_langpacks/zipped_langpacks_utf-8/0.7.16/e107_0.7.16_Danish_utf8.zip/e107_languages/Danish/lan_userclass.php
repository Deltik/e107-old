<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_userclass.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("UC_LAN_0", "Alle (offentlig)");
define("UC_LAN_1", "Kun gæster");
define("UC_LAN_2", "Ingen (inaktiv)");
define("UC_LAN_3", "Kun medlemmer");
define("UC_LAN_4", "Skrive beskyttet");
define("UC_LAN_5", "Kun admin");
define("UC_LAN_6", "Hovedadmin");
?>