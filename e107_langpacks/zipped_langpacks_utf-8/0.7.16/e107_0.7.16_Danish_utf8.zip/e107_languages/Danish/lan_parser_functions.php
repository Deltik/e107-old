<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_parser_functions.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("LAN_GUEST", "Gæst");
define("LAN_WROTE", "skrev"); // som i han skrev.."  ";


?>