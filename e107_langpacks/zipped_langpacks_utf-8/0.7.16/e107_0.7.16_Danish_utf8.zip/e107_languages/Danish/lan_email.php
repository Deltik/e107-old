<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_email.php,v $
|        $Revision: 1.6 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }

define("LAN_EMAIL_1", "Fra:");
define("LAN_EMAIL_2", "afsender IP adresse:");
define("LAN_EMAIL_3", "Emailet emne fra ");
define("LAN_EMAIL_4", "Send e-mail");
define("LAN_EMAIL_5", "E-mail emne til en ven");
define("LAN_EMAIL_6", "Jeg tænkte du måske ville være intereseret i dette emne fra");
define("LAN_EMAIL_7", "email til en ven");
define("LAN_EMAIL_8", "Kommentar");
define("LAN_EMAIL_9", "Er desværre ikke i stand til at sende e-mail");
define("LAN_EMAIL_10", "Mail blev sendt til");
define("LAN_EMAIL_11", "E-mail sendt");
define("LAN_EMAIL_12", "Fejl");
define("LAN_EMAIL_13", "E-mail artiklen til en ven");
define("LAN_EMAIL_14", "E-mail nyhed til en ven");
define("LAN_EMAIL_15", "Brugernavn: ");
define("LAN_EMAIL_106", "Det lader ikke til at være en gyldig e-mail-adresse");
define("LAN_EMAIL_185", "Send Artikel");
define("LAN_EMAIL_186", "Send Nyhed");
define("LAN_EMAIL_187", "E-mail-adresse der skal sendes til");
define("LAN_EMAIL_188", "Jeg tror du måske er interesseret i denne nyhed fra");
define("LAN_EMAIL_189", "Jeg tror du måske er interesseret i denne artikel fra");
define("LAN_EMAIL_190", "Skriv Vist Kode");

?>