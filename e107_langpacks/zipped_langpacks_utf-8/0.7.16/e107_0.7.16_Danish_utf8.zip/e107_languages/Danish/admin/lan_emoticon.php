<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_emoticon.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/23 00:02:41 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("EMOLAN_1", "Smiley aktivering");
define("EMOLAN_2", "Navn");
define("EMOLAN_3", "Smiley");
define("EMOLAN_4", "Aktiver Smileys?");

define("EMOLAN_5", "Billede");
define("EMOLAN_6", "Smiley kode");
define("EMOLAN_7", "adskil flere Smileys med mellemrum");

define("EMOLAN_8", "Status");
define("EMOLAN_9", "Indstillinger");
define("EMOLAN_10", "Aktiv");
define("EMOLAN_11", "Aktiver pakke'");

define("EMOLAN_12", "rediger/konfigure pakke");
define("EMOLAN_13", "Installerede pakker");

define("EMOLAN_14", "Gem indstillinger");
define("EMOLAN_15", "Rediger / Konfigurer Smileys");
define("EMOLAN_16", "Smiley Konfiguration gemt");
define("EMOLAN_17", "Du har en smiley pakke tilstede der indeholder mellemrum, dette er ikke tilladt !");
define("EMOLAN_18", "omdøb venligst emnerne listet herunder så de ikke længere indeholder mellemrum:");
define("EMOLAN_19", "Navn");
define("EMOLAN_20", "Sted");
define("EMOLAN_21", "Fejl");
//define("EMOLAN_2", "Navn");
define("EMOLAN_22", "Ny Smiley pakke fundet:");
define("EMOLAN_23", "Ny Smiley xml pakke fundet:");
define("EMOLAN_24", "Ny Smiley php fundet:");
define("EMOLAN_25", "Installing new PHP emotes: ");
define("EMOLAN_26", "gen-skan pakke");
define("EMOLAN_27", "Fejl under behandling af pakke: ");
define("EMOLAN_28", "Generer XML");
define("EMOLAN_29", "XML fil genereret: ");
define("EMOLAN_30", "Fejl under skrivning af XML fil: ");
?>