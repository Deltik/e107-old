<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_message.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/06 22:12:01 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Modtagende beskeder");
define("MESSLAN_2", "Slet besked");
define("MESSLAN_3", "Besked slettet.");
define("MESSLAN_4", "Slet alle beskeder");
define("MESSLAN_5", "Bekræft");
define("MESSLAN_6", "Alle beskeder slettet");
define("MESSLAN_7", "Ingen beskeder.");
define("MESSLAN_8", "Besked type");
define("MESSLAN_9", "Raporteret ");

define("MESSLAN_10", "Tilføjet af");
define("MESSLAN_11", "åbner i et nyt vindue");
define("MESSLAN_12", "Besked");
define("MESSLAN_13", "Link");


?>