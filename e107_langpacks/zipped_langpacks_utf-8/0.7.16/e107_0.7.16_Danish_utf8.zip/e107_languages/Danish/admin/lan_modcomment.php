<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_modcomment.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/07/09 10:46:53 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("MDCLAN_1", "Administreret.");
define("MDCLAN_2", "Ingen kommentar til dette element");
define("MDCLAN_3", "Bruger");
define("MDCLAN_4", "Gæst");
define("MDCLAN_5", "fjern blokering");
define("MDCLAN_6", "bloker");

define("MDCLAN_8", "Administrer kommentarer");
define("MDCLAN_9", "Advarsel! sletning af kommentargrupper vil også slette alle svar!");

define("MDCLAN_10", "egenskaber");
define("MDCLAN_11", "kommentar");
define("MDCLAN_12", "kommentarer");
define("MDCLAN_13", "blokeret");
define("MDCLAN_14", "lås kommentarer");
define("MDCLAN_15", "åben");
define("MDCLAN_16", "låst");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>