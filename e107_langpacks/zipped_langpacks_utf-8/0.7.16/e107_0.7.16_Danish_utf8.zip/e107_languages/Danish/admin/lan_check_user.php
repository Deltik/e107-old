<?php
/*
+---------------------------------------------------------------+
|        e107 website system Danish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_languages/Danish/admin/lan_check_user.php $
|        $Revision: 1.0 $
|        $Date: 2009/09/11 15:58:29 $
|        $Author: SteppeR - Webmaster $
+---------------------------------------------------------------+
*/
define("LAN_CKUSER_01", "Tjek bruger database");
define("LAN_CKUSER_02", "Dette vil undersøge for forskellige potentielle problemer ved din database");
define("LAN_CKUSER_03", "Hvis du har mange brugere, vil dette tage sin tid, og måske endda Time Out");
define("LAN_CKUSER_04", "Forsæt");
define("LAN_CKUSER_05", "Undersøg for identiske login navne");
define("LAN_CKUSER_06", "Vælg de funktioner som skal udføres");
define("LAN_CKUSER_07", "Identiske bruger navne fundet");
define("LAN_CKUSER_08", "indet identisk fundet");
define("LAN_CKUSER_09", "Bruger navn");
define("LAN_CKUSER_10", "Bruger ID");
define("LAN_CKUSER_11", "Viste navn");
define("LAN_CKUSER_12", "Undersøg for identiske email adresser");
define("LAN_CKUSER_13", "Identiske email adressser fundet");
define("LAN_CKUSER_14", "Email adresser");
define("LAN_CKUSER_15", "Indet identisk fundet");
define("LAN_CKUSER_16", "Find poster, hvor brugernavn er andres \ 's login-navn");
define("LAN_CKUSER_17", "Modstridende brugernavn og login-navn");
define("LAN_CKUSER_18", "Bruger A");
define("LAN_CKUSER_19", "Bruger B");
define("LAN_CKUSER_20", "");


?>