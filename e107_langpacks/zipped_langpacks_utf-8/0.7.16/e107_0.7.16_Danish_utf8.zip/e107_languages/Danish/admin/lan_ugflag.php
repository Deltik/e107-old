<?php
/*
+---------------------------------------------------------------+|        e107 website system  Language File|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_ugflag.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:01 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("UGFLAN_1", "Indstillinger opdateret");
define("UGFLAN_2", "Aktiver vedligeholdelses tilstand");
define("UGFLAN_3", "Opdater indstillinger");
define("UGFLAN_4", "Indstillinger");
define("UGFLAN_5", "Tekst der vises i vedligeholdelses tilstand");
define("UGFLAN_6", "Blank for at vise standard besked");

?>