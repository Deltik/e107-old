<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_banlist.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("BANLAN_1", "Ban fjernet.");
define("BANLAN_2", "Ingen bandlysninger.");
define("BANLAN_3", "Eksisterende bandlysninger");
define("BANLAN_4", "Fjern banlysning");
define("BANLAN_5", "Indtast IP eller e-mail");
define("BANLAN_7", "Begrundelse");
define("BANLAN_8", "Bandlys bruger");
define("BANLAN_9", "Bandlys bruger fra websted");
define("BANLAN_10", "IP / E-mail / begrundelse");
define("BANLAN_11", "Auto-banlys: Mere end 10 fejlede login forsøg");
define("BANLAN_12", "NB: Omvendt DNS er pt. slået fra, de skal slås til for at tillade banlysning af host.  Banlysning af IP og email vil stadig fungere normalt.");
define("BANLAN_13", "Obs: For at banlyse en bruger ved brugernavn, gå til Admin Brugere siden: ");
define("BANLAN_78", "Hit count exceeded (--HITS-- requests within allotted time)");


?>