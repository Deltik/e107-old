<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_header.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/10/21 12:58:11 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("LAN_head_1", "Admin menu");
define("LAN_head_2", "Din server tillader ikke HTTP fil uploads så det vil ikke være muligt for brugere at uploade billeder/filer osv. For at rette op på dette sæt file_uploads til On i din php.ini og genstart din server. Hvis du ikke har adgang til php.ini kontakt din host.");
define("LAN_head_3", "Din server kører med basedir restriction slået til. Dette forhindrer brug af hvilken som helst fil uden for din rodmappe og kan have effekt på visse scripts så som filemanager.");
define("LAN_head_4", "Administration");
define("LAN_head_5", "sprog vist i admin område: ");
define("LAN_head_6", "Plugin information");

?>