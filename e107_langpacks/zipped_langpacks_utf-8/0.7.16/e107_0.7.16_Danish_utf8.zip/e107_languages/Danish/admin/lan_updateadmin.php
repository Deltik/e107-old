<?php
/*
+---------------------------------------------------------------+|        e107 website system  Language File|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_updateadmin.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:01 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("UDALAN_1", "Fejl - prøv igen");
define("UDALAN_2", "Indstillinger opdateret");
define("UDALAN_3", "Indstillinger er opdateret for");
define("UDALAN_4", "Navn");
define("UDALAN_5", "Adgangskode");
define("UDALAN_6", "Gentag adgangskode");
define("UDALAN_7", "Skift adgangskode");
define("UDALAN_8", "Adgangskode opdatering for");

?>