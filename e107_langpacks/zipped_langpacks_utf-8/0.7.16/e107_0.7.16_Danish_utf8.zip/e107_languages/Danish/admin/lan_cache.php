<?php
/*
+---------------------------------------------------------------+|        e107 website system  Language File|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_cache.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:01 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("CACLAN_1", "Cache system status");
define("CACLAN_2", "Sæt cache status");
define("CACLAN_3", "Cache system");
define("CACLAN_4", "Cache status sat til");
define("CACLAN_5", "Tøm cache");
define("CACLAN_6", "Cache tømt");
define("CACLAN_7", "Cache slået fra");
define("CACLAN_8", "Cache data gemt i MySQL");
define("CACLAN_9", "Cache data gemt i disk fil");
define("CACLAN_10", "Cache mappen er skrive beskyttet. Kontroller at mappen er sat til CHMOD 0777");

?>