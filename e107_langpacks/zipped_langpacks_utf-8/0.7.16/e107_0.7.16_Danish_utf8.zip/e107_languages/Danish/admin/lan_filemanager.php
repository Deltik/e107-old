<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_filemanager.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/10/21 12:58:11 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("FMLAN_1", "Uploadet");
define("FMLAN_2", "til");
define("FMLAN_3", "mappe");
define("FMLAN_4", "Den uploadede fil, overskrider upload max fil størrelses grænsen i php.ini.");
// define("FMLAN_5", "Den uploadede fil, overskrider upload fil størrelses grænsen som var skrevet i HTML formen.");
// define("FMLAN_6", "Den uploadede fil var kun delvis uploadet.");
// define("FMLAN_7", "Filen blev ikke uploadet.");
// define("FMLAN_8", "Uploaded fil størrelse 0 byte");
// define("FMLAN_9", "Filen blev ikke uploadet. Filnavn");
// define("FMLAN_10", "Fejl");
// define("FMLAN_11", "Sansynligvis forkerte til rettigheder i upload mappen.");
define("FMLAN_12", "fil");
define("FMLAN_13", "filer");
define("FMLAN_14", "mappe");
define("FMLAN_15", "mapper");
define("FMLAN_16", "Rodkatalog");
define("FMLAN_17", "Navn");
define("FMLAN_18", "Størrelse");
define("FMLAN_19", "Sidst ændret");

define("FMLAN_21", "Upload fil til denne mappe");
define("FMLAN_22", "Upload");

define("FMLAN_26", "Slettet");
define("FMLAN_27", "succes");
define("FMLAN_28", "Kan ikke slette");
define("FMLAN_29", "Sti");
define("FMLAN_30", "niveau op");
define("FMLAN_31", "mappe");

define("FMLAN_32", "Vælg mappe");
define("FMLAN_33", "Vælg");
define("FMLAN_34", "Mappe valg");
define("FMLAN_35", "Fil mappe");

define("FMLAN_36", "Egne menuer mappe");
define("FMLAN_37", "Egne sider mappe");

define("FMLAN_38", "Fil flyttet til");
define("FMLAN_39", "Kan ikke flytte fil til");
define("FMLAN_40", "Newspost-Images Mappen");


define("FMLAN_43", "Slet valgte filer");


define("FMLAN_46", "Bekræft flytning af de valgte filer.");
define("FMLAN_47", "Brugeruploads"); 

define("FMLAN_48", "Flyt valgte til");
define("FMLAN_49", "Bekræft venligst at du ønsker at flytte de valgte filer.");
define("FMLAN_50", "Flyt");



?>