<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/cpage.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Fra denne side kan du oprette egne menuer eller egne sider med dit eget indhold i.<br /><br />";
// $text .= "Se venligst <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a> for en forklaring af alle funktionerne.";

$ns -> tablerender('Egne Menuer/Sider Hjælp', $text);
?>