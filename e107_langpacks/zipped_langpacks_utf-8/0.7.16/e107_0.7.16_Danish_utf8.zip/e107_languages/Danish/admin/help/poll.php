<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/poll.php,v $
|        $Revision: 1.2 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Du kan lave Afstemninger/undersøgelser fra denne side, Bare skriv et Afstemnings spørgsmål  og afstemnings muligheder, fremvis den og hvis alt ser tilfredsstillende ud marker boxen for at aktivere den.<br /><br />
For at se afstemningen, gå til din menu side og sikker dig at poll_menu er aktiveret.";

$ns -> tablerender("Afstemninger", $text);
?>