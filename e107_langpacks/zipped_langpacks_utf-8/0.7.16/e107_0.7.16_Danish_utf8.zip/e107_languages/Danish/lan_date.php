<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_date.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/06 22:12:00 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "år");
define("LANDT_02", "måned");
define("LANDT_03", "uge");
define("LANDT_04", "dag");
define("LANDT_05", "time");
define("LANDT_06", "minut");
define("LANDT_07", "sekund");
define("LANDT_01s", "år");
define("LANDT_02s", "måneder");
define("LANDT_03s", "uger");
define("LANDT_04s", "dage");
define("LANDT_05s", "timer");
define("LANDT_06s", "minutter");
define("LANDT_07s", "sekunder");

define("LANDT_08", "min");
define("LANDT_08s", "minutter");
define("LANDT_09", "sek");
define("LANDT_09s", "sekunder");
define("LANDT_AGO", "siden");


?>