<?php
/*
+---------------------------------------------------------------+|        e107 website system  Language File|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_subcontent.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:00 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("ARLAN_0", "Mange tak, din artikel er gemt og vil blive gennemlæst inden længe.");
define("ARLAN_1", "Felter ikke udfyldt.");
define("ARLAN_2", "Mange tak, din anmeldelse er gemt og vil blive gennemlæst inden længe.");
define("ARLAN_15", "Tilføj artikel");
define("ARLAN_17", "Overskrift");
define("ARLAN_18", "Underoverskrift");
define("ARLAN_19", "Resume");
define("ARLAN_20", "Artikel");
define("ARLAN_21", "Tillad kommentarer?");
define("ARLAN_22", "Til");
define("ARLAN_23", "Fra");
define("ARLAN_24", "Tilføj e-mail/udskriv ikoner?");
define("ARLAN_25", "Ja");
define("ARLAN_26", "Nej");
define("ARLAN_27", "Tilføj artikel");
define("ARLAN_28", "Vis");
define("ARLAN_55", "Synlig for");
define("ARLAN_73", "Åben HTML redigering");
define("ARLAN_74", "Kategori");
define("ARLAN_75", "Ingen");
define("ARLAN_82", "Forfatter detaljer");
define("ARLAN_84", "forfatter navn");
define("ARLAN_85", "forfatter e-mail-adresse");
define("ARLAN_86", "Anmeldelse");
define("ARLAN_87", "Bedømmelse");
define("ARLAN_88", "Vælg en bedømmelse");
define("ARLAN_89", "Tilføj Anmeldelse");
define("ARLAN_90", "Felter ikke udfyldt, gå tilbage og kontroller at alle felter er udfyldt.");
define("ARLAN_91", "Fremvis igen");
define("ARLAN_92", "Skriv dit navn/e-mail-adresse");
define("ARLAN_93", "artikel");
define("ARLAN_94", "anmeldelse");
define("ARLAN_95", "Bruger tilføjelse af artikler er pt. slået fra");
define("ARLAN_96", "Bruger tilføjelse af anmeldelser er pt. slået fra");
define("ARLAN_97", "Du har ikke tilstrækkelige rettigheder til at tilføje artikler");
define("ARLAN_98", "Du har ikke tilstrækkelige rettigheder til at tilføje anmeldelser");
define("ARLAN_99", "Hvad kunne du tænke dig at tilføje?");
define("ARLAN_100", "Nyheder");
define("ARLAN_101", " Begivenhed");
define("ARLAN_102", "Artikel");
define("ARLAN_103", "Anmeldelse");
define("ARLAN_104", "Link");
define("ARLAN_105", "Download");
define("ARLAN_106", "Tilføj emne");

?>