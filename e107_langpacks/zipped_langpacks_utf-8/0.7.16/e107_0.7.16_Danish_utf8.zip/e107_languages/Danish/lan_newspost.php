<?php
/*+---------------------------------------------------------------+|        e107 website system  Language File||        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_newspost.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:00 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("NWSLAN_1", "Nyhed slettet.");
define("NWSLAN_2", "Bekræft sletning af nyhed.");
define("NWSLAN_3", "Ingen nyheder endnu.");
define("NWSLAN_4", "Eksisterende nyheder");
define("NWSLAN_5", "Åben HTML redigering");
define("NWSLAN_6", "Kategori");
define("NWSLAN_7", "Rediger");
define("NWSLAN_8", "Slet");
define("NWSLAN_9", "bekræft");
define("NWSLAN_10", "pt. ingen kategorier.");
define("NWSLAN_11", "Tilføj/rediger kategorier");
define("NWSLAN_12", "Titel");
define("NWSLAN_13", "Indhold");
define("NWSLAN_14", "Udvidet");
define("NWSLAN_15", "Kommentarer");
define("NWSLAN_16", "Slået til");
define("NWSLAN_17", "Slået fra");
define("NWSLAN_18", "Tillad kommentarer til denne nyhed");
define("NWSLAN_19", "Aktivering");
define("NWSLAN_20", "Blank = auto-aktivering");
define("NWSLAN_21", "Aktiv mellem");
define("NWSLAN_22", "Synlighed");
define("NWSLAN_23", "Nyhed synlig kun for denne brugergruppe");
define("NWSLAN_24", "Fremvis igen");
define("NWSLAN_25", "Opdater nyhed");
define("NWSLAN_26", "Opret nyhed");
define("NWSLAN_27", "Fremvis");
define("NWSLAN_28", "Ny historie");
define("NWSLAN_29", "Nyhed");

define("NWSLAN_30", "Vis kun titel");

?>