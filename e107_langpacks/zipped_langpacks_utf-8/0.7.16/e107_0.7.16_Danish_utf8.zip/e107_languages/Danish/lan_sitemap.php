<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_sitemap.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/10/21 12:58:11 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Sideoversigt");
define("LANSM_1", "Sideoversigt for");
define("LANSM_2", "Hjem");
define("LANSM_3", "(Index side)");
define("LANSM_4", "Indhold");
define("LANSM_5", "Nyheder");
define("LANSM_6", "(Nyhedskategorier)");
define("LANSM_7", "Vise/skjule hele sideoversigten");
define("LANSM_8", "Links");
define("LANSM_9", "(linkkategorier)");
define("LANSM_10", "Forums");
define("LANSM_11", "(Forumsliste)");
define("LANSM_12", "Downloads");
define("LANSM_13", "(Downloadkategorier)");
define("LANSM_14", "Artikler");
define("LANSM_15", "(Artikelkategorier)");
define("LANSM_16", "Anmeldelser");
define("LANSM_17", "(Anmeldelseskategorier)");
define("LANSM_18", "Forside");
define("LANSM_19", "Medlemmer");
define("LANSM_20", "Statistik");
define("LANSM_21", "Brugerindstillinger");
define("LANSM_22", "Profil");
define("LANSM_23", "Kategorier:");
define("LANSM_24", "Generelle indstillinger");
define("LANSM_25", "Plugin");
define("LANSM_26", "Chatboksbeskeder");
define("LANSM_27", "Overskrifter");
define("LANSM_28", "Gamle afstemninger");
define("LANSM_29", "Indhold");
define("LANSM_30", "(Liste over indholdssider)");
define("LANSM_31", "eller klik på");
define("LANSM_32", "Liste over registrerede brugere");
define("LANSM_33", "(Statistik )");
define("LANSM_34", "(Info om et medlem)");
define("LANSM_35", "(Opsætnings info medlem)");
define("LANSM_36", "(Andre indholdssider)");
define("LANSM_37", "Underkategorier:");
define("LANSM_38", "Sider");
define("LANSM_39", "(indlæg/svar");
define("LANSM_40", "Ikke kategoriseret");
define("LANSM_41", "for at udvide/skjule en underkategori");
define("LANSM_42", "Chat");
define("LANSM_43", "(Alle beskeder skrevet i chatboksmenuen)");
define("LANSM_44", "Andre sider");
define("LANSM_45", "Tilmeld");
define("LANSM_46", "Glemt adgangskode?");
define("LANSM_47", "Søg");
define("LANSM_48", "Tilføj nyhed");
define("LANSM_49", "Tilføj indhold");
define("LANSM_50", "Top skribenter");
define("LANSM_51", "Tilføj links");
define("LANSM_52", "Brugerindlæg");
define("LANSM_53", "(Tjek kommentarer fra bestemte brugere)");

?>