<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'khatru' от <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "комментарий: ");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбеки: ");


?>
