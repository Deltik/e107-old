<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 237 $
|     $Date: 2009-09-20 16:18:50 +0600 (Вс, 20 сен 2009) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Комментарии выключены"); //Comments are turned off for this item
define("LAN_THEME_2", "Читать/Добавить комментарий: "); //Read/Post Comment: 
define("LAN_THEME_3", "Читать полностью..."); //Read the rest...
define("LAN_THEME_4", "Трекбеки: "); //Trackbacks: 
define("LAN_THEME_5", "Добавил "); //Posted by
define("LAN_THEME_6", "- "); //on 

?>
