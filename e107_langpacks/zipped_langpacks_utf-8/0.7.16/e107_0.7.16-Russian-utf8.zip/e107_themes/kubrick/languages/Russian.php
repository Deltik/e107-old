<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 237 $
|     $Date: 2009-09-20 16:18:50 +0600 (Вс, 20 сен 2009) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' от <a href='http://e107.org' rel='external'>jalist</a>, Основано на теме Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>).");
define("LAN_THEME_2", "Комментарии выключены");
define("LAN_THEME_3", "комментарии: ");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбеки: ");
define('LAN_THEME_6', 'От');
define('LAN_THEME_7', 'добавил');

?>
