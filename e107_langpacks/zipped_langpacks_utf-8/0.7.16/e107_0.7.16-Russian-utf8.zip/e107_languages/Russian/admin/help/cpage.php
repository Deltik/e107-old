<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 233 $
|     $Date: 2009-02-01 19:32:01 +0500 (Вс, 01 фев 2009) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

//                                          v[custom menus]       v[custom pages]
$text = "На этой странице вы можете создать меню и страницы с вашим контентом внутри.<br /><br />";
//Для подробностей смотрите <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a>.";

$ns -> tablerender('Свои меню/страницы: Справка', $text);
?>