<?php
/*
+---------------------------------------------------------------+
|	e107 website system
|
|	©Steve Dunstan 2001-2002
|	http://e107.org
|	jalist@e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NFP_1", "De laatste berichten horen bij forums waar u niet bij mag komen, ze kunnen niet worden getoond.");
define("NFP_2", "Nog geen berichten");

define("NFP_3", "New Forum Posts menuconfiguratie opgeslagen");
define("NFP_4", "Titelbalk");
define("NFP_5", "Aantal te tonen berichten?");
define("NFP_6", "Aantal te tonen tekens?");
define("NFP_7", "Aanduiding bij te lang bericht?");
define("NFP_8", "Originele discussies tonen in menu?");
define("NFP_9", "Bijwerken menuconfiguratie");
define("NFP_10", "New Forum Posts menuconfiguratie");
define("NFP_11", "Geplaatst door");

?>