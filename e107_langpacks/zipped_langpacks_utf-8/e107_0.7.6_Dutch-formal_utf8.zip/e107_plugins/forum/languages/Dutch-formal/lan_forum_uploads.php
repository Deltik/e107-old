<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Dutch-formal/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/18 16:57:43 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','Geuploade bestanden in forum');
define('FRMUP_2','Bestand verwijderd');
define('FRMUP_3','Fout: bestand niet te verwijderen');
define('FRMUP_4','Bestandsverwijdering');
define('FRMUP_5','Bestandsnaam');
define('FRMUP_6','Resultaat');
define('FRMUP_7','Gevonden in discussie');
define('FRMUP_8','NIET GEVONDEN');
define('FRMUP_9','Geen geuploade bestanden gevonden');
define('FRMUP_10','Verwijderen');
	
?>