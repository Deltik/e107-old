<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Dutch-formal/lan_forum_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/18 16:57:43 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Selecteer forum");
define("FOR_SCH_LAN_3", "Alle forums");
define("FOR_SCH_LAN_4", "Hele bericht");
define("FOR_SCH_LAN_5", "Als deel van discussie");

?>