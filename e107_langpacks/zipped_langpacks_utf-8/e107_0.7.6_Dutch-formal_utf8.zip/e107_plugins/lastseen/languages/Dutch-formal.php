<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/lastseen/languages/Dutch-formal.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/18 06:25:42 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("LSP_LAN_1", "Laatst gezien");


?>