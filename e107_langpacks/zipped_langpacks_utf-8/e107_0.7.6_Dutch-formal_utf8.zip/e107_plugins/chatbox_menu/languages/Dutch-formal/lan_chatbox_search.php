<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Dutch-formal/lan_chatbox_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/17 20:42:24 $
|     $Author: mijnheer $
+----------------------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");

?>