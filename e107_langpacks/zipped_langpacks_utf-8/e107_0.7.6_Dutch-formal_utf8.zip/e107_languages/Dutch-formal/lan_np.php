<?php

define("NP_1", "Vorige pagina");
define("NP_2", "Volgende pagina");
define("NP_3", "Ga naar pagina");

?>