<?php

/*
+---------------------------------------------------------------+
|        e107 website system
|        admin/lan_meta.php Dutch-utf language file 
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        Translation Updated by: koot on the 10th Sep 2004
+---------------------------------------------------------------+
*/

define("METLAN_1", "Meta tags bijgewerkt in database");
define("METLAN_2", "Opvoeren meta tags");
define("METLAN_3", "Invoeren nieuwe meta tag instellingen");
define("METLAN_4", "Bijgewerkt");
define("METLAN_5", "voer hier de beschrijving in");
define("METLAN_6", "geef, hier, een, serie, sleutelwoorden, op");
define("METLAN_7", "voer hier de auteursrecht info in");
define("METLAN_8", "Meta tags");
define("METLAN_9", "omschrijving");
define("METLAN_10", "sleutelwoorden");
define("METLAN_11", "auteursrecht");
define("METLAN_12", "Gebruik de nieuwstitel en samenvatting als meta-beschrijving op nieuwspagina's.");
define("METLAN_13", "Auteur");
?>