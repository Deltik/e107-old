<?php

if (!defined('e107_INIT')) { exit; }

$caption = "Menu Hulp";
$text .= "U kunt hiermee bepalen waar en in welke volgorde uw menublokken worden getoond. Gebruik de pijltjes om de menu's op en neer te verplaatsen totdat u tevreden bent met de plek.<br />
De menu's midden in het scherm zijn niet geactiveerd, u kunt ze activeren door een menuzone te selecteren.
";

$ns -> tablerender("Menu Hulp", $text);
?>