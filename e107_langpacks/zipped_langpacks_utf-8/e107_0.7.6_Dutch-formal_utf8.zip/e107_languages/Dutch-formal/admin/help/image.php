<?php

if (!defined('e107_INIT')) { exit; }

$text = "Hiervandaan kunt u instellen of gebruikers al dan niet de mogelijkheid hebben om afbeeldingen op de site te plaatsen, u kunt de verschalingsmethode kiezen en de geuploade avatars bekijken.";
$ns -> tablerender("Afbeeldingenhulp", $text);
?>