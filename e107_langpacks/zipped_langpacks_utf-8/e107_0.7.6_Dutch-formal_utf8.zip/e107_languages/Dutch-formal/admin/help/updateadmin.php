<?php

if (!defined('e107_INIT')) { exit; }

$text = "Wijzig hier uw naam, e-mailadres en wachtwoord.";
$ns -> tablerender("Bijwerken instellingen Hulp", $text);
?>