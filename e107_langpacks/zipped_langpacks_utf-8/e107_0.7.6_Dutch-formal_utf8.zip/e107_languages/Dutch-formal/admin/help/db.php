<?php

if (!defined('e107_INIT')) { exit; }

$text = "Dit zijn de hulpmiddelen waarmee u de e107 database kunt beheren.";
$ns -> tablerender("Database Hulpmiddelen", $text);
?>