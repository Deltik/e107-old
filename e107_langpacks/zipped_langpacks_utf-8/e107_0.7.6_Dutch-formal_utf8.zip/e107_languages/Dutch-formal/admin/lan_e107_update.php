<?php

define("LAN_UPDATE_2", "Actie");
define("LAN_UPDATE_3", "Niet nodig");
define("LAN_UPDATE_5", "Update(s) beschikbaar");
define("LAN_UPDATE_7", "Uitvoeren");
define("LAN_UPDATE_8", "Update van");
define("LAN_UPDATE_9", "naar");
define("LAN_UPDATE_10", "Beschikbare updates");
define("LAN_UPDATE_11", ".617 naar .7 update voortgezet");
define("LAN_UPDATE_12", "Eén van de tabellen bevat dubbele records.");
?>