<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:06 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_frontpage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_frontpage.php rev. 1.8
+-----------------------------------------------------------------------------+
*/
 
define("FRTLAN_1", "Ustawienia strony głównej zostały zaktualizowane.");
define("FRTLAN_2", "Ustawienia strony głównej dla");
define("FRTLAN_6", "Linki");
// define("FRTLAN_7", "Własna strona");
define("FRTLAN_12", "Aktualizuj ustawienia strony głównej");
define("FRTLAN_13", "Ustawienia strony głównej");
define("FRTLAN_15", "Inna (wpisz adres):");
define("FRTLAN_16", "Błąd: nie wybrano działu głównego publikacji");
define("FRTLAN_17", "Błąd: nie wybrano podkategorii publikacji");
define("FRTLAN_18", "Błąd: nie wybrano publikacji");
define("FRTLAN_19", "Dział główny publikacji");
define("FRTLAN_20", "Kategoria publikacji");
define("FRTLAN_21", "Publikacja");
// define("FRTLAN_22", "");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Wszyscy użytkownicy");
define("FRTLAN_27", "Goście");
define("FRTLAN_28", "Zarejestrowani użytkownicy");
define("FRTLAN_29", "Administratorzy");
define("FRTLAN_31", "Wszystkich użytkowników");
define("FRTLAN_32", "Grupy użytkowników");
define("FRTLAN_33", "Aktualne ustawienia");
define("FRTLAN_34", "Strona");

?>
