<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.1 $
|     $Date: 2006/06/21 21:35:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_ugflag.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_ugflag.php rev. 1.1
+-----------------------------------------------------------------------------+
*/
 
define("UGFLAN_1", "Ustawienia konserwacji zostały zaktualizowane");
define("UGFLAN_2", "Aktywuj tryb konserwacji");
define("UGFLAN_3", "Aktualizuj ustawienia konserwacji");
define("UGFLAN_4", "Ustawienia konserwacji");

define("UGFLAN_5", "Tekst do wyświetlenia podczas zamknięcia strony");
define("UGFLAN_6", "Pozostaw puste, aby wyświetlić domyślną wiadomość");

?>
