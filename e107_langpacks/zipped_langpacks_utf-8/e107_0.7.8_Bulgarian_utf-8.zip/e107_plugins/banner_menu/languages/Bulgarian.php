<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/banner_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/01/27 19:52:35 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Реклама");
define("BANNER_MENU_L2", "Настройките на меню Реклама са запазени");

//v.617
define("BANNER_MENU_L3", "Заглавие");
define("BANNER_MENU_L4", "Кампания");
define("BANNER_MENU_L5", "Настройки на меню Реклама");
define("BANNER_MENU_L6", "изберете кампания за показване в менюто");
define("BANNER_MENU_L7", "налични кампании");
define("BANNER_MENU_L8", "избрани кампании");
define("BANNER_MENU_L9", "премахване на избраните");
define("BANNER_MENU_L10", "как да бъдат показвани избраните кампании ?");
define("BANNER_MENU_L11", "избери начин на показване ...");
define("BANNER_MENU_L12", "по една кампания в отделно меню");
define("BANNER_MENU_L13", "всички избрани кампании в едно меню");
define("BANNER_MENU_L14", "всички избрани кампании в различни менюта");
define("BANNER_MENU_L15", "колко банери да бъдат показани ?");
define("BANNER_MENU_L16", "тази настройка ще бъде ползвана само с опции 2 и 3.<br />ако има по-малко налични банери, ще бъде ползвано максималното налично количество банери.");
define("BANNER_MENU_L17", "задай количество ...");
define("BANNER_MENU_L18", "Актуализиране на меню настройки");

?>