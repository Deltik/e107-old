<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/07 02:54:20 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("TREE_L1", "Настройка на дървоидно меню");
define("TREE_L2", "Обнови настройките на дървоидното меню");
define("TREE_L3", "Настройките на дървоидното меню са запазени.");
define("TREE_L4", "Вкл.");
define("TREE_L5", "Изкл.");
define("TREE_L6", "CSS клас за неотваряеми линкове");
define("TREE_L7", "CSS клас за отваряеми линкове");
define("TREE_L8", "CSS клас за отворени линкове");
define("TREE_L9", "Използвай клас за празно пространство между главните линкове");

?>