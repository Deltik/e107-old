<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/03 12:14:57 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
    
define("ONLINE_L1", "Гости: ");
define("ONLINE_L2", "Регистрирани: ");
define("ONLINE_L3", "На тази странница: ");
define("ONLINE_L4", "Онлайн");
define("ONLINE_L5", "Регистрирани");
define("ONLINE_L6", "най-новият");
//define("TRACKING_MESSAGE", (ADMIN ? "<br /><br /><span style='font-weight: bold'>Проследяване на потребителя е изключено, моля включете го от <a href='".e_ADMIN."users.php?options'>тук</a></span><br />" : ""));
define("TRACKING_MESSAGE", "Проследяване на потребителя е изключено, моля включете го от <a href='".e_ADMIN."users.php?options'> тук</a></span><br />");
?>