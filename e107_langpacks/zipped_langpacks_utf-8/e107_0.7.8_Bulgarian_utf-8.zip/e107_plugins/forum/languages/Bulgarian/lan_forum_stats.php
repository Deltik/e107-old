<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Bulgarian/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/25 11:38:50 $
|     $Author: stevedunstan $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Статистика на Форума");

define("FSLAN_1", "Главна");
define("FSLAN_2", "Форума е стартиран на");
define("FSLAN_3", "Отворен от");
define("FSLAN_4", "Общо съобщения");
define("FSLAN_5", "Общо теми");
define("FSLAN_6", "Орговори");
define("FSLAN_7", "Брой преглеждания на темите");
define("FSLAN_8", "Големина на базата данни (само таблиците от форума)");
define("FSLAN_9", "Average row length in forum table");
define("FSLAN_10", "Най-активни теми");
define("FSLAN_11", "Ранг");
define("FSLAN_12", "Тема");
define("FSLAN_13", "Отговори");
define("FSLAN_14", "Стартирана от");
define("FSLAN_15", "Дата");
define("FSLAN_16", "Най-гледаните теми");
define("FSLAN_17", "Преглеждани");
define("FSLAN_18", "Най-много отговаряли");
define("FSLAN_19", "Име");
define("FSLAN_20", "Отговора");
define("FSLAN_21", "Най-много потребители стартирали теми");
define("FSLAN_22", "Най-много отговаряли потребители");
define("FSLAN_23", "Статистика на Форума");
define("FSLAN_24", "Средно отговора на ден");

?>