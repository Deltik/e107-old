<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Bulgarian/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/24 20:43:34 $
|     $Author: mcfly_e107 $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Добавяне на файлове във Форума");

define('FRMUP_1','Добавени файлове във Форуми');
define('FRMUP_2','Файла е изтрит');
define('FRMUP_3','Грешка: Не е възможно да се изтрие файла');
define('FRMUP_4','Изтриване на файл');
define('FRMUP_5','Име на файл');
define('FRMUP_6','Резултат');
define('FRMUP_7','Намерен в тема');
define('FRMUP_8','НЕ Е НАМЕРЕН');
define('FRMUP_9','Не са намерени добавени файлове');
define('FRMUP_10','Изтрий');
    
?>