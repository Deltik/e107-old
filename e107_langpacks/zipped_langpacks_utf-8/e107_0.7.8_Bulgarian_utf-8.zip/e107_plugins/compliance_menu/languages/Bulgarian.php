<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/compliance_menu/languages/Bulgarian.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/03/22 20:58:14 $
|     $Author: stevedunstan $
|     $Превод:
|     $e107BG Team
|     $http://e107bg.org
+----------------------------------------------------------------------------+
*/
	
define("COMPLIANCE_L1", "W3C Проверка");

?>