<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright T? 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8  
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/16 10:36:59 $
|     $Author: lisa_ $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF поддръжка");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Този плъгин е готов за използване.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF настройки");
define("PDF_LAN_3", "включено");
define("PDF_LAN_4", "изключено");
define("PDF_LAN_5", "страницата от ляво");
define("PDF_LAN_6", "страницата от дясно");
define("PDF_LAN_7", "страницата горе");
define("PDF_LAN_8", "вид на шрифта");
define("PDF_LAN_9", "размер на шрифта по подразбиране");
define("PDF_LAN_10", "размер на шрифта на името на сайта");
define("PDF_LAN_11", "размер на шрифта на url на страницата");
define("PDF_LAN_12", "размер на шрифта на номер на страницата");
define("PDF_LAN_13", "да покаже ли лого в pdf?");
define("PDF_LAN_14", "да покаже ли името на сайта в pdf?");
define("PDF_LAN_15", "да покаже ли автора на сайта url в pdf?");
define("PDF_LAN_16", "да покаже ли номера на страницата в pdf?");
define("PDF_LAN_17", "обнови");
define("PDF_LAN_18", "PDF настройките са запазени успешно");
define("PDF_LAN_19", "Страница");
define("PDF_LAN_20", "рапорт за грешки");

?>