<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/22 18:20:52 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "Конфигуриране на Проследяване");
define("TRACKBACK_L2", "Този плъгин ви позволява да проследявате потребителите във постовете ви.");
define("TRACKBACK_L3", "Модула Проследяване е инсталиран.");
define("TRACKBACK_L4", "Настройките са запазени.");
define("TRACKBACK_L5", "Вкл.");
define("TRACKBACK_L6", "Изкл.");
define("TRACKBACK_L7", "Активирай проследяване");
define("TRACKBACK_L8", "Проследяване URL текст");
define("TRACKBACK_L9", "Запази Настройките");
define("TRACKBACK_L10", "Проследяване Настройки");
define("TRACKBACK_L11", "Проследи адрес за този пост:");

define("TRACKBACK_L12", "Няма проследени за тази публикация");
define("TRACKBACK_L13", "Редактирай проследявания");
define("TRACKBACK_L14", "Изтрий");
define("TRACKBACK_L15", "Проследяванета изтрити.");

?>