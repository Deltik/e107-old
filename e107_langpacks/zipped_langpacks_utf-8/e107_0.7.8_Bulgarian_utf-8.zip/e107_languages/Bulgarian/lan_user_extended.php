<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_user_extended.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Текстово поле");
define("UE_LAN_2", "Радио бутони");
define("UE_LAN_3", "Падащо Меню");
define("UE_LAN_4", "Поле за таблица от БД");
define("UE_LAN_5", "Текст поле");
define("UE_LAN_6", "Цяло число");
define("UE_LAN_7", "Дата");
define("UE_LAN_8", "Език");

define("UE_LAN_9", "Име");
define("UE_LAN_10", "Тип");
define("UE_LAN_11", "Употреба");

define("UE_LAN_HIDE", "Скриване от потребителите");

define("UE_LAN_LOCATION", "Местоположение");
define("UE_LAN_LOCATION_DESC", "Местоположение на потребителя");
define("UE_LAN_AIM", "AIM Адрес");
define("UE_LAN_AIM_DESC", "AIM Адрес");
define("UE_LAN_ICQ", "ICQ Номер");
define("UE_LAN_ICQ_DESC", "ICQ Номер");
define("UE_LAN_YAHOO", "Yahoo! Адрес");
define("UE_LAN_YAHOO_DESC", "Yahoo! Адрес");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN Адрес");
define("UE_LAN_HOMEPAGE", "Лична страница");
define("UE_LAN_HOMEPAGE_DESC", "Лична страница на потребителя (url)");
define("UE_LAN_BIRTHDAY", "Рождена дата");
define("UE_LAN_BIRTHDAY_DESC", "Рождена дата");
define("UE_LAN_LANGUAGE", "Език");
define("UE_LAN_LANGUAGE_DESC", "Потребителски език");
define("UE_LAN_COUNTRY", "Страна");
define("UE_LAN_COUNTRY_DESC", "Страна на потребителя (включва БД таблица)");
?>
