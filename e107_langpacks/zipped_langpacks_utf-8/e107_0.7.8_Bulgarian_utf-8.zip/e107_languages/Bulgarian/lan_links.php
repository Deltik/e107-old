<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_links.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Линкове");

define("LAN_61", "Линк Категории");
define("LAN_62", "категории");
define("LAN_63", "категория");
define("LAN_64", "в тази категория");
define("LAN_65", "линк");
define("LAN_66", "линка");
define("LAN_67", "Покажи всички линкове");
define("LAN_68", "редакция");
define("LAN_69", "изтриване");
define("LAN_86", "Категория:");
define("LAN_88", "Препратки:");
define("LAN_89", "Админ: ");
define("LAN_90", "добави линк в тази категория");
define("LAN_91", "добави нова категория");

define("LAN_92", "Предложи линк");
define("LAN_93", "След добавянето на вашия линк, той ще бъде разгледан от сайт-администратор и ако бъде одобрен, ще бъде добавен на страницата с линкове.");
define("LAN_94", "Име на линк:");
define("LAN_95", "URL адрес:");
define("LAN_96", "Описание на линка:");
define("LAN_97", "URL към картинка за линка:");
define("LAN_98", "Добавяне на линк");

define("LAN_99", "Благодарим");
define("LAN_100", "Вашият линк беше записан и ще бъде разгледан от администратор на сайта.");
define("LAN_101", "Моля натиснете тук за добавяне на линк");

define("LAN_102", ""); //intentional empty constant
define("LAN_103", "Има");
define("LAN_104", "Има");
define("LAN_105", "общо в");
define("LAN_106", "Подчертаните полета са задължителни.");

define("LAN_Links_1", "Общо линкове");
define("LAN_Links_2", "Общо активни линка");
define("LAN_LINKS_3", "Анонимен");
?>
