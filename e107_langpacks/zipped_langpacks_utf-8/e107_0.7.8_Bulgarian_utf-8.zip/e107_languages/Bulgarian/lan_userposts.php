<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File
|     Bulgarian Language Pack for e107 Version 0.7
|     Copyright © 2005 - Bulgarian e107
|     http://www.e107bg.org
|     Encoding: utf-8
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/lan_userposts.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/19 19:46:15 $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Потребителски публикации");

define("UP_LAN_0", "Всички публикации на форума за ");
define("UP_LAN_1", "Всички коментари за ");
define("UP_LAN_2", "Тема");
define("UP_LAN_3", "Преглеждания");
define("UP_LAN_4", "Отговори");
define("UP_LAN_5", "Последни публикации");
define("UP_LAN_6", "Теми");
define("UP_LAN_7", "Няма коментари");
define("UP_LAN_8", "Няма публикации");
define("UP_LAN_9", " на ");
define("UP_LAN_10", "В отговор на");
define("UP_LAN_11", "Написано на: ");
define("UP_LAN_12", "Търсене");
define("UP_LAN_13", "Коментари");
define("UP_LAN_14", "Публикации на форума");
define("UP_LAN_15", "В отговор на");
define("UP_LAN_16", "IP Адрес");
?>