<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_parser_functions.php,v $
|     $Revision: 83 $
|     $Date: 2006-11-27 14:47:49 +0200 (Mon, 27 Nov 2006) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Гост");
define("LAN_WROTE", "написа"); // as in John wrote.."  ";

?>