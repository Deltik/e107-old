<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 83 $
|     $Date: 2006-11-27 14:47:49 +0200 (Mon, 27 Nov 2006) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define("LANCONTACT_01", "Данни за контакт");
define("LANCONTACT_02", "Директна връзка");
define("LANCONTACT_03", "Вашето име:");
define("LANCONTACT_04", "Имейл адрес:");
define("LANCONTACT_05", "Заглавие:");
define("LANCONTACT_06", "Съобщение:");
define("LANCONTACT_07", "Изпрати копие от това съобщение на твоя личен адрес ");
define("LANCONTACT_08", "Изпращане");
define("LANCONTACT_09", "Съобщението беше успешно изпратено.");
define("LANCONTACT_10", "Намерен е проблем при изпращане на Вашето съобщение.");
define("LANCONTACT_11", "Вашият имейл адрес изглежда не е валиден.\\nМоля проверете и опитайте отново.");
define("LANCONTACT_12", "Съобщението Ви е твърде кратко.");
define("LANCONTACT_13", "Моля напишете заглавие."); 

define("LANCONTACT_14", "Изпрати съобщение до:");
define("LANCONTACT_15", "Въведен е неправилен код");
define("LANCONTACT_16", "Въведи код");




?>