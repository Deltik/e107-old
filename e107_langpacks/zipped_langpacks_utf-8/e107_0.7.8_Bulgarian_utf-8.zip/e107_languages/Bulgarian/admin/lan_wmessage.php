<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_userinfo.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/16 15:42:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Message for Guests");
// define("WMGLAN_2", "Message for Members");
// define("WMGLAN_3", "Message for Administrators");
// define("WMGLAN_4", "Submit");
// define("WMGLAN_5", "Set Welcome Message");
// define("WMGLAN_6", "Activate?");
// define("WMGLAN_7", "Welcome message settings updated.");

define("WMLAN_00","Начално съобщение");
define("WMLAN_01","Създаване");
define("WMLAN_02","Съобщение");
define("WMLAN_03","Ще се вижда от");
define("WMLAN_04","Текст на съобщението");

define("WMLAN_05","Ограждане");
define("WMLAN_06","Ако отметнете, съобщението ще бъде оградено");
define("WMLAN_07","Системата да ползва краткия код {WMESSAGE}:");
// define("WMLAN_08","Preferences");

define("WMLAN_09","Все още няма начални съобщения");
define("WMLAN_10","Заглавие на съобщението");    

?>
