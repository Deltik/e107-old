<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_emoticon.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/14 16:32:23 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Активиране на емоциите");
define("EMOLAN_2", "Име");
define("EMOLAN_3", "Емоции");
define("EMOLAN_4", "Активиране на емоциите?");

define("EMOLAN_5", "Иконка");
define("EMOLAN_6", "Код за показване");
define("EMOLAN_7", "разделете с разтояние ако искате да полазвате иконата при повече от един код");

define("EMOLAN_8", "Статус");
define("EMOLAN_9", "Опции");
define("EMOLAN_10", "Активни");
define("EMOLAN_11", "Активиране на пакета");

define("EMOLAN_12", "Редакция / настройки на този пакет");
define("EMOLAN_13", "Налични пакети");

define("EMOLAN_14", "Запазване на настройките");
define("EMOLAN_15", "Редакция / настройки на емоциите");
define("EMOLAN_16", "Настройките са запомнени");
define("EMOLAN_17", "Имате пакет емотикони, в който са намерени празни места (space), което не е позволено!");
define("EMOLAN_18", "моля преименувайте всичко от списъка по-долу така че да няма празно място:");
define("EMOLAN_19", "Име");
define("EMOLAN_20", "Местоположение");
define("EMOLAN_21", "Грешка");
//define("EMOLAN_2", "Name");
define("EMOLAN_22", "Намерен нов пакет емоции:");
define("EMOLAN_23", "Намерен нов xml пакет емоции:");
define("EMOLAN_24", "Намерен нови php емоции:");
?>