<?php
$text = "Setting a new language will allow you to have a version of your content in that language on your site.";
$ns -> tablerender("Language Help", $text);
?>