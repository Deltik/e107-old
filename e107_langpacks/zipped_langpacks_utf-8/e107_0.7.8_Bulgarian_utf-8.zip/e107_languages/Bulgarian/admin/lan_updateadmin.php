<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/16 13:26:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Греша - моля опитайте отново");
define("UDALAN_2", "Настройките са запазени");
define("UDALAN_3", "Настройките са запазени за");
define("UDALAN_4", "Име");
define("UDALAN_5", "Парола");
define("UDALAN_6", "Повторете паролата");
define("UDALAN_7", "Смяна на парола");
define("UDALAN_8", "Смяна на парола за");

?>
