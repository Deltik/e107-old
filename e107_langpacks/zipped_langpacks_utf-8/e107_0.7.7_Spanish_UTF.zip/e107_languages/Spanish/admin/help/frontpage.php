<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/frontpage.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$caption = "Ayuda Página de Inicio";
$text = "Desde esta pantalla puede elegir qué mostrar en la página inicial de su sitio,
la predeterminada es noticias.
Puede asimismo usar esta página para configurar 'splashscreen',
una página que solo aparecerá cuando el visitante entra por primera vez a su sitio.";
$ns -> tablerender($caption, $text);
?>