<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/links.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Introduzca todos los enlaces de su sitio aquí.
Los enlaces se mostrarán en el menú principal de navegación.
Para los demás enlaces utilice la página de enlaces del plugin
<br />
";
$ns -> tablerender("Ayuda Enlaces", $text);
?>