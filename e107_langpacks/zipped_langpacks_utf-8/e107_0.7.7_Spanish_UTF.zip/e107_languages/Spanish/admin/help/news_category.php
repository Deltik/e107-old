<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/help/news_category.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/12/15 23:43:32 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }
$text = "Puede separar sus ítems nuevos en diferentes categorías,
y permitir a los visitantes desplegar los nuevos ítems en esas categorías. <br /><br />
Suba los íconos de sus noticias a ".e_THEME."-tutema-/images/ o images/newsicons/.";
$ns -> tablerender("Ayuda Categoría de noticias", $text);
?>