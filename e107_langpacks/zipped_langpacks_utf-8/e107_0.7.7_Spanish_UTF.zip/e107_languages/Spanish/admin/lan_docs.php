<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_docs.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/03 22:17:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
?>