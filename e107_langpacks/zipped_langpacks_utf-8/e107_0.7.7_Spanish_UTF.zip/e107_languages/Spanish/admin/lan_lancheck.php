<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/admin/lan_lancheck.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/11/10 19:17:11 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Editar/Verificar archivos de idioma"); // modified in 0.7.6
define("LAN_CHECK_2", "Verificar");
define("LAN_CHECK_3", "Verificación de");
define("LAN_CHECK_4", "¡Archivo perdido!");
define("LAN_CHECK_5", "¡Frase perdida!");

define("LAN_CHECK_7", "Frase");
define("LAN_CHECK_8", "Falta un archivo...");
define("LAN_CHECK_9", " Faltan archivos...");
define("LAN_CHECK_10", "Error crítico: ");
define("LAN_CHECK_11", "¡No falta/n archivo/s !");
define("LAN_CHECK_12", "Un archivo está mal...");
define("LAN_CHECK_13", " Los archivos están mal...");
define("LAN_CHECK_14", "¡Todos los archivos son válidos!");
define("LAN_CHECK_15", "Encontrados caácteres ilegales antes de '&lt;?php'"); 
define("LAN_CHECK_16", "Archivo Original"); 
define("LAN_CHECK_17", "Hubo un problema de escritura al intentar guardar el archivo."); 
define("LAN_CHECK_18", "No están disponibles los archivos de idiomas estandar para este plugin/tema.");
define("LAN_CHECK_19", "Encontrados carácteres No-UTF8");
?>