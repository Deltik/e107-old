<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_parser_functions.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/11/22 18:18:50 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Invitado");
define("LAN_WROTE", "escribió"); // as in John wrote.."  ";
?>