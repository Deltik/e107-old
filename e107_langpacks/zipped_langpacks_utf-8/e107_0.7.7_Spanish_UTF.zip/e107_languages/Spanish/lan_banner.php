<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_banner.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/06/17 10:47:07 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Anuncio");
define("BANNERLAN_16", "Usuario: ");
define("BANNERLAN_17", "Contraseña: ");
define("BANNERLAN_18", "Continuar");
define("BANNERLAN_19", "Por favor identifíquese con su nombre de usuario y contraseña para continuar");
define("BANNERLAN_20", "Lo sentimos, No se pueden encontrar esos detalles en nuestra base de datos. Por favor póngase en contacto con el administrador del sitio.");
define("BANNERLAN_21", "Estadísticas de la publicidad");
define("BANNERLAN_22", "Cliente");
define("BANNERLAN_23", "ID anuncio");
define("BANNERLAN_24", "Visitas");
define("BANNERLAN_25", "% Visitas");
define("BANNERLAN_26", "Impresiones");
define("BANNERLAN_27", "Impresiones Contratadas");
define("BANNERLAN_28", "Impresiones realizadas");
define("BANNERLAN_29", "Sin anuncios");
define("BANNERLAN_30", "Ilimitado");
define("BANNERLAN_31", "No aplicable");
define("BANNERLAN_32", "Si");
define("BANNERLAN_33", "No");
define("BANNERLAN_34", "Finaliza");
define("BANNERLAN_35", "Pulsado desde las direcciones IP");
define("BANNERLAN_36", "Activo:");
define("BANNERLAN_37", "Comienzo:");
define("BANNERLAN_38", "Error");
?>






