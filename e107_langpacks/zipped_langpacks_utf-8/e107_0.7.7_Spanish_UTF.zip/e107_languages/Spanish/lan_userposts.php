<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Spanish/lan_userposts.php,v $
|     $Revision: 1.11 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Envios de usuario");

define("UP_LAN_0", "Todos los mensajes en foros para ");
define("UP_LAN_1", "Todos los comentarios para ");
define("UP_LAN_2", "Tema");
define("UP_LAN_3", "Vistas");
define("UP_LAN_4", "Respuestas");
define("UP_LAN_5", "Último");
define("UP_LAN_6", "Temas");
define("UP_LAN_7", "Sin comentarios");
define("UP_LAN_8", "Sin mensajes");
define("UP_LAN_9", " el ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Enviado el: ");
define("UP_LAN_12", "Buscar");
define("UP_LAN_13", "Comentarios");
define("UP_LAN_14", "Envíos de foros");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "Dirección IP");
?>