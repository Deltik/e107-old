<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Spanish/lan_forum_uploads.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/11/11 23:57:40 $
|     $Author: natxocc $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Transferencias del foro");

define("FRMUP_1","Archivos transferidos al foro");
define("FRMUP_2","Archivo eliminado");
define("FRMUP_3","Error: Imposible eliminar archivo");
define("FRMUP_4","Eliminación del archivo");
define("FRMUP_5","Nombre del archivo");
define("FRMUP_6","Resultado");
define("FRMUP_7","Encontrado en el tema");
define("FRMUP_8","NO ENCONTRADO");
define("FRMUP_9","No se han encontrado archivos transferidos");
define("FRMUP_10","Eliminar");
?>