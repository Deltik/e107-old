<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.3 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("ONLINE_EL1", "vendég: ");
define("ONLINE_EL2", "tag: ");
define("ONLINE_EL3", "Ezen az oldalon: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Tagok");
define("ONLINE_EL6", "Legújabb tag");
define("ONLINE_EL7", "olvassa");

define("ONLINE_EL8", "legtöbb ");
define("ONLINE_EL9", "-");

define("ONLINE_TRACKING_MESSAGE", "Online felhasználók követése jelenleg kikapcsolva, ezt engedélyezheted [link=".e_ADMIN."users.php?options]itt[/link][br]");

?>
