<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - rev: 1.2 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CONT_SCH_LAN_1", "Tartalom");
define("CONT_SCH_LAN_2", "Összes Tartalom Kategória");
define("CONT_SCH_LAN_3", "Üzenetek az adott részben");
define("CONT_SCH_LAN_4", "-");
?>
