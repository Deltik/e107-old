<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("TOP_LAN_0", "A legtöbb üzenetet író a fórumban");
define("TOP_LAN_1", "Felhasználónév");
define("TOP_LAN_2", "Üzenetek");
define("TOP_LAN_3", "A legtöbb hozzászólást író tag");
define("TOP_LAN_4", "Hozzászólások");
define("TOP_LAN_5", "A legtöbb chatbox üzenetet író tag");
define("TOP_LAN_6", "Weblap értékelése");

//v.616
define("LAN_1", "Téma");
define("LAN_2", "Küldő");
define("LAN_3", "Megtekintés");
define("LAN_4", "Válaszok");
define("LAN_5", "Utolsó üzenet");
define("LAN_6", "Témák");
define("LAN_7", "Legaktívabb témák");
define("LAN_8", "Legtöbb üzenetet író tagok");

?>
