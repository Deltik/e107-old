<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("CUSLAN_1", "Cím");
define("CUSLAN_2", "Típus");
define("CUSLAN_3", "Beállítások");
define("CUSLAN_4", "Törlöd ezt az oldalt?");
define("CUSLAN_5", "Létező oldalak");
define("CUSLAN_7", "Menü Neve");
define("CUSLAN_8", "Cím / Fejléc");
define("CUSLAN_9", "Szöveg");
define("CUSLAN_10", "Oldal értékelés engedélyezése");
define("CUSLAN_11", "Kezdőlap");
define("CUSLAN_12", "Oldal létrehozása");
define("CUSLAN_13", "Hozzászólás engedélyezése");
define("CUSLAN_14", "Jelszóval védett oldal");
define("CUSLAN_15", "írd be a jelszót");
define("CUSLAN_16", "Link létrehozása a Főmenüben");
define("CUSLAN_17", "írd be a link nevét");
define("CUSLAN_18", "Oldal / link elérhetőség");
define("CUSLAN_19", "Oldal frissítése");
define("CUSLAN_20", "Oldal létrehozása");
define("CUSLAN_21", "Menü frissítése");
define("CUSLAN_22", "Menü létrehozása");
define("CUSLAN_23", "Oldal szerkesztése");
define("CUSLAN_24", "Új oldal létrehozása");
define("CUSLAN_25", "Menü szerkesztése");
define("CUSLAN_26", "Új menü létrehozása");
define("CUSLAN_27", "Oldal adatbázisban elmentve.");
define("CUSLAN_28", "Oldal törölve");
define("CUSLAN_29", "Oldal lista, ha nincs oldal kiválasztva");
define("CUSLAN_30", "Cookie lejárati ideje (másodpercben)");
define("CUSLAN_31", "Menü létrehozása");
define("CUSLAN_32", "Régi oldalak/menük konvertálása");
define("CUSLAN_33", "Oldal beállítások");
define("CUSLAN_34", "KOnverzió megkezdése");
define("CUSLAN_35", "Saját oldal frissítése befejeződött - frissítve");
define("CUSLAN_36", "Az oldal beállítások kiválasztásához lépj vissza a kezdőoldalra és válaszd az oldal szerkesztését.");
define("CUSLAN_37", "Saját oldal frissítése");
define("CUSLAN_38", "be");
define("CUSLAN_39", "ki");
define("CUSLAN_40", "Beállítások mentése");

define("CUSLAN_41", "Szerző és dátum információk megjelenítése");
define("CUSLAN_42", "Még nics oldal beállítva");
?>
