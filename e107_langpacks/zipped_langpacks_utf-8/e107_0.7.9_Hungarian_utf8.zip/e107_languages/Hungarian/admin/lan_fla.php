<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("FLALAN_1", "Sikertelen belépési kísérletek");
define("FLALAN_2", "Nincs sikertelen belépési kísérlet rögzítve");
define("FLALAN_3", "Kísérlet törölve");
define("FLALAN_4", "A felhasználó a belépési kisérlethez nem megfelelő felhasználónevet/jelszót használt");
define("FLALAN_5", "IP(-k) kitiltva");
define("FLALAN_6", "Dátum");
define("FLALAN_7", "Adat");
define("FLALAN_8", "IP cím/kiszolgáló");
define("FLALAN_9", "Beállítások");
define("FLALAN_10", "Törlése / kitíltás kiválasztása");
define("FLALAN_11", "Összes kiválasztása törléshez");
define("FLALAN_12", "Törlés kiválasztás visszavonása");
define("FLALAN_13", "Összes kiválasztása kitíltáshoz");
define("FLALAN_14", "Kitíltás kiválasztás visszavonása");
define("FLALAN_15", "A következő IP cím(-ek) automatikusan kitíltásra kerülnek - felhasználó 10-nél többször kisérelte meg a belépést");
define("FLALAN_16", "Automatikus kitiltás lista törlése");
define("FLALAN_17", "Automatikus kitiltás lista törölve");
?>
