<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("LAN_UPDATE_2", "Műveletek");
define("LAN_UPDATE_3", "Nem szükséges");

define("LAN_UPDATE_5", "Van(nak) frissítés(ek)");
define("LAN_UPDATE_7", "Futtatás");
define("LAN_UPDATE_8", "Frissítés:");
define("LAN_UPDATE_9", " -> ");
define("LAN_UPDATE_10", "Elérhető frissítések");
define("LAN_UPDATE_11", ".617 -> .7 frissítés folytatása");
define("LAN_UPDATE_12", "Az egyik táblád duplikált bejegyzéseket tartalmaz.");
?>
