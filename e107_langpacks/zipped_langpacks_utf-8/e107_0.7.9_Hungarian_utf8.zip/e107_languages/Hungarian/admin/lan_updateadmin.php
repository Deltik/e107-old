<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UDALAN_1", "Hiba - küldd el újra");
define("UDALAN_2", "Beállítások frissítve");
define("UDALAN_3", "Beállítások frissítve:");
define("UDALAN_4", "Név");
define("UDALAN_5", "Jelszó");
define("UDALAN_6", "Jelszó megerősítése");
define("UDALAN_7", "Jelszó módosítása");
define("UDALAN_8", "Jelszó módosítása erre:");

?>