<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("UCSLAN_1", "Értesítés küldése");
define("UCSLAN_2", "Jogosultságok frissítése");
define("UCSLAN_3", "Kedves");
define("UCSLAN_4", "Jogosultságaid frissítve a következő oldalon:");
define("UCSLAN_5", "Mostantól elérheted a következő részleg(ek)et:");
define("UCSLAN_6", "Csoport beállítása felhasználóra");
define("UCSLAN_7", "Csoport beállítása");
define("UCSLAN_8", "Felhasználó értesítése");
define("UCSLAN_9", "Csoportok frissítve");
define("UCSLAN_10", "Üdvözlettel");
?>