<?php
# --------------------------------------------------------------------------
# e107 hungarian language file - ver: 0.700 - author: e107hungary.org team - 2006
# --------------------------------------------------------------------------

define("USFLAN_1", "IP cím meghatározatlan - nem áll rendelkezésre információ");
//define("USFLAN_2", "Hiba");
define("USFLAN_3", "Ezen IP címről küldött üzenetek");
define("USFLAN_4", "Kiszolgáló");
define("USFLAN_5", "IP cím blokkolása");
define("USFLAN_6", "Felhasználó ID");
define("USFLAN_7", "Felhasználó információ");

?>