<?php

interface SecureLinkDecorator
{
	public function decorate();
}