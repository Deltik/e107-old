<?php
/*
 * e107 website system
 *
 * Copyright (C) 2008-2013 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * BBCODE template - to be used by the bbcode editor
 *
 */


$BBCODE_TEMPLATE['forum'] = "
	<div class='field-spacer'><!-- --></div>
    {BB=link}{BB=b}{BB=i}{BB=u}{BB=img}{BB=format}{BB=left}{BB=center}{BB=right}{BB=justify}
	{BB=list}{BB=fontcol}{BB=fontsize}{BB=emotes}{BB=youtube}
	<div class='field-spacer'><!-- --></div>
";
