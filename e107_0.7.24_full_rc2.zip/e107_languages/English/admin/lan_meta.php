<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_meta.php $
|     $Revision: 11678 $
|     $Id: lan_meta.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags updated in database");
define("METLAN_2", "Enter additional meta-tags");
define("METLAN_3", "Enter new meta tag settings");
define("METLAN_4", "Updated");
define("METLAN_5", "type your description here");
define("METLAN_6", "type, a, list, of, your, keywords, here");
define("METLAN_7", "type your copyright info here");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "Description");
define("METLAN_10", "Keywords");
define("METLAN_11", "Copyright");
define("METLAN_12", "Use News title and summary as the meta-description on news pages.");
define("METLAN_13", "Author");

?>