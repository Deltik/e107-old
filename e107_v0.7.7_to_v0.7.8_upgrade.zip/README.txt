0.7.7 -> 0.7.8 Upgrade Guide

This is an update from 0.7.7 to 0.7.8 only.  If you are upgrading from any other version besides 0.7.7, then you have downloaded the wrong package.  For those users that have been using the current CVS version of e107, this is the correct version to use.

Included in these releases are security related file changes and so you must upgrade your site with all these files.

To install simply upload the files to your server overwriting the existing 0.7.7 files.

There may be some database changes in this release, so you will be required to login to the site admin account, go to the main admin page and perform the database upgrades indicated.

