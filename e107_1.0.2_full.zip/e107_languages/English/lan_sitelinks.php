<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_sitelinks.php $
|     $Revision: 11678 $
|     $Id: lan_sitelinks.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Main Menu");
define("LAN_SITELINKS_502", "Admin Area");

?>