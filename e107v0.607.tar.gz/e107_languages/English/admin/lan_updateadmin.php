<?php

define("UDALAN_1", "Error - please re-submit");
define("UDALAN_2", "Settings updated");
define("UDALAN_3", "Settings Updated for");
define("UDALAN_4", "Name");
define("UDALAN_5", "Password");
define("UDALAN_6", "Re-type Password");
define("UDALAN_7", "Change Password");
define("UDALAN_8", "Password Update for");

?>